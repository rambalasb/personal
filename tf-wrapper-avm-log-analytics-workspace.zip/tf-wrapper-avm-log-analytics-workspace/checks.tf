check "internet_ingestion_disabled_by_default" {
  assert {
    condition     = var.log_analytics_workspace_internet_ingestion_enabled != "true"
    error_message = "Public internet ingestion is enabled. Prefer 'false' or 'SecuredByPerimeter' and route ingestion through private endpoints / AMPLS."
  }
}

check "internet_query_disabled_by_default" {
  assert {
    condition     = var.log_analytics_workspace_internet_query_enabled != "true"
    error_message = "Public internet querying is enabled. Prefer 'false' or 'SecuredByPerimeter' and route queries through private endpoints / AMPLS."
  }
}

check "private_endpoint_implies_no_public_ingestion" {
  assert {
    condition     = length(var.private_endpoints) == 0 || var.log_analytics_workspace_internet_ingestion_enabled != "true"
    error_message = "Private endpoints are configured but public internet ingestion is still 'true'. Set log_analytics_workspace_internet_ingestion_enabled to 'false' or 'SecuredByPerimeter'."
  }
}

check "private_endpoint_implies_no_public_query" {
  assert {
    condition     = length(var.private_endpoints) == 0 || var.log_analytics_workspace_internet_query_enabled != "true"
    error_message = "Private endpoints are configured but public internet querying is still 'true'. Set log_analytics_workspace_internet_query_enabled to 'false' or 'SecuredByPerimeter'."
  }
}

check "retention_meets_compliance_minimum" {
  assert {
    condition     = var.log_analytics_workspace_retention_in_days == null || var.log_analytics_workspace_retention_in_days >= 30
    error_message = "Workspace retention should be at least 30 days for most compliance frameworks. Current value is below 30."
  }
}

check "daily_quota_set_for_cost_control" {
  assert {
    condition     = var.log_analytics_workspace_daily_quota_gb != null
    error_message = "log_analytics_workspace_daily_quota_gb is unset (unlimited). Consider setting a daily cap to avoid runaway ingestion costs."
  }
}
