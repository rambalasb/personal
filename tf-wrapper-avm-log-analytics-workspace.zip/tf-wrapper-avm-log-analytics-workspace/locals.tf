locals {
  module_tags = merge(
    var.tags == null ? {} : var.tags,
    {
      managed-by = "terraform"
      module     = "tf-wrapper-avm-log-analytics-workspace"
    }
  )

  has_private_endpoints  = length(var.private_endpoints) > 0
  internet_ingestion_off = var.log_analytics_workspace_internet_ingestion_enabled == "false"
  internet_query_off     = var.log_analytics_workspace_internet_query_enabled == "false"
}
