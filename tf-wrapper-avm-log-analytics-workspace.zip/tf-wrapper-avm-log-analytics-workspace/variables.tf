# =====================================================================
# Required inputs
# =====================================================================

variable "name" {
  type        = string
  description = "The name of the Log Analytics Workspace. 4-63 characters; alphanumerics and hyphens; must start and end with an alphanumeric."

  validation {
    condition     = can(regex("^[A-Za-z0-9][A-Za-z0-9-]{2,61}[A-Za-z0-9]$", var.name))
    error_message = "name must be 4-63 characters, alphanumerics and hyphens, starting and ending with alphanumeric."
  }
}

variable "resource_group_name" {
  type        = string
  description = "The name of the Resource Group where the Log Analytics Workspace will be deployed."

  validation {
    condition     = length(var.resource_group_name) > 0 && length(var.resource_group_name) <= 90
    error_message = "resource_group_name must be between 1 and 90 characters."
  }
}

variable "location" {
  type        = string
  description = "The Azure region where the Log Analytics Workspace will be deployed."

  validation {
    condition     = length(var.location) > 0
    error_message = "location must not be empty."
  }
}

# =====================================================================
# Workspace toggles
# =====================================================================

variable "log_analytics_workspace_sku" {
  type        = string
  description = "Workspace SKU. Valid: 'Free', 'PerNode', 'Premium', 'Standard', 'Standalone', 'Unlimited', 'CapacityReservation', 'PerGB2018'. Defaults to 'PerGB2018' upstream."
  default     = null

  validation {
    condition     = var.log_analytics_workspace_sku == null || contains(["Free", "PerNode", "Premium", "Standard", "Standalone", "Unlimited", "CapacityReservation", "PerGB2018"], coalesce(var.log_analytics_workspace_sku, "PerGB2018"))
    error_message = "log_analytics_workspace_sku must be one of: Free, PerNode, Premium, Standard, Standalone, Unlimited, CapacityReservation, PerGB2018, or null."
  }
}

variable "log_analytics_workspace_retention_in_days" {
  type        = number
  description = "Workspace data retention in days. Valid: 7 (Free tier only) or 30-730."
  default     = null

  validation {
    condition     = var.log_analytics_workspace_retention_in_days == null ? true : (var.log_analytics_workspace_retention_in_days == 7 || (var.log_analytics_workspace_retention_in_days >= 30 && var.log_analytics_workspace_retention_in_days <= 730))
    error_message = "log_analytics_workspace_retention_in_days must be 7 (Free tier) or between 30 and 730."
  }
}

variable "log_analytics_workspace_daily_quota_gb" {
  type        = number
  description = "Daily ingestion cap in GB. Defaults to -1 (unlimited) when null."
  default     = null
}

variable "log_analytics_workspace_reservation_capacity_in_gb_per_day" {
  type        = number
  description = "Capacity reservation level in GB. Valid: 100, 200, 300, 400, 500, 1000, 2000, 5000."
  default     = null

  validation {
    condition     = var.log_analytics_workspace_reservation_capacity_in_gb_per_day == null || contains([100, 200, 300, 400, 500, 1000, 2000, 5000], coalesce(var.log_analytics_workspace_reservation_capacity_in_gb_per_day, 0))
    error_message = "log_analytics_workspace_reservation_capacity_in_gb_per_day must be one of: 100, 200, 300, 400, 500, 1000, 2000, 5000, or null."
  }
}

variable "log_analytics_workspace_internet_ingestion_enabled" {
  type        = string
  description = "Whether public internet ingestion is permitted. Valid: 'true', 'false', 'SecuredByPerimeter'. Defaults to 'false'."
  default     = "false"

  validation {
    condition     = contains(["true", "false", "SecuredByPerimeter"], var.log_analytics_workspace_internet_ingestion_enabled)
    error_message = "log_analytics_workspace_internet_ingestion_enabled must be 'true', 'false', or 'SecuredByPerimeter'."
  }
}

variable "log_analytics_workspace_internet_query_enabled" {
  type        = string
  description = "Whether public internet querying is permitted. Valid: 'true', 'false', 'SecuredByPerimeter'. Defaults to 'false'."
  default     = "false"

  validation {
    condition     = contains(["true", "false", "SecuredByPerimeter"], var.log_analytics_workspace_internet_query_enabled)
    error_message = "log_analytics_workspace_internet_query_enabled must be 'true', 'false', or 'SecuredByPerimeter'."
  }
}

variable "log_analytics_workspace_local_authentication_enabled" {
  type        = bool
  description = "Whether the workspace allows non-Azure-AD authentication. Defaults to true upstream; set false to enforce Azure AD."
  default     = true
}

variable "log_analytics_workspace_allow_resource_only_permissions" {
  type        = bool
  description = "Whether users can access data for resources they have permission on, without workspace permission."
  default     = null
}

variable "log_analytics_workspace_cmk_for_query_forced" {
  type        = bool
  description = "Whether Customer Managed Storage is mandatory for query management."
  default     = null
}

variable "log_analytics_workspace_dedicated_cluster_resource_id" {
  type        = string
  description = "Resource ID of a dedicated Log Analytics cluster to link this workspace to."
  default     = null
}

variable "log_analytics_workspace_identity" {
  type = object({
    identity_ids = optional(set(string))
    type         = string
  })
  description = "Managed identity for the workspace. type: 'SystemAssigned' or 'UserAssigned'. identity_ids required when type is 'UserAssigned'."
  default     = null

  validation {
    condition     = var.log_analytics_workspace_identity == null || contains(["SystemAssigned", "UserAssigned"], try(var.log_analytics_workspace_identity.type, ""))
    error_message = "log_analytics_workspace_identity.type must be 'SystemAssigned' or 'UserAssigned'."
  }
}

variable "log_analytics_workspace_timeouts" {
  type = object({
    create = optional(string)
    delete = optional(string)
    read   = optional(string)
    update = optional(string)
  })
  description = "Operation timeouts for the workspace resource."
  default     = null
}

# =====================================================================
# Workspace content (tables, data exports, linked storage)
# =====================================================================

variable "log_analytics_workspace_tables" {
  type = map(object({
    name                    = string
    resource_id             = optional(string)
    retention_in_days       = optional(number)
    total_retention_in_days = optional(number)
    plan                    = optional(string)
    schema = optional(object({
      name        = optional(string)
      description = optional(string)
      columns = optional(list(object({
        name = string
        type = string
      })), [])
    }))
  }))
  description = "Map of tables to create in the workspace."
  default     = {}
}

variable "log_analytics_workspace_tables_update" {
  type = map(object({
    name                    = string
    resource_id             = optional(string)
    retention_in_days       = optional(number)
    total_retention_in_days = optional(number)
    plan                    = optional(string)
    schema = optional(object({
      name        = optional(string)
      description = optional(string)
      columns = optional(list(object({
        name = string
        type = string
      })), [])
    }))
  }))
  description = "Map of tables to update (e.g. add columns to default tables like Heartbeat or Syslog)."
  default     = {}
}

variable "log_analytics_workspace_data_exports" {
  type = map(object({
    name                    = string
    table_names             = list(string)
    destination_resource_id = string
    enabled                 = optional(bool, true)
    event_hub_name          = optional(string, null)
  }))
  description = "Map of data export rules. destination_resource_id can be a Storage Account or Event Hub Namespace ID."
  default     = {}
}

variable "log_analytics_workspace_linked_storage_accounts" {
  type = map(object({
    data_source_type    = string
    storage_account_ids = list(string)
  }))
  description = "Map of linked storage accounts. data_source_type: 'CustomLogs', 'AzureWatson', 'Query', 'Ingestion', 'Alerts'."
  default     = {}
}

# =====================================================================
# Networking — private endpoints, private link scope, NSP
# =====================================================================

variable "private_endpoints" {
  type = map(object({
    name = optional(string, null)
    role_assignments = optional(map(object({
      role_definition_id_or_name             = string
      principal_id                           = string
      description                            = optional(string, null)
      skip_service_principal_aad_check       = optional(bool, false)
      condition                              = optional(string, null)
      condition_version                      = optional(string, null)
      delegated_managed_identity_resource_id = optional(string, null)
      principal_type                         = optional(string, null)
    })), {})
    lock = optional(object({
      kind = string
      name = optional(string, null)
    }), null)
    tags                                    = optional(map(string), null)
    subnet_resource_id                      = string
    private_dns_zone_group_name             = optional(string, "default")
    private_dns_zone_resource_ids           = optional(set(string), [])
    application_security_group_associations = optional(map(string), {})
    private_service_connection_name         = optional(string, null)
    network_interface_name                  = optional(string, null)
    location                                = optional(string, null)
    resource_group_name                     = optional(string, null)
    ip_configurations = optional(map(object({
      name               = string
      private_ip_address = string
    })), {})
  }))
  description = "Map of private endpoints to create on the workspace."
  default     = {}
}

variable "private_endpoint_extensions" {
  type = map(object({
    monitor_private_link_scope_key = optional(string, null)
    monitor_private_link_scope_exclusion = optional(object({
      exclude               = optional(bool, true)
      ingestion_access_mode = optional(string, "PrivateOnly")
      query_access_mode     = optional(string, "PrivateOnly")
    }), null)
    manage_dns_zone_group = optional(bool, true)
  }))
  description = "Map of private endpoint extensions for Monitor Private Link Scope association. Map key must match var.private_endpoints."
  default     = {}
}

variable "monitor_private_link_scope" {
  type = map(object({
    name                  = optional(string)
    resource_id           = string
    ingestion_access_mode = optional(string, "PrivateOnly")
    query_access_mode     = optional(string, "PrivateOnly")
    exclusions = optional(list(object({
      ingestion_access_mode            = optional(string, "PrivateOnly")
      query_access_mode                = optional(string, "PrivateOnly")
      private_endpoint_connection_name = string
    })), [])
    lock = optional(object({
      kind = string
      name = optional(string, null)
    }))
  }))
  description = "Map of Monitor Private Link Scopes to create. resource_id is the Resource Group ID where the AMPLS will be created."
  default     = {}
}

variable "monitor_private_link_scoped_resource" {
  type = map(object({
    name        = optional(string)
    resource_id = string
    exclusions = optional(list(object({
      ingestion_access_mode            = optional(string, "PrivateOnly")
      query_access_mode                = optional(string, "PrivateOnly")
      private_endpoint_connection_name = string
    })), [])
  }))
  description = "Map of existing Monitor Private Link Scopes to attach this workspace to."
  default     = {}
}

variable "monitor_private_link_scoped_service_name" {
  type        = string
  description = "Name of the scoped service to connect to the Monitor Private Link Scope."
  default     = null
}

variable "network_security_perimeter_association" {
  type = object({
    resource_id  = string
    profile_name = string
    access_mode  = optional(string, "Learning")
  })
  description = "Network Security Perimeter association. access_mode: 'Learning', 'Enforced', or 'Audit'."
  default     = null

  validation {
    condition     = var.network_security_perimeter_association == null || contains(["Learning", "Enforced", "Audit"], try(var.network_security_perimeter_association.access_mode, "Learning"))
    error_message = "network_security_perimeter_association.access_mode must be 'Learning', 'Enforced', or 'Audit'."
  }
}

# =====================================================================
# RBAC, identity, encryption
# =====================================================================

variable "role_assignments" {
  type = map(object({
    role_definition_id_or_name             = string
    principal_id                           = string
    description                            = optional(string, null)
    skip_service_principal_aad_check       = optional(bool, false)
    condition                              = optional(string, null)
    condition_version                      = optional(string, null)
    delegated_managed_identity_resource_id = optional(string, null)
    principal_type                         = optional(string, null)
  }))
  description = "Map of RBAC role assignments scoped to the workspace. Common roles: 'Log Analytics Reader', 'Log Analytics Contributor', 'Monitoring Contributor'."
  default     = {}
}

variable "customer_managed_key" {
  type = object({
    key_vault_resource_id = string
    key_name              = string
    key_version           = optional(string, null)
    user_assigned_identity = optional(object({
      resource_id = string
    }), null)
  })
  description = "Customer-managed key configuration for workspace encryption."
  default     = null
}

# =====================================================================
# Diagnostics, locks, tags
# =====================================================================

variable "diagnostic_settings" {
  type = map(object({
    name                                     = optional(string, null)
    log_categories                           = optional(set(string), [])
    log_groups                               = optional(set(string), ["allLogs"])
    metric_categories                        = optional(set(string), ["AllMetrics"])
    log_analytics_destination_type           = optional(string, "Dedicated")
    workspace_resource_id                    = optional(string, null)
    storage_account_resource_id              = optional(string, null)
    event_hub_authorization_rule_resource_id = optional(string, null)
    event_hub_name                           = optional(string, null)
    marketplace_partner_resource_id          = optional(string, null)
  }))
  description = "Diagnostic settings for the workspace."
  default     = {}
}

variable "lock" {
  type = object({
    kind = string
    name = optional(string, null)
  })
  description = "Optional resource lock. kind must be 'CanNotDelete' or 'ReadOnly'."
  default     = null

  validation {
    condition     = var.lock == null || contains(["CanNotDelete", "ReadOnly"], try(var.lock.kind, ""))
    error_message = "lock.kind must be 'CanNotDelete' or 'ReadOnly' when lock is set."
  }
}

variable "enable_telemetry" {
  type        = bool
  description = "Whether to enable AVM module telemetry. Set false to opt out."
  default     = true
}

variable "tags" {
  type        = map(string)
  description = "A map of tags to apply to the workspace."
  default     = null
}
