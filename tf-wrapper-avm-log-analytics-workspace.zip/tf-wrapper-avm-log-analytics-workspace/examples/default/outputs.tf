output "resource_id" {
  value = module.log_analytics_workspace.resource_id
}

output "name" {
  value = azurerm_resource_group.this.name
}

output "private_endpoints" {
  value = module.log_analytics_workspace.private_endpoints
}
