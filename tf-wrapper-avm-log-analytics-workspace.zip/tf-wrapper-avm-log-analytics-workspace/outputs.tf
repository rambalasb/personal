output "resource_id" {
  description = "The Azure resource ID of the Log Analytics Workspace."
  value       = module.log_analytics_workspace.resource_id
}

output "resource" {
  description = "The full azurerm_log_analytics_workspace resource object. Sensitive."
  value       = module.log_analytics_workspace.resource
  sensitive   = true
}

output "private_endpoints" {
  description = "Map of private endpoints created on the workspace, keyed by the input map key."
  value       = module.log_analytics_workspace.private_endpoints
}
