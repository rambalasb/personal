locals {
  web_app_app_settings = {
    for app_key, app in var.web_app : app_key => merge(app.app_settings, lookup(var.web_app_secret_app_settings, app_key, {}))
  }

  web_app_connection_strings = {
    for app_key, app in var.web_app : app_key => {
      for cs_key, cs in app.connection_strings : cs_key => {
        name  = cs.name
        type  = cs.type
        value = try(var.web_app_secret_connection_strings[app_key][cs_key], null)
      }
    }
  }
}

module "web_app" {
  for_each = var.enable_web_app ? var.web_app : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-web-app/azurerm"
  version = "0.0.5"

  name                     = each.value.name
  subscription_id          = var.subscription_id
  resource_group_name      = module.resource_group[each.value.resource_group_key].name
  location                 = coalesce(each.value.location, module.resource_group[each.value.resource_group_key].location)
  os_type                  = each.value.os_type
  service_plan_resource_id = "/subscriptions/${var.subscription_id}/resourceGroups/${var.resource_group[var.app_service_plan[each.value.app_service_plan_key].resource_group_key].name}/providers/Microsoft.Web/serverFarms/${var.app_service_plan[each.value.app_service_plan_key].name}"
  hosting_environment_id   = "/subscriptions/${var.subscription_id}/resourceGroups/${var.resource_group[var.app_service_environment[each.value.app_service_environment_key].resource_group_key].name}/providers/Microsoft.Web/hostingEnvironments/${var.app_service_environment[each.value.app_service_environment_key].name}"

  enabled                                  = each.value.enabled
  https_only                               = each.value.https_only
  public_network_access_enabled            = each.value.public_network_access_enabled
  client_affinity_enabled                  = each.value.client_affinity_enabled
  client_affinity_proxy_enabled            = each.value.client_affinity_proxy_enabled
  client_certificate_enabled               = each.value.client_certificate_enabled
  client_certificate_mode                  = each.value.client_certificate_mode
  end_to_end_encryption_enabled            = each.value.end_to_end_encryption_enabled
  host_names_disabled                      = each.value.host_names_disabled
  hyper_v                                  = each.value.hyper_v
  ip_mode                                  = each.value.ip_mode
  redundancy_mode                          = each.value.redundancy_mode
  vnet_route_all_traffic                   = each.value.vnet_route_all_traffic
  vnet_application_traffic_enabled         = each.value.vnet_application_traffic_enabled
  vnet_image_pull_enabled                  = each.value.vnet_image_pull_enabled
  vnet_content_share_enabled               = each.value.vnet_content_share_enabled
  virtual_network_backup_restore_enabled   = each.value.virtual_network_backup_restore_enabled
  ftp_publish_basic_authentication_enabled = each.value.ftp_publish_basic_authentication_enabled
  scm_publish_basic_authentication_enabled = each.value.scm_publish_basic_authentication_enabled
  key_vault_reference_identity             = each.value.key_vault_reference_identity
  site_config                              = each.value.site_config
  tags                                     = each.value.tags

  managed_identities = {
    system_assigned            = false
    user_assigned_resource_ids = each.value.user_assigned_identity_ids
  }

  # The module rewrites the full settings lists on every apply, so these must
  # hold every live entry.
  app_settings       = local.web_app_app_settings[each.key]
  connection_strings = local.web_app_connection_strings[each.key]
  sticky_settings = {
    for k in(length(each.value.sticky_app_setting_names) > 0 ? ["default"] : []) : k => {
      app_setting_names = each.value.sticky_app_setting_names
    }
  }

  # Hostname bindings, certificates, log settings (SAS URLs) and the private
  # endpoint are left alone.
  custom_domains      = {}
  certificates        = {}
  logs                = {}
  backup              = {}
  private_endpoints   = {}
  deployment_slots    = {}
  role_assignments    = {}
  diagnostic_settings = {}
  lock                = null
  enable_telemetry    = false
}

import {
  for_each = var.enable_web_app ? var.web_app_imports : {}

  to = module.web_app[each.key].module.web_app.azapi_resource.this
  id = each.value
}
