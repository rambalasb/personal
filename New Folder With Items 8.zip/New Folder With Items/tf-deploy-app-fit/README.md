# tf-deploy-app-fit

Terraform that adopts the existing **FIT** (Field Investigation Tool)
resources into state, following the same layout as the Fabric and PTA
deploy repos.

| Environment | Subscription | ID |
|---|---|---|
| `nonprod` | Sub-Fit-NonProd | `fa089a5b-f881-41a6-a30f-58bfdfd52abd` |
| `prod` | Sub-Fit-Prod | `0aa40f3e-3340-444e-bfac-d01a42a54ad1` |

Use Terraform `>= 1.9, < 2.0`, one state per environment, and select
`envs/nonprod.tfvars` or `envs/prod.tfvars`. Adopt nonprod first; prod follows
the same runs and stages.

## Status

**Nonprod** is filled from the Azure resource export of 2026-10-20 and is
ready for the first import run. The Oracle VM and its NIC, the web app and
the VNet are filled in but switched off; they are adopted later, one stage at
a time (see [Staged adoption](#staged-adoption)).

**Prod** is filled from its own export of 2026-10-20 the same way, with the
same staged tiers (the Oracle VM and its NIC, the web app `app-fit-prod`,
then the VNet). Prod differs from nonprod:

- Three private DNS zones (the ASE zone, its `privatelink.` copy and a local
  `privatelink.blob.core.windows.net`), with their VNet links.
- Two storage accounts plus `stfitrestore` and its private endpoint
  `pep-fit-restore`; `stfitprodcac001` has public access enabled and is
  read-only.
- Several data disks in the prod resource group carry `nonprod` in their
  names; they are data disks and stay unmanaged either way.
- The web app's masked settings are `APPLICATIONINSIGHTS_CONNECTION_STRING`,
  `ESB_USER`, `ESBUserName`, plus the `ConnectionString` connection string.
- Alerts that stay out are listed at `alert_processing_rule_imports` in
  `envs/prod.tfvars`.

## Tiers

| File | Implementation | Nonprod |
|---|---|---|
| `resource_group.tf` | `tf-wrapper-avm-resource-group` 2.0.0 | 7, enabled |
| `alerts.tf` | `tf-wrapper-avm-ptn-monitoring-amba-alz` 0.3.3 | 6 activity log, 13 metric, 10 log search alerts, 2 processing rules, enabled |
| `app_service_environment.tf` | `tf-wrapper-avm-app-service-environment` 0.1.0 | 1, enabled |
| `app_service_plan.tf` | `tf-wrapper-avm-app-service-plan` 0.1.0 | 1, enabled |
| `application_insights.tf` | `tf-wrapper-avm-application-insights` 0.1.0 | 1, enabled |
| `bastion_host.tf` | `tf-wrapper-avm-bastion-host` 0.0.1 | 1 Developer SKU, enabled |
| `key_vault.tf` | `tf-wrapper-avm-key-vault` 0.4.0 | 1, enabled |
| `log_analytics_workspace.tf` | `tf-wrapper-avm-log-analytics-workspace` 0.1.2 | 1, enabled |
| `network_security_group.tf` | `tf-wrapper-avm-network-security-group` 0.1.1 | 3 + 9 rules, enabled |
| `network_watcher.tf` | `azurerm_network_watcher` | 1, enabled |
| `private_dns_zone.tf` | `tf-wrapper-avm-private-dns-zone` 1.0.0 | 1 + 3 VNet links, enabled |
| `private_endpoint.tf` | `tf-wrapper-avm-private-endpoint` 0.1.2 | 4, enabled |
| `recovery_services_vault.tf` | `tf-wrapper-avm-recovery-services-vault` 0.1.0 | 1, enabled |
| `restore_point_collection.tf` | `azurerm_virtual_machine_restore_point_collection` | 2, enabled |
| `storage_account.tf` | `azurerm_storage_account`; read-only `azapi_resource` data source | 0 + 2 read-only, enabled |
| `event_grid_system_topic.tf` | `azurerm_eventgrid_system_topic` | 2, enabled |
| `user_assigned_identity.tf` | `tf-wrapper-avm-user-assigned-identity` 0.0.4 | 1, enabled |
| `virtual_network.tf` | `tf-wrapper-avm-virtual-network` 0.1.0 | 1 + 3 subnets, disabled (hub connection) |
| `linux_virtual_machine.tf` | `tf-wrapper-avm-virtual-machine-linux` 0.0.7 | 1, disabled (separate run) |
| `network_interface.tf` | NIC inventory for the VM; no NSG associations | 1, disabled (with the VM) |
| `public_ssh_key.tf` | `azurerm_ssh_public_key` | 1, enabled |
| `web_app.tf` | `tf-wrapper-avm-web-app` 0.0.5 | 1, disabled (see below) |
| `role_assignment.tf` | `tf-wrapper-avm-role-assignment` 0.3.6 | all off |
| `compute_disk.tf` | `removed` block only | - |

Storage accounts with public network access enabled are read with
`data.azapi_resource.storage_account_existing` (`storage_account_existing`
in tfvars) instead of being managed: `Deny_Public_Access_On_PaaS_Services_v0`
denies any write to them, adoption included. Move an account into
`storage_account` once it has a policy exemption. They are listed under
"Blocked by policy" in [WRAPPER-GAPS.md](WRAPPER-GAPS.md).

The SSH key uses AzureRM directly because the upstream AVM module only
accepts lowercase alphanumeric names. Wrapper tags are switched off where
the wrapper allows it; the LAW, UAI, RSV, App Service, App Insights, DNS zone and monitoring wrappers
still add `managed-by`/`module` tags, so expect a tag update on those.

What stays unmanaged is in [WRAPPER-GAPS.md](WRAPPER-GAPS.md).

## Things to check before the first import

- **ASE:** `zone_redundancy_enabled` and the subnet force replacement. Both
  match the export, and every setting is passed because the wrapper defaults
  (zone redundant, internal encryption on) differ from the deployed ASE.
- **App Service plan:** worker count (1) and zone balancing (off) are set
  explicitly; the wrapper defaults are 3 and on.
- **App Insights** sends to `la-siem-security-canadacentral-001` in the
  security subscription. The daily cap was not exported; 100 GB is assumed.
- **NSG rules:** protocols are written as `Tcp`/`Icmp` because the wrapper
  rejects upper case. Azure reports `TCP`/`ICMP`, so a case-only update may
  appear.
- **App Service Environment:** `tls_1_enabled` is required per environment.
  `false` makes the upstream module add the `DisableTls1.0` cluster setting,
  so it must match the live ASE (`properties.clusterSettings`). Nonprod has
  no cluster settings, so it is `true`.
- **Storage:** both nonprod accounts have public network access enabled, so
  they are read, not adopted (see "Blocked by policy" in WRAPPER-GAPS).
- **Alerts:** three action group IDs contain a leading space
  (`actiongroups/ ag-...`). Kept as exported.
- **Private endpoint** `pep-func-fit-nonprod-canadacentral-001` points at a
  function app that no longer exists. In prod, `pep-app-fit-prod-canadacentral-001`
  and `pep-func-fit-prod-canadacentral-001` point at sites that no longer exist;
  their connections are Disconnected, so both have `enabled = false`.
- **Recovery Services vault** `monitoringSettings` is null on the live
  vault, but the upstream module always writes it. Both alert flags default
  to `false` so adoption does not switch alerting on; expect the vault to
  be listed as allowed in `scripts/import_gate.sh` for that write.
- `AzureBackupRG_canadacentral_1` is not managed. Azure Backup owns it
  (`managedBy` is `Microsoft.RecoveryServices`), and ARM rejects any PUT that
  drops `managedBy`, which the resource-group wrapper cannot set to that
  non-ID value. The restore-point collections inside it name the group
  directly via `resource_group_name`.

## Adoption

Every resource here already exists in Azure. Each tier has `enable_<type>`
and an import map; imports only run while the tier is enabled, and
validations check every import ID against the key, name, resource group and
`subscription_id`.

Before the first apply:

- Make sure auto-apply is off on the HCP workspace, so every apply is
  confirmed by hand after reading the plan.
- Optionally put a `CanNotDelete` lock on the app resource groups for the
  adoption window. A lock makes Azure refuse any delete, so an unexpected
  replace fails instead of destroying the resource. Do not lock
  `AzureBackupRG_canadacentral_1`; Azure Backup has to delete old restore
  points there.

  ```bash
  az lock create --name adoption-no-delete --lock-type CanNotDelete --resource-group <rg>
  az lock delete --name adoption-no-delete --resource-group <rg>   # afterwards
  ```

Each run, first or staged:

1. Run `.github/workflows/import-verify.yml` for the environment. It only
   plans, then runs `scripts/import_gate.sh`, which wraps
   `scripts/verify_zero_diff.sh`: it fails on anything other than imports and
   tag updates and reports any replace separately.
2. Fix diffs by correcting tfvars, never by changing Azure. Repeat until the
   gate passes. Never accept a replace or delete with `--allow-resource`.
   Accepted addresses go in `scripts/import_gate.sh`.
3. Run `.github/workflows/import-apply.yml` for the environment, with
   `confirm` set to `apply`. Read the check job's summary (gate output and
   plan: only imports and tag updates), then approve the apply job. It
   re-plans, re-runs the gate and refuses to apply if the change set moved
   since the check. Do not use `landing-zone-multi-env.yml` while imports
   are pending; it applies with `-auto-approve` and no gate.
4. Empty the import maps of the tiers that applied.

## Staged adoption

These tiers are complete in `envs/nonprod.tfvars` but switched off, because
adopting them can change or destroy something that is hard to get back. Each
gets its own import-verify and apply, after the first run has applied.

| Stage | Flags | Why it is held back |
|---|---|---|
| 1. Oracle VM | `enable_linux_virtual_machine`, `enable_network_interface` | A wrong plan would rebuild the database VM; adopt it on its own so any replace is obvious |
| 2. Web app | `enable_web_app` | Every apply rewrites the full app settings, so wrong or missing secrets break the live app |
| 3. Virtual network | `enable_virtual_network` | The vWAN hub connection is owned by the connectivity repo |

### Stage 1: Oracle VM

`vm-oracledb-fit-nonprod-canadacentral-001` uses SSH keys, so no password is
needed; the exported public key is in tfvars. Its image,
`RedHat/RHEL/810-gen2`, is grandfathered from
`tf-wrapper-avm-virtual-machine-linux` 0.0.7.

1. Set `enable_linux_virtual_machine = true` and
   `enable_network_interface = true`.
2. Run import-verify. Expected: one VM import and one NIC import. The five
   data disks and their attachments are not managed and must not appear.
3. Any replace on the VM means a ForceNew value (image, size, zone, OS disk)
   disagrees with Azure. Stop, correct tfvars and plan again.
4. Apply and empty `linux_virtual_machine_imports`.

The PAM-POC VM was built on attached disks with no OS profile, which
`azurerm_linux_virtual_machine` cannot represent; it stays unmanaged.

### Stage 2: Web app

The upstream module (`avm-res-web-site`, via `tf-wrapper-avm-web-app`
0.0.5) rewrites the full app settings list and the connection strings on
every apply. Anything not in Terraform is deleted, and any wrong value goes
live.

1. Deal with the plain-value secrets: six settings
   (`APPLICATIONINSIGHTS_CONNECTION_STRING`,
   `DIAGNOSTICS_AZUREBLOBCONTAINERSASURL`, `WEBSITE_HTTPLOGGING_CONTAINER_URL`,
   `ESBPassword`, `ESBUserName`, `ESB_USER`) and the `ConnectionString`
   connection string. Preferred: move each to a Key Vault reference in
   `kvfitcanadacentral` (the app's identity already reads it) and put the
   reference into `app_settings`, like `ESB_PASSWORD`. Otherwise set the real
   values as **sensitive** HCP variables `web_app_secret_app_settings` and
   `web_app_secret_connection_strings`. Never use placeholders. Validation
   blocks the plan until every name has a value.
2. Re-check the non-secret settings against the live app if anything changed
   since the export.
3. Set `enable_web_app = true` and run import-verify. Expected: one site
   import, plus creates for the app settings, connection strings, metadata,
   slot settings and FTP policy. Those are written with
   `azapi_update_resource`, which cannot be imported. Review each one, then
   accept those addresses only with `--allow-resource`.
4. Apply, smoke-test the app, then empty `web_app_imports`.

Hostname bindings, certificates, log settings (they contain SAS URLs) and
backups are not managed. The site's access restrictions include the implicit
"Allow all" rule with default action Allow, so the two specific rules do not
restrict anything; Terraform keeps that as is.

### Stage 3: Virtual network

The VNet module sends a body without subnets or peerings, so the import plan
shows both being removed. The VNet's only peering is the vWAN hub connection
`peering-hub-to-fitnonprod-canadacentral-001`, declared in
`tf-deploy-platform-connectivity`. Upstream tests confirm that subnets and
peerings created outside the module survive the update, but not vWAN hub
connections. This stage is the same as Fabric's and PTA's.

1. Agree a window with the connectivity team, so they can restore the hub
   connection from their repo if it drops.
2. Set `enable_virtual_network = true` and run import-verify. Expected: one
   VNet import and three subnet imports.
3. `defaultOutboundAccess` is not reported for any subnet, so it is set to
   Azure's default (`true`). It is create-time only: a subnet replace in the
   plan means that guess is wrong, so stop and correct it.
4. Apply, check the hub connection, the ASE and the Oracle VM, then empty the
   VNet and subnet import maps.

## Role assignments

`role_assignment.tf` uses one typed map: resource type, parent key, then
assignment key. Every `enable_<type>_role_assignment` is false and
`role_assignments = {}` in both environments. Nothing is inferred from the
export, and existing assignments need their own imports.

## Pipeline

| Workflow | Purpose |
|---|---|
| `import-verify.yml` | Plan and gate. Never applies. Run this first |
| `import-apply.yml` | Gate, approval on the `<env>` environment, re-gate, apply |
| `landing-zone-multi-env.yml` | Deploy pipeline, `workflow_dispatch` only |
| `tflint.yml` | HCL lint on push and PR |
| `trivy.yml` | IaC scan on PR and weekly |

`import-apply.yml` needs required reviewers on the `nonprod` and `prod`
GitHub Environments, or the apply job runs without stopping. Its check job
runs outside any environment, so `TF_API_TOKEN`, `TF_CLOUD_ORGANIZATION`
and `TFC_WORKSPACE_PREFIX` must be set at repo or org level.

`TFC_WORKSPACE_PREFIX` must be set before the first run (`az-fit`, matching Fabric's `az-fabric`).

This repo is now maintained by hand. Do not re-run
`generate-deploy-repos.py` over it.
