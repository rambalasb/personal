# Wrapper gaps: `tf-deploy-app-fit`

Resources in the FIT subscriptions that this repo does not manage. Nonprod
counts are from the Azure resource export of 2026-10-20. Prod follows the
same patterns; prod-specific differences are in the README and the skipped
alerts are listed in `envs/prod.tfvars`. Prod columns below are from the
earlier resource list.

## Staged (nonprod)

Code and tfvars are complete; each is switched off and adopted in its own
run. See "Staged adoption" in the README.

| Resource | Reason |
|---|---|
| `vm-oracledb-fit-nonprod-canadacentral-001` (+ NIC) | Database VM; adopted alone so any replace is obvious |
| `app-fit-dev` | Every apply rewrites the full app settings; secrets must be Key Vault references or real sensitive values first |
| `vnet-fit-nonprod-canadacentral-001` (+ 3 subnets) | vWAN hub connection owned by the connectivity repo |

## Blocked by policy

Public network access is enabled, so `Deny_Public_Access_On_PaaS_Services_v0`
denies any write, adoption included. Read with
`data.azapi_resource.storage_account_existing` until exempted.

| Resource | Environment | Reason |
|---|---|---|
| `stfitnprdcanadacentral1` | nonprod | App storage; default action Deny with a subnet in the FIT prod VNet |
| `stnwfitnpcanadacentral` (flow log storage) | nonprod | Disabling public access would stop flow logs, which rely on the trusted-services bypass |
| `stfitprodcac001` | prod | Has a private endpoint, but public access is still enabled |

## Not managed

| Type | Nonprod | Prod | Reason |
|---|---:|---:|---|
| `microsoft.compute/disks` | 14 | ? | OS disks belong to their VM; data disks and their attachments are not modelled yet; 2 are unattached (`vm-oracledb-...-001OS__1_8531...`, `oracledb-fit-nonprod-datadisk-001`) |
| `microsoft.insights/metricalerts` | 0 | 9 | All 13 nonprod metric alerts are managed |
| `microsoft.insights/scheduledqueryrules` | 2 | 10 | Two have a system-assigned identity, which the monitoring wrapper cannot set; the other 10 are managed |
| `microsoft.compute/virtualmachines/extensions` | 9 | ? | VM wrapper is called with `extensions = {}` |
| `microsoft.compute/snapshots` | 7 | ? | Ad hoc disk snapshots; no wrapper |
| `microsoft.network/networkinterfaces` | 6 | 8 | PE NICs belong to their endpoint; the PAM-POC VM NIC goes with that VM; `nic-vm-oracledb-fit-nonprod-canadacentral-001` has no VM |
| `microsoft.alertsmanagement/actionrules` | 2 | 10 | Two have spaces in their names, which AzureRM rejects; rename them in Azure to manage them |
| `microsoft.web/certificates` | 3 | 1 | No wrapper published |
| `microsoft.web/sites` | 0 | 1 | Prod not exported |
| `microsoft.compute/virtualmachines` | 1 | 1 | `vm-oracledb-fit-nonprod-canadacentral-PAM-POC-001` was built on attached disks with no OS profile, which `azurerm_linux_virtual_machine` cannot represent |
| `microsoft.insights/activitylogalerts` | 1 | 6 | `VM-OS-Patch-Available-FIT-Nonprod-Alert` matches two statuses and a resource type; the wrapper's `status` is a single string |
| `microsoft.insights/actiongroups` | 1 | 2 | App Insights smart detection group; created by Azure |
| `microsoft.network/networkwatchers/flowlogs` | 1 | ? | No wrapper |
| `microsoft.saas/resources` | 1 | 0 | Oracle Database@Azure subscription (`odb-fit-nonprod-canadacentral`); no wrapper |
| `microsoft.network/privatednszones` record sets | 4 | ? | Created by the ASE |
| `microsoft.network/virtualnetworks` peerings | 1 | ? | Hub peering is owned by the connectivity repo |
| `microsoft.insights/datacollectionrules` | 0 | 3 | `tf-wrapper-avm-data-collection-stack` needs stream/destination modelling |
| `microsoft.monitor/accounts` | 0 | 1 | Platform default Azure Monitor workspace |
| `microsoft.insights/datacollectionendpoints` | 0 | 1 | Belongs to the default Azure Monitor workspace |
