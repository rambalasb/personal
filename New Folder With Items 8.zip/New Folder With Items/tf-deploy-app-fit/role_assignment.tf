variable "enable_resource_group_role_assignment" {
  type        = bool
  description = "Enable explicitly configured resource-group RBAC assignments. Parent adoption alone does not enable RBAC."
  default     = false
}

variable "enable_monitoring_role_assignment" {
  type        = bool
  description = "Enable explicitly configured activity-log-alert RBAC assignments."
  default     = false
}

variable "enable_bastion_host_role_assignment" {
  type        = bool
  description = "Enable explicitly configured Bastion RBAC assignments."
  default     = false
}

variable "enable_key_vault_role_assignment" {
  type        = bool
  description = "Enable explicitly configured Key Vault RBAC assignments."
  default     = false
}

variable "enable_network_interface_role_assignment" {
  type        = bool
  description = "Enable explicitly configured standalone-NIC RBAC assignments."
  default     = false
}

variable "enable_network_security_group_role_assignment" {
  type        = bool
  description = "Enable explicitly configured NSG RBAC assignments."
  default     = false
}

variable "enable_restore_point_collection_role_assignment" {
  type        = bool
  description = "Enable explicitly configured restore-point-collection RBAC assignments."
  default     = false
}

variable "enable_network_watcher_role_assignment" {
  type        = bool
  description = "Enable explicitly configured Network Watcher RBAC assignments."
  default     = false
}

variable "enable_private_endpoint_role_assignment" {
  type        = bool
  description = "Enable explicitly configured private-endpoint RBAC assignments."
  default     = false
}

variable "enable_storage_account_role_assignment" {
  type        = bool
  description = "Enable explicitly configured storage-account RBAC assignments."
  default     = false
}

variable "enable_linux_virtual_machine_role_assignment" {
  type        = bool
  description = "Enable explicitly configured Linux VM RBAC assignments."
  default     = false
}

variable "enable_virtual_network_role_assignment" {
  type        = bool
  description = "Enable explicitly configured VNet RBAC assignments."
  default     = false
}

variable "enable_event_grid_system_topic_role_assignment" {
  type        = bool
  description = "Enable explicitly configured Event Grid system-topic RBAC assignments."
  default     = false
}

variable "enable_log_analytics_workspace_role_assignment" {
  type        = bool
  description = "Enable explicitly configured Log Analytics workspace RBAC assignments."
  default     = false
}

variable "enable_user_assigned_identity_role_assignment" {
  type        = bool
  description = "Enable explicitly configured user-assigned identity RBAC assignments."
  default     = false
}

variable "enable_recovery_services_vault_role_assignment" {
  type        = bool
  description = "Enable explicitly configured Recovery Services vault RBAC assignments."
  default     = false
}

variable "enable_public_ssh_key_role_assignment" {
  type        = bool
  description = "Enable explicitly configured SSH public key RBAC assignments."
  default     = false
}

variable "enable_app_service_environment_role_assignment" {
  type        = bool
  description = "Enable explicitly configured App Service Environment RBAC assignments."
  default     = false
}

variable "enable_app_service_plan_role_assignment" {
  type        = bool
  description = "Enable explicitly configured App Service plan RBAC assignments."
  default     = false
}

variable "enable_application_insights_role_assignment" {
  type        = bool
  description = "Enable explicitly configured Application Insights RBAC assignments."
  default     = false
}

variable "enable_private_dns_zone_role_assignment" {
  type        = bool
  description = "Enable explicitly configured private DNS zone RBAC assignments."
  default     = false
}

variable "enable_web_app_role_assignment" {
  type        = bool
  description = "Enable explicitly configured web app RBAC assignments."
  default     = false
}

variable "role_assignments" {
  type = map(map(map(object({
    role_definition_id_or_name             = string
    principal_id                           = string
    condition                              = optional(string)
    condition_version                      = optional(string)
    delegated_managed_identity_resource_id = optional(string)
    principal_type                         = optional(string)
    skip_service_principal_aad_check       = optional(bool)
  }))))
  description = "Explicit RBAC entries keyed by resource type, parent instance key, then assignment key. Companion modules inject the parent scope; no permissions are inferred."
  default     = {}

  validation {
    condition     = alltrue([for resource_type in keys(var.role_assignments) : contains(keys(local.role_assignment_scopes), resource_type)])
    error_message = "Each role_assignments resource type must be supported by the FIT RBAC scope catalog."
  }

  validation {
    condition = alltrue(flatten([
      for resource_type, parents in var.role_assignments : [
        for parent_key in keys(parents) : contains(keys(lookup(local.role_assignment_scopes, resource_type, {})), parent_key)
      ]
    ]))
    error_message = "Each RBAC parent key must identify an existing instance in the matching FIT resource inventory."
  }

  validation {
    condition = alltrue(flatten([
      for resource_type, parents in var.role_assignments : [
        for parent_key in keys(parents) :
        !lookup(local.role_assignment_flags, resource_type, false) || try(local.role_assignment_parent_enabled[resource_type][parent_key], false)
      ]
    ]))
    error_message = "Enabled RBAC companions require enabled parent resources, including per-instance NIC and private-endpoint gates."
  }
}

locals {
  role_assignment_flags = {
    resource_group           = var.enable_resource_group_role_assignment
    activity_log_alert       = var.enable_monitoring_role_assignment
    bastion_host             = var.enable_bastion_host_role_assignment
    key_vault                = var.enable_key_vault_role_assignment
    network_interface        = var.enable_network_interface_role_assignment
    network_security_group   = var.enable_network_security_group_role_assignment
    restore_point_collection = var.enable_restore_point_collection_role_assignment
    network_watcher          = var.enable_network_watcher_role_assignment
    private_endpoint         = var.enable_private_endpoint_role_assignment
    storage_account          = var.enable_storage_account_role_assignment
    linux_virtual_machine    = var.enable_linux_virtual_machine_role_assignment
    virtual_network          = var.enable_virtual_network_role_assignment
    event_grid_system_topic  = var.enable_event_grid_system_topic_role_assignment
    log_analytics_workspace  = var.enable_log_analytics_workspace_role_assignment
    user_assigned_identity   = var.enable_user_assigned_identity_role_assignment
    recovery_services_vault  = var.enable_recovery_services_vault_role_assignment
    public_ssh_key           = var.enable_public_ssh_key_role_assignment
    app_service_environment  = var.enable_app_service_environment_role_assignment
    app_service_plan         = var.enable_app_service_plan_role_assignment
    application_insights     = var.enable_application_insights_role_assignment
    private_dns_zone         = var.enable_private_dns_zone_role_assignment
    web_app                  = var.enable_web_app_role_assignment
  }

  role_assignment_resource_enabled = {
    resource_group           = var.enable_resource_group
    activity_log_alert       = var.enable_monitoring
    bastion_host             = var.enable_bastion_host
    key_vault                = var.enable_key_vault
    network_interface        = var.enable_network_interface
    network_security_group   = var.enable_network_security_group
    restore_point_collection = var.enable_restore_point_collection
    network_watcher          = var.enable_network_watcher
    private_endpoint         = var.enable_private_endpoint
    storage_account          = var.enable_storage_account
    linux_virtual_machine    = var.enable_linux_virtual_machine
    virtual_network          = var.enable_virtual_network
    event_grid_system_topic  = var.enable_event_grid_system_topic
    log_analytics_workspace  = var.enable_log_analytics_workspace
    user_assigned_identity   = var.enable_user_assigned_identity
    recovery_services_vault  = var.enable_recovery_services_vault
    public_ssh_key           = var.enable_public_ssh_key
    app_service_environment  = var.enable_app_service_environment
    app_service_plan         = var.enable_app_service_plan
    application_insights     = var.enable_application_insights
    private_dns_zone         = var.enable_private_dns_zone
    web_app                  = var.enable_web_app
  }

  role_assignment_scopes = {
    resource_group = {
      for parent_key, parent in var.resource_group : parent_key =>
      "/subscriptions/${var.subscription_id}/resourceGroups/${parent.name}"
    }
    activity_log_alert = {
      for parent_key, parent in var.alert.activity_log_alerts : parent_key =>
      "/subscriptions/${var.subscription_id}/resourceGroups/${parent.resource_group_name}/providers/Microsoft.Insights/activityLogAlerts/${parent.name}"
    }
    bastion_host = {
      for parent_key, parent in var.bastion_host : parent_key =>
      "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[parent.resource_group_key].name, "")}/providers/Microsoft.Network/bastionHosts/${parent.name}"
    }
    key_vault = {
      for parent_key, parent in var.key_vault : parent_key =>
      "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[parent.resource_group_key].name, "")}/providers/Microsoft.KeyVault/vaults/${parent.name}"
    }
    network_interface = {
      for parent_key, parent in var.network_interface : parent_key =>
      "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[parent.resource_group_key].name, "")}/providers/Microsoft.Network/networkInterfaces/${parent.name}"
    }
    network_security_group = {
      for parent_key, parent in var.network_security_group : parent_key =>
      "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[parent.resource_group_key].name, "")}/providers/Microsoft.Network/networkSecurityGroups/${parent.name}"
    }
    restore_point_collection = {
      for parent_key, parent in var.restore_point_collection : parent_key =>
      "/subscriptions/${var.subscription_id}/resourceGroups/${parent.resource_group_name}/providers/Microsoft.Compute/restorePointCollections/${parent.name}"
    }
    network_watcher = {
      for parent_key, parent in var.network_watcher : parent_key =>
      "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[parent.resource_group_key].name, "")}/providers/Microsoft.Network/networkWatchers/${parent.name}"
    }
    private_endpoint = {
      for parent_key, parent in var.private_endpoint : parent_key =>
      "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[parent.resource_group_key].name, "")}/providers/Microsoft.Network/privateEndpoints/${parent.name}"
    }
    storage_account = {
      for parent_key, parent in var.storage_account : parent_key =>
      "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[parent.resource_group_key].name, "")}/providers/Microsoft.Storage/storageAccounts/${parent.name}"
    }
    linux_virtual_machine = {
      for parent_key, parent in var.linux_virtual_machine : parent_key =>
      "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[parent.resource_group_key].name, "")}/providers/Microsoft.Compute/virtualMachines/${parent.name}"
    }
    virtual_network = {
      for parent_key, parent in var.virtual_network : parent_key =>
      "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[parent.resource_group_key].name, "")}/providers/Microsoft.Network/virtualNetworks/${parent.name}"
    }
    event_grid_system_topic = {
      for parent_key, parent in var.event_grid_system_topic : parent_key =>
      "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[parent.resource_group_key].name, "")}/providers/Microsoft.EventGrid/systemTopics/${parent.name}"
    }
    log_analytics_workspace = {
      for parent_key, parent in var.log_analytics_workspace : parent_key =>
      "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[parent.resource_group_key].name, "")}/providers/Microsoft.OperationalInsights/workspaces/${parent.name}"
    }
    user_assigned_identity = {
      for parent_key, parent in var.user_assigned_identity : parent_key =>
      "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[parent.resource_group_key].name, "")}/providers/Microsoft.ManagedIdentity/userAssignedIdentities/${parent.name}"
    }
    recovery_services_vault = {
      for parent_key, parent in var.recovery_services_vault : parent_key =>
      "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[parent.resource_group_key].name, "")}/providers/Microsoft.RecoveryServices/vaults/${parent.name}"
    }
    public_ssh_key = {
      for parent_key, parent in var.public_ssh_key : parent_key =>
      "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[parent.resource_group_key].name, "")}/providers/Microsoft.Compute/sshPublicKeys/${parent.name}"
    }
    app_service_environment = {
      for parent_key, parent in var.app_service_environment : parent_key =>
      "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[parent.resource_group_key].name, "")}/providers/Microsoft.Web/hostingEnvironments/${parent.name}"
    }
    app_service_plan = {
      for parent_key, parent in var.app_service_plan : parent_key =>
      "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[parent.resource_group_key].name, "")}/providers/Microsoft.Web/serverFarms/${parent.name}"
    }
    application_insights = {
      for parent_key, parent in var.application_insights : parent_key =>
      "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[parent.resource_group_key].name, "")}/providers/Microsoft.Insights/components/${parent.name}"
    }
    private_dns_zone = {
      for parent_key, parent in var.private_dns_zone : parent_key =>
      "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[parent.resource_group_key].name, "")}/providers/Microsoft.Network/privateDnsZones/${parent.name}"
    }
    web_app = {
      for parent_key, parent in var.web_app : parent_key =>
      "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[parent.resource_group_key].name, "")}/providers/Microsoft.Web/sites/${parent.name}"
    }
  }

  role_assignment_parent_enabled = {
    for resource_type, parents in local.role_assignment_scopes : resource_type => {
      for parent_key, scope in parents : parent_key => local.role_assignment_resource_enabled[resource_type] && (
        resource_type == "network_interface" ? try(var.network_interface[parent_key].enabled, false) :
        resource_type == "private_endpoint" ? try(var.private_endpoint[parent_key].enabled, false) : true
      )
    }
  }

  role_assignment_instances = merge({}, [
    for resource_type, parents in var.role_assignments : {
      for parent_key, assignments in parents : "${resource_type}/${parent_key}" => {
        scope       = try(local.role_assignment_scopes[resource_type][parent_key], null)
        assignments = assignments
      } if lookup(local.role_assignment_flags, resource_type, false) && try(local.role_assignment_parent_enabled[resource_type][parent_key], false) && length(assignments) > 0
    }
  ]...)
}

module "role_assignment" {
  for_each = local.role_assignment_instances

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-role-assignment/azurerm"
  version = "0.3.6"

  role_assignments_azure_resource_manager = {
    for assignment_key, assignment in each.value.assignments : assignment_key => merge(assignment, {
      scope = each.value.scope
    })
  }

  depends_on = [
    module.resource_group,
    module.monitoring,
    module.bastion_host,
    module.key_vault,
    module.network_security_group,
    module.private_endpoint,
    module.virtual_network,
    azurerm_virtual_machine_restore_point_collection.this,
    azurerm_network_watcher.this,
    azurerm_storage_account.this,
    module.linux_virtual_machine,
    azurerm_eventgrid_system_topic.this,
    module.log_analytics_workspace,
    module.user_assigned_identity,
    module.recovery_services_vault,
    azurerm_ssh_public_key.this,
    module.app_service_environment,
    module.app_service_plan,
    module.application_insights,
    module.private_dns_zone,
    module.web_app,
  ]
}