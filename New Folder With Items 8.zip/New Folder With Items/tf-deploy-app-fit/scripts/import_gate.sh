#!/usr/bin/env bash
# The import zero-diff gate, shared by import-verify.yml and import-apply.yml so
# the plan that gets applied passes exactly the check that was reviewed.
#
# Usage: import_gate.sh <env> <plan.json>
set -eo pipefail
ENV_NAME="${1:?usage: import_gate.sh <env> <plan.json>}"
PLAN="${2:?usage: import_gate.sh <env> <plan.json>}"
HERE="$(cd "$(dirname "$0")" && pwd)"

allow=()
if [ "$ENV_NAME" = "nonprod" ]; then
  # Import leaves local_authentication_enabled null; live disableLocalAuth
  # is null (local auth on), so writing true changes nothing.
  allow+=(--allow-resource "module.log_analytics_workspace[\"default_ccan\"].module.log_analytics_workspace.azurerm_log_analytics_workspace.this")
  # AVM always writes monitoringSettings (null live) and drops fields the
  # vault already holds at their defaults; tfvars keeps alerting off.
  allow+=(--allow-resource "module.recovery_services_vault[\"app\"].module.recovery_services_vault.azapi_resource.this")
  # AVM serverfarm sends kind "windows" for os_type Windows; Azure reports
  # "app" for the same Windows plan.
  allow+=(--allow-resource "module.app_service_plan[\"app\"].module.app_service_plan.azapi_resource.this")
  # Import reads unset samplingPercentage as 0; unset means 100% (no sampling).
  allow+=(--allow-resource "module.application_insights[\"func\"].module.application_insights.azurerm_application_insights.this")
  # The upstream module sends no body; a private DNS zone has no settable
  # properties, so only the imported etag drops out.
  allow+=(--allow-resource "module.private_dns_zone[\"ase\"].module.private_dns_zone.azapi_resource.private_dns_zone")
  # AVM always patches the ASE networking configuration; the values match
  # the export (PE connections on, FTP off, remote debug on).
  allow+=(--allow-resource "module.app_service_environment[\"app\"].module.app_service_environment.module.networking_configuration.azapi_update_resource.networking")
  # app-fit-nonprod-canadacentral-001 no longer exists; these alerts now
  # scope app-fit-dev. All are disabled.
  for key in app_fit_connections_warning app_fit_http_404_informational \
             app_health_alert_canadacentral app_high_cpu_alert_canadacentral \
             app_high_response_time_alert_canadcentral app_http_alert_canadacentral; do
    allow+=(--allow-resource "module.monitoring[0].azurerm_monitor_metric_alert.this[\"$key\"]")
  done
elif [ "$ENV_NAME" = "prod" ]; then
  # AVM serverfarm sends kind "windows" for os_type Windows; Azure reports
  # "app" for the same Windows plan.
  allow+=(--allow-resource "module.app_service_plan[\"app\"].module.app_service_plan.azapi_resource.this")
  # Match the nonprod vault defaults allowance. This accepts the API-version
  # change and the complete update, including monitoring and security fields.
  allow+=(--allow-resource "module.recovery_services_vault[\"app\"].module.recovery_services_vault.azapi_resource.this")
  # Import leaves local_authentication_enabled null; live disableLocalAuth
  # is null (local auth on), so writing true changes nothing.
  allow+=(--allow-resource "module.log_analytics_workspace[\"defaultworkspace\"].module.log_analytics_workspace.azurerm_log_analytics_workspace.this")
  # The upstream module sends no body; a private DNS zone has no settable
  # properties, so only the imported etag drops out.
  for key in ase_appserviceenvironment_net privatelink_ase_appserviceenvironment_net \
             privatelink_blob_core_windows_net; do
    allow+=(--allow-resource "module.private_dns_zone[\"$key\"].module.private_dns_zone.azapi_resource.private_dns_zone")
  done
  # Accept the ASE networking patch: PE connections on, FTP and remote debug off.
  allow+=(--allow-resource "module.app_service_environment[\"app\"].module.app_service_environment.module.networking_configuration.azapi_update_resource.networking")
fi
bash "$HERE/verify_zero_diff.sh" "$PLAN" "${allow[@]}" \
  --ignore-attr response_export_values \
  --ignore-attr retry \
  --ignore-attr timeouts \
  --ignore-attr ignore_null_property \
  --ignore-attr ignore_casing \
  --ignore-attr ignore_missing_property \
  --ignore-attr schema_validation_enabled \
  --subset-attr body \
  --ignore-type time_sleep \
  --ignore-type random_uuid \
  --ignore-type modtm_telemetry \
  --ignore-type terraform_data
