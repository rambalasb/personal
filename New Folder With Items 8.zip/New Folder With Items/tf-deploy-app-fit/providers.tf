terraform {
  required_version = ">= 1.9, < 2.0"

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 4.67.0, < 5.0.0"
    }
    azapi = {
      source  = "Azure/azapi"
      version = ">= 2.0, < 3.0"
    }
    azuread = {
      source = "hashicorp/azuread"
    }
  }

  # CI owns the backend and generates ci_backend.tf. Leave this commented.
  # backend "azurerm" {
  #   resource_group_name  = ""
  #   storage_account_name = ""
  #   container_name       = ""
  #   key                  = "APP.tfstate"
  # }
}

provider "azurerm" {
  subscription_id = var.subscription_id
  features {}
  # stnwfitnpcanadacentral disables shared keys, so storage data-plane reads need AAD.
  storage_use_azuread = true
}

provider "azapi" {
  subscription_id = var.subscription_id
}

provider "azuread" {}

# Connectivity subscription: the shared private DNS zones this app's VNet links
# and records live in (private_dns_zone_links.tf, custom-recordset.tf).
provider "azurerm" {
  alias           = "dns"
  subscription_id = var.hub_dns_subscription_id
  features {}
}
