variable "subscription_id" {
  type        = string
  description = "Azure subscription this environment adopts resources into."

  validation {
    condition     = can(regex("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$", var.subscription_id))
    error_message = "subscription_id must be an Azure subscription UUID."
  }
}

variable "enable_resource_group" {
  type        = bool
  description = "Whether Terraform manages and imports the existing resource groups."
  default     = false
}

variable "resource_group" {
  type = map(object({
    name     = string
    location = string
    lock = optional(object({
      kind = string
      name = optional(string)
    }))
    managed_by = optional(string)
    tags       = optional(map(string), {})
  }))
  description = "Existing resource groups to adopt, keyed by stable instance roles."
  default     = {}
}

variable "import_resource_group" {
  type        = map(string)
  description = "Existing resource group IDs, keyed by the matching resource_group instance."
  default     = {}

  validation {
    condition = alltrue([
      for group_key, resource_id in var.import_resource_group :
      resource_id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[group_key].name, "")}"
    ])
    error_message = "Each import_resource_group entry must match its resource_group key, name and subscription_id."
  }
}

variable "enable_monitoring" {
  type        = bool
  description = "Whether Terraform manages and imports the existing monitoring alerts."
  default     = false
}

variable "alert" {
  type = object({
    resource_group_key         = string
    root_management_group_name = optional(string)
    tags                       = optional(map(string), {})
    activity_log_alerts = optional(map(object({
      name                = string
      resource_group_name = string
      scopes              = list(string)
      location            = optional(string, "global")
      description         = optional(string)
      enabled             = optional(bool, true)
      criteria = object({
        category                = string
        operation_name          = optional(string)
        resource_provider       = optional(string)
        resource_type           = optional(string)
        resource_group          = optional(string)
        resource_id             = optional(string)
        caller                  = optional(string)
        level                   = optional(string)
        status                  = optional(string)
        sub_status              = optional(string)
        recommendation_category = optional(string)
        recommendation_impact   = optional(string)
        recommendation_type     = optional(string)
        service_health = optional(object({
          events    = optional(list(string))
          locations = optional(list(string))
          services  = optional(list(string))
        }))
        resource_health = optional(object({
          current  = optional(list(string))
          previous = optional(list(string))
          reason   = optional(list(string))
        }))
      })
      action_group_keys  = optional(list(string), [])
      action_group_ids   = optional(list(string), [])
      webhook_properties = optional(map(string), {})
      tags               = optional(map(string), {})
    })), {})
    metric_alerts = optional(map(object({
      name                     = string
      resource_group_name      = string
      scopes                   = list(string)
      description              = optional(string)
      enabled                  = optional(bool, true)
      auto_mitigate            = optional(bool, true)
      frequency                = optional(string, "PT1M")
      window_size              = optional(string, "PT5M")
      severity                 = optional(number, 3)
      target_resource_type     = optional(string)
      target_resource_location = optional(string)
      criteria = optional(list(object({
        metric_namespace       = string
        metric_name            = string
        aggregation            = string
        operator               = string
        threshold              = number
        skip_metric_validation = optional(bool, false)
        dimensions = optional(list(object({
          name     = string
          operator = string
          values   = list(string)
        })), [])
      })), [])
      dynamic_criteria = optional(object({
        metric_namespace         = string
        metric_name              = string
        aggregation              = string
        operator                 = string
        alert_sensitivity        = string
        evaluation_total_count   = optional(number)
        evaluation_failure_count = optional(number)
        ignore_data_before       = optional(string)
        skip_metric_validation   = optional(bool, false)
        dimensions = optional(list(object({
          name     = string
          operator = string
          values   = list(string)
        })), [])
      }))
      action_group_ids   = optional(list(string), [])
      webhook_properties = optional(map(string), {})
      tags               = optional(map(string), {})
    })), {})
    log_search_alerts = optional(map(object({
      name                              = string
      resource_group_name               = string
      location                          = string
      scopes                            = list(string)
      severity                          = optional(number, 3)
      evaluation_frequency              = optional(string, "PT5M")
      window_duration                   = optional(string, "PT5M")
      description                       = optional(string)
      display_name                      = optional(string)
      enabled                           = optional(bool, true)
      auto_mitigation_enabled           = optional(bool, false)
      skip_query_validation             = optional(bool, false)
      mute_actions_after_alert_duration = optional(string)
      query_time_range_override         = optional(string)
      target_resource_types             = optional(list(string))
      criteria = list(object({
        query                   = string
        time_aggregation_method = string
        threshold               = number
        operator                = string
        resource_id_column      = optional(string)
        metric_measure_column   = optional(string)
        dimensions = optional(list(object({
          name     = string
          operator = string
          values   = list(string)
        })), [])
        failing_periods = optional(object({
          minimum_failing_periods_to_trigger_alert = number
          number_of_evaluation_periods             = number
        }))
      }))
      action_group_ids  = optional(list(string), [])
      custom_properties = optional(map(string), {})
      email_subject     = optional(string)
      tags              = optional(map(string), {})
    })), {})
    alert_processing_rules = optional(map(object({
      name                = string
      resource_group_name = string
      scopes              = list(string)
      type                = optional(string, "suppression")
      description         = optional(string)
      enabled             = optional(bool, true)
      action_group_ids    = optional(list(string), [])
      conditions = optional(map(object({
        operator = string
        values   = list(string)
      })), {})
      schedule = optional(object({
        effective_from  = optional(string)
        effective_until = optional(string)
        time_zone       = optional(string)
        recurrence = optional(object({
          daily = optional(list(object({
            start_time = string
            end_time   = string
          })), [])
          weekly = optional(list(object({
            days_of_week = list(string)
            start_time   = optional(string)
            end_time     = optional(string)
          })), [])
          monthly = optional(list(object({
            days_of_month = list(number)
            start_time    = optional(string)
            end_time      = optional(string)
          })), [])
        }))
      }))
      tags = optional(map(string), {})
    })), {})
  })
  description = "Existing alerts passed to the shared monitoring wrapper: activity log, metric, log search and alert processing rules."
  default = {
    resource_group_key = "alerts"
  }

  validation {
    condition     = !var.enable_monitoring || (var.enable_resource_group && contains(keys(var.resource_group), var.alert.resource_group_key))
    error_message = "Monitoring requires enabled resource groups and a valid alert.resource_group_key."
  }
}

variable "activity_log_alert_imports" {
  type        = map(string)
  description = "Existing activity log alert IDs, keyed by the matching alert.activity_log_alerts instance."
  default     = {}

  validation {
    condition = alltrue([
      for alert_key, resource_id in var.activity_log_alert_imports :
      resource_id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.alert.activity_log_alerts[alert_key].resource_group_name, "")}/providers/Microsoft.Insights/activityLogAlerts/${try(var.alert.activity_log_alerts[alert_key].name, "")}"
    ])
    error_message = "Each activity_log_alert_imports entry must match its alert key, name, resource group and subscription_id."
  }
}

variable "metric_alert_imports" {
  type        = map(string)
  description = "Existing metric alert IDs, keyed by the matching alert.metric_alerts instance."
  default     = {}

  validation {
    condition = alltrue([
      for alert_key, resource_id in var.metric_alert_imports :
      lower(resource_id) == lower("/subscriptions/${var.subscription_id}/resourceGroups/${try(var.alert.metric_alerts[alert_key].resource_group_name, "")}/providers/Microsoft.Insights/metricAlerts/${try(var.alert.metric_alerts[alert_key].name, "")}")
    ])
    error_message = "Each metric_alert_imports entry must match its alert key, name, resource group and subscription_id."
  }
}

variable "log_search_alert_imports" {
  type        = map(string)
  description = "Existing scheduled query rule IDs, keyed by the matching alert.log_search_alerts instance."
  default     = {}

  validation {
    condition = alltrue([
      for alert_key, resource_id in var.log_search_alert_imports :
      lower(resource_id) == lower("/subscriptions/${var.subscription_id}/resourceGroups/${try(var.alert.log_search_alerts[alert_key].resource_group_name, "")}/providers/Microsoft.Insights/scheduledQueryRules/${try(var.alert.log_search_alerts[alert_key].name, "")}")
    ])
    error_message = "Each log_search_alert_imports entry must match its alert key, name, resource group and subscription_id."
  }
}

variable "alert_processing_rule_imports" {
  type        = map(string)
  description = "Existing alert processing rule IDs, keyed by the matching alert.alert_processing_rules instance."
  default     = {}

  validation {
    condition = alltrue([
      for rule_key, resource_id in var.alert_processing_rule_imports :
      lower(resource_id) == lower("/subscriptions/${var.subscription_id}/resourceGroups/${try(var.alert.alert_processing_rules[rule_key].resource_group_name, "")}/providers/Microsoft.AlertsManagement/actionRules/${try(var.alert.alert_processing_rules[rule_key].name, "")}")
    ])
    error_message = "Each alert_processing_rule_imports entry must match its rule key, name, resource group and subscription_id."
  }
}

variable "enable_bastion_host" {
  type        = bool
  description = "Whether Terraform manages and imports the existing Developer Bastion Hosts."
  default     = false
}

variable "bastion_host" {
  type = map(object({
    name               = string
    resource_group_key = string
    location           = optional(string)
    sku                = optional(string, "Developer")
    scale_units        = optional(number, 2)
    virtual_network_id = optional(string)
    ip_configuration = optional(object({
      name                 = optional(string)
      subnet_id            = string
      public_ip_address_id = string
    }))
    zones                     = optional(set(string), [])
    copy_paste_enabled        = optional(bool, true)
    file_copy_enabled         = optional(bool, false)
    ip_connect_enabled        = optional(bool, false)
    kerberos_enabled          = optional(bool, false)
    shareable_link_enabled    = optional(bool, false)
    tunneling_enabled         = optional(bool, false)
    session_recording_enabled = optional(bool, false)
    private_only_enabled      = optional(bool, false)
    tags                      = optional(map(string), {})
  }))
  description = "Existing Bastion Hosts. Developer attaches to virtual_network_id; other SKUs need ip_configuration with the existing public IP."
  default     = {}

  validation {
    condition = alltrue([
      for bastion in values(var.bastion_host) :
      contains(keys(var.resource_group), bastion.resource_group_key) && (!var.enable_bastion_host || var.enable_resource_group)
    ])
    error_message = "Each Bastion Host must reference a managed resource group, enabled when Bastion adoption is enabled."
  }

  validation {
    condition = alltrue([
      for bastion in values(var.bastion_host) :
      bastion.sku == "Developer" ? (bastion.virtual_network_id != null && length(bastion.zones) == 0) : bastion.ip_configuration != null
    ])
    error_message = "Developer Bastions need virtual_network_id and no zones; other SKUs need ip_configuration."
  }
}

variable "bastion_host_imports" {
  type        = map(string)
  description = "Existing Developer Bastion IDs, keyed by the matching bastion_host instance."
  default     = {}

  validation {
    condition = alltrue([
      for bastion_key, resource_id in var.bastion_host_imports :
      resource_id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[var.bastion_host[bastion_key].resource_group_key].name, "")}/providers/Microsoft.Network/bastionHosts/${try(var.bastion_host[bastion_key].name, "")}"
    ])
    error_message = "Each bastion_host_imports entry must match its Bastion key, name, resource group and subscription_id."
  }
}

variable "enable_key_vault" {
  type        = bool
  description = "Whether Terraform manages and imports the existing Key Vaults."
  default     = false
}

variable "key_vault" {
  type = map(object({
    name                            = string
    resource_group_key              = string
    location                        = optional(string)
    tenant_id                       = string
    sku_name                        = optional(string, "premium")
    enabled_for_deployment          = optional(bool, false)
    enabled_for_disk_encryption     = optional(bool, false)
    enabled_for_template_deployment = optional(bool, false)
    legacy_access_policies_enabled  = optional(bool, false)
    public_network_access_enabled   = optional(bool, true)
    purge_protection_enabled        = optional(bool, true)
    soft_delete_retention_days      = optional(number, 90)
    network_acls = optional(object({
      bypass                     = optional(string, "None")
      default_action             = optional(string, "Deny")
      ip_rules                   = optional(list(string), [])
      virtual_network_subnet_ids = optional(set(string), [])
    }), {})
    tags = optional(map(string), {})
  }))
  description = "Existing vault-level configuration to adopt without keys, secrets or child resources."
  default     = {}

  validation {
    condition = alltrue([
      for vault in values(var.key_vault) :
      contains(keys(var.resource_group), vault.resource_group_key) && (!var.enable_key_vault || var.enable_resource_group)
    ])
    error_message = "Each Key Vault must reference a managed resource group, enabled when vault adoption is enabled."
  }

  validation {
    condition     = alltrue([for vault in values(var.key_vault) : !vault.legacy_access_policies_enabled])
    error_message = "This vault-only adoption configuration requires RBAC; legacy policy adoption is not configured."
  }

  validation {
    condition     = alltrue([for vault in values(var.key_vault) : vault.soft_delete_retention_days >= 7 && vault.soft_delete_retention_days <= 90])
    error_message = "Key Vault soft-delete retention must be between 7 and 90 days."
  }
}

variable "key_vault_imports" {
  type        = map(string)
  description = "Existing Key Vault IDs, keyed by the matching key_vault instance."
  default     = {}

  validation {
    condition = alltrue([
      for vault_key, resource_id in var.key_vault_imports :
      resource_id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[var.key_vault[vault_key].resource_group_key].name, "")}/providers/Microsoft.KeyVault/vaults/${try(var.key_vault[vault_key].name, "")}"
    ])
    error_message = "Each key_vault_imports entry must match its vault key, name, resource group and subscription_id."
  }
}

variable "enable_network_interface" {
  type        = bool
  description = "Enable NIC NSG-association imports; VM NICs themselves import through the VM wrapper."
  default     = false
}

variable "network_interface" {
  type = map(object({
    name               = string
    resource_group_key = string
    location           = optional(string)
    enabled            = optional(bool, false)
    ip_configurations = map(object({
      name                          = string
      subnet_id                     = string
      private_ip_address_version    = optional(string, "IPv4")
      private_ip_address_allocation = optional(string, "Dynamic")
      private_ip_address            = optional(string)
      primary                       = optional(bool)
      public_ip_address_id          = optional(string)
    }))
    accelerated_networking_enabled = optional(bool, false)
    ip_forwarding_enabled          = optional(bool, false)
    tags                           = optional(map(string), {})
  }))
  description = "NIC inventory feeding the VM wrapper. Keep private-endpoint NICs individually disabled."
  default     = {}

  validation {
    condition = alltrue([
      for nic in values(var.network_interface) :
      contains(keys(var.resource_group), nic.resource_group_key) && (!var.enable_network_interface || !nic.enabled || var.enable_resource_group)
    ])
    error_message = "Each NIC must reference a managed resource group, enabled when that NIC is managed."
  }
}

variable "network_interface_nsg_associations" {
  type        = map(string)
  description = "Existing NSG IDs keyed by NIC; association imports use the NIC resource ID and share its enable flags."
  default     = {}

  validation {
    condition     = alltrue([for nic_key in keys(var.network_interface_nsg_associations) : contains(keys(var.network_interface), nic_key)])
    error_message = "Each NSG association must identify an existing network_interface key."
  }
}

variable "enable_network_security_group" {
  type        = bool
  description = "Whether Terraform manages and imports the existing NSGs and their custom rules."
  default     = false
}

variable "network_security_group" {
  type = map(object({
    name               = string
    resource_group_key = string
    location           = optional(string)
    security_rules = optional(map(object({
      name                         = string
      access                       = string
      direction                    = string
      priority                     = number
      protocol                     = string
      description                  = optional(string)
      source_port_range            = optional(string)
      source_port_ranges           = optional(set(string))
      destination_port_range       = optional(string)
      destination_port_ranges      = optional(set(string))
      source_address_prefix        = optional(string)
      source_address_prefixes      = optional(set(string))
      destination_address_prefix   = optional(string)
      destination_address_prefixes = optional(set(string))
    })), {})
    tags = optional(map(string), {})
  }))
  description = "Existing NSGs and custom rules to adopt, without extra tags or RBAC."
  default     = {}

  validation {
    condition = alltrue([
      for nsg in values(var.network_security_group) :
      contains(keys(var.resource_group), nsg.resource_group_key) && (!var.enable_network_security_group || var.enable_resource_group)
    ])
    error_message = "Each NSG must reference a managed resource group, enabled when NSG adoption is enabled."
  }
}

variable "import_network_security_group" {
  type        = map(string)
  description = "Existing NSG IDs, keyed by network_security_group."
  default     = {}

  validation {
    condition = alltrue([
      for nsg_key, resource_id in var.import_network_security_group :
      resource_id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[var.network_security_group[nsg_key].resource_group_key].name, "")}/providers/Microsoft.Network/networkSecurityGroups/${try(var.network_security_group[nsg_key].name, "")}"
    ])
    error_message = "Each import_network_security_group entry must match its NSG key, name, resource group and subscription_id."
  }
}

variable "network_security_rule_imports" {
  type = map(object({
    nsg_key  = string
    rule_key = string
    id       = string
  }))
  description = "Existing custom rule IDs and their wrapper map keys; verify the pinned nested rule resource address."
  default     = {}

  validation {
    condition = alltrue([
      for rule in values(var.network_security_rule_imports) :
      rule.id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[var.network_security_group[rule.nsg_key].resource_group_key].name, "")}/providers/Microsoft.Network/networkSecurityGroups/${try(var.network_security_group[rule.nsg_key].name, "")}/securityRules/${try(var.network_security_group[rule.nsg_key].security_rules[rule.rule_key].name, "")}"
    ])
    error_message = "Each rule import must match its NSG key, rule key, exported rule name, resource group and subscription_id."
  }
}

variable "enable_restore_point_collection" {
  type        = bool
  description = "Whether Terraform manages and imports existing VM restore-point collections directly with AzureRM."
  default     = false
}

variable "restore_point_collection" {
  type = map(object({
    name                      = string
    resource_group_name       = string
    location                  = string
    source_virtual_machine_id = string
    tags                      = map(string)
  }))
  description = "Existing restore-point collection containers. Source VMs are references only; individual restore points and backup policies are not managed here. The resource group is named directly because Azure Backup owns it and Terraform does not manage it."
  default     = {}

  validation {
    condition = alltrue([
      for collection in values(var.restore_point_collection) :
      can(regex("^/subscriptions/${var.subscription_id}/resourceGroups/[^/]+/providers/Microsoft.Compute/virtualMachines/[^/]+$", collection.source_virtual_machine_id))
    ])
    error_message = "Each source_virtual_machine_id must identify a VM in the configured subscription."
  }
}

variable "restore_point_collection_imports" {
  type        = map(string)
  description = "Existing bare restore-point collection ARM IDs, keyed by restore_point_collection key."
  default     = {}

  validation {
    condition = alltrue([
      for key, id in var.restore_point_collection_imports : try(
        id == "/subscriptions/${var.subscription_id}/resourceGroups/${var.restore_point_collection[key].resource_group_name}/providers/Microsoft.Compute/restorePointCollections/${var.restore_point_collection[key].name}",
        false
      )
    ])
    error_message = "Each restore-point collection import key and ID must match its name, resource group, and subscription."
  }

  validation {
    condition     = !var.enable_restore_point_collection || toset(keys(var.restore_point_collection_imports)) == toset(keys(var.restore_point_collection))
    error_message = "Enabled restore-point collection adoption requires exactly one import ID for every configured collection."
  }
}

variable "enable_network_watcher" {
  type        = bool
  description = "Whether Terraform manages and imports the existing Network Watchers."
  default     = false
}

variable "network_watcher" {
  type = map(object({
    name               = string
    resource_group_key = string
    location           = optional(string)
    tags               = optional(map(string), {})
  }))
  description = "Existing Network Watchers to adopt directly with AzureRM."
  default     = {}

  validation {
    condition = alltrue([
      for watcher in values(var.network_watcher) :
      contains(keys(var.resource_group), watcher.resource_group_key) && (!var.enable_network_watcher || var.enable_resource_group)
    ])
    error_message = "Each Network Watcher must reference a managed resource group, enabled when watcher adoption is enabled."
  }
}

variable "network_watcher_imports" {
  type        = map(string)
  description = "Existing Network Watcher IDs, keyed by the matching network_watcher instance."
  default     = {}

  validation {
    condition = alltrue([
      for watcher_key, resource_id in var.network_watcher_imports :
      resource_id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[var.network_watcher[watcher_key].resource_group_key].name, "")}/providers/Microsoft.Network/networkWatchers/${try(var.network_watcher[watcher_key].name, "")}"
    ])
    error_message = "Each network_watcher_imports entry must match its watcher key, name, resource group and subscription_id."
  }
}

variable "enable_private_endpoint" {
  type        = bool
  description = "Whether Terraform manages and imports the existing private endpoints."
  default     = false
}

variable "private_endpoint" {
  type = map(object({
    enabled                         = optional(bool, true)
    name                            = string
    resource_group_key              = string
    location                        = optional(string)
    subnet_resource_id              = string
    private_connection_resource_id  = string
    private_service_connection_name = optional(string)
    subresource_names               = optional(list(string))
    network_interface_name          = optional(string)
    private_dns_zone_group_name     = optional(string)
    private_dns_zone_resource_ids   = optional(list(string), [])
    ip_configurations = optional(map(object({
      name               = string
      private_ip_address = string
      subresource_name   = string
      member_name        = optional(string, "default")
    })), {})
    tags = optional(map(string), {})
  }))
  description = "Existing private endpoints to adopt, owning their generated NICs."
  default     = {}

  validation {
    condition = alltrue([
      for endpoint in values(var.private_endpoint) :
      contains(keys(var.resource_group), endpoint.resource_group_key) && (!var.enable_private_endpoint || !endpoint.enabled || var.enable_resource_group)
    ])
    error_message = "Each endpoint must reference a managed resource group, enabled when that endpoint is managed."
  }
}

variable "private_endpoint_imports" {
  type        = map(string)
  description = "Existing endpoint IDs, keyed by private_endpoint and filtered by global/per-entry enable flags."
  default     = {}

  validation {
    condition = alltrue([
      for endpoint_key, resource_id in var.private_endpoint_imports :
      resource_id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[var.private_endpoint[endpoint_key].resource_group_key].name, "")}/providers/Microsoft.Network/privateEndpoints/${try(var.private_endpoint[endpoint_key].name, "")}"
    ])
    error_message = "Each private_endpoint_imports entry must match its endpoint key, name, resource group and subscription_id."
  }
}

variable "enable_storage_account" {
  type        = bool
  description = "Whether Terraform manages and imports the existing storage accounts."
  default     = false
}

variable "storage_account" {
  type = map(object({
    name                              = string
    resource_group_key                = string
    location                          = optional(string)
    account_kind                      = optional(string, "StorageV2")
    account_tier                      = string
    account_replication_type          = string
    access_tier                       = string
    allow_nested_items_to_be_public   = bool
    cross_tenant_replication_enabled  = optional(bool, false)
    default_to_oauth_authentication   = bool
    https_traffic_only_enabled        = optional(bool, true)
    infrastructure_encryption_enabled = bool
    is_hns_enabled                    = optional(bool, false)
    large_file_share_enabled          = optional(bool)
    min_tls_version                   = optional(string, "TLS1_2")
    public_network_access_enabled     = bool
    sftp_enabled                      = optional(bool, false)
    shared_access_key_enabled         = optional(bool, true)
    blob_properties = optional(object({
      container_delete_retention_policy = object({ days = optional(number) })
      delete_retention_policy           = object({ days = optional(number) })
    }))
    network_rules = object({
      bypass                     = set(string)
      default_action             = string
      ip_rules                   = optional(set(string), [])
      virtual_network_subnet_ids = optional(set(string), [])
      private_link_access = optional(list(object({
        endpoint_resource_id = string
        endpoint_tenant_id   = optional(string)
      })), [])
    })
    tags = optional(map(string), {})
  }))
  description = "Existing storage accounts to adopt directly with AzureRM. infrastructure_encryption_enabled forces replacement, so it must match the export."
  default     = {}

  validation {
    condition = alltrue([
      for account in values(var.storage_account) :
      contains(keys(var.resource_group), account.resource_group_key) && (!var.enable_storage_account || var.enable_resource_group)
    ])
    error_message = "Each storage account must reference a managed resource group, enabled when account adoption is enabled."
  }
}

variable "storage_account_existing" {
  type = map(object({
    name               = string
    resource_group_key = string
  }))
  description = "Storage accounts read with a data source instead of managed, because policy denies writes to them."
  default     = {}

  validation {
    condition     = alltrue([for account in values(var.storage_account_existing) : contains(keys(var.resource_group), account.resource_group_key)])
    error_message = "Each existing storage account must reference a resource_group key."
  }
}

variable "storage_account_imports" {
  type        = map(string)
  description = "Existing storage account IDs, keyed by the matching storage_account instance."
  default     = {}

  validation {
    condition = alltrue([
      for account_key, resource_id in var.storage_account_imports :
      resource_id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[var.storage_account[account_key].resource_group_key].name, "")}/providers/Microsoft.Storage/storageAccounts/${try(var.storage_account[account_key].name, "")}"
    ])
    error_message = "Each storage_account_imports entry must match its account key, name, resource group and subscription_id."
  }
}

variable "enable_virtual_network" {
  type        = bool
  description = "Whether Terraform manages and imports the existing virtual networks and their subnets."
  default     = false
}

variable "virtual_network" {
  type = map(object({
    name               = string
    resource_group_key = string
    location           = optional(string)
    address_space      = set(string)
    dns_servers = optional(object({
      dns_servers = list(string)
    }))
    ddos_protection_plan = optional(object({
      id     = string
      enable = bool
    }))
    enable_vm_protection    = optional(bool, false)
    flow_timeout_in_minutes = optional(number)
    encryption = optional(object({
      enabled     = bool
      enforcement = string
    }))
    subnets = optional(map(object({
      name                                          = string
      address_prefixes                              = list(string)
      private_endpoint_network_policies             = optional(string, "Enabled")
      private_link_service_network_policies_enabled = optional(bool, true)
      default_outbound_access_enabled               = optional(bool, false)
      nat_gateway = optional(object({
        id = string
      }))
      network_security_group = optional(object({
        id = string
      }))
      route_table = optional(object({
        id = string
      }))
      service_endpoint_policies = optional(map(object({
        id = string
      })))
      service_endpoints_with_location = optional(list(object({
        service   = string
        locations = optional(list(string), ["*"])
      })))
      delegations = optional(list(object({
        name = string
        service_delegation = object({
          name    = string
          actions = optional(list(string), [])
        })
      })), [])
    })), {})
    tags = optional(map(string), {})
  }))
  description = "Existing VNets/subnets; delegation actions are retained as inventory, not forwarded."
  default     = {}

  validation {
    condition = alltrue([
      for vnet in values(var.virtual_network) :
      contains(keys(var.resource_group), vnet.resource_group_key) && (!var.enable_virtual_network || var.enable_resource_group)
    ])
    error_message = "Each VNet must reference a managed resource group, enabled when network adoption is enabled."
  }
}

variable "virtual_network_imports" {
  type        = map(string)
  description = "Existing VNet IDs, keyed by the matching virtual_network instance."
  default     = {}

  validation {
    condition = alltrue([
      for vnet_key, resource_id in var.virtual_network_imports :
      resource_id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[var.virtual_network[vnet_key].resource_group_key].name, "")}/providers/Microsoft.Network/virtualNetworks/${try(var.virtual_network[vnet_key].name, "")}"
    ])
    error_message = "Each virtual_network_imports entry must match its VNet key, name, resource group and subscription_id."
  }
}

variable "virtual_network_subnet_imports" {
  type = map(object({
    vnet_key   = string
    subnet_key = string
    id         = string
  }))
  description = "Existing bare subnet IDs and their owning VNet/subnet keys; the import block appends the API version."
  default     = {}

  validation {
    condition = alltrue([
      for subnet in values(var.virtual_network_subnet_imports) :
      subnet.id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[var.virtual_network[subnet.vnet_key].resource_group_key].name, "")}/providers/Microsoft.Network/virtualNetworks/${try(var.virtual_network[subnet.vnet_key].name, "")}/subnets/${try(var.virtual_network[subnet.vnet_key].subnets[subnet.subnet_key].name, "")}"
    ])
    error_message = "Each subnet import must match its VNet/subnet keys, names, resource group and subscription_id."
  }
}

variable "enable_event_grid_system_topic" {
  type        = bool
  description = "Whether Terraform manages and imports the existing Event Grid system topics."
  default     = false
}

variable "event_grid_system_topic" {
  type = map(object({
    name                        = string
    resource_group_key          = string
    location                    = optional(string)
    topic_type                  = string
    source_resource_id          = optional(string)
    exported_source_resource_id = string
    tags                        = optional(map(string), {})
  }))
  description = "Existing system topics to adopt directly; leave the ForceNew source unset and verify exported source inventory after import."
  default     = {}

  validation {
    condition = alltrue([
      for topic in values(var.event_grid_system_topic) :
      contains(keys(var.resource_group), topic.resource_group_key) && (!var.enable_event_grid_system_topic || var.enable_resource_group)
    ])
    error_message = "Each system topic must reference a managed resource group, enabled when topic adoption is enabled."
  }
}

variable "event_grid_system_topic_imports" {
  type        = map(string)
  description = "Existing system topic IDs, keyed by the matching event_grid_system_topic instance."
  default     = {}

  validation {
    condition = alltrue([
      for topic_key, resource_id in var.event_grid_system_topic_imports :
      resource_id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[var.event_grid_system_topic[topic_key].resource_group_key].name, "")}/providers/Microsoft.EventGrid/systemTopics/${try(var.event_grid_system_topic[topic_key].name, "")}"
    ])
    error_message = "Each event_grid_system_topic_imports entry must match its topic key, name, resource group and subscription_id."
  }
}
variable "enable_log_analytics_workspace" {
  type        = bool
  description = "Whether Terraform manages and imports the existing Log Analytics workspaces."
  default     = false
}

variable "log_analytics_workspace" {
  type = map(object({
    name                            = string
    resource_group_key              = string
    location                        = optional(string)
    sku                             = optional(string, "PerGB2018")
    retention_in_days               = optional(number, 30)
    daily_quota_gb                  = optional(number, -1)
    internet_ingestion_enabled      = optional(string, "true")
    internet_query_enabled          = optional(string, "true")
    local_authentication_enabled    = optional(bool, true)
    allow_resource_only_permissions = optional(bool, true)
    tags                            = optional(map(string), {})
  }))
  description = "Existing Log Analytics workspaces. Ingestion/query flags are strings because the wrapper accepts SecuredByPerimeter."
  default     = {}

  validation {
    condition = alltrue([
      for workspace in values(var.log_analytics_workspace) :
      contains(keys(var.resource_group), workspace.resource_group_key) && (!var.enable_log_analytics_workspace || var.enable_resource_group)
    ])
    error_message = "Each workspace must reference a managed resource group, enabled when workspace adoption is enabled."
  }
}

variable "log_analytics_workspace_imports" {
  type        = map(string)
  description = "Existing workspace IDs, keyed by the matching log_analytics_workspace instance."
  default     = {}

  validation {
    condition = alltrue([
      for workspace_key, resource_id in var.log_analytics_workspace_imports :
      lower(resource_id) == lower("/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[var.log_analytics_workspace[workspace_key].resource_group_key].name, "")}/providers/Microsoft.OperationalInsights/workspaces/${try(var.log_analytics_workspace[workspace_key].name, "")}")
    ])
    error_message = "Each log_analytics_workspace_imports entry must match its workspace key, name, resource group and subscription_id."
  }
}

variable "enable_user_assigned_identity" {
  type        = bool
  description = "Whether Terraform manages and imports the existing user-assigned identities."
  default     = false
}

variable "user_assigned_identity" {
  type = map(object({
    name               = string
    resource_group_key = string
    location           = optional(string)
    isolation_scope    = optional(string)
    tags               = optional(map(string), {})
  }))
  description = "Existing user-assigned identities. Federated credentials and role assignments are not managed here."
  default     = {}

  validation {
    condition = alltrue([
      for identity in values(var.user_assigned_identity) :
      contains(keys(var.resource_group), identity.resource_group_key) && (!var.enable_user_assigned_identity || var.enable_resource_group)
    ])
    error_message = "Each identity must reference a managed resource group, enabled when identity adoption is enabled."
  }
}

variable "user_assigned_identity_imports" {
  type        = map(string)
  description = "Existing identity IDs, keyed by the matching user_assigned_identity instance."
  default     = {}

  validation {
    condition = alltrue([
      for identity_key, resource_id in var.user_assigned_identity_imports :
      resource_id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[var.user_assigned_identity[identity_key].resource_group_key].name, "")}/providers/Microsoft.ManagedIdentity/userAssignedIdentities/${try(var.user_assigned_identity[identity_key].name, "")}"
    ])
    error_message = "Each user_assigned_identity_imports entry must match its identity key, name, resource group and subscription_id."
  }
}

variable "enable_recovery_services_vault" {
  type        = bool
  description = "Whether Terraform manages and imports the existing Recovery Services vaults."
  default     = false
}

variable "recovery_services_vault" {
  type = map(object({
    name                                           = string
    resource_group_key                             = string
    location                                       = optional(string)
    sku                                            = string
    storage_mode_type                              = string
    cross_region_restore_enabled                   = bool
    soft_delete_enabled                            = bool
    immutability                                   = string
    public_network_access_enabled                  = bool
    alerts_for_all_job_failures_enabled            = optional(bool, false)
    alerts_for_critical_operation_failures_enabled = optional(bool, false)
    tags                                           = optional(map(string), {})
  }))
  description = "Existing vault-level settings. Backup policies, protected items and private endpoints are not managed here."
  default     = {}

  validation {
    condition = alltrue([
      for vault in values(var.recovery_services_vault) :
      contains(keys(var.resource_group), vault.resource_group_key) && (!var.enable_recovery_services_vault || var.enable_resource_group)
    ])
    error_message = "Each vault must reference a managed resource group, enabled when vault adoption is enabled."
  }

  validation {
    condition     = alltrue([for vault in values(var.recovery_services_vault) : vault.immutability != "Locked"])
    error_message = "Locked immutability is irreversible and is not set through adoption."
  }
}

variable "recovery_services_vault_imports" {
  type        = map(string)
  description = "Existing vault IDs, keyed by the matching recovery_services_vault instance."
  default     = {}

  validation {
    condition = alltrue([
      for vault_key, resource_id in var.recovery_services_vault_imports :
      resource_id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[var.recovery_services_vault[vault_key].resource_group_key].name, "")}/providers/Microsoft.RecoveryServices/vaults/${try(var.recovery_services_vault[vault_key].name, "")}"
    ])
    error_message = "Each recovery_services_vault_imports entry must match its vault key, name, resource group and subscription_id."
  }
}

variable "enable_public_ssh_key" {
  type        = bool
  description = "Whether Terraform manages and imports the existing SSH public key resources."
  default     = false
}

variable "public_ssh_key" {
  type = map(object({
    name               = string
    resource_group_key = string
    location           = optional(string)
    public_key         = string
    tags               = optional(map(string), {})
  }))
  description = "Existing SSH public key resources. public_key forces replacement, so it must match the export."
  default     = {}

  validation {
    condition = alltrue([
      for key in values(var.public_ssh_key) :
      contains(keys(var.resource_group), key.resource_group_key) && (!var.enable_public_ssh_key || var.enable_resource_group)
    ])
    error_message = "Each SSH key must reference a managed resource group, enabled when key adoption is enabled."
  }
}

variable "public_ssh_key_imports" {
  type        = map(string)
  description = "Existing SSH public key IDs, keyed by the matching public_ssh_key instance."
  default     = {}

  validation {
    condition = alltrue([
      for key_key, resource_id in var.public_ssh_key_imports :
      resource_id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[var.public_ssh_key[key_key].resource_group_key].name, "")}/providers/Microsoft.Compute/sshPublicKeys/${try(var.public_ssh_key[key_key].name, "")}"
    ])
    error_message = "Each public_ssh_key_imports entry must match its key, name, resource group and subscription_id."
  }
}

variable "enable_linux_virtual_machine" {
  type        = bool
  description = "Whether Terraform manages and imports the image-based Linux VMs and their NICs."
  default     = false
}

variable "linux_virtual_machine" {
  type = map(object({
    name                                                   = string
    resource_group_key                                     = string
    location                                               = optional(string)
    size                                                   = string
    zone                                                   = optional(string)
    admin_username                                         = string
    admin_ssh_public_keys                                  = list(string)
    computer_name                                          = string
    network_interface_ids                                  = list(string)
    os_managed_disk_id                                     = string
    allow_extension_operations                             = bool
    bypass_platform_safety_checks_on_user_schedule_enabled = bool
    disk_controller_type                                   = string
    encryption_at_host_enabled                             = optional(bool)
    license_type                                           = optional(string)
    patch_assessment_mode                                  = string
    patch_mode                                             = string
    provision_vm_agent                                     = bool
    secure_boot_enabled                                    = bool
    vtpm_enabled                                           = bool
    additional_capabilities = optional(object({
      ultra_ssd_enabled   = optional(bool)
      hibernation_enabled = optional(bool)
    }), {})
    boot_diagnostics = optional(object({
      storage_account_uri = optional(string)
    }))
    identity = object({
      type                       = string
      user_assigned_identity_ids = optional(set(string), [])
    })
    os_disk = object({
      name                 = string
      caching              = string
      disk_size_gb         = number
      storage_account_type = string
    })
    source_image_reference = object({
      publisher = string
      offer     = string
      sku       = string
      version   = string
    })
    tags = optional(map(string), {})
  }))
  description = "Existing image-based Linux VMs to adopt through wrapper 0.0.7. The VM owns its OS disk inline; os_managed_disk_id is inventory only and data disk attachments stay unmanaged."
  default     = {}

  validation {
    condition = alltrue([
      for vm in values(var.linux_virtual_machine) :
      contains(keys(var.resource_group), vm.resource_group_key) && (!var.enable_linux_virtual_machine || var.enable_resource_group)
    ])
    error_message = "Each Linux VM must reference a managed resource group, enabled when VM adoption is enabled."
  }

  validation {
    condition = !var.enable_linux_virtual_machine || alltrue([
      for vm in values(var.linux_virtual_machine) :
      length(vm.network_interface_ids) > 0 && alltrue([
        for resource_id in vm.network_interface_ids : contains(values(local.network_interface_resource_ids), resource_id)
      ])
    ])
    error_message = "Every Linux VM NIC ID must match an existing network_interface inventory entry exactly for wrapper-owned adoption."
  }

  validation {
    condition = !var.enable_linux_virtual_machine || length(flatten([
      for vm in values(var.linux_virtual_machine) : vm.network_interface_ids
      ])) == length(toset(flatten([
        for vm in values(var.linux_virtual_machine) : vm.network_interface_ids
    ])))
    error_message = "A NIC must not be assigned to multiple Linux VM wrapper instances or listed more than once."
  }

  validation {
    condition = alltrue([
      for vm in values(var.linux_virtual_machine) :
      contains(["None", "SystemAssigned", "UserAssigned", "SystemAssigned, UserAssigned"], vm.identity.type) &&
      (strcontains(vm.identity.type, "UserAssigned") == (length(vm.identity.user_assigned_identity_ids) > 0))
    ])
    error_message = "VM identity type must be an exported ARM identity type, with user_assigned_identity_ids set exactly when it includes UserAssigned."
  }

  validation {
    condition     = alltrue([for vm in values(var.linux_virtual_machine) : length(vm.admin_ssh_public_keys) > 0])
    error_message = "The Linux wrapper forbids passwords, so each VM needs its exported SSH public key."
  }
}

variable "linux_virtual_machine_imports" {
  type        = map(string)
  description = "Existing Linux VM IDs, keyed by the matching linux_virtual_machine instance."
  default     = {}

  validation {
    condition = alltrue([
      for vm_key, resource_id in var.linux_virtual_machine_imports :
      resource_id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[var.linux_virtual_machine[vm_key].resource_group_key].name, "")}/providers/Microsoft.Compute/virtualMachines/${try(var.linux_virtual_machine[vm_key].name, "")}"
    ])
    error_message = "Each linux_virtual_machine_imports entry must match its VM key, name, resource group and subscription_id."
  }
}

variable "enable_app_service_environment" {
  type        = bool
  description = "Whether Terraform manages and imports the existing App Service Environments."
  default     = false
}

variable "app_service_environment" {
  type = map(object({
    name                                   = string
    resource_group_key                     = string
    location                               = optional(string)
    subnet_id                              = string
    internal_load_balancing_mode           = string
    zone_redundancy_enabled                = bool
    internal_encryption_enabled            = bool
    ftp_enabled                            = bool
    remote_debug_enabled                   = bool
    allow_new_private_endpoint_connections = bool
    tls_1_enabled                          = bool
    inbound_ip_address_override            = optional(string)
    upgrade_preference                     = string
    dedicated_host_count                   = optional(number)
    system_assigned_identity               = bool
    tags                                   = optional(map(string), {})
  }))
  description = "Existing ASEv3 settings. zone_redundancy_enabled and the subnet force replacement, and the wrapper defaults differ from the deployed ASE, so every field is explicit."
  default     = {}

  validation {
    condition = alltrue([
      for ase in values(var.app_service_environment) :
      contains(keys(var.resource_group), ase.resource_group_key) && (!var.enable_app_service_environment || var.enable_resource_group)
    ])
    error_message = "Each ASE must reference a managed resource group, enabled when ASE adoption is enabled."
  }
}

variable "app_service_environment_imports" {
  type        = map(string)
  description = "Existing ASE IDs, keyed by the matching app_service_environment instance."
  default     = {}

  validation {
    condition = alltrue([
      for ase_key, resource_id in var.app_service_environment_imports :
      resource_id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[var.app_service_environment[ase_key].resource_group_key].name, "")}/providers/Microsoft.Web/hostingEnvironments/${try(var.app_service_environment[ase_key].name, "")}"
    ])
    error_message = "Each app_service_environment_imports entry must match its ASE key, name, resource group and subscription_id."
  }
}

variable "enable_app_service_plan" {
  type        = bool
  description = "Whether Terraform manages and imports the existing App Service plans."
  default     = false
}

variable "app_service_plan" {
  type = map(object({
    name                            = string
    resource_group_key              = string
    location                        = optional(string)
    os_type                         = string
    sku_name                        = string
    worker_count                    = number
    maximum_elastic_worker_count    = number
    per_site_scaling_enabled        = bool
    premium_plan_auto_scale_enabled = bool
    zone_balancing_enabled          = bool
    app_service_environment_id      = optional(string)
    tags                            = optional(map(string), {})
  }))
  description = "Existing App Service plans. Every sizing field is explicit because the wrapper defaults (3 workers, zone balancing) differ from the deployed plan."
  default     = {}

  validation {
    condition = alltrue([
      for plan in values(var.app_service_plan) :
      contains(keys(var.resource_group), plan.resource_group_key) && (!var.enable_app_service_plan || var.enable_resource_group)
    ])
    error_message = "Each plan must reference a managed resource group, enabled when plan adoption is enabled."
  }
}

variable "app_service_plan_imports" {
  type        = map(string)
  description = "Existing App Service plan IDs, keyed by the matching app_service_plan instance."
  default     = {}

  validation {
    condition = alltrue([
      for plan_key, resource_id in var.app_service_plan_imports :
      resource_id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[var.app_service_plan[plan_key].resource_group_key].name, "")}/providers/Microsoft.Web/serverFarms/${try(var.app_service_plan[plan_key].name, "")}"
    ])
    error_message = "Each app_service_plan_imports entry must match its plan key, name, resource group and subscription_id."
  }
}

variable "enable_application_insights" {
  type        = bool
  description = "Whether Terraform manages and imports the existing Application Insights components."
  default     = false
}

variable "application_insights" {
  type = map(object({
    name                          = string
    resource_group_key            = string
    location                      = optional(string)
    workspace_id                  = string
    application_type              = optional(string, "web")
    retention_in_days             = number
    daily_data_cap_in_gb          = number
    sampling_percentage           = optional(number)
    internet_ingestion_enabled    = bool
    internet_query_enabled        = bool
    local_authentication_disabled = optional(bool, false)
    disable_ip_masking            = optional(bool, false)
    tags                          = optional(map(string), {})
  }))
  description = "Existing workspace-based Application Insights components. workspace_id is the exact workspace the component sends to, which may live in another subscription."
  default     = {}

  validation {
    condition = alltrue([
      for component in values(var.application_insights) :
      contains(keys(var.resource_group), component.resource_group_key) && (!var.enable_application_insights || var.enable_resource_group)
    ])
    error_message = "Each component must reference a managed resource group, enabled when component adoption is enabled."
  }
}

variable "application_insights_imports" {
  type        = map(string)
  description = "Existing Application Insights IDs, keyed by the matching application_insights instance."
  default     = {}

  validation {
    condition = alltrue([
      for component_key, resource_id in var.application_insights_imports :
      lower(resource_id) == lower("/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[var.application_insights[component_key].resource_group_key].name, "")}/providers/Microsoft.Insights/components/${try(var.application_insights[component_key].name, "")}")
    ])
    error_message = "Each application_insights_imports entry must match its component key, name, resource group and subscription_id."
  }
}

variable "enable_private_dns_zone" {
  type        = bool
  description = "Whether Terraform manages and imports the existing private DNS zones and their VNet links."
  default     = false
}

variable "private_dns_zone" {
  type = map(object({
    name               = string
    resource_group_key = string
    virtual_network_links = optional(map(object({
      name                 = string
      virtual_network_id   = string
      registration_enabled = optional(bool, false)
      resolution_policy    = optional(string, "Default")
      tags                 = optional(map(string))
    })), {})
    tags = optional(map(string), {})
  }))
  description = "Existing private DNS zones and VNet links. Record sets are not managed here."
  default     = {}

  validation {
    condition = alltrue([
      for zone in values(var.private_dns_zone) :
      contains(keys(var.resource_group), zone.resource_group_key) && (!var.enable_private_dns_zone || var.enable_resource_group)
    ])
    error_message = "Each private DNS zone must reference a managed resource group, enabled when zone adoption is enabled."
  }
}

variable "private_dns_zone_imports" {
  type        = map(string)
  description = "Existing private DNS zone IDs, keyed by the matching private_dns_zone instance."
  default     = {}

  validation {
    condition = alltrue([
      for zone_key, resource_id in var.private_dns_zone_imports :
      resource_id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[var.private_dns_zone[zone_key].resource_group_key].name, "")}/providers/Microsoft.Network/privateDnsZones/${try(var.private_dns_zone[zone_key].name, "")}"
    ])
    error_message = "Each private_dns_zone_imports entry must match its zone key, name, resource group and subscription_id."
  }
}

variable "private_dns_zone_link_imports" {
  type = map(object({
    zone_key = string
    link_key = string
    id       = string
  }))
  description = "Existing VNet link IDs and their zone/link keys."
  default     = {}

  validation {
    condition = alltrue([
      for link in values(var.private_dns_zone_link_imports) :
      lower(link.id) == lower("/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[var.private_dns_zone[link.zone_key].resource_group_key].name, "")}/providers/Microsoft.Network/privateDnsZones/${try(var.private_dns_zone[link.zone_key].name, "")}/virtualNetworkLinks/${try(var.private_dns_zone[link.zone_key].virtual_network_links[link.link_key].name, "")}")
    ])
    error_message = "Each private_dns_zone_link_imports entry must match its zone key, link key, names, resource group and subscription_id."
  }
}

variable "enable_web_app" {
  type        = bool
  description = "Whether Terraform manages and imports the existing web apps. Every live app setting and connection string must be supplied first; the module rewrites the full lists on apply."
  default     = false
}

variable "web_app" {
  type = map(object({
    name                                     = string
    resource_group_key                       = string
    location                                 = optional(string)
    os_type                                  = string
    app_service_plan_key                     = string
    app_service_environment_key              = string
    enabled                                  = bool
    https_only                               = bool
    public_network_access_enabled            = bool
    client_affinity_enabled                  = bool
    client_affinity_proxy_enabled            = bool
    client_certificate_enabled               = bool
    client_certificate_mode                  = string
    end_to_end_encryption_enabled            = bool
    host_names_disabled                      = bool
    hyper_v                                  = bool
    ip_mode                                  = string
    redundancy_mode                          = string
    vnet_route_all_traffic                   = bool
    vnet_application_traffic_enabled         = bool
    vnet_content_share_enabled               = bool
    vnet_image_pull_enabled                  = bool
    virtual_network_backup_restore_enabled   = bool
    ftp_publish_basic_authentication_enabled = bool
    scm_publish_basic_authentication_enabled = bool
    user_assigned_identity_ids               = set(string)
    key_vault_reference_identity             = optional(string)
    site_config                              = any
    app_settings                             = map(string)
    secret_app_setting_names                 = optional(set(string), [])
    connection_strings = optional(map(object({
      name = string
      type = string
    })), {})
    sticky_app_setting_names = optional(list(string), [])
    tags                     = optional(map(string), {})
  }))
  description = "Existing web apps. Non-secret app settings live here; secret ones are listed by name and supplied through web_app_secret_app_settings."
  default     = {}

  validation {
    condition = alltrue([
      for app in values(var.web_app) :
      contains(keys(var.resource_group), app.resource_group_key) && (!var.enable_web_app || var.enable_resource_group) &&
      contains(keys(var.app_service_plan), app.app_service_plan_key) && contains(keys(var.app_service_environment), app.app_service_environment_key)
    ])
    error_message = "Each web app must reference a managed resource group, an app_service_plan key and an app_service_environment key."
  }

  validation {
    condition = alltrue([
      for app in values(var.web_app) : length(setintersection(toset(keys(app.app_settings)), app.secret_app_setting_names)) == 0
    ])
    error_message = "A setting must not appear in both app_settings and secret_app_setting_names."
  }
}

variable "web_app_secret_app_settings" {
  type        = map(map(string))
  description = "Secret app setting values keyed by web_app key, then setting name. Supply through a sensitive pipeline variable, never tfvars."
  sensitive   = true
  default     = {}

  validation {
    condition = !var.enable_web_app || alltrue([
      for app_key, app in var.web_app :
      toset(keys(lookup(var.web_app_secret_app_settings, app_key, {}))) == app.secret_app_setting_names
    ])
    error_message = "Enabling web apps requires a value for every name in secret_app_setting_names, and no others."
  }
}

variable "web_app_secret_connection_strings" {
  type        = map(map(string))
  description = "Connection string values keyed by web_app key, then connection_strings key. Supply through a sensitive pipeline variable, never tfvars."
  sensitive   = true
  default     = {}

  validation {
    condition = !var.enable_web_app || alltrue([
      for app_key, app in var.web_app :
      toset(keys(lookup(var.web_app_secret_connection_strings, app_key, {}))) == toset(keys(app.connection_strings))
    ])
    error_message = "Enabling web apps requires a value for every configured connection string."
  }
}

variable "web_app_imports" {
  type        = map(string)
  description = "Existing web app IDs, keyed by the matching web_app instance."
  default     = {}

  validation {
    condition = alltrue([
      for app_key, resource_id in var.web_app_imports :
      resource_id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[var.web_app[app_key].resource_group_key].name, "")}/providers/Microsoft.Web/sites/${try(var.web_app[app_key].name, "")}"
    ])
    error_message = "Each web_app_imports entry must match its app key, name, resource group and subscription_id."
  }
}

# =====================================================================
# Hub private DNS (connectivity subscription)
# =====================================================================

variable "hub_dns_subscription_id" {
  type        = string
  description = "Connectivity subscription that hosts the shared private DNS zones."
  default     = "f3835bc1-9829-4ac8-9d7a-0999e0b29b90"
}

variable "hub_dns_resource_group_name" {
  type        = string
  description = "Resource group of the shared private DNS zones."
  default     = "rg-dns-connectivity-canadacentral-001"
}

variable "enable_hub_private_dns" {
  type        = bool
  description = "Whether Terraform manages and imports this app's VNet links and records in the shared hub zones."
  default     = false
}

variable "hub_private_dns_zone_link" {
  type = map(object({
    enabled              = optional(bool, true)
    name                 = string
    zone_name            = string
    virtual_network_id   = string
    registration_enabled = optional(bool, false)
    resolution_policy    = optional(string, "Default")
  }))
  description = "This app's VNet links in the shared hub zones."
  default     = {}
}

variable "hub_private_dns_zone_link_imports" {
  type        = map(string)
  description = "Existing VNet link IDs, keyed by hub_private_dns_zone_link and filtered by global/per-entry enable flags."
  default     = {}

  validation {
    condition = alltrue([
      for link_key, resource_id in var.hub_private_dns_zone_link_imports :
      resource_id == "/subscriptions/${var.hub_dns_subscription_id}/resourceGroups/${var.hub_dns_resource_group_name}/providers/Microsoft.Network/privateDnsZones/${try(var.hub_private_dns_zone_link[link_key].zone_name, "")}/virtualNetworkLinks/${try(var.hub_private_dns_zone_link[link_key].name, "")}"
    ])
    error_message = "Each hub_private_dns_zone_link_imports entry must match its link's zone, name, hub resource group and subscription."
  }
}

variable "hub_private_dns_a_record" {
  type = map(object({
    enabled   = optional(bool, true)
    name      = string
    zone_name = string
    ttl       = number
    records   = list(string)
  }))
  description = "This app's A records in the shared hub zones."
  default     = {}
}

variable "hub_private_dns_a_record_imports" {
  type        = map(string)
  description = "Existing A record IDs, keyed by hub_private_dns_a_record and filtered by global/per-entry enable flags."
  default     = {}

  validation {
    condition = alltrue([
      for record_key, resource_id in var.hub_private_dns_a_record_imports :
      resource_id == "/subscriptions/${var.hub_dns_subscription_id}/resourceGroups/${var.hub_dns_resource_group_name}/providers/Microsoft.Network/privateDnsZones/${try(var.hub_private_dns_a_record[record_key].zone_name, "")}/A/${try(var.hub_private_dns_a_record[record_key].name, "")}"
    ])
    error_message = "Each hub_private_dns_a_record_imports entry must match its record's zone, name, hub resource group and subscription."
  }
}

variable "hub_private_dns_cname_record" {
  type = map(object({
    enabled   = optional(bool, true)
    name      = string
    zone_name = string
    ttl       = number
    record    = string
  }))
  description = "This app's CNAME records in the shared hub zones."
  default     = {}
}

variable "hub_private_dns_cname_record_imports" {
  type        = map(string)
  description = "Existing CNAME record IDs, keyed by hub_private_dns_cname_record and filtered by global/per-entry enable flags."
  default     = {}

  validation {
    condition = alltrue([
      for record_key, resource_id in var.hub_private_dns_cname_record_imports :
      resource_id == "/subscriptions/${var.hub_dns_subscription_id}/resourceGroups/${var.hub_dns_resource_group_name}/providers/Microsoft.Network/privateDnsZones/${try(var.hub_private_dns_cname_record[record_key].zone_name, "")}/CNAME/${try(var.hub_private_dns_cname_record[record_key].name, "")}"
    ])
    error_message = "Each hub_private_dns_cname_record_imports entry must match its record's zone, name, hub resource group and subscription."
  }
}
