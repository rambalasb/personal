# Sub-Fit-NonProd (fa089a5b-f881-41a6-a30f-58bfdfd52abd)
# Values come from the Azure resource export of 2026-10-20 (web app settings
# and alerts from follow-up exports the same day).
# The Oracle VM (and its NIC) and the web app are off for the first apply;
# adopt them in separate runs.

subscription_id = "fa089a5b-f881-41a6-a30f-58bfdfd52abd"

enable_resource_group           = true
enable_monitoring               = true
enable_app_service_environment  = true
enable_app_service_plan         = true
enable_application_insights     = true
enable_bastion_host             = true
enable_key_vault                = true
enable_linux_virtual_machine    = false
enable_log_analytics_workspace  = true
enable_network_interface        = false
enable_network_security_group   = true
enable_network_watcher          = true
enable_private_dns_zone         = true
enable_private_endpoint         = true
enable_public_ssh_key           = true
enable_recovery_services_vault  = true
enable_restore_point_collection = true
enable_storage_account          = true
enable_user_assigned_identity   = true
enable_virtual_network          = false
enable_event_grid_system_topic  = true
enable_web_app                  = false

enable_resource_group_role_assignment           = false
enable_monitoring_role_assignment               = false
enable_app_service_environment_role_assignment  = false
enable_app_service_plan_role_assignment         = false
enable_application_insights_role_assignment     = false
enable_bastion_host_role_assignment             = false
enable_key_vault_role_assignment                = false
enable_linux_virtual_machine_role_assignment    = false
enable_log_analytics_workspace_role_assignment  = false
enable_network_interface_role_assignment        = false
enable_network_security_group_role_assignment   = false
enable_network_watcher_role_assignment          = false
enable_private_dns_zone_role_assignment         = false
enable_private_endpoint_role_assignment         = false
enable_public_ssh_key_role_assignment           = false
enable_recovery_services_vault_role_assignment  = false
enable_restore_point_collection_role_assignment = false
enable_storage_account_role_assignment          = false
enable_user_assigned_identity_role_assignment   = false
enable_virtual_network_role_assignment          = false
enable_event_grid_system_topic_role_assignment  = false
enable_web_app_role_assignment                  = false

role_assignments = {}

# AzureBackupRG_canadacentral_1 is left out: Azure Backup owns it (managedBy is
# Microsoft.RecoveryServices) and ARM rejects any PUT that drops managedBy.
resource_group = {
  alerts = {
    name     = "rg-alerts-fit-nonprod-canadacentral-001"
    location = "canadacentral"
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Field Investigation Tool"
    }
  }
  app = {
    name     = "rg-fit-app-nonprod-canadacentral-001"
    location = "canadacentral"
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Field Investigation Tool"
    }
  }
  app_pam_poc = {
    name     = "rg-fit-app-nonprod-canadacentral-PAM-POC"
    location = "canadacentral"
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Field Investigation Tool"
    }
  }
  mid_app = {
    name     = "rg-mid-fit-app-nonprod-canadacentral-001"
    location = "canadacentral"
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Field Investigation Tool"
    }
  }
  shared_app = {
    name     = "rg-shared-fit-app-nonprod-canadacentral-001"
    location = "canadacentral"
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Field Investigation Tool"
    }
  }
  defaultresourcegroup_ccan = {
    name     = "DefaultResourceGroup-CCAN"
    location = "canadacentral"
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Field Investigation Tool"
    }
  }
}

import_resource_group = {
  alerts                    = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-alerts-fit-nonprod-canadacentral-001"
  app                       = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001"
  app_pam_poc               = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-PAM-POC"
  mid_app                   = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-mid-fit-app-nonprod-canadacentral-001"
  shared_app                = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-shared-fit-app-nonprod-canadacentral-001"
  defaultresourcegroup_ccan = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/DefaultResourceGroup-CCAN"
}

# Several action group IDs contain a leading space in the group name; kept as exported.
# VM-OS-Patch-Available matches two statuses, which the wrapper's single
# status field cannot express; it stays unmanaged (see WRAPPER-GAPS.md).
alert = {
  resource_group_key         = "alerts"
  root_management_group_name = null
  tags                       = {}
  activity_log_alerts = {
    key_vault_deletion = {
      name                = "KeyVault-Deletion-Alert-canadacentral"
      resource_group_name = "rg-alerts-fit-nonprod-canadacentral-001"
      scopes              = ["/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd"]
      location            = "global"
      description         = "This alert will monitor any deletion of key vault"
      enabled             = true
      criteria = {
        category       = "Administrative"
        operation_name = "Microsoft.KeyVault/vaults/delete"
      }
      action_group_keys = []
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      webhook_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001397"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affairs"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Field Investigation Tool"
      }
    }
    service_outage = {
      name                = "Service-Outage-Alert-canadacentral"
      resource_group_name = "rg-alerts-fit-nonprod-canadacentral-001"
      scopes              = ["/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd"]
      location            = "global"
      description         = "Azure Landing Zone Service Health Alert"
      enabled             = true
      criteria = {
        category = "ServiceHealth"
        service_health = {
          locations = ["Global"]
        }
      }
      action_group_keys = []
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ ag-fit-db-mail-alerts-canadacentral-002"
      ]
      webhook_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001397"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affairs"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Field Investigation Tool"
      }
    }
    app_create_update = {
      name                = "app-fit-nonprod-create-update"
      resource_group_name = "rg-alerts-fit-nonprod-canadacentral-001"
      scopes              = ["/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd"]
      location            = "global"
      description         = ""
      enabled             = true
      criteria = {
        category       = "Administrative"
        operation_name = "Microsoft.Web/serverfarms/Write"
      }
      action_group_keys = []
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-monitor-mail-alerts-canadacentral-001"
      ]
      webhook_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        BusinessUnit            = "Customer & Corporate Affairs"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Call Out Procedures"
      }
    }
    app_delete = {
      name                = "app-fit-nonprod-delete"
      resource_group_name = "rg-alerts-fit-nonprod-canadacentral-001"
      scopes              = ["/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd"]
      location            = "global"
      description         = ""
      enabled             = true
      criteria = {
        category       = "Administrative"
        operation_name = "Microsoft.Web/sites/Delete"
      }
      action_group_keys = []
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ ag-fit-db-mail-alerts-canadacentral-002"
      ]
      webhook_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        BusinessUnit            = "Customer & Corporate Affairs"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Call Out Procedures"
      }
    }
    app_restart = {
      name                = "app-fit-nonprod-restart"
      resource_group_name = "rg-alerts-fit-nonprod-canadacentral-001"
      scopes              = ["/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd"]
      location            = "global"
      description         = ""
      enabled             = true
      criteria = {
        category       = "Administrative"
        operation_name = "Microsoft.Web/sites/restart/Action"
      }
      action_group_keys = []
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-monitor-mail-alerts-canadacentral-001"
      ]
      webhook_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        BusinessUnit            = "Customer & Corporate Affairs"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Call Out Procedures"
      }
    }
    app_stop = {
      name                = "app-fit-nonprod-stop"
      resource_group_name = "rg-alerts-fit-nonprod-canadacentral-001"
      scopes              = ["/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd"]
      location            = "global"
      description         = ""
      enabled             = true
      criteria = {
        category       = "Administrative"
        operation_name = "Microsoft.Web/sites/stop/Action"
      }
      action_group_keys = []
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-monitor-mail-alerts-canadacentral-001"
      ]
      webhook_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        BusinessUnit            = "Customer & Corporate Affairs"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Call Out Procedures"
      }
    }
  }
  metric_alerts = {
    app_fit_connections_warning = {
      name                = "app-fit-connections-warning"
      resource_group_name = "rg-alerts-fit-nonprod-canadacentral-001"
      scopes = [
        "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Web/sites/app-fit-dev"
      ]
      description              = "This alert is for Sub-Fit-nonProd App's connections"
      enabled                  = false
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 2
      target_resource_type     = "Microsoft.Web/sites"
      target_resource_location = "canadacentral"
      dynamic_criteria = {
        metric_namespace         = "Microsoft.Web/sites"
        metric_name              = "AppConnections"
        aggregation              = "Average"
        operator                 = "GreaterOrLessThan"
        alert_sensitivity        = "Medium"
        evaluation_total_count   = 4
        evaluation_failure_count = 4
        ignore_data_before       = null
        skip_metric_validation   = false
        dimensions               = []
      }
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/lga-servicenow-integration_group/providers/microsoft.insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001397"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affairs"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Field Investigation Tool"
      }
    }
    app_fit_http_404_informational = {
      name                = "app-fit-http-404-informational"
      resource_group_name = "rg-alerts-fit-nonprod-canadacentral-001"
      scopes = [
        "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Web/sites/app-fit-dev"
      ]
      description              = "This alert is for Sub-Fit-Prod App's HTTP errors"
      enabled                  = false
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 3
      target_resource_type     = "Microsoft.Web/sites"
      target_resource_location = "canadacentral"
      dynamic_criteria = {
        metric_namespace         = "Microsoft.Web/sites"
        metric_name              = "Http4xx"
        aggregation              = "Total"
        operator                 = "GreaterOrLessThan"
        alert_sensitivity        = "Medium"
        evaluation_total_count   = 4
        evaluation_failure_count = 4
        ignore_data_before       = null
        skip_metric_validation   = false
        dimensions               = []
      }
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/lga-servicenow-integration_group/providers/microsoft.insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001397"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affairs"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Field Investigation Tool"
      }
    }
    app_health_alert_canadacentral = {
      name                = "App-Health-Alert-canadacentral"
      resource_group_name = "rg-fit-app-nonprod-canadacentral-001"
      scopes = [
        "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Web/sites/app-fit-dev"
      ]
      description              = "This alert is for Sub-Fit-NonProd App's Health Check"
      enabled                  = false
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 3
      target_resource_type     = "Microsoft.Web/sites"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Web/sites"
          metric_name            = "HealthCheckStatus"
          aggregation            = "Average"
          operator               = "LessThan"
          threshold              = 100
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/lga-servicenow-integration_group/providers/microsoft.insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001397"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affairs"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Field Investigation Tool"
      }
    }
    app_high_cpu_alert_canadacentral = {
      name                = "App-High-CPU-Alert-canadacentral"
      resource_group_name = "rg-fit-app-nonprod-canadacentral-001"
      scopes = [
        "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Web/sites/app-fit-dev"
      ]
      description              = "This alert is fro Sub-Fit-NonProd App's High CPU usage"
      enabled                  = false
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 3
      target_resource_type     = "Microsoft.Web/sites"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Web/sites"
          metric_name            = "CpuTime"
          aggregation            = "Total"
          operator               = "GreaterThan"
          threshold              = 300
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001397"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affairs"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Field Investigation Tool"
      }
    }
    app_high_response_time_alert_canadcentral = {
      name                = "App-High-Response-Time-Alert-canadcentral"
      resource_group_name = "rg-fit-app-nonprod-canadacentral-001"
      scopes = [
        "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Web/sites/app-fit-dev"
      ]
      description              = "This alert is for Sub-Fit-NonProd App's High response time"
      enabled                  = false
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 3
      target_resource_type     = "Microsoft.Web/sites"
      target_resource_location = "canadacentral"
      dynamic_criteria = {
        metric_namespace         = "Microsoft.Web/sites"
        metric_name              = "HttpResponseTime"
        aggregation              = "Average"
        operator                 = "GreaterOrLessThan"
        alert_sensitivity        = "Medium"
        evaluation_total_count   = 4
        evaluation_failure_count = 4
        ignore_data_before       = null
        skip_metric_validation   = false
        dimensions               = []
      }
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001397"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affairs"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Field Investigation Tool"
      }
    }
    app_http_alert_canadacentral = {
      name                = "App-HTTP-Alert-canadacentral"
      resource_group_name = "rg-fit-app-nonprod-canadacentral-001"
      scopes = [
        "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Web/sites/app-fit-dev"
      ]
      description              = "This alert is for Sub-Fit-NonProd App's HTTP errors"
      enabled                  = false
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 1
      target_resource_type     = "Microsoft.Web/sites"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Web/sites"
          metric_name            = "Http5xx"
          aggregation            = "Total"
          operator               = "GreaterThan"
          threshold              = 5
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/lga-servicenow-integration_group/providers/microsoft.insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001397"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affairs"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Field Investigation Tool"
      }
    }
    backup_alert = {
      name                = "Backup Alert"
      resource_group_name = "rg-fit-app-nonprod-canadacentral-001"
      scopes = [
        "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.RecoveryServices/vaults/rsv-fit-canadacentral-001"
      ]
      description              = ""
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT15M"
      window_size              = "PT6H"
      severity                 = 3
      target_resource_type     = "Microsoft.RecoveryServices/vaults"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.RecoveryServices/vaults"
          metric_name            = "BackupHealthEvent"
          aggregation            = "Count"
          operator               = "GreaterThan"
          threshold              = 0
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actionGroups/ag-monitor-mail-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001397"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affairs"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Field Investigation Tool"
      }
    }
    oracle_vm_fit_nonprod_memory_high_warning = {
      name                = "oracle-vm-fit-nonprod-memory-high-warning"
      resource_group_name = "rg-mid-fit-app-nonprod-canadacentral-001"
      scopes = [
        "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-oracledb-fit-nonprod-canadacentral-001"
      ]
      description              = "Action will be triggered when percentage CPU for VM is greater than 90%"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 2
      target_resource_type     = "Microsoft.Compute/virtualMachines"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Compute/virtualMachines"
          metric_name            = "Available Memory Percentage"
          aggregation            = "Average"
          operator               = "LessThanOrEqual"
          threshold              = 10
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-db-mail-alerts-canadacentral-001",
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001",
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ ag-fit-db-mail-alerts-canadacentral-002"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001397"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affairs"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Field Investigation Tool"
      }
    }
    oracle_vm_nonprod_high_cpu_alert_canadacentral = {
      name                = "Oracle-VM-NonProd-High-CPU-Alert-canadacentral"
      resource_group_name = "rg-mid-fit-app-nonprod-canadacentral-001"
      scopes = [
        "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-oracledb-fit-nonprod-canadacentral-001"
      ]
      description              = "Triggered when disk space has consumed >85%"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT15M"
      severity                 = 3
      target_resource_type     = "Microsoft.Compute/virtualMachines"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Compute/virtualMachines"
          metric_name            = "Percentage CPU"
          aggregation            = "Average"
          operator               = "GreaterThan"
          threshold              = 85
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-db-mail-alerts-canadacentral-001",
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001",
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ ag-fit-db-mail-alerts-canadacentral-002"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001397"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affairs"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Field Investigation Tool"
      }
    }
    restore_job_failed_fit_nonprod_canadacentral = {
      name                = "Restore-Job-Failed-FIT-Nonprod-canadacentral"
      resource_group_name = "rg-mid-fit-app-nonprod-canadacentral-001"
      scopes = [
        "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourcegroups/rg-fit-app-nonprod-canadacentral-001"
      ]
      description              = "Job triggers when restore job is faild"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT15M"
      severity                 = 2
      target_resource_type     = "microsoft.recoveryservices/vaults"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "microsoft.recoveryservices/vaults"
          metric_name            = "RestoreHealthEvent"
          aggregation            = "Count"
          operator               = "GreaterThanOrEqual"
          threshold              = 1
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-monitor-mail-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001397"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affairs"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Field Investigation Tool"
      }
    }
    vm_fit_nonprod_cpu_high_warning = {
      name                     = "vm-fit-nonprod-cpu-high-warning"
      resource_group_name      = "rg-alerts-fit-nonprod-canadacentral-001"
      scopes                   = ["/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd"]
      description              = "Action will be triggered when percentage CPU for VM is greater than 90%"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT30M"
      severity                 = 2
      target_resource_type     = "microsoft.compute/virtualmachines"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "microsoft.compute/virtualmachines"
          metric_name            = "Percentage CPU"
          aggregation            = "Average"
          operator               = "GreaterThan"
          threshold              = 90
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/lga-servicenow-integration_group/providers/microsoft.insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001397"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affairs"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Field Investigation Tool"
      }
    }
    vm_fit_nonprod_memory_high_warning = {
      name                     = "vm-fit-nonprod-memory-high-warning"
      resource_group_name      = "rg-alerts-fit-nonprod-canadacentral-001"
      scopes                   = ["/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd"]
      description              = "Action will be triggered when percentage CPU for VM is greater than 90%"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 2
      target_resource_type     = "microsoft.compute/virtualmachines"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "microsoft.compute/virtualmachines"
          metric_name            = "Available Memory Percentage"
          aggregation            = "Average"
          operator               = "LessThanOrEqual"
          threshold              = 10
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/lga-servicenow-integration_group/providers/microsoft.insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001397"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affairs"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Field Investigation Tool"
      }
    }
    vm_os_disk_iops_alert_canadacentral = {
      name                     = "VM-OS-Disk-IOPS-Alert-canadacentral"
      resource_group_name      = "rg-mid-fit-app-nonprod-canadacentral-001"
      scopes                   = ["/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd"]
      description              = "Action will be triggered when Disk IOSP is greater"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 2
      target_resource_type     = "microsoft.compute/virtualmachines"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "microsoft.compute/virtualmachines"
          metric_name            = "OS Disk IOPS Consumed Percentage"
          aggregation            = "Average"
          operator               = "GreaterThan"
          threshold              = 80
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-monitor-mail-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001397"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affairs"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Field Investigation Tool"
      }
    }
  }
  log_search_alerts = {
    keyvault_secret_expired_alert_canadacentral = {
      name                              = "KeyVault-Secret-Expired-Alert-canadacentral"
      resource_group_name               = "rg-alerts-fit-nonprod-canadacentral-001"
      location                          = "canadacentral"
      scopes                            = ["/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd"]
      severity                          = 0
      evaluation_frequency              = "PT5M"
      window_duration                   = "PT30M"
      description                       = "Alert for expired secret in a Key Vault."
      display_name                      = "KeyVault-Secret-Expired-Alert-canadacentral"
      enabled                           = true
      auto_mitigation_enabled           = false
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = null
      target_resource_types             = null
      criteria = [
        {
          query                   = "        AzureDiagnostics\n        | where ResourceProvider == \"MICROSOFT.KEYVAULT\"\n        | where OperationName contains \"SecretExpired\"\n        "
          time_aggregation_method = "Count"
          threshold               = 1
          operator                = "GreaterThanOrEqual"
          resource_id_column      = "ResourceId"
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001397"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affairs"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Field Investigation Tool"
      }
    }
    keyvault_secret_near_expiry_alert_canadacentral = {
      name                              = "KeyVault-Secret-Near-Expiry-Alert-canadacentral"
      resource_group_name               = "rg-alerts-fit-nonprod-canadacentral-001"
      location                          = "canadacentral"
      scopes                            = ["/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd"]
      severity                          = 1
      evaluation_frequency              = "PT5M"
      window_duration                   = "PT30M"
      description                       = "Alert for secret in a Key Vault is about to expire."
      display_name                      = "KeyVault-Secret-Near-Expiry-Alert-canadacentral"
      enabled                           = true
      auto_mitigation_enabled           = false
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = null
      target_resource_types             = null
      criteria = [
        {
          query                   = "        AzureDiagnostics\n        | where ResourceProvider == \"MICROSOFT.KEYVAULT\"\n        | where OperationName contains \"SecretNearExpiry\"\n        "
          time_aggregation_method = "Count"
          threshold               = 1
          operator                = "GreaterThanOrEqual"
          resource_id_column      = "ResourceId"
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001397"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affairs"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Field Investigation Tool"
      }
    }
    resource_creation_alert_canadacentral = {
      name                              = "Resource-Creation-Alert-canadacentral"
      resource_group_name               = "rg-alerts-fit-nonprod-canadacentral-001"
      location                          = "canadacentral"
      scopes                            = ["/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd"]
      severity                          = 4
      evaluation_frequency              = "PT10M"
      window_duration                   = "PT30M"
      description                       = "Alert when a new resource is created."
      display_name                      = "Resource-Creation-Alert-canadacentral"
      enabled                           = true
      auto_mitigation_enabled           = false
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = null
      target_resource_types             = null
      criteria = [
        {
          query                   = "        AzureActivity\n        | where OperationNameValue has \"Microsoft.Resources/deployments/write\"\n        | where CategoryValue == \"Administrative\"\n        | where ActivityStatusValue == \"Success\"\n        "
          time_aggregation_method = "Count"
          threshold               = 10
          operator                = "GreaterThanOrEqual"
          resource_id_column      = "_ResourceId"
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001397"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affairs"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Field Investigation Tool"
      }
    }
    storage_account_container_deletion_alert_canadacentral = {
      name                              = "Storage-Account-Container-Deletion-Alert-canadacentral"
      resource_group_name               = "rg-alerts-fit-nonprod-canadacentral-001"
      location                          = "canadacentral"
      scopes                            = ["/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd"]
      severity                          = 0
      evaluation_frequency              = "PT5M"
      window_duration                   = "PT30M"
      description                       = "Alert for the deletion of Storage Account Container."
      display_name                      = "Storage-Account-Container-Deletion-Alert-canadacentral"
      enabled                           = true
      auto_mitigation_enabled           = false
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = null
      target_resource_types             = null
      criteria = [
        {
          query                   = "        AzureActivity\n        | where ResourceProviderValue == \"MICROSOFT.STORAGE\" and OperationNameValue == \"MICROSOFT.STORAGE/STORAGEACCOUNTS/BLOBSERVICES/CONTAINERS/DELETE\"\n        "
          time_aggregation_method = "Count"
          threshold               = 1
          operator                = "GreaterThanOrEqual"
          resource_id_column      = "_ResourceId"
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001397"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affairs"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Field Investigation Tool"
      }
    }
    storage_account_deletion_alert_canadacentral = {
      name                              = "Storage-Account-Deletion-Alert-canadacentral"
      resource_group_name               = "rg-alerts-fit-nonprod-canadacentral-001"
      location                          = "canadacentral"
      scopes                            = ["/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd"]
      severity                          = 0
      evaluation_frequency              = "PT5M"
      window_duration                   = "PT30M"
      description                       = "Alert for the deletion of Storage Account."
      display_name                      = "Storage-Account-Deletion-Alert-canadacentral"
      enabled                           = true
      auto_mitigation_enabled           = false
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = null
      target_resource_types             = null
      criteria = [
        {
          query                   = "        AzureActivity\n        | where ResourceProviderValue == \"MICROSOFT.STORAGE\" and OperationNameValue == \"MICROSOFT.STORAGE/STORAGEACCOUNTS/DELETE\"\n        "
          time_aggregation_method = "Count"
          threshold               = 1
          operator                = "GreaterThanOrEqual"
          resource_id_column      = "_ResourceId"
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001397"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affairs"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Field Investigation Tool"
      }
    }
    vm_backup_failure_alert_canadacentral = {
      name                              = "VM-Backup-Failure-Alert-canadacentral"
      resource_group_name               = "rg-mid-fit-app-nonprod-canadacentral-001"
      location                          = "canadacentral"
      scopes                            = ["/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd"]
      severity                          = 1
      evaluation_frequency              = "PT10M"
      window_duration                   = "PT30M"
      description                       = "Alert triggers when there is a VM Backup failure"
      display_name                      = "VM-Backup-Failure-Alert-canadacentral"
      enabled                           = true
      auto_mitigation_enabled           = false
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = null
      target_resource_types             = ["microsoft.compute/virtualmachines"]
      criteria = [
        {
          query                   = "        AzureDiagnostics\n\t\t    | where Category == \"AzureBackupReport\"\n\t\t    | where OperationName == \"Job\"\n\t\t    | where ResultType != \"Success\"\n        \n"
          time_aggregation_method = "Count"
          threshold               = 1
          operator                = "GreaterThanOrEqual"
          resource_id_column      = "_ResourceId"
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/lga-servicenow-integration_group/providers/microsoft.insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001397"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affairs"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Field Investigation Tool"
      }
    }
    vm_free_disk_space_fit_nonprod_alert_canadacentral = {
      name                = "VM-Free-Disk-Space-FIT-Nonprod-Alert-canadacentral"
      resource_group_name = "rg-fit-app-nonprod-canadacentral-001"
      location            = "canadacentral"
      scopes = [
        "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-oracledb-fit-nonprod-canadacentral-001"
      ]
      severity                          = 2
      evaluation_frequency              = "PT5M"
      window_duration                   = "PT5M"
      description                       = "Triggered when disk space has consumed >85%"
      display_name                      = "VM-Free-Disk-Space-FIT-Nonprod-Alert-canadacentral"
      enabled                           = true
      auto_mitigation_enabled           = false
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = "P2D"
      target_resource_types             = ["Microsoft.Compute/virtualMachines"]
      criteria = [
        {
          query                   = "Perf\n| where TimeGenerated > ago(15m)\n| where ObjectName in (\"LogicalDisk\", \"Logical Disk\")\n| where CounterName == \"% Free Space\"\n| where InstanceName == \"_Total\"\n| summarize \n    FreePercent = avg(CounterValue),\n    TimeGenerated = max(TimeGenerated)\n  by Computer\n| extend UsedPercent = round(100 - FreePercent, 2)\n| where UsedPercent >= 85\n| project TimeGenerated, Computer, UsedPercent\n"
          time_aggregation_method = "Count"
          threshold               = 1
          operator                = "GreaterThan"
          resource_id_column      = null
          metric_measure_column   = null
          dimensions = [
            {
              name     = "Computer"
              operator = "Include"
              values   = ["*"]
            }
          ]
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/lga-servicenow-integration_group/providers/microsoft.insights/actionGroups/ ag-servicenow-alerts-canadacentral-001",
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actionGroups/ag-DB-mail-alerts-canadacentral-001",
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actionGroups/ ag-FIT-DB-mail-alerts-canadacentral-002"
      ]
      custom_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001397"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affairs"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Field Investigation Tool"
      }
    }
    vm_heartbeat_lost_alert_canadacentral = {
      name                              = "VM-Heartbeat-Lost-Alert-canadacentral"
      resource_group_name               = "rg-mid-fit-app-nonprod-canadacentral-001"
      location                          = "canadacentral"
      scopes                            = ["/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd"]
      severity                          = 0
      evaluation_frequency              = "PT5M"
      window_duration                   = "PT5M"
      description                       = "This alert will be triggered when VM state is unhealthy for more than 5min"
      display_name                      = "VM-Heartbeat-Lost-Alert-canadacentral"
      enabled                           = true
      auto_mitigation_enabled           = false
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = "P2D"
      target_resource_types             = ["microsoft.compute/virtualmachines"]
      criteria = [
        {
          query                   = "Heartbeat\n| where TimeGenerated > ago(1d)\n| summarize LastHeartbeat = max(TimeGenerated) by _ResourceId, Computer\n| extend TimeSinceLastHeartbeatSeconds = (now() - LastHeartbeat) / 1s\n| extend AgentState = iff(TimeSinceLastHeartbeatSeconds < 300, \"Healthy\", \"Unhealthy\")\n| where AgentState == \"Unhealthy\"\n| project _ResourceId, Computer, LastHeartbeat, TimeSinceLastHeartbeatSeconds, AgentState\n"
          time_aggregation_method = "Count"
          threshold               = 0
          operator                = "GreaterThan"
          resource_id_column      = "_ResourceId"
          metric_measure_column   = null
          dimensions = [
            {
              name     = "Computer"
              operator = "Include"
              values   = ["*"]
            }
          ]
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/lga-servicenow-integration_group/providers/microsoft.insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001397"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affairs"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Field Investigation Tool"
      }
    }
    vm_linux_syslog_fit_nonprod_alert_canadacentral = {
      name                = "VM-Linux-Syslog-FIT-Nonprod-Alert-canadacentral"
      resource_group_name = "rg-mid-fit-app-nonprod-canadacentral-001"
      location            = "canadacentral"
      scopes = [
        "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourcegroups/rg-fit-app-nonprod-canadacentral-001"
      ]
      severity                          = 3
      evaluation_frequency              = "PT10M"
      window_duration                   = "PT30M"
      description                       = "Alert generated when syslog err occurs"
      display_name                      = "VM-Linux-Syslog-FIT-Nonprod-Alert-canadacentral"
      enabled                           = false
      auto_mitigation_enabled           = false
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = null
      target_resource_types             = ["microsoft.compute/virtualmachines"]
      criteria = [
        {
          query                   = "Syslog\n| where SeverityLevel == \"err\"\n"
          time_aggregation_method = "Count"
          threshold               = 1
          operator                = "GreaterThan"
          resource_id_column      = "_ResourceId"
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/lga-servicenow-integration_group/providers/microsoft.insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001397"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affairs"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Field Investigation Tool"
      }
    }
    vm_windows_service_stopped_fit_nonprod_canadacentral = {
      name                = "VM-Windows-Service-Stopped-FIT-Nonprod-canadacentral"
      resource_group_name = "rg-mid-fit-app-nonprod-canadacentral-001"
      location            = "canadacentral"
      scopes = [
        "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourcegroups/rg-fit-app-nonprod-canadacentral-001"
      ]
      severity                          = 1
      evaluation_frequency              = "PT5M"
      window_duration                   = "PT5M"
      description                       = "Triggered when windows services are stopped"
      display_name                      = "VM-Windows-Service-Stopped-FIT-Nonprod-canadacentral"
      enabled                           = true
      auto_mitigation_enabled           = false
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = null
      target_resource_types             = ["microsoft.compute/virtualmachines"]
      criteria = [
        {
          query                   = "Perf\n| where ObjectName == \"Service\"\n| where CounterName == \"Service State\"\n| extend ServiceState = iff(CounterValue == 4, \"Running\", \"Stopped\")\n| where ServiceState == \"Stopped\"\n//| extend _ResourceId = strcat(\"/subscriptions/<SUB-ID>/resourceGroups/<RG-NAME>/providers/Microsoft.Compute/virtualMachines/\", Computer)\n| project TimeGenerated, Computer, InstanceName, ServiceState, _ResourceId\n"
          time_aggregation_method = "Count"
          threshold               = 1
          operator                = "GreaterThan"
          resource_id_column      = null
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001",
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ ag-fit-db-mail-alerts-canadacentral-002",
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-db-mail-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001397"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affairs"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Field Investigation Tool"
      }
    }
  }
  alert_processing_rules = {
    alert_suppression_fit_nonprod_app = {
      name                = "alert-suppression-FIT-NonProd-APP"
      resource_group_name = "rg-fit-app-nonprod-canadacentral-001"
      scopes              = ["/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd"]
      type                = "suppression"
      description         = null
      enabled             = false
      action_group_ids    = []
      conditions          = {}
      schedule = {
        effective_from  = "2026-06-24T13:30:00"
        effective_until = "2026-06-24T19:00:00"
        time_zone       = "Eastern Standard Time"
        recurrence      = null
      }
      tags = {
        ApplicationId           = "BCH – LIX -0000001397"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affairs"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Field Investigation Tool"
      }
    }
    vm_fit_nonprodalertsuppress = {
      name                = "VM-FIT-NonProdAlertSuppress"
      resource_group_name = "rg-alerts-fit-nonprod-canadacentral-001"
      scopes              = ["/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd"]
      type                = "suppression"
      description         = null
      enabled             = false
      action_group_ids    = []
      conditions          = {}
      schedule = {
        effective_from  = "2026-03-11T12:00:00"
        effective_until = "2026-03-11T16:00:00"
        time_zone       = "Eastern Standard Time"
        recurrence      = null
      }
      tags = {
        ApplicationId           = "BCH – LIX -0000001397"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affairs"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Field Investigation Tool"
      }
    }
  }
}

activity_log_alert_imports = {
  key_vault_deletion = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-alerts-fit-nonprod-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/KeyVault-Deletion-Alert-canadacentral"
  service_outage     = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-alerts-fit-nonprod-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/Service-Outage-Alert-canadacentral"
  app_create_update  = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-alerts-fit-nonprod-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/app-fit-nonprod-create-update"
  app_delete         = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-alerts-fit-nonprod-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/app-fit-nonprod-delete"
  app_restart        = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-alerts-fit-nonprod-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/app-fit-nonprod-restart"
  app_stop           = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-alerts-fit-nonprod-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/app-fit-nonprod-stop"
}

metric_alert_imports = {
  app_fit_connections_warning                    = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-alerts-fit-nonprod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/app-fit-connections-warning"
  app_fit_http_404_informational                 = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-alerts-fit-nonprod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/app-fit-http-404-informational"
  app_health_alert_canadacentral                 = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/App-Health-Alert-canadacentral"
  app_high_cpu_alert_canadacentral               = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/App-High-CPU-Alert-canadacentral"
  app_high_response_time_alert_canadcentral      = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/App-High-Response-Time-Alert-canadcentral"
  app_http_alert_canadacentral                   = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/App-HTTP-Alert-canadacentral"
  backup_alert                                   = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/Backup Alert"
  oracle_vm_fit_nonprod_memory_high_warning      = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-mid-fit-app-nonprod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/oracle-vm-fit-nonprod-memory-high-warning"
  oracle_vm_nonprod_high_cpu_alert_canadacentral = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-mid-fit-app-nonprod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/Oracle-VM-NonProd-High-CPU-Alert-canadacentral"
  restore_job_failed_fit_nonprod_canadacentral   = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-mid-fit-app-nonprod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/Restore-Job-Failed-FIT-Nonprod-canadacentral"
  vm_fit_nonprod_cpu_high_warning                = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-alerts-fit-nonprod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/vm-fit-nonprod-cpu-high-warning"
  vm_fit_nonprod_memory_high_warning             = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-alerts-fit-nonprod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/vm-fit-nonprod-memory-high-warning"
  vm_os_disk_iops_alert_canadacentral            = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-mid-fit-app-nonprod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/VM-OS-Disk-IOPS-Alert-canadacentral"
}

log_search_alert_imports = {
  keyvault_secret_expired_alert_canadacentral            = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-alerts-fit-nonprod-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/KeyVault-Secret-Expired-Alert-canadacentral"
  keyvault_secret_near_expiry_alert_canadacentral        = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-alerts-fit-nonprod-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/KeyVault-Secret-Near-Expiry-Alert-canadacentral"
  resource_creation_alert_canadacentral                  = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-alerts-fit-nonprod-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/Resource-Creation-Alert-canadacentral"
  storage_account_container_deletion_alert_canadacentral = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-alerts-fit-nonprod-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/Storage-Account-Container-Deletion-Alert-canadacentral"
  storage_account_deletion_alert_canadacentral           = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-alerts-fit-nonprod-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/Storage-Account-Deletion-Alert-canadacentral"
  vm_backup_failure_alert_canadacentral                  = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-mid-fit-app-nonprod-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/VM-Backup-Failure-Alert-canadacentral"
  vm_free_disk_space_fit_nonprod_alert_canadacentral     = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/VM-Free-Disk-Space-FIT-Nonprod-Alert-canadacentral"
  vm_heartbeat_lost_alert_canadacentral                  = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-mid-fit-app-nonprod-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/VM-Heartbeat-Lost-Alert-canadacentral"
  vm_linux_syslog_fit_nonprod_alert_canadacentral        = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-mid-fit-app-nonprod-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/VM-Linux-Syslog-FIT-Nonprod-Alert-canadacentral"
  vm_windows_service_stopped_fit_nonprod_canadacentral   = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-mid-fit-app-nonprod-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/VM-Windows-Service-Stopped-FIT-Nonprod-canadacentral"
}

# Not managed here:
#   actionrules 'alert-supporession for non-prod-fit APPs' (rg-fit-app-nonprod-canadacentral-PAM-POC): azurerm rejects processing rule names with spaces; rename it in Azure to manage it
#   actionrules 'alert-suppression for Non-prod FIT app' (rg-alerts-fit-nonprod-canadacentral-001): azurerm rejects processing rule names with spaces; rename it in Azure to manage it
#   scheduledqueryrules 'VM-Patching-Failed-FIT-Nonprod-canadacentral' (rg-fit-app-nonprod-canadacentral-001): SystemAssigned identity (the wrapper has no identity input)
#   scheduledqueryrules 'VM-Pending-Update-FIT-NonProd-canadacentral' (rg-fit-app-nonprod-canadacentral-001): SystemAssigned identity (the wrapper has no identity input)
alert_processing_rule_imports = {
  alert_suppression_fit_nonprod_app = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.AlertsManagement/actionRules/alert-suppression-FIT-NonProd-APP"
  vm_fit_nonprodalertsuppress       = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-alerts-fit-nonprod-canadacentral-001/providers/Microsoft.AlertsManagement/actionRules/VM-FIT-NonProdAlertSuppress"
}

# zone_redundancy_enabled and the subnet force replacement; both match the export.
# The export reports dedicatedHostCount = 0; the wrapper only accepts null or 2.
app_service_environment = {
  app = {
    name                                   = "ase-fit-nonprod-canadacentral-001"
    resource_group_key                     = "app"
    location                               = "canadacentral"
    subnet_id                              = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-nonprod-canadacentral-001/subnets/snet-fit-nonprod-app-canadacentral-001"
    internal_load_balancing_mode           = "Web, Publishing"
    zone_redundancy_enabled                = false
    internal_encryption_enabled            = false
    ftp_enabled                            = false
    remote_debug_enabled                   = true
    allow_new_private_endpoint_connections = true
    tls_1_enabled                          = true # clusterSettings is empty, so DisableTls1.0 is not set
    inbound_ip_address_override            = "10.195.80.4"
    upgrade_preference                     = "None"
    dedicated_host_count                   = null
    system_assigned_identity               = true
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Field Investigation Tool"
    }
  }
}

app_service_environment_imports = {
  app = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Web/hostingEnvironments/ase-fit-nonprod-canadacentral-001"
}

app_service_plan = {
  app = {
    name                            = "asp-fit-nonprod-canadacentral-002"
    resource_group_key              = "app"
    location                        = "canadacentral"
    os_type                         = "Windows"
    sku_name                        = "I1v2"
    worker_count                    = 1
    maximum_elastic_worker_count    = 1
    per_site_scaling_enabled        = false
    premium_plan_auto_scale_enabled = false
    zone_balancing_enabled          = false
    app_service_environment_id      = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Web/hostingEnvironments/ase-fit-nonprod-canadacentral-001"
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Field Investigation Tool"
    }
  }
}

app_service_plan_imports = {
  app = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Web/serverFarms/asp-fit-nonprod-canadacentral-002"
}

# Sends to the central SIEM workspace. The daily cap is not in the export (100 is
# the provider default); confirm with az monitor app-insights component billing show.
application_insights = {
  func = {
    name                          = "ai-func-fit-nonprod-canadacentral-001"
    resource_group_key            = "app"
    location                      = "canadacentral"
    workspace_id                  = "/subscriptions/7d54d6f7-83d9-48cf-ac35-1068bcfd0561/resourceGroups/rg-siem-security-canadacentral-001/providers/Microsoft.OperationalInsights/workspaces/la-siem-security-canadacentral-001"
    application_type              = "web"
    retention_in_days             = 90
    daily_data_cap_in_gb          = 100
    sampling_percentage           = null
    internet_ingestion_enabled    = true
    internet_query_enabled        = true
    local_authentication_disabled = false
    disable_ip_masking            = false
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Field Investigation Tool"
    }
  }
}

application_insights_imports = {
  func = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Insights/components/ai-func-fit-nonprod-canadacentral-001"
}

bastion_host = {
  app = {
    name               = "bh-fit-nonprod-canadacentral-001"
    resource_group_key = "app"
    location           = "canadacentral"
    sku                = "Developer"
    scale_units        = 2
    virtual_network_id = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-nonprod-canadacentral-001"
    zones              = []
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Field Investigation Tool"
    }
  }
}

bastion_host_imports = {
  app = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/bastionHosts/bh-fit-nonprod-canadacentral-001"
}

key_vault = {
  app = {
    name                            = "kvfitcanadacentral"
    resource_group_key              = "app"
    location                        = "canadacentral"
    tenant_id                       = "8fbb85e8-0cbc-48c3-a2e9-528cef30ec27"
    sku_name                        = "premium"
    enabled_for_deployment          = true
    enabled_for_disk_encryption     = true
    enabled_for_template_deployment = true
    legacy_access_policies_enabled  = false
    public_network_access_enabled   = true
    purge_protection_enabled        = true
    soft_delete_retention_days      = 90
    network_acls = {
      bypass                     = "AzureServices"
      default_action             = "Deny"
      ip_rules                   = ["155.190.0.11/32", "155.190.0.9/32"]
      virtual_network_subnet_ids = []
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Field Investigation Tool"
    }
  }
}

key_vault_imports = {
  app = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvfitcanadacentral"
}

# RedHat/RHEL/810-gen2 is grandfathered in wrapper 0.0.7. The five data disks
# and their attachments stay unmanaged. The PAM-POC VM was
# built on attached disks (no OS profile), which azurerm_linux_virtual_machine
# cannot represent, so it stays out.
linux_virtual_machine = {
  oracledb = {
    name               = "vm-oracledb-fit-nonprod-canadacentral-001"
    resource_group_key = "app"
    location           = "canadacentral"
    size               = "Standard_D8s_v5"
    zone               = "1"
    admin_username     = "azoracledbuser"
    admin_ssh_public_keys = [
      "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQDG2iyIcCslJiemdRUA9V1XYSJu3qpAro887+fWPqfymHbixlNai4pYf8gELqmAQvThUojx2RVb+8T3N/JLp8cmj7FKX7/6T/84C/3wOb1r75g1wMUkGU7+VnnYLvuiIB9Vobi+pgnT8Zvz0RSUZTc99obsavW5n+bunln3+AcW/mBvFQg6HvffFn7GNMCIledl6G+9UK9Re4xMbALv/h49PdcC4RwfqBhBvD2y0pQX0Q2GulfNDQsMF93LMk0MO+O8y6juDGV0F/ivWBUvaRkJreZqA8Br+Xw/2bX8esSgjCcshTEbxiYh8xfhbEpdhVK9F6MBJUg4tYYkSx5lzyp4x16yoR6BE+MhZsuCmobTxsqGUXjw/5eCwDjOVmAxu7pn13SbWW7N2O8M+GEdcVaTcD5gYjyjLWhDD/hmUUQSE3bwO7xpxze/I4Oq6wowqfQ0Njw+wA9HRigVrgEIuWOT76ipS2zh01o35h9Ue5FKog636trDa0EqWzhuJflbdF0= generated-by-azure"
    ]
    computer_name = "vm-oracledb-fit-nonprod-canadacentral-001"
    network_interface_ids = [
      "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkInterfaces/vm-oracledb-fit-nonprod-canadacentral-001746_z1"
    ]
    os_managed_disk_id                                     = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Compute/disks/vmoracledbfitnonprodcanadacent-osdisk-20251219-154408"
    allow_extension_operations                             = true
    bypass_platform_safety_checks_on_user_schedule_enabled = true
    disk_controller_type                                   = "SCSI"
    encryption_at_host_enabled                             = false
    license_type                                           = "RHEL_BYOS"
    patch_assessment_mode                                  = "AutomaticByPlatform"
    patch_mode                                             = "AutomaticByPlatform"
    provision_vm_agent                                     = true
    secure_boot_enabled                                    = true
    vtpm_enabled                                           = true
    additional_capabilities = {
      hibernation_enabled = false
    }
    boot_diagnostics = {}
    identity = {
      type                       = "SystemAssigned"
      user_assigned_identity_ids = []
    }
    os_disk = {
      name                 = "vmoracledbfitnonprodcanadacent-osdisk-20251219-154408"
      caching              = "ReadWrite"
      disk_size_gb         = 64
      storage_account_type = "Premium_LRS"
    }
    source_image_reference = {
      publisher = "RedHat"
      offer     = "RHEL"
      sku       = "810-gen2"
      version   = "latest"
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Field Investigation Tool"
    }
  }
}

linux_virtual_machine_imports = {
  oracledb = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-oracledb-fit-nonprod-canadacentral-001"
}

network_interface = {
  oracledb_primary = {
    name                           = "vm-oracledb-fit-nonprod-canadacentral-001746_z1"
    resource_group_key             = "app"
    location                       = "canadacentral"
    enabled                        = true
    accelerated_networking_enabled = true
    ip_forwarding_enabled          = false
    ip_configurations = {
      primary = {
        name                          = "ipconfig1"
        primary                       = true
        private_ip_address            = "10.195.81.4"
        private_ip_address_allocation = "Dynamic"
        subnet_id                     = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-nonprod-canadacentral-001/subnets/snet-fit-nonprod-oracle-canadacentral-001"
      }
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Field Investigation Tool"
    }
  }
}

# No NIC-level NSGs; the NSGs are attached to subnets.
network_interface_nsg_associations = {}

# Protocols are normalised to the wrapper's casing (Tcp/Icmp); Azure reports
# them upper case, which may show as a case-only update on import.
network_security_group = {
  app = {
    name               = "nsg-fit-nonprod-app-canadacentral-001"
    resource_group_key = "app"
    location           = "canadacentral"
    security_rules = {
      allowonprem = {
        name                       = "AllowOnPrem"
        access                     = "Allow"
        direction                  = "Inbound"
        priority                   = 200
        protocol                   = "*"
        source_port_range          = "*"
        destination_port_range     = "*"
        source_address_prefixes    = ["10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "142.52.0.0/16"]
        destination_address_prefix = "*"
      }
      allowhostedrunners = {
        name                       = "AllowHostedRunners"
        access                     = "Allow"
        direction                  = "Inbound"
        priority                   = 105
        protocol                   = "*"
        source_port_range          = "*"
        destination_port_ranges    = ["80", "443", "4022", "4024", "4026", "8172"]
        source_address_prefixes    = ["10.195.114.7", "10.195.115.7"]
        destination_address_prefix = "10.195.80.0/24"
      }
      allowinternalhealthping = {
        name                       = "AllowInternalHealthPing"
        access                     = "Allow"
        direction                  = "Inbound"
        priority                   = 106
        protocol                   = "Tcp"
        source_port_range          = "*"
        destination_port_range     = "80"
        source_address_prefix      = "AzureLoadBalancer"
        destination_address_prefix = "10.195.80.0/24"
      }
      denyall_inbound = {
        name                       = "DenyAll-Inbound"
        access                     = "Deny"
        direction                  = "Inbound"
        priority                   = 1000
        protocol                   = "*"
        source_port_range          = "*"
        destination_port_range     = "*"
        source_address_prefix      = "*"
        destination_address_prefix = "*"
      }
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Field Investigation Tool"
    }
  }
  oracle = {
    name               = "nsg-fit-nonprod-oracle-canadacentral-001"
    resource_group_key = "app"
    location           = "canadacentral"
    security_rules = {
      allowbastionhost = {
        name                       = "AllowBastionHost"
        access                     = "Allow"
        direction                  = "Inbound"
        priority                   = 1001
        protocol                   = "Tcp"
        source_port_range          = "*"
        destination_port_ranges    = ["22", "3389"]
        source_address_prefix      = "168.63.129.16"
        destination_address_prefix = "*"
      }
      allowonprem = {
        name                       = "AllowOnPrem"
        access                     = "Allow"
        direction                  = "Inbound"
        priority                   = 1000
        protocol                   = "*"
        source_port_range          = "*"
        destination_port_range     = "*"
        source_address_prefixes    = ["10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "142.52.0.0/16"]
        destination_address_prefix = "*"
      }
      blockprodrunnerping = {
        name                       = "BlockProdRunnerPing"
        access                     = "Deny"
        direction                  = "Inbound"
        priority                   = 130
        protocol                   = "Icmp"
        source_port_range          = "*"
        destination_port_range     = "*"
        source_address_prefix      = "10.195.115.7"
        destination_address_prefix = "*"
      }
      cyberark_ssh = {
        name                       = "Cyberark-ssh"
        access                     = "Allow"
        direction                  = "Inbound"
        priority                   = 1011
        protocol                   = "Tcp"
        source_port_range          = "22"
        destination_port_range     = "22"
        source_address_prefixes    = ["10.195.116.4", "10.195.116.5"]
        destination_address_prefix = "10.195.81.4"
      }
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Field Investigation Tool"
    }
  }
  pep = {
    name               = "nsg-fit-nonprod-pep-canadacentral-001"
    resource_group_key = "app"
    location           = "canadacentral"
    security_rules = {
      allowonprem = {
        name                       = "AllowOnPrem"
        access                     = "Allow"
        direction                  = "Inbound"
        priority                   = 200
        protocol                   = "*"
        source_port_range          = "*"
        destination_port_range     = "*"
        source_address_prefixes    = ["10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "142.52.0.0/16"]
        destination_address_prefix = "*"
      }
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Field Investigation Tool"
    }
  }
}

import_network_security_group = {
  app    = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-fit-nonprod-app-canadacentral-001"
  oracle = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-fit-nonprod-oracle-canadacentral-001"
  pep    = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-fit-nonprod-pep-canadacentral-001"
}

network_security_rule_imports = {
  "app/allowonprem" = {
    nsg_key  = "app"
    rule_key = "allowonprem"
    id       = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-fit-nonprod-app-canadacentral-001/securityRules/AllowOnPrem"
  }
  "app/allowhostedrunners" = {
    nsg_key  = "app"
    rule_key = "allowhostedrunners"
    id       = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-fit-nonprod-app-canadacentral-001/securityRules/AllowHostedRunners"
  }
  "app/allowinternalhealthping" = {
    nsg_key  = "app"
    rule_key = "allowinternalhealthping"
    id       = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-fit-nonprod-app-canadacentral-001/securityRules/AllowInternalHealthPing"
  }
  "app/denyall_inbound" = {
    nsg_key  = "app"
    rule_key = "denyall_inbound"
    id       = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-fit-nonprod-app-canadacentral-001/securityRules/DenyAll-Inbound"
  }
  "oracle/allowbastionhost" = {
    nsg_key  = "oracle"
    rule_key = "allowbastionhost"
    id       = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-fit-nonprod-oracle-canadacentral-001/securityRules/AllowBastionHost"
  }
  "oracle/allowonprem" = {
    nsg_key  = "oracle"
    rule_key = "allowonprem"
    id       = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-fit-nonprod-oracle-canadacentral-001/securityRules/AllowOnPrem"
  }
  "oracle/blockprodrunnerping" = {
    nsg_key  = "oracle"
    rule_key = "blockprodrunnerping"
    id       = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-fit-nonprod-oracle-canadacentral-001/securityRules/BlockProdRunnerPing"
  }
  "oracle/cyberark_ssh" = {
    nsg_key  = "oracle"
    rule_key = "cyberark_ssh"
    id       = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-fit-nonprod-oracle-canadacentral-001/securityRules/Cyberark-ssh"
  }
  "pep/allowonprem" = {
    nsg_key  = "pep"
    rule_key = "allowonprem"
    id       = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-fit-nonprod-pep-canadacentral-001/securityRules/AllowOnPrem"
  }
}

# Its VNet flow log stays unmanaged.
network_watcher = {
  canadacentral = {
    name               = "NetworkWatcher_canadacentral_fit_app_nonprod"
    resource_group_key = "shared_app"
    location           = "canadacentral"
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Field Investigation Tool"
    }
  }
}

network_watcher_imports = {
  canadacentral = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-shared-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkWatchers/NetworkWatcher_canadacentral_fit_app_nonprod"
}

# Link names keep the casing from the resource ID. The ASE's record sets stay unmanaged.
private_dns_zone = {
  ase = {
    name               = "ase-fit-nonprod-canadacentral-001.appserviceenvironment.net"
    resource_group_key = "app"
    virtual_network_links = {
      link_dns_connectivity_canadacentral_001 = {
        name                 = "link-dns-connectivity-canadacentral-001"
        virtual_network_id   = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dns-connectivity-canadacentral-001"
        registration_enabled = false
        resolution_policy    = "Default"
        tags = {
          ApplicationId           = "BCH – LIX -0000001397"
          ApplicationServiceLevel = "Silver"
          BusinessUnit            = "Customer & Corporate Affairs"
          CostCenterId            = "YT-01585.S.IMP.CLZ"
          Environment             = "NonProd"
          Name                    = "Field Investigation Tool"
        }
      }
      link_runners_connectivity_canadacentral_001 = {
        name                 = "link-runners-connectivity-canadacentral-001"
        virtual_network_id   = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-runners-connectivity-canadacentral-001"
        registration_enabled = false
        resolution_policy    = "Default"
        tags = {
          ApplicationId           = "BCH – LIX -0000001397"
          ApplicationServiceLevel = "Silver"
          BusinessUnit            = "Customer & Corporate Affairs"
          CostCenterId            = "YT-01585.S.IMP.CLZ"
          Environment             = "NonProd"
          Name                    = "Field Investigation Tool"
        }
      }
      vnetlink = {
        name                 = "vnetLink"
        virtual_network_id   = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-nonprod-canadacentral-001"
        registration_enabled = false
        resolution_policy    = "Default"
        tags = {
          ApplicationId           = "BCH – LIX -0000001397"
          ApplicationServiceLevel = "Silver"
          BusinessUnit            = "Customer & Corporate Affairs"
          CostCenterId            = "YT-01585.S.IMP.CLZ"
          Environment             = "NonProd"
          Name                    = "Field Investigation Tool"
        }
      }
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Field Investigation Tool"
    }
  }
}

private_dns_zone_imports = {
  ase = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/privateDnsZones/ase-fit-nonprod-canadacentral-001.appserviceenvironment.net"
}

private_dns_zone_link_imports = {
  "ase/link_dns_connectivity_canadacentral_001" = {
    zone_key = "ase"
    link_key = "link_dns_connectivity_canadacentral_001"
    id       = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/privateDnsZones/ase-fit-nonprod-canadacentral-001.appserviceenvironment.net/virtualNetworkLinks/link-dns-connectivity-canadacentral-001"
  }
  "ase/link_runners_connectivity_canadacentral_001" = {
    zone_key = "ase"
    link_key = "link_runners_connectivity_canadacentral_001"
    id       = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/privateDnsZones/ase-fit-nonprod-canadacentral-001.appserviceenvironment.net/virtualNetworkLinks/link-runners-connectivity-canadacentral-001"
  }
  "ase/vnetlink" = {
    zone_key = "ase"
    link_key = "vnetlink"
    id       = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/privateDnsZones/ase-fit-nonprod-canadacentral-001.appserviceenvironment.net/virtualNetworkLinks/vnetLink"
  }
}

private_endpoint = {
  web_app = {
    name                            = "pep-fit-nonprod-canadacentral"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-nonprod-canadacentral-001/subnets/snet-fit-nonprod-pep-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Web/sites/app-fit-dev"
    private_service_connection_name = "pep-fit-nonprod-canadacentral"
    subresource_names               = ["sites"]
    network_interface_name          = "pep-fit-nonprod-canadacentral-nic"
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/privateDnsZones/ase-fit-nonprod-canadacentral-001.appserviceenvironment.net"
    ]
    ip_configurations = {
      pep_fit_nonprod_canadacentral_001 = {
        name               = "pep-fit-nonprod-canadacentral-001"
        private_ip_address = "10.195.82.6"
        subresource_name   = "sites"
        member_name        = "sites"
      }
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Field Investigation Tool"
    }
  }
  key_vault = {
    name                            = "pep-kv-fit-nonprod-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-nonprod-canadacentral-001/subnets/snet-fit-nonprod-pep-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvfitcanadacentral"
    private_service_connection_name = "pep-kv-fit-nonprod-canadacentral-001"
    subresource_names               = ["vault"]
    network_interface_name          = "pep-kv-fit-nonprod-canadacentral-001-nic"
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.vaultcore.azure.net"
    ]
    ip_configurations = {
      pep_kv_fit_nonprod_canadacentral_001 = {
        name               = "pep-kv-fit-nonprod-canadacentral-001"
        private_ip_address = "10.195.82.5"
        subresource_name   = "vault"
        member_name        = "default"
      }
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Field Investigation Tool"
    }
  }
  backup = {
    name                            = "pep-rsv-fit-backup-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-nonprod-canadacentral-001/subnets/snet-fit-nonprod-pep-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourcegroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.RecoveryServices/vaults/rsv-fit-canadacentral-001"
    private_service_connection_name = "pep-rsv-fit-backup-canadacentral-001_b45d1e79-497e-4b2f-8cab-fb155362206a"
    subresource_names               = ["AzureBackup"]
    network_interface_name          = null
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.cnc.backup.windowsazure.com",
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.queue.core.windows.net",
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net"
    ]
    ip_configurations = {}
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Field Investigation Tool"
    }
  }
}

private_endpoint_imports = {
  web_app   = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-fit-nonprod-canadacentral"
  key_vault = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-kv-fit-nonprod-canadacentral-001"
  backup    = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-rsv-fit-backup-canadacentral-001"
}

# Created by the platform (Defender/AMA default workspace).
log_analytics_workspace = {
  default_ccan = {
    name                            = "DefaultWorkspace-fa089a5b-f881-41a6-a30f-58bfdfd52abd-CCAN"
    resource_group_key              = "defaultresourcegroup_ccan"
    location                        = "canadacentral"
    sku                             = "PerGB2018"
    retention_in_days               = 30
    daily_quota_gb                  = -1
    internet_ingestion_enabled      = "true"
    internet_query_enabled          = "true"
    local_authentication_enabled    = true
    allow_resource_only_permissions = true
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Field Investigation Tool"
    }
  }
}

log_analytics_workspace_imports = {
  default_ccan = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/DefaultResourceGroup-CCAN/providers/Microsoft.OperationalInsights/workspaces/DefaultWorkspace-fa089a5b-f881-41a6-a30f-58bfdfd52abd-CCAN"
}

# Managed with azurerm_ssh_public_key directly; the AVM module rejects hyphens.
public_ssh_key = {
  oracle = {
    name               = "sshkey-oracle-fit-nonprod-canadacentral-001"
    resource_group_key = "app"
    location           = "canadacentral"
    public_key         = "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQDG2iyIcCslJiemdRUA9V1XYSJu3qpAro887+fWPqfymHbixlNai4pYf8gELqmAQvThUojx2RVb+8T3N/JLp8cmj7FKX7/6T/84C/3wOb1r75g1wMUkGU7+VnnYLvuiIB9Vobi+pgnT8Zvz0RSUZTc99obsavW5n+bunln3+AcW/mBvFQg6HvffFn7GNMCIledl6G+9UK9Re4xMbALv/h49PdcC4RwfqBhBvD2y0pQX0Q2GulfNDQsMF93LMk0MO+O8y6juDGV0F/ivWBUvaRkJreZqA8Br+Xw/2bX8esSgjCcshTEbxiYh8xfhbEpdhVK9F6MBJUg4tYYkSx5lzyp4x16yoR6BE+MhZsuCmobTxsqGUXjw/5eCwDjOVmAxu7pn13SbWW7N2O8M+GEdcVaTcD5gYjyjLWhDD/hmUUQSE3bwO7xpxze/I4Oq6wowqfQ0Njw+wA9HRigVrgEIuWOT76ipS2zh01o35h9Ue5FKog636trDa0EqWzhuJflbdF0= generated-by-azure"
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Field Investigation Tool"
    }
  }
}

public_ssh_key_imports = {
  oracle = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Compute/sshPublicKeys/sshkey-oracle-fit-nonprod-canadacentral-001"
}

# monitoringSettings is null on the live vault; alert flags default to false
# so adoption does not switch alerting on.
recovery_services_vault = {
  app = {
    name                          = "rsv-fit-canadacentral-001"
    resource_group_key            = "app"
    location                      = "canadacentral"
    sku                           = "RS0"
    storage_mode_type             = "GeoRedundant"
    cross_region_restore_enabled  = true
    soft_delete_enabled           = true
    immutability                  = "Unlocked"
    public_network_access_enabled = false
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Field Investigation Tool"
    }
  }
}

recovery_services_vault_imports = {
  app = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.RecoveryServices/vaults/rsv-fit-canadacentral-001"
}

# Azure Backup owns these; only the containers are adopted.
restore_point_collection = {
  oracledb = {
    name                      = "AzureBackup_vm-oracledb-fit-nonprod-canadacentral-001_6310633794653116661"
    resource_group_name       = "AzureBackupRG_canadacentral_1"
    location                  = "canadacentral"
    source_virtual_machine_id = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-oracledb-fit-nonprod-canadacentral-001"
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Field Investigation Tool"
    }
  }
  oracledb_pam_poc = {
    name                      = "AzureBackup_vm-oracledb-fit-nonprod-canadacentral-PAM-POC_6310633793615399339"
    resource_group_name       = "AzureBackupRG_canadacentral_1"
    location                  = "canadacentral"
    source_virtual_machine_id = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-PAM-POC/providers/Microsoft.Compute/virtualMachines/vm-oracledb-fit-nonprod-canadacentral-PAM-POC-001"
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Field Investigation Tool"
    }
  }
}

restore_point_collection_imports = {
  oracledb         = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/AzureBackupRG_canadacentral_1/providers/Microsoft.Compute/restorePointCollections/AzureBackup_vm-oracledb-fit-nonprod-canadacentral-001_6310633794653116661"
  oracledb_pam_poc = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/AzureBackupRG_canadacentral_1/providers/Microsoft.Compute/restorePointCollections/AzureBackup_vm-oracledb-fit-nonprod-canadacentral-PAM-POC_6310633793615399339"
}

storage_account = {}

# Public network access is enabled on these, and Deny_Public_Access_On_PaaS_Services_v0
# denies any write to them, so they are read, not adopted, until exempted.
storage_account_existing = {
  app = {
    name               = "stfitnprdcanadacentral1"
    resource_group_key = "app"
  }
  network_watcher = {
    name               = "stnwfitnpcanadacentral"
    resource_group_key = "shared_app"
  }
}

storage_account_imports = {}

event_grid_system_topic = {
  app_storage = {
    name                        = "stfitnprdcanadacentral1-1b93157f-4e0a-4f24-bcac-f294be62c0bf"
    resource_group_key          = "app"
    location                    = "canadacentral"
    topic_type                  = "microsoft.storage.storageaccounts"
    source_resource_id          = null
    exported_source_resource_id = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/microsoft.storage/storageaccounts/stfitnprdcanadacentral1"
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Field Investigation Tool"
    }
  }
  network_watcher_storage = {
    name                        = "stnwfitnpcanadacentral-00f92de2-6faf-4ec2-bcf5-0183aad325dc"
    resource_group_key          = "shared_app"
    location                    = "canadacentral"
    topic_type                  = "microsoft.storage.storageaccounts"
    source_resource_id          = null
    exported_source_resource_id = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-shared-fit-app-nonprod-canadacentral-001/providers/microsoft.storage/storageaccounts/stnwfitnpcanadacentral"
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Field Investigation Tool"
    }
  }
}

event_grid_system_topic_imports = {
  app_storage             = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.EventGrid/systemTopics/stfitnprdcanadacentral1-1b93157f-4e0a-4f24-bcac-f294be62c0bf"
  network_watcher_storage = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-shared-fit-app-nonprod-canadacentral-001/providers/Microsoft.EventGrid/systemTopics/stnwfitnpcanadacentral-00f92de2-6faf-4ec2-bcf5-0183aad325dc"
}

# Used by the web app (not managed here).
user_assigned_identity = {
  app = {
    name               = "mid-fit-nonprod-canadacentral-001"
    resource_group_key = "mid_app"
    location           = "canadacentral"
    isolation_scope    = null
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Field Investigation Tool"
    }
  }
}

user_assigned_identity_imports = {
  app = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-mid-fit-app-nonprod-canadacentral-001/providers/Microsoft.ManagedIdentity/userAssignedIdentities/mid-fit-nonprod-canadacentral-001"
}

# Disabled for now, as in Fabric: the VNet module's body omits subnets and
# peerings, so the import plan removes them, and the only peering is the vWAN
# hub connection owned by tf-deploy-platform-connectivity. Adopt it with the
# connectivity team on hand to restore the hub connection.
# defaultOutboundAccess is not reported for any subnet, which means Azure's
# default (enabled). It is create-time only, so a replace in the plan means
# this guess is wrong. The hub peering stays unmanaged.
virtual_network = {
  app = {
    name               = "vnet-fit-nonprod-canadacentral-001"
    resource_group_key = "app"
    location           = "canadacentral"
    address_space      = ["10.195.80.0/22"]
    dns_servers = {
      dns_servers = ["10.195.4.7"]
    }
    ddos_protection_plan = {
      enable = true
      id     = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/ddosProtectionPlans/ddos-protection-plan"
    }
    subnets = {
      oracle = {
        name                                          = "snet-fit-nonprod-oracle-canadacentral-001"
        address_prefixes                              = ["10.195.81.0/24"]
        default_outbound_access_enabled               = true
        private_endpoint_network_policies             = "Disabled"
        private_link_service_network_policies_enabled = true
        network_security_group = {
          id = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-fit-nonprod-oracle-canadacentral-001"
        }
        service_endpoint_policies       = {}
        service_endpoints_with_location = []
        delegations                     = []
      }
      app = {
        name                                          = "snet-fit-nonprod-app-canadacentral-001"
        address_prefixes                              = ["10.195.80.0/24"]
        default_outbound_access_enabled               = true
        private_endpoint_network_policies             = "Disabled"
        private_link_service_network_policies_enabled = true
        network_security_group = {
          id = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-fit-nonprod-app-canadacentral-001"
        }
        service_endpoint_policies       = {}
        service_endpoints_with_location = []
        delegations = [
          {
            name = "app-fit-nonprod-canadacentral-001-delegation"
            service_delegation = {
              name    = "Microsoft.Web/hostingEnvironments"
              actions = ["Microsoft.Network/virtualNetworks/subnets/action"]
            }
          }
        ]
      }
      pep = {
        name                                          = "snet-fit-nonprod-pep-canadacentral-001"
        address_prefixes                              = ["10.195.82.0/23"]
        default_outbound_access_enabled               = true
        private_endpoint_network_policies             = "RouteTableEnabled"
        private_link_service_network_policies_enabled = true
        network_security_group = {
          id = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-fit-nonprod-pep-canadacentral-001"
        }
        service_endpoint_policies       = {}
        service_endpoints_with_location = []
        delegations                     = []
      }
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Field Investigation Tool"
    }
  }
}

virtual_network_imports = {
  app = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-nonprod-canadacentral-001"
}

virtual_network_subnet_imports = {
  fit_oracle = {
    vnet_key   = "app"
    subnet_key = "oracle"
    id         = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-nonprod-canadacentral-001/subnets/snet-fit-nonprod-oracle-canadacentral-001"
  }
  fit_app = {
    vnet_key   = "app"
    subnet_key = "app"
    id         = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-nonprod-canadacentral-001/subnets/snet-fit-nonprod-app-canadacentral-001"
  }
  fit_pep = {
    vnet_key   = "app"
    subnet_key = "pep"
    id         = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-nonprod-canadacentral-001/subnets/snet-fit-nonprod-pep-canadacentral-001"
  }
}

# Disabled until the secret settings below are moved to Key Vault references or
# supplied through web_app_secret_app_settings / web_app_secret_connection_strings.
# The module rewrites the full app settings list on apply, so it must stay complete.
# The implicit 'Allow all' access rule is not sent; it comes from default_action Allow.
web_app = {
  app_fit_dev = {
    name                                     = "app-fit-dev"
    resource_group_key                       = "app"
    location                                 = "canadacentral"
    os_type                                  = "Windows"
    app_service_plan_key                     = "app"
    app_service_environment_key              = "app"
    enabled                                  = true
    https_only                               = true
    public_network_access_enabled            = true
    client_affinity_enabled                  = true
    client_affinity_proxy_enabled            = false
    client_certificate_enabled               = false
    client_certificate_mode                  = "Required"
    end_to_end_encryption_enabled            = false
    host_names_disabled                      = false
    hyper_v                                  = false
    ip_mode                                  = "IPv4"
    redundancy_mode                          = "None"
    vnet_route_all_traffic                   = false
    vnet_application_traffic_enabled         = false
    vnet_content_share_enabled               = true
    vnet_image_pull_enabled                  = true
    virtual_network_backup_restore_enabled   = false
    ftp_publish_basic_authentication_enabled = false
    scm_publish_basic_authentication_enabled = true
    user_assigned_identity_ids = [
      "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-mid-fit-app-nonprod-canadacentral-001/providers/Microsoft.ManagedIdentity/userAssignedIdentities/mid-fit-nonprod-canadacentral-001"
    ]
    key_vault_reference_identity = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-mid-fit-app-nonprod-canadacentral-001/providers/Microsoft.ManagedIdentity/userAssignedIdentities/mid-fit-nonprod-canadacentral-001"
    site_config = {
      always_on                      = true
      default_documents              = ["index.aspx"]
      detailed_error_logging_enabled = true
      elastic_web_app_scale_limit    = 0
      elastic_instance_minimum       = 1
      experiments = {
        ramp_up_rules = []
      }
      ftps_state           = "FtpsOnly"
      http2_enabled        = false
      http20_proxy_flag    = 0
      http_logging_enabled = true
      ip_restriction = [
        {
          action     = "Allow"
          ip_address = "10.195.115.7/32,10.195.114.7/32"
          name       = "allowRunners"
          priority   = 100
        },
        {
          action     = "Allow"
          ip_address = "10.242.47.2/32,10.242.47.1/32"
          name       = "AllowESB"
          priority   = 200
        }
      ]
      ip_restriction_default_action     = "Allow"
      load_balancing_mode               = "LeastRequests"
      local_mysql_enabled               = false
      logs_directory_size_limit         = 35
      managed_pipeline_mode             = "Integrated"
      minimum_tls_version               = "1.2"
      scm_minimum_tls_version           = "1.2"
      dotnet_framework_version          = "v4.0"
      worker_count                      = 1
      pre_warmed_instance_count         = 0
      remote_debugging_enabled          = false
      remote_debugging_version          = "VS2022"
      request_tracing_enabled           = true
      request_tracing_expiration_time   = "9999-12-31T23:59:00Z"
      scm_ip_restriction                = []
      scm_ip_restriction_default_action = "Allow"
      scm_use_main_ip_restriction       = false
      use_32_bit_worker                 = true
      virtual_application = [
        {
          physical_path     = "site\\wwwroot"
          preload_enabled   = true
          virtual_path      = "/"
          virtual_directory = []
        },
        {
          physical_path     = "site\\wwwroot\\FITMobile"
          preload_enabled   = false
          virtual_path      = "/FIT_LITE"
          virtual_directory = []
        },
        {
          physical_path     = "site\\wwwroot\\FIT_WS"
          preload_enabled   = false
          virtual_path      = "/FIT_WS"
          virtual_directory = []
        }
      ]
      vnet_private_ports_count                = 0
      vnet_route_all_enabled                  = false
      websockets_enabled                      = false
      website_time_zone                       = "Pacific Standard Time"
      container_registry_use_managed_identity = false
      metadata = [
        {
          name  = "CURRENT_STACK"
          value = "dotnet"
        }
      ]
    }
    app_settings = {
      AllowableMeterTypes                             = "P261, P263, P264, P710, P716, P717, P860, P910, P916, P917, P960, P963, P967, P968, P363, P364, P973, P978"
      APPINSIGHTS_PROFILERFEATURE_VERSION             = "1.0.0"
      APPINSIGHTS_SNAPSHOTFEATURE_VERSION             = "1.0.0"
      ApplicationInsightsAgent_EXTENSION_VERSION      = "~2"
      ApplicationName                                 = "FIT"
      DateFormat                                      = "yyyy/MM/dd"
      DateTimeFormat                                  = "yyyy/MM/dd HH:mm"
      DateTimeFormat_WithSeconds                      = "yyyy/MM/dd HH:mm:ss"
      DIAGNOSTICS_AZUREBLOBRETENTIONINDAYS            = "180"
      DiagnosticServices_EXTENSION_VERSION            = "~3"
      DisallowedMeterTypesMsg                         = "The Meter {0} is currently not supported in FIT, as the Meter Type is {1} ({2})."
      ESB_PASSWORD                                    = "@Microsoft.KeyVault(SecretUri=https://kvfitcanadacentral.vault.azure.net/secrets/ESB-PASSWORD)"
      FITLiteURL                                      = "https://fit-dev.internal.bchydro.bc.ca/FIT_LITE"
      "ida:AADInstance"                               = "https://login.microsoftonline.com/{0}/v2.0"
      "ida:ClientId"                                  = "ef800b06-7b5a-4831-a768-6cb5aee376b4"
      "ida:ClientSecret"                              = "@Microsoft.KeyVault(SecretUri=https://kvfitcanadacentral.vault.azure.net/secrets/CLIENT-SECRET)"
      "ida:TenantId"                                  = "8fbb85e8-0cbc-48c3-a2e9-528cef30ec27"
      InstrumentationEngine_EXTENSION_VERSION         = "disabled"
      LogFileName                                     = "Log - {0}.log"
      LogTraceEvents                                  = "true"
      MaxFitCaseMeters                                = "4"
      MaxSearchResults                                = "50"
      NegativeRegisters                               = "Instantaneous Watts Received Phase A,Instantaneous Watts Received Aggregate"
      SnapshotDebugger_EXTENSION_VERSION              = "disabled"
      WEBSITE_LOAD_ROOT_CERTIFICATES                  = "28F13DD5EDF3288CF7DC8D2B8C5963C0041FCEE2,FEDE578F45A1C9568AEA73F512E3F633B2906D53"
      WEBSITE_TIME_ZONE                               = "Pacific Standard Time"
      WEBSITE_VNET_ROUTE_ALL                          = "1"
      XDT_MicrosoftApplicationInsights_BaseExtensions = "disabled"
      XDT_MicrosoftApplicationInsights_Java           = "1"
      XDT_MicrosoftApplicationInsights_Mode           = "recommended"
      XDT_MicrosoftApplicationInsights_NodeJS         = "1"
      XDT_MicrosoftApplicationInsights_PreemptSdk     = "disabled"
    }
    secret_app_setting_names = [
      "APPLICATIONINSIGHTS_CONNECTION_STRING",
      "DIAGNOSTICS_AZUREBLOBCONTAINERSASURL",
      "ESBPassword",
      "ESBUserName",
      "ESB_USER",
      "WEBSITE_HTTPLOGGING_CONTAINER_URL"
    ]
    connection_strings = {
      connectionstring = {
        name = "ConnectionString"
        type = "Custom"
      }
    }
    sticky_app_setting_names = [
      "ApplicationInsightsAgent_EXTENSION_VERSION",
      "DiagnosticServices_EXTENSION_VERSION",
      "InstrumentationEngine_EXTENSION_VERSION",
      "SnapshotDebugger_EXTENSION_VERSION",
      "XDT_MicrosoftApplicationInsights_BaseExtensions",
      "XDT_MicrosoftApplicationInsights_Mode",
      "XDT_MicrosoftApplicationInsights_NodeJS",
      "XDT_MicrosoftApplicationInsights_PreemptSdk"
    ]
    tags = {
      ApplicationId                            = "BCH – LIX -0000001397"
      ApplicationServiceLevel                  = "Silver"
      BusinessUnit                             = "Customer & Corporate Affairs"
      CostCenterId                             = "YT-01585.S.IMP.CLZ"
      Environment                              = "NonProd"
      Name                                     = "Field Investigation Tool"
      "hidden-link: /app-insights-resource-id" = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/microsoft.insights/components/ai-func-fit-nonprod-canadacentral-001"
    }
  }
}

web_app_imports = {
  app_fit_dev = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Web/sites/app-fit-dev"
}

# =====================================================================
# Hub private DNS: links and records in the shared zones (connectivity subscription)
# =====================================================================

enable_hub_private_dns = true

hub_private_dns_zone_link = {
  "fit-link-canadacentral" = {
    name               = "fit-link-canadacentral"
    zone_name          = "internal.bchydro.bc.ca"
    virtual_network_id = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-nonprod-canadacentral-001"
  }
  "link-blob-fit-nonprod-canadacentral-001" = {
    name               = "link-blob-fit-nonprod-canadacentral-001"
    zone_name          = "privatelink.blob.core.windows.net"
    virtual_network_id = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-nonprod-canadacentral-001"
  }
  "link-files-fit-nonprod-canadacentral-001" = {
    name               = "link-files-fit-nonprod-canadacentral-001"
    zone_name          = "privatelink.file.core.windows.net"
    virtual_network_id = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-nonprod-canadacentral-001"
  }
  "link-fit-dns-canadacentral-001" = {
    name               = "link-fit-dns-canadacentral-001"
    zone_name          = "app-fit-nonprod-canadacentral-001.appserviceenvironment.net"
    virtual_network_id = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-nonprod-canadacentral-001"
  }
  "link-fit-nonprod-canadacentral-001" = {
    name                 = "link-fit-nonprod-canadacentral-001"
    zone_name            = "bchydro.bc.ca"
    virtual_network_id   = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-nonprod-canadacentral-001"
    registration_enabled = true
  }
  "link-sites-fit-nonprod-canadacentral-001" = {
    name               = "link-sites-fit-nonprod-canadacentral-001"
    zone_name          = "privatelink.azurewebsites.net"
    virtual_network_id = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-nonprod-canadacentral-001"
  }
  "link-vault-fit-nonprod-canadacentral-001" = {
    name               = "link-vault-fit-nonprod-canadacentral-001"
    zone_name          = "privatelink.vaultcore.azure.net"
    virtual_network_id = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-nonprod-canadacentral-001"
  }
  "privatelink.agentsvc.azure-automation.net/link-fit-nonprod-canadacentral" = {
    name               = "link-fit-nonprod-canadacentral"
    zone_name          = "privatelink.agentsvc.azure-automation.net"
    virtual_network_id = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-nonprod-canadacentral-001"
  }
  "privatelink.cnc.backup.windowsazure.com/g3sclxwzc33p2" = {
    name               = "g3sclxwzc33p2"
    zone_name          = "privatelink.cnc.backup.windowsazure.com"
    virtual_network_id = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-nonprod-canadacentral-001"
  }
  "privatelink.monitor.azure.com/link-fit-nonprod-canadacentral" = {
    name               = "link-fit-nonprod-canadacentral"
    zone_name          = "privatelink.monitor.azure.com"
    virtual_network_id = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-nonprod-canadacentral-001"
  }
  "privatelink.ods.opinsights.azure.com/link-fit-nonprod-canadacentral" = {
    name               = "link-fit-nonprod-canadacentral"
    zone_name          = "privatelink.ods.opinsights.azure.com"
    virtual_network_id = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-nonprod-canadacentral-001"
  }
  "privatelink.oms.opinsights.azure.com/link-fit-nonprod-canadacentral" = {
    name               = "link-fit-nonprod-canadacentral"
    zone_name          = "privatelink.oms.opinsights.azure.com"
    virtual_network_id = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-nonprod-canadacentral-001"
  }
  "privatelink.queue.core.windows.net/g3sclxwzc33p2" = {
    name               = "g3sclxwzc33p2"
    zone_name          = "privatelink.queue.core.windows.net"
    virtual_network_id = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-nonprod-canadacentral-001"
  }
}

hub_private_dns_zone_link_imports = {
  "fit-link-canadacentral"                                                   = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/internal.bchydro.bc.ca/virtualNetworkLinks/fit-link-canadacentral"
  "link-blob-fit-nonprod-canadacentral-001"                                  = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net/virtualNetworkLinks/link-blob-fit-nonprod-canadacentral-001"
  "link-files-fit-nonprod-canadacentral-001"                                 = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.file.core.windows.net/virtualNetworkLinks/link-files-fit-nonprod-canadacentral-001"
  "link-fit-dns-canadacentral-001"                                           = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/app-fit-nonprod-canadacentral-001.appserviceenvironment.net/virtualNetworkLinks/link-fit-dns-canadacentral-001"
  "link-fit-nonprod-canadacentral-001"                                       = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/bchydro.bc.ca/virtualNetworkLinks/link-fit-nonprod-canadacentral-001"
  "link-sites-fit-nonprod-canadacentral-001"                                 = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.azurewebsites.net/virtualNetworkLinks/link-sites-fit-nonprod-canadacentral-001"
  "link-vault-fit-nonprod-canadacentral-001"                                 = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.vaultcore.azure.net/virtualNetworkLinks/link-vault-fit-nonprod-canadacentral-001"
  "privatelink.agentsvc.azure-automation.net/link-fit-nonprod-canadacentral" = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.agentsvc.azure-automation.net/virtualNetworkLinks/link-fit-nonprod-canadacentral"
  "privatelink.cnc.backup.windowsazure.com/g3sclxwzc33p2"                    = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.cnc.backup.windowsazure.com/virtualNetworkLinks/g3sclxwzc33p2"
  "privatelink.monitor.azure.com/link-fit-nonprod-canadacentral"             = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.monitor.azure.com/virtualNetworkLinks/link-fit-nonprod-canadacentral"
  "privatelink.ods.opinsights.azure.com/link-fit-nonprod-canadacentral"      = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.ods.opinsights.azure.com/virtualNetworkLinks/link-fit-nonprod-canadacentral"
  "privatelink.oms.opinsights.azure.com/link-fit-nonprod-canadacentral"      = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.oms.opinsights.azure.com/virtualNetworkLinks/link-fit-nonprod-canadacentral"
  "privatelink.queue.core.windows.net/g3sclxwzc33p2"                         = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.queue.core.windows.net/virtualNetworkLinks/g3sclxwzc33p2"
}

hub_private_dns_a_record = {
  "*" = {
    name      = "*"
    zone_name = "app-fit-nonprod-canadacentral-001.appserviceenvironment.net"
    ttl       = 10
    records   = ["10.195.80.4"]
  }
  "*.scm" = {
    name      = "*.scm"
    zone_name = "app-fit-nonprod-canadacentral-001.appserviceenvironment.net"
    ttl       = 10
    records   = ["10.195.80.4"]
  }
  "@" = {
    name      = "@"
    zone_name = "app-fit-nonprod-canadacentral-001.appserviceenvironment.net"
    ttl       = 10
    records   = ["10.195.80.4"]
  }
  "fit-dev" = {
    name      = "fit-dev"
    zone_name = "internal.bchydro.bc.ca"
    ttl       = 10
    records   = ["10.195.82.6"]
  }
  "vm-oracledb-fit-nonprod-canadacentral-001" = {
    name      = "vm-oracledb-fit-nonprod-canadacentral-001"
    zone_name = "internal.bchydro.bc.ca"
    ttl       = 10
    records   = ["10.195.81.4"]
  }
}

hub_private_dns_a_record_imports = {
  "*"                                         = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/app-fit-nonprod-canadacentral-001.appserviceenvironment.net/A/*"
  "*.scm"                                     = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/app-fit-nonprod-canadacentral-001.appserviceenvironment.net/A/*.scm"
  "@"                                         = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/app-fit-nonprod-canadacentral-001.appserviceenvironment.net/A/@"
  "fit-dev"                                   = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/internal.bchydro.bc.ca/A/fit-dev"
  "vm-oracledb-fit-nonprod-canadacentral-001" = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/internal.bchydro.bc.ca/A/vm-oracledb-fit-nonprod-canadacentral-001"
}

hub_private_dns_cname_record = {
  "fit-dev" = {
    name      = "fit-dev"
    zone_name = "bchydro.bc.ca"
    ttl       = 10
    record    = "fit-nonprod.app-fit-nonprod-canadacentral-001.appserviceenvironment.net"
  }
}

hub_private_dns_cname_record_imports = {
  "fit-dev" = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/bchydro.bc.ca/CNAME/fit-dev"
}
