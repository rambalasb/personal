# Prod subscription (0aa40f3e-3340-444e-bfac-d01a42a54ad1)
# Values come from the Azure resource export of 2026-10-20.
# VMs, web apps and the VNet are off for the first apply; see "Staged adoption"
# in the README.

subscription_id = "0aa40f3e-3340-444e-bfac-d01a42a54ad1"

enable_app_service_environment  = true
enable_app_service_plan         = true
enable_application_insights     = true
enable_bastion_host             = true
enable_event_grid_system_topic  = true
enable_key_vault                = true
enable_linux_virtual_machine    = false
enable_log_analytics_workspace  = true
enable_monitoring               = true
enable_network_interface        = false
enable_network_security_group   = true
enable_network_watcher          = true
enable_private_dns_zone         = true
enable_private_endpoint         = true
enable_public_ssh_key           = true
enable_recovery_services_vault  = true
enable_resource_group           = true
enable_restore_point_collection = true
enable_storage_account          = true
enable_user_assigned_identity   = true
enable_virtual_network          = false
enable_web_app                  = false

enable_app_service_environment_role_assignment  = false
enable_app_service_plan_role_assignment         = false
enable_application_insights_role_assignment     = false
enable_bastion_host_role_assignment             = false
enable_event_grid_system_topic_role_assignment  = false
enable_key_vault_role_assignment                = false
enable_linux_virtual_machine_role_assignment    = false
enable_log_analytics_workspace_role_assignment  = false
enable_monitoring_role_assignment               = false
enable_network_interface_role_assignment        = false
enable_network_security_group_role_assignment   = false
enable_network_watcher_role_assignment          = false
enable_private_dns_zone_role_assignment         = false
enable_private_endpoint_role_assignment         = false
enable_public_ssh_key_role_assignment           = false
enable_recovery_services_vault_role_assignment  = false
enable_resource_group_role_assignment           = false
enable_restore_point_collection_role_assignment = false
enable_storage_account_role_assignment          = false
enable_user_assigned_identity_role_assignment   = false
enable_virtual_network_role_assignment          = false
enable_web_app_role_assignment                  = false

role_assignments = {}

# Resource groups with a non-ID managedBy (Azure Backup) leave managed_by unset; the wrapper rejects it.
resource_group = {
  defaultresourcegroup_cca = {
    name     = "defaultresourcegroup-cca"
    location = "canadacentral"
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Field Investigation Tool"
    }
  }
  ma_defaultazuremonitorworkspace_cca_managed = {
    name       = "MA_defaultazuremonitorworkspace-cca_canadacentral_managed"
    location   = "canadacentral"
    managed_by = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourcegroups/defaultresourcegroup-cca/providers/microsoft.monitor/accounts/defaultazuremonitorworkspace-cca"
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Field Investigation Tool"
    }
  }
  mid_app = {
    name     = "rg-mid-fit-app-prod-canadacentral-001"
    location = "canadacentral"
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Field Investigation Tool"
    }
  }
  app = {
    name     = "rg-fit-app-prod-canadacentral-001"
    location = "canadacentral"
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Field Investigation Tool"
    }
  }
  network_watcher = {
    name     = "NetworkWatcherRG"
    location = "canadacentral"
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Field Investigation Tool"
    }
  }
  defaultresourcegroup_ccan = {
    name     = "DefaultResourceGroup-CCAN"
    location = "canadacentral"
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Field Investigation Tool"
    }
  }
}

import_resource_group = {
  defaultresourcegroup_cca                    = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/defaultresourcegroup-cca"
  ma_defaultazuremonitorworkspace_cca_managed = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/MA_defaultazuremonitorworkspace-cca_canadacentral_managed"
  mid_app                                     = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-mid-fit-app-prod-canadacentral-001"
  app                                         = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001"
  network_watcher                             = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/NetworkWatcherRG"
  defaultresourcegroup_ccan                   = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/DefaultResourceGroup-CCAN"
}

# Some action group IDs may contain a leading space in the group name; kept as exported.
alert = {
  resource_group_key         = "app"
  root_management_group_name = null
  tags                       = {}
  activity_log_alerts = {
    app_fit_prod_create_update = {
      name                = "app-fit-prod-create-update"
      resource_group_name = "rg-mid-fit-app-prod-canadacentral-001"
      scopes              = ["/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1"]
      location            = "global"
      description         = ""
      enabled             = true
      criteria = {
        category       = "Administrative"
        operation_name = "Microsoft.Web/serverfarms/Write"
      }
      action_group_keys = []
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ ag-fit-db-mail-alerts-canadacentral-002"
      ]
      webhook_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        BusinessUnit            = "Customer & Corporate Affairs"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Call Out Procedures"
      }
    }
    app_fit_prod_delete = {
      name                = "app-fit-prod-delete"
      resource_group_name = "rg-fit-app-prod-canadacentral-001"
      scopes              = ["/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1"]
      location            = "global"
      description         = ""
      enabled             = true
      criteria = {
        category       = "Administrative"
        operation_name = "Microsoft.Web/sites/Delete"
      }
      action_group_keys = []
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      webhook_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        BusinessUnit            = "Customer & Corporate Affairs"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Call Out Procedures"
      }
    }
    app_fit_prod_restart = {
      name                = "app-fit-prod-restart"
      resource_group_name = "rg-fit-app-prod-canadacentral-001"
      scopes              = ["/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1"]
      location            = "global"
      description         = ""
      enabled             = true
      criteria = {
        category       = "Administrative"
        operation_name = "Microsoft.Web/sites/restart/Action"
      }
      action_group_keys = []
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      webhook_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        BusinessUnit            = "Customer & Corporate Affairs"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Call Out Procedures"
      }
    }
    app_fit_prod_stop = {
      name                = "app-fit-prod-stop"
      resource_group_name = "rg-fit-app-prod-canadacentral-001"
      scopes              = ["/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1"]
      location            = "global"
      description         = ""
      enabled             = true
      criteria = {
        category       = "Administrative"
        operation_name = "Microsoft.Web/sites/stop/Action"
      }
      action_group_keys = []
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      webhook_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        BusinessUnit            = "Customer & Corporate Affairs"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Call Out Procedures"
      }
    }
    keyvault_deletion_alert = {
      name                = "keyVault-Deletion-Alert-CanadaCentral"
      resource_group_name = "rg-fit-app-prod-canadacentral-001"
      scopes              = ["/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1"]
      location            = "global"
      description         = "This alert will monitor any deletion of key vault"
      enabled             = true
      criteria = {
        category       = "Administrative"
        resource_type  = "microsoft.keyvault/vaults"
        operation_name = "Microsoft.KeyVault/vaults/delete"
      }
      action_group_keys = []
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      webhook_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001397"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affair"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Field Investigation Tool"
      }
    }
    service_outage_alert = {
      name                = "Service-Outage-Alert-CanadaCentral"
      resource_group_name = "rg-fit-app-prod-canadacentral-001"
      scopes              = ["/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1"]
      location            = "global"
      description         = "Azure Landing Zone Service Health Alert"
      enabled             = true
      criteria = {
        category = "ServiceHealth"
      }
      action_group_keys = []
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-monitor-mail-alerts-canadacentral-001"
      ]
      webhook_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001397"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affair"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Field Investigation Tool"
      }
    }
  }
  metric_alerts = {
    app_fit_http_404_informational = {
      name                = "app-fit-http-404-informational"
      resource_group_name = "rg-fit-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Web/sites/app-fit-prod-canadacentral-001"
      ]
      description              = "This alert is for Sub-Fit-Prod App's HTTP errors"
      enabled                  = false
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 3
      target_resource_type     = "Microsoft.Web/sites"
      target_resource_location = "canadacentral"
      dynamic_criteria = {
        metric_namespace         = "Microsoft.Web/sites"
        metric_name              = "Http4xx"
        aggregation              = "Total"
        operator                 = "GreaterOrLessThan"
        alert_sensitivity        = "Medium"
        evaluation_total_count   = 4
        evaluation_failure_count = 4
        ignore_data_before       = null
        skip_metric_validation   = false
        dimensions               = []
      }
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/lga-servicenow-integration_group/providers/microsoft.insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001397"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affairs"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Field Investigation Tool"
      }
    }
    app_health_alert_canadacentral = {
      name                = "App-Health-Alert-canadacentral"
      resource_group_name = "rg-mid-fit-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Web/sites/app-fit-prod-canadacentral-001"
      ]
      description              = "This alert is for Sub-Fit-Prod App's Health Check"
      enabled                  = false
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 3
      target_resource_type     = "Microsoft.Web/sites"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Web/sites"
          metric_name            = "HealthCheckStatus"
          aggregation            = "Average"
          operator               = "LessThan"
          threshold              = 100
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/lga-servicenow-integration_group/providers/microsoft.insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001397"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affairs"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Field Investigation Tool"
      }
    }
    app_high_cpu_alert_canadacentral = {
      name                = "App-High-CPU-Alert-canadacentral"
      resource_group_name = "rg-mid-fit-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Web/sites/app-fit-prod-canadacentral-001"
      ]
      description              = "This alert is fro Sub-Fit-Prod App's High CPU usage"
      enabled                  = false
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 3
      target_resource_type     = "Microsoft.Web/sites"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Web/sites"
          metric_name            = "CpuTime"
          aggregation            = "Total"
          operator               = "GreaterThan"
          threshold              = 300
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/lga-servicenow-integration_group/providers/microsoft.insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001397"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affairs"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Field Investigation Tool"
      }
    }
    app_http_alert_canadacentral = {
      name                = "App-HTTP-Alert-canadacentral"
      resource_group_name = "rg-mid-fit-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Web/sites/app-fit-prod-canadacentral-001"
      ]
      description              = "This alert is for Sub-Fit-Prod App's HTTP errors"
      enabled                  = false
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 1
      target_resource_type     = "Microsoft.Web/sites"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Web/sites"
          metric_name            = "Http5xx"
          aggregation            = "Total"
          operator               = "GreaterThan"
          threshold              = 5
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/lga-servicenow-integration_group/providers/microsoft.insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001397"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affairs"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Field Investigation Tool"
      }
    }
    backup_alert = {
      name                = "Backup-alert"
      resource_group_name = "rg-fit-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.RecoveryServices/vaults/rsv-fit-prod-canadacentral-001"
      ]
      description              = "Backup health alert"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT15M"
      window_size              = "PT6H"
      severity                 = 3
      target_resource_type     = "Microsoft.RecoveryServices/vaults"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.RecoveryServices/vaults"
          metric_name            = "BackupHealthEvent"
          aggregation            = "Count"
          operator               = "GreaterThan"
          threshold              = 0
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actionGroups/ag-monitor-mail-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001397"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affairs"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Field Investigation Tool"
      }
    }
    oracle_vm_fit_prod_memory_high_warning = {
      name                = "oracle-vm-fit-prod-memory-high-warning"
      resource_group_name = "rg-mid-fit-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-oracledb-fit-prod-canadacentral-001"
      ]
      description              = "Action will be triggered when percentage CPU for VM is greater than 85%"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 2
      target_resource_type     = "Microsoft.Compute/virtualMachines"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Compute/virtualMachines"
          metric_name            = "Available Memory Percentage"
          aggregation            = "Average"
          operator               = "LessThanOrEqual"
          threshold              = 15
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-db-mail-alerts-canadacentral-001",
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001",
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ ag-fit-db-mail-alerts-canadacentral-002"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001397"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affairs"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Field Investigation Tool"
      }
    }
    oracle_vm_prod_high_cpu_alert_canadacentral = {
      name                = "Oracle-VM-Prod-High-CPU-Alert-canadacentral"
      resource_group_name = "rg-mid-fit-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-oracledb-fit-prod-canadacentral-001"
      ]
      description              = "Triggered when disk space has consumed >80%"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 3
      target_resource_type     = "Microsoft.Compute/virtualMachines"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Compute/virtualMachines"
          metric_name            = "Percentage CPU"
          aggregation            = "Average"
          operator               = "GreaterThan"
          threshold              = 80
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-db-mail-alerts-canadacentral-001",
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001",
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ ag-fit-db-mail-alerts-canadacentral-002"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001397"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affairs"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Field Investigation Tool"
      }
    }
    restore_job_failed_fit_prod_alert_canadacentral = {
      name                = "Restore-Job-Failed-FIT-Prod-Alert-CanadaCentral"
      resource_group_name = "rg-fit-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.RecoveryServices/vaults/rsv-fit-prod-canadacentral-001"
      ]
      description              = "Job triggers when restore job is faild"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT15M"
      severity                 = 2
      target_resource_type     = "Microsoft.RecoveryServices/vaults"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.RecoveryServices/vaults"
          metric_name            = "RestoreHealthEvent"
          aggregation            = "Count"
          operator               = "GreaterThanOrEqual"
          threshold              = 1
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-monitor-mail-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001397"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affair"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Field Investigation Tool"
      }
    }
    vm_heartbeat_lost_alert_canadacentral_001 = {
      name                = "VM-heartbeat-lost-alert-CanadaCentral-001"
      resource_group_name = "DefaultResourceGroup-CCAN"
      scopes = [
        "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/DefaultResourceGroup-CCAN/providers/Microsoft.OperationalInsights/workspaces/DefaultWorkspace-0aa40f3e-3340-444e-bfac-d01a42a54ad1-CCAN"
      ]
      description              = "This alert will be triggered when VM state is unhealthy for more than 5min"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 0
      target_resource_type     = "Microsoft.OperationalInsights/workspaces"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.OperationalInsights/workspaces"
          metric_name            = "Heartbeat"
          aggregation            = "Total"
          operator               = "LessThan"
          threshold              = 2
          skip_metric_validation = false
          dimensions = [
            {
              name     = "Computer"
              operator = "Include"
              values   = ["vm-oracledb-fit-prod-canadacentral-001"]
            }
          ]
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001397"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affair"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Field Investigation Tool"
      }
    }
  }
  log_search_alerts = {
    keyvault_secret_expired_alert_canadacentral = {
      name                              = "KeyVault-Secret-Expired-Alert-CanadaCentral"
      resource_group_name               = "defaultresourcegroup-cca"
      location                          = "canadacentral"
      scopes                            = ["/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1"]
      severity                          = 0
      evaluation_frequency              = "PT5M"
      window_duration                   = "PT30M"
      description                       = "Alert for expired secret in a Key Vault."
      display_name                      = "KeyVault-Secret-Expired-Alert-CanadaCentral"
      enabled                           = true
      auto_mitigation_enabled           = false
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = null
      target_resource_types             = ["microsoft.keyvault/vaults"]
      criteria = [
        {
          query                   = " AzureDiagnostics\n        | where ResourceProvider == \"MICROSOFT.KEYVAULT\"\n        | where OperationName contains \"SecretExpired\"\n"
          time_aggregation_method = "Count"
          threshold               = 1
          operator                = "GreaterThan"
          resource_id_column      = "_ResourceId"
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001397"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affair"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Field Investigation Tool"
      }
    }
    keyvault_secret_near_expiry_alert_canadacentral = {
      name                              = "KeyVault-Secret-Near-Expiry-Alert-CanadaCentral"
      resource_group_name               = "defaultresourcegroup-cca"
      location                          = "canadacentral"
      scopes                            = ["/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1"]
      severity                          = 3
      evaluation_frequency              = "PT5M"
      window_duration                   = "PT30M"
      description                       = "Alert for secret in a Key Vault is about to expire."
      display_name                      = "KeyVault-Secret-Near-Expiry-Alert-CanadaCentral"
      enabled                           = true
      auto_mitigation_enabled           = false
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = null
      target_resource_types             = ["microsoft.keyvault/vaults"]
      criteria = [
        {
          query                   = "AzureDiagnostics\n        | where ResourceProvider == \"MICROSOFT.KEYVAULT\"\n        | where OperationName contains \"SecretNearExpiry\"\n"
          time_aggregation_method = "Count"
          threshold               = 1
          operator                = "GreaterThanOrEqual"
          resource_id_column      = "_ResourceId"
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001397"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affair"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Field Investigation Tool"
      }
    }
    resource_creation_alert_canadacentral = {
      name                              = "Resource-Creation-Alert-CanadaCentral"
      resource_group_name               = "rg-fit-app-prod-canadacentral-001"
      location                          = "canadacentral"
      scopes                            = ["/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1"]
      severity                          = 4
      evaluation_frequency              = "PT10M"
      window_duration                   = "PT30M"
      description                       = "Alert when a new resource is created."
      display_name                      = "Resource-Creation-Alert-CanadaCentral"
      enabled                           = true
      auto_mitigation_enabled           = false
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = null
      target_resource_types             = null
      criteria = [
        {
          query                   = "AzureActivity\n        | where OperationNameValue has \"Microsoft.Resources/deployments/write\"\n        | where CategoryValue == \"Administrative\"\n        | where ActivityStatusValue == \"Success\"\n"
          time_aggregation_method = "Count"
          threshold               = 10
          operator                = "GreaterThanOrEqual"
          resource_id_column      = "_ResourceId"
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-monitor-mail-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001397"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affair"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Field Investigation Tool"
      }
    }
    storage_account_container_deletion_alert_canadacentral = {
      name                              = "Storage-Account-Container-Deletion-Alert-CanadaCentral"
      resource_group_name               = "rg-fit-app-prod-canadacentral-001"
      location                          = "canadacentral"
      scopes                            = ["/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1"]
      severity                          = 0
      evaluation_frequency              = "PT5M"
      window_duration                   = "PT30M"
      description                       = "Alert for the deletion of Storage Account Container."
      display_name                      = "Storage-Account-Container-Deletion-Alert-CanadaCentral"
      enabled                           = true
      auto_mitigation_enabled           = false
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = null
      target_resource_types             = ["microsoft.storage/storageaccounts"]
      criteria = [
        {
          query                   = "AzureActivity\n        | where ResourceProviderValue == \"MICROSOFT.STORAGE\" and OperationNameValue == \"MICROSOFT.STORAGE/STORAGEACCOUNTS/BLOBSERVICES/CONTAINERS/DELETE\"\n"
          time_aggregation_method = "Count"
          threshold               = 1
          operator                = "GreaterThanOrEqual"
          resource_id_column      = "_ResourceId"
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001397"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affair"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Field Investigation Tool"
      }
    }
    storage_account_deletion_alert_canadacentral = {
      name                              = "Storage-Account-Deletion-Alert-CanadaCentral"
      resource_group_name               = "defaultresourcegroup-cca"
      location                          = "canadacentral"
      scopes                            = ["/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1"]
      severity                          = 0
      evaluation_frequency              = "PT5M"
      window_duration                   = "PT30M"
      description                       = "Alert for the deletion of Storage Account."
      display_name                      = "Storage-Account-Deletion-Alert-CanadaCentral"
      enabled                           = true
      auto_mitigation_enabled           = false
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = null
      target_resource_types             = ["microsoft.storage/storageaccounts"]
      criteria = [
        {
          query                   = "AzureActivity\n        | where ResourceProviderValue == \"MICROSOFT.STORAGE\" and OperationNameValue == \"MICROSOFT.STORAGE/STORAGEACCOUNTS/DELETE\"\n"
          time_aggregation_method = "Count"
          threshold               = 1
          operator                = "GreaterThanOrEqual"
          resource_id_column      = "_ResourceId"
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001397"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affair"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Field Investigation Tool"
      }
    }
    vm_backup_failure_error_alert_canadacentral = {
      name                = "vm-backup-failure-error-alert-CanadaCentral"
      resource_group_name = "rg-fit-app-prod-canadacentral-001"
      location            = "canadacentral"
      scopes = [
        "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.RecoveryServices/vaults/rsv-fit-prod-canadacentral-001"
      ]
      severity                          = 1
      evaluation_frequency              = "PT10M"
      window_duration                   = "PT30M"
      description                       = "Alert triggers when there is a VM Backup failure"
      display_name                      = "vm-backup-failure-error-alert-CanadaCentral"
      enabled                           = true
      auto_mitigation_enabled           = false
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = null
      target_resource_types             = ["Microsoft.RecoveryServices/vaults"]
      criteria = [
        {
          query                   = "AzureDiagnostics\n\t\t    | where Category == \"AzureBackupReport\"\n\t\t    | where OperationName == \"Job\"\n\t\t    | where ResultType != \"Success\"\n"
          time_aggregation_method = "Count"
          threshold               = 1
          operator                = "GreaterThanOrEqual"
          resource_id_column      = null
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-monitor-mail-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001397"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affair"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Field Investigation Tool"
      }
    }
    vm_free_disk_space_fit_prod_alert_canadacentral = {
      name                = "VM-Free-Disk-Space-FIT-prod-Alert-canadacentral"
      resource_group_name = "rg-mid-fit-app-prod-canadacentral-001"
      location            = "canadacentral"
      scopes = [
        "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-oracledb-fit-prod-canadacentral-001"
      ]
      severity                          = 2
      evaluation_frequency              = "PT5M"
      window_duration                   = "PT5M"
      description                       = "Triggered when disk space has consumed >85%"
      display_name                      = "VM-Free-Disk-Space-FIT-prod-Alert-canadacentral"
      enabled                           = true
      auto_mitigation_enabled           = false
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = "P2D"
      target_resource_types             = ["Microsoft.Compute/virtualMachines"]
      criteria = [
        {
          query                   = "Perf\n| where TimeGenerated > ago(15m)\n| where ObjectName in (\"LogicalDisk\", \"Logical Disk\")\n| where CounterName == \"% Free Space\"\n| where InstanceName == \"_Total\"\n| summarize \n    FreePercent = avg(CounterValue),\n    TimeGenerated = max(TimeGenerated)\n  by Computer\n| extend UsedPercent = round(100 - FreePercent, 2)\n| where UsedPercent >= 85\n| project TimeGenerated, Computer, UsedPercent\n"
          time_aggregation_method = "Count"
          threshold               = 1
          operator                = "GreaterThan"
          resource_id_column      = null
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-db-mail-alerts-canadacentral-001",
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ ag-fit-db-mail-alerts-canadacentral-002"
      ]
      custom_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001397"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affairs"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Field Investigation Tool"
      }
    }
  }
  alert_processing_rules = {
    suppress_alert_fit_app = {
      name                = "Suppress_Alert_FIT_APP"
      resource_group_name = "rg-fit-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Web/sites/app-fit-prod"
      ]
      type             = "suppression"
      description      = "suppressing alert on FIT-APP-Prod, Change implementation - CHG0082799"
      enabled          = false
      action_group_ids = []
      conditions       = {}
      schedule = {
        effective_from  = "2026-02-20T16:30:00"
        effective_until = "2026-02-20T18:00:00"
        time_zone       = "Eastern Standard Time"
        recurrence      = null
      }
      tags = {
        ApplicationId           = "BCH – LIX -0000001397"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affairs"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Field Investigation Tool"
      }
    }
    suppress_alert_vm_oracledb_fit_prod = {
      name                = "Suppress_Alert_VM-Oracledb-fit-prod"
      resource_group_name = "rg-fit-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-oracledb-fit-prod-canadacentral-001"
      ]
      type             = "suppression"
      description      = "suppressing alsert on vm-oracledb-fit-prod to cover the change CHG0082870"
      enabled          = false
      action_group_ids = []
      conditions       = {}
      schedule = {
        effective_from  = "2026-02-20T16:00:00"
        effective_until = "2026-02-20T19:00:00"
        time_zone       = "Eastern Standard Time"
        recurrence      = null
      }
      tags = {
        ApplicationId           = "BCH – LIX -0000001397"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affairs"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Field Investigation Tool"
      }
    }
  }
}

activity_log_alert_imports = {
  app_fit_prod_create_update = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-mid-fit-app-prod-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/app-fit-prod-create-update"
  app_fit_prod_delete        = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/app-fit-prod-delete"
  app_fit_prod_restart       = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/app-fit-prod-restart"
  app_fit_prod_stop          = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/app-fit-prod-stop"
  keyvault_deletion_alert    = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/keyVault-Deletion-Alert-CanadaCentral"
  service_outage_alert       = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/Service-Outage-Alert-CanadaCentral"
}

metric_alert_imports = {
  app_fit_http_404_informational                  = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/app-fit-http-404-informational"
  app_health_alert_canadacentral                  = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-mid-fit-app-prod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/App-Health-Alert-canadacentral"
  app_high_cpu_alert_canadacentral                = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-mid-fit-app-prod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/App-High-CPU-Alert-canadacentral"
  app_http_alert_canadacentral                    = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-mid-fit-app-prod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/App-HTTP-Alert-canadacentral"
  backup_alert                                    = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/Backup-alert"
  oracle_vm_fit_prod_memory_high_warning          = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-mid-fit-app-prod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/oracle-vm-fit-prod-memory-high-warning"
  oracle_vm_prod_high_cpu_alert_canadacentral     = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-mid-fit-app-prod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/Oracle-VM-Prod-High-CPU-Alert-canadacentral"
  restore_job_failed_fit_prod_alert_canadacentral = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/Restore-Job-Failed-FIT-Prod-Alert-CanadaCentral"
  vm_heartbeat_lost_alert_canadacentral_001       = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/DefaultResourceGroup-CCAN/providers/Microsoft.Insights/metricAlerts/VM-heartbeat-lost-alert-CanadaCentral-001"
}

log_search_alert_imports = {
  keyvault_secret_expired_alert_canadacentral            = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/defaultresourcegroup-cca/providers/Microsoft.Insights/scheduledQueryRules/KeyVault-Secret-Expired-Alert-CanadaCentral"
  keyvault_secret_near_expiry_alert_canadacentral        = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/defaultresourcegroup-cca/providers/Microsoft.Insights/scheduledQueryRules/KeyVault-Secret-Near-Expiry-Alert-CanadaCentral"
  resource_creation_alert_canadacentral                  = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/Resource-Creation-Alert-CanadaCentral"
  storage_account_container_deletion_alert_canadacentral = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/Storage-Account-Container-Deletion-Alert-CanadaCentral"
  storage_account_deletion_alert_canadacentral           = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/defaultresourcegroup-cca/providers/Microsoft.Insights/scheduledQueryRules/Storage-Account-Deletion-Alert-CanadaCentral"
  vm_backup_failure_error_alert_canadacentral            = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/vm-backup-failure-error-alert-CanadaCentral"
  vm_free_disk_space_fit_prod_alert_canadacentral        = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-mid-fit-app-prod-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/VM-Free-Disk-Space-FIT-prod-Alert-canadacentral"
}

# Not managed here:
#   actionrules 'Alert Suppressing - Fit Sub' (rg-mid-fit-app-prod-canadacentral-001): azurerm rejects processing rule names with spaces; rename it in Azure to manage it
#   actionrules 'Alert Surpressing' (rg-fit-app-prod-canadacentral-001): azurerm rejects processing rule names with spaces; rename it in Azure to manage it
#   actionrules 'Alert-Suppression for FIT resources' (rg-fit-app-prod-canadacentral-001): azurerm rejects processing rule names with spaces; rename it in Azure to manage it
#   actionrules 'Suppress notifications - fit sub' (AzureBackupRG_canadacentral_1): azurerm rejects processing rule names with spaces; rename it in Azure to manage it
#   actionrules 'Suppress notifications - fit sub' (defaultresourcegroup-cca): azurerm rejects processing rule names with spaces; rename it in Azure to manage it
#   actionrules 'Suppress notifications - fit sub' (DefaultResourceGroup-CCAN): azurerm rejects processing rule names with spaces; rename it in Azure to manage it
#   actionrules 'Suppress notifications - fit sub' (MA_defaultazuremonitorworkspace-cca_canadacentral_managed): azurerm rejects processing rule names with spaces; rename it in Azure to manage it
#   actionrules 'Suppress notifications - fit sub' (NetworkWatcherRG): azurerm rejects processing rule names with spaces; rename it in Azure to manage it
#   scheduledqueryrules 'AzureUpdateManager-Update-failure' (AzureBackupRG_canadacentral_1): SystemAssigned identity (the wrapper has no identity input)
#   scheduledqueryrules 'VM-heartbeat-lost-alert-CanadaCentral-001' (DefaultResourceGroup-CCAN): LogToMetric rule (legacy; not supported by scheduled query rules v2)
#   scheduledqueryrules 'VM-OS-Patch-Available-FIT-Prod-Alert-CanadaCentral' (rg-fit-app-prod-canadacentral-001): SystemAssigned identity (the wrapper has no identity input)
alert_processing_rule_imports = {
  suppress_alert_fit_app              = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.AlertsManagement/actionRules/Suppress_Alert_FIT_APP"
  suppress_alert_vm_oracledb_fit_prod = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.AlertsManagement/actionRules/Suppress_Alert_VM-Oracledb-fit-prod"
}

# zone_redundancy_enabled and the subnet force replacement; both match the export.
app_service_environment = {
  app = {
    name                                   = "ase-fit-prod-canadacentral-001"
    resource_group_key                     = "app"
    location                               = "canadacentral"
    subnet_id                              = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-prod-canadacentral-001/subnets/snet-app-fit-prod-canadacentral-001"
    internal_load_balancing_mode           = "Web, Publishing"
    zone_redundancy_enabled                = false
    internal_encryption_enabled            = false
    ftp_enabled                            = false
    remote_debug_enabled                   = false
    allow_new_private_endpoint_connections = true
    tls_1_enabled                          = true # clusterSettings is empty, so DisableTls1.0 is not set
    inbound_ip_address_override            = null
    upgrade_preference                     = "None"
    dedicated_host_count                   = null
    system_assigned_identity               = false
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Field Investigation Tool"
    }
  }
}

app_service_environment_imports = {
  app = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Web/hostingEnvironments/ase-fit-prod-canadacentral-001"
}

app_service_plan = {
  app = {
    name                            = "asp-fit-prod-canadacentral-002"
    resource_group_key              = "app"
    location                        = "canadacentral"
    os_type                         = "Windows"
    sku_name                        = "I1v2"
    worker_count                    = 1
    maximum_elastic_worker_count    = 1
    per_site_scaling_enabled        = false
    premium_plan_auto_scale_enabled = false
    zone_balancing_enabled          = false
    app_service_environment_id      = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Web/hostingEnvironments/ase-fit-prod-canadacentral-001"
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Field Investigation Tool"
    }
  }
}

app_service_plan_imports = {
  app = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Web/serverFarms/asp-fit-prod-canadacentral-002"
}

# The daily cap is not in the export (100 is the provider default); confirm with
# az monitor app-insights component billing show.
application_insights = {
  func = {
    name                          = "ai-func-fit-prod-canadacentral-001"
    resource_group_key            = "app"
    location                      = "canadacentral"
    workspace_id                  = "/subscriptions/7d54d6f7-83d9-48cf-ac35-1068bcfd0561/resourceGroups/rg-siem-security-canadacentral-001/providers/Microsoft.OperationalInsights/workspaces/la-siem-security-canadacentral-001"
    application_type              = "web"
    retention_in_days             = 90
    daily_data_cap_in_gb          = 100
    sampling_percentage           = 0
    internet_ingestion_enabled    = true
    internet_query_enabled        = true
    local_authentication_disabled = false
    disable_ip_masking            = false
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Field Investigation Tool"
    }
  }
}

application_insights_imports = {
  func = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Insights/components/ai-func-fit-prod-canadacentral-001"
}

# Standard bastions reuse their existing public IP; the public IP itself is not managed.
bastion_host = {
  app = {
    name               = "vnet-fit-prod-canadacentral-001-bastion"
    resource_group_key = "app"
    location           = "canadacentral"
    sku                = "Developer"
    scale_units        = 2
    zones              = []
    virtual_network_id = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-prod-canadacentral-001"
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Field Investigation Tool"
    }
  }
}

bastion_host_imports = {
  app = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/bastionHosts/vnet-fit-prod-canadacentral-001-bastion"
}

event_grid_system_topic = {
  stfitprodcac001_storage = {
    name                        = "stfitprodcac001-1bd38248-b256-4bf8-ac06-331065cdf37e"
    resource_group_key          = "app"
    location                    = "canadacentral"
    topic_type                  = "microsoft.storage.storageaccounts"
    source_resource_id          = null
    exported_source_resource_id = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/microsoft.storage/storageaccounts/stfitprodcac001"
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Field Investigation Tool"
    }
  }
  stfitrestore_storage = {
    name                        = "stfitrestore-257eb076-d06b-4b46-a9a6-0d02c9a87985"
    resource_group_key          = "app"
    location                    = "canadacentral"
    topic_type                  = "microsoft.storage.storageaccounts"
    source_resource_id          = null
    exported_source_resource_id = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/microsoft.storage/storageaccounts/stfitrestore"
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Field Investigation Tool"
    }
  }
  stnwfitprdcac001xdf_storage = {
    name                        = "stnwfitprdcac001xdf-f0ee0938-2382-4658-827a-ce1e3497e3e3"
    resource_group_key          = "network_watcher"
    location                    = "canadacentral"
    topic_type                  = "microsoft.storage.storageaccounts"
    source_resource_id          = null
    exported_source_resource_id = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/networkwatcherrg/providers/microsoft.storage/storageaccounts/stnwfitprdcac001xdf"
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Field Investigation Tool"
    }
  }
}

event_grid_system_topic_imports = {
  stfitprodcac001_storage     = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.EventGrid/systemTopics/stfitprodcac001-1bd38248-b256-4bf8-ac06-331065cdf37e"
  stfitrestore_storage        = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.EventGrid/systemTopics/stfitrestore-257eb076-d06b-4b46-a9a6-0d02c9a87985"
  stnwfitprdcac001xdf_storage = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/NetworkWatcherRG/providers/Microsoft.EventGrid/systemTopics/stnwfitprdcac001xdf-f0ee0938-2382-4658-827a-ce1e3497e3e3"
}

key_vault = {
  app = {
    name                            = "kvfitprodcac001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    tenant_id                       = "8fbb85e8-0cbc-48c3-a2e9-528cef30ec27"
    sku_name                        = "premium"
    enabled_for_deployment          = true
    enabled_for_disk_encryption     = true
    enabled_for_template_deployment = true
    legacy_access_policies_enabled  = false
    public_network_access_enabled   = true
    purge_protection_enabled        = true
    soft_delete_retention_days      = 90
    network_acls = {
      bypass                     = "AzureServices"
      default_action             = "Deny"
      ip_rules                   = []
      virtual_network_subnet_ids = []
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Field Investigation Tool"
    }
  }
}

key_vault_imports = {
  app = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvfitprodcac001"
}

# Created by the platform (Defender/AMA default workspace).
log_analytics_workspace = {
  defaultworkspace = {
    name                            = "DefaultWorkspace-0aa40f3e-3340-444e-bfac-d01a42a54ad1-CCAN"
    resource_group_key              = "defaultresourcegroup_ccan"
    location                        = "canadacentral"
    sku                             = "PerGB2018"
    retention_in_days               = 30
    daily_quota_gb                  = -1
    internet_ingestion_enabled      = "true"
    internet_query_enabled          = "true"
    local_authentication_enabled    = true
    allow_resource_only_permissions = true
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Field Investigation Tool"
    }
  }
}

log_analytics_workspace_imports = {
  defaultworkspace = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/DefaultResourceGroup-CCAN/providers/Microsoft.OperationalInsights/workspaces/DefaultWorkspace-0aa40f3e-3340-444e-bfac-d01a42a54ad1-CCAN"
}

# Protocols use the wrapper's casing (Tcp); Azure reports TCP, so a case-only update may appear.
network_security_group = {
  app = {
    name               = "nsg-app-fit-prod-canadacentral-001"
    resource_group_key = "app"
    location           = "canadacentral"
    security_rules = {
      allowonprem = {
        name                       = "AllowOnPrem"
        access                     = "Allow"
        direction                  = "Inbound"
        priority                   = 200
        protocol                   = "*"
        source_port_range          = "*"
        destination_port_range     = "*"
        source_address_prefixes    = ["10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "142.52.0.0/16"]
        destination_address_prefix = "*"
      }
      denyallinbound = {
        name                       = "DenyAllInbound"
        access                     = "Deny"
        direction                  = "Inbound"
        priority                   = 1000
        protocol                   = "*"
        source_port_range          = "*"
        destination_port_range     = "*"
        source_address_prefix      = "*"
        destination_address_prefix = "*"
      }
      allowhostedrunners = {
        name                       = "AllowHostedRunners"
        access                     = "Allow"
        direction                  = "Inbound"
        priority                   = 105
        protocol                   = "*"
        source_port_range          = "*"
        destination_port_ranges    = ["80", "443", "4022", "4024", "4026", "8172"]
        source_address_prefixes    = ["10.195.114.7", "10.195.115.7"]
        destination_address_prefix = "10.195.32.0/24"
      }
      allowinternalhealthping = {
        name                       = "AllowInternalHealthPing"
        access                     = "Allow"
        direction                  = "Inbound"
        priority                   = 106
        protocol                   = "Tcp"
        source_port_range          = "*"
        destination_port_range     = "80"
        source_address_prefix      = "AzureLoadBalancer"
        destination_address_prefix = "10.195.32.0/24"
      }
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Field Investigation Tool"
    }
  }
  oracle = {
    name               = "nsg-oracle-fit-prod-canadacentral-001"
    resource_group_key = "app"
    location           = "canadacentral"
    security_rules = {
      allowonprem = {
        name                       = "AllowOnPrem"
        access                     = "Allow"
        direction                  = "Inbound"
        priority                   = 200
        protocol                   = "*"
        source_port_range          = "*"
        destination_port_range     = "*"
        source_address_prefixes    = ["10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "142.52.0.0/16"]
        destination_address_prefix = "*"
      }
      allowbastionhost = {
        name                       = "AllowBastionHost"
        access                     = "Allow"
        direction                  = "Inbound"
        priority                   = 900
        protocol                   = "Tcp"
        source_port_range          = "*"
        destination_port_ranges    = ["22", "3389"]
        source_address_prefix      = "168.63.129.16"
        destination_address_prefix = "*"
      }
      cyberark_ssh = {
        name                       = "cyberark-ssh"
        access                     = "Allow"
        direction                  = "Inbound"
        priority                   = 910
        protocol                   = "Tcp"
        source_port_range          = "22"
        destination_port_range     = "22"
        source_address_prefixes    = ["10.195.116.4", "10.195.116.5"]
        destination_address_prefix = "10.195.33.4"
      }
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Field Investigation Tool"
    }
  }
  pep = {
    name               = "nsg-pep-fit-prod-canadacentral-001"
    resource_group_key = "app"
    location           = "canadacentral"
    security_rules = {
      allowonprem = {
        name                       = "AllowOnPrem"
        access                     = "Allow"
        direction                  = "Inbound"
        priority                   = 200
        protocol                   = "*"
        source_port_range          = "*"
        destination_port_range     = "*"
        source_address_prefixes    = ["10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "142.52.0.0/16"]
        destination_address_prefix = "*"
      }
      denyallinbound = {
        name                       = "DenyAllInbound"
        access                     = "Deny"
        direction                  = "Inbound"
        priority                   = 1000
        protocol                   = "*"
        source_port_range          = "*"
        destination_port_range     = "*"
        source_address_prefix      = "*"
        destination_address_prefix = "*"
      }
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Field Investigation Tool"
    }
  }
}

import_network_security_group = {
  app    = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-app-fit-prod-canadacentral-001"
  oracle = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-oracle-fit-prod-canadacentral-001"
  pep    = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-pep-fit-prod-canadacentral-001"
}

network_security_rule_imports = {
  "app/allowonprem" = {
    nsg_key  = "app"
    rule_key = "allowonprem"
    id       = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-app-fit-prod-canadacentral-001/securityRules/AllowOnPrem"
  }
  "app/denyallinbound" = {
    nsg_key  = "app"
    rule_key = "denyallinbound"
    id       = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-app-fit-prod-canadacentral-001/securityRules/DenyAllInbound"
  }
  "app/allowhostedrunners" = {
    nsg_key  = "app"
    rule_key = "allowhostedrunners"
    id       = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-app-fit-prod-canadacentral-001/securityRules/AllowHostedRunners"
  }
  "app/allowinternalhealthping" = {
    nsg_key  = "app"
    rule_key = "allowinternalhealthping"
    id       = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-app-fit-prod-canadacentral-001/securityRules/AllowInternalHealthPing"
  }
  "oracle/allowonprem" = {
    nsg_key  = "oracle"
    rule_key = "allowonprem"
    id       = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-oracle-fit-prod-canadacentral-001/securityRules/AllowOnPrem"
  }
  "oracle/allowbastionhost" = {
    nsg_key  = "oracle"
    rule_key = "allowbastionhost"
    id       = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-oracle-fit-prod-canadacentral-001/securityRules/AllowBastionHost"
  }
  "oracle/cyberark_ssh" = {
    nsg_key  = "oracle"
    rule_key = "cyberark_ssh"
    id       = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-oracle-fit-prod-canadacentral-001/securityRules/cyberark-ssh"
  }
  "pep/allowonprem" = {
    nsg_key  = "pep"
    rule_key = "allowonprem"
    id       = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-pep-fit-prod-canadacentral-001/securityRules/AllowOnPrem"
  }
  "pep/denyallinbound" = {
    nsg_key  = "pep"
    rule_key = "denyallinbound"
    id       = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-pep-fit-prod-canadacentral-001/securityRules/DenyAllInbound"
  }
}

# Its VNet flow log stays unmanaged.
network_watcher = {
  canadacentral = {
    name               = "NetworkWatcher_canadacentral"
    resource_group_key = "network_watcher"
    location           = "canadacentral"
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Field Investigation Tool"
    }
  }
}

network_watcher_imports = {
  canadacentral = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/NetworkWatcherRG/providers/Microsoft.Network/networkWatchers/NetworkWatcher_canadacentral"
}

# Record sets are not managed.
private_dns_zone = {
  ase_appserviceenvironment_net = {
    name               = "ase-fit-prod-canadacentral-001.appserviceenvironment.net"
    resource_group_key = "app"
    virtual_network_links = {
      link_dns_connectivity_canadacentral_001 = {
        name                 = "link-dns-connectivity-canadacentral-001"
        virtual_network_id   = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dns-connectivity-canadacentral-001"
        registration_enabled = false
        resolution_policy    = "Default"
        tags = {
          ApplicationId           = "BCH – LIX -0000001397"
          ApplicationServiceLevel = "Silver"
          BusinessUnit            = "Customer & Corporate Affairs"
          CostCenterId            = "YT-01585.S.IMP.CLZ"
          Environment             = "Prod"
          Name                    = "Field Investigation Tool"
        }
      }
      link_runners_connectivity_canadacentral_001 = {
        name                 = "link-runners-connectivity-canadacentral-001"
        virtual_network_id   = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-runners-connectivity-canadacentral-001"
        registration_enabled = false
        resolution_policy    = "Default"
        tags = {
          ApplicationId           = "BCH – LIX -0000001397"
          ApplicationServiceLevel = "Silver"
          BusinessUnit            = "Customer & Corporate Affairs"
          CostCenterId            = "YT-01585.S.IMP.CLZ"
          Environment             = "Prod"
          Name                    = "Field Investigation Tool"
        }
      }
      vnetlink = {
        name                 = "vnetLink"
        virtual_network_id   = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-prod-canadacentral-001"
        registration_enabled = false
        resolution_policy    = "Default"
        tags = {
          ApplicationId           = "BCH – LIX -0000001397"
          ApplicationServiceLevel = "Silver"
          BusinessUnit            = "Customer & Corporate Affairs"
          CostCenterId            = "YT-01585.S.IMP.CLZ"
          Environment             = "Prod"
          Name                    = "Field Investigation Tool"
        }
      }
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Field Investigation Tool"
    }
  }
  privatelink_ase_appserviceenvironment_net = {
    name               = "privatelink.ase-fit-prod-canadacentral-001.appserviceenvironment.net"
    resource_group_key = "app"
    virtual_network_links = {
      "85bb8ff3319af" = {
        name                 = "85bb8ff3319af"
        virtual_network_id   = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-prod-canadacentral-001"
        registration_enabled = false
        resolution_policy    = "Default"
        tags = {
          ApplicationId           = "BCH – LIX -0000001397"
          ApplicationServiceLevel = "Silver"
          BusinessUnit            = "Customer & Corporate Affairs"
          CostCenterId            = "YT-01585.S.IMP.CLZ"
          Environment             = "Prod"
          Name                    = "Field Investigation Tool"
        }
      }
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Field Investigation Tool"
    }
  }
  privatelink_blob_core_windows_net = {
    name                  = "privatelink.blob.core.windows.net"
    resource_group_key    = "app"
    virtual_network_links = {}
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Field Investigation Tool"
    }
  }
}

private_dns_zone_imports = {
  ase_appserviceenvironment_net             = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/privateDnsZones/ase-fit-prod-canadacentral-001.appserviceenvironment.net"
  privatelink_ase_appserviceenvironment_net = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.ase-fit-prod-canadacentral-001.appserviceenvironment.net"
  privatelink_blob_core_windows_net         = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net"
}

private_dns_zone_link_imports = {
  "ase_appserviceenvironment_net/link_dns_connectivity_canadacentral_001" = {
    zone_key = "ase_appserviceenvironment_net"
    link_key = "link_dns_connectivity_canadacentral_001"
    id       = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/privateDnsZones/ase-fit-prod-canadacentral-001.appserviceenvironment.net/virtualNetworkLinks/link-dns-connectivity-canadacentral-001"
  }
  "ase_appserviceenvironment_net/link_runners_connectivity_canadacentral_001" = {
    zone_key = "ase_appserviceenvironment_net"
    link_key = "link_runners_connectivity_canadacentral_001"
    id       = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/privateDnsZones/ase-fit-prod-canadacentral-001.appserviceenvironment.net/virtualNetworkLinks/link-runners-connectivity-canadacentral-001"
  }
  "ase_appserviceenvironment_net/vnetlink" = {
    zone_key = "ase_appserviceenvironment_net"
    link_key = "vnetlink"
    id       = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/privateDnsZones/ase-fit-prod-canadacentral-001.appserviceenvironment.net/virtualNetworkLinks/vnetLink"
  }
  "privatelink_ase_appserviceenvironment_net/85bb8ff3319af" = {
    zone_key = "privatelink_ase_appserviceenvironment_net"
    link_key = "85bb8ff3319af"
    id       = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.ase-fit-prod-canadacentral-001.appserviceenvironment.net/virtualNetworkLinks/85bb8ff3319af"
  }
}

private_endpoint = {
  app = {
    enabled                         = false # target site no longer exists; connection is Disconnected
    name                            = "pep-app-fit-prod-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-prod-canadacentral-001/subnets/snet-pep-fit-prod-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Web/sites/app-fit-prod-canadacentral-001"
    private_service_connection_name = "app-fit-prod-canadacentral-001"
    subresource_names               = ["sites"]
    network_interface_name          = null
    private_dns_zone_group_name     = "fit_prod_canadacentral_app_zone_group"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.azurewebsites.net"
    ]
    ip_configurations = {}
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Field Investigation Tool"
    }
  }
  blob = {
    name                            = "pep-blob-fit-prod-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-prod-canadacentral-001/subnets/snet-pep-fit-prod-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Storage/storageAccounts/stfitprodcac001"
    private_service_connection_name = "stfitprodcac001"
    subresource_names               = ["blob"]
    network_interface_name          = null
    private_dns_zone_group_name     = "fit_prod_canadacentral_blob_zone_group"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net"
    ]
    ip_configurations = {}
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Field Investigation Tool"
    }
  }
  pep = {
    name                            = "pep-fit-prod-canadacentral"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-prod-canadacentral-001/subnets/snet-pep-fit-prod-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Web/sites/app-fit-prod"
    private_service_connection_name = "pep-fit-prod-canadacentral-a3a8"
    subresource_names               = ["sites"]
    network_interface_name          = null
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.ase-fit-prod-canadacentral-001.appserviceenvironment.net"
    ]
    ip_configurations = {}
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Field Investigation Tool"
    }
  }
  fit_restore = {
    name                            = "pep-fit-restore"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-prod-canadacentral-001/subnets/snet-pep-fit-prod-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourcegroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Storage/storageAccounts/stfitrestore"
    private_service_connection_name = "pep-fit-restore_7e9c96cf-f22e-4897-99d3-41578f108017"
    subresource_names               = ["blob"]
    network_interface_name          = null
    private_dns_zone_group_name     = null
    private_dns_zone_resource_ids   = []
    ip_configurations               = {}
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Field Investigation Tool"
    }
  }
  func = {
    enabled                         = false # target site no longer exists; connection is Disconnected
    name                            = "pep-func-fit-prod-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-prod-canadacentral-001/subnets/snet-pep-fit-prod-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Web/sites/func-fit-prod-canadacentral-001"
    private_service_connection_name = "func-fit-prod-canadacentral-001"
    subresource_names               = ["sites"]
    network_interface_name          = null
    private_dns_zone_group_name     = "fit_prod_canadacentral_func_zone_group"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.azurewebsites.net"
    ]
    ip_configurations = {}
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Field Investigation Tool"
    }
  }
  kv = {
    name                            = "pep-kv-fit-prod-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-prod-canadacentral-001/subnets/snet-pep-fit-prod-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvfitprodcac001"
    private_service_connection_name = "pep-kv-fit-prod-canadacentral-001"
    subresource_names               = ["vault"]
    network_interface_name          = "pep-kv-fit-prod-canadacentral-001-nic"
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.vaultcore.azure.net"
    ]
    ip_configurations = {
      pep_kv_fit_prod_canadacentral_001 = {
        name               = "pep-kv-fit-prod-canadacentral-001"
        private_ip_address = "10.195.34.4"
        subresource_name   = "vault"
        member_name        = "default"
      }
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Field Investigation Tool"
    }
  }
  stnwfitprdcac001xdf = {
    name                            = "pep-stnwfitprdcac001xdf"
    resource_group_key              = "network_watcher"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-prod-canadacentral-001/subnets/snet-pep-fit-prod-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/NetworkWatcherRG/providers/Microsoft.Storage/storageAccounts/stnwfitprdcac001xdf"
    private_service_connection_name = "pep-stnwfitprdcac001xdf"
    subresource_names               = ["blob"]
    network_interface_name          = "pep-stnwfitprdcac001xdf-nic"
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net"
    ]
    ip_configurations = {}
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Field Investigation Tool"
    }
  }
}

private_endpoint_imports = {
  app                 = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-app-fit-prod-canadacentral-001"
  blob                = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-blob-fit-prod-canadacentral-001"
  pep                 = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-fit-prod-canadacentral"
  fit_restore         = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-fit-restore"
  func                = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-func-fit-prod-canadacentral-001"
  kv                  = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-kv-fit-prod-canadacentral-001"
  stnwfitprdcac001xdf = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/NetworkWatcherRG/providers/Microsoft.Network/privateEndpoints/pep-stnwfitprdcac001xdf"
}

# Alert flags default to false so adoption does not switch alerting on;
# check monitoringSettings on the prod vault before import.
recovery_services_vault = {
  app = {
    name                          = "rsv-fit-prod-canadacentral-001"
    resource_group_key            = "app"
    location                      = "canadacentral"
    sku                           = "RS0"
    storage_mode_type             = "GeoRedundant"
    cross_region_restore_enabled  = false
    soft_delete_enabled           = true
    immutability                  = "Disabled"
    public_network_access_enabled = true
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Field Investigation Tool"
    }
  }
}

recovery_services_vault_imports = {
  app = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.RecoveryServices/vaults/rsv-fit-prod-canadacentral-001"
}

# Azure Backup owns these; only the containers are adopted.
restore_point_collection = {
  oracledb = {
    name                      = "AzureBackup_vm-oracledb-fit-prod-canadacentral-001_6310581016965731604"
    resource_group_name       = "AzureBackupRG_canadacentral_1"
    location                  = "canadacentral"
    source_virtual_machine_id = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/RG-FIT-APP-PROD-CANADACENTRAL-001/providers/Microsoft.Compute/virtualMachines/vm-oracledb-fit-prod-canadacentral-001"
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Field Investigation Tool"
    }
  }
}

restore_point_collection_imports = {
  oracledb = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/AzureBackupRG_canadacentral_1/providers/Microsoft.Compute/restorePointCollections/AzureBackup_vm-oracledb-fit-prod-canadacentral-001_6310581016965731604"
}

public_ssh_key = {
  oracle = {
    name               = "sshkey-oracle-fit-prod-canadacentral-001"
    resource_group_key = "app"
    location           = "canadacentral"
    public_key         = "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQCuXK3tEqzVCscxu652jksFIV79P7O5egHxZhhMHxLjmATFcAFs0W9tsg6aPhg5PJ6QQ2FDJVNJ8K9fVxaHYxdvqdIVyB5IF2E/8fLhLUFbTA/HDF7n8S6Diph49qucoA1rgQiZHcPjLHHmjsrz28MPYmGioOtXeriE5kDKNnvWugO8mC1E/DyJ8MN8q8VMGbB+YwwZ8T2VrNkQ3ly3hzb9KNm491t7E4NwQaUNcS+djGv/ivc6FsePyumTsAgI0z1Mc2qNFzFMnhnr3DxKFwn0eLDnDsHHV50c6VVq6y51+fEsqrSPIh1ghT9PoYUGubUlHHj3tGJd1kmje/rI9UxTGZdZDe95JzwZVDwCquAAmkySCKcvwWxv6aUOqeglPEYNgp98lxul7KcygmpN4oIurPvepCP873EwkuQ15TVL2EwzVDgRLrzftTAOREWDOEuqT01hOleseMBpP/jDjDYT2RF67rpQerMKyCmXWkBIfSQhjshoXlVJyXehVbIrHEk= generated-by-azure"
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Field Investigation Tool"
    }
  }
}

public_ssh_key_imports = {
  oracle = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Compute/sshPublicKeys/sshkey-oracle-fit-prod-canadacentral-001"
}

# blob_properties is left unset (no drift either way).
storage_account = {
  stfitrestore = {
    name                              = "stfitrestore"
    resource_group_key                = "app"
    location                          = "canadacentral"
    account_kind                      = "StorageV2"
    account_tier                      = "Standard"
    account_replication_type          = "LRS"
    access_tier                       = "Hot"
    allow_nested_items_to_be_public   = false
    cross_tenant_replication_enabled  = false
    default_to_oauth_authentication   = false
    https_traffic_only_enabled        = true
    infrastructure_encryption_enabled = false
    is_hns_enabled                    = false
    large_file_share_enabled          = true
    min_tls_version                   = "TLS1_2"
    public_network_access_enabled     = false
    sftp_enabled                      = false
    shared_access_key_enabled         = true
    network_rules = {
      bypass                     = ["AzureServices"]
      default_action             = "Deny"
      ip_rules                   = []
      virtual_network_subnet_ids = []
      private_link_access = [
        {
          endpoint_resource_id = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/providers/Microsoft.Security/datascanners/StorageDataScanner"
          endpoint_tenant_id   = "8fbb85e8-0cbc-48c3-a2e9-528cef30ec27"
        }
      ]
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Field Investigation Tool"
    }
  }
  stnwfitprdcac001xdf = {
    name                              = "stnwfitprdcac001xdf"
    resource_group_key                = "network_watcher"
    location                          = "canadacentral"
    account_kind                      = "StorageV2"
    account_tier                      = "Standard"
    account_replication_type          = "LRS"
    access_tier                       = "Hot"
    allow_nested_items_to_be_public   = false
    cross_tenant_replication_enabled  = false
    default_to_oauth_authentication   = false
    https_traffic_only_enabled        = true
    infrastructure_encryption_enabled = false
    is_hns_enabled                    = false
    min_tls_version                   = "TLS1_2"
    public_network_access_enabled     = false
    sftp_enabled                      = false
    shared_access_key_enabled         = true
    network_rules = {
      bypass                     = ["AzureServices"]
      default_action             = "Deny"
      ip_rules                   = []
      virtual_network_subnet_ids = []
      private_link_access = [
        {
          endpoint_resource_id = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/providers/Microsoft.Security/datascanners/StorageDataScanner"
          endpoint_tenant_id   = "8fbb85e8-0cbc-48c3-a2e9-528cef30ec27"
        }
      ]
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Field Investigation Tool"
    }
  }
}

# Public network access is enabled on these, and Deny_Public_Access_On_PaaS_Services_v0
# denies any write to them, so they are read, not adopted, until exempted.
storage_account_existing = {
  stfitprodcac001 = {
    name               = "stfitprodcac001"
    resource_group_key = "app"
  }
}

storage_account_imports = {
  stfitrestore        = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Storage/storageAccounts/stfitrestore"
  stnwfitprdcac001xdf = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/NetworkWatcherRG/providers/Microsoft.Storage/storageAccounts/stnwfitprdcac001xdf"
}

user_assigned_identity = {
  app = {
    name               = "mid-fit-prod-canadacentral-001"
    resource_group_key = "mid_app"
    location           = "canadacentral"
    isolation_scope    = null
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Field Investigation Tool"
    }
  }
}

user_assigned_identity_imports = {
  app = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-mid-fit-app-prod-canadacentral-001/providers/Microsoft.ManagedIdentity/userAssignedIdentities/mid-fit-prod-canadacentral-001"
}

# VM NICs; private endpoint NICs belong to their endpoint.
network_interface = {
  vm_oracledb = {
    name                           = "nic-vm-oracledb-fit-prod-canadacentral-001"
    resource_group_key             = "app"
    location                       = "canadacentral"
    enabled                        = true
    accelerated_networking_enabled = true
    ip_forwarding_enabled          = false
    ip_configurations = {
      primary = {
        name                          = "internal"
        primary                       = true
        private_ip_address            = "10.195.33.4"
        private_ip_address_allocation = "Static"
        subnet_id                     = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-prod-canadacentral-001/subnets/snet-oracle-fit-prod-canadacentral-001"
      }
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Field Investigation Tool"
    }
  }
}

network_interface_nsg_associations = {}

# Staged: adopted in its own run (see README).
linux_virtual_machine = {
  oracledb = {
    name               = "vm-oracledb-fit-prod-canadacentral-001"
    resource_group_key = "app"
    location           = "canadacentral"
    size               = "Standard_D8s_v5"
    zone               = "1"
    admin_username     = "azoracleuser"
    computer_name      = "ocdbprodcac"
    network_interface_ids = [
      "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/networkInterfaces/nic-vm-oracledb-fit-prod-canadacentral-001"
    ]
    os_managed_disk_id         = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Compute/disks/vmoracledbfitprodcanadacentral-osdisk-20260213-235310"
    allow_extension_operations = true
    admin_ssh_public_keys = [
      "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQCuXK3tEqzVCscxu652jksFIV79P7O5egHxZhhMHxLjmATFcAFs0W9tsg6aPhg5PJ6QQ2FDJVNJ8K9fVxaHYxdvqdIVyB5IF2E/8fLhLUFbTA/HDF7n8S6Diph49qucoA1rgQiZHcPjLHHmjsrz28MPYmGioOtXeriE5kDKNnvWugO8mC1E/DyJ8MN8q8VMGbB+YwwZ8T2VrNkQ3ly3hzb9KNm491t7E4NwQaUNcS+djGv/ivc6FsePyumTsAgI0z1Mc2qNFzFMnhnr3DxKFwn0eLDnDsHHV50c6VVq6y51+fEsqrSPIh1ghT9PoYUGubUlHHj3tGJd1kmje/rI9UxTGZdZDe95JzwZVDwCquAAmkySCKcvwWxv6aUOqeglPEYNgp98lxul7KcygmpN4oIurPvepCP873EwkuQ15TVL2EwzVDgRLrzftTAOREWDOEuqT01hOleseMBpP/jDjDYT2RF67rpQerMKyCmXWkBIfSQhjshoXlVJyXehVbIrHEk= generated-by-azure"
    ]
    bypass_platform_safety_checks_on_user_schedule_enabled = true
    disk_controller_type                                   = "SCSI"
    encryption_at_host_enabled                             = false
    license_type                                           = "RHEL_BYOS"
    patch_assessment_mode                                  = "AutomaticByPlatform"
    patch_mode                                             = "AutomaticByPlatform"
    provision_vm_agent                                     = true
    secure_boot_enabled                                    = true
    vtpm_enabled                                           = true
    additional_capabilities = {
      hibernation_enabled = false
    }
    boot_diagnostics = {}
    identity = {
      type                       = "SystemAssigned"
      user_assigned_identity_ids = []
    }
    os_disk = {
      name                 = "vmoracledbfitprodcanadacentral-osdisk-20260213-235310"
      caching              = "ReadWrite"
      disk_size_gb         = 64
      storage_account_type = "Premium_ZRS"
    }
    source_image_reference = {
      publisher = "RedHat"
      offer     = "RHEL"
      sku       = "810-gen2"
      version   = "8.10.2025052607"
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Field Investigation Tool"
    }
  }
}

linux_virtual_machine_imports = {
  oracledb = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-oracledb-fit-prod-canadacentral-001"
}

# Staged: the module rewrites the full app settings on apply; the masked settings
# must be Key Vault references or real sensitive values first (see README).
web_app = {
  app = {
    name                                     = "app-fit-prod"
    resource_group_key                       = "app"
    location                                 = "canadacentral"
    os_type                                  = "Windows"
    app_service_plan_key                     = "app"
    app_service_environment_key              = "app"
    enabled                                  = true
    https_only                               = true
    public_network_access_enabled            = true
    client_affinity_enabled                  = true
    client_affinity_proxy_enabled            = false
    client_certificate_enabled               = false
    client_certificate_mode                  = "Required"
    end_to_end_encryption_enabled            = false
    host_names_disabled                      = false
    hyper_v                                  = false
    ip_mode                                  = "IPv4"
    redundancy_mode                          = "None"
    vnet_route_all_traffic                   = false
    vnet_application_traffic_enabled         = false
    vnet_content_share_enabled               = true
    vnet_image_pull_enabled                  = true
    virtual_network_backup_restore_enabled   = false
    ftp_publish_basic_authentication_enabled = false
    scm_publish_basic_authentication_enabled = true
    user_assigned_identity_ids = [
      "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-mid-fit-app-prod-canadacentral-001/providers/Microsoft.ManagedIdentity/userAssignedIdentities/mid-fit-prod-canadacentral-001"
    ]
    key_vault_reference_identity = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-mid-fit-app-prod-canadacentral-001/providers/Microsoft.ManagedIdentity/userAssignedIdentities/mid-fit-prod-canadacentral-001"
    site_config = {
      always_on = true
      default_documents = [
        "Default.htm",
        "Default.html",
        "Default.asp",
        "index.htm",
        "index.html",
        "iisstart.htm",
        "default.aspx",
        "index.php",
        "hostingstart.html",
        "index.aspx"
      ]
      detailed_error_logging_enabled = true
      elastic_web_app_scale_limit    = 0
      elastic_instance_minimum       = 1
      experiments = {
        ramp_up_rules = []
      }
      ftps_state           = "FtpsOnly"
      http2_enabled        = false
      http20_proxy_flag    = 0
      http_logging_enabled = true
      ip_restriction = [
        {
          action     = "Allow"
          ip_address = "10.195.115.7/32,10.195.114.7/32"
          name       = "allowRunners"
          priority   = 100
        },
        {
          action     = "Allow"
          ip_address = "10.242.93.12/32,10.242.93.13/32,10.242.93.16/32,10.242.93.17/32"
          name       = "allowESB"
          priority   = 200
        }
      ]
      ip_restriction_default_action     = "Deny"
      load_balancing_mode               = "LeastRequests"
      local_mysql_enabled               = false
      logs_directory_size_limit         = 35
      managed_pipeline_mode             = "Integrated"
      minimum_tls_version               = "1.2"
      scm_minimum_tls_version           = "1.2"
      worker_count                      = 1
      pre_warmed_instance_count         = 0
      remote_debugging_enabled          = false
      remote_debugging_version          = "VS2022"
      request_tracing_enabled           = true
      request_tracing_expiration_time   = "9999-12-31T23:59:00Z"
      scm_ip_restriction                = []
      scm_ip_restriction_default_action = "Allow"
      scm_use_main_ip_restriction       = false
      use_32_bit_worker                 = true
      virtual_application = [
        {
          physical_path     = "site\\wwwroot"
          preload_enabled   = true
          virtual_path      = "/"
          virtual_directory = []
        },
        {
          physical_path     = "site\\wwwroot\\FITMobile"
          preload_enabled   = false
          virtual_path      = "/FIT_LITE"
          virtual_directory = []
        },
        {
          physical_path     = "site\\wwwroot\\FIT_WS"
          preload_enabled   = false
          virtual_path      = "/FIT_WS"
          virtual_directory = []
        }
      ]
      vnet_private_ports_count                = 0
      vnet_route_all_enabled                  = false
      websockets_enabled                      = false
      website_time_zone                       = "Pacific Standard Time"
      container_registry_use_managed_identity = false
      metadata = [
        {
          name  = "CURRENT_STACK"
          value = "dotnet"
        }
      ]
      linux_fx_version         = null
      app_command_line         = null
      dotnet_framework_version = "v4.0"
    }
    app_settings = {
      AllowableMeterTypes                             = "P261, P263, P264, P710, P716, P717, P860, P910, P916, P917, P960, P963, P967, P968, P363, P364, P973, P978"
      APPINSIGHTS_PROFILERFEATURE_VERSION             = "1.0.0"
      APPINSIGHTS_SNAPSHOTFEATURE_VERSION             = "1.0.0"
      ApplicationInsightsAgent_EXTENSION_VERSION      = "~2"
      ApplicationName                                 = "FIT"
      DateFormat                                      = "yyyy/MM/dd"
      DateTimeFormat                                  = "yyyy/MM/dd HH:mm"
      DateTimeFormat_WithSeconds                      = "yyyy/MM/dd HH:mm:ss"
      DiagnosticServices_EXTENSION_VERSION            = "~3"
      DisallowedMeterTypesMsg                         = "The Meter {0} is currently not supported in FIT, as the Meter Type is {1} ({2})."
      ESB_PASSWORD                                    = "@Microsoft.KeyVault(SecretUri=https://kvfitprodcac001.vault.azure.net/secrets/ESB-PASSWORD)"
      ESBPassword                                     = "@Microsoft.KeyVault(SecretUri=https://kvfitprodcac001.vault.azure.net/secrets/ESB-PASSWORD-FIT-to-ESB)"
      FITLiteURL                                      = "https://fit.internal.bchydro.bc.ca/fit_lite/"
      FITWSAddress                                    = "https://fit.internal.bchydro.bc.ca/FIT_WS/SaveMeterRead.asmx"
      "ida:AADInstance"                               = "https://login.microsoftonline.com/{0}/v2.0"
      "ida:ClientId"                                  = "996998f7-5db5-4c15-b85f-fad2caecda52"
      "ida:ClientSecret"                              = "@Microsoft.KeyVault(SecretUri=https://kvfitprodcac001.vault.azure.net/secrets/CLIENT-SECRET)"
      "ida:RedirectUri"                               = "https://fit.internal.bchydro.bc.ca/signin-oidc"
      "ida:TenantId"                                  = "8fbb85e8-0cbc-48c3-a2e9-528cef30ec27"
      InstrumentationEngine_EXTENSION_VERSION         = "disabled"
      LogFileName                                     = "Log - {0}.log"
      LogTraceEvents                                  = "true"
      MaxFitCaseMeters                                = "4"
      MaxSearchResults                                = "50"
      NegativeRegisters                               = "Instantaneous Watts Received Phase A,Instantaneous Watts Received Aggregate"
      SnapshotDebugger_EXTENSION_VERSION              = "disabled"
      WEBSITE_LOAD_ROOT_CERTIFICATES                  = "28F13DD5EDF3288CF7DC8D2B8C5963C0041FCEE2,FEDE578F45A1C9568AEA73F512E3F633B2906D53"
      WEBSITE_TIME_ZONE                               = "Pacific Standard Time"
      WEBSITE_VNET_ROUTE_ALL                          = "1"
      XDT_MicrosoftApplicationInsights_BaseExtensions = "disabled"
      XDT_MicrosoftApplicationInsights_Java           = "1"
      XDT_MicrosoftApplicationInsights_Mode           = "recommended"
      XDT_MicrosoftApplicationInsights_NodeJS         = "1"
      XDT_MicrosoftApplicationInsights_PreemptSdk     = "disabled"
    }
    secret_app_setting_names = ["APPLICATIONINSIGHTS_CONNECTION_STRING", "ESBUserName", "ESB_USER"]
    connection_strings = {
      connectionstring = {
        name = "ConnectionString"
        type = "Custom"
      }
    }
    sticky_app_setting_names = [
      "APPINSIGHTS_PROFILERFEATURE_VERSION",
      "APPINSIGHTS_SNAPSHOTFEATURE_VERSION",
      "ApplicationInsightsAgent_EXTENSION_VERSION",
      "DiagnosticServices_EXTENSION_VERSION",
      "InstrumentationEngine_EXTENSION_VERSION",
      "SnapshotDebugger_EXTENSION_VERSION",
      "XDT_MicrosoftApplicationInsights_BaseExtensions",
      "XDT_MicrosoftApplicationInsights_Mode",
      "XDT_MicrosoftApplicationInsights_NodeJS",
      "XDT_MicrosoftApplicationInsights_PreemptSdk"
    ]
    tags = {
      ApplicationId                            = "BCH – LIX -0000001397"
      ApplicationServiceLevel                  = "Silver"
      BusinessUnit                             = "Customer & Corporate Affairs"
      CostCenterId                             = "YT-01585.S.IMP.CLZ"
      Environment                              = "Prod"
      Name                                     = "Field Investigation Tool"
      "hidden-link: /app-insights-resource-id" = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/microsoft.insights/components/ai-func-fit-prod-canadacentral-001"
    }
  }
}

web_app_imports = {
  app = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Web/sites/app-fit-prod"
}

# Staged: the vWAN hub connection is owned by tf-deploy-platform-connectivity.
# defaultOutboundAccess is not reported, so Azure's default (enabled) is assumed.
virtual_network = {
  app = {
    name               = "vnet-fit-prod-canadacentral-001"
    resource_group_key = "app"
    location           = "canadacentral"
    address_space      = ["10.195.32.0/22"]
    ddos_protection_plan = {
      enable = true
      id     = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/ddosProtectionPlans/ddos-protection-plan"
    }
    subnets = {
      oracle = {
        name                                          = "snet-oracle-fit-prod-canadacentral-001"
        address_prefixes                              = ["10.195.33.0/26"]
        default_outbound_access_enabled               = true
        private_endpoint_network_policies             = "Disabled"
        private_link_service_network_policies_enabled = true
        network_security_group = {
          id = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-oracle-fit-prod-canadacentral-001"
        }
        service_endpoint_policies = {}
        service_endpoints_with_location = [
          {
            service   = "Microsoft.Storage"
            locations = ["canadacentral", "canadaeast"]
          }
        ]
        delegations = []
      }
      app = {
        name                                          = "snet-app-fit-prod-canadacentral-001"
        address_prefixes                              = ["10.195.32.0/24"]
        default_outbound_access_enabled               = true
        private_endpoint_network_policies             = "Disabled"
        private_link_service_network_policies_enabled = true
        network_security_group = {
          id = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-app-fit-prod-canadacentral-001"
        }
        service_endpoint_policies = {}
        service_endpoints_with_location = [
          {
            service   = "Microsoft.KeyVault"
            locations = ["*"]
          }
        ]
        delegations = [
          {
            name = "Microsoft.Web/hostingEnvironments"
            service_delegation = {
              name    = "Microsoft.Web/hostingEnvironments"
              actions = ["Microsoft.Network/virtualNetworks/subnets/action"]
            }
          }
        ]
      }
      pep = {
        name                                          = "snet-pep-fit-prod-canadacentral-001"
        address_prefixes                              = ["10.195.34.0/24"]
        default_outbound_access_enabled               = true
        private_endpoint_network_policies             = "RouteTableEnabled"
        private_link_service_network_policies_enabled = true
        network_security_group = {
          id = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-pep-fit-prod-canadacentral-001"
        }
        service_endpoint_policies = {}
        service_endpoints_with_location = [
          {
            service   = "Microsoft.KeyVault"
            locations = ["*"]
          }
        ]
        delegations = []
      }
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001397"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Customer & Corporate Affairs"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Field Investigation Tool"
    }
  }
}

virtual_network_imports = {
  app = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-prod-canadacentral-001"
}

virtual_network_subnet_imports = {
  fit_oracle = {
    vnet_key   = "app"
    subnet_key = "oracle"
    id         = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-prod-canadacentral-001/subnets/snet-oracle-fit-prod-canadacentral-001"
  }
  fit_app = {
    vnet_key   = "app"
    subnet_key = "app"
    id         = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-prod-canadacentral-001/subnets/snet-app-fit-prod-canadacentral-001"
  }
  fit_pep = {
    vnet_key   = "app"
    subnet_key = "pep"
    id         = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-prod-canadacentral-001/subnets/snet-pep-fit-prod-canadacentral-001"
  }
}

# =====================================================================
# Hub private DNS: links and records in the shared zones (connectivity subscription)
# =====================================================================

enable_hub_private_dns = true

hub_private_dns_zone_link = {
  "bchydro.bc.ca/link-fit-prod-canadacentral-001" = {
    name               = "link-fit-prod-canadacentral-001"
    zone_name          = "bchydro.bc.ca"
    virtual_network_id = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-prod-canadacentral-001"
  }
  "internal.bchydro.bc.ca/link-fit-prod-canadacentral-001" = {
    name               = "link-fit-prod-canadacentral-001"
    zone_name          = "internal.bchydro.bc.ca"
    virtual_network_id = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-prod-canadacentral-001"
  }
  "link-blob-fit-prod-canadacentral-001" = {
    name               = "link-blob-fit-prod-canadacentral-001"
    zone_name          = "privatelink.blob.core.windows.net"
    virtual_network_id = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-prod-canadacentral-001"
  }
  "link-sites-fit-prod-canadacentral-001" = {
    name               = "link-sites-fit-prod-canadacentral-001"
    zone_name          = "privatelink.azurewebsites.net"
    virtual_network_id = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-prod-canadacentral-001"
  }
  "link-vault-fit-prod-canadacentral-001" = {
    name               = "link-vault-fit-prod-canadacentral-001"
    zone_name          = "privatelink.vaultcore.azure.net"
    virtual_network_id = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-prod-canadacentral-001"
  }
  "privatelink.agentsvc.azure-automation.net/link-fit-prod-canadacentral" = {
    name               = "link-fit-prod-canadacentral"
    zone_name          = "privatelink.agentsvc.azure-automation.net"
    virtual_network_id = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-prod-canadacentral-001"
  }
  "privatelink.monitor.azure.com/link-fit-prod-canadacentral" = {
    name               = "link-fit-prod-canadacentral"
    zone_name          = "privatelink.monitor.azure.com"
    virtual_network_id = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-prod-canadacentral-001"
  }
  "privatelink.ods.opinsights.azure.com/link-fit-prod-canadacentral" = {
    name               = "link-fit-prod-canadacentral"
    zone_name          = "privatelink.ods.opinsights.azure.com"
    virtual_network_id = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-prod-canadacentral-001"
  }
  "privatelink.oms.opinsights.azure.com/link-fit-prod-canadacentral" = {
    name               = "link-fit-prod-canadacentral"
    zone_name          = "privatelink.oms.opinsights.azure.com"
    virtual_network_id = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-prod-canadacentral-001"
  }
}

hub_private_dns_zone_link_imports = {
  "bchydro.bc.ca/link-fit-prod-canadacentral-001"                         = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/bchydro.bc.ca/virtualNetworkLinks/link-fit-prod-canadacentral-001"
  "internal.bchydro.bc.ca/link-fit-prod-canadacentral-001"                = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/internal.bchydro.bc.ca/virtualNetworkLinks/link-fit-prod-canadacentral-001"
  "link-blob-fit-prod-canadacentral-001"                                  = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net/virtualNetworkLinks/link-blob-fit-prod-canadacentral-001"
  "link-sites-fit-prod-canadacentral-001"                                 = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.azurewebsites.net/virtualNetworkLinks/link-sites-fit-prod-canadacentral-001"
  "link-vault-fit-prod-canadacentral-001"                                 = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.vaultcore.azure.net/virtualNetworkLinks/link-vault-fit-prod-canadacentral-001"
  "privatelink.agentsvc.azure-automation.net/link-fit-prod-canadacentral" = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.agentsvc.azure-automation.net/virtualNetworkLinks/link-fit-prod-canadacentral"
  "privatelink.monitor.azure.com/link-fit-prod-canadacentral"             = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.monitor.azure.com/virtualNetworkLinks/link-fit-prod-canadacentral"
  "privatelink.ods.opinsights.azure.com/link-fit-prod-canadacentral"      = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.ods.opinsights.azure.com/virtualNetworkLinks/link-fit-prod-canadacentral"
  "privatelink.oms.opinsights.azure.com/link-fit-prod-canadacentral"      = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.oms.opinsights.azure.com/virtualNetworkLinks/link-fit-prod-canadacentral"
}

hub_private_dns_a_record = {
  "fit" = {
    name      = "fit"
    zone_name = "internal.bchydro.bc.ca"
    ttl       = 10
    records   = ["10.195.34.8"]
  }
  "vm-oracledb-fit-prod-canadacentral-001" = {
    name      = "vm-oracledb-fit-prod-canadacentral-001"
    zone_name = "internal.bchydro.bc.ca"
    ttl       = 10
    records   = ["10.195.33.4"]
  }
}

hub_private_dns_a_record_imports = {
  "fit"                                    = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/internal.bchydro.bc.ca/A/fit"
  "vm-oracledb-fit-prod-canadacentral-001" = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/internal.bchydro.bc.ca/A/vm-oracledb-fit-prod-canadacentral-001"
}
