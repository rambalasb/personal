variable "subscription_id" {
  type        = string
  description = "Azure subscription this environment adopts resources into."

  validation {
    condition     = can(regex("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$", var.subscription_id))
    error_message = "subscription_id must be an Azure subscription UUID."
  }
}

variable "enable_resource_group" {
  type        = bool
  description = "Whether Terraform manages and imports the existing resource groups."
  default     = false
}

variable "resource_group" {
  type = map(object({
    name     = string
    location = string
    lock = optional(object({
      kind = string
      name = optional(string)
    }))
    managed_by = optional(string)
    tags       = optional(map(string), {})
  }))
  description = "Existing resource groups to adopt, keyed by stable instance roles."
  default     = {}
}

variable "import_resource_group" {
  type        = map(string)
  description = "Existing resource group IDs, keyed by the matching resource_group instance."
  default     = {}

  validation {
    condition = alltrue([
      for group_key, resource_id in var.import_resource_group :
      resource_id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[group_key].name, "")}"
    ])
    error_message = "Each import_resource_group entry must match its resource_group key, name and subscription_id."
  }
}

variable "enable_monitoring" {
  type        = bool
  description = "Whether Terraform manages and imports the existing monitoring alerts."
  default     = false
}

variable "alert" {
  type = object({
    resource_group_key         = string
    root_management_group_name = optional(string)
    tags                       = optional(map(string), {})
    activity_log_alerts = optional(map(object({
      name                = string
      resource_group_name = string
      scopes              = list(string)
      location            = optional(string, "global")
      description         = optional(string)
      enabled             = optional(bool, true)
      criteria = object({
        category                = string
        operation_name          = optional(string)
        resource_provider       = optional(string)
        resource_type           = optional(string)
        resource_group          = optional(string)
        resource_id             = optional(string)
        caller                  = optional(string)
        level                   = optional(string)
        status                  = optional(string)
        sub_status              = optional(string)
        recommendation_category = optional(string)
        recommendation_impact   = optional(string)
        recommendation_type     = optional(string)
        service_health = optional(object({
          events    = optional(list(string))
          locations = optional(list(string))
          services  = optional(list(string))
        }))
        resource_health = optional(object({
          current  = optional(list(string))
          previous = optional(list(string))
          reason   = optional(list(string))
        }))
      })
      action_group_keys  = optional(list(string), [])
      action_group_ids   = optional(list(string), [])
      webhook_properties = optional(map(string), {})
      tags               = optional(map(string), {})
    })), {})
    metric_alerts = optional(map(object({
      name                     = string
      resource_group_name      = string
      scopes                   = list(string)
      description              = optional(string)
      enabled                  = optional(bool, true)
      auto_mitigate            = optional(bool, true)
      frequency                = optional(string, "PT1M")
      window_size              = optional(string, "PT5M")
      severity                 = optional(number, 3)
      target_resource_type     = optional(string)
      target_resource_location = optional(string)
      criteria = optional(list(object({
        metric_namespace       = string
        metric_name            = string
        aggregation            = string
        operator               = string
        threshold              = number
        skip_metric_validation = optional(bool, false)
        dimensions = optional(list(object({
          name     = string
          operator = string
          values   = list(string)
        })), [])
      })), [])
      dynamic_criteria = optional(object({
        metric_namespace         = string
        metric_name              = string
        aggregation              = string
        operator                 = string
        alert_sensitivity        = string
        evaluation_total_count   = optional(number)
        evaluation_failure_count = optional(number)
        ignore_data_before       = optional(string)
        skip_metric_validation   = optional(bool, false)
        dimensions = optional(list(object({
          name     = string
          operator = string
          values   = list(string)
        })), [])
      }))
      action_group_ids   = optional(list(string), [])
      webhook_properties = optional(map(string), {})
      tags               = optional(map(string), {})
    })), {})
    log_search_alerts = optional(map(object({
      name                              = string
      resource_group_name               = string
      location                          = string
      scopes                            = list(string)
      severity                          = optional(number, 3)
      evaluation_frequency              = optional(string, "PT5M")
      window_duration                   = optional(string, "PT5M")
      description                       = optional(string)
      display_name                      = optional(string)
      enabled                           = optional(bool, true)
      auto_mitigation_enabled           = optional(bool, false)
      skip_query_validation             = optional(bool, false)
      mute_actions_after_alert_duration = optional(string)
      query_time_range_override         = optional(string)
      target_resource_types             = optional(list(string))
      criteria = list(object({
        query                   = string
        time_aggregation_method = string
        threshold               = number
        operator                = string
        resource_id_column      = optional(string)
        metric_measure_column   = optional(string)
        dimensions = optional(list(object({
          name     = string
          operator = string
          values   = list(string)
        })), [])
        failing_periods = optional(object({
          minimum_failing_periods_to_trigger_alert = number
          number_of_evaluation_periods             = number
        }))
      }))
      action_group_ids  = optional(list(string), [])
      custom_properties = optional(map(string), {})
      email_subject     = optional(string)
      tags              = optional(map(string), {})
    })), {})
    alert_processing_rules = optional(map(object({
      name                = string
      resource_group_name = string
      scopes              = list(string)
      type                = optional(string, "suppression")
      description         = optional(string)
      enabled             = optional(bool, true)
      action_group_ids    = optional(list(string), [])
      conditions = optional(map(object({
        operator = string
        values   = list(string)
      })), {})
      schedule = optional(object({
        effective_from  = optional(string)
        effective_until = optional(string)
        time_zone       = optional(string)
        recurrence = optional(object({
          daily = optional(list(object({
            start_time = string
            end_time   = string
          })), [])
          weekly = optional(list(object({
            days_of_week = list(string)
            start_time   = optional(string)
            end_time     = optional(string)
          })), [])
          monthly = optional(list(object({
            days_of_month = list(number)
            start_time    = optional(string)
            end_time      = optional(string)
          })), [])
        }))
      }))
      tags = optional(map(string), {})
    })), {})
  })
  description = "Existing alerts passed to the shared monitoring wrapper: activity log, metric, log search and alert processing rules."
  default = {
    resource_group_key = "alerts"
  }

  validation {
    condition     = !var.enable_monitoring || (var.enable_resource_group && contains(keys(var.resource_group), var.alert.resource_group_key))
    error_message = "Monitoring requires enabled resource groups and a valid alert.resource_group_key."
  }
}

variable "activity_log_alert_imports" {
  type        = map(string)
  description = "Existing activity log alert IDs, keyed by the matching alert.activity_log_alerts instance."
  default     = {}

  validation {
    condition = alltrue([
      for alert_key, resource_id in var.activity_log_alert_imports :
      resource_id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.alert.activity_log_alerts[alert_key].resource_group_name, "")}/providers/Microsoft.Insights/activityLogAlerts/${try(var.alert.activity_log_alerts[alert_key].name, "")}"
    ])
    error_message = "Each activity_log_alert_imports entry must match its alert key, name, resource group and subscription_id."
  }
}

variable "metric_alert_imports" {
  type        = map(string)
  description = "Existing metric alert IDs, keyed by the matching alert.metric_alerts instance."
  default     = {}

  validation {
    condition = alltrue([
      for alert_key, resource_id in var.metric_alert_imports :
      lower(resource_id) == lower("/subscriptions/${var.subscription_id}/resourceGroups/${try(var.alert.metric_alerts[alert_key].resource_group_name, "")}/providers/Microsoft.Insights/metricAlerts/${try(var.alert.metric_alerts[alert_key].name, "")}")
    ])
    error_message = "Each metric_alert_imports entry must match its alert key, name, resource group and subscription_id."
  }
}

variable "log_search_alert_imports" {
  type        = map(string)
  description = "Existing scheduled query rule IDs, keyed by the matching alert.log_search_alerts instance."
  default     = {}

  validation {
    condition = alltrue([
      for alert_key, resource_id in var.log_search_alert_imports :
      lower(resource_id) == lower("/subscriptions/${var.subscription_id}/resourceGroups/${try(var.alert.log_search_alerts[alert_key].resource_group_name, "")}/providers/Microsoft.Insights/scheduledQueryRules/${try(var.alert.log_search_alerts[alert_key].name, "")}")
    ])
    error_message = "Each log_search_alert_imports entry must match its alert key, name, resource group and subscription_id."
  }
}

variable "alert_processing_rule_imports" {
  type        = map(string)
  description = "Existing alert processing rule IDs, keyed by the matching alert.alert_processing_rules instance."
  default     = {}

  validation {
    condition = alltrue([
      for rule_key, resource_id in var.alert_processing_rule_imports :
      lower(resource_id) == lower("/subscriptions/${var.subscription_id}/resourceGroups/${try(var.alert.alert_processing_rules[rule_key].resource_group_name, "")}/providers/Microsoft.AlertsManagement/actionRules/${try(var.alert.alert_processing_rules[rule_key].name, "")}")
    ])
    error_message = "Each alert_processing_rule_imports entry must match its rule key, name, resource group and subscription_id."
  }
}

variable "enable_event_grid_system_topic" {
  type        = bool
  description = "Whether Terraform manages and imports the existing Event Grid system topics."
  default     = false
}

variable "event_grid_system_topic" {
  type = map(object({
    name                        = string
    resource_group_key          = string
    location                    = optional(string)
    topic_type                  = string
    source_resource_id          = optional(string)
    exported_source_resource_id = string
    tags                        = optional(map(string), {})
  }))
  description = "Existing system topics to adopt directly; leave the ForceNew source unset and verify exported source inventory after import."
  default     = {}

  validation {
    condition = alltrue([
      for topic in values(var.event_grid_system_topic) :
      contains(keys(var.resource_group), topic.resource_group_key) && (!var.enable_event_grid_system_topic || var.enable_resource_group)
    ])
    error_message = "Each system topic must reference a managed resource group, enabled when topic adoption is enabled."
  }
}

variable "event_grid_system_topic_imports" {
  type        = map(string)
  description = "Existing system topic IDs, keyed by the matching event_grid_system_topic instance."
  default     = {}

  validation {
    condition = alltrue([
      for topic_key, resource_id in var.event_grid_system_topic_imports :
      resource_id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[var.event_grid_system_topic[topic_key].resource_group_key].name, "")}/providers/Microsoft.EventGrid/systemTopics/${try(var.event_grid_system_topic[topic_key].name, "")}"
    ])
    error_message = "Each event_grid_system_topic_imports entry must match its topic key, name, resource group and subscription_id."
  }
}

variable "enable_network_watcher" {
  type        = bool
  description = "Whether Terraform manages and imports the existing Network Watchers."
  default     = false
}

variable "network_watcher" {
  type = map(object({
    name               = string
    resource_group_key = string
    location           = optional(string)
    tags               = optional(map(string), {})
  }))
  description = "Existing Network Watchers to adopt directly with AzureRM."
  default     = {}

  validation {
    condition = alltrue([
      for watcher in values(var.network_watcher) :
      contains(keys(var.resource_group), watcher.resource_group_key) && (!var.enable_network_watcher || var.enable_resource_group)
    ])
    error_message = "Each Network Watcher must reference a managed resource group, enabled when watcher adoption is enabled."
  }
}

variable "network_watcher_imports" {
  type        = map(string)
  description = "Existing Network Watcher IDs, keyed by the matching network_watcher instance."
  default     = {}

  validation {
    condition = alltrue([
      for watcher_key, resource_id in var.network_watcher_imports :
      resource_id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[var.network_watcher[watcher_key].resource_group_key].name, "")}/providers/Microsoft.Network/networkWatchers/${try(var.network_watcher[watcher_key].name, "")}"
    ])
    error_message = "Each network_watcher_imports entry must match its watcher key, name, resource group and subscription_id."
  }
}

variable "enable_private_endpoint" {
  type        = bool
  description = "Whether Terraform manages and imports the existing private endpoints."
  default     = false
}

variable "private_endpoint" {
  type = map(object({
    enabled                         = optional(bool, true)
    name                            = string
    resource_group_key              = string
    location                        = optional(string)
    subnet_resource_id              = string
    private_connection_resource_id  = string
    private_service_connection_name = optional(string)
    subresource_names               = optional(list(string))
    network_interface_name          = optional(string)
    private_dns_zone_group_name     = optional(string)
    private_dns_zone_resource_ids   = optional(list(string), [])
    ip_configurations = optional(map(object({
      name               = string
      private_ip_address = string
      subresource_name   = string
      member_name        = optional(string, "default")
    })), {})
    tags = optional(map(string), {})
  }))
  description = "Existing private endpoints to adopt, owning their generated NICs."
  default     = {}

  validation {
    condition = alltrue([
      for endpoint in values(var.private_endpoint) :
      contains(keys(var.resource_group), endpoint.resource_group_key) && (!var.enable_private_endpoint || !endpoint.enabled || var.enable_resource_group)
    ])
    error_message = "Each endpoint must reference a managed resource group, enabled when that endpoint is managed."
  }
}

variable "private_endpoint_imports" {
  type        = map(string)
  description = "Existing endpoint IDs, keyed by private_endpoint and filtered by global/per-entry enable flags."
  default     = {}

  validation {
    condition = alltrue([
      for endpoint_key, resource_id in var.private_endpoint_imports :
      resource_id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[var.private_endpoint[endpoint_key].resource_group_key].name, "")}/providers/Microsoft.Network/privateEndpoints/${try(var.private_endpoint[endpoint_key].name, "")}"
    ])
    error_message = "Each private_endpoint_imports entry must match its endpoint key, name, resource group and subscription_id."
  }
}

variable "enable_storage_account" {
  type        = bool
  description = "Whether Terraform manages and imports the existing storage accounts."
  default     = false
}

variable "storage_account" {
  type = map(object({
    name                              = string
    resource_group_key                = string
    location                          = optional(string)
    account_kind                      = optional(string, "StorageV2")
    account_tier                      = string
    account_replication_type          = string
    access_tier                       = string
    allow_nested_items_to_be_public   = bool
    cross_tenant_replication_enabled  = optional(bool, false)
    default_to_oauth_authentication   = bool
    https_traffic_only_enabled        = optional(bool, true)
    infrastructure_encryption_enabled = bool
    is_hns_enabled                    = optional(bool, false)
    large_file_share_enabled          = optional(bool)
    min_tls_version                   = optional(string, "TLS1_2")
    public_network_access_enabled     = bool
    sftp_enabled                      = optional(bool, false)
    shared_access_key_enabled         = optional(bool, true)
    blob_properties = optional(object({
      container_delete_retention_policy = object({ days = optional(number) })
      delete_retention_policy           = object({ days = optional(number) })
    }))
    network_rules = object({
      bypass                     = set(string)
      default_action             = string
      ip_rules                   = optional(set(string), [])
      virtual_network_subnet_ids = optional(set(string), [])
      private_link_access = optional(list(object({
        endpoint_resource_id = string
        endpoint_tenant_id   = optional(string)
      })), [])
    })
    tags = optional(map(string), {})
  }))
  description = "Existing storage accounts to adopt directly with AzureRM. infrastructure_encryption_enabled forces replacement, so it must match the export."
  default     = {}

  validation {
    condition = alltrue([
      for account in values(var.storage_account) :
      contains(keys(var.resource_group), account.resource_group_key) && (!var.enable_storage_account || var.enable_resource_group)
    ])
    error_message = "Each storage account must reference a managed resource group, enabled when account adoption is enabled."
  }
}

variable "storage_account_existing" {
  type = map(object({
    name               = string
    resource_group_key = string
  }))
  description = "Storage accounts read with a data source instead of managed, because policy denies writes to them."
  default     = {}

  validation {
    condition     = alltrue([for account in values(var.storage_account_existing) : contains(keys(var.resource_group), account.resource_group_key)])
    error_message = "Each existing storage account must reference a resource_group key."
  }
}

variable "storage_account_imports" {
  type        = map(string)
  description = "Existing storage account IDs, keyed by the matching storage_account instance."
  default     = {}

  validation {
    condition = alltrue([
      for account_key, resource_id in var.storage_account_imports :
      resource_id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[var.storage_account[account_key].resource_group_key].name, "")}/providers/Microsoft.Storage/storageAccounts/${try(var.storage_account[account_key].name, "")}"
    ])
    error_message = "Each storage_account_imports entry must match its account key, name, resource group and subscription_id."
  }
}

variable "enable_virtual_network" {
  type        = bool
  description = "Whether Terraform manages and imports the existing virtual networks and their subnets."
  default     = false
}

variable "virtual_network" {
  type = map(object({
    name               = string
    resource_group_key = string
    location           = optional(string)
    address_space      = set(string)
    dns_servers = optional(object({
      dns_servers = list(string)
    }))
    ddos_protection_plan = optional(object({
      id     = string
      enable = bool
    }))
    enable_vm_protection    = optional(bool, false)
    flow_timeout_in_minutes = optional(number)
    encryption = optional(object({
      enabled     = bool
      enforcement = string
    }))
    subnets = optional(map(object({
      name                                          = string
      address_prefixes                              = list(string)
      private_endpoint_network_policies             = optional(string, "Enabled")
      private_link_service_network_policies_enabled = optional(bool, true)
      default_outbound_access_enabled               = optional(bool, false)
      nat_gateway = optional(object({
        id = string
      }))
      network_security_group = optional(object({
        id = string
      }))
      route_table = optional(object({
        id = string
      }))
      service_endpoint_policies = optional(map(object({
        id = string
      })))
      service_endpoints_with_location = optional(list(object({
        service   = string
        locations = optional(list(string), ["*"])
      })))
      delegations = optional(list(object({
        name = string
        service_delegation = object({
          name    = string
          actions = optional(list(string), [])
        })
      })), [])
    })), {})
    tags = optional(map(string), {})
  }))
  description = "Existing VNets/subnets; delegation actions are retained as inventory, not forwarded."
  default     = {}

  validation {
    condition = alltrue([
      for vnet in values(var.virtual_network) :
      contains(keys(var.resource_group), vnet.resource_group_key) && (!var.enable_virtual_network || var.enable_resource_group)
    ])
    error_message = "Each VNet must reference a managed resource group, enabled when network adoption is enabled."
  }
}

variable "virtual_network_imports" {
  type        = map(string)
  description = "Existing VNet IDs, keyed by the matching virtual_network instance."
  default     = {}

  validation {
    condition = alltrue([
      for vnet_key, resource_id in var.virtual_network_imports :
      resource_id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[var.virtual_network[vnet_key].resource_group_key].name, "")}/providers/Microsoft.Network/virtualNetworks/${try(var.virtual_network[vnet_key].name, "")}"
    ])
    error_message = "Each virtual_network_imports entry must match its VNet key, name, resource group and subscription_id."
  }
}

variable "virtual_network_subnet_imports" {
  type = map(object({
    vnet_key   = string
    subnet_key = string
    id         = string
  }))
  description = "Existing bare subnet IDs and their owning VNet/subnet keys; the import block appends the API version."
  default     = {}

  validation {
    condition = alltrue([
      for subnet in values(var.virtual_network_subnet_imports) :
      subnet.id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[var.virtual_network[subnet.vnet_key].resource_group_key].name, "")}/providers/Microsoft.Network/virtualNetworks/${try(var.virtual_network[subnet.vnet_key].name, "")}/subnets/${try(var.virtual_network[subnet.vnet_key].subnets[subnet.subnet_key].name, "")}"
    ])
    error_message = "Each subnet import must match its VNet/subnet keys, names, resource group and subscription_id."
  }
}

# =====================================================================
# Hub private DNS (connectivity subscription)
# =====================================================================

variable "hub_dns_subscription_id" {
  type        = string
  description = "Connectivity subscription that hosts the shared private DNS zones."
  default     = "f3835bc1-9829-4ac8-9d7a-0999e0b29b90"
}

variable "hub_dns_resource_group_name" {
  type        = string
  description = "Resource group of the shared private DNS zones."
  default     = "rg-dns-connectivity-canadacentral-001"
}

variable "enable_hub_private_dns" {
  type        = bool
  description = "Whether Terraform manages and imports this app's VNet links and records in the shared hub zones."
  default     = false
}

variable "hub_private_dns_zone_link" {
  type = map(object({
    enabled              = optional(bool, true)
    name                 = string
    zone_name            = string
    virtual_network_id   = string
    registration_enabled = optional(bool, false)
    resolution_policy    = optional(string, "Default")
  }))
  description = "This app's VNet links in the shared hub zones."
  default     = {}
}

variable "hub_private_dns_zone_link_imports" {
  type        = map(string)
  description = "Existing VNet link IDs, keyed by hub_private_dns_zone_link and filtered by global/per-entry enable flags."
  default     = {}

  validation {
    condition = alltrue([
      for link_key, resource_id in var.hub_private_dns_zone_link_imports :
      resource_id == "/subscriptions/${var.hub_dns_subscription_id}/resourceGroups/${var.hub_dns_resource_group_name}/providers/Microsoft.Network/privateDnsZones/${try(var.hub_private_dns_zone_link[link_key].zone_name, "")}/virtualNetworkLinks/${try(var.hub_private_dns_zone_link[link_key].name, "")}"
    ])
    error_message = "Each hub_private_dns_zone_link_imports entry must match its link's zone, name, hub resource group and subscription."
  }
}
