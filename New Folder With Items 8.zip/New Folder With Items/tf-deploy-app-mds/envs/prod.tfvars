# Sub-Mds-Prod (dea89b5c-c8a0-4f3e-810e-c36a51501f29)
# Values come from the Azure resource export of 2026-11-03.
# The VNet is off for the first apply; adopt it in a separate run.

subscription_id = "dea89b5c-c8a0-4f3e-810e-c36a51501f29"

enable_resource_group          = true
enable_monitoring              = true
enable_event_grid_system_topic = true
enable_network_watcher         = true
enable_private_endpoint        = true
enable_storage_account         = true
enable_virtual_network         = false

enable_resource_group_role_assignment          = false
enable_monitoring_role_assignment              = false
enable_event_grid_system_topic_role_assignment = false
enable_network_watcher_role_assignment         = false
enable_private_endpoint_role_assignment        = false
enable_storage_account_role_assignment         = false
enable_virtual_network_role_assignment         = false

role_assignments = {}

resource_group = {
  network = {
    name     = "rg-network-mds-prod-canadacentral-001"
    location = "canadacentral"
    tags = {
      CostCenterId = "YT-01886.S.IMP"
      Environment  = "Prod"
    }
  }
  siem = {
    name     = "rg-siem-mds-prod-canadacentral-001"
    location = "canadacentral"
    tags = {
      CostCenterId = "YT-01886.S.IMP"
      Environment  = "Prod"
    }
  }
  networkwatcherrg = {
    name     = "NetworkWatcherRG"
    location = "canadacentral"
    tags = {
      CostCenterId = "YT-01886.S.IMP"
      Environment  = "Prod"
    }
  }
  linux = {
    name     = "rg-linux-mds-prod-canadacentral-001"
    location = "canadacentral"
    tags = {
      CostCenterId = "YT-01886.S.IMP"
      Environment  = "Prod"
    }
  }
  windows = {
    name     = "rg-windows-mds-prod-canadacentral-001"
    location = "canadacentral"
    tags = {
      CostCenterId = "YT-01886.S.IMP"
      Environment  = "Prod"
    }
  }
  kubernetes = {
    name     = "rg-kubernetes-mds-prod-canadacentral-001"
    location = "canadacentral"
    tags = {
      CostCenterId = "YT-01886.S.IMP"
      Environment  = "Prod"
    }
  }
}

import_resource_group = {
  network          = "/subscriptions/dea89b5c-c8a0-4f3e-810e-c36a51501f29/resourceGroups/rg-network-mds-prod-canadacentral-001"
  siem             = "/subscriptions/dea89b5c-c8a0-4f3e-810e-c36a51501f29/resourceGroups/rg-siem-mds-prod-canadacentral-001"
  networkwatcherrg = "/subscriptions/dea89b5c-c8a0-4f3e-810e-c36a51501f29/resourceGroups/NetworkWatcherRG"
  linux            = "/subscriptions/dea89b5c-c8a0-4f3e-810e-c36a51501f29/resourceGroups/rg-linux-mds-prod-canadacentral-001"
  windows          = "/subscriptions/dea89b5c-c8a0-4f3e-810e-c36a51501f29/resourceGroups/rg-windows-mds-prod-canadacentral-001"
  kubernetes       = "/subscriptions/dea89b5c-c8a0-4f3e-810e-c36a51501f29/resourceGroups/rg-kubernetes-mds-prod-canadacentral-001"
}

alert = {
  resource_group_key         = "network"
  root_management_group_name = null
  tags                       = {}
  activity_log_alerts = {
    service_outage = {
      name                = "Service-Outage-Alert-CanadaCentral"
      resource_group_name = "rg-network-mds-prod-canadacentral-001"
      scopes              = ["/subscriptions/dea89b5c-c8a0-4f3e-810e-c36a51501f29"]
      location            = "global"
      description         = "Azure Landing Zone Service Health Alert"
      enabled             = true
      criteria = {
        category = "ServiceHealth"
      }
      action_group_keys = []
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-monitor-mail-alerts-canadacentral-001"
      ]
      webhook_properties = {}
      tags = {
        CostCenterId = "YT-01886.S.IMP"
        Environment  = "Prod"
      }
    }
  }
  metric_alerts          = {}
  log_search_alerts      = {}
  alert_processing_rules = {}
}

activity_log_alert_imports = {
  service_outage = "/subscriptions/dea89b5c-c8a0-4f3e-810e-c36a51501f29/resourceGroups/rg-network-mds-prod-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/Service-Outage-Alert-CanadaCentral"
}

metric_alert_imports = {}

log_search_alert_imports = {}

alert_processing_rule_imports = {}

event_grid_system_topic = {
  siem_storage = {
    name                        = "stcybermdsprdcac001xd-be56c5ff-c588-4142-90eb-07b7a6d82e99"
    resource_group_key          = "siem"
    location                    = "canadacentral"
    topic_type                  = "microsoft.storage.storageaccounts"
    source_resource_id          = null
    exported_source_resource_id = "/subscriptions/dea89b5c-c8a0-4f3e-810e-c36a51501f29/resourceGroups/rg-siem-mds-prod-canadacentral-001/providers/microsoft.storage/storageaccounts/stcybermdsprdcac001xd"
    tags = {
      CostCenterId = "YT-01886.S.IMP"
      Environment  = "Prod"
    }
  }
  network_watcher_storage = {
    name                        = "stnwmdsprdcac001xdf-1993388b-b45f-432c-a444-a3e021f30845"
    resource_group_key          = "networkwatcherrg"
    location                    = "canadacentral"
    topic_type                  = "microsoft.storage.storageaccounts"
    source_resource_id          = null
    exported_source_resource_id = "/subscriptions/dea89b5c-c8a0-4f3e-810e-c36a51501f29/resourceGroups/networkwatcherrg/providers/microsoft.storage/storageaccounts/stnwmdsprdcac001xdf"
    tags = {
      CostCenterId = "YT-01886.S.IMP"
      Environment  = "Prod"
    }
  }
}

event_grid_system_topic_imports = {
  siem_storage            = "/subscriptions/dea89b5c-c8a0-4f3e-810e-c36a51501f29/resourceGroups/rg-siem-mds-prod-canadacentral-001/providers/Microsoft.EventGrid/systemTopics/stcybermdsprdcac001xd-be56c5ff-c588-4142-90eb-07b7a6d82e99"
  network_watcher_storage = "/subscriptions/dea89b5c-c8a0-4f3e-810e-c36a51501f29/resourceGroups/NetworkWatcherRG/providers/Microsoft.EventGrid/systemTopics/stnwmdsprdcac001xdf-1993388b-b45f-432c-a444-a3e021f30845"
}

# Their VNet flow logs stay unmanaged.
network_watcher = {
  canadacentral = {
    name               = "NetworkWatcher_canadacentral"
    resource_group_key = "networkwatcherrg"
    location           = "canadacentral"
    tags = {
      CostCenterId = "YT-01886.S.IMP"
      Environment  = "Prod"
    }
  }
}

network_watcher_imports = {
  canadacentral = "/subscriptions/dea89b5c-c8a0-4f3e-810e-c36a51501f29/resourceGroups/NetworkWatcherRG/providers/Microsoft.Network/networkWatchers/NetworkWatcher_canadacentral"
}

private_endpoint = {
  arc_private_link_scope = {
    enabled                         = true
    name                            = "pep-apls-mds-prod-canadacentral"
    resource_group_key              = "network"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/dea89b5c-c8a0-4f3e-810e-c36a51501f29/resourceGroups/rg-network-mds-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-mds-prod-canadacentral/subnets/snet-mds-prod-canadacentral"
    private_connection_resource_id  = "/subscriptions/dea89b5c-c8a0-4f3e-810e-c36a51501f29/resourceGroups/rg-network-mds-prod-canadacentral-001/providers/Microsoft.HybridCompute/privateLinkScopes/apls-mds-prod-canadacentral-001"
    private_service_connection_name = "apls-mds-prod-canadacentral-001"
    subresource_names               = ["hybridcompute"]
    network_interface_name          = null
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.his.arc.azure.com",
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.guestconfiguration.azure.com",
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.dp.kubernetesconfiguration.azure.com"
    ]
    ip_configurations = {}
    tags = {
      CostCenterId = "YT-01886.S.IMP"
      Environment  = "Prod"
    }
  }
  network_watcher_storage = {
    enabled                         = true
    name                            = "pep-stnwmdsprdcac001xdf"
    resource_group_key              = "networkwatcherrg"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/dea89b5c-c8a0-4f3e-810e-c36a51501f29/resourceGroups/rg-network-mds-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-mds-prod-canadacentral/subnets/snet-mds-prod-canadacentral"
    private_connection_resource_id  = "/subscriptions/dea89b5c-c8a0-4f3e-810e-c36a51501f29/resourceGroups/NetworkWatcherRG/providers/Microsoft.Storage/storageAccounts/stnwmdsprdcac001xdf"
    private_service_connection_name = "pep-stnwmdsprdcac001xdf"
    subresource_names               = ["blob"]
    network_interface_name          = "pep-stnwmdsprdcac001xdf-nic"
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net"
    ]
    ip_configurations = {}
    tags = {
      CostCenterId = "YT-01886.S.IMP"
      Environment  = "Prod"
    }
  }
}

private_endpoint_imports = {
  arc_private_link_scope  = "/subscriptions/dea89b5c-c8a0-4f3e-810e-c36a51501f29/resourceGroups/rg-network-mds-prod-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-apls-mds-prod-canadacentral"
  network_watcher_storage = "/subscriptions/dea89b5c-c8a0-4f3e-810e-c36a51501f29/resourceGroups/NetworkWatcherRG/providers/Microsoft.Network/privateEndpoints/pep-stnwmdsprdcac001xdf"
}

# Blob service properties were not exported, so blob_properties stays null.
storage_account = {
  network_watcher = {
    name                              = "stnwmdsprdcac001xdf"
    resource_group_key                = "networkwatcherrg"
    location                          = "canadacentral"
    account_kind                      = "StorageV2"
    account_tier                      = "Standard"
    account_replication_type          = "ZRS"
    access_tier                       = "Hot"
    allow_nested_items_to_be_public   = true
    cross_tenant_replication_enabled  = false
    default_to_oauth_authentication   = false
    https_traffic_only_enabled        = true
    infrastructure_encryption_enabled = false
    is_hns_enabled                    = false
    large_file_share_enabled          = null
    min_tls_version                   = "TLS1_2"
    public_network_access_enabled     = false
    sftp_enabled                      = false
    shared_access_key_enabled         = true
    blob_properties                   = null
    network_rules = {
      bypass                     = ["AzureServices"]
      default_action             = "Deny"
      ip_rules                   = []
      virtual_network_subnet_ids = []
      private_link_access = [
        {
          endpoint_resource_id = "/subscriptions/dea89b5c-c8a0-4f3e-810e-c36a51501f29/providers/Microsoft.Security/datascanners/storageDataScanner"
          endpoint_tenant_id   = "8fbb85e8-0cbc-48c3-a2e9-528cef30ec27"
        }
      ]
    }
    tags = {
      CostCenterId = "YT-01886.S.IMP"
      Environment  = "Prod"
    }
  }
  siem = {
    name                              = "stcybermdsprdcac001xd"
    resource_group_key                = "siem"
    location                          = "canadacentral"
    account_kind                      = "StorageV2"
    account_tier                      = "Standard"
    account_replication_type          = "ZRS"
    access_tier                       = "Hot"
    allow_nested_items_to_be_public   = true
    cross_tenant_replication_enabled  = false
    default_to_oauth_authentication   = false
    https_traffic_only_enabled        = true
    infrastructure_encryption_enabled = false
    is_hns_enabled                    = false
    large_file_share_enabled          = null
    min_tls_version                   = "TLS1_2"
    public_network_access_enabled     = false
    sftp_enabled                      = false
    shared_access_key_enabled         = true
    blob_properties                   = null
    network_rules = {
      bypass                     = ["AzureServices"]
      default_action             = "Deny"
      ip_rules                   = []
      virtual_network_subnet_ids = []
      private_link_access = [
        {
          endpoint_resource_id = "/subscriptions/dea89b5c-c8a0-4f3e-810e-c36a51501f29/providers/Microsoft.Security/datascanners/storageDataScanner"
          endpoint_tenant_id   = "8fbb85e8-0cbc-48c3-a2e9-528cef30ec27"
        }
      ]
    }
    tags = {
      CostCenterId = "YT-01886.S.IMP"
      Environment  = "Prod"
    }
  }
}

storage_account_existing = {}

storage_account_imports = {
  network_watcher = "/subscriptions/dea89b5c-c8a0-4f3e-810e-c36a51501f29/resourceGroups/NetworkWatcherRG/providers/Microsoft.Storage/storageAccounts/stnwmdsprdcac001xdf"
  siem            = "/subscriptions/dea89b5c-c8a0-4f3e-810e-c36a51501f29/resourceGroups/rg-siem-mds-prod-canadacentral-001/providers/Microsoft.Storage/storageAccounts/stcybermdsprdcac001xd"
}

# vnet-mds-prod-canadacentral peerings (unmanaged): RemoteVnetToHubPeering_a8db0ae7-e4bd-4112-a74f-86be5b004e19
# Disabled for now, as in Fit and Fabric: the VNet module's body omits subnets and
# peerings, so the import plan removes them, and the only peering is the vWAN
# hub connection owned by tf-deploy-platform-connectivity. Adopt it with the
# connectivity team on hand to restore the hub connection.
# defaultOutboundAccess is taken from the export where reported, otherwise Azure's
# default (enabled). It is create-time only, so a replace in the plan means the
# value is wrong. The hub peering stays unmanaged.
virtual_network = {
  app = {
    name               = "vnet-mds-prod-canadacentral"
    resource_group_key = "network"
    location           = "canadacentral"
    address_space      = ["10.195.120.0/24"]
    dns_servers = {
      dns_servers = ["10.195.1.4"]
    }
    ddos_protection_plan = {
      enable = true
      id     = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/ddosProtectionPlans/ddos-protection-plan"
    }
    subnets = {
      snet_mds_prod_canadacentral = {
        name                                          = "snet-mds-prod-canadacentral"
        address_prefixes                              = ["10.195.120.0/24"]
        default_outbound_access_enabled               = true
        private_endpoint_network_policies             = "RouteTableEnabled"
        private_link_service_network_policies_enabled = true
        service_endpoint_policies                     = {}
        service_endpoints_with_location               = []
        delegations                                   = []
      }
    }
    tags = {
      CostCenterId = "YT-01886.S.IMP"
      Environment  = "Prod"
    }
  }
}

virtual_network_imports = {
  app = "/subscriptions/dea89b5c-c8a0-4f3e-810e-c36a51501f29/resourceGroups/rg-network-mds-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-mds-prod-canadacentral"
}

virtual_network_subnet_imports = {
  app_snet_mds_prod_canadacentral = {
    vnet_key   = "app"
    subnet_key = "snet_mds_prod_canadacentral"
    id         = "/subscriptions/dea89b5c-c8a0-4f3e-810e-c36a51501f29/resourceGroups/rg-network-mds-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-mds-prod-canadacentral/subnets/snet-mds-prod-canadacentral"
  }
}

# =====================================================================
# Hub private DNS: links and records in the shared zones (connectivity subscription)
# =====================================================================

enable_hub_private_dns = true

hub_private_dns_zone_link = {
  "link-vnet-mds-prod-canadacentral-001" = {
    name               = "link-vnet-mds-prod-canadacentral-001"
    zone_name          = "privatelink.blob.core.windows.net"
    virtual_network_id = "/subscriptions/dea89b5c-c8a0-4f3e-810e-c36a51501f29/resourceGroups/rg-network-mds-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-mds-prod-canadacentral"
  }
  "privatelink.dp.kubernetesconfiguration.azure.com/link-vnet-mds-prod-canadacentral" = {
    name               = "link-vnet-mds-prod-canadacentral"
    zone_name          = "privatelink.dp.kubernetesconfiguration.azure.com"
    virtual_network_id = "/subscriptions/dea89b5c-c8a0-4f3e-810e-c36a51501f29/resourceGroups/rg-network-mds-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-mds-prod-canadacentral"
  }
  "privatelink.guestconfiguration.azure.com/link-vnet-mds-prod-canadacentral" = {
    name               = "link-vnet-mds-prod-canadacentral"
    zone_name          = "privatelink.guestconfiguration.azure.com"
    virtual_network_id = "/subscriptions/dea89b5c-c8a0-4f3e-810e-c36a51501f29/resourceGroups/rg-network-mds-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-mds-prod-canadacentral"
  }
  "privatelink.his.arc.azure.com/link-vnet-mds-prod-canadacentral" = {
    name               = "link-vnet-mds-prod-canadacentral"
    zone_name          = "privatelink.his.arc.azure.com"
    virtual_network_id = "/subscriptions/dea89b5c-c8a0-4f3e-810e-c36a51501f29/resourceGroups/rg-network-mds-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-mds-prod-canadacentral"
  }
}

hub_private_dns_zone_link_imports = {
  "link-vnet-mds-prod-canadacentral-001"                                              = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net/virtualNetworkLinks/link-vnet-mds-prod-canadacentral-001"
  "privatelink.dp.kubernetesconfiguration.azure.com/link-vnet-mds-prod-canadacentral" = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.dp.kubernetesconfiguration.azure.com/virtualNetworkLinks/link-vnet-mds-prod-canadacentral"
  "privatelink.guestconfiguration.azure.com/link-vnet-mds-prod-canadacentral"         = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.guestconfiguration.azure.com/virtualNetworkLinks/link-vnet-mds-prod-canadacentral"
  "privatelink.his.arc.azure.com/link-vnet-mds-prod-canadacentral"                    = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.his.arc.azure.com/virtualNetworkLinks/link-vnet-mds-prod-canadacentral"
}
