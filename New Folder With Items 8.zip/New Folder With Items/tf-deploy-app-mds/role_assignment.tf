variable "enable_resource_group_role_assignment" {
  type        = bool
  description = "Enable explicitly configured resource-group RBAC assignments. Parent adoption alone does not enable RBAC."
  default     = false
}

variable "enable_monitoring_role_assignment" {
  type        = bool
  description = "Enable explicitly configured activity-log-alert RBAC assignments."
  default     = false
}

variable "enable_event_grid_system_topic_role_assignment" {
  type        = bool
  description = "Enable explicitly configured Event Grid system-topic RBAC assignments."
  default     = false
}

variable "enable_network_watcher_role_assignment" {
  type        = bool
  description = "Enable explicitly configured Network Watcher RBAC assignments."
  default     = false
}

variable "enable_private_endpoint_role_assignment" {
  type        = bool
  description = "Enable explicitly configured private-endpoint RBAC assignments."
  default     = false
}

variable "enable_storage_account_role_assignment" {
  type        = bool
  description = "Enable explicitly configured storage-account RBAC assignments."
  default     = false
}

variable "enable_virtual_network_role_assignment" {
  type        = bool
  description = "Enable explicitly configured VNet RBAC assignments."
  default     = false
}

variable "role_assignments" {
  type = map(map(map(object({
    role_definition_id_or_name             = string
    principal_id                           = string
    condition                              = optional(string)
    condition_version                      = optional(string)
    delegated_managed_identity_resource_id = optional(string)
    principal_type                         = optional(string)
    skip_service_principal_aad_check       = optional(bool)
  }))))
  description = "Explicit RBAC entries keyed by resource type, parent instance key, then assignment key. Companion modules inject the parent scope; no permissions are inferred."
  default     = {}

  validation {
    condition     = alltrue([for resource_type in keys(var.role_assignments) : contains(keys(local.role_assignment_scopes), resource_type)])
    error_message = "Each role_assignments resource type must be supported by the MDS RBAC scope catalog."
  }

  validation {
    condition = alltrue(flatten([
      for resource_type, parents in var.role_assignments : [
        for parent_key in keys(parents) : contains(keys(lookup(local.role_assignment_scopes, resource_type, {})), parent_key)
      ]
    ]))
    error_message = "Each RBAC parent key must identify an existing instance in the matching MDS resource inventory."
  }

  validation {
    condition = alltrue(flatten([
      for resource_type, parents in var.role_assignments : [
        for parent_key in keys(parents) :
        !lookup(local.role_assignment_flags, resource_type, false) || try(local.role_assignment_parent_enabled[resource_type][parent_key], false)
      ]
    ]))
    error_message = "Enabled RBAC companions require enabled parent resources, including per-instance NIC and private-endpoint gates."
  }
}

locals {
  role_assignment_flags = {
    resource_group          = var.enable_resource_group_role_assignment
    activity_log_alert      = var.enable_monitoring_role_assignment
    event_grid_system_topic = var.enable_event_grid_system_topic_role_assignment
    network_watcher         = var.enable_network_watcher_role_assignment
    private_endpoint        = var.enable_private_endpoint_role_assignment
    storage_account         = var.enable_storage_account_role_assignment
    virtual_network         = var.enable_virtual_network_role_assignment
  }

  role_assignment_resource_enabled = {
    resource_group          = var.enable_resource_group
    activity_log_alert      = var.enable_monitoring
    event_grid_system_topic = var.enable_event_grid_system_topic
    network_watcher         = var.enable_network_watcher
    private_endpoint        = var.enable_private_endpoint
    storage_account         = var.enable_storage_account
    virtual_network         = var.enable_virtual_network
  }

  role_assignment_scopes = {
    resource_group = {
      for parent_key, parent in var.resource_group : parent_key =>
      "/subscriptions/${var.subscription_id}/resourceGroups/${parent.name}"
    }
    activity_log_alert = {
      for parent_key, parent in var.alert.activity_log_alerts : parent_key =>
      "/subscriptions/${var.subscription_id}/resourceGroups/${parent.resource_group_name}/providers/Microsoft.Insights/activityLogAlerts/${parent.name}"
    }
    event_grid_system_topic = {
      for parent_key, parent in var.event_grid_system_topic : parent_key =>
      "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[parent.resource_group_key].name, "")}/providers/Microsoft.EventGrid/systemTopics/${parent.name}"
    }
    network_watcher = {
      for parent_key, parent in var.network_watcher : parent_key =>
      "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[parent.resource_group_key].name, "")}/providers/Microsoft.Network/networkWatchers/${parent.name}"
    }
    private_endpoint = {
      for parent_key, parent in var.private_endpoint : parent_key =>
      "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[parent.resource_group_key].name, "")}/providers/Microsoft.Network/privateEndpoints/${parent.name}"
    }
    storage_account = {
      for parent_key, parent in var.storage_account : parent_key =>
      "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[parent.resource_group_key].name, "")}/providers/Microsoft.Storage/storageAccounts/${parent.name}"
    }
    virtual_network = {
      for parent_key, parent in var.virtual_network : parent_key =>
      "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[parent.resource_group_key].name, "")}/providers/Microsoft.Network/virtualNetworks/${parent.name}"
    }
  }

  role_assignment_parent_enabled = {
    for resource_type, parents in local.role_assignment_scopes : resource_type => {
      for parent_key, scope in parents : parent_key => local.role_assignment_resource_enabled[resource_type] && (
        resource_type == "private_endpoint" ? try(var.private_endpoint[parent_key].enabled, false) : true
      )
    }
  }

  role_assignment_instances = merge({}, [
    for resource_type, parents in var.role_assignments : {
      for parent_key, assignments in parents : "${resource_type}/${parent_key}" => {
        scope       = try(local.role_assignment_scopes[resource_type][parent_key], null)
        assignments = assignments
      } if lookup(local.role_assignment_flags, resource_type, false) && try(local.role_assignment_parent_enabled[resource_type][parent_key], false) && length(assignments) > 0
    }
  ]...)
}

module "role_assignment" {
  for_each = local.role_assignment_instances

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-role-assignment/azurerm"
  version = "0.3.6"

  role_assignments_azure_resource_manager = {
    for assignment_key, assignment in each.value.assignments : assignment_key => merge(assignment, {
      scope = each.value.scope
    })
  }

  depends_on = [
    module.resource_group,
    module.monitoring,
    azurerm_eventgrid_system_topic.this,
    azurerm_network_watcher.this,
    module.private_endpoint,
    azurerm_storage_account.this,
    module.virtual_network,
  ]
}
