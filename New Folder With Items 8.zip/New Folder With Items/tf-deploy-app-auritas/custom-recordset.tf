# This app's records in the shared private DNS zones in
# rg-dns-connectivity-canadacentral-001 (connectivity subscription).
# tf-deploy-platform-connectivity owns the zones; this repo owns this app's
# records in them.
#
# Tags are ignored: the connectivity subscription's tag policy sets them.

resource "azurerm_private_dns_a_record" "hub" {
  for_each = var.enable_hub_private_dns ? { for record_key, record in var.hub_private_dns_a_record : record_key => record if record.enabled } : {}
  provider = azurerm.dns

  name                = each.value.name
  resource_group_name = var.hub_dns_resource_group_name
  zone_name           = each.value.zone_name
  ttl                 = each.value.ttl
  records             = each.value.records

  lifecycle {
    ignore_changes = [tags]
  }
}

import {
  for_each = var.enable_hub_private_dns ? { for record_key, resource_id in var.hub_private_dns_a_record_imports : record_key => resource_id if try(var.hub_private_dns_a_record[record_key].enabled, false) } : {}
  provider = azurerm.dns

  to = azurerm_private_dns_a_record.hub[each.key]
  id = each.value
}
