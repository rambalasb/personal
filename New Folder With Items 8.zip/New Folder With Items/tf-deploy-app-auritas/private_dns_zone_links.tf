# This app's VNet links in the shared private DNS zones in
# rg-dns-connectivity-canadacentral-001 (connectivity subscription).
# tf-deploy-platform-connectivity owns the zones; this repo owns the links for
# this app's VNets, so the app team can change them without a connectivity PR.
#
# Tags are ignored: the connectivity subscription's tag policy sets them.

resource "azurerm_private_dns_zone_virtual_network_link" "hub" {
  for_each = var.enable_hub_private_dns ? { for link_key, link in var.hub_private_dns_zone_link : link_key => link if link.enabled } : {}
  provider = azurerm.dns

  name                  = each.value.name
  resource_group_name   = var.hub_dns_resource_group_name
  private_dns_zone_name = each.value.zone_name
  virtual_network_id    = each.value.virtual_network_id
  registration_enabled  = each.value.registration_enabled
  resolution_policy     = each.value.resolution_policy

  lifecycle {
    ignore_changes = [tags]
  }
}

import {
  for_each = var.enable_hub_private_dns ? { for link_key, resource_id in var.hub_private_dns_zone_link_imports : link_key => resource_id if try(var.hub_private_dns_zone_link[link_key].enabled, false) } : {}
  provider = azurerm.dns

  to = azurerm_private_dns_zone_virtual_network_link.hub[each.key]
  id = each.value
}
