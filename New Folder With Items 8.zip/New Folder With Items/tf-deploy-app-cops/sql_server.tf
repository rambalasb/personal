module "sql_server" {
  for_each = var.enable_sql_server ? var.sql_server : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-sql-server/azurerm"
  version = "0.1.0"

  name                                     = each.value.name
  resource_group_name                      = module.resource_group[each.value.resource_group_key].name
  location                                 = coalesce(each.value.location, module.resource_group[each.value.resource_group_key].location)
  server_version                           = each.value.server_version
  administrator_login                      = each.value.administrator_login
  azuread_administrator                    = each.value.azuread_administrator
  public_network_access_enabled            = each.value.public_network_access_enabled
  outbound_network_restriction_enabled     = each.value.outbound_network_restriction_enabled
  express_vulnerability_assessment_enabled = each.value.express_vulnerability_assessment_enabled
  primary_user_assigned_identity_id        = each.value.primary_user_assigned_identity_id
  tags                                     = each.value.tags

  managed_identities = {
    system_assigned            = false
    user_assigned_resource_ids = each.value.user_assigned_identity_ids
  }

  # Existing databases stay unmanaged here.
  databases                             = {}
  elastic_pools                         = {}
  firewall_rules                        = {}
  private_endpoints                     = {}
  role_assignments                      = {}
  diagnostic_settings                   = {}
  generate_administrator_login_password = false
  lock                                  = null
  enable_telemetry                      = false
}

import {
  for_each = var.enable_sql_server ? var.sql_server_imports : {}

  to = module.sql_server[each.key].module.sql_server.azurerm_mssql_server.this
  id = each.value
}
