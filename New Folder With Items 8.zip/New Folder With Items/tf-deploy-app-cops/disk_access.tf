resource "azurerm_disk_access" "this" {
  for_each = var.enable_disk_access ? var.disk_access : {}

  name                = each.value.name
  resource_group_name = module.resource_group[each.value.resource_group_key].name
  location            = coalesce(each.value.location, module.resource_group[each.value.resource_group_key].location)
  tags                = each.value.tags

  lifecycle {
    prevent_destroy = true
  }
}

import {
  for_each = var.enable_disk_access ? var.disk_access_imports : {}

  to = azurerm_disk_access.this[each.key]
  id = each.value
}
