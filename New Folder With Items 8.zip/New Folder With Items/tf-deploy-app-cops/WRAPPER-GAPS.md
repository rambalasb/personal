# Wrapper gaps: `tf-deploy-app-cops`

Resources in the COPS subscriptions that this repo does not manage. Counts
are from the Azure resource export of 2026-11-05.

## Staged

Code and tfvars are complete; each is switched off and adopted in its own
run. See "Staged adoption" in the README.

| Resource | Environment | Reason |
|---|---|---|
| `api-cops-nonprod-canadacentral-001`, `wrk-cops-nonprod-canadacentral-001` | nonprod | Every apply rewrites the full app settings; secrets must be Key Vault references or real sensitive values first |
| `api-cops-prod-canadacentral-002`, `wrk-cops-prod-canadacentral-001` | prod | Same, and not yet filled in: the export masks app setting values |
| `vnet-cops-<env>-canadacentral-001` (+ 3 subnets) | both | vWAN hub connection owned by the connectivity repo |

## Blocked by policy

Public network access is enabled, so `Deny_Public_Access_On_PaaS_Services_v0`
denies any write, adoption included. Read with
`data.azapi_resource.storage_account_existing` until exempted.

| Resource | Environment | Reason |
|---|---|---|
| `stnwcopsnonprodcac` (flow log storage) | nonprod | Disabling public access would stop flow logs, which rely on the trusted-services bypass |
| `stcopsprodcac002` | prod | Public access enabled with default action Deny |

## Not managed

| Type | Nonprod | Prod | Reason |
|---|---:|---:|---|
| `microsoft.web/sites` | 1 | 1 | `app-cops-<env>-canadacentral-00x` mounts an NFS share; the web-app module writes mounts without a protocol and would turn it into SMB |
| `microsoft.network/networkinterfaces` | 9 | 10 | Private endpoint NICs belong to their endpoint |
| `microsoft.sql/servers/databases` | 2 | 2 | `COPS40_STAGING`/`COPS40_PRODUCTION` and `master`; the SQL wrapper is called with `databases = {}` |
| `microsoft.sql/servers/jobagents`, `jobaccounts` | 2 | 2 | Elastic job agent; no wrapper input |
| `microsoft.insights/activitylogalerts` | 2 | 0 | `app-cops-nonprod-delete` matches `level` with `containsAny`; `adv-leg-sub-cops-nonprod-cost-high` uses `anyOf` with several values. The wrapper takes a single value for both |
| `microsoft.alertsmanagement/actionrules` | 0 | 4 | Spaces in their names, which AzureRM rejects; rename them in Azure to manage them |
| `microsoft.alertsmanagement/smartdetectoralertrules` | 1 | 1 | App Insights failure anomalies; created by Azure |
| `microsoft.insights/actiongroups` | 2 | 1 | `Application Insights Smart Detection` is created by Azure; `ag-cops-nonprod-mail-alerts-*` is not modelled (alerts reference it by ID) |
| `microsoft.web/certificates` | 1 | 1 | No wrapper published |
| `microsoft.network/networkwatchers/flowlogs` | 1 | 1 | No wrapper |
| Service Bus queues, topics and rules | ? | ? | Only the namespace is adopted |
| Private DNS zone record sets | 2 | 0 | Only the zone is adopted |
