# The standalone disk is managed directly in managed_disk.tf. Drops any disk
# adopted earlier under the compute-disk wrapper from state without deleting it.
removed {
  from = module.compute_disk

  lifecycle {
    destroy = false
  }
}
