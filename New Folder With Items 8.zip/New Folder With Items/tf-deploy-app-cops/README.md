# tf-deploy-app-cops

Terraform that adopts the existing **COPS** (Call Out) resources into state,
following the same layout as the Fabric, PTA and FIT deploy repos.

| Environment | Subscription | ID |
|---|---|---|
| `nonprod` | Sub-Cops-NonProd | `675a173c-0b66-4506-9aec-c0b2681e0fb9` |
| `prod` | Sub-Cops-Prod | `9a891d10-c1e9-4527-a22c-204426e3725b` |

Use Terraform `>= 1.9, < 2.0`, one state per environment, and select
`envs/nonprod.tfvars` or `envs/prod.tfvars`. Adopt nonprod first; prod follows
the same runs and stages.

## Status

**Nonprod** is filled from the Azure resource export of 2026-10-20 and is
ready for the first import run. Two web apps and the VNet are filled in but
switched off; they are adopted later, one stage at a time (see
[Staged adoption](#staged-adoption)).

**Prod** is filled from the Azure resource export of 2026-11-05. The VNet is
filled in but switched off, as in nonprod. The web apps are not filled in:
the export masks app setting values, so `api-cops-prod-canadacentral-002` and
`wrk-cops-prod-canadacentral-001` need their settings (as Key Vault
references) before that tier is staged. Prod differs from nonprod:

- Four resource groups (no alerts or shared group; alerts sit in the app,
  identity and Network Watcher groups), one App Service plan, two Application
  Insights components, no private DNS zone, and no disk access or standalone
  disk.
- `app-cops-prod-canadacentral-002` mounts an NFS share, so like its nonprod
  twin it is not modelled.
- `stfilescopsprodcac01` is a provisioned v1 premium file account
  (`Premium_ZRS`, FileStorage); HTTPS-only is off for NFS.
- `stcopsprodcac002` has public network access enabled, so it is read with
  `storage_account_existing` instead of being adopted.
- The Service Bus private endpoint is named `pe-sb-cops-nonprod-canadacentral-001`
  although it is in prod. Kept as exported.
- Alerts that stay out (four processing rules with spaces in their names,
  one smart detector rule) are listed at `alert_processing_rule_imports` in
  `envs/prod.tfvars`.

## Tiers

| File | Implementation | Nonprod |
|---|---|---|
| `resource_group.tf` | `tf-wrapper-avm-resource-group` 2.0.0 | 6, enabled |
| `alerts.tf` | `tf-wrapper-avm-ptn-monitoring-amba-alz` 0.3.3 | 5 activity log, 15 metric, 5 log search alerts, enabled |
| `app_service_plan.tf` | `tf-wrapper-avm-app-service-plan` 0.1.0 | 2, enabled |
| `application_insights.tf` | `tf-wrapper-avm-application-insights` 0.1.0 | 1, enabled |
| `disk_access.tf` | `azurerm_disk_access` | 1, enabled |
| `event_grid_system_topic.tf` | `azurerm_eventgrid_system_topic` | 2, enabled |
| `key_vault.tf` | `tf-wrapper-avm-key-vault` 0.4.0 | 1, enabled |
| `log_analytics_workspace.tf` | `tf-wrapper-avm-log-analytics-workspace` 0.1.2 | 1, enabled |
| `managed_disk.tf` | `azurerm_managed_disk` | 1, enabled |
| `network_security_group.tf` | `tf-wrapper-avm-network-security-group` 0.1.1 | 3 + 4 rules, enabled |
| `network_watcher.tf` | `azurerm_network_watcher` | 1, enabled |
| `private_dns_zone.tf` | `tf-wrapper-avm-private-dns-zone` 1.0.0 | 1, enabled |
| `private_endpoint.tf` | `tf-wrapper-avm-private-endpoint` 0.1.2 | 9, enabled |
| `redis_cache.tf` | `azurerm_redis_cache` | 1, enabled |
| `service_bus_namespace.tf` | `azurerm_servicebus_namespace` | 1, enabled |
| `sql_server.tf` | `tf-wrapper-avm-sql-server` 0.1.0 | 1, enabled |
| `storage_account.tf` | `azurerm_storage_account`; read-only `azapi_resource` data source | 2 + 1 read-only, enabled |
| `user_assigned_identity.tf` | `tf-wrapper-avm-user-assigned-identity` 0.0.4 | 2, enabled |
| `web_app.tf` | `tf-wrapper-avm-web-app` 0.0.5 | 2, disabled (separate run) |
| `virtual_network.tf` | `tf-wrapper-avm-virtual-network` 0.1.0 | 1 + 3 subnets, disabled (hub connection) |
| `role_assignment.tf` | `tf-wrapper-avm-role-assignment` 0.3.6 | all off |
| `compute_disk.tf` | `removed` block only | - |

Redis, Service Bus, the disk access and the standalone disk use AzureRM
directly, as storage does, because no wrapper for them is pinned in this
estate; each has `prevent_destroy`. Wrapper tags are switched off where the
wrapper allows it; the LAW, UAI, SQL, App Service, App Insights, DNS zone and
monitoring wrappers still add `managed-by`/`module` tags, so expect a tag
update on those.

Storage accounts with public network access enabled are read with
`data.azapi_resource.storage_account_existing` (`storage_account_existing`
in tfvars) instead of being managed: `Deny_Public_Access_On_PaaS_Services_v0`
denies any write to them, adoption included. Move an account into
`storage_account` once it has a policy exemption. They are listed under
"Blocked by policy" in [WRAPPER-GAPS.md](WRAPPER-GAPS.md).

What stays unmanaged is in [WRAPPER-GAPS.md](WRAPPER-GAPS.md).

## Things to check before the first import

- `storage_account.infrastructure_encryption_enabled`,
  `sql_server.administrator_login`, the Redis SKU/family/capacity and the
  Service Bus SKU force replacement or a resize. They are copied from the
  export; a `replace` in the plan means one of them is wrong.
- `stappcopsnonprodcac01` is a provisioned v2 premium file account
  (`PremiumV2_LRS`, `provisioned_billing_model_version = "V2"`) serving the
  NFS share that `app-cops` mounts. HTTPS-only is off because NFS needs it.
- The SQL server allows SQL logins as well as Entra ID. Its admin password is
  not managed and is not needed for the import.
- The Application Insights daily cap was not exported; 100 GB is assumed.
- NSG rule protocols are written as `Tcp` because the wrapper rejects upper
  case. Azure reports `TCP`, so a case-only update may appear.
- Several alert action group IDs contain a leading space in the group name.
  They are kept as exported.
- One resource group tag value (`CostCenterId`) has a leading space in Azure;
  it is kept as exported.

## Adoption

Every resource here already exists in Azure. Each tier has `enable_<type>`
and an import map; imports only run while the tier is enabled, and
validations check every import ID against the key, name, resource group and
`subscription_id`.

Before the first apply:

- Make sure auto-apply is off on the HCP workspace, so every apply is
  confirmed by hand after reading the plan.
- Optionally put a `CanNotDelete` lock on the app resource groups for the
  adoption window. A lock makes Azure refuse any delete, so an unexpected
  replace fails instead of destroying the resource.

  ```bash
  az lock create --name adoption-no-delete --lock-type CanNotDelete --resource-group <rg>
  az lock delete --name adoption-no-delete --resource-group <rg>   # afterwards
  ```

Each run, first or staged:

1. Run `.github/workflows/import-verify.yml` for the environment. It only
   plans, then runs `scripts/import_gate.sh`, which wraps
   `scripts/verify_zero_diff.sh`: it fails on anything other than imports and
   tag updates and reports any replace separately.
2. Fix diffs by correcting tfvars, never by changing Azure. Repeat until the
   gate passes. Never accept a replace or delete with `--allow-resource`.
   Accepted addresses go in `scripts/import_gate.sh`.
3. Run `.github/workflows/import-apply.yml` for the environment, with
   `confirm` set to `apply`. Read the check job's summary (gate output and
   plan: only imports and tag updates), then approve the apply job. It
   re-plans, re-runs the gate and refuses to apply if the change set moved
   since the check. Do not use `landing-zone-multi-env.yml` while imports
   are pending; it applies with `-auto-approve` and no gate.
4. Empty the import maps of the tiers that applied.

## Staged adoption

These tiers are complete in `envs/nonprod.tfvars` but switched off, because
adopting them can change or destroy something that is hard to get back. Each
gets its own import-verify and apply, after the first run has applied.

| Stage | Flags | Why it is held back |
|---|---|---|
| 1. Web apps (`api-cops`, `wrk-cops`) | `enable_web_app` | Every apply rewrites the full app settings, so wrong or missing secrets break the live apps |
| 2. Virtual network | `enable_virtual_network` | The vWAN hub connection is owned by the connectivity repo |

### Stage 1: Web apps

The upstream module (`avm-res-web-site`, via `tf-wrapper-avm-web-app` 0.0.5)
rewrites the full app settings list, the connection strings and the storage
mounts on every apply. Anything not in Terraform is deleted, and any wrong
value goes live.

1. Deal with the masked settings. `api-cops`: `APNS_KEY_ID`,
   `APPLICATIONINSIGHTS_CONNECTION_STRING`, `DB_USER`, `REDIS_USERNAME`.
   `wrk-cops`: `APNS_KEY_ID`, `APPLICATIONINSIGHTS_CONNECTION_STRING`. The
   export masks by name, so `DB_USER` and `REDIS_USERNAME` may not be secret:
   if they are plain values, move them into `app_settings`. For the real
   secrets, prefer Key Vault references in `kvcopsnonprodcac001` (both apps
   already use some), otherwise set the real values in the **sensitive** HCP
   variable `web_app_secret_app_settings` (`{ api = { ... }, wrk = { ... } }`).
   Never use placeholders. Validation blocks the plan until every name has a
   value.
2. Re-check the non-secret settings against the live apps if anything
   changed since the export.
3. Set `enable_web_app = true` and run import-verify. Expected: two site
   imports, plus creates for the app settings, connection strings, metadata,
   slot settings, storage mounts and FTP policy of each app. Those are
   written with `azapi_update_resource` / `azapi_resource_action`, which
   cannot be imported. Review each one, then accept those addresses only
   with `--allow-resource`.
4. Apply, smoke-test both apps, then empty `web_app_imports`.

`app-cops-nonprod-canadacentral-001` is not modelled. It mounts the NFS share
`fs-cops-nonprod` from `stappcopsnonprodcac01`, and the module writes storage
mounts without a protocol, so the first apply would replace the NFS mount
with an SMB one. Its plan (`ASP-rgcopsappnonprodcanadacentral00-ba5c`) is
managed. Hostname bindings, certificates and log settings are not managed on
any app.

### Stage 2: Virtual network

The VNet module sends a body without subnets or peerings, so the import plan
shows both being removed. The VNet's only peering is the vWAN hub connection,
declared in `tf-deploy-platform-connectivity`. Upstream tests confirm that
subnets and peerings created outside the module survive the update, but not
vWAN hub connections. This stage is the same as Fabric's, PTA's and FIT's.

1. Agree a window with the connectivity team, so they can restore the hub
   connection from their repo if it drops.
2. Set `enable_virtual_network = true` and run import-verify. Expected: one
   VNet import and three subnet imports.
3. `defaultOutboundAccess` is not reported for any subnet, so it is set to
   Azure's default (`true`). It is create-time only: a subnet replace in the
   plan means that guess is wrong, so stop and correct it.
4. Apply, check the hub connection and the web apps' VNet integration, then
   empty the VNet and subnet import maps.

## Role assignments

`role_assignment.tf` uses one typed map: resource type, parent key, then
assignment key. Every `enable_<type>_role_assignment` is false and
`role_assignments = {}` in both environments. Nothing is inferred from the
export, and existing assignments need their own imports.

## Pipeline

| Workflow | Purpose |
|---|---|
| `import-verify.yml` | Plan and gate. Never applies. Run this first |
| `import-apply.yml` | Gate, approval on the `<env>` environment, re-gate, apply |
| `landing-zone-multi-env.yml` | Deploy pipeline, `workflow_dispatch` only |
| `tflint.yml` | HCL lint on push and PR |
| `trivy.yml` | IaC scan on PR and weekly |

`import-apply.yml` needs required reviewers on the `nonprod` and `prod`
GitHub Environments, or the apply job runs without stopping. Its check job
runs outside any environment, so `TF_API_TOKEN`, `TF_CLOUD_ORGANIZATION`
and `TFC_WORKSPACE_PREFIX` must be set at repo or org level.

`TFC_WORKSPACE_PREFIX` must be set before the first run (`az-cops`, matching Fabric's `az-fabric`).

This repo is now maintained by hand. Do not re-run
`generate-deploy-repos.py` over it.
