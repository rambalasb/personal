variable "enable_resource_group_role_assignment" {
  type        = bool
  description = "Enable explicitly configured resource-group RBAC assignments."
  default     = false
}

variable "enable_monitoring_role_assignment" {
  type        = bool
  description = "Enable explicitly configured activity-log-alert RBAC assignments."
  default     = false
}

variable "enable_app_service_plan_role_assignment" {
  type        = bool
  description = "Enable explicitly configured App Service plan RBAC assignments."
  default     = false
}

variable "enable_application_insights_role_assignment" {
  type        = bool
  description = "Enable explicitly configured Application Insights RBAC assignments."
  default     = false
}

variable "enable_disk_access_role_assignment" {
  type        = bool
  description = "Enable explicitly configured disk access RBAC assignments."
  default     = false
}

variable "enable_event_grid_system_topic_role_assignment" {
  type        = bool
  description = "Enable explicitly configured Event Grid system-topic RBAC assignments."
  default     = false
}

variable "enable_key_vault_role_assignment" {
  type        = bool
  description = "Enable explicitly configured Key Vault RBAC assignments."
  default     = false
}

variable "enable_log_analytics_workspace_role_assignment" {
  type        = bool
  description = "Enable explicitly configured Log Analytics workspace RBAC assignments."
  default     = false
}

variable "enable_managed_disk_role_assignment" {
  type        = bool
  description = "Enable explicitly configured managed disk RBAC assignments."
  default     = false
}

variable "enable_network_security_group_role_assignment" {
  type        = bool
  description = "Enable explicitly configured NSG RBAC assignments."
  default     = false
}

variable "enable_network_watcher_role_assignment" {
  type        = bool
  description = "Enable explicitly configured Network Watcher RBAC assignments."
  default     = false
}

variable "enable_private_dns_zone_role_assignment" {
  type        = bool
  description = "Enable explicitly configured private DNS zone RBAC assignments."
  default     = false
}

variable "enable_private_endpoint_role_assignment" {
  type        = bool
  description = "Enable explicitly configured private-endpoint RBAC assignments."
  default     = false
}

variable "enable_redis_cache_role_assignment" {
  type        = bool
  description = "Enable explicitly configured Redis cache RBAC assignments."
  default     = false
}

variable "enable_service_bus_namespace_role_assignment" {
  type        = bool
  description = "Enable explicitly configured Service Bus namespace RBAC assignments."
  default     = false
}

variable "enable_sql_server_role_assignment" {
  type        = bool
  description = "Enable explicitly configured SQL server RBAC assignments."
  default     = false
}

variable "enable_storage_account_role_assignment" {
  type        = bool
  description = "Enable explicitly configured storage-account RBAC assignments."
  default     = false
}

variable "enable_user_assigned_identity_role_assignment" {
  type        = bool
  description = "Enable explicitly configured user-assigned identity RBAC assignments."
  default     = false
}

variable "enable_virtual_network_role_assignment" {
  type        = bool
  description = "Enable explicitly configured VNet RBAC assignments."
  default     = false
}

variable "enable_web_app_role_assignment" {
  type        = bool
  description = "Enable explicitly configured web app RBAC assignments."
  default     = false
}

variable "role_assignments" {
  type = map(map(map(object({
    role_definition_id_or_name             = string
    principal_id                           = string
    condition                              = optional(string)
    condition_version                      = optional(string)
    delegated_managed_identity_resource_id = optional(string)
    principal_type                         = optional(string)
    skip_service_principal_aad_check       = optional(bool)
  }))))
  description = "Explicit RBAC entries keyed by resource type, parent instance key, then assignment key. Companion modules inject the parent scope; no permissions are inferred."
  default     = {}

  validation {
    condition     = alltrue([for resource_type in keys(var.role_assignments) : contains(keys(local.role_assignment_scopes), resource_type)])
    error_message = "Each role_assignments resource type must be supported by the COPS RBAC scope catalog."
  }

  validation {
    condition = alltrue(flatten([
      for resource_type, parents in var.role_assignments : [
        for parent_key in keys(parents) : contains(keys(lookup(local.role_assignment_scopes, resource_type, {})), parent_key)
      ]
    ]))
    error_message = "Each RBAC parent key must identify an existing instance in the matching COPS resource inventory."
  }

  validation {
    condition = alltrue(flatten([
      for resource_type, parents in var.role_assignments : [
        for parent_key in keys(parents) :
        !lookup(local.role_assignment_flags, resource_type, false) || try(local.role_assignment_parent_enabled[resource_type][parent_key], false)
      ]
    ]))
    error_message = "Enabled RBAC companions require enabled parent resources, including the per-instance private-endpoint gate."
  }
}

locals {
  role_assignment_flags = {
    resource_group          = var.enable_resource_group_role_assignment
    activity_log_alert      = var.enable_monitoring_role_assignment
    app_service_plan        = var.enable_app_service_plan_role_assignment
    application_insights    = var.enable_application_insights_role_assignment
    disk_access             = var.enable_disk_access_role_assignment
    event_grid_system_topic = var.enable_event_grid_system_topic_role_assignment
    key_vault               = var.enable_key_vault_role_assignment
    log_analytics_workspace = var.enable_log_analytics_workspace_role_assignment
    managed_disk            = var.enable_managed_disk_role_assignment
    network_security_group  = var.enable_network_security_group_role_assignment
    network_watcher         = var.enable_network_watcher_role_assignment
    private_dns_zone        = var.enable_private_dns_zone_role_assignment
    private_endpoint        = var.enable_private_endpoint_role_assignment
    redis_cache             = var.enable_redis_cache_role_assignment
    service_bus_namespace   = var.enable_service_bus_namespace_role_assignment
    sql_server              = var.enable_sql_server_role_assignment
    storage_account         = var.enable_storage_account_role_assignment
    user_assigned_identity  = var.enable_user_assigned_identity_role_assignment
    virtual_network         = var.enable_virtual_network_role_assignment
    web_app                 = var.enable_web_app_role_assignment
  }

  role_assignment_resource_enabled = {
    resource_group          = var.enable_resource_group
    activity_log_alert      = var.enable_monitoring
    app_service_plan        = var.enable_app_service_plan
    application_insights    = var.enable_application_insights
    disk_access             = var.enable_disk_access
    event_grid_system_topic = var.enable_event_grid_system_topic
    key_vault               = var.enable_key_vault
    log_analytics_workspace = var.enable_log_analytics_workspace
    managed_disk            = var.enable_managed_disk
    network_security_group  = var.enable_network_security_group
    network_watcher         = var.enable_network_watcher
    private_dns_zone        = var.enable_private_dns_zone
    private_endpoint        = var.enable_private_endpoint
    redis_cache             = var.enable_redis_cache
    service_bus_namespace   = var.enable_service_bus_namespace
    sql_server              = var.enable_sql_server
    storage_account         = var.enable_storage_account
    user_assigned_identity  = var.enable_user_assigned_identity
    virtual_network         = var.enable_virtual_network
    web_app                 = var.enable_web_app
  }

  role_assignment_scopes = {
    resource_group = {
      for parent_key, parent in var.resource_group : parent_key =>
      "/subscriptions/${var.subscription_id}/resourceGroups/${parent.name}"
    }
    activity_log_alert = {
      for parent_key, parent in var.alert.activity_log_alerts : parent_key =>
      "/subscriptions/${var.subscription_id}/resourceGroups/${parent.resource_group_name}/providers/Microsoft.Insights/activityLogAlerts/${parent.name}"
    }
    app_service_plan = {
      for parent_key, parent in var.app_service_plan : parent_key =>
      "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[parent.resource_group_key].name, "")}/providers/Microsoft.Web/serverFarms/${parent.name}"
    }
    application_insights = {
      for parent_key, parent in var.application_insights : parent_key =>
      "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[parent.resource_group_key].name, "")}/providers/Microsoft.Insights/components/${parent.name}"
    }
    disk_access = {
      for parent_key, parent in var.disk_access : parent_key =>
      "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[parent.resource_group_key].name, "")}/providers/Microsoft.Compute/diskAccesses/${parent.name}"
    }
    event_grid_system_topic = {
      for parent_key, parent in var.event_grid_system_topic : parent_key =>
      "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[parent.resource_group_key].name, "")}/providers/Microsoft.EventGrid/systemTopics/${parent.name}"
    }
    key_vault = {
      for parent_key, parent in var.key_vault : parent_key =>
      "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[parent.resource_group_key].name, "")}/providers/Microsoft.KeyVault/vaults/${parent.name}"
    }
    log_analytics_workspace = {
      for parent_key, parent in var.log_analytics_workspace : parent_key =>
      "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[parent.resource_group_key].name, "")}/providers/Microsoft.OperationalInsights/workspaces/${parent.name}"
    }
    managed_disk = {
      for parent_key, parent in var.managed_disk : parent_key =>
      "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[parent.resource_group_key].name, "")}/providers/Microsoft.Compute/disks/${parent.name}"
    }
    network_security_group = {
      for parent_key, parent in var.network_security_group : parent_key =>
      "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[parent.resource_group_key].name, "")}/providers/Microsoft.Network/networkSecurityGroups/${parent.name}"
    }
    network_watcher = {
      for parent_key, parent in var.network_watcher : parent_key =>
      "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[parent.resource_group_key].name, "")}/providers/Microsoft.Network/networkWatchers/${parent.name}"
    }
    private_dns_zone = {
      for parent_key, parent in var.private_dns_zone : parent_key =>
      "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[parent.resource_group_key].name, "")}/providers/Microsoft.Network/privateDnsZones/${parent.name}"
    }
    private_endpoint = {
      for parent_key, parent in var.private_endpoint : parent_key =>
      "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[parent.resource_group_key].name, "")}/providers/Microsoft.Network/privateEndpoints/${parent.name}"
    }
    redis_cache = {
      for parent_key, parent in var.redis_cache : parent_key =>
      "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[parent.resource_group_key].name, "")}/providers/Microsoft.Cache/redis/${parent.name}"
    }
    service_bus_namespace = {
      for parent_key, parent in var.service_bus_namespace : parent_key =>
      "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[parent.resource_group_key].name, "")}/providers/Microsoft.ServiceBus/namespaces/${parent.name}"
    }
    sql_server = {
      for parent_key, parent in var.sql_server : parent_key =>
      "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[parent.resource_group_key].name, "")}/providers/Microsoft.Sql/servers/${parent.name}"
    }
    storage_account = {
      for parent_key, parent in var.storage_account : parent_key =>
      "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[parent.resource_group_key].name, "")}/providers/Microsoft.Storage/storageAccounts/${parent.name}"
    }
    user_assigned_identity = {
      for parent_key, parent in var.user_assigned_identity : parent_key =>
      "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[parent.resource_group_key].name, "")}/providers/Microsoft.ManagedIdentity/userAssignedIdentities/${parent.name}"
    }
    virtual_network = {
      for parent_key, parent in var.virtual_network : parent_key =>
      "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[parent.resource_group_key].name, "")}/providers/Microsoft.Network/virtualNetworks/${parent.name}"
    }
    web_app = {
      for parent_key, parent in var.web_app : parent_key =>
      "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[parent.resource_group_key].name, "")}/providers/Microsoft.Web/sites/${parent.name}"
    }
  }

  role_assignment_parent_enabled = {
    for resource_type, parents in local.role_assignment_scopes : resource_type => {
      for parent_key, scope in parents : parent_key => local.role_assignment_resource_enabled[resource_type] && (
        resource_type == "private_endpoint" ? try(var.private_endpoint[parent_key].enabled, false) : true
      )
    }
  }

  role_assignment_instances = merge({}, [
    for resource_type, parents in var.role_assignments : {
      for parent_key, assignments in parents : "${resource_type}/${parent_key}" => {
        scope       = try(local.role_assignment_scopes[resource_type][parent_key], null)
        assignments = assignments
      } if lookup(local.role_assignment_flags, resource_type, false) && try(local.role_assignment_parent_enabled[resource_type][parent_key], false) && length(assignments) > 0
    }
  ]...)
}

module "role_assignment" {
  for_each = local.role_assignment_instances

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-role-assignment/azurerm"
  version = "0.3.6"

  role_assignments_azure_resource_manager = {
    for assignment_key, assignment in each.value.assignments : assignment_key => merge(assignment, {
      scope = each.value.scope
    })
  }

  depends_on = [
    module.resource_group,
    module.monitoring,
    module.app_service_plan,
    module.application_insights,
    azurerm_disk_access.this,
    azurerm_eventgrid_system_topic.this,
    module.key_vault,
    module.log_analytics_workspace,
    azurerm_managed_disk.this,
    module.network_security_group,
    azurerm_network_watcher.this,
    module.private_dns_zone,
    module.private_endpoint,
    azurerm_redis_cache.this,
    azurerm_servicebus_namespace.this,
    module.sql_server,
    azurerm_storage_account.this,
    module.user_assigned_identity,
    module.virtual_network,
    module.web_app,
  ]
}
