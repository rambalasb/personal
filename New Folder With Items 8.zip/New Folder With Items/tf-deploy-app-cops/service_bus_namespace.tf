resource "azurerm_servicebus_namespace" "this" {
  for_each = var.enable_service_bus_namespace ? var.service_bus_namespace : {}

  name                          = each.value.name
  resource_group_name           = module.resource_group[each.value.resource_group_key].name
  location                      = coalesce(each.value.location, module.resource_group[each.value.resource_group_key].location)
  sku                           = each.value.sku
  capacity                      = each.value.capacity
  premium_messaging_partitions  = each.value.premium_messaging_partitions
  local_auth_enabled            = each.value.local_auth_enabled
  minimum_tls_version           = each.value.minimum_tls_version
  public_network_access_enabled = each.value.public_network_access_enabled
  tags                          = each.value.tags

  dynamic "identity" {
    for_each = each.value.identity_type == null ? [] : [each.value.identity_type]
    content {
      type = identity.value
    }
  }

  lifecycle {
    prevent_destroy = true
  }
}

import {
  for_each = var.enable_service_bus_namespace ? var.service_bus_namespace_imports : {}

  to = azurerm_servicebus_namespace.this[each.key]
  id = each.value
}
