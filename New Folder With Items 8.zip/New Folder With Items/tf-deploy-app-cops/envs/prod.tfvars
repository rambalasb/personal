# Sub-Cops-Prod (9a891d10-c1e9-4527-a22c-204426e3725b)
# Values come from the Azure resource export of 2026-11-05.
# The VNet is off for the first apply and the web apps are not filled in; see
# "Staged adoption" in the README.

subscription_id = "9a891d10-c1e9-4527-a22c-204426e3725b"

enable_resource_group          = true
enable_monitoring              = true
enable_app_service_plan        = true
enable_application_insights    = true
enable_disk_access             = false
enable_event_grid_system_topic = true
enable_key_vault               = true
enable_log_analytics_workspace = true
enable_managed_disk            = false
enable_network_security_group  = true
enable_network_watcher         = true
enable_private_dns_zone        = false
enable_private_endpoint        = true
enable_redis_cache             = true
enable_service_bus_namespace   = true
enable_sql_server              = true
enable_storage_account         = true
enable_user_assigned_identity  = true
enable_virtual_network         = false
enable_web_app                 = false

enable_resource_group_role_assignment          = false
enable_monitoring_role_assignment              = false
enable_app_service_plan_role_assignment        = false
enable_application_insights_role_assignment    = false
enable_disk_access_role_assignment             = false
enable_event_grid_system_topic_role_assignment = false
enable_key_vault_role_assignment               = false
enable_log_analytics_workspace_role_assignment = false
enable_managed_disk_role_assignment            = false
enable_network_security_group_role_assignment  = false
enable_network_watcher_role_assignment         = false
enable_private_dns_zone_role_assignment        = false
enable_private_endpoint_role_assignment        = false
enable_redis_cache_role_assignment             = false
enable_service_bus_namespace_role_assignment   = false
enable_sql_server_role_assignment              = false
enable_storage_account_role_assignment         = false
enable_user_assigned_identity_role_assignment  = false
enable_virtual_network_role_assignment         = false
enable_web_app_role_assignment                 = false

role_assignments = {}

resource_group = {
  mid_app = {
    name     = "rg-mid-cops-app-prod-canadacentral-001"
    location = "canadacentral"
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Call Out Procedures"
    }
  }
  app = {
    name     = "rg-cops-app-prod-canadacentral-001"
    location = "canadacentral"
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Call Out Procedures"
    }
  }
  network_watcher = {
    name     = "NetworkWatcherRG"
    location = "canadacentral"
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Call Out Procedures"
    }
  }
  defaultresourcegroup_ccan = {
    name     = "DefaultResourceGroup-CCAN"
    location = "canadacentral"
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Call Out Procedures"
    }
  }
}

import_resource_group = {
  mid_app                   = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-mid-cops-app-prod-canadacentral-001"
  app                       = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001"
  network_watcher           = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/NetworkWatcherRG"
  defaultresourcegroup_ccan = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/DefaultResourceGroup-CCAN"
}

# Some action group IDs contain a leading space in the group name; kept as exported.
alert = {
  resource_group_key         = "app"
  root_management_group_name = null
  tags                       = {}
  activity_log_alerts = {
    app_create_update_error = {
      name                = "app-cops-prod-create-update-error"
      resource_group_name = "rg-cops-app-prod-canadacentral-001"
      scopes              = ["/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b"]
      location            = "global"
      description         = ""
      enabled             = true
      criteria = {
        category       = "Administrative"
        operation_name = "Microsoft.Web/serverfarms/Write"
      }
      action_group_keys = []
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-cops-mail-alerts-canadacentral-001"
      ]
      webhook_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Call Out Procedures"
      }
    }
    app_delete = {
      name                = "app-cops-prod-delete"
      resource_group_name = "rg-cops-app-prod-canadacentral-001"
      scopes              = ["/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b"]
      location            = "global"
      description         = ""
      enabled             = true
      criteria = {
        category       = "Administrative"
        operation_name = "Microsoft.Web/sites/Delete"
      }
      action_group_keys = []
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      webhook_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Call Out Procedures"
      }
    }
    app_restart = {
      name                = "app-cops-prod-restart"
      resource_group_name = "rg-cops-app-prod-canadacentral-001"
      scopes              = ["/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b"]
      location            = "global"
      description         = ""
      enabled             = true
      criteria = {
        category       = "Administrative"
        operation_name = "Microsoft.Web/sites/restart/Action"
      }
      action_group_keys = []
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-cops-mail-alerts-canadacentral-001"
      ]
      webhook_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Call Out Procedures"
      }
    }
    app_stop = {
      name                = "app-cops-prod-stop"
      resource_group_name = "rg-cops-app-prod-canadacentral-001"
      scopes              = ["/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b"]
      location            = "global"
      description         = ""
      enabled             = true
      criteria = {
        category       = "Administrative"
        operation_name = "Microsoft.Web/sites/stop/Action"
      }
      action_group_keys = []
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      webhook_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        BusinessUnit            = "Customer & Corporate Affairs"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Call Out Procedures"
      }
    }
    keyvault_deletion = {
      name                = "KeyVault-Deletion-Alert-COPS-Prod-canadacentral"
      resource_group_name = "rg-cops-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvcopsprodcac001"
      ]
      location    = "global"
      description = "This alert will monitor any deletion of key vault"
      enabled     = true
      criteria = {
        category       = "Administrative"
        operation_name = "Microsoft.KeyVault/vaults/delete"
      }
      action_group_keys = []
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      webhook_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affair"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Call Out Procedures"
      }
    }
    service_outage = {
      name                = "Service-Outage-Alert-canadacentral"
      resource_group_name = "rg-mid-cops-app-prod-canadacentral-001"
      scopes              = ["/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b"]
      location            = "global"
      description         = "Service outage alert for COPS Prod environment"
      enabled             = true
      criteria = {
        category = "ServiceHealth"
      }
      action_group_keys = []
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-cops-mail-alerts-canadacentral-001"
      ]
      webhook_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affair"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Call Out Procedures"
      }
    }
  }
  metric_alerts = {
    app_http_canadcentral = {
      name                = "App-HTTP-Alert-canadcentral"
      resource_group_name = "rg-cops-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Web/sites/app-cops-prod-canadacentral-001"
      ]
      description              = "This alert is for HTTP related error for Sub-Cops-Prod App services"
      enabled                  = false
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 1
      target_resource_type     = "Microsoft.Web/sites"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Web/sites"
          metric_name            = "Http5xx"
          aggregation            = "Total"
          operator               = "GreaterThan"
          threshold              = 5
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/lga-servicenow-integration_group/providers/microsoft.insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Call Out Procedures"
      }
    }
    app_http = {
      name                = "App-HTTP-Alert-canadacentral"
      resource_group_name = "rg-cops-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Web/sites/app-cops-nonprod-canadacentral-001"
      ]
      description              = "This alert is for HTTP related error for Sub-Cops-Prod App services"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 1
      target_resource_type     = "Microsoft.Web/sites"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Web/sites"
          metric_name            = "Http5xx"
          aggregation            = "Total"
          operator               = "GreaterThan"
          threshold              = 5
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/lga-servicenow-integration_group/providers/microsoft.insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Call Out Procedures"
      }
    }
    app_health = {
      name                = "App-Health-Alert-canadacentral"
      resource_group_name = "rg-cops-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Web/sites/app-cops-prod-canadacentral-001"
      ]
      description              = "Health check alert for Sub-Cops-Prod Apps"
      enabled                  = false
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 3
      target_resource_type     = "Microsoft.Web/sites"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "microsoft.web/sites"
          metric_name            = "HealthCheckStatus"
          aggregation            = "Average"
          operator               = "LessThan"
          threshold              = 100
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/lga-servicenow-integration_group/providers/microsoft.insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Call Out Procedures"
      }
    }
    sql_db_cpu = {
      name                = "SQL-DB-CPU-Alert-canadacentral"
      resource_group_name = "rg-cops-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Sql/servers/sql-cops-prod-canadacentral-001/databases/COPS40_PRODUCTION"
      ]
      description              = "This alert is for high CPU utilzation of Sub-Cops-prod DB's"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 2
      target_resource_type     = "Microsoft.Sql/servers/databases"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Sql/servers/databases"
          metric_name            = "cpu_percent"
          aggregation            = "Average"
          operator               = "GreaterThan"
          threshold              = 80
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001",
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-db-mail-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Call Out Procedures"
      }
    }
    app_high_cpu = {
      name                = "App-High-CPU-Alert-canadacentral"
      resource_group_name = "rg-mid-cops-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Web/sites/app-cops-prod-canadacentral-001"
      ]
      description              = "This alert is fro Sub-Cops-Prod App's High CPU usage"
      enabled                  = false
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 3
      target_resource_type     = "Microsoft.Web/sites"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Web/sites"
          metric_name            = "CpuTime"
          aggregation            = "Total"
          operator               = "GreaterThan"
          threshold              = 300
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/lga-servicenow-integration_group/providers/microsoft.insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Call Out Procedures"
      }
    }
    app_http_404_informational = {
      name                = "app-cops-prod-http-404-informational"
      resource_group_name = "rg-cops-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Web/sites/app-cops-prod-canadacentral-001"
      ]
      description              = "This alert is for Sub-Fit-Prod App's HTTP errors"
      enabled                  = false
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 3
      target_resource_type     = "Microsoft.Web/sites"
      target_resource_location = "canadacentral"
      dynamic_criteria = {
        metric_namespace         = "Microsoft.Web/sites"
        metric_name              = "Http4xx"
        aggregation              = "Total"
        operator                 = "GreaterOrLessThan"
        alert_sensitivity        = "Medium"
        evaluation_total_count   = 4
        evaluation_failure_count = 4
        ignore_data_before       = null
        skip_metric_validation   = false
        dimensions               = []
      }
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/lga-servicenow-integration_group/providers/microsoft.insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        BusinessUnit            = ""
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Call Out Procedures"
      }
    }
    sql_db_memory = {
      name                = "SQL-DB-Memory-Alert-canadacentral"
      resource_group_name = "rg-cops-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Sql/servers/sql-cops-prod-canadacentral-001/databases/sqldb-2025-cops-prod-canadacentral"
      ]
      description              = ""
      enabled                  = false
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 3
      target_resource_type     = "Microsoft.Sql/servers/databases"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Sql/servers/databases"
          metric_name            = "sql_instance_memory_percent"
          aggregation            = "Maximum"
          operator               = "GreaterThan"
          threshold              = 90
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Call Out Procedures"
      }
    }
    sql_db_deadlock_canadcentral = {
      name                = "SQL-DB-Deadlock-Cops-Prod-canadcentral"
      resource_group_name = "rg-cops-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Sql/servers/sql-cops-prod-canadacentral-001/databases/sqldb-2025-cops-prod-canadacentral"
      ]
      description              = ""
      enabled                  = false
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT1H"
      severity                 = 1
      target_resource_type     = "Microsoft.Sql/servers/databases"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Sql/servers/databases"
          metric_name            = "deadlock"
          aggregation            = "Total"
          operator               = "GreaterThan"
          threshold              = 5
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/lga-servicenow-integration_group/providers/microsoft.insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Call Out Procedures"
      }
    }
    sql_db_deadlock_canadcentral_2 = {
      name                = "SQL-DB-Deadlock-Cops-Prod-canadcentral"
      resource_group_name = "rg-mid-cops-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Sql/servers/sql-cops-prod-canadacentral-001/databases/sqldb-system-cops-prod-canadacentral"
      ]
      description              = ""
      enabled                  = false
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT1H"
      severity                 = 1
      target_resource_type     = "Microsoft.Sql/servers/databases"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Sql/servers/databases"
          metric_name            = "deadlock"
          aggregation            = "Total"
          operator               = "GreaterThan"
          threshold              = 5
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/lga-servicenow-integration_group/providers/microsoft.insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Call Out Procedures"
      }
    }
    sql_tempdb_log_file_size = {
      name                = "SQL-Tempdb-log-file-size-alert-canadacentral"
      resource_group_name = "rg-cops-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Sql/servers/sql-cops-prod-canadacentral-001/databases/sqldb-2025-cops-prod-canadacentral"
      ]
      description              = ""
      enabled                  = false
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT15M"
      severity                 = 2
      target_resource_type     = "Microsoft.Sql/servers/databases"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Sql/servers/databases"
          metric_name            = "tempdb_log_size"
          aggregation            = "Average"
          operator               = "GreaterThan"
          threshold              = 80
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/lga-servicenow-integration_group/providers/microsoft.insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Call Out Procedures"
      }
    }
    sql_tempdb_log_file_size_2 = {
      name                = "SQL-Tempdb-log-file-size-alert-canadacentral"
      resource_group_name = "rg-mid-cops-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Sql/servers/sql-cops-prod-canadacentral-001/databases/sqldb-system-cops-prod-canadacentral"
      ]
      description              = ""
      enabled                  = false
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT15M"
      severity                 = 2
      target_resource_type     = "Microsoft.Sql/servers/databases"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Sql/servers/databases"
          metric_name            = "tempdb_log_size"
          aggregation            = "Average"
          operator               = "GreaterThan"
          threshold              = 80
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/lga-servicenow-integration_group/providers/microsoft.insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Call Out Procedures"
      }
    }
    sql_tempdb_usage = {
      name                = "SQL-Tempdb-usage-alert-canadacentral"
      resource_group_name = "rg-cops-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Sql/servers/sql-cops-prod-canadacentral-001/databases/sqldb-2025-cops-prod-canadacentral"
      ]
      description              = ""
      enabled                  = false
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT15M"
      severity                 = 2
      target_resource_type     = "Microsoft.Sql/servers/databases"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Sql/servers/databases"
          metric_name            = "tempdb_log_size"
          aggregation            = "Average"
          operator               = "GreaterThan"
          threshold              = 85
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/lga-servicenow-integration_group/providers/microsoft.insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Call Out Procedures"
      }
    }
    sql_db_storage_space_size = {
      name                = "SQL-DB-storage-space-size-alert-canadacentral"
      resource_group_name = "rg-cops-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Sql/servers/sql-cops-prod-canadacentral-001/databases/sqldb-2025-cops-prod-canadacentral"
      ]
      description              = ""
      enabled                  = false
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT15M"
      severity                 = 2
      target_resource_type     = "Microsoft.Sql/servers/databases"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Sql/servers/databases"
          metric_name            = "storage_percent"
          aggregation            = "Maximum"
          operator               = "GreaterThan"
          threshold              = 85
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/lga-servicenow-integration_group/providers/microsoft.insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Call Out Procedures"
      }
    }
    sql_db_storage_space_size_2 = {
      name                = "SQL-DB-storage-space-size-alert-canadacentral"
      resource_group_name = "rg-mid-cops-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Sql/servers/sql-cops-prod-canadacentral-001/databases/sqldb-system-cops-prod-canadacentral"
      ]
      description              = ""
      enabled                  = false
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT15M"
      severity                 = 2
      target_resource_type     = "Microsoft.Sql/servers/databases"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Sql/servers/databases"
          metric_name            = "storage_percent"
          aggregation            = "Maximum"
          operator               = "GreaterThan"
          threshold              = 85
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/lga-servicenow-integration_group/providers/microsoft.insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Call Out Procedures"
      }
    }
    sql_tempdb_data_file_size = {
      name                = "SQL-Tempdb-data-file-size-alert-canadacentral"
      resource_group_name = "rg-cops-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Sql/servers/sql-cops-prod-canadacentral-001/databases/sqldb-2025-cops-prod-canadacentral"
      ]
      description              = ""
      enabled                  = false
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT15M"
      severity                 = 2
      target_resource_type     = "Microsoft.Sql/servers/databases"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Sql/servers/databases"
          metric_name            = "tempdb_data_size"
          aggregation            = "Maximum"
          operator               = "GreaterThan"
          threshold              = 80
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/lga-servicenow-integration_group/providers/microsoft.insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Call Out Procedures"
      }
    }
    sql_tempdb_data_file_size_2 = {
      name                = "SQL-Tempdb-data-file-size-alert-canadacentral"
      resource_group_name = "rg-mid-cops-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Sql/servers/sql-cops-prod-canadacentral-001/databases/sqldb-system-cops-prod-canadacentral"
      ]
      description              = ""
      enabled                  = false
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT15M"
      severity                 = 2
      target_resource_type     = "Microsoft.Sql/servers/databases"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Sql/servers/databases"
          metric_name            = "tempdb_data_size"
          aggregation            = "Maximum"
          operator               = "GreaterThan"
          threshold              = 80
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/lga-servicenow-integration_group/providers/microsoft.insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Call Out Procedures"
      }
    }
    sql_db_ddata_io_usage_canadcentral = {
      name                = "SQL-DB-Ddata-IO-usage-alert-canadcentral"
      resource_group_name = "rg-cops-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Sql/servers/sql-cops-prod-canadacentral-001/databases/sqldb-2025-cops-prod-canadacentral"
      ]
      description              = ""
      enabled                  = false
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT15M"
      severity                 = 2
      target_resource_type     = "Microsoft.Sql/servers/databases"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Sql/servers/databases"
          metric_name            = "physical_data_read_percent"
          aggregation            = "Average"
          operator               = "GreaterThan"
          threshold              = 85
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/lga-servicenow-integration_group/providers/microsoft.insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Call Out Procedures"
      }
    }
    sql_db_data_io_usage_canadcentral = {
      name                = "SQL-DB-Data-IO-usage-canadcentral"
      resource_group_name = "rg-mid-cops-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Sql/servers/sql-cops-prod-canadacentral-001/databases/sqldb-system-cops-prod-canadacentral"
      ]
      description              = ""
      enabled                  = false
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT15M"
      severity                 = 2
      target_resource_type     = "Microsoft.Sql/servers/databases"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Sql/servers/databases"
          metric_name            = "physical_data_read_percent"
          aggregation            = "Average"
          operator               = "GreaterThan"
          threshold              = 85
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/lga-servicenow-integration_group/providers/microsoft.insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Call Out Procedures"
      }
    }
    sql_db_log_io_usage_canadcentral = {
      name                = "SQL-DB-Log-IO-usage-Alert-canadcentral"
      resource_group_name = "rg-mid-cops-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Sql/servers/sql-cops-prod-canadacentral-001/databases/sqldb-system-cops-prod-canadacentral"
      ]
      description              = ""
      enabled                  = false
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT15M"
      severity                 = 2
      target_resource_type     = "Microsoft.Sql/servers/databases"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Sql/servers/databases"
          metric_name            = "log_write_percent"
          aggregation            = "Average"
          operator               = "GreaterThan"
          threshold              = 85
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/lga-servicenow-integration_group/providers/microsoft.insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Call Out Procedures"
      }
    }
    sql_db_log_io_usage_canadcentral_2 = {
      name                = "SQL-DB-Log-IO-usage-alert-canadcentral"
      resource_group_name = "rg-cops-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Sql/servers/sql-cops-prod-canadacentral-001/databases/sqldb-2025-cops-prod-canadacentral"
      ]
      description              = ""
      enabled                  = false
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT15M"
      severity                 = 2
      target_resource_type     = "Microsoft.Sql/servers/databases"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Sql/servers/databases"
          metric_name            = "log_write_percent"
          aggregation            = "Average"
          operator               = "GreaterThan"
          threshold              = 85
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/lga-servicenow-integration_group/providers/microsoft.insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Call Out Procedures"
      }
    }
    sql_db_data_io_usage = {
      name                = "SQL-DB-Data-IO-usage-Alert-canadacentral"
      resource_group_name = "rg-cops-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Sql/servers/sql-cops-prod-canadacentral-001/databases/COPS40_PRODUCTION"
      ]
      description              = ""
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT15M"
      severity                 = 2
      target_resource_type     = "Microsoft.Sql/servers/databases"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Sql/servers/databases"
          metric_name            = "physical_data_read_percent"
          aggregation            = "Average"
          operator               = "GreaterThan"
          threshold              = 85
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001",
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-db-mail-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Call Out Procedures"
      }
    }
    sql_db_stoarge_space_size = {
      name                = "SQL-DB-stoarge-space-size-alert-canadacentral"
      resource_group_name = "rg-cops-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Sql/servers/sql-cops-prod-canadacentral-001/databases/COPS40_PRODUCTION"
      ]
      description              = ""
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 2
      target_resource_type     = "Microsoft.Sql/servers/databases"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Sql/servers/databases"
          metric_name            = "storage_percent"
          aggregation            = "Maximum"
          operator               = "GreaterThan"
          threshold              = 80
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001",
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-db-mail-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Call Out Procedures"
      }
    }
    sql_tempdb_data_file_size_3 = {
      name                = "SQL-Tempdb-data-file-size-alert-canadacentral"
      resource_group_name = "NetworkWatcherRG"
      scopes = [
        "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Sql/servers/sql-cops-prod-canadacentral-001/databases/COPS40_PRODUCTION"
      ]
      description              = ""
      enabled                  = false
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT15M"
      severity                 = 2
      target_resource_type     = "Microsoft.Sql/servers/databases"
      target_resource_location = "canadacentral"
      dynamic_criteria = {
        metric_namespace         = "Microsoft.Sql/servers/databases"
        metric_name              = "tempdb_data_size"
        aggregation              = "Average"
        operator                 = "GreaterOrLessThan"
        alert_sensitivity        = "Low"
        evaluation_total_count   = 4
        evaluation_failure_count = 4
        ignore_data_before       = null
        skip_metric_validation   = false
        dimensions               = []
      }
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actionGroups/ag-DB-mail-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Call Out Procedures"
      }
    }
    sql_tempdb_usage_prod = {
      name                = "SQL-Tempdb-usage-prod-alert-canadacentral"
      resource_group_name = "rg-cops-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Sql/servers/sql-cops-prod-canadacentral-001/databases/COPS40_PRODUCTION"
      ]
      description              = ""
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT15M"
      severity                 = 2
      target_resource_type     = "Microsoft.Sql/servers/databases"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Sql/servers/databases"
          metric_name            = "tempdb_log_used_percent"
          aggregation            = "Maximum"
          operator               = "GreaterThan"
          threshold              = 80
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/lga-servicenow-integration_group/providers/microsoft.insights/actionGroups/ ag-servicenow-alerts-canadacentral-001",
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actionGroups/ag-DB-mail-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Call Out Procedures"
      }
    }
    app_health_check = {
      name                = "app-health-check-alert-CanadaCentral"
      resource_group_name = "rg-cops-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Web/sites/api-cops-prod-canadacentral-002"
      ]
      description              = "This alert is for Sub-Cop-NonProd App's Health check alert"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 3
      target_resource_type     = "Microsoft.Web/sites"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Web/sites"
          metric_name            = "HealthCheckStatus"
          aggregation            = "Average"
          operator               = "LessThan"
          threshold              = 100
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-monitor-mail-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Silver"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Call Out Procedures"
      }
    }
    app_http_404_error = {
      name                = "app-cops-prod-http-404-error"
      resource_group_name = "rg-cops-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Web/sites/app-cops-prod-canadacentral-002"
      ]
      description              = "This alert is for Sub-COPS-Prod App's HTTP errors"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 3
      target_resource_type     = "Microsoft.Web/sites"
      target_resource_location = "canadacentral"
      dynamic_criteria = {
        metric_namespace         = "Microsoft.Web/sites"
        metric_name              = "Http4xx"
        aggregation              = "Total"
        operator                 = "GreaterOrLessThan"
        alert_sensitivity        = "Medium"
        evaluation_total_count   = 4
        evaluation_failure_count = 4
        ignore_data_before       = null
        skip_metric_validation   = false
        dimensions               = []
      }
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-cops-mail-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affair"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Call Out Procedures"
      }
    }
    app_high_cpu_2 = {
      name                = "app-high-cpu-alert-canadacentral"
      resource_group_name = "rg-cops-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Web/sites/app-cops-prod-canadacentral-002"
      ]
      description              = "This alert is fro Sub-Cops-Prod App's High CPU usage"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 3
      target_resource_type     = "Microsoft.Web/sites"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Web/sites"
          metric_name            = "CpuTime"
          aggregation            = "Total"
          operator               = "GreaterThan"
          threshold              = 300
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affair"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Call Out Procedures"
      }
    }
    sql_db_deadlock = {
      name                = "sql-db-deadlock-cops-prod-canadacentral"
      resource_group_name = "rg-cops-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Sql/servers/sql-cops-prod-canadacentral-001/databases/COPS40_PRODUCTION"
      ]
      description              = "COPS SQL db deadlock alert in the Prod environment"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT1H"
      severity                 = 1
      target_resource_type     = "Microsoft.Sql/servers/databases"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Sql/servers/databases"
          metric_name            = "deadlock"
          aggregation            = "Total"
          operator               = "GreaterThan"
          threshold              = 5
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001",
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-db-mail-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affair"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Call Out Procedures"
      }
    }
    sql_db_memory_canadacentral001 = {
      name                = "sql-db-memory-alert-canadacentral001"
      resource_group_name = "rg-cops-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Sql/servers/sql-cops-prod-canadacentral-001/databases/COPS40_PRODUCTION"
      ]
      description              = "This alert is for high memory utilization of Sub-Cop-Prod DB"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 3
      target_resource_type     = "Microsoft.Sql/servers/databases"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Sql/servers/databases"
          metric_name            = "sql_instance_memory_percent"
          aggregation            = "Maximum"
          operator               = "GreaterThan"
          threshold              = 90
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-db-mail-alerts-canadacentral-001",
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affair"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Call Out Procedures"
      }
    }
    sql_tempdb_log_file_size_canadacentral001 = {
      name                = "sql-tempdb-log-file-size-alert-canadacentral001"
      resource_group_name = "rg-cops-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Sql/servers/sql-cops-prod-canadacentral-001/databases/COPS40_PRODUCTION"
      ]
      description              = "SQL tempdb log file size alert for COPS Prod environment"
      enabled                  = false
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT15M"
      severity                 = 2
      target_resource_type     = "Microsoft.Sql/servers/databases"
      target_resource_location = "canadacentral"
      dynamic_criteria = {
        metric_namespace         = "Microsoft.Sql/servers/databases"
        metric_name              = "tempdb_log_size"
        aggregation              = "Average"
        operator                 = "GreaterOrLessThan"
        alert_sensitivity        = "Low"
        evaluation_total_count   = 4
        evaluation_failure_count = 4
        ignore_data_before       = null
        skip_metric_validation   = false
        dimensions               = []
      }
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001",
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-db-mail-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affair"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Call Out Procedures"
      }
    }
    azure_cache_redis_cpu = {
      name                = "Azure-Cache-Redis-CPU-Alert-CanadaCentral"
      resource_group_name = "rg-cops-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Cache/Redis/redis-cops-prod-canadacentral-001"
      ]
      description              = "Azure Cache for Redis CPU Alert in the Prod environment\n"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT15M"
      severity                 = 3
      target_resource_type     = "Microsoft.Cache/Redis"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Cache/Redis"
          metric_name            = "percentProcessorTime"
          aggregation            = "Maximum"
          operator               = "GreaterThan"
          threshold              = 85
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001",
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-db-mail-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affair"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Call Out Procedures"
      }
    }
    azure_cache_redis_highmemory = {
      name                = "Azure-Cache-Redis-HighMemory-Alert-CanadaCentral"
      resource_group_name = "rg-cops-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Cache/Redis/redis-cops-prod-canadacentral-001"
      ]
      description              = "Azure Cache for Redis High memory alert in the Prod environment"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 3
      target_resource_type     = "Microsoft.Cache/Redis"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Cache/Redis"
          metric_name            = "usedmemorypercentage"
          aggregation            = "Average"
          operator               = "GreaterThan"
          threshold              = 90
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001",
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-db-mail-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affair"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Call Out Procedures"
      }
    }
    azure_cache_redis_serverload = {
      name                = "Azure-Cache-Redis-ServerLoad-Alert-CanadaCentral"
      resource_group_name = "rg-cops-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Cache/Redis/redis-cops-prod-canadacentral-001"
      ]
      description              = "Azure Cache Redis ServerLoad Alert in the Prod environment"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT15M"
      severity                 = 3
      target_resource_type     = "Microsoft.Cache/Redis"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Cache/Redis"
          metric_name            = "serverLoad"
          aggregation            = "Average"
          operator               = "GreaterThan"
          threshold              = 90
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-db-mail-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affair"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Call Out Procedures"
      }
    }
    azure_cache_redis_connectedclient = {
      name                = "Azure-Cache-Redis-Connectedclient-Alert-CanadaCentral"
      resource_group_name = "rg-cops-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Cache/Redis/redis-cops-prod-canadacentral-001"
      ]
      description              = "Azure-Cache-Redis-Connectedclient-Alert-CanadaCentral\n"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT15M"
      severity                 = 3
      target_resource_type     = "Microsoft.Cache/Redis"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Cache/Redis"
          metric_name            = "connectedclients"
          aggregation            = "Maximum"
          operator               = "GreaterThan"
          threshold              = 80
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-db-mail-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affair"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Call Out Procedures"
      }
    }
    azure_cache_redis_latency = {
      name                = "Azure-Cache-Redis-latency-Alert-CanadaCentral"
      resource_group_name = "rg-cops-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Cache/Redis/redis-cops-prod-canadacentral-001"
      ]
      description              = "Azure-Cache-Redis-latency-Alert-CanadaCentral in the prod environment\n"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT15M"
      severity                 = 3
      target_resource_type     = "Microsoft.Cache/Redis"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Cache/Redis"
          metric_name            = "cacheLatency"
          aggregation            = "Average"
          operator               = "GreaterThan"
          threshold              = 10
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-db-mail-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affair"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Call Out Procedures"
      }
    }
  }
  log_search_alerts = {
    keyvault_secret_expired = {
      name                = "KeyVault-Secret-Expired-Alert-COPS-Prod-canadacentral"
      resource_group_name = "rg-cops-app-prod-canadacentral-001"
      location            = "canadacentral"
      scopes = [
        "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvcopsprodcac001"
      ]
      severity                          = 0
      evaluation_frequency              = "PT5M"
      window_duration                   = "PT30M"
      description                       = "Alert for expired secret in a Key Vault in COPS Prod environment"
      display_name                      = "KeyVault-Secret-Expired-Alert-COPS-Prod-canadacentral"
      enabled                           = true
      auto_mitigation_enabled           = false
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = null
      target_resource_types             = ["Microsoft.KeyVault/vaults"]
      criteria = [
        {
          query                   = "AzureDiagnostics\n        | where ResourceProvider == \"MICROSOFT.KEYVAULT\"\n        | where OperationName contains \"SecretExpired\"\n"
          time_aggregation_method = "Count"
          threshold               = 1
          operator                = "GreaterThan"
          resource_id_column      = ""
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affair"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Call Out Procedures"
      }
    }
    keyvault_secret_near_expiry = {
      name                = "KeyVault-Secret-Near-Expiry-Alert-COPS-Prod-canadacentral"
      resource_group_name = "rg-cops-app-prod-canadacentral-001"
      location            = "canadacentral"
      scopes = [
        "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvcopsprodcac001"
      ]
      severity                          = 3
      evaluation_frequency              = "PT5M"
      window_duration                   = "PT30M"
      description                       = "Alert for secret in a Key Vault is about to expire in COPS Prod environment"
      display_name                      = "KeyVault-Secret-Near-Expiry-Alert-COPS-Prod-canadacentral"
      enabled                           = true
      auto_mitigation_enabled           = false
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = null
      target_resource_types             = ["Microsoft.KeyVault/vaults"]
      criteria = [
        {
          query                   = "AzureDiagnostics\n| where ResourceProvider == \"MICROSOFT.KEYVAULT\"\n| where OperationName contains \"SecretNearExpiry\"\n"
          time_aggregation_method = "Count"
          threshold               = 1
          operator                = "GreaterThanOrEqual"
          resource_id_column      = ""
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-monitor-mail-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affair"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Call Out Procedures"
      }
    }
    resource_creation = {
      name                              = "Resource-Creation-Alert-COPS-Prod-canadacentral"
      resource_group_name               = "rg-mid-cops-app-prod-canadacentral-001"
      location                          = "canadacentral"
      scopes                            = ["/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b"]
      severity                          = 4
      evaluation_frequency              = "PT10M"
      window_duration                   = "PT30M"
      description                       = "Alert when a new resource is created in COPS Prod environment."
      display_name                      = "Resource-Creation-Alert-COPS-Prod-canadacentral"
      enabled                           = true
      auto_mitigation_enabled           = false
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = null
      target_resource_types             = null
      criteria = [
        {
          query                   = "AzureActivity\n        | where OperationNameValue has \"Microsoft.Resources/deployments/write\"\n        | where CategoryValue == \"Administrative\"\n        | where ActivityStatusValue == \"Success\"\n"
          time_aggregation_method = "Count"
          threshold               = 10
          operator                = "GreaterThanOrEqual"
          resource_id_column      = "_ResourceId"
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-monitor-mail-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affair"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        name                    = "Call Out Procedures"
      }
    }
    storage_account_container_deletion = {
      name                              = "Storage-Account-Container-Deletion-Alert-canadacentral"
      resource_group_name               = "rg-mid-cops-app-prod-canadacentral-001"
      location                          = "canadacentral"
      scopes                            = ["/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b"]
      severity                          = 0
      evaluation_frequency              = "PT5M"
      window_duration                   = "PT30M"
      description                       = "Storage account container deletion alert in COPS prod environment"
      display_name                      = "Storage-Account-Container-Deletion-Alert-canadacentral"
      enabled                           = true
      auto_mitigation_enabled           = false
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = null
      target_resource_types             = null
      criteria = [
        {
          query                   = "AzureActivity\n        | where ResourceProviderValue == \"MICROSOFT.STORAGE\" and OperationNameValue == \"MICROSOFT.STORAGE/STORAGEACCOUNTS/BLOBSERVICES/CONTAINERS/DELETE\"\n"
          time_aggregation_method = "Count"
          threshold               = 1
          operator                = "GreaterThanOrEqual"
          resource_id_column      = "_ResourceId"
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affair"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Call Out Procedures"
      }
    }
    storage_account_deletion = {
      name                              = "Storage-Account-Deletion-Alert-canadacentral"
      resource_group_name               = "rg-mid-cops-app-prod-canadacentral-001"
      location                          = "canadacentral"
      scopes                            = ["/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b"]
      severity                          = 3
      evaluation_frequency              = "PT5M"
      window_duration                   = "PT30M"
      description                       = "Storage account deletetion alert in COPS Prod environment"
      display_name                      = "Storage-Account-Deletion-Alert-canadacentral"
      enabled                           = true
      auto_mitigation_enabled           = false
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = null
      target_resource_types             = null
      criteria = [
        {
          query                   = "AzureActivity\n        | where ResourceProviderValue == \"MICROSOFT.STORAGE\" and OperationNameValue == \"MICROSOFT.STORAGE/STORAGEACCOUNTS/DELETE\"\n"
          time_aggregation_method = "Count"
          threshold               = 1
          operator                = "GreaterThanOrEqual"
          resource_id_column      = "_ResourceId"
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Customer & Corporate Affair"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Call Out Procedures"
      }
    }
  }
  alert_processing_rules = {
    cops_app_prod_suppression = {
      name                = "COPS-App-Prod-suppression-alert"
      resource_group_name = "rg-cops-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b",
        "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001",
        "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-mid-cops-app-prod-canadacentral-001"
      ]
      type             = "suppression"
      description      = "COPS-Prod patching scheduled maintenance "
      enabled          = false
      action_group_ids = []
      conditions       = {}
      schedule = {
        effective_from  = "2026-10-26T14:00:00"
        effective_until = "2026-10-26T18:00:00"
        time_zone       = "Eastern Standard Time"
        recurrence      = null
      }
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = "80025906"
        Environment             = "Prod"
        Name                    = "Call Out Procedures"
      }
    }
  }
}

activity_log_alert_imports = {
  app_create_update_error = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/app-cops-prod-create-update-error"
  app_delete              = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/app-cops-prod-delete"
  app_restart             = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/app-cops-prod-restart"
  app_stop                = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/app-cops-prod-stop"
  keyvault_deletion       = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/KeyVault-Deletion-Alert-COPS-Prod-canadacentral"
  service_outage          = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-mid-cops-app-prod-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/Service-Outage-Alert-canadacentral"
}

metric_alert_imports = {
  app_http_canadcentral                     = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/App-HTTP-Alert-canadcentral"
  app_http                                  = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/App-HTTP-Alert-canadacentral"
  app_health                                = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/App-Health-Alert-canadacentral"
  sql_db_cpu                                = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/SQL-DB-CPU-Alert-canadacentral"
  app_high_cpu                              = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-mid-cops-app-prod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/App-High-CPU-Alert-canadacentral"
  app_http_404_informational                = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/app-cops-prod-http-404-informational"
  sql_db_memory                             = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/SQL-DB-Memory-Alert-canadacentral"
  sql_db_deadlock_canadcentral              = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/SQL-DB-Deadlock-Cops-Prod-canadcentral"
  sql_db_deadlock_canadcentral_2            = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-mid-cops-app-prod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/SQL-DB-Deadlock-Cops-Prod-canadcentral"
  sql_tempdb_log_file_size                  = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/SQL-Tempdb-log-file-size-alert-canadacentral"
  sql_tempdb_log_file_size_2                = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-mid-cops-app-prod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/SQL-Tempdb-log-file-size-alert-canadacentral"
  sql_tempdb_usage                          = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/SQL-Tempdb-usage-alert-canadacentral"
  sql_db_storage_space_size                 = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/SQL-DB-storage-space-size-alert-canadacentral"
  sql_db_storage_space_size_2               = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-mid-cops-app-prod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/SQL-DB-storage-space-size-alert-canadacentral"
  sql_tempdb_data_file_size                 = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/SQL-Tempdb-data-file-size-alert-canadacentral"
  sql_tempdb_data_file_size_2               = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-mid-cops-app-prod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/SQL-Tempdb-data-file-size-alert-canadacentral"
  sql_db_ddata_io_usage_canadcentral        = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/SQL-DB-Ddata-IO-usage-alert-canadcentral"
  sql_db_data_io_usage_canadcentral         = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-mid-cops-app-prod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/SQL-DB-Data-IO-usage-canadcentral"
  sql_db_log_io_usage_canadcentral          = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-mid-cops-app-prod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/SQL-DB-Log-IO-usage-Alert-canadcentral"
  sql_db_log_io_usage_canadcentral_2        = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/SQL-DB-Log-IO-usage-alert-canadcentral"
  sql_db_data_io_usage                      = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/SQL-DB-Data-IO-usage-Alert-canadacentral"
  sql_db_stoarge_space_size                 = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/SQL-DB-stoarge-space-size-alert-canadacentral"
  sql_tempdb_data_file_size_3               = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/NetworkWatcherRG/providers/Microsoft.Insights/metricAlerts/SQL-Tempdb-data-file-size-alert-canadacentral"
  sql_tempdb_usage_prod                     = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/SQL-Tempdb-usage-prod-alert-canadacentral"
  app_health_check                          = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/app-health-check-alert-CanadaCentral"
  app_http_404_error                        = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/app-cops-prod-http-404-error"
  app_high_cpu_2                            = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/app-high-cpu-alert-canadacentral"
  sql_db_deadlock                           = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/sql-db-deadlock-cops-prod-canadacentral"
  sql_db_memory_canadacentral001            = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/sql-db-memory-alert-canadacentral001"
  sql_tempdb_log_file_size_canadacentral001 = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/sql-tempdb-log-file-size-alert-canadacentral001"
  azure_cache_redis_cpu                     = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/Azure-Cache-Redis-CPU-Alert-CanadaCentral"
  azure_cache_redis_highmemory              = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/Azure-Cache-Redis-HighMemory-Alert-CanadaCentral"
  azure_cache_redis_serverload              = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/Azure-Cache-Redis-ServerLoad-Alert-CanadaCentral"
  azure_cache_redis_connectedclient         = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/Azure-Cache-Redis-Connectedclient-Alert-CanadaCentral"
  azure_cache_redis_latency                 = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/Azure-Cache-Redis-latency-Alert-CanadaCentral"
}

log_search_alert_imports = {
  keyvault_secret_expired            = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/KeyVault-Secret-Expired-Alert-COPS-Prod-canadacentral"
  keyvault_secret_near_expiry        = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/KeyVault-Secret-Near-Expiry-Alert-COPS-Prod-canadacentral"
  resource_creation                  = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-mid-cops-app-prod-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/Resource-Creation-Alert-COPS-Prod-canadacentral"
  storage_account_container_deletion = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-mid-cops-app-prod-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/Storage-Account-Container-Deletion-Alert-canadacentral"
  storage_account_deletion           = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-mid-cops-app-prod-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/Storage-Account-Deletion-Alert-canadacentral"
}

# Not managed here:
#   actionrules 'Suppress notifications - COPS PROD sub' (DefaultResourceGroup-CCAN): azurerm rejects processing rule names with spaces; rename it in Azure to manage it
#   actionrules 'Suppress notifications - COPS -PROD sub' (NetworkWatcherRG): azurerm rejects processing rule names with spaces; rename it in Azure to manage it
#   actionrules 'Suppress notifications - COPS-PROD sub' (rg-cops-app-prod-canadacentral-001): azurerm rejects processing rule names with spaces; rename it in Azure to manage it
#   actionrules 'Suppress notifications - COPS-PROD sub' (rg-mid-cops-app-prod-canadacentral-001): azurerm rejects processing rule names with spaces; rename it in Azure to manage it
#   smartDetectorAlertRules 'Failure Anomalies - ai-func-wrk-cops-prod-canadancentral-001' (rg-cops-app-prod-canadacentral-001): created by Azure for App Insights
alert_processing_rule_imports = {
  cops_app_prod_suppression = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.AlertsManagement/actionRules/COPS-App-Prod-suppression-alert"
}

app_service_plan = {
  app = {
    name                            = "asp-cops-prod-linux-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    os_type                         = "Linux"
    sku_name                        = "P1v4"
    worker_count                    = 2
    maximum_elastic_worker_count    = 2
    per_site_scaling_enabled        = false
    premium_plan_auto_scale_enabled = false
    zone_balancing_enabled          = true
    app_service_environment_id      = null
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Call Out Procedures"
    }
  }
}

app_service_plan_imports = {
  app = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Web/serverFarms/asp-cops-prod-linux-canadacentral-001"
}

# The daily cap is not in the export (100 is the provider default); confirm with
# az monitor app-insights component billing show.
application_insights = {
  func = {
    name                          = "ai-func-cops-prod-canadacentral-001"
    resource_group_key            = "app"
    location                      = "canadacentral"
    workspace_id                  = "/subscriptions/7d54d6f7-83d9-48cf-ac35-1068bcfd0561/resourceGroups/rg-siem-security-canadacentral-001/providers/Microsoft.OperationalInsights/workspaces/la-siem-security-canadacentral-001"
    application_type              = "web"
    retention_in_days             = 90
    daily_data_cap_in_gb          = 100
    sampling_percentage           = 0
    internet_ingestion_enabled    = true
    internet_query_enabled        = true
    local_authentication_disabled = false
    disable_ip_masking            = false
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Call Out Procedures"
    }
  }
  func_wrk = {
    name                          = "ai-func-wrk-cops-prod-canadancentral-001"
    resource_group_key            = "app"
    location                      = "canadacentral"
    workspace_id                  = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/DefaultResourceGroup-CCAN/providers/Microsoft.OperationalInsights/workspaces/DefaultWorkspace-9a891d10-c1e9-4527-a22c-204426e3725b-CCAN"
    application_type              = "web"
    retention_in_days             = 90
    daily_data_cap_in_gb          = 100
    sampling_percentage           = 0
    internet_ingestion_enabled    = true
    internet_query_enabled        = true
    local_authentication_disabled = false
    disable_ip_masking            = false
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "80025906"
      Environment             = "Prod"
      Name                    = "Call Out Procedures"
    }
  }
}

application_insights_imports = {
  func     = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Insights/components/ai-func-cops-prod-canadacentral-001"
  func_wrk = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Insights/components/ai-func-wrk-cops-prod-canadancentral-001"
}

disk_access = {}

disk_access_imports = {}

event_grid_system_topic = {
  app_storage = {
    name                        = "stcopsprodcac001-2567d03f-a8fb-4621-89ba-ec97954ea4d1"
    resource_group_key          = "app"
    location                    = "canadacentral"
    topic_type                  = "microsoft.storage.storageaccounts"
    source_resource_id          = null
    exported_source_resource_id = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/microsoft.storage/storageaccounts/stcopsprodcac001"
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Call Out Procedures"
    }
  }
  app_002_storage = {
    name                        = "stcopsprodcac002-6ba5f03d-a9e1-4e74-9aa0-59cf05165506"
    resource_group_key          = "app"
    location                    = "canadacentral"
    topic_type                  = "microsoft.storage.storageaccounts"
    source_resource_id          = null
    exported_source_resource_id = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/microsoft.storage/storageaccounts/stcopsprodcac002"
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Call Out Procedures"
    }
  }
  network_watcher_storage = {
    name                        = "stnwcopsprdcac001xdf-33f37712-1f12-4b97-aa1f-8ca9216c9908"
    resource_group_key          = "network_watcher"
    location                    = "canadacentral"
    topic_type                  = "microsoft.storage.storageaccounts"
    source_resource_id          = null
    exported_source_resource_id = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/networkwatcherrg/providers/microsoft.storage/storageaccounts/stnwcopsprdcac001xdf"
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Call Out Procedures"
    }
  }
}

event_grid_system_topic_imports = {
  app_storage             = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.EventGrid/systemTopics/stcopsprodcac001-2567d03f-a8fb-4621-89ba-ec97954ea4d1"
  app_002_storage         = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.EventGrid/systemTopics/stcopsprodcac002-6ba5f03d-a9e1-4e74-9aa0-59cf05165506"
  network_watcher_storage = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/NetworkWatcherRG/providers/Microsoft.EventGrid/systemTopics/stnwcopsprdcac001xdf-33f37712-1f12-4b97-aa1f-8ca9216c9908"
}

key_vault = {
  app = {
    name                            = "kvcopsprodcac001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    tenant_id                       = "8fbb85e8-0cbc-48c3-a2e9-528cef30ec27"
    sku_name                        = "premium"
    enabled_for_deployment          = true
    enabled_for_disk_encryption     = true
    enabled_for_template_deployment = true
    legacy_access_policies_enabled  = false
    public_network_access_enabled   = true
    purge_protection_enabled        = true
    soft_delete_retention_days      = 90
    network_acls = {
      bypass                     = "AzureServices"
      default_action             = "Deny"
      ip_rules                   = ["155.190.0.11/32"]
      virtual_network_subnet_ids = []
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Call Out Procedures"
    }
  }
}

key_vault_imports = {
  app = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvcopsprodcac001"
}

log_analytics_workspace = {
  default_ccan = {
    name                            = "DefaultWorkspace-9a891d10-c1e9-4527-a22c-204426e3725b-CCAN"
    resource_group_key              = "defaultresourcegroup_ccan"
    location                        = "canadacentral"
    sku                             = "PerGB2018"
    retention_in_days               = 30
    daily_quota_gb                  = -1
    internet_ingestion_enabled      = "true"
    internet_query_enabled          = "true"
    local_authentication_enabled    = true
    allow_resource_only_permissions = true
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Call Out Procedures"
    }
  }
}

log_analytics_workspace_imports = {
  default_ccan = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/DefaultResourceGroup-CCAN/providers/Microsoft.OperationalInsights/workspaces/DefaultWorkspace-9a891d10-c1e9-4527-a22c-204426e3725b-CCAN"
}

managed_disk = {}

managed_disk_imports = {}

# Protocols are written as Tcp because the wrapper rejects upper case. Azure
# reports TCP, so a case-only update may appear.
network_security_group = {
  app = {
    name               = "nsg-app-cops-prod-canadacentral-001"
    resource_group_key = "app"
    location           = "canadacentral"
    security_rules = {
      allowonprem = {
        name                       = "AllowOnPrem"
        access                     = "Allow"
        direction                  = "Inbound"
        priority                   = 200
        protocol                   = "*"
        source_port_range          = "*"
        destination_port_range     = "*"
        source_address_prefixes    = ["10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "142.52.0.0/16"]
        destination_address_prefix = "*"
      }
      denyallinbound = {
        name                       = "DenyAllInbound"
        access                     = "Deny"
        direction                  = "Inbound"
        priority                   = 1000
        protocol                   = "*"
        source_port_range          = "*"
        destination_port_range     = "*"
        source_address_prefix      = "*"
        destination_address_prefix = "*"
      }
      allowinternalhealthping = {
        name                       = "AllowInternalHealthPing"
        access                     = "Allow"
        direction                  = "Inbound"
        priority                   = 210
        protocol                   = "Tcp"
        source_port_range          = "*"
        destination_port_ranges    = ["80", "8080"]
        source_address_prefix      = "AzureLoadBalancer"
        destination_address_prefix = "10.195.48.0/26"
      }
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Call Out Procedures"
    }
  }
  pep = {
    name               = "nsg-pep-cops-prod-canadacentral-001"
    resource_group_key = "app"
    location           = "canadacentral"
    security_rules = {
      allowonprem = {
        name                       = "AllowOnPrem"
        access                     = "Allow"
        direction                  = "Inbound"
        priority                   = 200
        protocol                   = "*"
        source_port_range          = "*"
        destination_port_range     = "*"
        source_address_prefixes    = ["10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "142.52.0.0/16"]
        destination_address_prefix = "*"
      }
      allowprodrunner = {
        name                       = "AllowProdRunner"
        access                     = "Allow"
        direction                  = "Inbound"
        priority                   = 800
        protocol                   = "*"
        source_port_range          = "*"
        destination_port_range     = "443"
        source_address_prefix      = "10.195.115.7"
        destination_address_prefix = "*"
      }
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Call Out Procedures"
    }
  }
  sql = {
    name               = "nsg-sql-cops-prod-canadacentral-001"
    resource_group_key = "app"
    location           = "canadacentral"
    security_rules = {
      allowonprem = {
        name                       = "AllowOnPrem"
        access                     = "Allow"
        direction                  = "Inbound"
        priority                   = 200
        protocol                   = "*"
        source_port_range          = "*"
        destination_port_range     = "*"
        source_address_prefixes    = ["10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "142.52.0.0/16"]
        destination_address_prefix = "*"
      }
      denyallinbound = {
        name                       = "DenyAllInbound"
        access                     = "Deny"
        direction                  = "Inbound"
        priority                   = 1000
        protocol                   = "*"
        source_port_range          = "*"
        destination_port_range     = "*"
        source_address_prefix      = "*"
        destination_address_prefix = "*"
      }
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Call Out Procedures"
    }
  }
}

import_network_security_group = {
  app = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-app-cops-prod-canadacentral-001"
  pep = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-pep-cops-prod-canadacentral-001"
  sql = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-sql-cops-prod-canadacentral-001"
}

network_security_rule_imports = {
  "app/allowonprem" = {
    nsg_key  = "app"
    rule_key = "allowonprem"
    id       = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-app-cops-prod-canadacentral-001/securityRules/AllowOnPrem"
  }
  "app/denyallinbound" = {
    nsg_key  = "app"
    rule_key = "denyallinbound"
    id       = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-app-cops-prod-canadacentral-001/securityRules/DenyAllInbound"
  }
  "app/allowinternalhealthping" = {
    nsg_key  = "app"
    rule_key = "allowinternalhealthping"
    id       = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-app-cops-prod-canadacentral-001/securityRules/AllowInternalHealthPing"
  }
  "pep/allowonprem" = {
    nsg_key  = "pep"
    rule_key = "allowonprem"
    id       = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-pep-cops-prod-canadacentral-001/securityRules/AllowOnPrem"
  }
  "pep/allowprodrunner" = {
    nsg_key  = "pep"
    rule_key = "allowprodrunner"
    id       = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-pep-cops-prod-canadacentral-001/securityRules/AllowProdRunner"
  }
  "sql/allowonprem" = {
    nsg_key  = "sql"
    rule_key = "allowonprem"
    id       = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-sql-cops-prod-canadacentral-001/securityRules/AllowOnPrem"
  }
  "sql/denyallinbound" = {
    nsg_key  = "sql"
    rule_key = "denyallinbound"
    id       = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-sql-cops-prod-canadacentral-001/securityRules/DenyAllInbound"
  }
}

network_watcher = {
  canadacentral = {
    name               = "NetworkWatcher_canadacentral"
    resource_group_key = "network_watcher"
    location           = "canadacentral"
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Call Out Procedures"
    }
  }
}

network_watcher_imports = {
  canadacentral = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/NetworkWatcherRG/providers/Microsoft.Network/networkWatchers/NetworkWatcher_canadacentral"
}

private_dns_zone = {}

private_dns_zone_imports = {}

private_dns_zone_link_imports = {}

# The Service Bus endpoint is named pe-sb-cops-nonprod-canadacentral-001 although
# it is in prod; kept as exported.
private_endpoint = {
  blob = {
    enabled                         = true
    name                            = "pep-blob-cops-prod-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-prod-canadacentral-001/subnets/snet-pep-cops-prod-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Storage/storageAccounts/stcopsprodcac001"
    private_service_connection_name = "stcopsprodcac001"
    subresource_names               = ["blob"]
    network_interface_name          = null
    private_dns_zone_group_name     = "cops_prod_canadacentral_blob_zone_group"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net"
    ]
    ip_configurations = {}
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Call Out Procedures"
    }
  }
  api = {
    enabled                         = true
    name                            = "pep-api-cops-prod-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-prod-canadacentral-001/subnets/snet-pep-cops-prod-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourcegroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Web/sites/api-cops-prod-canadacentral-002"
    private_service_connection_name = "pep-api-cops-prod-canadacentral-001"
    subresource_names               = ["sites"]
    network_interface_name          = "pep-api-cops-prod-canadacentral-001-nic"
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.azurewebsites.net"
    ]
    ip_configurations = {
      pep_api_cops_prod_canadacentral_001 = {
        name               = "pep-api-cops-prod-canadacentral-001"
        private_ip_address = "10.195.50.6"
        subresource_name   = "sites"
        member_name        = "sites"
      }
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Call Out Procedures"
    }
  }
  sql = {
    enabled                         = true
    name                            = "pep-sql-cops-prod-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-prod-canadacentral-001/subnets/snet-pep-cops-prod-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Sql/servers/sql-cops-prod-canadacentral-001"
    private_service_connection_name = "sql-cops-prod-canadacentral-001"
    subresource_names               = ["SqlServer"]
    network_interface_name          = null
    private_dns_zone_group_name     = "cops_prod_canadacentral_sql_zone_group"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.database.windows.net"
    ]
    ip_configurations = {}
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Call Out Procedures"
    }
  }
  app = {
    enabled                         = true
    name                            = "pep-app-cops-prod-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-prod-canadacentral-001/subnets/snet-pep-cops-prod-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Web/sites/app-cops-prod-canadacentral-002"
    private_service_connection_name = "pep-app-cops-prod-canadacentral-001"
    subresource_names               = ["sites"]
    network_interface_name          = "pep-app-cops-prod-canadacentral-001-nic"
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.azurewebsites.net"
    ]
    ip_configurations = {
      app_cops_prod_canadacentral_001 = {
        name               = "app-cops-prod-canadacentral-001"
        private_ip_address = "10.195.50.8"
        subresource_name   = "sites"
        member_name        = "sites"
      }
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Call Out Procedures"
    }
  }
  file = {
    enabled                         = true
    name                            = "pep-file-cops-prod-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-prod-canadacentral-001/subnets/snet-pep-cops-prod-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Storage/storageAccounts/stfilescopsprodcac01"
    private_service_connection_name = "stfilescopsprodcac01"
    subresource_names               = ["file"]
    network_interface_name          = null
    private_dns_zone_group_name     = "cops_prod_canadacentral_file_zone_group"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.file.core.windows.net"
    ]
    ip_configurations = {}
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Call Out Procedures"
    }
  }
  redis = {
    enabled                         = true
    name                            = "pep-redis-cops-prod-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-prod-canadacentral-001/subnets/snet-pep-cops-prod-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Cache/redis/redis-cops-prod-canadacentral-001"
    private_service_connection_name = "pep-redis-cops-prod-canadacentral-001"
    subresource_names               = ["redisCache"]
    network_interface_name          = "pep-redis-cops-prod-canadacentral-001-nic"
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.redis.cache.windows.net"
    ]
    ip_configurations = {}
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Call Out Procedures"
    }
  }
  kv = {
    enabled                         = true
    name                            = "pep-kv-cops-prod-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-prod-canadacentral-001/subnets/snet-pep-cops-prod-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvcopsprodcac001"
    private_service_connection_name = "pep-kv-cops-prod-canadacentral-001"
    subresource_names               = ["vault"]
    network_interface_name          = "pep-kv-cops-prod-canadacentral-001-nic"
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.vaultcore.azure.net"
    ]
    ip_configurations = {
      pep_kv_cops_prod_canadacentral_001 = {
        name               = "pep-kv-cops-prod-canadacentral-001"
        private_ip_address = "10.195.50.4"
        subresource_name   = "vault"
        member_name        = "default"
      }
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Call Out Procedures"
    }
  }
  network_watcher_storage = {
    enabled                         = true
    name                            = "pep-stnwcopsprdcac001xdf"
    resource_group_key              = "network_watcher"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-prod-canadacentral-001/subnets/snet-pep-cops-prod-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourcegroups/NetworkWatcherRG/providers/Microsoft.Storage/storageAccounts/stnwcopsprdcac001xdf"
    private_service_connection_name = "pep-stnwcopsprdcac001xdf"
    subresource_names               = ["blob"]
    network_interface_name          = "pep-stnwcopsprdcac001xdf-nic"
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net"
    ]
    ip_configurations = {}
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Call Out Procedures"
    }
  }
  wrk = {
    enabled                         = true
    name                            = "pe-wrk-cops-prod-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-prod-canadacentral-001/subnets/snet-pep-cops-prod-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Web/Sites/wrk-cops-prod-canadacentral-001"
    private_service_connection_name = "pe-wrk-cops-prod-canadacentral-001"
    subresource_names               = ["sites"]
    network_interface_name          = null
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.azurewebsites.net"
    ]
    ip_configurations = {}
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "80025906"
      Environment             = "Prod"
      Name                    = "Call Out Procedures"
    }
  }
  sb = {
    enabled                         = true
    name                            = "pe-sb-cops-nonprod-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-prod-canadacentral-001/subnets/snet-pep-cops-prod-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.ServiceBus/namespaces/sb-cops-prod-canadacentral-001"
    private_service_connection_name = "pe-sb-cops-nonprod-canadacentral-001_df12255e-dd73-43e2-bc30-76fc68eb0040"
    subresource_names               = ["namespace"]
    network_interface_name          = null
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.azurewebsites.net",
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.servicebus.windows.net"
    ]
    ip_configurations = {}
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "80025906"
      Environment             = "Prod"
      Name                    = "Call Out Procedures"
    }
  }
}

private_endpoint_imports = {
  blob                    = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-blob-cops-prod-canadacentral-001"
  api                     = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-api-cops-prod-canadacentral-001"
  sql                     = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-sql-cops-prod-canadacentral-001"
  app                     = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-app-cops-prod-canadacentral-001"
  file                    = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-file-cops-prod-canadacentral-001"
  redis                   = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-redis-cops-prod-canadacentral-001"
  kv                      = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-kv-cops-prod-canadacentral-001"
  network_watcher_storage = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/NetworkWatcherRG/providers/Microsoft.Network/privateEndpoints/pep-stnwcopsprdcac001xdf"
  wrk                     = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pe-wrk-cops-prod-canadacentral-001"
  sb                      = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pe-sb-cops-nonprod-canadacentral-001"
}

redis_cache = {
  app = {
    name                               = "redis-cops-prod-canadacentral-001"
    resource_group_key                 = "app"
    location                           = "canadacentral"
    sku_name                           = "Standard"
    family                             = "C"
    capacity                           = 1
    redis_version                      = "6"
    minimum_tls_version                = "1.2"
    non_ssl_port_enabled               = false
    public_network_access_enabled      = false
    access_keys_authentication_enabled = true
    redis_configuration = {
      active_directory_authentication_enabled = true
      maxmemory_policy                        = "noeviction"
      maxmemory_reserved                      = 125
      maxmemory_delta                         = 125
      maxfragmentationmemory_reserved         = 125
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Call Out Procedures"
    }
  }
}

redis_cache_imports = {
  app = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Cache/redis/redis-cops-prod-canadacentral-001"
}

# Queues, topics and authorization rules stay unmanaged. Zone redundancy is
# automatic for Premium and not set here.
service_bus_namespace = {
  app = {
    name                          = "sb-cops-prod-canadacentral-001"
    resource_group_key            = "app"
    location                      = "canadacentral"
    sku                           = "Premium"
    capacity                      = 1
    premium_messaging_partitions  = 1
    local_auth_enabled            = true
    minimum_tls_version           = "1.2"
    public_network_access_enabled = false
    identity_type                 = null
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "80025906"
      Environment             = "Prod"
      Name                    = "Call Out Procedures"
    }
  }
}

service_bus_namespace_imports = {
  app = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.ServiceBus/namespaces/sb-cops-prod-canadacentral-001"
}

# SQL logins are enabled alongside Entra ID; the admin password is not managed.
# The COPS40_PRODUCTION database and the elastic job agent stay unmanaged.
sql_server = {
  app = {
    name                                     = "sql-cops-prod-canadacentral-001"
    resource_group_key                       = "app"
    location                                 = "canadacentral"
    server_version                           = "12.0"
    administrator_login                      = "CloudSA4a427fcb"
    public_network_access_enabled            = false
    outbound_network_restriction_enabled     = false
    express_vulnerability_assessment_enabled = true # not in the export; as on the nonprod server
    primary_user_assigned_identity_id        = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-mid-cops-app-prod-canadacentral-001/providers/Microsoft.ManagedIdentity/userAssignedIdentities/mid-app-cops-prod-canadacentral-001"
    user_assigned_identity_ids = [
      "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-mid-cops-app-prod-canadacentral-001/providers/Microsoft.ManagedIdentity/userAssignedIdentities/mid-app-cops-prod-canadacentral-001"
    ]
    azuread_administrator = {
      azuread_authentication_only = false
      login_username              = "AAD Azure-Fujitsu-AMS-DBA"
      object_id                   = "3c563ed4-04ee-4a74-a34c-4bbb677e7a70"
      tenant_id                   = "8fbb85e8-0cbc-48c3-a2e9-528cef30ec27"
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Call Out Procedures"
    }
  }
}

sql_server_imports = {
  app = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Sql/servers/sql-cops-prod-canadacentral-001"
}

# app_files is a provisioned v1 premium file account (Premium_ZRS) serving the
# NFS share mounted by app-cops-prod-canadacentral-002; HTTPS-only is off
# because NFS requires it. Blob service properties were not exported, so
# blob_properties is unset.
storage_account = {
  app = {
    name                              = "stcopsprodcac001"
    resource_group_key                = "app"
    location                          = "canadacentral"
    account_kind                      = "StorageV2"
    account_tier                      = "Premium"
    account_replication_type          = "ZRS"
    access_tier                       = "Hot"
    provisioned_billing_model_version = null
    allow_nested_items_to_be_public   = false
    cross_tenant_replication_enabled  = false
    default_to_oauth_authentication   = false
    https_traffic_only_enabled        = true
    infrastructure_encryption_enabled = false
    is_hns_enabled                    = false
    min_tls_version                   = "TLS1_2"
    public_network_access_enabled     = false
    sftp_enabled                      = false
    shared_access_key_enabled         = true
    network_rules = {
      bypass                     = ["AzureServices"]
      default_action             = "Deny"
      ip_rules                   = []
      virtual_network_subnet_ids = []
      private_link_access = [
        {
          endpoint_resource_id = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/providers/Microsoft.Security/datascanners/StorageDataScanner"
          endpoint_tenant_id   = "8fbb85e8-0cbc-48c3-a2e9-528cef30ec27"
        }
      ]
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Call Out Procedures"
    }
  }
  app_files = {
    name                              = "stfilescopsprodcac01"
    resource_group_key                = "app"
    location                          = "canadacentral"
    account_kind                      = "FileStorage"
    account_tier                      = "Premium"
    account_replication_type          = "ZRS"
    access_tier                       = null
    provisioned_billing_model_version = null
    allow_nested_items_to_be_public   = false
    cross_tenant_replication_enabled  = false
    default_to_oauth_authentication   = false
    https_traffic_only_enabled        = false
    infrastructure_encryption_enabled = false
    is_hns_enabled                    = false
    large_file_share_enabled          = true
    min_tls_version                   = "TLS1_2"
    public_network_access_enabled     = false
    sftp_enabled                      = false
    shared_access_key_enabled         = true
    network_rules = {
      bypass                     = ["AzureServices"]
      default_action             = "Deny"
      ip_rules                   = []
      virtual_network_subnet_ids = []
      private_link_access        = []
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Call Out Procedures"
    }
  }
  network_watcher = {
    name                              = "stnwcopsprdcac001xdf"
    resource_group_key                = "network_watcher"
    location                          = "canadacentral"
    account_kind                      = "StorageV2"
    account_tier                      = "Standard"
    account_replication_type          = "LRS"
    access_tier                       = "Hot"
    provisioned_billing_model_version = null
    allow_nested_items_to_be_public   = false
    cross_tenant_replication_enabled  = false
    default_to_oauth_authentication   = true
    https_traffic_only_enabled        = true
    infrastructure_encryption_enabled = false
    is_hns_enabled                    = false
    min_tls_version                   = "TLS1_2"
    public_network_access_enabled     = false
    sftp_enabled                      = false
    shared_access_key_enabled         = false
    network_rules = {
      bypass                     = ["AzureServices"]
      default_action             = "Deny"
      ip_rules                   = []
      virtual_network_subnet_ids = []
      private_link_access = [
        {
          endpoint_resource_id = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/providers/Microsoft.Security/datascanners/StorageDataScanner"
          endpoint_tenant_id   = "8fbb85e8-0cbc-48c3-a2e9-528cef30ec27"
        }
      ]
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Call Out Procedures"
    }
  }
}

# Public network access is enabled on these, and Deny_Public_Access_On_PaaS_Services_v0
# denies any write to them, so they are read, not adopted, until exempted.
storage_account_existing = {
  app_002 = {
    name               = "stcopsprodcac002"
    resource_group_key = "app"
  }
}

storage_account_imports = {
  app             = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Storage/storageAccounts/stcopsprodcac001"
  app_files       = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Storage/storageAccounts/stfilescopsprodcac01"
  network_watcher = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/NetworkWatcherRG/providers/Microsoft.Storage/storageAccounts/stnwcopsprdcac001xdf"
}

user_assigned_identity = {
  app = {
    name               = "mid-app-cops-prod-canadacentral-001"
    resource_group_key = "mid_app"
    location           = "canadacentral"
    isolation_scope    = null
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Call Out Procedures"
    }
  }
  api = {
    name               = "mid-api-cops-prod-canadacentral-001"
    resource_group_key = "mid_app"
    location           = "canadacentral"
    isolation_scope    = null
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Call Out Procedures"
    }
  }
}

user_assigned_identity_imports = {
  app = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-mid-cops-app-prod-canadacentral-001/providers/Microsoft.ManagedIdentity/userAssignedIdentities/mid-app-cops-prod-canadacentral-001"
  api = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-mid-cops-app-prod-canadacentral-001/providers/Microsoft.ManagedIdentity/userAssignedIdentities/mid-api-cops-prod-canadacentral-001"
}

# Off for now, as in nonprod: the VNet module's body omits subnets and peerings,
# and the only peering is the vWAN hub connection owned by
# tf-deploy-platform-connectivity. defaultOutboundAccess is not reported, so
# Azure's default (enabled) is assumed; it is create-time only.
# vnet-cops-prod-canadacentral-001 peerings (unmanaged): RemoteVnetToHubPeering_a8db0ae7-e4bd-4112-a74f-86be5b004e19
virtual_network = {
  app = {
    name               = "vnet-cops-prod-canadacentral-001"
    resource_group_key = "app"
    location           = "canadacentral"
    address_space      = ["10.195.48.0/22"]
    dns_servers = {
      dns_servers = ["10.195.1.4"]
    }
    ddos_protection_plan = {
      enable = true
      id     = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/ddosProtectionPlans/ddos-protection-plan"
    }
    subnets = {
      app = {
        name                                          = "snet-app-cops-prod-canadacentral-001"
        address_prefixes                              = ["10.195.48.0/26"]
        default_outbound_access_enabled               = true
        private_endpoint_network_policies             = "Disabled"
        private_link_service_network_policies_enabled = true
        network_security_group = {
          id = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-app-cops-prod-canadacentral-001"
        }
        service_endpoint_policies       = {}
        service_endpoints_with_location = []
        delegations = [
          {
            name = "serverFarmDelegation"
            service_delegation = {
              name    = "Microsoft.Web/serverFarms"
              actions = ["Microsoft.Network/virtualNetworks/subnets/action"]
            }
          }
        ]
      }
      sql = {
        name                                          = "snet-sql-cops-prod-canadacentral-001"
        address_prefixes                              = ["10.195.49.0/26"]
        default_outbound_access_enabled               = true
        private_endpoint_network_policies             = "Disabled"
        private_link_service_network_policies_enabled = true
        network_security_group = {
          id = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-sql-cops-prod-canadacentral-001"
        }
        service_endpoint_policies       = {}
        service_endpoints_with_location = []
        delegations                     = []
      }
      pep = {
        name                                          = "snet-pep-cops-prod-canadacentral-001"
        address_prefixes                              = ["10.195.50.0/24"]
        default_outbound_access_enabled               = true
        private_endpoint_network_policies             = "RouteTableEnabled"
        private_link_service_network_policies_enabled = true
        network_security_group = {
          id = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-pep-cops-prod-canadacentral-001"
        }
        service_endpoint_policies       = {}
        service_endpoints_with_location = []
        delegations                     = []
      }
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Call Out Procedures"
    }
  }
}

virtual_network_imports = {
  app = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-prod-canadacentral-001"
}

virtual_network_subnet_imports = {
  app_app = {
    vnet_key   = "app"
    subnet_key = "app"
    id         = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-prod-canadacentral-001/subnets/snet-app-cops-prod-canadacentral-001"
  }
  app_sql = {
    vnet_key   = "app"
    subnet_key = "sql"
    id         = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-prod-canadacentral-001/subnets/snet-sql-cops-prod-canadacentral-001"
  }
  app_pep = {
    vnet_key   = "app"
    subnet_key = "pep"
    id         = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-prod-canadacentral-001/subnets/snet-pep-cops-prod-canadacentral-001"
  }
}

# Not filled in. The export masks app setting values and the module rewrites every
# setting on apply, so api-cops-prod-canadacentral-002 and
# wrk-cops-prod-canadacentral-001 need their settings (as Key Vault references)
# before this tier is staged. app-cops-prod-canadacentral-002 is not modelled: its
# NFS storage mount cannot be written by the module.
web_app = {}

web_app_imports = {}

# =====================================================================
# Hub private DNS: links and records in the shared zones (connectivity subscription)
# =====================================================================

enable_hub_private_dns = true

hub_private_dns_zone_link = {
  "default" = {
    name               = "default"
    zone_name          = "privatelink.servicebus.windows.net"
    virtual_network_id = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-prod-canadacentral-001"
    resolution_policy  = "NxDomainRedirect"
  }
  "internal.bchydro.bc.ca/link-sites-cops-prod-canadacentral-001" = {
    name               = "link-sites-cops-prod-canadacentral-001"
    zone_name          = "internal.bchydro.bc.ca"
    virtual_network_id = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-prod-canadacentral-001"
  }
  "link-blob-cops-prod-canadacentral-001" = {
    name               = "link-blob-cops-prod-canadacentral-001"
    zone_name          = "privatelink.blob.core.windows.net"
    virtual_network_id = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-prod-canadacentral-001"
  }
  "link-cache-cops-prod-canadacentral-001" = {
    name               = "link-cache-cops-prod-canadacentral-001"
    zone_name          = "privatelink.redis.cache.windows.net"
    virtual_network_id = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-prod-canadacentral-001"
  }
  "link-file-cops-prod-canadacentral-001" = {
    name               = "link-file-cops-prod-canadacentral-001"
    zone_name          = "privatelink.file.core.windows.net"
    virtual_network_id = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-prod-canadacentral-001"
  }
  "link-sql-cops-prod-canadacentral-001" = {
    name               = "link-sql-cops-prod-canadacentral-001"
    zone_name          = "privatelink.database.windows.net"
    virtual_network_id = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-prod-canadacentral-001"
  }
  "link-vault-cops-prod-canadacentral-001" = {
    name               = "link-vault-cops-prod-canadacentral-001"
    zone_name          = "privatelink.vaultcore.azure.net"
    virtual_network_id = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-prod-canadacentral-001"
  }
  "privatelink.agentsvc.azure-automation.net/link-cops-prod-canadacentral" = {
    name               = "link-cops-prod-canadacentral"
    zone_name          = "privatelink.agentsvc.azure-automation.net"
    virtual_network_id = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-prod-canadacentral-001"
  }
  "privatelink.azurewebsites.net/link-sites-cops-prod-canadacentral-001" = {
    name               = "link-sites-cops-prod-canadacentral-001"
    zone_name          = "privatelink.azurewebsites.net"
    virtual_network_id = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-prod-canadacentral-001"
  }
  "privatelink.monitor.azure.com/link-cops-prod-canadacentral" = {
    name               = "link-cops-prod-canadacentral"
    zone_name          = "privatelink.monitor.azure.com"
    virtual_network_id = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-prod-canadacentral-001"
  }
  "privatelink.ods.opinsights.azure.com/link-cops-prod-canadacentral" = {
    name               = "link-cops-prod-canadacentral"
    zone_name          = "privatelink.ods.opinsights.azure.com"
    virtual_network_id = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-prod-canadacentral-001"
  }
  "privatelink.oms.opinsights.azure.com/link-cops-prod-canadacentral" = {
    name               = "link-cops-prod-canadacentral"
    zone_name          = "privatelink.oms.opinsights.azure.com"
    virtual_network_id = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-prod-canadacentral-001"
  }
}

hub_private_dns_zone_link_imports = {
  "default"                                                                = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.servicebus.windows.net/virtualNetworkLinks/default"
  "internal.bchydro.bc.ca/link-sites-cops-prod-canadacentral-001"          = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/internal.bchydro.bc.ca/virtualNetworkLinks/link-sites-cops-prod-canadacentral-001"
  "link-blob-cops-prod-canadacentral-001"                                  = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net/virtualNetworkLinks/link-blob-cops-prod-canadacentral-001"
  "link-cache-cops-prod-canadacentral-001"                                 = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.redis.cache.windows.net/virtualNetworkLinks/link-cache-cops-prod-canadacentral-001"
  "link-file-cops-prod-canadacentral-001"                                  = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.file.core.windows.net/virtualNetworkLinks/link-file-cops-prod-canadacentral-001"
  "link-sql-cops-prod-canadacentral-001"                                   = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.database.windows.net/virtualNetworkLinks/link-sql-cops-prod-canadacentral-001"
  "link-vault-cops-prod-canadacentral-001"                                 = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.vaultcore.azure.net/virtualNetworkLinks/link-vault-cops-prod-canadacentral-001"
  "privatelink.agentsvc.azure-automation.net/link-cops-prod-canadacentral" = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.agentsvc.azure-automation.net/virtualNetworkLinks/link-cops-prod-canadacentral"
  "privatelink.azurewebsites.net/link-sites-cops-prod-canadacentral-001"   = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.azurewebsites.net/virtualNetworkLinks/link-sites-cops-prod-canadacentral-001"
  "privatelink.monitor.azure.com/link-cops-prod-canadacentral"             = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.monitor.azure.com/virtualNetworkLinks/link-cops-prod-canadacentral"
  "privatelink.ods.opinsights.azure.com/link-cops-prod-canadacentral"      = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.ods.opinsights.azure.com/virtualNetworkLinks/link-cops-prod-canadacentral"
  "privatelink.oms.opinsights.azure.com/link-cops-prod-canadacentral"      = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.oms.opinsights.azure.com/virtualNetworkLinks/link-cops-prod-canadacentral"
}

hub_private_dns_a_record = {
  "cops" = {
    name      = "cops"
    zone_name = "internal.bchydro.bc.ca"
    ttl       = 10
    records   = ["10.195.50.8"]
  }
}

hub_private_dns_a_record_imports = {
  "cops" = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/internal.bchydro.bc.ca/A/cops"
}
