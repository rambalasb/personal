# Sub-Cops-NonProd (675a173c-0b66-4506-9aec-c0b2681e0fb9)
# Values come from the Azure resource export of 2026-10-20.
# The web apps and the VNet are off for the first apply; see "Staged adoption"
# in the README.

subscription_id = "675a173c-0b66-4506-9aec-c0b2681e0fb9"

enable_resource_group          = true
enable_monitoring              = true
enable_app_service_plan        = true ###
enable_application_insights    = true
enable_disk_access             = true
enable_event_grid_system_topic = true
enable_key_vault               = true
enable_log_analytics_workspace = true ###
enable_managed_disk            = true
enable_network_security_group  = true
enable_network_watcher         = true
enable_private_dns_zone        = true ###
enable_private_endpoint        = true
enable_redis_cache             = true
enable_service_bus_namespace   = true
enable_sql_server              = true
enable_storage_account         = true
enable_user_assigned_identity  = true
enable_virtual_network         = false
enable_web_app                 = false

enable_resource_group_role_assignment          = false
enable_monitoring_role_assignment              = false
enable_app_service_plan_role_assignment        = false
enable_application_insights_role_assignment    = false
enable_disk_access_role_assignment             = false
enable_event_grid_system_topic_role_assignment = false
enable_key_vault_role_assignment               = false
enable_log_analytics_workspace_role_assignment = false
enable_managed_disk_role_assignment            = false
enable_network_security_group_role_assignment  = false
enable_network_watcher_role_assignment         = false
enable_private_dns_zone_role_assignment        = false
enable_private_endpoint_role_assignment        = false
enable_redis_cache_role_assignment             = false
enable_service_bus_namespace_role_assignment   = false
enable_sql_server_role_assignment              = false
enable_storage_account_role_assignment         = false
enable_user_assigned_identity_role_assignment  = false
enable_virtual_network_role_assignment         = false
enable_web_app_role_assignment                 = false

role_assignments = {}

resource_group = {
  alerts = {
    name     = "rg-alerts-cops-nonprod-canadacentral-001"
    location = "canadacentral"
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Call Out Procedures"
    }
  }
  app = {
    name     = "rg-cops-app-nonprod-canadacentral-001"
    location = "canadacentral"
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Call Out Procedures"
    }
  }
  mid_app = {
    name     = "rg-mid-cops-app-nonprod-canadacentral-001"
    location = "canadacentral"
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Call Out Procedures"
    }
  }
  shared_app = {
    name     = "rg-shared-cops-app-nonprod-canadacentral-001"
    location = "canadacentral"
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Call Out Procedures"
    }
  }
  network_watcher = {
    name     = "NetworkWatcherRG"
    location = "canadacentral"
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Call Out Procedures"
    }
  }
  defaultresourcegroup_ccan = {
    name     = "DefaultResourceGroup-CCAN"
    location = "canadacentral"
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Call Out Procedures"
    }
  }
}

import_resource_group = {
  alerts                    = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-alerts-cops-nonprod-canadacentral-001"
  app                       = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001"
  mid_app                   = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-mid-cops-app-nonprod-canadacentral-001"
  shared_app                = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-shared-cops-app-nonprod-canadacentral-001"
  network_watcher           = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/NetworkWatcherRG"
  defaultresourcegroup_ccan = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/DefaultResourceGroup-CCAN"
}

# Some action group IDs contain a leading space in the group name; kept as exported.
alert = {
  resource_group_key         = "alerts"
  root_management_group_name = null
  tags                       = {}
  activity_log_alerts = {
    app_cops_nonprod_create_update_error = {
      name                = "app-cops-nonprod-create-update-error"
      resource_group_name = "rg-alerts-cops-nonprod-canadacentral-001"
      scopes              = ["/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9"]
      location            = "global"
      description         = ""
      enabled             = true
      criteria = {
        category       = "Administrative"
        operation_name = "Microsoft.Web/serverfarms/Write"
      }
      action_group_keys = []
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-monitor-mail-alerts-canadacentral-001"
      ]
      webhook_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Call Out Procedures"
      }
    }
    app_cops_nonprod_restart = {
      name                = "app-cops-nonprod-restart"
      resource_group_name = "rg-alerts-cops-nonprod-canadacentral-001"
      scopes              = ["/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9"]
      location            = "global"
      description         = ""
      enabled             = true
      criteria = {
        category       = "Administrative"
        operation_name = "Microsoft.Web/sites/restart/Action"
      }
      action_group_keys = []
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-monitor-mail-alerts-canadacentral-001"
      ]
      webhook_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Call Out Procedures"
      }
    }
    app_cops_nonprod_stop = {
      name                = "app-cops-nonprod-stop"
      resource_group_name = "rg-alerts-cops-nonprod-canadacentral-001"
      scopes              = ["/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9"]
      location            = "global"
      description         = ""
      enabled             = true
      criteria = {
        category       = "Administrative"
        operation_name = "Microsoft.Web/sites/stop/Action"
      }
      action_group_keys = []
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-monitor-mail-alerts-canadacentral-001"
      ]
      webhook_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        BusinessUnit            = "Customer & Corporate Affairs"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Call Out Procedures"
      }
    }
    keyvault_deletion_alert_canadacentral = {
      name                = "KeyVault-Deletion-Alert-canadacentral"
      resource_group_name = "rg-alerts-cops-nonprod-canadacentral-001"
      scopes              = ["/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9"]
      location            = "global"
      description         = "This alert will monitor any deletion of key vault"
      enabled             = true
      criteria = {
        category       = "Administrative"
        operation_name = "Microsoft.KeyVault/vaults/delete"
      }
      action_group_keys = []
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      webhook_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Call Out Procedures"
      }
    }
    service_outage_alert_canadacentral = {
      name                = "Service-Outage-Alert-canadacentral"
      resource_group_name = "rg-alerts-cops-nonprod-canadacentral-001"
      scopes              = ["/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9"]
      location            = "global"
      description         = "Azure Landing Zone Service Health Alert"
      enabled             = true
      criteria = {
        category = "ServiceHealth"
        service_health = {
          locations = ["Global"]
        }
      }
      action_group_keys = []
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-cops-mail-alerts-canadacentral-001"
      ]
      webhook_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Call Out Procedures"
      }
    }
  }
  metric_alerts = {
    app_cops_nonprod_http_404_informational = {
      name                = "app-cops-nonprod-http-404-informational"
      resource_group_name = "rg-alerts-cops-nonprod-canadacentral-001"
      scopes = [
        "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Web/sites/app-cops-nonprod-canadacentral-001"
      ]
      description              = "This alert is for Sub-Fit-Prod App's HTTP errors"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 3
      target_resource_type     = "Microsoft.Web/sites"
      target_resource_location = "canadacentral"
      dynamic_criteria = {
        metric_namespace         = "Microsoft.Web/sites"
        metric_name              = "Http4xx"
        aggregation              = "Total"
        operator                 = "GreaterOrLessThan"
        alert_sensitivity        = "Medium"
        evaluation_total_count   = 4
        evaluation_failure_count = 4
        ignore_data_before       = null
        skip_metric_validation   = false
        dimensions               = []
      }
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-cops-mail-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Call Out Procedures"
      }
    }
    app_health_alert_canadacentral = {
      name                = "App-Health-Alert-canadacentral"
      resource_group_name = "rg-cops-app-nonprod-canadacentral-001"
      scopes = [
        "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Web/sites/app-cops-nonprod-canadacentral-001"
      ]
      description              = "This alert is for Sub-Cop-NonProd App's Health check alert"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 3
      target_resource_type     = "Microsoft.Web/sites"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "microsoft.web/sites"
          metric_name            = "HealthCheckStatus"
          aggregation            = "Average"
          operator               = "LessThan"
          threshold              = 100
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-cops-mail-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Call Out Procedures"
      }
    }
    app_high_cpu_alert_canadacentral = {
      name                = "App-High-CPU-Alert-canadacentral"
      resource_group_name = "NetworkWatcherRG"
      scopes = [
        "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Web/sites/app-cops-nonprod-canadacentral-001"
      ]
      description              = "This alert is fro Sub-Cops-NonProd App's High CPU usage"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 3
      target_resource_type     = "Microsoft.Web/sites"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Web/sites"
          metric_name            = "CpuTime"
          aggregation            = "Total"
          operator               = "GreaterThan"
          threshold              = 300
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/lga-servicenow-integration_group/providers/microsoft.insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Call Out Procedures"
      }
    }
    servicebus_activemessage_in_queue = {
      name                = "ServiceBus-ActiveMessage-in-Queue"
      resource_group_name = "rg-cops-app-nonprod-canadacentral-001"
      scopes = [
        "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.ServiceBus/namespaces/sb-cops-nonprod-canadacentral-001"
      ]
      description              = "ServiceBus-ActiveMessage-in-Queue"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 3
      target_resource_type     = "Microsoft.ServiceBus/namespaces"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.ServiceBus/namespaces"
          metric_name            = "ActiveMessages"
          aggregation            = "Average"
          operator               = "GreaterThan"
          threshold              = 50
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-monitor-mail-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Call Out Procedures"
      }
    }
    servicebus_deadletteredmessages_in_queue = {
      name                = "ServiceBus-DeadLetteredMessages-in-queue"
      resource_group_name = "rg-cops-app-nonprod-canadacentral-001"
      scopes = [
        "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.ServiceBus/namespaces/sb-cops-nonprod-canadacentral-001"
      ]
      description              = "ServiceBus-DeadLetteredMessages-in-queue"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 3
      target_resource_type     = "Microsoft.ServiceBus/namespaces"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.ServiceBus/namespaces"
          metric_name            = "DeadletteredMessages"
          aggregation            = "Average"
          operator               = "GreaterThan"
          threshold              = 0
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-monitor-mail-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Call Out Procedures"
      }
    }
    servicebus_throttledrequest = {
      name                = "ServiceBus-ThrottledRequest"
      resource_group_name = "rg-cops-app-nonprod-canadacentral-001"
      scopes = [
        "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.ServiceBus/namespaces/sb-cops-nonprod-canadacentral-001"
      ]
      description              = "ServiceBus-ThrottledRequest"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 3
      target_resource_type     = "Microsoft.ServiceBus/namespaces"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.ServiceBus/namespaces"
          metric_name            = "ThrottledRequests"
          aggregation            = "Total"
          operator               = "GreaterThan"
          threshold              = 0
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-monitor-mail-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Call Out Procedures"
      }
    }
    sql_db_cpu_alert_canadacentral = {
      name                = "SQL-DB-CPU-Alert-canadacentral"
      resource_group_name = "rg-cops-app-nonprod-canadacentral-001"
      scopes = [
        "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Sql/servers/sql-cops-nonprod-canadacentral-001/databases/COPS40_STAGING"
      ]
      description              = "This alert is for high CPU utilization of Sub-Cop-non Prod DB's"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT15M"
      severity                 = 3
      target_resource_type     = "Microsoft.Sql/servers/databases"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Sql/servers/databases"
          metric_name            = "cpu_percent"
          aggregation            = "Average"
          operator               = "GreaterThan"
          threshold              = 85
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001",
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-db-mail-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Call Out Procedures"
      }
    }
    sql_db_data_io_usage_alert_canadacentral = {
      name                = "SQL-DB-Data-IO-usage-Alert-canadacentral"
      resource_group_name = "rg-cops-app-nonprod-canadacentral-001"
      scopes = [
        "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Sql/servers/sql-cops-nonprod-canadacentral-001/databases/COPS40_STAGING"
      ]
      description              = ""
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT15M"
      severity                 = 2
      target_resource_type     = "Microsoft.Sql/servers/databases"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Sql/servers/databases"
          metric_name            = "physical_data_read_percent"
          aggregation            = "Average"
          operator               = "GreaterThan"
          threshold              = 85
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001",
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-db-mail-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Call Out Procedures"
      }
    }
    sql_db_deadlock_cops_nonprod_canadcentral = {
      name                = "SQL-DB-Deadlock-Cops-NonProd-canadcentral"
      resource_group_name = "NetworkWatcherRG"
      scopes = [
        "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Sql/servers/sql-cops-nonprod-canadacentral-001/databases/COPS40_STAGING"
      ]
      description              = ""
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT1H"
      severity                 = 1
      target_resource_type     = "Microsoft.Sql/servers/databases"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Sql/servers/databases"
          metric_name            = "deadlock"
          aggregation            = "Total"
          operator               = "GreaterThan"
          threshold              = 5
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001",
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-db-mail-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Call Out Procedures"
      }
    }
    sql_db_log_io_usage_alert_canadacentral = {
      name                = "SQL-DB-Log-IO-usage-Alert-canadacentral"
      resource_group_name = "rg-cops-app-nonprod-canadacentral-001"
      scopes = [
        "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Sql/servers/sql-cops-nonprod-canadacentral-001/databases/COPS40_STAGING"
      ]
      description              = ""
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT15M"
      severity                 = 2
      target_resource_type     = "Microsoft.Sql/servers/databases"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Sql/servers/databases"
          metric_name            = "log_write_percent"
          aggregation            = "Average"
          operator               = "GreaterThan"
          threshold              = 85
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001",
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-db-mail-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Call Out Procedures"
      }
    }
    sql_db_memory_alert_canadacentral = {
      name                = "SQL-DB-Memory-Alert-canadacentral"
      resource_group_name = "rg-cops-app-nonprod-canadacentral-001"
      scopes = [
        "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Sql/servers/sql-cops-nonprod-canadacentral-001/databases/COPS40_STAGING"
      ]
      description              = "This alert is for high memory utilization of Sub-Cop-Prod DB's"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 3
      target_resource_type     = "Microsoft.Sql/servers/databases"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Sql/servers/databases"
          metric_name            = "sql_instance_memory_percent"
          aggregation            = "Maximum"
          operator               = "GreaterThan"
          threshold              = 90
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001",
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-db-mail-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Call Out Procedures"
      }
    }
    sql_db_stoarge_space_size_alert_canadacentral = {
      name                = "SQL-DB-stoarge-space-size-alert-canadacentral"
      resource_group_name = "rg-cops-app-nonprod-canadacentral-001"
      scopes = [
        "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Sql/servers/sql-cops-nonprod-canadacentral-001/databases/COPS40_STAGING"
      ]
      description              = ""
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT15M"
      severity                 = 2
      target_resource_type     = "Microsoft.Sql/servers/databases"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Sql/servers/databases"
          metric_name            = "storage_percent"
          aggregation            = "Maximum"
          operator               = "GreaterThan"
          threshold              = 85
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001",
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-db-mail-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Call Out Procedures"
      }
    }
    sql_tempdb_data_file_size_alert_canadacentral = {
      name                = "SQL-Tempdb-data-file-size-alert-canadacentral"
      resource_group_name = "rg-cops-app-nonprod-canadacentral-001"
      scopes = [
        "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Sql/servers/sql-cops-nonprod-canadacentral-001/databases/COPS40_STAGING"
      ]
      description              = ""
      enabled                  = false
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT15M"
      severity                 = 2
      target_resource_type     = "Microsoft.Sql/servers/databases"
      target_resource_location = "canadacentral"
      dynamic_criteria = {
        metric_namespace         = "Microsoft.Sql/servers/databases"
        metric_name              = "tempdb_data_size"
        aggregation              = "Average"
        operator                 = "GreaterOrLessThan"
        alert_sensitivity        = "Low"
        evaluation_total_count   = 4
        evaluation_failure_count = 4
        ignore_data_before       = null
        skip_metric_validation   = false
        dimensions               = []
      }
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actionGroups/ag-DB-mail-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Call Out Procedures"
      }
    }
    sql_tempdb_log_file_size_alert_canadacentral = {
      name                = "SQL-Tempdb-log-file-size-alert-canadacentral"
      resource_group_name = "NetworkWatcherRG"
      scopes = [
        "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Sql/servers/sql-cops-nonprod-canadacentral-001/databases/COPS40_STAGING"
      ]
      description              = ""
      enabled                  = false
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT15M"
      severity                 = 2
      target_resource_type     = "Microsoft.Sql/servers/databases"
      target_resource_location = "canadacentral"
      dynamic_criteria = {
        metric_namespace         = "Microsoft.Sql/servers/databases"
        metric_name              = "tempdb_log_size"
        aggregation              = "Average"
        operator                 = "GreaterOrLessThan"
        alert_sensitivity        = "Low"
        evaluation_total_count   = 4
        evaluation_failure_count = 4
        ignore_data_before       = null
        skip_metric_validation   = false
        dimensions               = []
      }
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/lga-servicenow-integration_group/providers/microsoft.insights/actionGroups/ ag-servicenow-alerts-canadacentral-001",
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actionGroups/ag-DB-mail-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Call Out Procedures"
      }
    }
    sql_tempdb_usage_alert_canadacentral = {
      name                = "SQL-Tempdb-usage-alert-canadacentral"
      resource_group_name = "NetworkWatcherRG"
      scopes = [
        "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Sql/servers/sql-cops-nonprod-canadacentral-001/databases/COPS40_STAGING"
      ]
      description              = ""
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT15M"
      severity                 = 2
      target_resource_type     = "Microsoft.Sql/servers/databases"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Sql/servers/databases"
          metric_name            = "tempdb_log_used_percent"
          aggregation            = "Maximum"
          operator               = "GreaterThan"
          threshold              = 85
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/lga-servicenow-integration_group/providers/microsoft.insights/actionGroups/ ag-servicenow-alerts-canadacentral-001",
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actionGroups/ag-DB-mail-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Call Out Procedures"
      }
    }
  }
  log_search_alerts = {
    keyvault_secret_expired_alert_canadacentral = {
      name                              = "KeyVault-Secret-Expired-Alert-canadacentral"
      resource_group_name               = "rg-alerts-cops-nonprod-canadacentral-001"
      location                          = "canadacentral"
      scopes                            = ["/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9"]
      severity                          = 0
      evaluation_frequency              = "PT5M"
      window_duration                   = "PT30M"
      description                       = "Alert for expired secret in a Key Vault."
      display_name                      = "KeyVault-Secret-Expired-Alert-canadacentral"
      enabled                           = true
      auto_mitigation_enabled           = false
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = null
      target_resource_types             = null
      criteria = [
        {
          query                   = "        AzureDiagnostics\n        | where ResourceProvider == \"MICROSOFT.KEYVAULT\"\n        | where OperationName contains \"SecretExpired\"\n        "
          time_aggregation_method = "Count"
          threshold               = 1
          operator                = "GreaterThanOrEqual"
          resource_id_column      = "ResourceId"
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Call Out Procedures"
      }
    }
    keyvault_secret_near_expiry_alert_canadacentral = {
      name                              = "KeyVault-Secret-Near-Expiry-Alert-canadacentral"
      resource_group_name               = "rg-alerts-cops-nonprod-canadacentral-001"
      location                          = "canadacentral"
      scopes                            = ["/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9"]
      severity                          = 1
      evaluation_frequency              = "PT5M"
      window_duration                   = "PT30M"
      description                       = "Alert for secret in a Key Vault is about to expire."
      display_name                      = "KeyVault-Secret-Near-Expiry-Alert-canadacentral"
      enabled                           = true
      auto_mitigation_enabled           = false
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = null
      target_resource_types             = null
      criteria = [
        {
          query                   = "        AzureDiagnostics\n        | where ResourceProvider == \"MICROSOFT.KEYVAULT\"\n        | where OperationName contains \"SecretNearExpiry\"\n        "
          time_aggregation_method = "Count"
          threshold               = 1
          operator                = "GreaterThanOrEqual"
          resource_id_column      = "ResourceId"
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Call Out Procedures"
      }
    }
    resource_creation_alert_canadacentral = {
      name                              = "Resource-Creation-Alert-canadacentral"
      resource_group_name               = "rg-alerts-cops-nonprod-canadacentral-001"
      location                          = "canadacentral"
      scopes                            = ["/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9"]
      severity                          = 4
      evaluation_frequency              = "PT10M"
      window_duration                   = "PT30M"
      description                       = "Alert when a new resource is created."
      display_name                      = "Resource-Creation-Alert-canadacentral"
      enabled                           = true
      auto_mitigation_enabled           = false
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = null
      target_resource_types             = null
      criteria = [
        {
          query                   = "        AzureActivity\n        | where OperationNameValue has \"Microsoft.Resources/deployments/write\"\n        | where CategoryValue == \"Administrative\"\n        | where ActivityStatusValue == \"Success\"\n        "
          time_aggregation_method = "Count"
          threshold               = 10
          operator                = "GreaterThanOrEqual"
          resource_id_column      = "_ResourceId"
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Call Out Procedures"
      }
    }
    storage_account_container_deletion_alert_canadacentral = {
      name                              = "Storage-Account-Container-Deletion-Alert-canadacentral"
      resource_group_name               = "rg-alerts-cops-nonprod-canadacentral-001"
      location                          = "canadacentral"
      scopes                            = ["/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9"]
      severity                          = 0
      evaluation_frequency              = "PT5M"
      window_duration                   = "PT30M"
      description                       = "Alert for the deletion of Storage Account Container."
      display_name                      = "Storage-Account-Container-Deletion-Alert-canadacentral"
      enabled                           = true
      auto_mitigation_enabled           = false
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = null
      target_resource_types             = null
      criteria = [
        {
          query                   = "        AzureActivity\n        | where ResourceProviderValue == \"MICROSOFT.STORAGE\" and OperationNameValue == \"MICROSOFT.STORAGE/STORAGEACCOUNTS/BLOBSERVICES/CONTAINERS/DELETE\"\n        "
          time_aggregation_method = "Count"
          threshold               = 1
          operator                = "GreaterThanOrEqual"
          resource_id_column      = "_ResourceId"
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Call Out Procedures"
      }
    }
    storage_account_deletion_alert_canadacentral = {
      name                              = "Storage-Account-Deletion-Alert-canadacentral"
      resource_group_name               = "rg-alerts-cops-nonprod-canadacentral-001"
      location                          = "canadacentral"
      scopes                            = ["/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9"]
      severity                          = 0
      evaluation_frequency              = "PT5M"
      window_duration                   = "PT30M"
      description                       = "Alert for the deletion of Storage Account."
      display_name                      = "Storage-Account-Deletion-Alert-canadacentral"
      enabled                           = true
      auto_mitigation_enabled           = false
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = null
      target_resource_types             = null
      criteria = [
        {
          query                   = "        AzureActivity\n        | where ResourceProviderValue == \"MICROSOFT.STORAGE\" and OperationNameValue == \"MICROSOFT.STORAGE/STORAGEACCOUNTS/DELETE\"\n        "
          time_aggregation_method = "Count"
          threshold               = 1
          operator                = "GreaterThanOrEqual"
          resource_id_column      = "_ResourceId"
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001624"
        ApplicationServiceLevel = "Bronze"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Call Out Procedures"
      }
    }
  }
  alert_processing_rules = {}
}

activity_log_alert_imports = {
  app_cops_nonprod_create_update_error  = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-alerts-cops-nonprod-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/app-cops-nonprod-create-update-error"
  app_cops_nonprod_restart              = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-alerts-cops-nonprod-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/app-cops-nonprod-restart"
  app_cops_nonprod_stop                 = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-alerts-cops-nonprod-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/app-cops-nonprod-stop"
  keyvault_deletion_alert_canadacentral = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-alerts-cops-nonprod-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/KeyVault-Deletion-Alert-canadacentral"
  service_outage_alert_canadacentral    = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-alerts-cops-nonprod-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/Service-Outage-Alert-canadacentral"
}

metric_alert_imports = {
  app_cops_nonprod_http_404_informational       = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-alerts-cops-nonprod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/app-cops-nonprod-http-404-informational"
  app_health_alert_canadacentral                = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/App-Health-Alert-canadacentral"
  app_high_cpu_alert_canadacentral              = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/NetworkWatcherRG/providers/Microsoft.Insights/metricAlerts/App-High-CPU-Alert-canadacentral"
  servicebus_activemessage_in_queue             = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/ServiceBus-ActiveMessage-in-Queue"
  servicebus_deadletteredmessages_in_queue      = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/ServiceBus-DeadLetteredMessages-in-queue"
  servicebus_throttledrequest                   = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/ServiceBus-ThrottledRequest"
  sql_db_cpu_alert_canadacentral                = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/SQL-DB-CPU-Alert-canadacentral"
  sql_db_data_io_usage_alert_canadacentral      = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/SQL-DB-Data-IO-usage-Alert-canadacentral"
  sql_db_deadlock_cops_nonprod_canadcentral     = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/NetworkWatcherRG/providers/Microsoft.Insights/metricAlerts/SQL-DB-Deadlock-Cops-NonProd-canadcentral"
  sql_db_log_io_usage_alert_canadacentral       = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/SQL-DB-Log-IO-usage-Alert-canadacentral"
  sql_db_memory_alert_canadacentral             = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/SQL-DB-Memory-Alert-canadacentral"
  sql_db_stoarge_space_size_alert_canadacentral = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/SQL-DB-stoarge-space-size-alert-canadacentral"
  sql_tempdb_data_file_size_alert_canadacentral = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/SQL-Tempdb-data-file-size-alert-canadacentral"
  sql_tempdb_log_file_size_alert_canadacentral  = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/NetworkWatcherRG/providers/Microsoft.Insights/metricAlerts/SQL-Tempdb-log-file-size-alert-canadacentral"
  sql_tempdb_usage_alert_canadacentral          = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/NetworkWatcherRG/providers/Microsoft.Insights/metricAlerts/SQL-Tempdb-usage-alert-canadacentral"
}

log_search_alert_imports = {
  keyvault_secret_expired_alert_canadacentral            = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-alerts-cops-nonprod-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/KeyVault-Secret-Expired-Alert-canadacentral"
  keyvault_secret_near_expiry_alert_canadacentral        = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-alerts-cops-nonprod-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/KeyVault-Secret-Near-Expiry-Alert-canadacentral"
  resource_creation_alert_canadacentral                  = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-alerts-cops-nonprod-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/Resource-Creation-Alert-canadacentral"
  storage_account_container_deletion_alert_canadacentral = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-alerts-cops-nonprod-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/Storage-Account-Container-Deletion-Alert-canadacentral"
  storage_account_deletion_alert_canadacentral           = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-alerts-cops-nonprod-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/Storage-Account-Deletion-Alert-canadacentral"
}

# Not managed here:
#   activitylogalerts 'app-cops-nonprod-delete' (): criteria the wrapper cannot express
alert_processing_rule_imports = {}

# app_secondary (ASP-rgcopsapp...-ba5c) was created by the portal and hosts only app-cops.
app_service_plan = {
  app = {
    name                            = "asp-cops-nonprod-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    os_type                         = "Linux"
    sku_name                        = "P1v4"
    worker_count                    = 1
    maximum_elastic_worker_count    = 1
    per_site_scaling_enabled        = false
    premium_plan_auto_scale_enabled = false
    zone_balancing_enabled          = false
    app_service_environment_id      = null
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Call Out Procedures"
    }
  }
  app_secondary = {
    name                            = "ASP-rgcopsappnonprodcanadacentral00-ba5c"
    resource_group_key              = "app"
    location                        = "canadacentral"
    os_type                         = "Linux"
    sku_name                        = "P1v4"
    worker_count                    = 1
    maximum_elastic_worker_count    = 1
    per_site_scaling_enabled        = false
    premium_plan_auto_scale_enabled = false
    zone_balancing_enabled          = false
    app_service_environment_id      = null
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Call Out Procedures"
    }
  }
}

app_service_plan_imports = {
  app           = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Web/serverFarms/asp-cops-nonprod-canadacentral-001"
  app_secondary = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Web/serverFarms/ASP-rgcopsappnonprodcanadacentral00-ba5c"
}

# The daily cap is not in the export (100 is the provider default); confirm with
# az monitor app-insights component billing show.
application_insights = {
  func = {
    name                          = "ai-func-cops-nonprod-canadacentral-001"
    resource_group_key            = "app"
    location                      = "canadacentral"
    workspace_id                  = "/subscriptions/7d54d6f7-83d9-48cf-ac35-1068bcfd0561/resourceGroups/rg-siem-security-canadacentral-001/providers/Microsoft.OperationalInsights/workspaces/la-siem-security-canadacentral-001"
    application_type              = "web"
    retention_in_days             = 90
    daily_data_cap_in_gb          = 100
    sampling_percentage           = 0
    internet_ingestion_enabled    = true
    internet_query_enabled        = true
    local_authentication_disabled = false
    disable_ip_masking            = false
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Call Out Procedures"
    }
  }
}

application_insights_imports = {
  func = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Insights/components/ai-func-cops-nonprod-canadacentral-001"
}

disk_access = {
  app = {
    name               = "access-disk-cops-nonprod-canadacentral-001"
    resource_group_key = "app"
    location           = "canadacentral"
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Call Out Procedures"
    }
  }
}

disk_access_imports = {
  app = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Compute/diskAccesses/access-disk-cops-nonprod-canadacentral-001"
}

# Unattached data disk reachable only through the disk access private endpoint.
managed_disk = {
  app = {
    name                          = "disk-cops-nonprod-canadacentral-001"
    resource_group_key            = "app"
    location                      = "canadacentral"
    storage_account_type          = "Premium_ZRS"
    create_option                 = "Empty"
    disk_size_gb                  = 128
    zone                          = null
    network_access_policy         = "AllowPrivate"
    disk_access_id                = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Compute/diskAccesses/access-disk-cops-nonprod-canadacentral-001"
    public_network_access_enabled = false
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Call Out Procedures"
    }
  }
}

managed_disk_imports = {
  app = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Compute/disks/disk-cops-nonprod-canadacentral-001"
}

event_grid_system_topic = {
  app_storage = {
    name                        = "stcopsnonprodcac001-30aa5f98-d396-4bb5-a22e-6a9282aeae3d"
    resource_group_key          = "app"
    location                    = "canadacentral"
    topic_type                  = "microsoft.storage.storageaccounts"
    source_resource_id          = null
    exported_source_resource_id = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/microsoft.storage/storageaccounts/stcopsnonprodcac001"
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Call Out Procedures"
    }
  }
  network_watcher_storage = {
    name                        = "stnwcopsnonprodcac-f571ae7e-c0ea-41fb-b1ab-0a81c1cc098d"
    resource_group_key          = "shared_app"
    location                    = "canadacentral"
    topic_type                  = "microsoft.storage.storageaccounts"
    source_resource_id          = null
    exported_source_resource_id = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-shared-cops-app-nonprod-canadacentral-001/providers/microsoft.storage/storageaccounts/stnwcopsnonprodcac"
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Call Out Procedures"
    }
  }
}

event_grid_system_topic_imports = {
  app_storage             = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.EventGrid/systemTopics/stcopsnonprodcac001-30aa5f98-d396-4bb5-a22e-6a9282aeae3d"
  network_watcher_storage = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-shared-cops-app-nonprod-canadacentral-001/providers/Microsoft.EventGrid/systemTopics/stnwcopsnonprodcac-f571ae7e-c0ea-41fb-b1ab-0a81c1cc098d"
}

key_vault = {
  app = {
    name                            = "kvcopsnonprodcac001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    tenant_id                       = "8fbb85e8-0cbc-48c3-a2e9-528cef30ec27"
    sku_name                        = "premium"
    enabled_for_deployment          = true
    enabled_for_disk_encryption     = true
    enabled_for_template_deployment = true
    legacy_access_policies_enabled  = false
    public_network_access_enabled   = false
    purge_protection_enabled        = true
    soft_delete_retention_days      = 90
    network_acls = {
      bypass                     = "AzureServices"
      default_action             = "Deny"
      ip_rules                   = []
      virtual_network_subnet_ids = []
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Call Out Procedures"
    }
  }
}

key_vault_imports = {
  app = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvcopsnonprodcac001"
}

# Created by the platform (Defender/AMA default workspace).
log_analytics_workspace = {
  default_ccan = {
    name                       = "DefaultWorkspace-675a173c-0b66-4506-9aec-c0b2681e0fb9-CCAN"
    resource_group_key         = "defaultresourcegroup_ccan"
    location                   = "canadacentral"
    sku                        = "PerGB2018"
    retention_in_days          = 30
    daily_quota_gb             = -1
    internet_ingestion_enabled = "true"
    internet_query_enabled     = "true"
    # local_authentication_enabled    = true
    allow_resource_only_permissions = true
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Call Out Procedures"
    }
  }
}

log_analytics_workspace_imports = {
  default_ccan = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/DefaultResourceGroup-CCAN/providers/Microsoft.OperationalInsights/workspaces/DefaultWorkspace-675a173c-0b66-4506-9aec-c0b2681e0fb9-CCAN"
}

# Protocols use the wrapper's casing (Tcp); Azure reports TCP, so a case-only
# update may appear.
network_security_group = {
  app = {
    name               = "nsg-app-cops-nonprod-canadacentral-001"
    resource_group_key = "app"
    location           = "canadacentral"
    security_rules = {
      allowonprem = {
        name                       = "AllowOnPrem"
        access                     = "Allow"
        direction                  = "Inbound"
        priority                   = 200
        protocol                   = "*"
        source_port_range          = "*"
        destination_port_range     = "*"
        source_address_prefixes    = ["10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "142.52.0.0/16"]
        destination_address_prefix = "*"
      }
      allowinternalhealthping = {
        name                       = "AllowInternalHealthPing"
        access                     = "Allow"
        direction                  = "Inbound"
        priority                   = 201
        protocol                   = "Tcp"
        source_port_range          = "*"
        destination_port_ranges    = ["80", "8080"]
        source_address_prefix      = "AzureLoadBalancer"
        destination_address_prefix = "10.195.96.0/24"
      }
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Call Out Procedures"
    }
  }
  pep = {
    name               = "nsg-pep-cops-nonprod-canadacentral-001"
    resource_group_key = "app"
    location           = "canadacentral"
    security_rules = {
      allowonprem = {
        name                       = "AllowOnPrem"
        access                     = "Allow"
        direction                  = "Inbound"
        priority                   = 200
        protocol                   = "*"
        source_port_range          = "*"
        destination_port_range     = "*"
        source_address_prefixes    = ["10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "142.52.0.0/16"]
        destination_address_prefix = "*"
      }
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Call Out Procedures"
    }
  }
  sql = {
    name               = "nsg-sql-cops-nonprod-canadacentral-001"
    resource_group_key = "app"
    location           = "canadacentral"
    security_rules = {
      allowonprem = {
        name                       = "AllowOnPrem"
        access                     = "Allow"
        direction                  = "Inbound"
        priority                   = 200
        protocol                   = "*"
        source_port_range          = "*"
        destination_port_range     = "*"
        source_address_prefixes    = ["10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "142.52.0.0/16"]
        destination_address_prefix = "*"
      }
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Call Out Procedures"
    }
  }
}

import_network_security_group = {
  app = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-app-cops-nonprod-canadacentral-001"
  pep = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-pep-cops-nonprod-canadacentral-001"
  sql = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-sql-cops-nonprod-canadacentral-001"
}

network_security_rule_imports = {
  "app/allowonprem" = {
    nsg_key  = "app"
    rule_key = "allowonprem"
    id       = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-app-cops-nonprod-canadacentral-001/securityRules/AllowOnPrem"
  }
  "app/allowinternalhealthping" = {
    nsg_key  = "app"
    rule_key = "allowinternalhealthping"
    id       = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-app-cops-nonprod-canadacentral-001/securityRules/AllowInternalHealthPing"
  }
  "pep/allowonprem" = {
    nsg_key  = "pep"
    rule_key = "allowonprem"
    id       = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-pep-cops-nonprod-canadacentral-001/securityRules/AllowOnPrem"
  }
  "sql/allowonprem" = {
    nsg_key  = "sql"
    rule_key = "allowonprem"
    id       = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-sql-cops-nonprod-canadacentral-001/securityRules/AllowOnPrem"
  }
}

# Its VNet flow log stays unmanaged.
network_watcher = {
  canadacentral = {
    name               = "NetworkWatcher_canadacentral_cops_app_nonprod"
    resource_group_key = "shared_app"
    location           = "canadacentral"
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Call Out Procedures"
    }
  }
}

network_watcher_imports = {
  canadacentral = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-shared-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkWatchers/NetworkWatcher_canadacentral_cops_app_nonprod"
}

# Local copy of the Service Bus private link zone; it has no VNet links and its
# record sets are not managed.
private_dns_zone = {
  servicebus = {
    name                  = "privatelink.servicebus.windows.net"
    resource_group_key    = "app"
    virtual_network_links = {}
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Call Out Procedures"
    }
  }
}

private_dns_zone_imports = {
  servicebus = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.servicebus.windows.net"
}

private_dns_zone_link_imports = {}

private_endpoint = {
  sb = {
    name                            = "pe-sb-cops-nonprod-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-nonprod-canadacentral-001/subnets/snet-pep-cops-nonprod-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.ServiceBus/namespaces/sb-cops-nonprod-canadacentral-001"
    private_service_connection_name = "pe-sb-cops-nonprod-canadacentral-001_d617bded-6060-457c-88e1-3a01b319d016"
    subresource_names               = ["namespace"]
    network_interface_name          = null
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.azurewebsites.net",
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.servicebus.windows.net"
    ]
    ip_configurations = {}
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = " YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Call Out Procedures"
    }
  }
  wrk = {
    name                            = "pe-wrk-cops-nonprod-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-nonprod-canadacentral-001/subnets/snet-pep-cops-nonprod-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Web/Sites/wrk-cops-nonprod-canadacentral-001"
    private_service_connection_name = "pe-wrk-cops-nonprod-canadacentral-001"
    subresource_names               = ["sites"]
    network_interface_name          = null
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.azurewebsites.net"
    ]
    ip_configurations = {}
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = " YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Call Out Procedures"
    }
  }
  api = {
    name                            = "pep-api-cops-nonprod-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-nonprod-canadacentral-001/subnets/snet-pep-cops-nonprod-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourcegroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Web/sites/api-cops-nonprod-canadacentral-001"
    private_service_connection_name = "pep-api-cops-nonprod-canadacentral-001"
    subresource_names               = ["sites"]
    network_interface_name          = "pep-api-cops-nonprod-canadacentral-001-nic"
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.azurewebsites.net"
    ]
    ip_configurations = {
      pep_api_cops_nonprod_canadacentral_001 = {
        name               = "pep-api-cops-nonprod-canadacentral-001"
        private_ip_address = "10.195.98.8"
        subresource_name   = "sites"
        member_name        = "sites"
      }
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Call Out Procedures"
    }
  }
  app = {
    name                            = "pep-app-cops-nonprod-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-nonprod-canadacentral-001/subnets/snet-pep-cops-nonprod-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Web/sites/app-cops-nonprod-canadacentral-001"
    private_service_connection_name = "pep-app-cops-nonprod-canadacentral-001"
    subresource_names               = ["sites"]
    network_interface_name          = "pep-app-cops-nonprod-canadacentral-001-nic"
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.azurewebsites.net"
    ]
    ip_configurations = {
      app_cops_nonprod_canadacentral_001 = {
        name               = "app-cops-nonprod-canadacentral-001"
        private_ip_address = "10.195.98.7"
        subresource_name   = "sites"
        member_name        = "sites"
      }
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Call Out Procedures"
    }
  }
  disk = {
    name                            = "pep-disk-cops-nonprod-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-nonprod-canadacentral-001/subnets/snet-pep-cops-nonprod-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Compute/diskAccesses/access-disk-cops-nonprod-canadacentral-001"
    private_service_connection_name = "access-disk-cops-nonprod-canadacentral-001"
    subresource_names               = ["disks"]
    network_interface_name          = null
    private_dns_zone_group_name     = "cops_nonprod_canadacentral_disk_zone_group"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net"
    ]
    ip_configurations = {}
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Call Out Procedures"
    }
  }
  kv = {
    name                            = "pep-kv-cops-nonprod-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-nonprod-canadacentral-001/subnets/snet-pep-cops-nonprod-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvcopsnonprodcac001"
    private_service_connection_name = "kvcopsnonprodcac001"
    subresource_names               = ["vault"]
    network_interface_name          = null
    private_dns_zone_group_name     = "cops_nonprod_canadacentral_kv_zone_group"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.vaultcore.azure.net"
    ]
    ip_configurations = {}
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Call Out Procedures"
    }
  }
  redis = {
    name                            = "pep-redis-cops-nonprod-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-nonprod-canadacentral-001/subnets/snet-pep-cops-nonprod-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Cache/redis/redis-cops-nonprod-canadacentral-001"
    private_service_connection_name = "pep-redis-cops-nonprod-canadacentral-001"
    subresource_names               = ["redisCache"]
    network_interface_name          = "pep-redis-cops-nonprod-canadacentral-001-nic"
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.redis.cache.windows.net"
    ]
    ip_configurations = {}
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Call Out Procedures"
    }
  }
  sql = {
    name                            = "pep-sql-cops-nonprod-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-nonprod-canadacentral-001/subnets/snet-pep-cops-nonprod-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Sql/servers/sql-cops-nonprod-canadacentral-001"
    private_service_connection_name = "sql-cops-nonprod-canadacentral-001"
    subresource_names               = ["SqlServer"]
    network_interface_name          = null
    private_dns_zone_group_name     = "cops_nonprod_canadacentral_sql_zone_group"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.database.windows.net"
    ]
    ip_configurations = {}
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Call Out Procedures"
    }
  }
  stapp = {
    name                            = "pep-stapp-cops-nonprod-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-nonprod-canadacentral-001/subnets/snet-pep-cops-nonprod-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Storage/storageAccounts/stappcopsnonprodcac01"
    private_service_connection_name = "pep-stapp-cops-nonprod-canadacentral-001"
    subresource_names               = ["file"]
    network_interface_name          = "pep-stapp-cops-nonprod-canadacentral-001-nic"
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.file.core.windows.net"
    ]
    ip_configurations = {}
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Call Out Procedures"
    }
  }
}

private_endpoint_imports = {
  sb    = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pe-sb-cops-nonprod-canadacentral-001"
  wrk   = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pe-wrk-cops-nonprod-canadacentral-001"
  api   = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-api-cops-nonprod-canadacentral-001"
  app   = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-app-cops-nonprod-canadacentral-001"
  disk  = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-disk-cops-nonprod-canadacentral-001"
  kv    = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-kv-cops-nonprod-canadacentral-001"
  redis = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-redis-cops-nonprod-canadacentral-001"
  sql   = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-sql-cops-nonprod-canadacentral-001"
  stapp = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-stapp-cops-nonprod-canadacentral-001"
}

redis_cache = {
  app = {
    name                               = "redis-cops-nonprod-canadacentral-001"
    resource_group_key                 = "app"
    location                           = "canadacentral"
    sku_name                           = "Standard"
    family                             = "C"
    capacity                           = 1
    redis_version                      = "6"
    minimum_tls_version                = "1.2"
    non_ssl_port_enabled               = false
    public_network_access_enabled      = false
    access_keys_authentication_enabled = true
    redis_configuration = {
      active_directory_authentication_enabled = true
      maxmemory_policy                        = "noeviction"
      maxmemory_reserved                      = 125
      maxmemory_delta                         = 125
      maxfragmentationmemory_reserved         = 125
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Call Out Procedures"
    }
  }
}

redis_cache_imports = {
  app = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Cache/redis/redis-cops-nonprod-canadacentral-001"
}

# Queues, topics and authorization rules stay unmanaged. Zone redundancy is
# automatic for Premium and not set here.
service_bus_namespace = {
  app = {
    name                          = "sb-cops-nonprod-canadacentral-001"
    resource_group_key            = "app"
    location                      = "canadacentral"
    sku                           = "Premium"
    capacity                      = 1
    premium_messaging_partitions  = 1
    local_auth_enabled            = true
    minimum_tls_version           = "1.2"
    public_network_access_enabled = false
    identity_type                 = "SystemAssigned"
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = " YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Call Out Procedures"
    }
  }
}

service_bus_namespace_imports = {
  app = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.ServiceBus/namespaces/sb-cops-nonprod-canadacentral-001"
}

# SQL logins are enabled alongside Entra ID; the admin password is not managed.
# The COPS40_STAGING database and the elastic job agent stay unmanaged.
sql_server = {
  app = {
    name                                     = "sql-cops-nonprod-canadacentral-001"
    resource_group_key                       = "app"
    location                                 = "canadacentral"
    server_version                           = "12.0"
    administrator_login                      = "CloudSA0a621de9"
    public_network_access_enabled            = false
    outbound_network_restriction_enabled     = false
    express_vulnerability_assessment_enabled = true
    primary_user_assigned_identity_id        = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-mid-cops-app-nonprod-canadacentral-001/providers/Microsoft.ManagedIdentity/userAssignedIdentities/mid-app-cops-nonprod-canadacentral-001"
    user_assigned_identity_ids = [
      "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-mid-cops-app-nonprod-canadacentral-001/providers/Microsoft.ManagedIdentity/userAssignedIdentities/mid-app-cops-nonprod-canadacentral-001"
    ]
    azuread_administrator = {
      azuread_authentication_only = false
      login_username              = "fujitsu_ams_dba_cloud"
      object_id                   = "3c563ed4-04ee-4a74-a34c-4bbb677e7a70"
      tenant_id                   = "8fbb85e8-0cbc-48c3-a2e9-528cef30ec27"
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Call Out Procedures"
    }
  }
}

sql_server_imports = {
  app = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Sql/servers/sql-cops-nonprod-canadacentral-001"
}

# app_files is a provisioned v2 premium file account (PremiumV2_LRS) serving the
# NFS share mounted by app-cops; HTTPS-only is off because NFS requires it.
# Blob retention is disabled on the blob account, so blob_properties is unset.
storage_account = {
  app_files = {
    name                              = "stappcopsnonprodcac01"
    resource_group_key                = "app"
    location                          = "canadacentral"
    account_kind                      = "FileStorage"
    account_tier                      = "Premium"
    account_replication_type          = "LRS"
    access_tier                       = null
    provisioned_billing_model_version = "V2"
    allow_nested_items_to_be_public   = false
    cross_tenant_replication_enabled  = false
    default_to_oauth_authentication   = false
    https_traffic_only_enabled        = false
    infrastructure_encryption_enabled = false
    is_hns_enabled                    = false
    large_file_share_enabled          = true
    min_tls_version                   = "TLS1_2"
    public_network_access_enabled     = false
    sftp_enabled                      = false
    shared_access_key_enabled         = true
    network_rules = {
      bypass                     = ["AzureServices"]
      default_action             = "Deny"
      ip_rules                   = []
      virtual_network_subnet_ids = []
      private_link_access        = []
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Call Out Procedures"
    }
  }
  app = {
    name                              = "stcopsnonprodcac001"
    resource_group_key                = "app"
    location                          = "canadacentral"
    account_kind                      = "StorageV2"
    account_tier                      = "Standard"
    account_replication_type          = "LRS"
    access_tier                       = "Hot"
    provisioned_billing_model_version = null
    allow_nested_items_to_be_public   = false
    cross_tenant_replication_enabled  = false
    default_to_oauth_authentication   = false
    https_traffic_only_enabled        = true
    infrastructure_encryption_enabled = false
    is_hns_enabled                    = false
    min_tls_version                   = "TLS1_2"
    public_network_access_enabled     = false
    sftp_enabled                      = false
    shared_access_key_enabled         = true
    network_rules = {
      bypass                     = ["AzureServices"]
      default_action             = "Deny"
      ip_rules                   = ["155.190.0.11", "155.190.0.9"]
      virtual_network_subnet_ids = []
      private_link_access = [
        {
          endpoint_resource_id = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/providers/Microsoft.Security/datascanners/storageDataScanner"
          endpoint_tenant_id   = "8fbb85e8-0cbc-48c3-a2e9-528cef30ec27"
        }
      ]
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Call Out Procedures"
    }
  }
}

# Public network access is enabled on these, and Deny_Public_Access_On_PaaS_Services_v0
# denies any write to them, so they are read, not adopted, until exempted.
storage_account_existing = {
  network_watcher = {
    name               = "stnwcopsnonprodcac"
    resource_group_key = "shared_app"
  }
}

storage_account_imports = {
  app_files = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Storage/storageAccounts/stappcopsnonprodcac01"
  app       = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Storage/storageAccounts/stcopsnonprodcac001"
}

user_assigned_identity = {
  api = {
    name               = "mid-api-cops-nonprod-canadacentral-001"
    resource_group_key = "mid_app"
    location           = "canadacentral"
    isolation_scope    = null
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Call Out Procedures"
    }
  }
  app = {
    name               = "mid-app-cops-nonprod-canadacentral-001"
    resource_group_key = "mid_app"
    location           = "canadacentral"
    isolation_scope    = null
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Call Out Procedures"
    }
  }
}

user_assigned_identity_imports = {
  api = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-mid-cops-app-nonprod-canadacentral-001/providers/Microsoft.ManagedIdentity/userAssignedIdentities/mid-api-cops-nonprod-canadacentral-001"
  app = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-mid-cops-app-nonprod-canadacentral-001/providers/Microsoft.ManagedIdentity/userAssignedIdentities/mid-app-cops-nonprod-canadacentral-001"
}

# Off for now, as in Fabric, FIT and PTA: the VNet module's body omits subnets and
# peerings, and the only peering is the vWAN hub connection owned by
# tf-deploy-platform-connectivity. defaultOutboundAccess is not reported, so
# Azure's default (enabled) is assumed; it is create-time only.
virtual_network = {
  app = {
    name               = "vnet-cops-nonprod-canadacentral-001"
    resource_group_key = "app"
    location           = "canadacentral"
    address_space      = ["10.195.96.0/22"]
    dns_servers = {
      dns_servers = ["10.195.1.4"]
    }
    ddos_protection_plan = {
      enable = true
      id     = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/ddosProtectionPlans/ddos-protection-plan"
    }
    subnets = {
      sql = {
        name                                          = "snet-sql-cops-nonprod-canadacentral-001"
        address_prefixes                              = ["10.195.97.0/24"]
        default_outbound_access_enabled               = true
        private_endpoint_network_policies             = "Disabled"
        private_link_service_network_policies_enabled = true
        network_security_group = {
          id = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-sql-cops-nonprod-canadacentral-001"
        }
        service_endpoint_policies       = {}
        service_endpoints_with_location = []
        delegations                     = []
      }
      app = {
        name                                          = "snet-app-cops-nonprod-canadacentral-001"
        address_prefixes                              = ["10.195.96.0/24"]
        default_outbound_access_enabled               = true
        private_endpoint_network_policies             = "Disabled"
        private_link_service_network_policies_enabled = true
        network_security_group = {
          id = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-app-cops-nonprod-canadacentral-001"
        }
        service_endpoint_policies       = {}
        service_endpoints_with_location = []
        delegations = [
          {
            name = "serverFarmDelegation"
            service_delegation = {
              name    = "Microsoft.Web/serverFarms"
              actions = ["Microsoft.Network/virtualNetworks/subnets/action"]
            }
          }
        ]
      }
      pep = {
        name                                          = "snet-pep-cops-nonprod-canadacentral-001"
        address_prefixes                              = ["10.195.98.0/23"]
        default_outbound_access_enabled               = true
        private_endpoint_network_policies             = "RouteTableEnabled"
        private_link_service_network_policies_enabled = true
        network_security_group = {
          id = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-pep-cops-nonprod-canadacentral-001"
        }
        service_endpoint_policies       = {}
        service_endpoints_with_location = []
        delegations                     = []
      }
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001624"
      ApplicationServiceLevel = "Bronze"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Call Out Procedures"
    }
  }
}

virtual_network_imports = {
  app = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-nonprod-canadacentral-001"
}

virtual_network_subnet_imports = {
  cops_sql = {
    vnet_key   = "app"
    subnet_key = "sql"
    id         = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-nonprod-canadacentral-001/subnets/snet-sql-cops-nonprod-canadacentral-001"
  }
  cops_app = {
    vnet_key   = "app"
    subnet_key = "app"
    id         = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-nonprod-canadacentral-001/subnets/snet-app-cops-nonprod-canadacentral-001"
  }
  cops_pep = {
    vnet_key   = "app"
    subnet_key = "pep"
    id         = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-nonprod-canadacentral-001/subnets/snet-pep-cops-nonprod-canadacentral-001"
  }
}

# Off for the first apply (see README). The module rewrites the full app settings
# on apply, so the masked settings below must be Key Vault references or real
# sensitive values before enabling. app-cops-nonprod-canadacentral-001 is not
# modelled: its NFS storage mount cannot be written by the module and would be
# replaced with an SMB mount.
web_app = {
  api = {
    name                                     = "api-cops-nonprod-canadacentral-001"
    resource_group_key                       = "app"
    location                                 = "canadacentral"
    os_type                                  = "Linux"
    app_service_plan_key                     = "app"
    virtual_network_subnet_id                = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-nonprod-canadacentral-001/subnets/snet-app-cops-nonprod-canadacentral-001"
    enabled                                  = true
    https_only                               = true
    public_network_access_enabled            = false
    client_affinity_enabled                  = false
    client_affinity_proxy_enabled            = false
    client_certificate_enabled               = false
    client_certificate_mode                  = "Required"
    end_to_end_encryption_enabled            = false
    host_names_disabled                      = false
    hyper_v                                  = false
    ip_mode                                  = "IPv4"
    redundancy_mode                          = "None"
    vnet_route_all_traffic                   = false
    vnet_application_traffic_enabled         = true
    vnet_content_share_enabled               = false
    vnet_image_pull_enabled                  = false
    virtual_network_backup_restore_enabled   = false
    ftp_publish_basic_authentication_enabled = false
    scm_publish_basic_authentication_enabled = true
    system_assigned_identity                 = true
    user_assigned_identity_ids = [
      "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-mid-cops-app-nonprod-canadacentral-001/providers/Microsoft.ManagedIdentity/userAssignedIdentities/mid-api-cops-nonprod-canadacentral-001"
    ]
    key_vault_reference_identity = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-mid-cops-app-nonprod-canadacentral-001/providers/Microsoft.ManagedIdentity/userAssignedIdentities/mid-api-cops-nonprod-canadacentral-001"
    site_config = {
      always_on        = true
      linux_fx_version = "NODE|22-lts"
      app_command_line = null
      default_documents = [
        "Default.htm",
        "Default.html",
        "Default.asp",
        "index.htm",
        "index.html",
        "iisstart.htm",
        "default.aspx",
        "index.php",
        "hostingstart.html"
      ]
      detailed_error_logging_enabled    = false
      elastic_web_app_scale_limit       = 0
      elastic_instance_minimum          = 1
      ftps_state                        = "FtpsOnly"
      http2_enabled                     = false
      http20_proxy_flag                 = 0
      http_logging_enabled              = true
      ip_restriction                    = []
      ip_restriction_default_action     = "Allow"
      load_balancing_mode               = "LeastRequests"
      local_mysql_enabled               = false
      logs_directory_size_limit         = 100
      managed_pipeline_mode             = "Integrated"
      minimum_tls_version               = "1.2"
      scm_minimum_tls_version           = "1.2"
      worker_count                      = 1
      pre_warmed_instance_count         = 0
      remote_debugging_enabled          = false
      request_tracing_enabled           = false
      scm_ip_restriction                = []
      scm_ip_restriction_default_action = "Allow"
      scm_use_main_ip_restriction       = false
      use_32_bit_worker                 = true
      virtual_application = [
        {
          physical_path     = "site\\wwwroot"
          preload_enabled   = true
          virtual_path      = "/"
          virtual_directory = []
        }
      ]
      vnet_private_ports_count                = 0
      vnet_route_all_enabled                  = true
      websockets_enabled                      = false
      website_time_zone                       = "America/Vancouver"
      container_registry_use_managed_identity = false
      metadata                                = []
    }
    app_settings = {
      API_KEY                                       = "@Microsoft.KeyVault(SecretUri=https://kvcopsnonprodcac001.vault.azure.net/secrets/MOBILE-API-KEY)"
      APNS_BUNDLE_ID                                = "com.flightdeckmedia.cops.staging"
      APNS_P8_BASE64                                = "@Microsoft.KeyVault(SecretUri=https://kvcopsnonprodcac001.vault.azure.net/secrets/APNS-P8-BASE64)"
      APNS_P8_PEM                                   = "-----BEGIN PRIVATE KEY----- MIGTAgEAMBMGByqGSM49AgEGCCqGSM49AwEHBHkwdwIBAQQgE1pHfaBf58Gw8Rau 7UfbDTGLkWcGt/fp98SYFJJbqgWgCgYIKoZIzj0DAQehRANCAAQWSazQv950G1Od nAXpdTCMmx3avrbMUlPLbIY4gG6Ox9JFOFBysnij+acq5jAaImz9MZY5uZT6zsmR LccuqeVH -----END PRIVATE KEY-----"
      APNS_TEAM_ID                                  = "4K6Z897NMU"
      AZURE_CLIENT_ID                               = "fafff1ed-536b-4524-b6cf-15931f647122"
      AZURE_TENANT_ID                               = "8fbb85e8-0cbc-48c3-a2e9-528cef30ec27"
      CALLOUT_ENGINE                                = "servicebus"
      CALLOUT_SINGLE_ACTIVE_RUN_PER_TICKET          = "true"
      DB_HOST                                       = "sql-cops-nonprod-canadacentral-001.database.windows.net"
      DB_NAME                                       = "COPS40_STAGING"
      DB_PASSWORD                                   = "@Microsoft.KeyVault(SecretUri=https://kvcopsnonprodcac001.vault.azure.net/secrets/DATABASE-PASSWORD)"
      ENABLE_ORYX_BUILD                             = "false"
      IS_BCH_MACHINE                                = "true"
      JWT_SECRET                                    = "@Microsoft.KeyVault(SecretUri=https://kvcopsnonprodcac001.vault.azure.net/secrets/JWT-SECRET)"
      MICROSOFT_PROVIDER_AUTHENTICATION_SECRET      = "@Microsoft.KeyVault(SecretUri=https://kvcopsnonprodcac001.vault.azure.net/secrets/MICROSOFT-PROVIDER-AUTHENTICATION-SECRET-API)"
      NODE_ENV                                      = "STAGING"
      ORYX_ENABLE_NPM_CACHE                         = "true"
      REDIS_HOST                                    = "redis-cops-nonprod-canadacentral-001.redis.cache.windows.net"
      REDIS_PASSWORD                                = "@Microsoft.KeyVault(SecretUri=https://kvcopsnonprodcac001.vault.azure.net/secrets/REDIS-PASSWORD)"
      REDIS_PORT                                    = "6380"
      REDIS_URL                                     = "@Microsoft.KeyVault(SecretUri=https://kvcopsnonprodcac001.vault.azure.net/secrets/REDIS-URL)"
      SCM_DO_BUILD_DURING_DEPLOYMENT                = "false"
      ServiceBusConnection__fullyQualifiedNamespace = "sb-cops-nonprod-canadacentral-001.servicebus.windows.net"
      ServiceBusQueueName                           = "callout-jobs"
      WEBSITE_AUTH_AAD_ALLOWED_TENANTS              = "8fbb85e8-0cbc-48c3-a2e9-528cef30ec27"
      WEBSITE_AUTH_EXCLUDED_PATHS                   = "/socket.io/*,/realtime/*, /realtime/socket.io/*"
      WEBSITE_RUN_FROM_PACKAGE                      = "true"
      WEBSITE_TIME_ZONE                             = "America/Vancouver"
      XDT_MicrosoftApplicationInsights_Mode         = "default"
    }
    secret_app_setting_names = [
      "APNS_KEY_ID",
      "APPLICATIONINSIGHTS_CONNECTION_STRING",
      "DB_USER",
      "REDIS_USERNAME"
    ]
    connection_strings       = {}
    sticky_app_setting_names = ["MICROSOFT_PROVIDER_AUTHENTICATION_SECRET"]
    tags = {
      ApplicationId                            = "BCH – LIX -0000001624"
      ApplicationServiceLevel                  = "Bronze"
      CostCenterId                             = "YT-01585.S.IMP.CLZ"
      Environment                              = "NonProd"
      Name                                     = "Call Out Procedures"
      "hidden-link: /app-insights-resource-id" = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/microsoft.insights/components/ai-func-cops-nonprod-canadacentral-001"
    }
  }
  wrk = {
    name                                     = "wrk-cops-nonprod-canadacentral-001"
    resource_group_key                       = "app"
    location                                 = "canadacentral"
    os_type                                  = "Linux"
    app_service_plan_key                     = "app"
    virtual_network_subnet_id                = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-nonprod-canadacentral-001/subnets/snet-app-cops-nonprod-canadacentral-001"
    enabled                                  = true
    https_only                               = true
    public_network_access_enabled            = false
    client_affinity_enabled                  = false
    client_affinity_proxy_enabled            = false
    client_certificate_enabled               = false
    client_certificate_mode                  = "Required"
    end_to_end_encryption_enabled            = false
    host_names_disabled                      = false
    hyper_v                                  = false
    ip_mode                                  = "IPv4"
    redundancy_mode                          = "None"
    vnet_route_all_traffic                   = false
    vnet_application_traffic_enabled         = true
    vnet_content_share_enabled               = false
    vnet_image_pull_enabled                  = false
    virtual_network_backup_restore_enabled   = false
    ftp_publish_basic_authentication_enabled = false
    scm_publish_basic_authentication_enabled = true
    system_assigned_identity                 = true
    user_assigned_identity_ids               = []
    key_vault_reference_identity             = "SystemAssigned"
    site_config = {
      always_on        = true
      linux_fx_version = "NODE|22-lts"
      app_command_line = "npm run start:worker"
      default_documents = [
        "Default.htm",
        "Default.html",
        "Default.asp",
        "index.htm",
        "index.html",
        "iisstart.htm",
        "default.aspx",
        "index.php",
        "hostingstart.html"
      ]
      detailed_error_logging_enabled    = false
      elastic_web_app_scale_limit       = 0
      elastic_instance_minimum          = 0
      ftps_state                        = "FtpsOnly"
      http2_enabled                     = false
      http20_proxy_flag                 = 0
      http_logging_enabled              = true
      ip_restriction                    = []
      ip_restriction_default_action     = "Allow"
      load_balancing_mode               = "LeastRequests"
      local_mysql_enabled               = false
      logs_directory_size_limit         = 100
      managed_pipeline_mode             = "Integrated"
      minimum_tls_version               = "1.2"
      scm_minimum_tls_version           = "1.2"
      worker_count                      = 1
      pre_warmed_instance_count         = 0
      remote_debugging_enabled          = false
      request_tracing_enabled           = false
      scm_ip_restriction                = []
      scm_ip_restriction_default_action = "Allow"
      scm_use_main_ip_restriction       = false
      use_32_bit_worker                 = true
      virtual_application = [
        {
          physical_path     = "site\\wwwroot"
          preload_enabled   = true
          virtual_path      = "/"
          virtual_directory = []
        }
      ]
      vnet_private_ports_count                = 0
      vnet_route_all_enabled                  = true
      websockets_enabled                      = false
      website_time_zone                       = "America/Vancouver"
      container_registry_use_managed_identity = false
      metadata                                = []
    }
    app_settings = {
      APNS_BUNDLE_ID                                = "com.flightdeckmedia.cops.staging"
      APNS_P8_BASE64                                = "@Microsoft.KeyVault(SecretUri=https://kvcopsnonprodcac001.vault.azure.net/secrets/APNS-P8-BASE64)"
      APNS_P8_PEM                                   = "-----BEGIN PRIVATE KEY----- MIGTAgEAMBMGByqGSM49AgEGCCqGSM49AwEHBHkwdwIBAQQgE1pHfaBf58Gw8Rau 7UfbDTGLkWcGt/fp98SYFJJbqgWgCgYIKoZIzj0DAQehRANCAAQWSazQv950G1Od nAXpdTCMmx3avrbMUlPLbIY4gG6Ox9JFOFBysnij+acq5jAaImz9MZY5uZT6zsmR LccuqeVH -----END PRIVATE KEY-----"
      APNS_TEAM_ID                                  = "4K6Z897NMU"
      ApplicationInsightsAgent_EXTENSION_VERSION    = "~3"
      CALLOUT_SINGLE_ACTIVE_RUN_PER_TICKET          = "true"
      CALLOUT_WORKER_CONCURRENCY                    = "1"
      DB_HOST                                       = "sql-cops-nonprod-canadacentral-001.database.windows.net"
      DB_NAME                                       = "COPS40_STAGING"
      IS_BCH_MACHINE                                = "true"
      NODE_ENV                                      = "staging"
      SERVICE_BUS_OUTBOX_MAX_ATTEMPTS               = "20"
      ServiceBusConnection__fullyQualifiedNamespace = "sb-cops-nonprod-canadacentral-001.servicebus.windows.net"
      ServiceBusQueueName                           = "callout-jobs"
      WEBSITE_TIME_ZONE                             = "America/Vancouver"
      XDT_MicrosoftApplicationInsights_Mode         = "default"
    }
    secret_app_setting_names = ["APNS_KEY_ID", "APPLICATIONINSIGHTS_CONNECTION_STRING"]
    connection_strings       = {}
    sticky_app_setting_names = []
    tags = {
      ApplicationId                            = "BCH – LIX -0000001624"
      ApplicationServiceLevel                  = "Bronze"
      CostCenterId                             = " YT-01585.S.IMP.CLZ"
      Environment                              = "NonProd"
      Name                                     = "Call Out Procedures"
      "hidden-link: /app-insights-resource-id" = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/microsoft.insights/components/ai-func-cops-nonprod-canadacentral-001"
    }
  }
}

web_app_imports = {
  api = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Web/sites/api-cops-nonprod-canadacentral-001"
  wrk = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Web/sites/wrk-cops-nonprod-canadacentral-001"
}

# =====================================================================
# Hub private DNS: links and records in the shared zones (connectivity subscription)
# =====================================================================

enable_hub_private_dns = true

hub_private_dns_zone_link = {
  "internal.bchydro.bc.ca/link-sites-cops-nonprod-canadacentral-001" = {
    name               = "link-sites-cops-nonprod-canadacentral-001"
    zone_name          = "internal.bchydro.bc.ca"
    virtual_network_id = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-nonprod-canadacentral-001"
  }
  "link-blob-cops-nonprod-canadacentral-001" = {
    name               = "link-blob-cops-nonprod-canadacentral-001"
    zone_name          = "privatelink.blob.core.windows.net"
    virtual_network_id = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-nonprod-canadacentral-001"
  }
  "link-cops-canadacentral-001" = {
    name                 = "link-cops-canadacentral-001"
    zone_name            = "bchydro.bc.ca"
    virtual_network_id   = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-nonprod-canadacentral-001"
    registration_enabled = true
  }
  "link-files-cops-nonprod-canadacentral-001" = {
    name               = "link-files-cops-nonprod-canadacentral-001"
    zone_name          = "privatelink.file.core.windows.net"
    virtual_network_id = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-nonprod-canadacentral-001"
  }
  "link-sb-cops-nonprod-canadacentral-001" = {
    name               = "link-sb-cops-nonprod-canadacentral-001"
    zone_name          = "privatelink.servicebus.windows.net"
    virtual_network_id = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-nonprod-canadacentral-001"
  }
  "link-sql-cops-nonprod-canadacentral-001" = {
    name               = "link-sql-cops-nonprod-canadacentral-001"
    zone_name          = "privatelink.database.windows.net"
    virtual_network_id = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-nonprod-canadacentral-001"
  }
  "link-vault-cops-nonprod-canadacentral-001" = {
    name               = "link-vault-cops-nonprod-canadacentral-001"
    zone_name          = "privatelink.vaultcore.azure.net"
    virtual_network_id = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-nonprod-canadacentral-001"
  }
  "privatelink.agentsvc.azure-automation.net/link-cops-nonprod-canadacentral" = {
    name               = "link-cops-nonprod-canadacentral"
    zone_name          = "privatelink.agentsvc.azure-automation.net"
    virtual_network_id = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-nonprod-canadacentral-001"
  }
  "privatelink.azurewebsites.net/link-sites-cops-nonprod-canadacentral-001" = {
    name               = "link-sites-cops-nonprod-canadacentral-001"
    zone_name          = "privatelink.azurewebsites.net"
    virtual_network_id = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-nonprod-canadacentral-001"
  }
  "privatelink.monitor.azure.com/link-cops-nonprod-canadacentral" = {
    name               = "link-cops-nonprod-canadacentral"
    zone_name          = "privatelink.monitor.azure.com"
    virtual_network_id = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-nonprod-canadacentral-001"
  }
  "privatelink.ods.opinsights.azure.com/link-cops-nonprod-canadacentral" = {
    name               = "link-cops-nonprod-canadacentral"
    zone_name          = "privatelink.ods.opinsights.azure.com"
    virtual_network_id = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-nonprod-canadacentral-001"
  }
  "privatelink.oms.opinsights.azure.com/link-cops-nonprod-canadacentral" = {
    name               = "link-cops-nonprod-canadacentral"
    zone_name          = "privatelink.oms.opinsights.azure.com"
    virtual_network_id = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-nonprod-canadacentral-001"
  }
  "privatelink.redis.azure.net/dmzd6g33v2eog" = {
    name               = "dmzd6g33v2eog"
    zone_name          = "privatelink.redis.azure.net"
    virtual_network_id = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-nonprod-canadacentral-001"
  }
  "privatelink.redis.cache.windows.net/dmzd6g33v2eog" = {
    name               = "dmzd6g33v2eog"
    zone_name          = "privatelink.redis.cache.windows.net"
    virtual_network_id = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-nonprod-canadacentral-001"
  }
}

hub_private_dns_zone_link_imports = {
  "internal.bchydro.bc.ca/link-sites-cops-nonprod-canadacentral-001"          = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/internal.bchydro.bc.ca/virtualNetworkLinks/link-sites-cops-nonprod-canadacentral-001"
  "link-blob-cops-nonprod-canadacentral-001"                                  = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net/virtualNetworkLinks/link-blob-cops-nonprod-canadacentral-001"
  "link-cops-canadacentral-001"                                               = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/bchydro.bc.ca/virtualNetworkLinks/link-cops-canadacentral-001"
  "link-files-cops-nonprod-canadacentral-001"                                 = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.file.core.windows.net/virtualNetworkLinks/link-files-cops-nonprod-canadacentral-001"
  "link-sb-cops-nonprod-canadacentral-001"                                    = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.servicebus.windows.net/virtualNetworkLinks/link-sb-cops-nonprod-canadacentral-001"
  "link-sql-cops-nonprod-canadacentral-001"                                   = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.database.windows.net/virtualNetworkLinks/link-sql-cops-nonprod-canadacentral-001"
  "link-vault-cops-nonprod-canadacentral-001"                                 = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.vaultcore.azure.net/virtualNetworkLinks/link-vault-cops-nonprod-canadacentral-001"
  "privatelink.agentsvc.azure-automation.net/link-cops-nonprod-canadacentral" = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.agentsvc.azure-automation.net/virtualNetworkLinks/link-cops-nonprod-canadacentral"
  "privatelink.azurewebsites.net/link-sites-cops-nonprod-canadacentral-001"   = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.azurewebsites.net/virtualNetworkLinks/link-sites-cops-nonprod-canadacentral-001"
  "privatelink.monitor.azure.com/link-cops-nonprod-canadacentral"             = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.monitor.azure.com/virtualNetworkLinks/link-cops-nonprod-canadacentral"
  "privatelink.ods.opinsights.azure.com/link-cops-nonprod-canadacentral"      = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.ods.opinsights.azure.com/virtualNetworkLinks/link-cops-nonprod-canadacentral"
  "privatelink.oms.opinsights.azure.com/link-cops-nonprod-canadacentral"      = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.oms.opinsights.azure.com/virtualNetworkLinks/link-cops-nonprod-canadacentral"
  "privatelink.redis.azure.net/dmzd6g33v2eog"                                 = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.redis.azure.net/virtualNetworkLinks/dmzd6g33v2eog"
  "privatelink.redis.cache.windows.net/dmzd6g33v2eog"                         = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.redis.cache.windows.net/virtualNetworkLinks/dmzd6g33v2eog"
}

hub_private_dns_a_record = {
  "cops-dev" = {
    name      = "cops-dev"
    zone_name = "internal.bchydro.bc.ca"
    ttl       = 10
    records   = ["10.195.98.7"]
  }
}

hub_private_dns_a_record_imports = {
  "cops-dev" = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/internal.bchydro.bc.ca/A/cops-dev"
}
