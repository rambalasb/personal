#!/usr/bin/env bash
# The import zero-diff gate, shared by import-verify.yml and import-apply.yml so
# the plan that gets applied passes exactly the check that was reviewed.
#
# Usage: import_gate.sh <env> <plan.json>
set -eo pipefail
ENV_NAME="${1:?usage: import_gate.sh <env> <plan.json>}"
PLAN="${2:?usage: import_gate.sh <env> <plan.json>}"
HERE="$(cd "$(dirname "$0")" && pwd)"

# Reviewed deltas the modules cannot express. Each one must be inert in Azure.
ALLOW=()
case "$ENV_NAME" in
  nonprod)
    # Import leaves local_authentication_enabled null; live disableLocalAuth is
    # unset, so the module default of true matches.
    ALLOW+=(--allow-resource 'module.log_analytics_workspace["default_ccan"].module.log_analytics_workspace.azurerm_log_analytics_workspace.this')
    # Module sends no body; private DNS zone properties are all read-only.
    ALLOW+=(--allow-resource 'module.private_dns_zone["servicebus"].module.private_dns_zone.azapi_resource.private_dns_zone')
    ;;
esac

bash "$HERE/verify_zero_diff.sh" "$PLAN" \
  --ignore-attr response_export_values \
  --ignore-attr retry \
  --ignore-attr timeouts \
  --ignore-attr ignore_null_property \
  --ignore-attr ignore_casing \
  --ignore-attr ignore_missing_property \
  --ignore-attr schema_validation_enabled \
  --subset-attr body \
  --ignore-type time_sleep \
  --ignore-type random_uuid \
  --ignore-type modtm_telemetry \
  --ignore-type terraform_data \
  "${ALLOW[@]}"
