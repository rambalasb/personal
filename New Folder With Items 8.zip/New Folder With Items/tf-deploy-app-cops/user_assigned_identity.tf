module "user_assigned_identity" {
  for_each = var.enable_user_assigned_identity ? var.user_assigned_identity : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-user-assigned-identity/azurerm"
  version = "0.0.4"

  name                = each.value.name
  resource_group_name = module.resource_group[each.value.resource_group_key].name
  location            = coalesce(each.value.location, module.resource_group[each.value.resource_group_key].location)
  isolation_scope     = each.value.isolation_scope
  tags                = each.value.tags

  federated_identity_credentials = {}
  role_assignments               = {}
  lock                           = null
  enable_telemetry               = false
}

import {
  for_each = var.enable_user_assigned_identity ? var.user_assigned_identity_imports : {}

  to = module.user_assigned_identity[each.key].module.user_assigned_identity.azurerm_user_assigned_identity.this
  id = each.value
}
