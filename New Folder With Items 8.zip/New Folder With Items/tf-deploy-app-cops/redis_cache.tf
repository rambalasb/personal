resource "azurerm_redis_cache" "this" {
  for_each = var.enable_redis_cache ? var.redis_cache : {}

  name                               = each.value.name
  resource_group_name                = module.resource_group[each.value.resource_group_key].name
  location                           = coalesce(each.value.location, module.resource_group[each.value.resource_group_key].location)
  sku_name                           = each.value.sku_name
  family                             = each.value.family
  capacity                           = each.value.capacity
  redis_version                      = each.value.redis_version
  minimum_tls_version                = each.value.minimum_tls_version
  non_ssl_port_enabled               = each.value.non_ssl_port_enabled
  public_network_access_enabled      = each.value.public_network_access_enabled
  access_keys_authentication_enabled = each.value.access_keys_authentication_enabled
  tags                               = each.value.tags

  redis_configuration {
    active_directory_authentication_enabled = each.value.redis_configuration.active_directory_authentication_enabled
    maxmemory_policy                        = each.value.redis_configuration.maxmemory_policy
    maxmemory_reserved                      = each.value.redis_configuration.maxmemory_reserved
    maxmemory_delta                         = each.value.redis_configuration.maxmemory_delta
    maxfragmentationmemory_reserved         = each.value.redis_configuration.maxfragmentationmemory_reserved
  }

  lifecycle {
    prevent_destroy = true
  }
}

import {
  for_each = var.enable_redis_cache ? var.redis_cache_imports : {}

  to = azurerm_redis_cache.this[each.key]
  id = each.value
}
