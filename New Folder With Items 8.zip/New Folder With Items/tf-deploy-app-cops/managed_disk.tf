resource "azurerm_managed_disk" "this" {
  for_each = var.enable_managed_disk ? var.managed_disk : {}

  name                          = each.value.name
  resource_group_name           = module.resource_group[each.value.resource_group_key].name
  location                      = coalesce(each.value.location, module.resource_group[each.value.resource_group_key].location)
  storage_account_type          = each.value.storage_account_type
  create_option                 = each.value.create_option
  disk_size_gb                  = each.value.disk_size_gb
  zone                          = each.value.zone
  network_access_policy         = each.value.network_access_policy
  disk_access_id                = each.value.disk_access_id
  public_network_access_enabled = each.value.public_network_access_enabled
  tags                          = each.value.tags

  lifecycle {
    prevent_destroy = true
  }
}

import {
  for_each = var.enable_managed_disk ? var.managed_disk_imports : {}

  to = azurerm_managed_disk.this[each.key]
  id = each.value
}
