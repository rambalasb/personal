terraform {
  required_version = ">= 1.9, < 2.0"

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 4.67.0, < 5.0.0"
    }
    azapi = {
      source  = "Azure/azapi"
      version = ">= 2.0, < 3.0"
    }
    azuread = {
      source  = "hashicorp/azuread"
      version = ">= 2.50, < 4.0"
    }
  }
}

provider "azurerm" {
  subscription_id = var.subscription_id
  features {}
}

provider "azapi" {
  subscription_id = var.subscription_id
}

provider "azuread" {}

# Connectivity subscription: the shared private DNS zones this app's VNet links
# and records live in (private_dns_zone_links.tf, custom-recordset.tf).
provider "azurerm" {
  alias           = "dns"
  subscription_id = var.hub_dns_subscription_id
  features {}
}
