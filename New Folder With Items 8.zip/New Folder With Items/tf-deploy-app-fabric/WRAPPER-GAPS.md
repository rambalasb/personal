# Wrapper gaps: `tf-deploy-fabric`

Resources in the Fabric subscriptions that this repo does not manage. Counts
are from the Azure resource exports of 2026-10-19 (nonprod) and 2026-10-20
(prod).

## Staged

Code and tfvars are complete; each is switched off and adopted in its own
run. See "Staged adoption" in the README.

| Resource | Environment | Reason |
|---|---|---|
| 2 Windows VMs (+ NICs) | prod | Needs the admin passwords; adopted alone |
| `vnet-fabric-*-canadacentral-001` (+ subnets) | both | vWAN hub connection owned by the connectivity repo |

## Not managed

| Type | Nonprod | Prod | Reason |
|---|---:|---:|---|
| `microsoft.compute/disks` | 1 | 2 | OS disks belong to their VM |
| `microsoft.compute/virtualmachines/extensions` | 4 | 4 | VM wrapper is called with `extensions = {}` |
| `microsoft.network/networkinterfaces` | 4 | 6 | Private endpoint NICs belong to their endpoint |
| `microsoft.recoveryservices/vaults` | 0 | 1 | No backup vault tier in this repo |
| `microsoft.network/privateendpoints` | 0 | 1 | `pep-rsv-fabric-prod-backup-*`: its connection name is 81 characters; AzureRM allows 80 (`enabled = false`) |
| `microsoft.network/networkwatchers/flowlogs` | 0 | 1 | No wrapper |
| Role assignments | all | all | Deferred until the resource imports have a clean plan |
