# Every exported disk is a VM OS disk, owned inline by its VM. Drops any
# standalone disk from state without deleting it in Azure.
removed {
  from = module.managed_disk

  lifecycle {
    destroy = false
  }
}
