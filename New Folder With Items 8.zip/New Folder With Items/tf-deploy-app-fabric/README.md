# tf-deploy-fabric

Terraform that adopts the existing **Fabric** resources into state, using the
same layout as the PTA, FIT and COPS deploy repos.

| Environment | Subscription | ID |
|---|---|---|
| `nonprod` | Sub-Fabric-NonProd | `cd096fc9-e946-4547-8b46-eb23b6024332` |
| `prod` | Sub-Fabric-Prod | `e299ec5b-9b38-4d00-9c9a-9257a48b6ecc` |

Use Terraform `>= 1.9, < 2.0`, one state per environment, and select
`envs/nonprod.tfvars` or `envs/prod.tfvars`. Adopt nonprod first; prod follows
the same runs and stages.

## Status

**Nonprod** has had a real import-verify run (2026-10-20): 22 imports,
0 destroys, and every change was a tag update except two (see
[Things to check](#things-to-check-before-the-first-import)). The VNet is
filled in but switched off and is adopted last (see
[Staged adoption](#staged-adoption)).

**Prod** is filled in the same way. The two Windows VMs (and their NICs) and
the VNet are switched off and adopted in their own runs. Prod has no bastion,
NAT gateway or public IP prefix.

## Tiers

| File | Implementation | Nonprod | Prod |
|---|---|---|---|
| `resource_group.tf` | `tf-wrapper-avm-resource-group` 2.0.0 | 4 | 6 |
| `alerts.tf` | `tf-wrapper-avm-ptn-monitoring-amba-alz` 0.3.3 | 1 activity log alert | 1 activity log alert |
| `bastion_host.tf` | `tf-wrapper-avm-bastion-host` 0.0.1 | 1 Developer | - |
| `data_factory.tf` | `tf-wrapper-avm-data-factory` 0.1.0 | 1 | 1 |
| `event_grid_system_topic.tf` | `azurerm_eventgrid_system_topic` | off | 1 |
| `fabric_capacity.tf` | `tf-wrapper-avm-fabric-capacity` 0.0.1 | 1 | 2 |
| `key_vault.tf` | `tf-wrapper-avm-key-vault` 0.4.0 | 1 | 1 |
| `nat_gateway.tf` | `tf-wrapper-avm-nat-gateway` 0.1.0 | 1 | - |
| `network_interface.tf` | NSG association; VM NICs import through the VM | 1 association | off (with the VMs) |
| `network_security_group.tf` | `tf-wrapper-avm-network-security-group` 0.1.1 | 1 + 1 rule | 2 |
| `network_watcher.tf` | `azurerm_network_watcher` | 1 | 1 |
| `private_endpoint.tf` | `tf-wrapper-avm-private-endpoint` 0.1.2 | 4 | 6 |
| `public_ip_prefix.tf` | `tf-wrapper-avm-public-ip-prefix` 0.1.1 | 1 | - |
| `restore_point_collection.tf` | `azurerm_virtual_machine_restore_point_collection` | off | 2 |
| `storage_account.tf` | `azurerm_storage_account` | 1 | 2 |
| `windows_virtual_machine.tf` | `tf-wrapper-avm-virtual-machine-windows` 0.1.6 | 1 | 2, off (separate run) |
| `virtual_network.tf` | `tf-wrapper-avm-virtual-network` 0.1.0 | 1 + 3 subnets, off | 1 + 2 subnets, off |
| `role_assignment.tf` | `tf-wrapper-avm-role-assignment` 0.3.6 | all off | all off |
| `managed_disk.tf` | `removed` block only | - | - |

No Fabric storage account has public network access enabled. If one does,
read it with a data source instead of managing it:
`Deny_Public_Access_On_PaaS_Services_v0` denies any write to it, adoption
included (see `storage_account_existing` in tf-deploy-app-pta).

What stays unmanaged is in [WRAPPER-GAPS.md](WRAPPER-GAPS.md).

## Things to check before the first import

From the nonprod import-verify run of 2026-10-20:

- **Windows VM:** the import planned only a tag update, so `admin_password`
  did not force a replace with wrapper 0.1.6. VM passwords still come from
  the sensitive variable `windows_virtual_machine_admin_passwords`.
- **Fabric capacity:** the gate flags `body` because upstream AVM sorts
  `administration_members`, while Azure keeps them in insertion order. The
  members are the same. Allow-listed for nonprod in `scripts/import_gate.sh`;
  the diff clears after the first apply.
- **NAT gateway:** for `StandardV2` upstream AVM hard-codes zones `1-3` (and
  empty public IP lists), which the live gateway does not report, so the gate
  flags `body`. A wrapper input cannot change this. Confirm with the network
  team that Azure accepts it as a no-op before allow-listing it in
  `scripts/import_gate.sh`.
- Every other change in that run was a tag update (wrapper `managed-by` /
  `module` tags), which the gate tolerates.

Prod:

- The backup private endpoint's connection name,
  `pep-rsv-fabric-prod-backup-canadacentral-001_2079140f-2f80-49cb-a408-80305c88f0fc`,
  is 81 characters; AzureRM allows 80, so that endpoint has `enabled = false`
  and stays unmanaged.
- The backup vault has no tier in this repo and is not managed.

## Adoption

Every resource here already exists in Azure. Each tier has `enable_<type>`
and an import map; imports only run while the tier is enabled, and
validations check every import ID against the key, name, resource group and
`subscription_id`.

Before the first apply:

- Make sure auto-apply is off on the HCP workspace, so every apply is
  confirmed by hand after reading the plan.
- Optionally put a `CanNotDelete` lock on the app resource groups for the
  adoption window, so an unexpected replace fails instead of destroying the
  resource. Do not lock the Azure Backup resource group.

Each run, first or staged:

1. Run `.github/workflows/import-verify.yml` for the environment. It only
   plans, then runs `scripts/import_gate.sh`, which wraps
   `scripts/verify_zero_diff.sh`: it fails on anything other than imports and
   tag updates and reports any replace separately.
2. Fix diffs by correcting tfvars, never by changing Azure. Repeat until the
   gate passes. Never accept a replace or delete with `--allow-resource`.
   Accepted addresses go in `scripts/import_gate.sh`.
3. Run `.github/workflows/import-apply.yml` for the environment, with
   `confirm` set to `apply`. Read the check job's summary (gate output and
   plan: only imports and tag updates), then approve the apply job. It
   re-plans, re-runs the gate and refuses to apply if the change set moved
   since the check. Do not use `landing-zone-multi-env.yml` while imports
   are pending; it applies with `-auto-approve` and no gate.
4. Empty the import maps of the tiers that applied.

## Staged adoption

| Stage | Flags | Why it is held back |
|---|---|---|
| 1. Prod Windows VMs | `enable_windows_virtual_machine`, `enable_network_interface` | Needs the admin passwords; adopted alone so any replace is obvious |
| 2. Virtual network | `enable_virtual_network` | The vWAN hub connection is owned by the connectivity repo |

### Stage 1: Prod Windows VMs

1. Set `windows_virtual_machine_admin_passwords` as a **sensitive** HCP
   variable, keyed like `windows_virtual_machine` in `envs/prod.tfvars`. Use
   the real passwords.
2. Set `enable_windows_virtual_machine = true` and
   `enable_network_interface = true`, run import-verify, and expect two VM
   imports plus their NICs and NSG associations. Any replace means stop.
3. Apply and empty the VM import map.

### Stage 2: Virtual network

The VNet module sends a body without subnets or peerings, so the import plan
shows both being removed, and the VNet's only peering is the vWAN hub
connection declared in `tf-deploy-platform-connectivity`. Adopt it after the
connectivity repo has those hub connections in state, in a window with the
connectivity team.

1. Set `enable_virtual_network = true` and run import-verify. Expected: one
   VNet import and one import per subnet, no subnet replace.
2. Apply, check the hub connection, then empty the VNet and subnet import
   maps.

## Role assignments

`role_assignment.tf` uses one typed map: resource type, parent key, then
assignment key. Every `enable_<type>_role_assignment` is false and
`role_assignments = {}` in both environments, and stays that way until the
resource imports have a clean plan. Nothing is inferred from the export, and
existing assignments need their own imports.

## Pipeline

| Workflow | Purpose |
|---|---|
| `import-verify.yml` | Plan and gate. Never applies. Run this first |
| `import-apply.yml` | Gate, approval on the `<env>` environment, re-gate, apply |
| `landing-zone-multi-env.yml` | Deploy pipeline, `workflow_dispatch` only |
| `tflint.yml` | HCL lint on push and PR |
| `trivy.yml` | IaC scan on PR and weekly |

`import-apply.yml` needs required reviewers on the `nonprod` and `prod`
GitHub Environments, or the apply job runs without stopping. Its check job
runs outside any environment, so `TF_API_TOKEN`, `TF_CLOUD_ORGANIZATION`
and `TFC_WORKSPACE_PREFIX` must be set at repo or org level.

The HCP workspace prefix is `az-fabric` (workspaces `az-fabric-nonprod` and
`az-fabric-prod`).
