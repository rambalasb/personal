#!/usr/bin/env bash
# The import zero-diff gate, shared by import-verify.yml and import-apply.yml so
# the plan that gets applied passes exactly the check that was reviewed.
#
# Usage: import_gate.sh <env> <plan.json>
set -eo pipefail
ENV_NAME="${1:?usage: import_gate.sh <env> <plan.json>}"
PLAN="${2:?usage: import_gate.sh <env> <plan.json>}"
HERE="$(cd "$(dirname "$0")" && pwd)"

# Reviewed deltas the modules cannot express. Never add a replace or delete.
ALLOW=()
case "$ENV_NAME" in
  nonprod)
    # Upstream AVM sorts the admins; Azure keeps insertion order. Same members.
    ALLOW+=(--allow-resource 'module.fabric_capacity["fabric_nonprod"].module.fabric_capacity.azapi_resource.this')
    ;;
esac

bash "$HERE/verify_zero_diff.sh" "$PLAN" \
  --ignore-attr response_export_values \
  --ignore-attr retry \
  --ignore-attr timeouts \
  --ignore-attr ignore_null_property \
  --ignore-attr ignore_casing \
  --ignore-attr ignore_missing_property \
  --ignore-attr schema_validation_enabled \
  --subset-attr body \
  --ignore-type time_sleep \
  --ignore-type random_uuid \
  --ignore-type modtm_telemetry \
  "${ALLOW[@]}"
