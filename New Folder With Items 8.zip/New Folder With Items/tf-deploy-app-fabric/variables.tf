variable "subscription_id" {
  type        = string
  description = "Azure subscription this environment adopts resources into."

  validation {
    condition     = can(regex("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$", var.subscription_id))
    error_message = "subscription_id must be an Azure subscription UUID."
  }
}

variable "enable_resource_group" {
  type        = bool
  description = "Whether Terraform manages and imports the existing resource groups."
  default     = false
}

variable "resource_group" {
  type = map(object({
    name     = string
    location = string
    lock = optional(object({
      kind = string
      name = optional(string)
    }))
    managed_by = optional(string)
    tags       = optional(map(string), {})
  }))
  description = "Existing resource groups to adopt, keyed by stable instance roles."
  default     = {}
}

variable "import_resource_group" {
  type        = map(string)
  description = "Existing resource group IDs, keyed by the matching resource_group instance."
  default     = {}

  validation {
    condition = alltrue([
      for group_key, resource_id in var.import_resource_group :
      resource_id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[group_key].name, "")}"
    ])
    error_message = "Each import_resource_group entry must match its resource_group key, name and subscription_id."
  }
}

variable "enable_fabric_capacity" {
  type        = bool
  description = "Whether Terraform manages and imports the existing Fabric capacities."
  default     = false
}

variable "fabric_capacity" {
  type = map(object({
    name                   = string
    resource_group_key     = string
    location               = optional(string)
    sku_name               = string
    administration_members = set(string)
    tags                   = optional(map(string), {})
  }))
  description = "Existing Fabric capacity inventory with exact administrator identities, SKU and tags."
  default     = {}

  validation {
    condition = alltrue([
      for capacity in values(var.fabric_capacity) :
      contains(keys(var.resource_group), capacity.resource_group_key) && (!var.enable_fabric_capacity || var.enable_resource_group)
    ])
    error_message = "Each Fabric capacity must reference a managed resource group, enabled when capacity adoption is enabled."
  }

  validation {
    condition = alltrue([
      for capacity in values(var.fabric_capacity) :
      can(regex("^[a-z][a-z0-9]{2,62}$", capacity.name)) && length(capacity.administration_members) > 0 &&
      alltrue([for member in capacity.administration_members : trimspace(member) != ""])
    ])
    error_message = "Fabric capacity names must be 3-63 lowercase letters/numbers starting with a letter, and administrator identities must be non-empty."
  }
}

variable "fabric_capacity_imports" {
  type        = map(string)
  description = "Existing Fabric capacity IDs keyed by fabric_capacity; verify the pinned nested AzAPI address."
  default     = {}

  validation {
    condition = alltrue([
      for capacity_key, resource_id in var.fabric_capacity_imports :
      resource_id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[var.fabric_capacity[capacity_key].resource_group_key].name, "")}/providers/Microsoft.Fabric/capacities/${try(var.fabric_capacity[capacity_key].name, "")}"
    ])
    error_message = "Each fabric_capacity_imports entry must match its capacity key, name, resource group and subscription_id."
  }
}

variable "enable_data_factory" {
  type        = bool
  description = "Whether Terraform manages and imports the existing Data Factory parents."
  default     = false
}

variable "data_factory" {
  type = map(object({
    name                            = string
    resource_group_key              = string
    location                        = optional(string)
    public_network_enabled          = bool
    managed_virtual_network_enabled = optional(bool, false)
    managed_identities = object({
      system_assigned            = bool
      user_assigned_resource_ids = optional(set(string), [])
    })
    tags = optional(map(string), {})
  }))
  description = "Data Factory parent inventory; managed-VNet defaults require independent live verification."
  default     = {}

  validation {
    condition = alltrue([
      for factory in values(var.data_factory) :
      contains(keys(var.resource_group), factory.resource_group_key) && (!var.enable_data_factory || var.enable_resource_group)
    ])
    error_message = "Each Data Factory must reference a managed resource group, enabled when factory adoption is enabled."
  }
}

variable "data_factory_imports" {
  type        = map(string)
  description = "Existing Data Factory IDs keyed by data_factory; verify the pinned wrapper's nested resource address."
  default     = {}

  validation {
    condition = alltrue([
      for factory_key, resource_id in var.data_factory_imports :
      resource_id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[var.data_factory[factory_key].resource_group_key].name, "")}/providers/Microsoft.DataFactory/factories/${try(var.data_factory[factory_key].name, "")}"
    ])
    error_message = "Each data_factory_imports entry must match its factory key, name, resource group and subscription_id."
  }
}

variable "enable_monitoring" {
  type        = bool
  description = "Whether Terraform manages and imports the existing monitoring alerts."
  default     = false
}

variable "alert" {
  type = object({
    resource_group_key         = string
    root_management_group_name = optional(string)
    tags                       = optional(map(string), {})
    activity_log_alerts = optional(map(object({
      name                = string
      resource_group_name = string
      scopes              = list(string)
      location            = optional(string, "global")
      description         = optional(string)
      enabled             = optional(bool, true)
      criteria = object({
        category                = string
        operation_name          = optional(string)
        resource_provider       = optional(string)
        resource_type           = optional(string)
        resource_group          = optional(string)
        resource_id             = optional(string)
        caller                  = optional(string)
        level                   = optional(string)
        status                  = optional(string)
        sub_status              = optional(string)
        recommendation_category = optional(string)
        recommendation_impact   = optional(string)
        recommendation_type     = optional(string)
        service_health = optional(object({
          events    = optional(list(string))
          locations = optional(list(string))
          services  = optional(list(string))
        }))
        resource_health = optional(object({
          current  = optional(list(string))
          previous = optional(list(string))
          reason   = optional(list(string))
        }))
      })
      action_group_keys  = optional(list(string), [])
      action_group_ids   = optional(list(string), [])
      webhook_properties = optional(map(string), {})
      tags               = optional(map(string), {})
    })), {})
  })
  description = "Existing activity log alerts passed to the same monitoring wrapper as Auritas."
  default = {
    resource_group_key = "app"
  }

  validation {
    condition     = !var.enable_monitoring || (var.enable_resource_group && contains(keys(var.resource_group), var.alert.resource_group_key))
    error_message = "Monitoring requires enabled resource groups and a valid alert.resource_group_key."
  }
}

variable "activity_log_alert_imports" {
  type        = map(string)
  description = "Existing activity log alert IDs, keyed by the matching alert.activity_log_alerts instance."
  default     = {}

  validation {
    condition = alltrue([
      for alert_key, resource_id in var.activity_log_alert_imports :
      resource_id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.alert.activity_log_alerts[alert_key].resource_group_name, "")}/providers/Microsoft.Insights/activityLogAlerts/${try(var.alert.activity_log_alerts[alert_key].name, "")}"
    ])
    error_message = "Each activity_log_alert_imports entry must match its alert key, name, resource group and subscription_id."
  }
}

variable "enable_bastion_host" {
  type        = bool
  description = "Whether Terraform manages and imports the existing Developer Bastion Hosts."
  default     = false
}

variable "bastion_host" {
  type = map(object({
    name               = string
    resource_group_key = string
    location           = optional(string)
    sku                = optional(string, "Developer")
    scale_units        = optional(number, 2)
    virtual_network_id = string
    zones              = optional(set(string), [])
    tags               = optional(map(string), {})
  }))
  description = "Existing Developer Bastion Hosts to adopt, keyed by stable instance identifiers."
  default     = {}

  validation {
    condition = alltrue([
      for bastion in values(var.bastion_host) :
      contains(keys(var.resource_group), bastion.resource_group_key) && (!var.enable_bastion_host || var.enable_resource_group)
    ])
    error_message = "Each Bastion Host must reference a managed resource group, enabled when Bastion adoption is enabled."
  }

  validation {
    condition     = alltrue([for bastion in values(var.bastion_host) : bastion.sku == "Developer" && length(bastion.zones) == 0])
    error_message = "The Developer Bastion import target requires Developer SKU, virtual_network_id and no availability zones."
  }
}

variable "bastion_host_imports" {
  type        = map(string)
  description = "Existing Developer Bastion IDs, keyed by the matching bastion_host instance."
  default     = {}

  validation {
    condition = alltrue([
      for bastion_key, resource_id in var.bastion_host_imports :
      resource_id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[var.bastion_host[bastion_key].resource_group_key].name, "")}/providers/Microsoft.Network/bastionHosts/${try(var.bastion_host[bastion_key].name, "")}"
    ])
    error_message = "Each bastion_host_imports entry must match its Bastion key, name, resource group and subscription_id."
  }
}

variable "enable_key_vault" {
  type        = bool
  description = "Whether Terraform manages and imports the existing Key Vaults."
  default     = false
}

variable "key_vault" {
  type = map(object({
    name                            = string
    resource_group_key              = string
    location                        = optional(string)
    tenant_id                       = string
    sku_name                        = optional(string, "premium")
    enabled_for_deployment          = optional(bool, false)
    enabled_for_disk_encryption     = optional(bool, false)
    enabled_for_template_deployment = optional(bool, false)
    legacy_access_policies_enabled  = optional(bool, false)
    public_network_access_enabled   = optional(bool, true)
    purge_protection_enabled        = optional(bool, true)
    soft_delete_retention_days      = optional(number, 90)
    network_acls = optional(object({
      bypass                     = optional(string, "None")
      default_action             = optional(string, "Deny")
      ip_rules                   = optional(list(string), [])
      virtual_network_subnet_ids = optional(set(string), [])
    }), {})
    tags = optional(map(string), {})
  }))
  description = "Existing vault-level configuration to adopt without keys, secrets or child resources."
  default     = {}

  validation {
    condition = alltrue([
      for vault in values(var.key_vault) :
      contains(keys(var.resource_group), vault.resource_group_key) && (!var.enable_key_vault || var.enable_resource_group)
    ])
    error_message = "Each Key Vault must reference a managed resource group, enabled when vault adoption is enabled."
  }

  validation {
    condition     = alltrue([for vault in values(var.key_vault) : !vault.legacy_access_policies_enabled])
    error_message = "This vault-only adoption configuration requires RBAC; legacy policy adoption is not configured."
  }

  validation {
    condition     = alltrue([for vault in values(var.key_vault) : vault.soft_delete_retention_days >= 7 && vault.soft_delete_retention_days <= 90])
    error_message = "Key Vault soft-delete retention must be between 7 and 90 days."
  }
}

variable "key_vault_imports" {
  type        = map(string)
  description = "Existing Key Vault IDs, keyed by the matching key_vault instance."
  default     = {}

  validation {
    condition = alltrue([
      for vault_key, resource_id in var.key_vault_imports :
      resource_id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[var.key_vault[vault_key].resource_group_key].name, "")}/providers/Microsoft.KeyVault/vaults/${try(var.key_vault[vault_key].name, "")}"
    ])
    error_message = "Each key_vault_imports entry must match its vault key, name, resource group and subscription_id."
  }
}

variable "enable_nat_gateway" {
  type        = bool
  description = "Whether Terraform manages and imports the existing NAT Gateways."
  default     = false
}

variable "nat_gateway" {
  type = map(object({
    name                          = string
    resource_group_key            = string
    location                      = optional(string)
    sku_name                      = optional(string, "StandardV2")
    idle_timeout_in_minutes       = optional(number, 4)
    public_ip_prefix_resource_ids = optional(set(string), [])
    zones                         = optional(set(string))
    tags                          = optional(map(string), {})
  }))
  description = "Existing NAT Gateways and their prefix associations to adopt through the Auritas wrapper pattern."
  default     = {}

  validation {
    condition = alltrue([
      for gateway in values(var.nat_gateway) :
      contains(keys(var.resource_group), gateway.resource_group_key) && (!var.enable_nat_gateway || var.enable_resource_group)
    ])
    error_message = "Each NAT Gateway must reference a managed resource group, enabled when gateway adoption is enabled."
  }
}

variable "nat_gateway_imports" {
  type        = map(string)
  description = "Existing NAT Gateway IDs, keyed by the matching nat_gateway instance. The import adds the AzAPI version."
  default     = {}

  validation {
    condition = alltrue([
      for gateway_key, resource_id in var.nat_gateway_imports :
      resource_id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[var.nat_gateway[gateway_key].resource_group_key].name, "")}/providers/Microsoft.Network/natGateways/${try(var.nat_gateway[gateway_key].name, "")}"
    ])
    error_message = "Each nat_gateway_imports entry must match its gateway key, name, resource group and subscription_id."
  }
}

variable "enable_network_interface" {
  type        = bool
  description = "Enable staged standalone NIC and NSG-association imports only after ownership and wrapper behavior are confirmed."
  default     = false
}

variable "network_interface" {
  type = map(object({
    name               = string
    resource_group_key = string
    location           = optional(string)
    enabled            = optional(bool, false)
    ip_configurations = map(object({
      name                          = string
      subnet_id                     = string
      private_ip_address_version    = optional(string, "IPv4")
      private_ip_address_allocation = optional(string, "Dynamic")
      private_ip_address            = optional(string)
      primary                       = optional(bool)
      public_ip_address_id          = optional(string)
    }))
    accelerated_networking_enabled = optional(bool, false)
    ip_forwarding_enabled          = optional(bool, false)
    tags                           = optional(map(string), {})
  }))
  description = "Staged NIC inventory using Auritas's wrapper inputs. Keep private-endpoint NICs individually disabled."
  default     = {}

  validation {
    condition = alltrue([
      for nic in values(var.network_interface) :
      contains(keys(var.resource_group), nic.resource_group_key) && (!var.enable_network_interface || !nic.enabled || var.enable_resource_group)
    ])
    error_message = "Each NIC must reference a managed resource group, enabled when that NIC is managed."
  }
}

variable "network_interface_nsg_associations" {
  type        = map(string)
  description = "Existing NSG IDs keyed by NIC; association imports use the NIC resource ID and share its enable flags."
  default     = {}

  validation {
    condition     = alltrue([for nic_key in keys(var.network_interface_nsg_associations) : contains(keys(var.network_interface), nic_key)])
    error_message = "Each NSG association must identify an existing network_interface key."
  }
}

variable "enable_network_security_group" {
  type        = bool
  description = "Whether Terraform manages and imports the existing NSGs and their custom rules."
  default     = false
}

variable "network_security_group" {
  type = map(object({
    name               = string
    resource_group_key = string
    location           = optional(string)
    security_rules = optional(map(object({
      name                       = string
      access                     = string
      direction                  = string
      priority                   = number
      protocol                   = string
      description                = optional(string)
      source_port_range          = optional(string)
      destination_port_range     = optional(string)
      source_address_prefix      = optional(string)
      destination_address_prefix = optional(string)
    })), {})
    tags = optional(map(string), {})
  }))
  description = "Existing NSGs and custom rules to adopt with COPS's wrapper pattern, without extra tags or RBAC."
  default     = {}

  validation {
    condition = alltrue([
      for nsg in values(var.network_security_group) :
      contains(keys(var.resource_group), nsg.resource_group_key) && (!var.enable_network_security_group || var.enable_resource_group)
    ])
    error_message = "Each NSG must reference a managed resource group, enabled when NSG adoption is enabled."
  }
}

variable "import_network_security_group" {
  type        = map(string)
  description = "Existing NSG IDs, keyed by network_security_group, following COPS's import-map naming."
  default     = {}

  validation {
    condition = alltrue([
      for nsg_key, resource_id in var.import_network_security_group :
      resource_id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[var.network_security_group[nsg_key].resource_group_key].name, "")}/providers/Microsoft.Network/networkSecurityGroups/${try(var.network_security_group[nsg_key].name, "")}"
    ])
    error_message = "Each import_network_security_group entry must match its NSG key, name, resource group and subscription_id."
  }
}

variable "network_security_rule_imports" {
  type = map(object({
    nsg_key  = string
    rule_key = string
    id       = string
  }))
  description = "Existing custom rule IDs and their wrapper map keys; verify the pinned nested rule resource address."
  default     = {}

  validation {
    condition = alltrue([
      for rule in values(var.network_security_rule_imports) :
      rule.id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[var.network_security_group[rule.nsg_key].resource_group_key].name, "")}/providers/Microsoft.Network/networkSecurityGroups/${try(var.network_security_group[rule.nsg_key].name, "")}/securityRules/${try(var.network_security_group[rule.nsg_key].security_rules[rule.rule_key].name, "")}"
    ])
    error_message = "Each rule import must match its NSG key, rule key, exported rule name, resource group and subscription_id."
  }
}

variable "enable_restore_point_collection" {
  type        = bool
  description = "Whether Terraform manages and imports existing VM restore-point collections directly with AzureRM."
  default     = false
}

variable "restore_point_collection" {
  type = map(object({
    name                      = string
    resource_group_key        = string
    location                  = optional(string)
    source_virtual_machine_id = string
    tags                      = map(string)
  }))
  description = "Existing restore-point collection containers. Source VMs are references only; individual restore points and backup policies are not managed here."
  default     = {}

  validation {
    condition = alltrue([
      for collection in values(var.restore_point_collection) :
      contains(keys(var.resource_group), collection.resource_group_key) && (!var.enable_restore_point_collection || var.enable_resource_group)
    ])
    error_message = "Each restore-point collection must reference a managed resource group, enabled when collection adoption is enabled."
  }

  validation {
    condition = alltrue([
      for collection in values(var.restore_point_collection) :
      can(regex("^/subscriptions/${var.subscription_id}/resourceGroups/[^/]+/providers/Microsoft.Compute/virtualMachines/[^/]+$", collection.source_virtual_machine_id))
    ])
    error_message = "Each source_virtual_machine_id must identify a VM in the configured subscription."
  }
}

variable "restore_point_collection_imports" {
  type        = map(string)
  description = "Existing bare restore-point collection ARM IDs, keyed by restore_point_collection key. Backup resource-group spelling remains lowercase as exported."
  default     = {}

  validation {
    condition = alltrue([
      for key, id in var.restore_point_collection_imports : try(
        id == "/subscriptions/${var.subscription_id}/resourceGroups/${lower(var.resource_group[var.restore_point_collection[key].resource_group_key].name)}/providers/Microsoft.Compute/restorePointCollections/${var.restore_point_collection[key].name}",
        false
      )
    ])
    error_message = "Each restore-point collection import key and ID must match its name, lowercase resource group, and subscription."
  }

  validation {
    condition     = !var.enable_restore_point_collection || toset(keys(var.restore_point_collection_imports)) == toset(keys(var.restore_point_collection))
    error_message = "Enabled restore-point collection adoption requires exactly one import ID for every configured collection."
  }
}

variable "enable_network_watcher" {
  type        = bool
  description = "Whether Terraform manages and imports the existing Network Watchers."
  default     = false
}

variable "network_watcher" {
  type = map(object({
    name               = string
    resource_group_key = string
    location           = optional(string)
    tags               = optional(map(string), {})
  }))
  description = "Existing Network Watchers to adopt directly with AzureRM."
  default     = {}

  validation {
    condition = alltrue([
      for watcher in values(var.network_watcher) :
      contains(keys(var.resource_group), watcher.resource_group_key) && (!var.enable_network_watcher || var.enable_resource_group)
    ])
    error_message = "Each Network Watcher must reference a managed resource group, enabled when watcher adoption is enabled."
  }
}

variable "network_watcher_imports" {
  type        = map(string)
  description = "Existing Network Watcher IDs, keyed by the matching network_watcher instance."
  default     = {}

  validation {
    condition = alltrue([
      for watcher_key, resource_id in var.network_watcher_imports :
      resource_id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[var.network_watcher[watcher_key].resource_group_key].name, "")}/providers/Microsoft.Network/networkWatchers/${try(var.network_watcher[watcher_key].name, "")}"
    ])
    error_message = "Each network_watcher_imports entry must match its watcher key, name, resource group and subscription_id."
  }
}

variable "enable_private_endpoint" {
  type        = bool
  description = "Whether Terraform manages and imports the existing private endpoints."
  default     = false
}

variable "private_endpoint" {
  type = map(object({
    enabled                         = optional(bool, true)
    name                            = string
    resource_group_key              = string
    location                        = optional(string)
    subnet_resource_id              = string
    private_connection_resource_id  = string
    private_service_connection_name = optional(string)
    subresource_names               = optional(list(string))
    network_interface_name          = optional(string)
    private_dns_zone_group_name     = optional(string)
    private_dns_zone_resource_ids   = optional(list(string), [])
    ip_configurations = optional(map(object({
      name               = string
      private_ip_address = string
      subresource_name   = string
      member_name        = optional(string, "default")
    })), {})
    tags = optional(map(string), {})
  }))
  description = "Existing private endpoints to adopt through Auritas's wrapper, owning their generated NICs."
  default     = {}

  validation {
    condition = alltrue([
      for endpoint in values(var.private_endpoint) :
      contains(keys(var.resource_group), endpoint.resource_group_key) && (!var.enable_private_endpoint || !endpoint.enabled || var.enable_resource_group)
    ])
    error_message = "Each endpoint must reference a managed resource group, enabled when that endpoint is managed."
  }
}

variable "private_endpoint_imports" {
  type        = map(string)
  description = "Existing endpoint IDs, keyed by private_endpoint and filtered by global/per-entry enable flags."
  default     = {}

  validation {
    condition = alltrue([
      for endpoint_key, resource_id in var.private_endpoint_imports :
      resource_id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[var.private_endpoint[endpoint_key].resource_group_key].name, "")}/providers/Microsoft.Network/privateEndpoints/${try(var.private_endpoint[endpoint_key].name, "")}"
    ])
    error_message = "Each private_endpoint_imports entry must match its endpoint key, name, resource group and subscription_id."
  }
}

variable "enable_public_ip_prefix" {
  type        = bool
  description = "Whether Terraform manages and imports the existing public IP prefixes."
  default     = false
}

variable "public_ip_prefix" {
  type = map(object({
    name               = string
    resource_group_key = string
    location           = optional(string)
    prefix_length      = number
    ip_version         = optional(string, "IPv4")
    sku_name           = optional(string, "Standard")
    sku_tier           = optional(string, "Regional")
    zones              = optional(set(string))
    tags               = optional(map(string), {})
  }))
  description = "Existing public IP prefixes to adopt through Auritas's wrapper, without inferred zones."
  default     = {}

  validation {
    condition = alltrue([
      for prefix in values(var.public_ip_prefix) :
      contains(keys(var.resource_group), prefix.resource_group_key) && (!var.enable_public_ip_prefix || var.enable_resource_group)
    ])
    error_message = "Each public IP prefix must reference a managed resource group, enabled when prefix adoption is enabled."
  }
}

variable "public_ip_prefix_imports" {
  type        = map(string)
  description = "Existing public IP prefix IDs, keyed by the matching public_ip_prefix instance."
  default     = {}

  validation {
    condition = alltrue([
      for prefix_key, resource_id in var.public_ip_prefix_imports :
      resource_id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[var.public_ip_prefix[prefix_key].resource_group_key].name, "")}/providers/Microsoft.Network/publicIPPrefixes/${try(var.public_ip_prefix[prefix_key].name, "")}"
    ])
    error_message = "Each public_ip_prefix_imports entry must match its prefix key, name, resource group and subscription_id."
  }
}

variable "enable_storage_account" {
  type        = bool
  description = "Whether Terraform manages and imports the existing storage accounts."
  default     = false
}

variable "storage_account" {
  type = map(object({
    name                            = string
    resource_group_key              = string
    location                        = optional(string)
    account_tier                    = string
    account_replication_type        = string
    access_tier                     = string
    allow_nested_items_to_be_public = bool
    default_to_oauth_authentication = bool
    is_hns_enabled                  = bool
    public_network_access_enabled   = bool
    shared_access_key_enabled       = optional(bool, true)
    blob_properties = object({
      container_delete_retention_policy = object({ days = optional(number) })
      delete_retention_policy           = object({ days = optional(number) })
    })
    network_rules = object({
      bypass                     = set(string)
      default_action             = string
      ip_rules                   = optional(set(string), [])
      virtual_network_subnet_ids = optional(set(string), [])
      private_link_access = optional(list(object({
        endpoint_resource_id = string
        endpoint_tenant_id   = optional(string)
      })), [])
    })
    share_properties = object({
      retention_policy = optional(object({ days = optional(number) }))
    })
    tags = optional(map(string), {})
  }))
  description = "Existing storage accounts to adopt directly with AzureRM, preserving exported service properties and network rules."
  default     = {}

  validation {
    condition = alltrue([
      for account in values(var.storage_account) :
      contains(keys(var.resource_group), account.resource_group_key) && (!var.enable_storage_account || var.enable_resource_group)
    ])
    error_message = "Each storage account must reference a managed resource group, enabled when account adoption is enabled."
  }
}

variable "storage_account_imports" {
  type        = map(string)
  description = "Existing storage account IDs, keyed by the matching storage_account instance."
  default     = {}

  validation {
    condition = alltrue([
      for account_key, resource_id in var.storage_account_imports :
      resource_id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[var.storage_account[account_key].resource_group_key].name, "")}/providers/Microsoft.Storage/storageAccounts/${try(var.storage_account[account_key].name, "")}"
    ])
    error_message = "Each storage_account_imports entry must match its account key, name, resource group and subscription_id."
  }
}

variable "enable_windows_virtual_machine" {
  type        = bool
  description = "Whether Terraform manages and imports the staged Windows VMs, after credential and OS disk ownership checks."
  default     = false
}

variable "windows_virtual_machine" {
  type = map(object({
    name                                                   = string
    resource_group_key                                     = string
    location                                               = optional(string)
    size                                                   = string
    zone                                                   = string
    admin_username                                         = string
    computer_name                                          = string
    network_interface_ids                                  = list(string)
    os_managed_disk_id                                     = string
    allow_extension_operations                             = bool
    automatic_updates_enabled                              = bool
    bypass_platform_safety_checks_on_user_schedule_enabled = bool
    disk_controller_type                                   = string
    encryption_at_host_enabled                             = optional(bool)
    license_type                                           = string
    patch_assessment_mode                                  = string
    patch_mode                                             = string
    provision_vm_agent                                     = bool
    secure_boot_enabled                                    = bool
    vm_agent_platform_updates_enabled                      = bool
    vtpm_enabled                                           = bool
    additional_capabilities = optional(object({
      ultra_ssd_enabled   = optional(bool)
      hibernation_enabled = optional(bool)
    }), {})
    boot_diagnostics = optional(object({
      storage_account_uri = optional(string)
    }))
    identity = object({ type = string })
    os_disk = object({
      name                 = string
      caching              = string
      disk_size_gb         = number
      storage_account_type = string
    })
    source_image_reference = object({
      publisher = string
      offer     = string
      sku       = string
      version   = string
    })
    tags = optional(map(string), {})
  }))
  description = "Existing Windows VMs to adopt through wrapper 0.1.6. The VM owns its OS disk inline; os_managed_disk_id and vm_agent_platform_updates_enabled are inventory only."
  default     = {}

  validation {
    condition = alltrue([
      for vm in values(var.windows_virtual_machine) :
      contains(keys(var.resource_group), vm.resource_group_key) && (!var.enable_windows_virtual_machine || var.enable_resource_group)
    ])
    error_message = "Each Windows VM must reference a managed resource group, enabled when VM adoption is enabled."
  }

  validation {
    condition = !var.enable_windows_virtual_machine || alltrue([
      for vm in values(var.windows_virtual_machine) :
      length(vm.network_interface_ids) > 0 && alltrue([
        for resource_id in vm.network_interface_ids : contains(values(local.network_interface_resource_ids), resource_id)
      ])
    ])
    error_message = "Every Windows VM NIC ID must match an existing network_interface inventory entry exactly for wrapper-owned adoption."
  }

  validation {
    condition = !var.enable_windows_virtual_machine || length(flatten([
      for vm in values(var.windows_virtual_machine) : vm.network_interface_ids
      ])) == length(toset(flatten([
        for vm in values(var.windows_virtual_machine) : vm.network_interface_ids
    ])))
    error_message = "A NIC must not be assigned to multiple Windows VM wrapper instances or listed more than once."
  }

  validation {
    condition = alltrue([
      for vm in values(var.windows_virtual_machine) : contains(["None", "SystemAssigned"], vm.identity.type)
    ])
    error_message = "The Windows VM adapter supports only the exported None or SystemAssigned identity types; user-assigned identities require explicit inventory and mapping."
  }
}

variable "windows_virtual_machine_admin_passwords" {
  type        = map(string)
  description = "Existing VM passwords forwarded to the wrapper without generation, supplied only through secure Terraform variable channels; verify its credential-preservation behavior before adoption."
  sensitive   = true
  default     = {}

  validation {
    condition = !var.enable_windows_virtual_machine || alltrue([
      for vm_key in keys(var.windows_virtual_machine) :
      trimspace(lookup(var.windows_virtual_machine_admin_passwords, vm_key, "")) != ""
    ])
    error_message = "Enabling Windows VMs requires a non-empty password input for each VM key, supplied securely outside committed files."
  }
}

variable "windows_virtual_machine_imports" {
  type        = map(string)
  description = "Existing Windows VM IDs, keyed by the matching windows_virtual_machine instance."
  default     = {}

  validation {
    condition = alltrue([
      for vm_key, resource_id in var.windows_virtual_machine_imports :
      resource_id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[var.windows_virtual_machine[vm_key].resource_group_key].name, "")}/providers/Microsoft.Compute/virtualMachines/${try(var.windows_virtual_machine[vm_key].name, "")}"
    ])
    error_message = "Each windows_virtual_machine_imports entry must match its VM key, name, resource group and subscription_id."
  }
}

variable "enable_virtual_network" {
  type        = bool
  description = "Whether Terraform manages and imports the existing virtual networks and their subnets."
  default     = false
}

variable "virtual_network" {
  type = map(object({
    name               = string
    resource_group_key = string
    location           = optional(string)
    address_space      = set(string)
    dns_servers = optional(object({
      dns_servers = list(string)
    }))
    ddos_protection_plan = optional(object({
      id     = string
      enable = bool
    }))
    enable_vm_protection    = optional(bool, false)
    flow_timeout_in_minutes = optional(number)
    encryption = optional(object({
      enabled     = bool
      enforcement = string
    }))
    subnets = optional(map(object({
      name                                          = string
      address_prefixes                              = list(string)
      private_endpoint_network_policies             = optional(string, "Enabled")
      private_link_service_network_policies_enabled = optional(bool, true)
      default_outbound_access_enabled               = optional(bool, false)
      nat_gateway = optional(object({
        id = string
      }))
      network_security_group = optional(object({
        id = string
      }))
      route_table = optional(object({
        id = string
      }))
      service_endpoint_policies = optional(map(object({
        id = string
      })))
      service_endpoints_with_location = optional(list(object({
        service   = string
        locations = optional(list(string), ["*"])
      })))
      delegations = optional(list(object({
        name = string
        service_delegation = object({
          name    = string
          actions = optional(list(string), [])
        })
      })), [])
    })), {})
    tags = optional(map(string), {})
  }))
  description = "Existing VNets/subnets using Auritas's wrapper inputs; delegation actions are retained as inventory, not forwarded."
  default     = {}

  validation {
    condition = alltrue([
      for vnet in values(var.virtual_network) :
      contains(keys(var.resource_group), vnet.resource_group_key) && (!var.enable_virtual_network || var.enable_resource_group)
    ])
    error_message = "Each VNet must reference a managed resource group, enabled when network adoption is enabled."
  }
}

variable "virtual_network_imports" {
  type        = map(string)
  description = "Existing VNet IDs, keyed by the matching virtual_network instance."
  default     = {}

  validation {
    condition = alltrue([
      for vnet_key, resource_id in var.virtual_network_imports :
      resource_id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[var.virtual_network[vnet_key].resource_group_key].name, "")}/providers/Microsoft.Network/virtualNetworks/${try(var.virtual_network[vnet_key].name, "")}"
    ])
    error_message = "Each virtual_network_imports entry must match its VNet key, name, resource group and subscription_id."
  }
}

variable "virtual_network_subnet_imports" {
  type = map(object({
    vnet_key   = string
    subnet_key = string
    id         = string
  }))
  description = "Existing bare subnet IDs and their owning VNet/subnet keys; the import block appends the API version."
  default     = {}

  validation {
    condition = alltrue([
      for subnet in values(var.virtual_network_subnet_imports) :
      subnet.id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[var.virtual_network[subnet.vnet_key].resource_group_key].name, "")}/providers/Microsoft.Network/virtualNetworks/${try(var.virtual_network[subnet.vnet_key].name, "")}/subnets/${try(var.virtual_network[subnet.vnet_key].subnets[subnet.subnet_key].name, "")}"
    ])
    error_message = "Each subnet import must match its VNet/subnet keys, names, resource group and subscription_id."
  }
}

variable "enable_event_grid_system_topic" {
  type        = bool
  description = "Whether Terraform manages and imports the existing Event Grid system topics."
  default     = false
}

variable "event_grid_system_topic" {
  type = map(object({
    name                        = string
    resource_group_key          = string
    location                    = optional(string)
    topic_type                  = string
    source_resource_id          = optional(string)
    exported_source_resource_id = string
    tags                        = optional(map(string), {})
  }))
  description = "Existing system topics to adopt directly; leave the ForceNew source unset and verify exported source inventory after import."
  default     = {}

  validation {
    condition = alltrue([
      for topic in values(var.event_grid_system_topic) :
      contains(keys(var.resource_group), topic.resource_group_key) && (!var.enable_event_grid_system_topic || var.enable_resource_group)
    ])
    error_message = "Each system topic must reference a managed resource group, enabled when topic adoption is enabled."
  }
}

variable "event_grid_system_topic_imports" {
  type        = map(string)
  description = "Existing system topic IDs, keyed by the matching event_grid_system_topic instance."
  default     = {}

  validation {
    condition = alltrue([
      for topic_key, resource_id in var.event_grid_system_topic_imports :
      resource_id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[var.event_grid_system_topic[topic_key].resource_group_key].name, "")}/providers/Microsoft.EventGrid/systemTopics/${try(var.event_grid_system_topic[topic_key].name, "")}"
    ])
    error_message = "Each event_grid_system_topic_imports entry must match its topic key, name, resource group and subscription_id."
  }
}

# =====================================================================
# Hub private DNS (connectivity subscription)
# =====================================================================

variable "hub_dns_subscription_id" {
  type        = string
  description = "Connectivity subscription that hosts the shared private DNS zones."
  default     = "f3835bc1-9829-4ac8-9d7a-0999e0b29b90"
}

variable "hub_dns_resource_group_name" {
  type        = string
  description = "Resource group of the shared private DNS zones."
  default     = "rg-dns-connectivity-canadacentral-001"
}

variable "enable_hub_private_dns" {
  type        = bool
  description = "Whether Terraform manages and imports this app's VNet links and records in the shared hub zones."
  default     = false
}

variable "hub_private_dns_zone_link" {
  type = map(object({
    enabled              = optional(bool, true)
    name                 = string
    zone_name            = string
    virtual_network_id   = string
    registration_enabled = optional(bool, false)
    resolution_policy    = optional(string, "Default")
  }))
  description = "This app's VNet links in the shared hub zones."
  default     = {}
}

variable "hub_private_dns_zone_link_imports" {
  type        = map(string)
  description = "Existing VNet link IDs, keyed by hub_private_dns_zone_link and filtered by global/per-entry enable flags."
  default     = {}

  validation {
    condition = alltrue([
      for link_key, resource_id in var.hub_private_dns_zone_link_imports :
      resource_id == "/subscriptions/${var.hub_dns_subscription_id}/resourceGroups/${var.hub_dns_resource_group_name}/providers/Microsoft.Network/privateDnsZones/${try(var.hub_private_dns_zone_link[link_key].zone_name, "")}/virtualNetworkLinks/${try(var.hub_private_dns_zone_link[link_key].name, "")}"
    ])
    error_message = "Each hub_private_dns_zone_link_imports entry must match its link's zone, name, hub resource group and subscription."
  }
}
