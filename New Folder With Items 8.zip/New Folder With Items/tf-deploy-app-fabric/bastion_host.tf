module "bastion_host" {
  for_each = var.enable_bastion_host ? var.bastion_host : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-bastion-host/azurerm"
  version = "0.0.1"

  name        = each.value.name
  parent_id   = module.resource_group[each.value.resource_group_key].resource_id
  location    = coalesce(each.value.location, module.resource_group[each.value.resource_group_key].location)
  sku         = each.value.sku
  scale_units = each.value.scale_units

  virtual_network_id = each.value.virtual_network_id
  zones              = each.value.zones
  tags               = each.value.tags

  enable_telemetry = false
}

import {
  for_each = var.enable_bastion_host ? var.bastion_host_imports : {}

  to = module.bastion_host[each.key].module.bastion_host.azapi_resource.bastion_developer[0]
  id = "${each.value}?api-version=2024-05-01"
}