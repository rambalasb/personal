locals {
  network_interface_resource_ids = {
    for nic_key, nic in var.network_interface : nic_key =>
    "/subscriptions/${var.subscription_id}/resourceGroups/${var.resource_group[nic.resource_group_key].name}/providers/Microsoft.Network/networkInterfaces/${nic.name}"
  }
}

# Every enabled NIC is a VM NIC, now owned by the VM wrapper. Drops any NIC
# adopted earlier under the standalone wrapper from state without deleting it,
# so the VM import can take it over.
removed {
  from = module.network_interface

  lifecycle {
    destroy = false
  }
}

resource "azurerm_network_interface_security_group_association" "this" {
  for_each = var.enable_network_interface ? { for nic_key, nsg_id in var.network_interface_nsg_associations : nic_key => nsg_id if try(var.network_interface[nic_key].enabled, false) } : {}

  network_interface_id      = local.network_interface_resource_ids[each.key]
  network_security_group_id = each.value

  depends_on = [module.windows_virtual_machine]
}

import {
  for_each = var.enable_network_interface ? { for nic_key, nsg_id in var.network_interface_nsg_associations : nic_key => nsg_id if try(var.network_interface[nic_key].enabled, false) } : {}

  to = azurerm_network_interface_security_group_association.this[each.key]
  id = "${local.network_interface_resource_ids[each.key]}|${each.value}"
}
