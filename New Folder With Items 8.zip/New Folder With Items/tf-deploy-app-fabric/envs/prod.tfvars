# Sub-Fabric-Prod (e299ec5b-9b38-4d00-9c9a-9257a48b6ecc)
# The VMs (and their NICs) and the VNet are off; they are adopted later, one
# stage at a time (see "Staged adoption" in the README).

subscription_id                 = "e299ec5b-9b38-4d00-9c9a-9257a48b6ecc"
enable_resource_group           = true
enable_monitoring               = true
enable_bastion_host             = false
enable_key_vault                = true
enable_nat_gateway              = false
enable_network_interface        = false
enable_network_security_group   = true
enable_network_watcher          = true
enable_private_endpoint         = true
enable_public_ip_prefix         = false
enable_storage_account          = true
enable_windows_virtual_machine  = false
enable_virtual_network          = false
enable_event_grid_system_topic  = true
enable_data_factory             = true
enable_fabric_capacity          = true
enable_restore_point_collection = true

enable_resource_group_role_assignment           = false
enable_fabric_capacity_role_assignment          = false
enable_data_factory_role_assignment             = false
enable_monitoring_role_assignment               = false
enable_bastion_host_role_assignment             = false
enable_key_vault_role_assignment                = false
enable_nat_gateway_role_assignment              = false
enable_network_interface_role_assignment        = false
enable_network_security_group_role_assignment   = false
enable_restore_point_collection_role_assignment = false
enable_network_watcher_role_assignment          = false
enable_private_endpoint_role_assignment         = false
enable_public_ip_prefix_role_assignment         = false
enable_storage_account_role_assignment          = false
enable_windows_virtual_machine_role_assignment  = false
enable_virtual_network_role_assignment          = false
enable_event_grid_system_topic_role_assignment  = false

role_assignments = {}

restore_point_collection = {
  vm_001 = {
    name                      = "AzureBackup_vm-fabric-prod-canadacentral-001_6310211582381500496"
    resource_group_key        = "backup"
    location                  = "canadacentral"
    source_virtual_machine_id = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-app-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-fabric-prod-canadacentral-001"
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "Prod"
    }
  }
  vm_002 = {
    name                      = "AzureBackup_vm-fabric-prod-canadacentral-002_6310211583015634737"
    resource_group_key        = "backup"
    location                  = "canadacentral"
    source_virtual_machine_id = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-app-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-fabric-prod-canadacentral-002"
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "Prod"
    }
  }
}

restore_point_collection_imports = {
  vm_001 = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/azurebackuprg_canadacentral_1/providers/Microsoft.Compute/restorePointCollections/AzureBackup_vm-fabric-prod-canadacentral-001_6310211582381500496"
  vm_002 = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/azurebackuprg_canadacentral_1/providers/Microsoft.Compute/restorePointCollections/AzureBackup_vm-fabric-prod-canadacentral-002_6310211583015634737"
}

resource_group = {
  "network_watcher" = {
    name     = "NetworkWatcherRG"
    location = "canadacentral"
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "Prod"
    }
  }
  "app" = {
    name     = "rg-fabric-prod-app-canadacentral-001"
    location = "canadacentral"
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "Prod"
    }
  }
  "backup" = {
    name     = "AzureBackupRG_canadacentral_1"
    location = "canadacentral"
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "Prod"
    }
  }
  "ds" = {
    name     = "rg-fabric-prod-ds-canadacentral-001"
    location = "canadacentral"
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "Prod"
    }
  }
  "network" = {
    name     = "rg-fabric-prod-network-canadacentral-001"
    location = "canadacentral"
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "Prod"
    }
  }
  "siem" = {
    name     = "rg-fabric-prod-siem-canadacentral-001"
    location = "canadacentral"
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "Prod"
    }
  }
}

import_resource_group = {
  "network_watcher" = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/NetworkWatcherRG"
  "app"             = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-app-canadacentral-001"
  "backup"          = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/AzureBackupRG_canadacentral_1"
  "ds"              = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-ds-canadacentral-001"
  "network"         = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-network-canadacentral-001"
  "siem"            = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-siem-canadacentral-001"
}

fabric_capacity = {
  "copilot" = {
    name               = "copilotfabricprodcapacity001"
    resource_group_key = "app"
    location           = "canadacentral"
    sku_name           = "F8"
    administration_members = [
      "Akanksha.Choudhary@bchydro.com",
      "John.Mei@bchydro.com",
      "Malik.Merchant@bchydro.com",
      "Milind.More@bchydro.com"
    ]
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "Prod"
    }
  }
  "data_science" = {
    name               = "datasciencefabricprodcapacity001"
    resource_group_key = "ds"
    location           = "canadacentral"
    sku_name           = "F16"
    administration_members = [
      "John.Mei@bchydro.com",
      "Malik.Merchant@bchydro.com",
      "Milind.More@bchydro.com",
      "a-mmore.cloud@bchydro.onmicrosoft.com"
    ]
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "Prod"
    }
  }
}

fabric_capacity_imports = {
  "copilot"      = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-app-canadacentral-001/providers/Microsoft.Fabric/capacities/copilotfabricprodcapacity001"
  "data_science" = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-ds-canadacentral-001/providers/Microsoft.Fabric/capacities/datasciencefabricprodcapacity001"
}

data_factory = {
  "fabric_prod" = {
    name                            = "df-fabric-prod-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    public_network_enabled          = false
    managed_virtual_network_enabled = false
    managed_identities = {
      system_assigned            = true
      user_assigned_resource_ids = []
    }
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "Prod"
    }
  }
}

data_factory_imports = {
  "fabric_prod" = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-app-canadacentral-001/providers/Microsoft.DataFactory/factories/df-fabric-prod-canadacentral-001"
}

virtual_network = {
  "fabric_prod" = {
    name               = "vnet-fabric-prod-canadacentral-001"
    resource_group_key = "network"
    location           = "canadacentral"
    address_space      = ["10.195.123.0/24"]
    dns_servers = {
      dns_servers = ["10.195.1.4"]
    }
    ddos_protection_plan = {
      enable = true
      id     = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/ddosProtectionPlans/ddos-protection-plan"
    }
    subnets = {
      "app" = {
        name                                          = "snet-fabric-prod-app-canadacentral-001"
        address_prefixes                              = ["10.195.123.0/26"]
        default_outbound_access_enabled               = false
        private_endpoint_network_policies             = "Disabled"
        private_link_service_network_policies_enabled = true
        service_endpoint_policies                     = {}
        service_endpoints_with_location               = []
        delegations                                   = []
      }
      "pep" = {
        name                                          = "snet-fabric-prod-pep-canadacentral-001"
        address_prefixes                              = ["10.195.123.128/26"]
        default_outbound_access_enabled               = false
        private_endpoint_network_policies             = "RouteTableEnabled"
        private_link_service_network_policies_enabled = true
        service_endpoint_policies                     = {}
        service_endpoints_with_location               = []
        delegations                                   = []
      }
    }
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "Prod"
    }
  }
}

virtual_network_imports = {
  "fabric_prod" = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-prod-canadacentral-001"
}

virtual_network_subnet_imports = {
  "fabric_prod_app" = {
    vnet_key   = "fabric_prod"
    subnet_key = "app"
    id         = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-prod-canadacentral-001/subnets/snet-fabric-prod-app-canadacentral-001"
  }
  "fabric_prod_pep" = {
    vnet_key   = "fabric_prod"
    subnet_key = "pep"
    id         = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-prod-canadacentral-001/subnets/snet-fabric-prod-pep-canadacentral-001"
  }
}

alert = {
  resource_group_key = "network"
  tags = {
    CostCenterId = "YT-01860.S.IMP.DEV"
    Environment  = "Prod"
  }
  activity_log_alerts = {
    "service_outage_canada_central" = {
      name                = "Service-Outage-Alert-CanadaCentral"
      resource_group_name = "rg-fabric-prod-network-canadacentral-001"
      scopes              = ["/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc"]
      location            = "global"
      description         = "Azure Landing Zone Service Health Alert"
      enabled             = true
      criteria = {
        category       = "ServiceHealth"
        service_health = {}
      }
      action_group_keys = []
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-monitor-mail-alerts-canadacentral-001"
      ]
      webhook_properties = {}
      tags = {
        CostCenterId = "YT-01860.S.IMP.DEV"
        Environment  = "Prod"
      }
    }
  }
}

activity_log_alert_imports = {
  "service_outage_canada_central" = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-network-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/Service-Outage-Alert-CanadaCentral"
}

event_grid_system_topic = {
  "network_watcher_storage" = {
    name                        = "stnwfabricprdcac001xdf-48b5fff5-bf24-4081-891e-6e53d2d825a6"
    resource_group_key          = "network_watcher"
    location                    = "canadacentral"
    topic_type                  = "microsoft.storage.storageaccounts"
    source_resource_id          = null
    exported_source_resource_id = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/networkwatcherrg/providers/microsoft.storage/storageaccounts/stnwfabricprdcac001xdf"
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "Prod"
    }
  }
}

event_grid_system_topic_imports = {
  "network_watcher_storage" = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/NetworkWatcherRG/providers/Microsoft.EventGrid/systemTopics/stnwfabricprdcac001xdf-48b5fff5-bf24-4081-891e-6e53d2d825a6"
}

key_vault = {
  "siem" = {
    name                            = "kvfabricprodcc001"
    resource_group_key              = "siem"
    location                        = "canadacentral"
    tenant_id                       = "8fbb85e8-0cbc-48c3-a2e9-528cef30ec27"
    sku_name                        = "premium"
    enabled_for_deployment          = false
    enabled_for_disk_encryption     = true
    enabled_for_template_deployment = true
    legacy_access_policies_enabled  = false
    public_network_access_enabled   = false
    purge_protection_enabled        = true
    soft_delete_retention_days      = 90
    network_acls = {
      bypass                     = "AzureServices"
      default_action             = "Deny"
      ip_rules                   = []
      virtual_network_subnet_ids = []
    }
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "Prod"
    }
  }
}

network_security_group = {
  "vm_001" = {
    name               = "vm-fabric-prod-canadacentral-001-nsg"
    resource_group_key = "app"
    location           = "canadacentral"
    security_rules     = {}
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "Prod"
    }
  }
  "vm_002" = {
    name               = "vm-fabric-prod-canadacentral-002-nsg"
    resource_group_key = "app"
    location           = "canadacentral"
    security_rules     = {}
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "Prod"
    }
  }
}

network_watcher = {
  "canadacentral" = {
    name               = "NetworkWatcher_canadacentral"
    resource_group_key = "network_watcher"
    location           = "canadacentral"
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "Prod"
    }
  }
}

network_watcher_imports = {
  "canadacentral" = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/NetworkWatcherRG/providers/Microsoft.Network/networkWatchers/NetworkWatcher_canadacentral"
}

import_network_security_group = {
  "vm_001" = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-app-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/vm-fabric-prod-canadacentral-001-nsg"
  "vm_002" = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-app-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/vm-fabric-prod-canadacentral-002-nsg"
}

private_endpoint = {
  "network_watcher_storage" = {
    name                            = "pep-stnwfabricprdcac001xdf"
    resource_group_key              = "network_watcher"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-prod-canadacentral-001/subnets/snet-fabric-prod-pep-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourcegroups/NetworkWatcherRG/providers/Microsoft.Storage/storageAccounts/stnwfabricprdcac001xdf"
    private_service_connection_name = "pep-stnwfabricprdcac001xdf"
    subresource_names               = ["blob"]
    network_interface_name          = "pep-stnwfabricprdcac001xdf-nic"
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net"
    ]
    ip_configurations = {}
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "Prod"
    }
  }
  "storage_blob" = {
    name                            = "pep-blob-stfabricprodcac001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-prod-canadacentral-001/subnets/snet-fabric-prod-pep-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourcegroups/rg-fabric-prod-app-canadacentral-001/providers/Microsoft.Storage/storageAccounts/stfabricprodcac001"
    private_service_connection_name = "pep-blob-stfabricprodcac001"
    subresource_names               = ["blob"]
    network_interface_name          = "pep-blob-stfabricprodcac001-nic"
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net"
    ]
    ip_configurations = {}
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "Prod"
    }
  }
  "data_factory" = {
    name                            = "pep-df-fabric-prod-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-prod-canadacentral-001/subnets/snet-fabric-prod-pep-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-app-canadacentral-001/providers/Microsoft.DataFactory/factories/df-fabric-prod-canadacentral-001"
    private_service_connection_name = "pep-df-fabric-prod-canadacentral-001"
    subresource_names               = ["dataFactory"]
    network_interface_name          = "pep-df-fabric-prod-canadacentral-001-nic"
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.datafactory.azure.net"
    ]
    ip_configurations = {}
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "Prod"
    }
  }
  "storage_dfs" = {
    name                            = "pep-dfs-stfabricprodcac001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-prod-canadacentral-001/subnets/snet-fabric-prod-pep-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-app-canadacentral-001/providers/Microsoft.Storage/storageAccounts/stfabricprodcac001"
    private_service_connection_name = "pep-dfs-stfabricprodcac001"
    subresource_names               = ["dfs"]
    network_interface_name          = "pep-dfs-stfabricprodcac001-nic"
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.dfs.core.windows.net"
    ]
    ip_configurations = {}
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "Prod"
    }
  }
  "backup" = {
    # Connection name is 81 characters; AzureRM allows 80, so this endpoint stays unmanaged.
    enabled                         = false
    name                            = "pep-rsv-fabric-prod-backup-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-prod-canadacentral-001/subnets/snet-fabric-prod-pep-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourcegroups/rg-fabric-prod-app-canadacentral-001/providers/Microsoft.RecoveryServices/vaults/rsv-fabric-prod-canadacentral-001"
    private_service_connection_name = "pep-rsv-fabric-prod-backup-canadacentral-001_2079140f-2f80-49cb-a408-80305c88f0fc"
    subresource_names               = ["AzureBackup"]
    network_interface_name          = null
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net",
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.cnc.backup.windowsazure.com",
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.queue.core.windows.net"
    ]
    ip_configurations = {}
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "Prod"
    }
  }
  "key_vault" = {
    name                            = "pep-kvfabricprodcc001"
    resource_group_key              = "siem"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-prod-canadacentral-001/subnets/snet-fabric-prod-pep-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-siem-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvfabricprodcc001"
    private_service_connection_name = "pep-kvfabricprodcc001"
    subresource_names               = ["vault"]
    network_interface_name          = "pep-kvfabricprodcc001-nic"
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.vaultcore.azure.net"
    ]
    ip_configurations = {}
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "Prod"
    }
  }
}

private_endpoint_imports = {
  "network_watcher_storage" = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/NetworkWatcherRG/providers/Microsoft.Network/privateEndpoints/pep-stnwfabricprdcac001xdf"
  "storage_blob"            = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-app-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-blob-stfabricprodcac001"
  "data_factory"            = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-app-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-df-fabric-prod-canadacentral-001"
  "storage_dfs"             = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-app-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-dfs-stfabricprodcac001"
  "backup"                  = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-app-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-rsv-fabric-prod-backup-canadacentral-001"
  "key_vault"               = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-siem-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-kvfabricprodcc001"
}

storage_account = {
  "network_watcher" = {
    name                            = "stnwfabricprdcac001xdf"
    resource_group_key              = "network_watcher"
    location                        = "canadacentral"
    account_tier                    = "Standard"
    account_replication_type        = "LRS"
    access_tier                     = "Hot"
    allow_nested_items_to_be_public = false
    default_to_oauth_authentication = true
    is_hns_enabled                  = false
    public_network_access_enabled   = false
    shared_access_key_enabled       = false
    blob_properties = {
      container_delete_retention_policy = {}
      delete_retention_policy           = {}
    }
    network_rules = {
      bypass         = ["AzureServices"]
      default_action = "Deny"
      private_link_access = [{
        endpoint_resource_id = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/providers/Microsoft.Security/datascanners/storageDataScanner"
        endpoint_tenant_id   = "8fbb85e8-0cbc-48c3-a2e9-528cef30ec27"
      }]
    }
    share_properties = {
      retention_policy = {}
    }
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "Prod"
    }
  }
  "fabric_prod" = {
    name                            = "stfabricprodcac001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    account_tier                    = "Standard"
    account_replication_type        = "ZRS"
    access_tier                     = "Hot"
    allow_nested_items_to_be_public = false
    default_to_oauth_authentication = true
    is_hns_enabled                  = true
    public_network_access_enabled   = false
    blob_properties = {
      container_delete_retention_policy = { days = 14 }
      delete_retention_policy           = { days = 14 }
    }
    network_rules = {
      bypass         = ["AzureServices"]
      default_action = "Deny"
    }
    share_properties = {}
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "Prod"
    }
  }
}

storage_account_imports = {
  "network_watcher" = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/NetworkWatcherRG/providers/Microsoft.Storage/storageAccounts/stnwfabricprdcac001xdf"
  "fabric_prod"     = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-app-canadacentral-001/providers/Microsoft.Storage/storageAccounts/stfabricprodcac001"
}

windows_virtual_machine = {
  "vm_001" = {
    name                                                   = "vm-fabric-prod-canadacentral-001"
    resource_group_key                                     = "app"
    location                                               = "canadacentral"
    size                                                   = "Standard_B4as_v2"
    zone                                                   = "1"
    admin_username                                         = "shiruser"
    computer_name                                          = "vm-fabric-prod-"
    network_interface_ids                                  = ["/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-app-canadacentral-001/providers/Microsoft.Network/networkInterfaces/vm-fabric-prod-canadacentral-001914_z1"]
    os_managed_disk_id                                     = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-app-canadacentral-001/providers/Microsoft.Compute/disks/vm-fabric-prod-canadacentral-001_OsDisk_1_b517a4b1c0b54cd3962d27ac742ac40b"
    allow_extension_operations                             = true
    automatic_updates_enabled                              = true
    bypass_platform_safety_checks_on_user_schedule_enabled = false
    disk_controller_type                                   = "SCSI"
    license_type                                           = "Windows_Server"
    patch_assessment_mode                                  = "ImageDefault"
    patch_mode                                             = "AutomaticByOS"
    provision_vm_agent                                     = true
    secure_boot_enabled                                    = true
    vm_agent_platform_updates_enabled                      = true
    vtpm_enabled                                           = true
    additional_capabilities                                = {}
    boot_diagnostics                                       = null
    identity                                               = { type = "SystemAssigned" }
    os_disk = {
      caching              = "ReadWrite"
      disk_size_gb         = 127
      name                 = "vm-fabric-prod-canadacentral-001_OsDisk_1_b517a4b1c0b54cd3962d27ac742ac40b"
      storage_account_type = "Premium_LRS"
    }
    source_image_reference = {
      publisher = "MicrosoftWindowsServer"
      offer     = "WindowsServer"
      sku       = "2025-datacenter-g2"
      version   = "latest"
    }
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "Prod"
    }
  }
  "vm_002" = {
    name                                                   = "vm-fabric-prod-canadacentral-002"
    resource_group_key                                     = "app"
    location                                               = "canadacentral"
    size                                                   = "Standard_B4as_v2"
    zone                                                   = "2"
    admin_username                                         = "shiruser"
    computer_name                                          = "vm-fabric-prod-"
    network_interface_ids                                  = ["/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-app-canadacentral-001/providers/Microsoft.Network/networkInterfaces/vm-fabric-prod-canadacentral-002835_z2"]
    os_managed_disk_id                                     = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-app-canadacentral-001/providers/Microsoft.Compute/disks/vm-fabric-prod-canadacentral-002_OsDisk_1_9e90a79a82b247c1ba4a606cdf9f3797"
    allow_extension_operations                             = true
    automatic_updates_enabled                              = true
    bypass_platform_safety_checks_on_user_schedule_enabled = false
    disk_controller_type                                   = "SCSI"
    license_type                                           = "Windows_Server"
    patch_assessment_mode                                  = "ImageDefault"
    patch_mode                                             = "AutomaticByOS"
    provision_vm_agent                                     = true
    secure_boot_enabled                                    = true
    vm_agent_platform_updates_enabled                      = true
    vtpm_enabled                                           = true
    additional_capabilities                                = {}
    boot_diagnostics                                       = null
    identity                                               = { type = "SystemAssigned" }
    os_disk = {
      caching              = "ReadWrite"
      disk_size_gb         = 127
      name                 = "vm-fabric-prod-canadacentral-002_OsDisk_1_9e90a79a82b247c1ba4a606cdf9f3797"
      storage_account_type = "Premium_LRS"
    }
    source_image_reference = {
      publisher = "MicrosoftWindowsServer"
      offer     = "WindowsServer"
      sku       = "2025-datacenter-g2"
      version   = "latest"
    }
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "Prod"
    }
  }
}

windows_virtual_machine_imports = {
  "vm_001" = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-app-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-fabric-prod-canadacentral-001"
  "vm_002" = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-app-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-fabric-prod-canadacentral-002"
}

key_vault_imports = {
  "siem" = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-siem-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvfabricprodcc001"
}

network_interface = {
  "network_watcher_storage_pep" = {
    name               = "pep-stnwfabricprdcac001xdf-nic"
    resource_group_key = "network_watcher"
    location           = "canadacentral"
    enabled            = false
    ip_configurations = {
      "private_endpoint" = {
        name                          = "privateEndpointIpConfig.5069d52e-6164-4257-a288-1c623a116214"
        primary                       = true
        private_ip_address            = "10.195.123.133"
        private_ip_address_allocation = "Dynamic"
        subnet_id                     = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-prod-canadacentral-001/subnets/snet-fabric-prod-pep-canadacentral-001"
      }
    }
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "Prod"
    }
  }
  "storage_blob_pep" = {
    name               = "pep-blob-stfabricprodcac001-nic"
    resource_group_key = "app"
    location           = "canadacentral"
    enabled            = false
    ip_configurations = {
      "private_endpoint" = {
        name                          = "privateEndpointIpConfig.1c7e4fd2-d442-4990-97b1-2e6da6fe2210"
        primary                       = true
        private_ip_address            = "10.195.123.134"
        private_ip_address_allocation = "Dynamic"
        subnet_id                     = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-prod-canadacentral-001/subnets/snet-fabric-prod-pep-canadacentral-001"
      }
    }
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "Prod"
    }
  }
  "data_factory_pep" = {
    name               = "pep-df-fabric-prod-canadacentral-001-nic"
    resource_group_key = "app"
    location           = "canadacentral"
    enabled            = false
    ip_configurations = {
      "private_endpoint" = {
        name                          = "privateEndpointIpConfig.995f9de9-86f2-4f5c-9b16-e5538800b3e0"
        primary                       = true
        private_ip_address            = "10.195.123.136"
        private_ip_address_allocation = "Dynamic"
        subnet_id                     = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-prod-canadacentral-001/subnets/snet-fabric-prod-pep-canadacentral-001"
      }
    }
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "Prod"
    }
  }
  "storage_dfs_pep" = {
    name               = "pep-dfs-stfabricprodcac001-nic"
    resource_group_key = "app"
    location           = "canadacentral"
    enabled            = false
    ip_configurations = {
      "private_endpoint" = {
        name                          = "privateEndpointIpConfig.2b2f09d8-1b79-4263-acc6-df54250b1adf"
        primary                       = true
        private_ip_address            = "10.195.123.135"
        private_ip_address_allocation = "Dynamic"
        subnet_id                     = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-prod-canadacentral-001/subnets/snet-fabric-prod-pep-canadacentral-001"
      }
    }
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "Prod"
    }
  }
  "backup_pep" = {
    name               = "pep-rsv-fabric-prod-backup-canadacentral-00.nic.d7b817ef-3508-4822-b26f-96f90da516ec"
    resource_group_key = "app"
    location           = "canadacentral"
    enabled            = false
    ip_configurations = {
      "primary" = {
        name                          = "privateEndpointIpConfig.cec99379-6f7f-42aa-a24f-a1ed4cd04090"
        primary                       = true
        private_ip_address            = "10.195.123.137"
        private_ip_address_allocation = "Dynamic"
        subnet_id                     = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-prod-canadacentral-001/subnets/snet-fabric-prod-pep-canadacentral-001"
      }
      "secondary" = {
        name                          = "privateEndpointIpConfig.0ce567d2-80f0-46f6-bf71-87f22e194873"
        primary                       = false
        private_ip_address            = "10.195.123.138"
        private_ip_address_allocation = "Dynamic"
        subnet_id                     = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-prod-canadacentral-001/subnets/snet-fabric-prod-pep-canadacentral-001"
      }
    }
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "Prod"
    }
  }
  "vm_001" = {
    name                           = "vm-fabric-prod-canadacentral-001914_z1"
    resource_group_key             = "app"
    location                       = "canadacentral"
    enabled                        = true
    accelerated_networking_enabled = true
    ip_configurations = {
      "primary" = {
        name                          = "ipconfig1"
        primary                       = true
        private_ip_address            = "10.195.123.4"
        private_ip_address_allocation = "Dynamic"
        subnet_id                     = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-prod-canadacentral-001/subnets/snet-fabric-prod-app-canadacentral-001"
      }
    }
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "Prod"
    }
  }
  "vm_002" = {
    name                           = "vm-fabric-prod-canadacentral-002835_z2"
    resource_group_key             = "app"
    location                       = "canadacentral"
    enabled                        = true
    accelerated_networking_enabled = true
    ip_configurations = {
      "primary" = {
        name                          = "ipconfig1"
        primary                       = true
        private_ip_address            = "10.195.123.5"
        private_ip_address_allocation = "Dynamic"
        subnet_id                     = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-prod-canadacentral-001/subnets/snet-fabric-prod-app-canadacentral-001"
      }
    }
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "Prod"
    }
  }
  "key_vault_pep" = {
    name               = "pep-kvfabricprodcc001-nic"
    resource_group_key = "siem"
    location           = "canadacentral"
    enabled            = false
    ip_configurations = {
      "private_endpoint" = {
        name                          = "privateEndpointIpConfig.584aa24b-acda-49ac-a211-c0eeb2bfe0e4"
        primary                       = true
        private_ip_address            = "10.195.123.132"
        private_ip_address_allocation = "Dynamic"
        subnet_id                     = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-prod-canadacentral-001/subnets/snet-fabric-prod-pep-canadacentral-001"
      }
    }
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "Prod"
    }
  }
}

network_interface_nsg_associations = {
  "vm_001" = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-app-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/vm-fabric-prod-canadacentral-001-nsg"
  "vm_002" = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-app-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/vm-fabric-prod-canadacentral-002-nsg"
}

# =====================================================================
# Hub private DNS: links and records in the shared zones (connectivity subscription)
# =====================================================================

enable_hub_private_dns = true

hub_private_dns_zone_link = {
  "link-fabric-prod-canadacentral-001" = {
    name               = "link-fabric-prod-canadacentral-001"
    zone_name          = "bchydro.bc.ca"
    virtual_network_id = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-prod-canadacentral-001"
  }
  "privatelink.blob.core.windows.net/link-vnet-fabric-prod-canadacentral-001" = {
    name               = "link-vnet-fabric-prod-canadacentral-001"
    zone_name          = "privatelink.blob.core.windows.net"
    virtual_network_id = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-prod-canadacentral-001"
  }
  "privatelink.cnc.backup.windowsazure.com/default" = {
    name               = "default"
    zone_name          = "privatelink.cnc.backup.windowsazure.com"
    virtual_network_id = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-prod-canadacentral-001"
    resolution_policy  = "NxDomainRedirect"
  }
  "privatelink.datafactory.azure.net/link-vnet-fabric-prod-canadacentral-001" = {
    name               = "link-vnet-fabric-prod-canadacentral-001"
    zone_name          = "privatelink.datafactory.azure.net"
    virtual_network_id = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-prod-canadacentral-001"
  }
  "privatelink.dfs.core.windows.net/link-vnet-fabric-prod-canadacentral-001" = {
    name               = "link-vnet-fabric-prod-canadacentral-001"
    zone_name          = "privatelink.dfs.core.windows.net"
    virtual_network_id = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-prod-canadacentral-001"
  }
  "privatelink.queue.core.windows.net/default" = {
    name               = "default"
    zone_name          = "privatelink.queue.core.windows.net"
    virtual_network_id = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-prod-canadacentral-001"
    resolution_policy  = "NxDomainRedirect"
  }
  "privatelink.vaultcore.azure.net/link-vnet-fabric-prod-canadacentral-001" = {
    name               = "link-vnet-fabric-prod-canadacentral-001"
    zone_name          = "privatelink.vaultcore.azure.net"
    virtual_network_id = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-prod-canadacentral-001"
  }
}

hub_private_dns_zone_link_imports = {
  "link-fabric-prod-canadacentral-001"                                        = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/bchydro.bc.ca/virtualNetworkLinks/link-fabric-prod-canadacentral-001"
  "privatelink.blob.core.windows.net/link-vnet-fabric-prod-canadacentral-001" = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net/virtualNetworkLinks/link-vnet-fabric-prod-canadacentral-001"
  "privatelink.cnc.backup.windowsazure.com/default"                           = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.cnc.backup.windowsazure.com/virtualNetworkLinks/default"
  "privatelink.datafactory.azure.net/link-vnet-fabric-prod-canadacentral-001" = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.datafactory.azure.net/virtualNetworkLinks/link-vnet-fabric-prod-canadacentral-001"
  "privatelink.dfs.core.windows.net/link-vnet-fabric-prod-canadacentral-001"  = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.dfs.core.windows.net/virtualNetworkLinks/link-vnet-fabric-prod-canadacentral-001"
  "privatelink.queue.core.windows.net/default"                                = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.queue.core.windows.net/virtualNetworkLinks/default"
  "privatelink.vaultcore.azure.net/link-vnet-fabric-prod-canadacentral-001"   = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.vaultcore.azure.net/virtualNetworkLinks/link-vnet-fabric-prod-canadacentral-001"
}
