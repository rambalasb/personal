# Sub-Fabric-NonProd (cd096fc9-e946-4547-8b46-eb23b6024332)
# Values come from the Azure resource export of 2026-10-19.
# The VNet is off; it is adopted last, with the connectivity team (see
# "Staged adoption" in the README).

subscription_id                = "cd096fc9-e946-4547-8b46-eb23b6024332"
enable_resource_group          = true
enable_monitoring              = true
enable_bastion_host            = true
enable_key_vault               = true
enable_nat_gateway             = true
enable_network_interface       = false
enable_network_security_group  = true
enable_network_watcher         = true
enable_private_endpoint        = true
enable_public_ip_prefix        = true
enable_storage_account         = true
enable_windows_virtual_machine = false
enable_virtual_network         = false
enable_data_factory            = true
enable_fabric_capacity         = true

enable_resource_group_role_assignment           = false
enable_fabric_capacity_role_assignment          = false
enable_data_factory_role_assignment             = false
enable_monitoring_role_assignment               = false
enable_bastion_host_role_assignment             = false
enable_key_vault_role_assignment                = false
enable_nat_gateway_role_assignment              = false
enable_network_interface_role_assignment        = false
enable_network_security_group_role_assignment   = false
enable_restore_point_collection_role_assignment = false
enable_network_watcher_role_assignment          = false
enable_private_endpoint_role_assignment         = false
enable_public_ip_prefix_role_assignment         = false
enable_storage_account_role_assignment          = false
enable_windows_virtual_machine_role_assignment  = false
enable_virtual_network_role_assignment          = false
enable_event_grid_system_topic_role_assignment  = false

role_assignments = {}

resource_group = {
  "network_watcher" = {
    name     = "NetworkWatcherRG"
    location = "canadacentral"
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "NonProd"
    }
  }
  "app" = {
    name     = "rg-fabric-nonprod-app-canadacentral-001"
    location = "canadacentral"
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "NonProd"
    }
  }
  "network" = {
    name     = "rg-fabric-nonprod-network-canadacentral-001"
    location = "canadacentral"
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "NonProd"
    }
  }
  "siem" = {
    name     = "rg-fabric-nonprod-siem-canadacentral-001"
    location = "canadacentral"
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "NonProd"
    }
  }
}

import_resource_group = {
  "network_watcher" = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/NetworkWatcherRG"
  "app"             = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/rg-fabric-nonprod-app-canadacentral-001"
  "network"         = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/rg-fabric-nonprod-network-canadacentral-001"
  "siem"            = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/rg-fabric-nonprod-siem-canadacentral-001"
}

fabric_capacity = {
  "fabric_nonprod" = {
    name               = "onelakefoundationfabricfapacitynonprod"
    resource_group_key = "app"
    location           = "canadacentral"
    sku_name           = "F64"
    # Live order; the list is compared positionally.
    administration_members = [
      "Malik.Merchant@bchydro.com",
      "Milind.More@bchydro.com",
      "John.Mei@bchydro.com",
      "a-jmei.cloud@bchydro.onmicrosoft.com"
    ]
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "NonProd"
    }
  }
}

fabric_capacity_imports = {
  "fabric_nonprod" = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/rg-fabric-nonprod-app-canadacentral-001/providers/Microsoft.Fabric/capacities/onelakefoundationfabricfapacitynonprod"
}

data_factory = {
  "fabric_nonprod" = {
    name                            = "df-fabric-nonprod-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    public_network_enabled          = false
    managed_virtual_network_enabled = false
    managed_identities = {
      system_assigned            = true
      user_assigned_resource_ids = []
    }
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "NonProd"
    }
  }
}

data_factory_imports = {
  "fabric_nonprod" = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/rg-fabric-nonprod-app-canadacentral-001/providers/Microsoft.DataFactory/factories/df-fabric-nonprod-canadacentral-001"
}

alert = {
  resource_group_key         = "app"
  root_management_group_name = null
  tags                       = {}

  activity_log_alerts = {
    "service_outage_canada_central" = {
      name                = "Service-Outage-Alert-CanadaCentral"
      resource_group_name = "rg-fabric-nonprod-app-canadacentral-001"
      scopes              = ["/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332"]
      location            = "global"
      description         = "Azure Landing Zone Service Health Alert"
      enabled             = true
      criteria = {
        category       = "ServiceHealth"
        service_health = {}
      }
      action_group_keys = []
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-monitor-mail-alerts-canadacentral-001"
      ]
      webhook_properties = {}
      tags = {
        CostCenterId = "YT-01860.S.IMP.DEV"
        Environment  = "NonProd"
      }
    }
  }
}

activity_log_alert_imports = {
  "service_outage_canada_central" = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/rg-fabric-nonprod-app-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/Service-Outage-Alert-CanadaCentral"
}

bastion_host = {
  "fabric_nonprod" = {
    name               = "vnet-fabric-nonprod-canadacentral-001-bastion"
    resource_group_key = "network"
    location           = "canadacentral"
    sku                = "Developer"
    scale_units        = 2
    virtual_network_id = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/rg-fabric-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-nonprod-canadacentral-001"
    zones              = []
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "NonProd"
    }
  }
}

bastion_host_imports = {
  "fabric_nonprod" = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/rg-fabric-nonprod-network-canadacentral-001/providers/Microsoft.Network/bastionHosts/vnet-fabric-nonprod-canadacentral-001-bastion"
}

key_vault = {
  "siem" = {
    name                            = "kvfabricnonprodcc001"
    resource_group_key              = "siem"
    location                        = "canadacentral"
    tenant_id                       = "8fbb85e8-0cbc-48c3-a2e9-528cef30ec27"
    sku_name                        = "premium"
    enabled_for_deployment          = false
    enabled_for_disk_encryption     = true
    enabled_for_template_deployment = true
    legacy_access_policies_enabled  = false
    public_network_access_enabled   = false
    purge_protection_enabled        = true
    soft_delete_retention_days      = 90
    network_acls = {
      bypass                     = "AzureServices"
      default_action             = "Deny"
      ip_rules                   = []
      virtual_network_subnet_ids = []
    }
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "NonProd"
    }
  }
}

key_vault_imports = {
  "siem" = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/rg-fabric-nonprod-siem-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvfabricnonprodcc001"
}

nat_gateway = {
  "fabric_nonprod" = {
    name                    = "ngw-fabric-nonprod-canadacentral-001"
    resource_group_key      = "app"
    location                = "canadacentral"
    sku_name                = "StandardV2"
    idle_timeout_in_minutes = 10
    public_ip_prefix_resource_ids = [
      "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/rg-fabric-nonprod-app-canadacentral-001/providers/Microsoft.Network/publicIPPrefixes/pip-ngw-fabric-nonprod-canadacentral-001"
    ]
    zones = null
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "NonProd"
    }
  }
}

nat_gateway_imports = {
  "fabric_nonprod" = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/rg-fabric-nonprod-app-canadacentral-001/providers/Microsoft.Network/natGateways/ngw-fabric-nonprod-canadacentral-001"
}

network_interface = {
  "storage_blob_pep" = {
    name               = "pep-blob-stfabricnonprodcac001-nic"
    resource_group_key = "app"
    location           = "canadacentral"
    enabled            = false
    ip_configurations = {
      "private_endpoint" = {
        name                          = "privateEndpointIpConfig.5c704813-1041-4997-846d-e57e2b5718c5"
        primary                       = true
        private_ip_address            = "10.195.127.135"
        private_ip_address_allocation = "Dynamic"
        subnet_id                     = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/rg-fabric-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-nonprod-canadacentral-001/subnets/snet-fabric-nonprod-pep-canadacentral-001"
      }
    }
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "NonProd"
    }
  }
  "data_factory_pep" = {
    name               = "pep-df-fabric-nonprod-canadacentral-001.nic.dec4ac4d-6cc0-41e5-a9dc-dfbba2647e3a"
    resource_group_key = "app"
    location           = "canadacentral"
    enabled            = false
    ip_configurations = {
      "private_endpoint" = {
        name                          = "privateEndpointIpConfig.2175a545-ed31-462b-8273-92144470c1c2"
        primary                       = true
        private_ip_address            = "10.195.127.134"
        private_ip_address_allocation = "Dynamic"
        subnet_id                     = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/rg-fabric-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-nonprod-canadacentral-001/subnets/snet-fabric-nonprod-pep-canadacentral-001"
      }
    }
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "NonProd"
    }
  }
  "storage_dfs_pep" = {
    name               = "pep-dfs-stfabricnonprodcac001.nic.f1ff9d42-62a3-44a0-87ac-b3eb89ec424b"
    resource_group_key = "app"
    location           = "canadacentral"
    enabled            = false
    ip_configurations = {
      "private_endpoint" = {
        name                          = "privateEndpointIpConfig.b30cdff3-018a-4578-9aa2-ed26b2106ea6"
        primary                       = true
        private_ip_address            = "10.195.127.133"
        private_ip_address_allocation = "Dynamic"
        subnet_id                     = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/rg-fabric-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-nonprod-canadacentral-001/subnets/snet-fabric-nonprod-pep-canadacentral-001"
      }
    }
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "NonProd"
    }
  }
  "vm_primary" = {
    name                           = "vm-fabric-nonprod-canadacentral-001870_z1"
    resource_group_key             = "app"
    location                       = "canadacentral"
    enabled                        = true
    accelerated_networking_enabled = true
    ip_configurations = {
      "primary" = {
        name                          = "ipconfig1"
        primary                       = true
        private_ip_address            = "10.195.127.4"
        private_ip_address_allocation = "Dynamic"
        subnet_id                     = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/rg-fabric-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-nonprod-canadacentral-001/subnets/snet-fabric-nonprod-app-canadacentral-001"
      }
    }
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "NonProd"
    }
  }
  "key_vault_pep" = {
    name               = "pep-kvfabricnonprodcc001.nic.8c4f8744-cf2e-44b2-ae8d-44dd551b0e74"
    resource_group_key = "siem"
    location           = "canadacentral"
    enabled            = false
    ip_configurations = {
      "private_endpoint" = {
        name                          = "privateEndpointIpConfig.7933b45b-2508-4115-bf3e-3d1562765503"
        primary                       = true
        private_ip_address            = "10.195.127.132"
        private_ip_address_allocation = "Dynamic"
        subnet_id                     = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/rg-fabric-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-nonprod-canadacentral-001/subnets/snet-fabric-nonprod-pep-canadacentral-001"
      }
    }
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "NonProd"
    }
  }
}

network_interface_nsg_associations = {
  "vm_primary" = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/rg-fabric-nonprod-app-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/vm-fabric-nonprod-canadacentral-001-nsg"
}

network_security_group = {
  "vm" = {
    name               = "vm-fabric-nonprod-canadacentral-001-nsg"
    resource_group_key = "app"
    location           = "canadacentral"
    security_rules = {
      "allow_rdp" = {
        name                       = "AllowRDPfromKDCAZDEVJUMPP1"
        description                = ""
        access                     = "Allow"
        direction                  = "Inbound"
        priority                   = 100
        protocol                   = "Tcp"
        source_address_prefix      = "10.242.112.1"
        source_port_range          = "*"
        destination_address_prefix = "*"
        destination_port_range     = "3389"
      }
    }
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "NonProd"
    }
  }
}

import_network_security_group = {
  "vm" = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/rg-fabric-nonprod-app-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/vm-fabric-nonprod-canadacentral-001-nsg"
}

network_security_rule_imports = {
  "vm/allow_rdp" = {
    nsg_key  = "vm"
    rule_key = "allow_rdp"
    id       = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/rg-fabric-nonprod-app-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/vm-fabric-nonprod-canadacentral-001-nsg/securityRules/AllowRDPfromKDCAZDEVJUMPP1"
  }
}

network_watcher = {
  "canadacentral" = {
    name               = "NetworkWatcher_canadacentral"
    resource_group_key = "network_watcher"
    location           = "canadacentral"
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "NonProd"
    }
  }
}

network_watcher_imports = {
  "canadacentral" = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/NetworkWatcherRG/providers/Microsoft.Network/networkWatchers/NetworkWatcher_canadacentral"
}

private_endpoint = {
  "storage_blob" = {
    name                            = "pep-blob-stfabricnonprodcac001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/rg-fabric-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-nonprod-canadacentral-001/subnets/snet-fabric-nonprod-pep-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/rg-fabric-nonprod-app-canadacentral-001/providers/Microsoft.Storage/storageAccounts/stfabricnonprodcac001"
    private_service_connection_name = "pep-blob-stfabricnonprodcac001"
    subresource_names               = ["blob"]
    network_interface_name          = "pep-blob-stfabricnonprodcac001-nic"
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net"
    ]
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "NonProd"
    }
  }
  "data_factory" = {
    name                            = "pep-df-fabric-nonprod-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/rg-fabric-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-nonprod-canadacentral-001/subnets/snet-fabric-nonprod-pep-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourcegroups/rg-fabric-nonprod-app-canadacentral-001/providers/Microsoft.DataFactory/factories/df-fabric-nonprod-canadacentral-001"
    private_service_connection_name = "pep-df-fabric-nonprod-canadacentral-001"
    subresource_names               = ["dataFactory"]
    network_interface_name          = null
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.datafactory.azure.net"
    ]
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "NonProd"
    }
  }
  "storage_dfs" = {
    name                            = "pep-dfs-stfabricnonprodcac001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/rg-fabric-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-nonprod-canadacentral-001/subnets/snet-fabric-nonprod-pep-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourcegroups/rg-fabric-nonprod-app-canadacentral-001/providers/Microsoft.Storage/storageAccounts/stfabricnonprodcac001"
    private_service_connection_name = "pep-dfs-stfabricnonprodcac001_280e76bc-5e4b-475a-80c8-ef6c0a1c805d"
    subresource_names               = ["dfs"]
    network_interface_name          = null
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.dfs.core.windows.net"
    ]
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "NonProd"
    }
  }
  "key_vault" = {
    name                            = "pep-kvfabricnonprodcc001"
    resource_group_key              = "siem"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/rg-fabric-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-nonprod-canadacentral-001/subnets/snet-fabric-nonprod-pep-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/rg-fabric-nonprod-siem-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvfabricnonprodcc001"
    private_service_connection_name = "pep-kvfabricnonprodcc001_280e76bc-5e4b-475a-80c8-ef6c0a1c803a"
    subresource_names               = ["vault"]
    network_interface_name          = null
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.vaultcore.azure.net"
    ]
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "NonProd"
    }
  }
}

private_endpoint_imports = {
  "storage_blob" = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/rg-fabric-nonprod-app-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-blob-stfabricnonprodcac001"
  "data_factory" = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/rg-fabric-nonprod-app-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-df-fabric-nonprod-canadacentral-001"
  "storage_dfs"  = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/rg-fabric-nonprod-app-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-dfs-stfabricnonprodcac001"
  "key_vault"    = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/rg-fabric-nonprod-siem-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-kvfabricnonprodcc001"
}

public_ip_prefix = {
  "fabric_nonprod" = {
    name               = "pip-ngw-fabric-nonprod-canadacentral-001"
    resource_group_key = "app"
    location           = "canadacentral"
    prefix_length      = 31
    sku_name           = "StandardV2"
    zones              = null
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "NonProd"
    }
  }
}

public_ip_prefix_imports = {
  "fabric_nonprod" = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/rg-fabric-nonprod-app-canadacentral-001/providers/Microsoft.Network/publicIPPrefixes/pip-ngw-fabric-nonprod-canadacentral-001"
}

storage_account = {
  "fabric_nonprod" = {
    name                            = "stfabricnonprodcac001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    account_tier                    = "Standard"
    account_replication_type        = "ZRS"
    access_tier                     = "Hot"
    allow_nested_items_to_be_public = false
    default_to_oauth_authentication = true
    is_hns_enabled                  = true
    public_network_access_enabled   = false
    blob_properties = {
      container_delete_retention_policy = { days = 14 }
      delete_retention_policy           = { days = 14 }
    }
    network_rules = {
      bypass         = ["AzureServices"]
      default_action = "Deny"
      ip_rules       = ["155.190.0.9"]
      private_link_access = [{
        endpoint_resource_id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourcegroups/Fabric/providers/Microsoft.Fabric/workspaces/30fde402-7155-4e42-aff2-4d75109e6400"
        endpoint_tenant_id   = "8fbb85e8-0cbc-48c3-a2e9-528cef30ec27"
      }]
    }
    share_properties = {
      retention_policy = {}
    }
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "NonProd"
    }
  }
}

storage_account_imports = {
  "fabric_nonprod" = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/rg-fabric-nonprod-app-canadacentral-001/providers/Microsoft.Storage/storageAccounts/stfabricnonprodcac001"
}

windows_virtual_machine = {
  "fabric_nonprod" = {
    name                                                   = "vm-fabric-nonprod-canadacentral-001"
    resource_group_key                                     = "app"
    location                                               = "canadacentral"
    size                                                   = "Standard_B4as_v2"
    zone                                                   = "1"
    admin_username                                         = "shiruser"
    computer_name                                          = "vm-fabric-nonpr"
    network_interface_ids                                  = ["/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/rg-fabric-nonprod-app-canadacentral-001/providers/Microsoft.Network/networkInterfaces/vm-fabric-nonprod-canadacentral-001870_z1"]
    os_managed_disk_id                                     = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/rg-fabric-nonprod-app-canadacentral-001/providers/Microsoft.Compute/disks/vm-fabric-nonprod-canadacentral-001_OsDisk_1_9603cbd42c3147ac8d56576c241a99db"
    allow_extension_operations                             = true
    automatic_updates_enabled                              = true
    bypass_platform_safety_checks_on_user_schedule_enabled = true
    disk_controller_type                                   = "SCSI"
    encryption_at_host_enabled                             = false
    license_type                                           = "Windows_Server"
    patch_assessment_mode                                  = "AutomaticByPlatform"
    patch_mode                                             = "AutomaticByPlatform"
    provision_vm_agent                                     = true
    secure_boot_enabled                                    = true
    vm_agent_platform_updates_enabled                      = true
    vtpm_enabled                                           = true
    additional_capabilities                                = {}
    boot_diagnostics                                       = {}
    identity                                               = { type = "SystemAssigned" }
    os_disk = {
      caching              = "ReadWrite"
      disk_size_gb         = 127
      name                 = "vm-fabric-nonprod-canadacentral-001_OsDisk_1_9603cbd42c3147ac8d56576c241a99db"
      storage_account_type = "Premium_LRS"
    }
    source_image_reference = {
      publisher = "MicrosoftWindowsServer"
      offer     = "WindowsServer"
      sku       = "2025-datacenter-g2"
      version   = "latest"
    }
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "NonProd"
    }
  }
}

windows_virtual_machine_imports = {
  "fabric_nonprod" = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/rg-fabric-nonprod-app-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-fabric-nonprod-canadacentral-001"
}

virtual_network = {
  "fabric_nonprod" = {
    name               = "vnet-fabric-nonprod-canadacentral-001"
    resource_group_key = "network"
    location           = "canadacentral"
    address_space      = ["10.195.127.0/24"]
    dns_servers = {
      dns_servers = ["10.195.1.4"]
    }
    ddos_protection_plan = {
      enable = true
      id     = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/ddosProtectionPlans/ddos-protection-plan"
    }
    encryption = {
      enabled     = false
      enforcement = "AllowUnencrypted"
    }
    subnets = {
      "app" = {
        name                                          = "snet-fabric-nonprod-app-canadacentral-001"
        address_prefixes                              = ["10.195.127.0/26"]
        default_outbound_access_enabled               = false
        private_endpoint_network_policies             = "Disabled"
        private_link_service_network_policies_enabled = true
        nat_gateway = {
          id = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/rg-fabric-nonprod-app-canadacentral-001/providers/Microsoft.Network/natGateways/ngw-fabric-nonprod-canadacentral-001"
        }
        service_endpoint_policies = {}
        service_endpoints_with_location = [{
          service   = "Microsoft.Storage"
          locations = ["canadacentral", "canadaeast"]
        }]
        delegations = []
      }
      "pep" = {
        name                                          = "snet-fabric-nonprod-pep-canadacentral-001"
        address_prefixes                              = ["10.195.127.128/26"]
        default_outbound_access_enabled               = false
        private_endpoint_network_policies             = "RouteTableEnabled"
        private_link_service_network_policies_enabled = true
        service_endpoint_policies                     = {}
        service_endpoints_with_location               = []
        delegations                                   = []
      }
      "vdg" = {
        name                                          = "snet-fabric-nonprod-vdg-canadacentral-001"
        address_prefixes                              = ["10.195.127.64/26"]
        default_outbound_access_enabled               = false
        private_endpoint_network_policies             = "Disabled"
        private_link_service_network_policies_enabled = true
        service_endpoint_policies                     = {}
        service_endpoints_with_location               = []
        delegations = [{
          name = "Microsoft.PowerPlatform/vnetaccesslinks"
          service_delegation = {
            name    = "Microsoft.PowerPlatform/vnetaccesslinks"
            actions = ["Microsoft.Network/virtualNetworks/subnets/join/action"]
          }
        }]
      }
    }
    tags = {
      CostCenterId = "YT-01860.S.IMP.DEV"
      Environment  = "NonProd"
    }
  }
}

virtual_network_imports = {
  "fabric_nonprod" = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/rg-fabric-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-nonprod-canadacentral-001"
}

virtual_network_subnet_imports = {
  "fabric_app" = {
    vnet_key   = "fabric_nonprod"
    subnet_key = "app"
    id         = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/rg-fabric-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-nonprod-canadacentral-001/subnets/snet-fabric-nonprod-app-canadacentral-001"
  }
  "fabric_pep" = {
    vnet_key   = "fabric_nonprod"
    subnet_key = "pep"
    id         = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/rg-fabric-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-nonprod-canadacentral-001/subnets/snet-fabric-nonprod-pep-canadacentral-001"
  }
  "fabric_vdg" = {
    vnet_key   = "fabric_nonprod"
    subnet_key = "vdg"
    id         = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/rg-fabric-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-nonprod-canadacentral-001/subnets/snet-fabric-nonprod-vdg-canadacentral-001"
  }
}

# =====================================================================
# Hub private DNS: links and records in the shared zones (connectivity subscription)
# =====================================================================

enable_hub_private_dns = true

hub_private_dns_zone_link = {
  "link-fabric-nonprod-canadacentral-001" = {
    name               = "link-fabric-nonprod-canadacentral-001"
    zone_name          = "bchydro.bc.ca"
    virtual_network_id = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/rg-fabric-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-nonprod-canadacentral-001"
  }
  "privatelink.blob.core.windows.net/link-vnet-fabric-nonprod-canadacentral-001" = {
    name               = "link-vnet-fabric-nonprod-canadacentral-001"
    zone_name          = "privatelink.blob.core.windows.net"
    virtual_network_id = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/rg-fabric-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-nonprod-canadacentral-001"
  }
  "privatelink.datafactory.azure.net/link-vnet-fabric-nonprod-canadacentral-001" = {
    name               = "link-vnet-fabric-nonprod-canadacentral-001"
    zone_name          = "privatelink.datafactory.azure.net"
    virtual_network_id = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/rg-fabric-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-nonprod-canadacentral-001"
  }
  "privatelink.dfs.core.windows.net/link-vnet-fabric-nonprod-canadacentral-001" = {
    name               = "link-vnet-fabric-nonprod-canadacentral-001"
    zone_name          = "privatelink.dfs.core.windows.net"
    virtual_network_id = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/rg-fabric-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-nonprod-canadacentral-001"
  }
  "privatelink.vaultcore.azure.net/link-vnet-fabric-nonprod-canadacentral-001" = {
    name               = "link-vnet-fabric-nonprod-canadacentral-001"
    zone_name          = "privatelink.vaultcore.azure.net"
    virtual_network_id = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/rg-fabric-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-nonprod-canadacentral-001"
  }
}

hub_private_dns_zone_link_imports = {
  "link-fabric-nonprod-canadacentral-001"                                        = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/bchydro.bc.ca/virtualNetworkLinks/link-fabric-nonprod-canadacentral-001"
  "privatelink.blob.core.windows.net/link-vnet-fabric-nonprod-canadacentral-001" = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net/virtualNetworkLinks/link-vnet-fabric-nonprod-canadacentral-001"
  "privatelink.datafactory.azure.net/link-vnet-fabric-nonprod-canadacentral-001" = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.datafactory.azure.net/virtualNetworkLinks/link-vnet-fabric-nonprod-canadacentral-001"
  "privatelink.dfs.core.windows.net/link-vnet-fabric-nonprod-canadacentral-001"  = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.dfs.core.windows.net/virtualNetworkLinks/link-vnet-fabric-nonprod-canadacentral-001"
  "privatelink.vaultcore.azure.net/link-vnet-fabric-nonprod-canadacentral-001"   = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.vaultcore.azure.net/virtualNetworkLinks/link-vnet-fabric-nonprod-canadacentral-001"
}
