module "monitoring" {
  count = var.enable_monitoring ? 1 : 0

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-ptn-monitoring-amba-alz/azurerm"
  version = "0.3.3"

  enable_amba              = false
  enable_governance_alerts = false
  enable_telemetry         = false

  location                   = module.resource_group[var.alert.resource_group_key].location
  root_management_group_name = var.alert.root_management_group_name

  action_groups       = {}
  metric_alerts       = {}
  activity_log_alerts = var.alert.activity_log_alerts
  log_search_alerts   = {}
  tags                = var.alert.tags

  depends_on = [module.resource_group]
}

import {
  for_each = var.enable_monitoring ? var.activity_log_alert_imports : {}

  to = module.monitoring[0].azurerm_monitor_activity_log_alert.this[each.key]
  id = each.value
}