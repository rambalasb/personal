module "fabric_capacity" {
  for_each = var.enable_fabric_capacity ? var.fabric_capacity : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-fabric-capacity/azurerm"
  version = "0.0.1"

  administration_members = each.value.administration_members
  location               = coalesce(each.value.location, module.resource_group[each.value.resource_group_key].location)
  name                   = each.value.name
  parent_id              = module.resource_group[each.value.resource_group_key].resource_id
  sku_name               = each.value.sku_name
  tags                   = each.value.tags

  enable_telemetry     = false
  wrapper_tags_enabled = false
  lock                 = null
  role_assignments     = {}
}

import {
  for_each = var.enable_fabric_capacity ? var.fabric_capacity_imports : {}

  to = module.fabric_capacity[each.key].module.fabric_capacity.azapi_resource.this
  id = "${each.value}?api-version=2023-11-01"
}