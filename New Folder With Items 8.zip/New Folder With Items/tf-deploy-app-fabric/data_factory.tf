module "data_factory" {
  for_each = var.enable_data_factory ? var.data_factory : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-data-factory/azurerm"
  version = "0.1.0"

  name                            = each.value.name
  resource_group_name             = module.resource_group[each.value.resource_group_key].name
  location                        = coalesce(each.value.location, module.resource_group[each.value.resource_group_key].location)
  managed_identities              = each.value.managed_identities
  public_network_enabled          = each.value.public_network_enabled
  managed_virtual_network_enabled = each.value.managed_virtual_network_enabled
  tags                            = each.value.tags

  customer_managed_key_id          = null
  customer_managed_key_identity_id = null
  github_configuration             = null
  vsts_configuration               = null
  global_parameters                = []
  purview_id                       = null

  credential_service_principal          = {}
  credential_user_managed_identity      = {}
  integration_runtime_self_hosted       = {}
  linked_service_azure_blob_storage     = {}
  linked_service_azure_file_storage     = {}
  linked_service_azure_sql_database     = {}
  linked_service_data_lake_storage_gen2 = {}
  linked_service_databricks             = {}
  linked_service_key_vault              = {}
  diagnostic_settings                   = {}
  private_endpoints                     = {}
  role_assignments                      = {}
  lock                                  = null
  enable_telemetry                      = false
}

import {
  for_each = var.enable_data_factory ? var.data_factory_imports : {}

  to = module.data_factory[each.key].module.data_factory.azurerm_data_factory.this
  id = each.value
}