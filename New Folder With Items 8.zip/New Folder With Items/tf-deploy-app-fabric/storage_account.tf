resource "azurerm_storage_account" "this" {
  for_each = var.enable_storage_account ? var.storage_account : {}

  name                            = each.value.name
  resource_group_name             = module.resource_group[each.value.resource_group_key].name
  location                        = coalesce(each.value.location, module.resource_group[each.value.resource_group_key].location)
  account_tier                    = each.value.account_tier
  account_replication_type        = each.value.account_replication_type
  access_tier                     = each.value.access_tier
  allow_nested_items_to_be_public = each.value.allow_nested_items_to_be_public
  default_to_oauth_authentication = each.value.default_to_oauth_authentication
  is_hns_enabled                  = each.value.is_hns_enabled
  public_network_access_enabled   = each.value.public_network_access_enabled
  shared_access_key_enabled       = each.value.shared_access_key_enabled
  tags                            = each.value.tags

  blob_properties {
    container_delete_retention_policy {
      days = each.value.blob_properties.container_delete_retention_policy.days
    }
    delete_retention_policy {
      days = each.value.blob_properties.delete_retention_policy.days
    }
  }

  network_rules {
    bypass                     = each.value.network_rules.bypass
    default_action             = each.value.network_rules.default_action
    ip_rules                   = each.value.network_rules.ip_rules
    virtual_network_subnet_ids = each.value.network_rules.virtual_network_subnet_ids

    dynamic "private_link_access" {
      for_each = each.value.network_rules.private_link_access
      content {
        endpoint_resource_id = private_link_access.value.endpoint_resource_id
        endpoint_tenant_id   = private_link_access.value.endpoint_tenant_id
      }
    }
  }

  share_properties {
    dynamic "retention_policy" {
      for_each = each.value.share_properties.retention_policy == null ? [] : [each.value.share_properties.retention_policy]
      content {
        days = retention_policy.value.days
      }
    }
  }
}

import {
  for_each = var.enable_storage_account ? var.storage_account_imports : {}

  to = azurerm_storage_account.this[each.key]
  id = each.value
}