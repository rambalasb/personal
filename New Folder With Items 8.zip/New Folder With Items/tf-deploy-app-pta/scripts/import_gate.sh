#!/usr/bin/env bash
# The import zero-diff gate, shared by import-verify.yml and import-apply.yml so
# the plan that gets applied passes exactly the check that was reviewed.
#
# Usage: import_gate.sh <env> <plan.json>
set -eo pipefail
ENV_NAME="${1:?usage: import_gate.sh <env> <plan.json>}"
PLAN="${2:?usage: import_gate.sh <env> <plan.json>}"
HERE="$(cd "$(dirname "$0")" && pwd)"

# Reviewed: AVM 0.10.0 rewrites the storage account body on adoption
# with no setting change (README, "Things to check before the first
# import"). Prod accounts need their own review before being added.
allow=()
if [ "$ENV_NAME" = "nonprod" ]; then
  for key in app testing; do
    allow+=(--allow-resource "module.storage_account[\"$key\"].module.storage_account.azapi_resource.this")
  done
  # Import leaves local_authentication_enabled null; live disableLocalAuth
  # is null (local auth on), so writing true changes nothing.
  allow+=(--allow-resource "module.log_analytics_workspace[\"default_cca\"].module.log_analytics_workspace.azurerm_log_analytics_workspace.this")
  # AVM always writes monitoringSettings (null live) and drops fields the
  # vault already holds at their defaults; tfvars keeps alerting off.
  allow+=(--allow-resource "module.recovery_services_vault[\"app\"].module.recovery_services_vault.azapi_resource.this")
  # ag-connectivity-canadacentral-001 no longer exists; repointed to the
  # mail action group the other VM CPU alerts use. Alert stays disabled.
  allow+=(--allow-resource "module.monitoring[0].azurerm_monitor_metric_alert.this[\"sub_pta_nonprod_vm_cpu_usage_alert_canadacentral\"]")
fi
bash "$HERE/verify_zero_diff.sh" "$PLAN" "${allow[@]}" \
  --ignore-attr response_export_values \
  --ignore-attr retry \
  --ignore-attr timeouts \
  --ignore-attr ignore_null_property \
  --ignore-attr ignore_casing \
  --ignore-attr ignore_missing_property \
  --ignore-attr schema_validation_enabled \
  --subset-attr body \
  --ignore-type time_sleep \
  --ignore-type random_uuid \
  --ignore-type modtm_telemetry
