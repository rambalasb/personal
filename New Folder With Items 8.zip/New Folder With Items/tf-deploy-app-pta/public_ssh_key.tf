module "public_ssh_key" {
  for_each = var.enable_public_ssh_key ? var.public_ssh_key : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-public-ssh-key/azurerm"
  version = "0.1.0"

  name                = each.value.name
  resource_group_name = module.resource_group[each.value.resource_group_key].name
  location            = coalesce(each.value.location, module.resource_group[each.value.resource_group_key].location)
  public_key          = each.value.public_key
  tags                = each.value.tags

  role_assignments = {}
  lock             = null
  enable_telemetry = false
}

import {
  for_each = var.enable_public_ssh_key ? var.public_ssh_key_imports : {}

  to = module.public_ssh_key[each.key].module.public_ssh_key.azurerm_ssh_public_key.this
  id = each.value
}
