# Prod subscription (9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4)
# Values come from the Azure resource export of 2026-10-20.
# VMs, web apps and the VNet are off for the first apply; see "Staged adoption"
# in the README.

subscription_id = "9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4"

enable_bastion_host             = true
enable_event_grid_system_topic  = true
enable_key_vault                = true
enable_log_analytics_workspace  = true
enable_monitoring               = true
enable_network_interface        = false
enable_network_security_group   = true
enable_network_watcher          = true
enable_private_endpoint         = true
enable_public_ssh_key           = false
enable_recovery_services_vault  = true
enable_resource_group           = true
enable_restore_point_collection = true
enable_sql_server               = false
enable_storage_account          = true
enable_user_assigned_identity   = true
enable_virtual_network          = false
enable_windows_virtual_machine  = false

enable_bastion_host_role_assignment             = false
enable_event_grid_system_topic_role_assignment  = false
enable_key_vault_role_assignment                = false
enable_log_analytics_workspace_role_assignment  = false
enable_monitoring_role_assignment               = false
enable_network_interface_role_assignment        = false
enable_network_security_group_role_assignment   = false
enable_network_watcher_role_assignment          = false
enable_private_endpoint_role_assignment         = false
enable_public_ssh_key_role_assignment           = false
enable_recovery_services_vault_role_assignment  = false
enable_resource_group_role_assignment           = false
enable_restore_point_collection_role_assignment = false
enable_sql_server_role_assignment               = false
enable_storage_account_role_assignment          = false
enable_user_assigned_identity_role_assignment   = false
enable_virtual_network_role_assignment          = false
enable_windows_virtual_machine_role_assignment  = false

role_assignments = {}

resource_group = {
  network_watcher = {
    name     = "NetworkWatcherRG"
    location = "canadacentral"
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Property Tax and Assessment"
    }
  }
  app = {
    name     = "rg-pta-app-prod-canadacentral-001"
    location = "canadacentral"
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Property Tax and Assessment"
    }
  }
  mid_app = {
    name     = "rg-mid-pta-app-prod-canadacentral-001"
    location = "canadacentral"
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Property Tax and Assessment"
    }
  }
  defaultresourcegroup_cca = {
    name     = "defaultresourcegroup-cca"
    location = "canadacentral"
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Property Tax and Assessment"
    }
  }
}

import_resource_group = {
  network_watcher          = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/NetworkWatcherRG"
  app                      = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001"
  mid_app                  = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-mid-pta-app-prod-canadacentral-001"
  defaultresourcegroup_cca = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/defaultresourcegroup-cca"
}

# Some action group IDs may contain a leading space in the group name; kept as exported.
alert = {
  resource_group_key         = "app"
  root_management_group_name = null
  tags                       = {}
  activity_log_alerts = {
    keyvault_deletion_alert = {
      name                = "KeyVault-deletion-alert"
      resource_group_name = "rg-pta-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvptaprodcac001"
      ]
      location    = "global"
      description = "This alert will monitor any deletion of key vault"
      enabled     = true
      criteria = {
        category       = "Administrative"
        operation_name = "Microsoft.KeyVault/vaults/delete"
      }
      action_group_keys = []
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      webhook_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001597"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Capital Infrastructure Project Delivery"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Property Tax and Assessment"
      }
    }
    service_outage_alert = {
      name                = "Service-Outage-Alert-canadacentral"
      resource_group_name = "rg-pta-app-prod-canadacentral-001"
      scopes              = ["/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4"]
      location            = "global"
      description         = "Azure Landing Zone Service Health Alert"
      enabled             = true
      criteria = {
        category = "ServiceHealth"
        service_health = {
          locations = ["Global"]
        }
      }
      action_group_keys = []
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-pta-mail-alerts-canadacentral-001"
      ]
      webhook_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001597"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Capital Infrastructure Project Delivery"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Property Tax and Assessment"
      }
    }
  }
  metric_alerts = {
    backup_alert = {
      name                = "backup-alert"
      resource_group_name = "rg-pta-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.RecoveryServices/vaults/defaultVault775"
      ]
      description              = ""
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT15M"
      window_size              = "PT6H"
      severity                 = 3
      target_resource_type     = "Microsoft.RecoveryServices/vaults"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.RecoveryServices/vaults"
          metric_name            = "BackupHealthEvent"
          aggregation            = "Count"
          operator               = "GreaterThan"
          threshold              = 0
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actionGroups/ag-monitor-mail-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001597"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Capital Infrastructure Project Delivery"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Property Tax and Assessment"
      }
    }
    mi_sql_cpu_high_alert_canadacentral = {
      name                = "MI-SQL-CPU-High-Alert-canadacentral"
      resource_group_name = "rg-pta-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Sql/managedInstances/mi-sql-pta-prod-canadacentral-001"
      ]
      description              = "Alert triggered when SQL server CPU is > 80%"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 1
      target_resource_type     = "Microsoft.Sql/managedInstances"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Sql/managedInstances"
          metric_name            = "avg_cpu_percent"
          aggregation            = "Maximum"
          operator               = "GreaterThan"
          threshold              = 80
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001",
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-db-mail-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001597"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Capital Infrastructure Project Delivery"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Property Tax and Assessment"
      }
    }
    vm_heartbeat_lost_alert_pta_prod_canadacentral = {
      name                = "vm-heartbeat-lost-alert-PTA-Prod-CanadaCentral"
      resource_group_name = "rg-pta-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/defaultresourcegroup-cca/providers/microsoft.operationalinsights/workspaces/defaultworkspace-9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4-cca"
      ]
      description              = "This alert will be triggered when VM state is unhealthy for more than 5min"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 0
      target_resource_type     = "microsoft.operationalinsights/workspaces"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "microsoft.operationalinsights/workspaces"
          metric_name            = "Heartbeat"
          aggregation            = "Total"
          operator               = "LessThan"
          threshold              = 2
          skip_metric_validation = false
          dimensions = [
            {
              name     = "Computer"
              operator = "Include"
              values   = ["vm-pta-prod-canadacentral-001"]
            }
          ]
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001597"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Capital Infrastructure Project Delivery"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Property Tax and Assessment"
      }
    }
    vm_os_disk_iops_alert_canadacentral = {
      name                     = "VM-OS-Disk-IOPs-Alert-Canadacentral"
      resource_group_name      = "NetworkWatcherRG"
      scopes                   = ["/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4"]
      description              = "Action will be triggered when Disk IOPS is high"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 2
      target_resource_type     = "microsoft.compute/virtualmachines"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "microsoft.compute/virtualmachines"
          metric_name            = "OS Disk IOPS Consumed Percentage"
          aggregation            = "Average"
          operator               = "GreaterThan"
          threshold              = 75
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-monitor-mail-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001597"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Capital Infrastructure Project Delivery"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Property Tax and Assessment"
      }
    }
    vm_pta_prod_cpu_high_warning = {
      name                = "vm-pta-prod-cpu-high-warning"
      resource_group_name = "rg-pta-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/RG-PTA-APP-PROD-CANADACENTRAL-001/providers/Microsoft.Compute/virtualMachines/VM-PTA-PROD-CANADACENTRAL-001"
      ]
      description              = "Action will be triggered when percentage CPU for VM is greater than 80%"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 2
      target_resource_type     = "Microsoft.Compute/virtualMachines"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Compute/virtualMachines"
          metric_name            = "Percentage CPU"
          aggregation            = "Average"
          operator               = "GreaterThan"
          threshold              = 80
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/lga-servicenow-integration_group/providers/microsoft.insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001597"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Capital Infrastructure Project Delivery"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Property Tax and Assessment"
      }
    }
    vm_pta_prod_memory_high_warning = {
      name                = "vm-pta-prod-memory-high-warning"
      resource_group_name = "rg-pta-app-prod-canadacentral-001"
      scopes = [
        "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/RG-PTA-APP-PROD-CANADACENTRAL-001/providers/Microsoft.Compute/virtualMachines/VM-PTA-PROD-CANADACENTRAL-001"
      ]
      description              = "Action will be triggered when percentage memory for VM is greater than 80%"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 2
      target_resource_type     = "Microsoft.Compute/virtualMachines"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Compute/virtualMachines"
          metric_name            = "Available Memory Percentage"
          aggregation            = "Average"
          operator               = "LessThanOrEqual"
          threshold              = 20
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/lga-servicenow-integration_group/providers/microsoft.insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001597"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Capital Infrastructure Project Delivery"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Property Tax and Assessment"
      }
    }
  }
  log_search_alerts = {
    keyvault_nearexpiry_alert_canadacentral = {
      name                = "KeyVault-NearExpiry-Alert-CanadaCentral"
      resource_group_name = "rg-pta-app-prod-canadacentral-001"
      location            = "canadacentral"
      scopes = [
        "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvptaprodcac001"
      ]
      severity                          = 1
      evaluation_frequency              = "PT5M"
      window_duration                   = "PT30M"
      description                       = "Alert for secret in a Key Vault is about to expire."
      display_name                      = "KeyVault-NearExpiry-Alert-CanadaCentral"
      enabled                           = true
      auto_mitigation_enabled           = false
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = null
      target_resource_types             = ["Microsoft.KeyVault/vaults"]
      criteria = [
        {
          query                   = "AzureDiagnostics\n| where ResourceProvider == \"MICROSOFT.KEYVAULT\"\n| where OperationName contains \"SecretNearExpiry\"\n"
          time_aggregation_method = "Count"
          threshold               = 1
          operator                = "GreaterThanOrEqual"
          resource_id_column      = null
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-monitor-mail-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001597"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Capital Infrastructure Project Delivery"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Property Tax and Assessment"
      }
    }
    keyvault_secret_expired_alert_canadacentral = {
      name                = "KeyVault-Secret-Expired-Alert-CanadaCentral"
      resource_group_name = "rg-pta-app-prod-canadacentral-001"
      location            = "canadacentral"
      scopes = [
        "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvptaprodcac001"
      ]
      severity                          = 0
      evaluation_frequency              = "PT5M"
      window_duration                   = "PT30M"
      description                       = "Alert for expired secret in a Key Vault."
      display_name                      = "KeyVault-Secret-Expired-Alert-CanadaCentral"
      enabled                           = true
      auto_mitigation_enabled           = false
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = null
      target_resource_types             = ["Microsoft.KeyVault/vaults"]
      criteria = [
        {
          query                   = "AzureDiagnostics\n| where ResourceProvider == \"MICROSOFT.KEYVAULT\"\n| where OperationName contains \"SecretExpired\"\n"
          time_aggregation_method = "Count"
          threshold               = 1
          operator                = "GreaterThanOrEqual"
          resource_id_column      = null
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001597"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Capital Infrastructure Project Delivery"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Property Tax and Assessment"
      }
    }
    resource_creation_alert_canadacentral = {
      name                              = "Resource-Creation-Alert-CanadaCentral"
      resource_group_name               = "NetworkWatcherRG"
      location                          = "canadacentral"
      scopes                            = ["/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4"]
      severity                          = 4
      evaluation_frequency              = "PT10M"
      window_duration                   = "PT30M"
      description                       = "Alert when a new resource is created."
      display_name                      = "Resource-Creation-Alert-CanadaCentral"
      enabled                           = true
      auto_mitigation_enabled           = false
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = null
      target_resource_types             = null
      criteria = [
        {
          query                   = "AzureActivity\n        | where OperationNameValue has \"Microsoft.Resources/deployments/write\"\n        | where CategoryValue == \"Administrative\"\n        | where ActivityStatusValue == \"Success\"\n"
          time_aggregation_method = "Count"
          threshold               = 10
          operator                = "GreaterThan"
          resource_id_column      = "_ResourceId"
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-monitor-mail-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001597"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Capital Infrastructure Project Delivery"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "prod"
        Name                    = "Property Tax and Assessment"
      }
    }
    storage_account_container_deletion_alert_canadacentral = {
      name                              = "Storage-Account-Container-deletion-alert-Canadacentral"
      resource_group_name               = "rg-pta-app-prod-canadacentral-001"
      location                          = "canadacentral"
      scopes                            = ["/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4"]
      severity                          = 0
      evaluation_frequency              = "PT5M"
      window_duration                   = "PT30M"
      description                       = "Alert for the deletion of Storage Account Container."
      display_name                      = "Storage-Account-Container-deletion-alert-Canadacentral"
      enabled                           = true
      auto_mitigation_enabled           = false
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = null
      target_resource_types             = ["microsoft.storage/storageaccounts"]
      criteria = [
        {
          query                   = "AzureActivity\n        | where ResourceProviderValue == \"MICROSOFT.STORAGE\" and OperationNameValue == \"MICROSOFT.STORAGE/STORAGEACCOUNTS/BLOBSERVICES/CONTAINERS/DELETE\"\n"
          time_aggregation_method = "Count"
          threshold               = 1
          operator                = "GreaterThan"
          resource_id_column      = "_ResourceId"
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001597"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Capital Infrastructure Project Delivery"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "prod"
        Name                    = "Property Tax and Assessment"
      }
    }
    storage_account_deletion_alert_canadacentral = {
      name                              = "Storage-Account-Deletion-Alert-CanadaCentral"
      resource_group_name               = "rg-pta-app-prod-canadacentral-001"
      location                          = "canadacentral"
      scopes                            = ["/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4"]
      severity                          = 0
      evaluation_frequency              = "PT5M"
      window_duration                   = "PT30M"
      description                       = "Alert for the deletion of Storage Account."
      display_name                      = "Storage-Account-Deletion-Alert-CanadaCentral"
      enabled                           = true
      auto_mitigation_enabled           = false
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = null
      target_resource_types             = ["microsoft.storage/storageaccounts"]
      criteria = [
        {
          query                   = " AzureActivity\n        | where ResourceProviderValue == \"MICROSOFT.STORAGE\" and OperationNameValue == \"MICROSOFT.STORAGE/STORAGEACCOUNTS/DELETE\"\n"
          time_aggregation_method = "Count"
          threshold               = 1
          operator                = "GreaterThan"
          resource_id_column      = "_ResourceId"
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001597"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Capital Infrastructure Project Delivery"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "prod"
        Name                    = "Property Tax and Assessment"
      }
    }
    vm_backup_failure_alert_canadacentral = {
      name                = "VM-Backup-Failure-Alert-canadacentral"
      resource_group_name = "rg-pta-app-prod-canadacentral-001"
      location            = "canadacentral"
      scopes = [
        "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourcegroups/rg-pta-app-prod-canadacentral-001"
      ]
      severity                          = 1
      evaluation_frequency              = "PT10M"
      window_duration                   = "PT30M"
      description                       = "Alert triggered when there is a VM Backup failure"
      display_name                      = "VM-Backup-Failure-Alert-canadacentral"
      enabled                           = true
      auto_mitigation_enabled           = false
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = null
      target_resource_types             = ["microsoft.compute/virtualmachines"]
      criteria = [
        {
          query                   = "        AzureDiagnostics\n| where Category == \"AzureBackupReport\"\n| where OperationName == \"Job\"\n| where ResultType != \"Success\"\n\n"
          time_aggregation_method = "Count"
          threshold               = 1
          operator                = "GreaterThanOrEqual"
          resource_id_column      = "_ResourceId"
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/lga-servicenow-integration_group/providers/microsoft.insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001597"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Capital Infrastructure Project Delivery"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Property Tax and Assessment"
      }
    }
    vm_free_disk_space_pta_prod_alert_canadacentral = {
      name                = "VM-Free-Disk-Space-PTA-prod-Alert-canadacentral"
      resource_group_name = "rg-pta-app-prod-canadacentral-001"
      location            = "canadacentral"
      scopes = [
        "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/RG-PTA-APP-PROD-CANADACENTRAL-001/providers/Microsoft.Compute/virtualMachines/VM-PTA-PROD-CANADACENTRAL-001"
      ]
      severity                          = 2
      evaluation_frequency              = "PT5M"
      window_duration                   = "PT5M"
      description                       = "Triggered when disk space has consumed >85%"
      display_name                      = "VM-Free-Disk-Space-PTA-prod-Alert-canadacentral"
      enabled                           = true
      auto_mitigation_enabled           = false
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = null
      target_resource_types             = ["Microsoft.Compute/virtualMachines"]
      criteria = [
        {
          query                   = "Perf\n| where TimeGenerated > ago(15m)\n| where ObjectName in (\"LogicalDisk\", \"Logical Disk\")\n| where CounterName == \"% Free Space\"\n| where InstanceName == \"_Total\"\n| summarize \n    FreePercent = avg(CounterValue),\n    TimeGenerated = max(TimeGenerated)\n  by Computer\n| extend UsedPercent = round(100 - FreePercent, 2)\n| where UsedPercent >= 85\n| project TimeGenerated, Computer, UsedPercent\n"
          time_aggregation_method = "Count"
          threshold               = 1
          operator                = "GreaterThan"
          resource_id_column      = null
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/lga-servicenow-integration_group/providers/microsoft.insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001597"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Capital Infrastructure Project Delivery"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Property Tax and Assessment"
      }
    }
    vm_windows_syslog_alert_prod_canadacentral = {
      name                              = "vm-windows-syslog-alert-Prod-Canadacentral"
      resource_group_name               = "NetworkWatcherRG"
      location                          = "canadacentral"
      scopes                            = ["/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4"]
      severity                          = 3
      evaluation_frequency              = "PT5M"
      window_duration                   = "PT5M"
      description                       = "Triigered when there is a event for syslog error"
      display_name                      = "vm-windows-syslog-alert-Prod-Canadacentral"
      enabled                           = false
      auto_mitigation_enabled           = false
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = "P2D"
      target_resource_types             = ["microsoft.compute/virtualmachines"]
      criteria = [
        {
          query                   = "union Event, Syslog // Event table stores Windows event records, Syslog stores Linux records\n| where TimeGenerated > ago(1h)\n| where EventLevelName == \"Error\" // EventLevelName is used in the Event (Windows) records\nor SeverityLevel== \"err\" // SeverityLevel is used in Syslog (Linux) records\n"
          time_aggregation_method = "Count"
          threshold               = 1
          operator                = "GreaterThan"
          resource_id_column      = "_ResourceId"
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-monitor-mail-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001597"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Capital Infrastructure Project Delivery"
        CostCenterId            = " YT-01585.S.IMP.CLZ"
        Environment             = "Prod"
        Name                    = "Property Tax and Assessment"
      }
    }
  }
  alert_processing_rules = {}
}

activity_log_alert_imports = {
  keyvault_deletion_alert = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/KeyVault-deletion-alert"
  service_outage_alert    = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/Service-Outage-Alert-canadacentral"
}

metric_alert_imports = {
  backup_alert                                   = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/backup-alert"
  mi_sql_cpu_high_alert_canadacentral            = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/MI-SQL-CPU-High-Alert-canadacentral"
  vm_heartbeat_lost_alert_pta_prod_canadacentral = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/vm-heartbeat-lost-alert-PTA-Prod-CanadaCentral"
  vm_os_disk_iops_alert_canadacentral            = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/NetworkWatcherRG/providers/Microsoft.Insights/metricAlerts/VM-OS-Disk-IOPs-Alert-Canadacentral"
  vm_pta_prod_cpu_high_warning                   = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/vm-pta-prod-cpu-high-warning"
  vm_pta_prod_memory_high_warning                = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/vm-pta-prod-memory-high-warning"
}

log_search_alert_imports = {
  keyvault_nearexpiry_alert_canadacentral                = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/KeyVault-NearExpiry-Alert-CanadaCentral"
  keyvault_secret_expired_alert_canadacentral            = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/KeyVault-Secret-Expired-Alert-CanadaCentral"
  resource_creation_alert_canadacentral                  = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/NetworkWatcherRG/providers/Microsoft.Insights/scheduledQueryRules/Resource-Creation-Alert-CanadaCentral"
  storage_account_container_deletion_alert_canadacentral = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/Storage-Account-Container-deletion-alert-Canadacentral"
  storage_account_deletion_alert_canadacentral           = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/Storage-Account-Deletion-Alert-CanadaCentral"
  vm_backup_failure_alert_canadacentral                  = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/VM-Backup-Failure-Alert-canadacentral"
  vm_free_disk_space_pta_prod_alert_canadacentral        = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/VM-Free-Disk-Space-PTA-prod-Alert-canadacentral"
  vm_windows_syslog_alert_prod_canadacentral             = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/NetworkWatcherRG/providers/Microsoft.Insights/scheduledQueryRules/vm-windows-syslog-alert-Prod-Canadacentral"
}

# Not managed here:
#   actionrules 'alert suppression for PTA apps' (rg-pta-app-prod-canadacentral-001): azurerm rejects processing rule names with spaces; rename it in Azure to manage it
#   actionrules 'Alert suppression for PTA mid-app' (rg-mid-pta-app-prod-canadacentral-001): azurerm rejects processing rule names with spaces; rename it in Azure to manage it
#   scheduledqueryrules ' VM-OS-Patch-Available-PTA-prod-Alert-canadacentral' (rg-pta-app-prod-canadacentral-001): SystemAssigned identity (the wrapper has no identity input)
#   scheduledqueryrules 'AUMAlertRule_20260318T210036108Z' (AzureBackupRG_canadacentral_1): SystemAssigned identity (the wrapper has no identity input)
#   scheduledqueryrules 'vm-heartbeat-lost-alert-PTA-Prod-CanadaCentral' (rg-pta-app-prod-canadacentral-001): LogToMetric rule (legacy; not supported by scheduled query rules v2)
#   scheduledqueryrules 'VM-Pending-Update-PTA-Prod-canadacentral' (rg-pta-app-prod-canadacentral-001): SystemAssigned identity (the wrapper has no identity input)
#   activitylogalerts 'App-Health-Alert-canadacentral' (rg-pta-app-prod-canadacentral-001): criteria the wrapper cannot express
#   activitylogalerts 'VM-OS-Patch-Available-PTA-Alert-canadacentral' (rg-pta-app-prod-canadacentral-001): criteria the wrapper cannot express
alert_processing_rule_imports = {}

# Standard bastions reuse their existing public IP; the public IP itself is not managed.
bastion_host = {
  app = {
    name               = "vnet-pta-prod-canadacentral-001-bastion"
    resource_group_key = "app"
    location           = "canadacentral"
    sku                = "Standard"
    scale_units        = 2
    zones              = ["2", "3", "1"]
    ip_configuration = {
      name                 = "IpConf"
      subnet_id            = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-prod-canadacentral-001/subnets/AzureBastionSubnet"
      public_ip_address_id = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/publicIPAddresses/vnetptaprodcanadacentral001IPv4979"
    }
    copy_paste_enabled        = true
    file_copy_enabled         = false
    ip_connect_enabled        = false
    kerberos_enabled          = false
    shareable_link_enabled    = false
    tunneling_enabled         = false
    session_recording_enabled = false
    private_only_enabled      = false
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Property Tax and Assessment"
    }
  }
}

bastion_host_imports = {
  app = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/bastionHosts/vnet-pta-prod-canadacentral-001-bastion"
}

event_grid_system_topic = {
  sqlvahnwiqbvli57nk_storage = {
    name                        = "sqlvahnwiqbvli57nk-71bf5eed-4bf0-4c94-aa57-3ba7685d17b8"
    resource_group_key          = "app"
    location                    = "canadacentral"
    topic_type                  = "microsoft.storage.storageaccounts"
    source_resource_id          = null
    exported_source_resource_id = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/microsoft.storage/storageaccounts/sqlvahnwiqbvli57nk"
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Property Tax and Assessment"
    }
  }
  stnwptaprdcac001xdf_storage = {
    name                        = "stnwptaprdcac001xdf-2fe9cd5b-54f7-448d-b4c6-384f16b31c80"
    resource_group_key          = "network_watcher"
    location                    = "canadacentral"
    topic_type                  = "microsoft.storage.storageaccounts"
    source_resource_id          = null
    exported_source_resource_id = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/networkwatcherrg/providers/microsoft.storage/storageaccounts/stnwptaprdcac001xdf"
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Property Tax and Assessment"
    }
  }
  stptaprodcac001_storage = {
    name                        = "stptaprodcac001-ffed8d24-99fb-4210-b426-827da0a42d5c"
    resource_group_key          = "app"
    location                    = "canadacentral"
    topic_type                  = "microsoft.storage.storageaccounts"
    source_resource_id          = null
    exported_source_resource_id = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/microsoft.storage/storageaccounts/stptaprodcac001"
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Property Tax and Assessment"
    }
  }
  stptaprodcac002_storage = {
    name                        = "stptaprodcac002-d9d39e61-8e5f-43fb-9185-ce6422ab94d8"
    resource_group_key          = "app"
    location                    = "canadacentral"
    topic_type                  = "microsoft.storage.storageaccounts"
    source_resource_id          = null
    exported_source_resource_id = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/microsoft.storage/storageaccounts/stptaprodcac002"
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Property Tax and Assessment"
    }
  }
}

event_grid_system_topic_imports = {
  sqlvahnwiqbvli57nk_storage  = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.EventGrid/systemTopics/sqlvahnwiqbvli57nk-71bf5eed-4bf0-4c94-aa57-3ba7685d17b8"
  stnwptaprdcac001xdf_storage = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/NetworkWatcherRG/providers/Microsoft.EventGrid/systemTopics/stnwptaprdcac001xdf-2fe9cd5b-54f7-448d-b4c6-384f16b31c80"
  stptaprodcac001_storage     = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.EventGrid/systemTopics/stptaprodcac001-ffed8d24-99fb-4210-b426-827da0a42d5c"
  stptaprodcac002_storage     = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.EventGrid/systemTopics/stptaprodcac002-d9d39e61-8e5f-43fb-9185-ce6422ab94d8"
}

key_vault = {
  app = {
    name                            = "kvptaprodcac001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    tenant_id                       = "8fbb85e8-0cbc-48c3-a2e9-528cef30ec27"
    sku_name                        = "premium"
    enabled_for_deployment          = true
    enabled_for_disk_encryption     = true
    enabled_for_template_deployment = true
    legacy_access_policies_enabled  = false
    public_network_access_enabled   = false
    purge_protection_enabled        = true
    soft_delete_retention_days      = 90
    network_acls = {
      bypass                     = "AzureServices"
      default_action             = "Deny"
      ip_rules                   = []
      virtual_network_subnet_ids = []
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Property Tax and Assessment"
    }
  }
}

key_vault_imports = {
  app = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvptaprodcac001"
}

# Created by the platform (Defender/AMA default workspace).
log_analytics_workspace = {
  defaultworkspace = {
    name                            = "defaultworkspace-9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4-cca"
    resource_group_key              = "defaultresourcegroup_cca"
    location                        = "canadacentral"
    sku                             = "PerGB2018"
    retention_in_days               = 30
    daily_quota_gb                  = -1
    internet_ingestion_enabled      = "true"
    internet_query_enabled          = "true"
    local_authentication_enabled    = true
    allow_resource_only_permissions = true
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Property Tax and Assessment"
    }
  }
}

log_analytics_workspace_imports = {
  defaultworkspace = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/defaultresourcegroup-cca/providers/Microsoft.OperationalInsights/workspaces/defaultworkspace-9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4-cca"
}

# Protocols use the wrapper's casing (Tcp); Azure reports TCP, so a case-only update may appear.
# Left out (owned by SQL MI / Defender JIT): nsg-app-pta-prod-canadacentral-001/MicrosoftDefenderForCloud-JITRule_132199, nsg-sql-pta-prod-canadacentral-001/Microsoft.Sql-managedInstances_UseOnly_m, nsg-sql-pta-prod-canadacentral-001/Microsoft.Sql-managedInstances_UseOnly_m, nsg-sql-pta-prod-canadacentral-001/Microsoft.Sql-managedInstances_UseOnly_m, nsg-sql-pta-prod-canadacentral-001/Microsoft.Sql-managedInstances_UseOnly_m, nsg-sql-pta-prod-canadacentral-001/Microsoft.Sql-managedInstances_UseOnly_m, nsg-sql-pta-prod-canadacentral-001/Microsoft.Sql-managedInstances_UseOnly_m, nsg-sql-pta-prod-canadacentral-001/Microsoft.Sql-managedInstances_UseOnly_m, nsg-sql-pta-prod-canadacentral-001/Microsoft.Sql-managedInstances_UseOnly_m
network_security_group = {
  app = {
    name               = "nsg-app-pta-prod-canadacentral-001"
    resource_group_key = "app"
    location           = "canadacentral"
    security_rules = {
      denyallinbound = {
        name                       = "DenyAllInbound"
        access                     = "Deny"
        direction                  = "Inbound"
        priority                   = 1001
        protocol                   = "*"
        source_port_range          = "*"
        destination_port_range     = "*"
        source_address_prefix      = "*"
        destination_address_prefix = "*"
      }
      allowonprem = {
        name                       = "AllowOnPrem"
        access                     = "Allow"
        direction                  = "Inbound"
        priority                   = 1000
        protocol                   = "*"
        source_port_range          = "*"
        destination_port_range     = "*"
        source_address_prefixes    = ["10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "142.52.0.0/16"]
        destination_address_prefix = "*"
      }
      allowbastion = {
        name                       = "AllowBastion"
        access                     = "Allow"
        direction                  = "Inbound"
        priority                   = 800
        protocol                   = "*"
        source_port_range          = "*"
        destination_port_range     = "8080"
        source_address_prefix      = "10.195.16.0/26"
        destination_address_prefix = "*"
      }
      allowbastion2 = {
        name                       = "AllowBastion2"
        access                     = "Allow"
        direction                  = "Inbound"
        priority                   = 750
        protocol                   = "*"
        source_port_range          = "*"
        destination_port_range     = "3389"
        source_address_prefix      = "168.63.129.16"
        destination_address_prefix = "*"
      }
      allowcyberarkservers = {
        name                       = "AllowCyberArkServers"
        access                     = "Allow"
        direction                  = "Inbound"
        priority                   = 850
        protocol                   = "*"
        source_port_range          = "*"
        destination_port_ranges    = ["135", "445", "3389"]
        source_address_prefixes    = ["10.195.116.4", "10.195.116.5"]
        destination_address_prefix = "*"
      }
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Property Tax and Assessment"
    }
  }
  pep = {
    name               = "nsg-pep-pta-prod-canadacentral-001"
    resource_group_key = "app"
    location           = "canadacentral"
    security_rules = {
      allowonprem = {
        name                       = "AllowOnPrem"
        access                     = "Allow"
        direction                  = "Inbound"
        priority                   = 200
        protocol                   = "*"
        source_port_range          = "*"
        destination_port_range     = "*"
        source_address_prefixes    = ["10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "142.52.0.0/16"]
        destination_address_prefix = "*"
      }
      denyallinbound = {
        name                       = "DenyAllInbound"
        access                     = "Deny"
        direction                  = "Inbound"
        priority                   = 1000
        protocol                   = "*"
        source_port_range          = "*"
        destination_port_range     = "*"
        source_address_prefix      = "*"
        destination_address_prefix = "*"
      }
      allowsqlinbound = {
        name                   = "AllowSQLInbound"
        access                 = "Allow"
        direction              = "Inbound"
        priority               = 100
        protocol               = "*"
        source_port_range      = "*"
        destination_port_range = "1433-65535"
        source_address_prefixes = [
          "10.0.0.0/8",
          "172.16.0.0/12",
          "192.168.0.0/16",
          "142.52.0.0/16",
          "155.190.0.0/16"
        ]
        destination_address_prefix = "*"
      }
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Property Tax and Assessment"
    }
  }
  sql = {
    name               = "nsg-sql-pta-prod-canadacentral-001"
    resource_group_key = "app"
    location           = "canadacentral"
    security_rules = {
      allowonprem = {
        name                       = "AllowOnPrem"
        access                     = "Allow"
        direction                  = "Inbound"
        priority                   = 200
        protocol                   = "*"
        source_port_range          = "*"
        destination_port_range     = "*"
        source_address_prefixes    = ["10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "142.52.0.0/16"]
        destination_address_prefix = "*"
      }
      allowbastionhost = {
        name                       = "AllowBastionHost"
        access                     = "Allow"
        direction                  = "Inbound"
        priority                   = 150
        protocol                   = "Tcp"
        source_port_range          = "3389"
        destination_port_range     = "3389"
        source_address_prefixes    = ["168.63.129.16", "10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16"]
        destination_address_prefix = "*"
      }
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Property Tax and Assessment"
    }
  }
}

import_network_security_group = {
  app = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-app-pta-prod-canadacentral-001"
  pep = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-pep-pta-prod-canadacentral-001"
  sql = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-sql-pta-prod-canadacentral-001"
}

network_security_rule_imports = {
  "app/denyallinbound" = {
    nsg_key  = "app"
    rule_key = "denyallinbound"
    id       = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-app-pta-prod-canadacentral-001/securityRules/DenyAllInbound"
  }
  "app/allowonprem" = {
    nsg_key  = "app"
    rule_key = "allowonprem"
    id       = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-app-pta-prod-canadacentral-001/securityRules/AllowOnPrem"
  }
  "app/allowbastion" = {
    nsg_key  = "app"
    rule_key = "allowbastion"
    id       = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-app-pta-prod-canadacentral-001/securityRules/AllowBastion"
  }
  "app/allowbastion2" = {
    nsg_key  = "app"
    rule_key = "allowbastion2"
    id       = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-app-pta-prod-canadacentral-001/securityRules/AllowBastion2"
  }
  "app/allowcyberarkservers" = {
    nsg_key  = "app"
    rule_key = "allowcyberarkservers"
    id       = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-app-pta-prod-canadacentral-001/securityRules/AllowCyberArkServers"
  }
  "pep/allowonprem" = {
    nsg_key  = "pep"
    rule_key = "allowonprem"
    id       = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-pep-pta-prod-canadacentral-001/securityRules/AllowOnPrem"
  }
  "pep/denyallinbound" = {
    nsg_key  = "pep"
    rule_key = "denyallinbound"
    id       = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-pep-pta-prod-canadacentral-001/securityRules/DenyAllInbound"
  }
  "pep/allowsqlinbound" = {
    nsg_key  = "pep"
    rule_key = "allowsqlinbound"
    id       = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-pep-pta-prod-canadacentral-001/securityRules/AllowSQLInbound"
  }
  "sql/allowonprem" = {
    nsg_key  = "sql"
    rule_key = "allowonprem"
    id       = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-sql-pta-prod-canadacentral-001/securityRules/AllowOnPrem"
  }
  "sql/allowbastionhost" = {
    nsg_key  = "sql"
    rule_key = "allowbastionhost"
    id       = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-sql-pta-prod-canadacentral-001/securityRules/AllowBastionHost"
  }
}

# Its VNet flow log stays unmanaged.
network_watcher = {
  canadacentral = {
    name               = "NetworkWatcher_canadacentral"
    resource_group_key = "network_watcher"
    location           = "canadacentral"
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Property Tax and Assessment"
    }
  }
}

network_watcher_imports = {
  canadacentral = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/NetworkWatcherRG/providers/Microsoft.Network/networkWatchers/NetworkWatcher_canadacentral"
}

private_endpoint = {
  blob = {
    name                            = "pep-blob-pta-prod-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-prod-canadacentral-001/subnets/snet-pep-pta-prod-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Storage/storageAccounts/stptaprodcac001"
    private_service_connection_name = "stptaprodcac001"
    subresource_names               = ["blob"]
    network_interface_name          = null
    private_dns_zone_group_name     = "pta_prod_canadacentral_blob_zone_group"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net"
    ]
    ip_configurations = {}
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Property Tax and Assessment"
    }
  }
  blob_2 = {
    name                            = "pep-blob-pta-prod-canadacentral-002"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-prod-canadacentral-001/subnets/snet-pep-pta-prod-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourcegroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Storage/storageAccounts/stptaprodcac002"
    private_service_connection_name = "pep-blob-pta-prod-canadacentral-002"
    subresource_names               = ["blob"]
    network_interface_name          = "pep-blob-pta-prod-canadacentral-002-nic"
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net"
    ]
    ip_configurations = {}
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Property Tax and Assessment"
    }
  }
  kv = {
    name                            = "pep-kv-pta-prod-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-prod-canadacentral-001/subnets/snet-pep-pta-prod-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvptaprodcac001"
    private_service_connection_name = "kvptaprodcac001"
    subresource_names               = ["vault"]
    network_interface_name          = null
    private_dns_zone_group_name     = "pta_prod_canadacentral_kv_zone_group"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.vaultcore.azure.net"
    ]
    ip_configurations = {}
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Property Tax and Assessment"
    }
  }
  mi_sql = {
    name                            = "pep-mi-sql-pta-prod-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-prod-canadacentral-001/subnets/snet-pep-pta-prod-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Sql/managedInstances/mi-sql-pta-prod-canadacentral-001"
    private_service_connection_name = "pep-mi-sql-pta-prod-canadacentral-001"
    subresource_names               = ["managedInstance"]
    network_interface_name          = "pep-mi-sql-pta-prod-canadacentral-001-nic"
    private_dns_zone_group_name     = null
    private_dns_zone_resource_ids   = []
    ip_configurations               = {}
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Property Tax and Assessment"
    }
  }
  stnwfitprdcac001xdf = {
    name                            = "pep-stnwfitprdcac001xdf"
    resource_group_key              = "network_watcher"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-prod-canadacentral-001/subnets/snet-pep-pta-prod-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourcegroups/NetworkWatcherRG/providers/Microsoft.Storage/storageAccounts/stnwptaprdcac001xdf"
    private_service_connection_name = "pep-stnwfitprdcac001xdf"
    subresource_names               = ["blob"]
    network_interface_name          = "pep-stnwfitprdcac001xdf-nic"
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net"
    ]
    ip_configurations = {}
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Property Tax and Assessment"
    }
  }
}

private_endpoint_imports = {
  blob                = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-blob-pta-prod-canadacentral-001"
  blob_2              = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-blob-pta-prod-canadacentral-002"
  kv                  = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-kv-pta-prod-canadacentral-001"
  mi_sql              = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-mi-sql-pta-prod-canadacentral-001"
  stnwfitprdcac001xdf = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/NetworkWatcherRG/providers/Microsoft.Network/privateEndpoints/pep-stnwfitprdcac001xdf"
}

# Alert settings were not exported; confirm before import with
# az backup vault show --query properties.monitoringSettings
recovery_services_vault = {
  app = {
    name                          = "defaultVault775"
    resource_group_key            = "app"
    location                      = "canadacentral"
    sku                           = "RS0"
    storage_mode_type             = "GeoRedundant"
    cross_region_restore_enabled  = false
    soft_delete_enabled           = true
    immutability                  = "Unlocked"
    public_network_access_enabled = true
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Property Tax and Assessment"
    }
  }
}

recovery_services_vault_imports = {
  app = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.RecoveryServices/vaults/defaultVault775"
}

# Azure Backup owns these; only the containers are adopted.
restore_point_collection = {
  vm = {
    name                      = "AzureBackup_vm-pta-prod-canadacentral-001_809241818695025"
    resource_group_name       = "AzureBackupRG_canadacentral_1"
    location                  = "canadacentral"
    source_virtual_machine_id = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-pta-prod-canadacentral-001"
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Property Tax and Assessment"
    }
  }
}

restore_point_collection_imports = {
  vm = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/AzureBackupRG_canadacentral_1/providers/Microsoft.Compute/restorePointCollections/AzureBackup_vm-pta-prod-canadacentral-001_809241818695025"
}

public_ssh_key = {}

public_ssh_key_imports = {}

# Databases and job agents stay unmanaged.
sql_server = {}

sql_server_imports = {}

# blob_properties is left unset (no drift either way).
storage_account = {
  stnwptaprdcac001xdf = {
    name                              = "stnwptaprdcac001xdf"
    resource_group_key                = "network_watcher"
    location                          = "canadacentral"
    account_kind                      = "StorageV2"
    account_tier                      = "Standard"
    account_replication_type          = "LRS"
    access_tier                       = "Hot"
    allow_nested_items_to_be_public   = false
    cross_tenant_replication_enabled  = false
    default_to_oauth_authentication   = true
    https_traffic_only_enabled        = true
    infrastructure_encryption_enabled = false
    is_hns_enabled                    = false
    min_tls_version                   = "TLS1_2"
    public_network_access_enabled     = false
    sftp_enabled                      = false
    shared_access_key_enabled         = false
    network_rules = {
      bypass                     = ["AzureServices"]
      default_action             = "Deny"
      ip_rules                   = []
      virtual_network_subnet_ids = []
      private_link_access = [
        {
          endpoint_resource_id = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/providers/Microsoft.Security/datascanners/storageDataScanner"
          endpoint_tenant_id   = "8fbb85e8-0cbc-48c3-a2e9-528cef30ec27"
        }
      ]
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Property Tax and Assessment"
    }
  }
}

# Public network access is enabled on these, and Deny_Public_Access_On_PaaS_Services_v0
# denies any write to them, so they are read, not adopted, until exempted.
storage_account_existing = {
  sqlvahnwiqbvli57nk = {
    name               = "sqlvahnwiqbvli57nk"
    resource_group_key = "app"
  }
  stptaprodcac001 = {
    name               = "stptaprodcac001"
    resource_group_key = "app"
  }
  stptaprodcac002 = {
    name               = "stptaprodcac002"
    resource_group_key = "app"
  }
}

storage_account_imports = {
  stnwptaprdcac001xdf = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/NetworkWatcherRG/providers/Microsoft.Storage/storageAccounts/stnwptaprdcac001xdf"
}

user_assigned_identity = {
  app = {
    name               = "mid-app-pta-prod-canadacentral-001"
    resource_group_key = "mid_app"
    location           = "canadacentral"
    isolation_scope    = null
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Property Tax and Assessment"
    }
  }
}

user_assigned_identity_imports = {
  app = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-mid-pta-app-prod-canadacentral-001/providers/Microsoft.ManagedIdentity/userAssignedIdentities/mid-app-pta-prod-canadacentral-001"
}

# VM NICs; private endpoint NICs belong to their endpoint.
network_interface = {
  vm = {
    name                           = "nic-vm-pta-prod-canadacentral-001"
    resource_group_key             = "app"
    location                       = "canadacentral"
    enabled                        = true
    accelerated_networking_enabled = false
    ip_forwarding_enabled          = false
    ip_configurations = {
      primary = {
        name                          = "internal"
        primary                       = true
        private_ip_address            = "10.195.16.4"
        private_ip_address_allocation = "Dynamic"
        subnet_id                     = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-prod-canadacentral-001/subnets/snet-app-pta-prod-canadacentral-001"
      }
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Property Tax and Assessment"
    }
  }
}

network_interface_nsg_associations = {}

# Staged: adopted in its own run (see README).
windows_virtual_machine = {
  vm = {
    name               = "vm-pta-prod-canadacentral-001"
    resource_group_key = "app"
    location           = "canadacentral"
    size               = "Standard_F2s_v2"
    zone               = null
    admin_username     = "a-ptaprodf2sv2"
    computer_name      = "ptaprodcac1"
    network_interface_ids = [
      "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/networkInterfaces/nic-vm-pta-prod-canadacentral-001"
    ]
    os_managed_disk_id                                     = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Compute/disks/osdisk-vm-pta-prod-canadacentral-001"
    allow_extension_operations                             = true
    automatic_updates_enabled                              = false
    bypass_platform_safety_checks_on_user_schedule_enabled = true
    disk_controller_type                                   = "SCSI"
    encryption_at_host_enabled                             = false
    license_type                                           = "Windows_Server"
    patch_assessment_mode                                  = "AutomaticByPlatform"
    patch_mode                                             = "AutomaticByPlatform"
    provision_vm_agent                                     = true
    secure_boot_enabled                                    = true
    vm_agent_platform_updates_enabled                      = true
    vtpm_enabled                                           = true
    additional_capabilities = {
      hibernation_enabled = false
    }
    boot_diagnostics = null
    identity = {
      type = "SystemAssigned, UserAssigned"
      user_assigned_identity_ids = [
        "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-mid-pta-app-prod-canadacentral-001/providers/Microsoft.ManagedIdentity/userAssignedIdentities/mid-app-pta-prod-canadacentral-001"
      ]
    }
    os_disk = {
      name                 = "osdisk-vm-pta-prod-canadacentral-001"
      caching              = "ReadWrite"
      disk_size_gb         = 127
      storage_account_type = "Premium_LRS"
    }
    source_image_reference = {
      publisher = "MicrosoftWindowsServer"
      offer     = "WindowsServer"
      sku       = "2022-datacenter-g2"
      version   = "latest"
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Property Tax and Assessment"
    }
  }
}

windows_virtual_machine_imports = {
  vm = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-pta-prod-canadacentral-001"
}

# Staged: the vWAN hub connection is owned by tf-deploy-platform-connectivity.
# defaultOutboundAccess is not reported, so Azure's default (enabled) is assumed.
virtual_network = {
  app = {
    name               = "vnet-pta-prod-canadacentral-001"
    resource_group_key = "app"
    location           = "canadacentral"
    address_space      = ["10.195.16.0/22"]
    ddos_protection_plan = {
      enable = true
      id     = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/ddosProtectionPlans/ddos-protection-plan"
    }
    subnets = {
      app = {
        name                                          = "snet-app-pta-prod-canadacentral-001"
        address_prefixes                              = ["10.195.16.0/26"]
        default_outbound_access_enabled               = true
        private_endpoint_network_policies             = "Disabled"
        private_link_service_network_policies_enabled = true
        network_security_group = {
          id = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-app-pta-prod-canadacentral-001"
        }
        service_endpoint_policies = {}
        service_endpoints_with_location = [
          {
            service   = "Microsoft.Storage"
            locations = ["canadacentral", "canadaeast"]
          }
        ]
        delegations = []
      }
      sql = {
        name                                          = "snet-sql-pta-prod-canadacentral-001"
        address_prefixes                              = ["10.195.17.0/26"]
        default_outbound_access_enabled               = true
        private_endpoint_network_policies             = "Disabled"
        private_link_service_network_policies_enabled = true
        network_security_group = {
          id = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-sql-pta-prod-canadacentral-001"
        }
        route_table = {
          id = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/routeTables/rt-mi-sql-pta-prod-canadacentral-001"
        }
        service_endpoint_policies       = {}
        service_endpoints_with_location = []
        delegations = [
          {
            name = "dlg-mi-sql-pta-prod-canadacentral-001"
            service_delegation = {
              name = "Microsoft.Sql/managedInstances"
              actions = [
                "Microsoft.Network/virtualNetworks/subnets/join/action",
                "Microsoft.Network/virtualNetworks/subnets/prepareNetworkPolicies/action",
                "Microsoft.Network/virtualNetworks/subnets/unprepareNetworkPolicies/action"
              ]
            }
          }
        ]
      }
      azurebastionsubnet = {
        name                                          = "AzureBastionSubnet"
        address_prefixes                              = ["10.195.19.0/26"]
        default_outbound_access_enabled               = true
        private_endpoint_network_policies             = "Disabled"
        private_link_service_network_policies_enabled = true
        service_endpoint_policies                     = {}
        service_endpoints_with_location = [
          {
            service   = "Microsoft.Storage"
            locations = ["canadacentral", "canadaeast"]
          }
        ]
        delegations = []
      }
      pep = {
        name                                          = "snet-pep-pta-prod-canadacentral-001"
        address_prefixes                              = ["10.195.18.0/24"]
        default_outbound_access_enabled               = true
        private_endpoint_network_policies             = "RouteTableEnabled"
        private_link_service_network_policies_enabled = true
        network_security_group = {
          id = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-pep-pta-prod-canadacentral-001"
        }
        service_endpoint_policies       = {}
        service_endpoints_with_location = []
        delegations                     = []
      }
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "Prod"
      Name                    = "Property Tax and Assessment"
    }
  }
}

virtual_network_imports = {
  app = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-prod-canadacentral-001"
}

virtual_network_subnet_imports = {
  pta_app = {
    vnet_key   = "app"
    subnet_key = "app"
    id         = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-prod-canadacentral-001/subnets/snet-app-pta-prod-canadacentral-001"
  }
  pta_sql = {
    vnet_key   = "app"
    subnet_key = "sql"
    id         = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-prod-canadacentral-001/subnets/snet-sql-pta-prod-canadacentral-001"
  }
  pta_azurebastionsubnet = {
    vnet_key   = "app"
    subnet_key = "azurebastionsubnet"
    id         = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-prod-canadacentral-001/subnets/AzureBastionSubnet"
  }
  pta_pep = {
    vnet_key   = "app"
    subnet_key = "pep"
    id         = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-prod-canadacentral-001/subnets/snet-pep-pta-prod-canadacentral-001"
  }
}

# =====================================================================
# Hub private DNS: links and records in the shared zones (connectivity subscription)
# =====================================================================

enable_hub_private_dns = true

hub_private_dns_zone_link = {
  "link-blob-pta-prod-canadacentral-001" = {
    name               = "link-blob-pta-prod-canadacentral-001"
    zone_name          = "privatelink.blob.core.windows.net"
    virtual_network_id = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-prod-canadacentral-001"
  }
  "link-vault-pta-prod-canadacentral-001" = {
    name               = "link-vault-pta-prod-canadacentral-001"
    zone_name          = "privatelink.vaultcore.azure.net"
    virtual_network_id = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-prod-canadacentral-001"
  }
  "mi-sql-pta-privatelink-canadacentral" = {
    name               = "mi-sql-pta-privatelink-canadacentral"
    zone_name          = "privatelink.d1b5826aa498.database.windows.net"
    virtual_network_id = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-prod-canadacentral-001"
  }
  "privatelink.agentsvc.azure-automation.net/link-pta-prod-canadacentral" = {
    name               = "link-pta-prod-canadacentral"
    zone_name          = "privatelink.agentsvc.azure-automation.net"
    virtual_network_id = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-prod-canadacentral-001"
  }
  "privatelink.monitor.azure.com/link-pta-prod-canadacentral" = {
    name               = "link-pta-prod-canadacentral"
    zone_name          = "privatelink.monitor.azure.com"
    virtual_network_id = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-prod-canadacentral-001"
  }
  "privatelink.ods.opinsights.azure.com/link-pta-prod-canadacentral" = {
    name               = "link-pta-prod-canadacentral"
    zone_name          = "privatelink.ods.opinsights.azure.com"
    virtual_network_id = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-prod-canadacentral-001"
  }
  "privatelink.oms.opinsights.azure.com/link-pta-prod-canadacentral" = {
    name               = "link-pta-prod-canadacentral"
    zone_name          = "privatelink.oms.opinsights.azure.com"
    virtual_network_id = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-prod-canadacentral-001"
  }
}

hub_private_dns_zone_link_imports = {
  "link-blob-pta-prod-canadacentral-001"                                  = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net/virtualNetworkLinks/link-blob-pta-prod-canadacentral-001"
  "link-vault-pta-prod-canadacentral-001"                                 = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.vaultcore.azure.net/virtualNetworkLinks/link-vault-pta-prod-canadacentral-001"
  "mi-sql-pta-privatelink-canadacentral"                                  = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.d1b5826aa498.database.windows.net/virtualNetworkLinks/mi-sql-pta-privatelink-canadacentral"
  "privatelink.agentsvc.azure-automation.net/link-pta-prod-canadacentral" = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.agentsvc.azure-automation.net/virtualNetworkLinks/link-pta-prod-canadacentral"
  "privatelink.monitor.azure.com/link-pta-prod-canadacentral"             = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.monitor.azure.com/virtualNetworkLinks/link-pta-prod-canadacentral"
  "privatelink.ods.opinsights.azure.com/link-pta-prod-canadacentral"      = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.ods.opinsights.azure.com/virtualNetworkLinks/link-pta-prod-canadacentral"
  "privatelink.oms.opinsights.azure.com/link-pta-prod-canadacentral"      = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.oms.opinsights.azure.com/virtualNetworkLinks/link-pta-prod-canadacentral"
}

hub_private_dns_a_record = {
  "app.pta" = {
    name      = "app.pta"
    zone_name = "internal.bchydro.bc.ca"
    ttl       = 10
    records   = ["10.195.16.4"]
  }
}

hub_private_dns_a_record_imports = {
  "app.pta" = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/internal.bchydro.bc.ca/A/app.pta"
}
