# Sub-Pta-NonProd (770996e1-e364-4315-9ab9-0c703d5d0996)
# Values come from the Azure resource export of 2026-10-20 (network resources
# and alerts from follow-up exports the same day).
# The Windows VMs (and their NICs) are off for the first apply. Enable them in a
# separate run once windows_virtual_machine_admin_passwords is set as a sensitive
# HCP workspace variable ({ dev = "...", uat = "..." }), and check that plan for a
# VM replace caused by admin_password before applying.

subscription_id = "770996e1-e364-4315-9ab9-0c703d5d0996"

enable_resource_group           = true
enable_monitoring               = true
enable_bastion_host             = true
enable_key_vault                = true
enable_log_analytics_workspace  = true
enable_network_interface        = false
enable_network_security_group   = true
enable_network_watcher          = true
enable_private_endpoint         = true
enable_public_ssh_key           = true
enable_recovery_services_vault  = true
enable_restore_point_collection = true
enable_sql_server               = true
enable_storage_account          = true
enable_user_assigned_identity   = true
enable_virtual_network          = false
enable_windows_virtual_machine  = false
enable_event_grid_system_topic  = true

enable_resource_group_role_assignment           = false
enable_monitoring_role_assignment               = false
enable_bastion_host_role_assignment             = false
enable_key_vault_role_assignment                = false
enable_log_analytics_workspace_role_assignment  = false
enable_network_interface_role_assignment        = false
enable_network_security_group_role_assignment   = false
enable_network_watcher_role_assignment          = false
enable_private_endpoint_role_assignment         = false
enable_public_ssh_key_role_assignment           = false
enable_recovery_services_vault_role_assignment  = false
enable_restore_point_collection_role_assignment = false
enable_sql_server_role_assignment               = false
enable_storage_account_role_assignment          = false
enable_user_assigned_identity_role_assignment   = false
enable_virtual_network_role_assignment          = false
enable_windows_virtual_machine_role_assignment  = false
enable_event_grid_system_topic_role_assignment  = false

role_assignments = {}

# AzureBackupRG_canadacentral_1 is managed by Microsoft.RecoveryServices; the
# wrapper rejects that non-ID managed_by value, so it is left unset.
resource_group = {
  alerts = {
    name     = "rg-alerts-pta-nonprod-canadacentral-001"
    location = "canadacentral"
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Property Tax and Assessment"
    }
  }
  app = {
    name     = "rg-pta-app-nonprod-canadacentral-001"
    location = "canadacentral"
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Property Tax and Assessment"
    }
  }
  app_pam_poc = {
    name     = "rg-pta-app-nonprod-canadacentral-PAM-POC"
    location = "canadacentral"
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Property Tax and Assessment"
    }
  }
  mid_app = {
    name     = "rg-mid-pta-app-nonprod-canadacentral-001"
    location = "canadacentral"
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Property Tax and Assessment"
    }
  }
  shared_app = {
    name     = "rg-shared-pta-app-nonprod-canadacentral-001"
    location = "canadacentral"
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Property Tax and Assessment"
    }
  }
  defaultresourcegroup_cca = {
    name     = "defaultresourcegroup-cca"
    location = "canadacentral"
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Property Tax and Assessment"
    }
  }
}

import_resource_group = {
  alerts                   = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-alerts-pta-nonprod-canadacentral-001"
  app                      = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001"
  app_pam_poc              = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-PAM-POC"
  mid_app                  = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-mid-pta-app-nonprod-canadacentral-001"
  shared_app               = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-shared-pta-app-nonprod-canadacentral-001"
  defaultresourcegroup_cca = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/defaultresourcegroup-cca"
}

# KeyVault-Deletion's action group ID has a leading space in its name, kept as exported.
# VM-OS-Patch-Available matches two statuses, which the wrapper's single
# status field cannot express; it stays unmanaged (see WRAPPER-GAPS.md).
alert = {
  resource_group_key         = "alerts"
  root_management_group_name = null
  tags                       = {}
  activity_log_alerts = {
    key_vault_deletion = {
      name                = "KeyVault-Deletion-Alert-canadacentral"
      resource_group_name = "rg-alerts-pta-nonprod-canadacentral-001"
      scopes              = ["/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996"]
      location            = "global"
      description         = "This alert will monitor any deletion of key vault"
      enabled             = true
      criteria = {
        category       = "Administrative"
        operation_name = "Microsoft.KeyVault/vaults/delete"
      }
      action_group_keys = []
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      webhook_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001597"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Capital Infrastructure Project Delivery"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Property Tax and Assessment"
      }
    }
    service_outage = {
      name                = "Service-Outage-Alert-canadacentral"
      resource_group_name = "rg-alerts-pta-nonprod-canadacentral-001"
      scopes              = ["/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996"]
      location            = "global"
      description         = "Azure Landing Zone Service Health Alert"
      enabled             = true
      criteria = {
        category = "ServiceHealth"
        service_health = {
          locations = ["Global"]
        }
      }
      action_group_keys = []
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-pta-mail-alerts-canadacentral-001"
      ]
      webhook_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001597"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Capital Infrastructure Project Delivery"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Property Tax and Assessment"
      }
    }
  }
  metric_alerts = {
    backup_alert = {
      name                = "Backup Alert"
      resource_group_name = "rg-pta-app-nonprod-canadacentral-001"
      scopes = [
        "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.RecoveryServices/vaults/rsv-pta-canadacentral-001"
      ]
      description              = ""
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT15M"
      window_size              = "PT6H"
      severity                 = 3
      target_resource_type     = "Microsoft.RecoveryServices/vaults"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.RecoveryServices/vaults"
          metric_name            = "BackupHealthEvent"
          aggregation            = "Count"
          operator               = "GreaterThan"
          threshold              = 0
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actionGroups/ag-monitor-mail-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001597"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Capital Infrastructure Project Delivery"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Property Tax and Assessment"
      }
    }
    mi_sql_cpu_high_alert_canadacentral = {
      name                = "MI-SQL-CPU-High-Alert-canadacentral"
      resource_group_name = "rg-pta-app-nonprod-canadacentral-001"
      scopes = [
        "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Sql/managedInstances/mi-sql-pta-nonprod-canadacentral-001"
      ]
      description              = "Alert triggred when CPU is 80 % high"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 1
      target_resource_type     = "Microsoft.Sql/managedInstances"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Sql/managedInstances"
          metric_name            = "avg_cpu_percent"
          aggregation            = "Average"
          operator               = "GreaterThan"
          threshold              = 90
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001",
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-db-mail-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001597"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Capital Infrastructure Project Delivery"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Property Tax and Assessment"
      }
    }
    restore_job_failed_pta_canadacentral = {
      name                     = "Restore-Job-Failed-PTA-canadacentral"
      resource_group_name      = "rg-pta-app-nonprod-canadacentral-001"
      scopes                   = ["/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4"]
      description              = "Job triggers when restore job is faild"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT15M"
      severity                 = 2
      target_resource_type     = "microsoft.recoveryservices/vaults"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "microsoft.recoveryservices/vaults"
          metric_name            = "RestoreHealthEvent"
          aggregation            = "Count"
          operator               = "GreaterThanOrEqual"
          threshold              = 1
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-monitor-mail-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001597"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Capital Infrastructure Project Delivery"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Property Tax and Assessment"
      }
    }
    restore_job_failed_pta_nonprod_canadacentral = {
      name                = "Restore-Job-Failed-PTA-Nonprod-canadacentral"
      resource_group_name = "rg-shared-pta-app-nonprod-canadacentral-001"
      scopes = [
        "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourcegroups/rg-pta-app-nonprod-canadacentral-001"
      ]
      description              = "Job triggers when restore job is faild"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT15M"
      severity                 = 2
      target_resource_type     = "microsoft.recoveryservices/vaults"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "microsoft.recoveryservices/vaults"
          metric_name            = "RestoreHealthEvent"
          aggregation            = "Count"
          operator               = "GreaterThanOrEqual"
          threshold              = 1
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-monitor-mail-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001597"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Capital Infrastructure Project Delivery"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Property Tax and Assessment"
      }
    }
    sql_db_cpu_alert_canadacentral = {
      name                = "SQL-DB-CPU-Alert-canadacentral"
      resource_group_name = "rg-shared-pta-app-nonprod-canadacentral-001"
      scopes = [
        "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Sql/servers/sql-pta-nonprod-canadacentral-001/databases/PTA_2024"
      ]
      description              = "This alert is for high CPU utilization of Sub-Pta-NonProd DB's"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT15M"
      severity                 = 3
      target_resource_type     = "Microsoft.Sql/servers/databases"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Sql/servers/databases"
          metric_name            = "cpu_percent"
          aggregation            = "Average"
          operator               = "GreaterThan"
          threshold              = 90
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001",
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-db-mail-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001597"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Capital Infrastructure Project Delivery"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Property Tax and Assessment"
      }
    }
    sql_db_memory_alert_canadacentral = {
      name                = "SQL-DB-Memory-Alert-canadacentral"
      resource_group_name = "rg-alerts-pta-nonprod-canadacentral-001"
      scopes = [
        "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourcegroups/rg-pta-app-nonprod-canadacentral-001"
      ]
      description              = "This alert is for high Mmeory utilization of Sub-Pta-NonProd DB's"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 3
      target_resource_type     = "microsoft.sql/servers/databases"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "microsoft.sql/servers/databases"
          metric_name            = "sql_instance_memory_percent"
          aggregation            = "Maximum"
          operator               = "GreaterThan"
          threshold              = 90
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/lga-servicenow-integration_group/providers/microsoft.insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001597"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Capital Infrastructure Project Delivery"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Property Tax and Assessment"
      }
    }
    sql_db_pta_2025_cpu_alert_canadacentral = {
      name                = "SQL-DB-PTA-2025-CPU-Alert-canadacentral"
      resource_group_name = "rg-shared-pta-app-nonprod-canadacentral-001"
      scopes = [
        "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Sql/servers/sql-pta-nonprod-canadacentral-001/databases/PTA_2025"
      ]
      description              = "This alert is for high CPU utilization of Sub-Pta-NonProd DB's"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT15M"
      severity                 = 3
      target_resource_type     = "Microsoft.Sql/servers/databases"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Sql/servers/databases"
          metric_name            = "cpu_percent"
          aggregation            = "Average"
          operator               = "GreaterThan"
          threshold              = 90
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001",
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-db-mail-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001597"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Capital Infrastructure Project Delivery"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Property Tax and Assessment"
      }
    }
    sql_db_pta_system_cpu_alert_canadacentral = {
      name                = "SQL-DB-PTA-SYSTEM-CPU-Alert-canadacentral"
      resource_group_name = "rg-shared-pta-app-nonprod-canadacentral-001"
      scopes = [
        "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Sql/servers/sql-pta-nonprod-canadacentral-001/databases/PTA_System"
      ]
      description              = "This alert is for high CPU utilization of Sub-Pta-NonProd DB's"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT15M"
      severity                 = 3
      target_resource_type     = "Microsoft.Sql/servers/databases"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Sql/servers/databases"
          metric_name            = "cpu_percent"
          aggregation            = "Average"
          operator               = "GreaterThan"
          threshold              = 90
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001",
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-db-mail-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001597"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Capital Infrastructure Project Delivery"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Property Tax and Assessment"
      }
    }
    sub_pta_nonprod_vm_cpu_usage_alert_canadacentral = {
      name                     = "Sub-PTA-Nonprod-VM-CPU-Usage-Alert-canadacentral"
      resource_group_name      = "rg-shared-pta-app-nonprod-canadacentral-001"
      scopes                   = ["/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996"]
      description              = "Action will be triggered when percentage CPU for VM is greater than 90%"
      enabled                  = false
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT30M"
      severity                 = 2
      target_resource_type     = "microsoft.compute/virtualmachines"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "microsoft.compute/virtualmachines"
          metric_name            = "Percentage CPU"
          aggregation            = "Average"
          operator               = "GreaterThan"
          threshold              = 90
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-monitor-mail-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001597"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Capital Infrastructure Project Delivery"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Property Tax and Assessment"
      }
    }
    vm_os_disk_iops_alert_canadacentral = {
      name                     = "VM-OS-Disk-IOPS-Alert-canadacentral"
      resource_group_name      = "rg-alerts-pta-nonprod-canadacentral-001"
      scopes                   = ["/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996"]
      description              = "Action will be triggered when Disk IOPS is high"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 2
      target_resource_type     = "Microsoft.Compute/virtualMachines"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "microsoft.compute/virtualmachines"
          metric_name            = "OS Disk IOPS Consumed Percentage"
          aggregation            = "Average"
          operator               = "GreaterThan"
          threshold              = 75
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-monitor-mail-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001597"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Capital Infrastructure Project Delivery"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Property Tax and Assessment"
      }
    }
    vm_pta_nonprod_cpu_high_warning = {
      name                     = "vm-pta-nonprod-cpu-high-warning"
      resource_group_name      = "rg-alerts-pta-nonprod-canadacentral-001"
      scopes                   = ["/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996"]
      description              = "Action will be triggered when percentage CPU for VM is greater than 90%"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT30M"
      severity                 = 2
      target_resource_type     = "microsoft.compute/virtualmachines"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "microsoft.compute/virtualmachines"
          metric_name            = "Percentage CPU"
          aggregation            = "Average"
          operator               = "GreaterThan"
          threshold              = 90
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-monitor-mail-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001597"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Capital Infrastructure Project Delivery"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Property Tax and Assessment"
      }
    }
    vm_pta_nonprod_cpu_high_warning_shared_pta_app_nonprod = {
      name                     = "vm-pta-nonprod-cpu-high-warning"
      resource_group_name      = "rg-shared-pta-app-nonprod-canadacentral-001"
      scopes                   = ["/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996"]
      description              = "Action will be triggered when percentage CPU for VM is greater than 90%"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT30M"
      severity                 = 2
      target_resource_type     = "microsoft.compute/virtualmachines"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "microsoft.compute/virtualmachines"
          metric_name            = "Percentage CPU"
          aggregation            = "Average"
          operator               = "GreaterThan"
          threshold              = 90
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-monitor-mail-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001597"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Capital Infrastructure Project Delivery"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Property Tax and Assessment"
      }
    }
    vm_pta_nonprod_memory_high_warning = {
      name                     = "vm-pta-nonprod-memory-high-warning"
      resource_group_name      = "rg-alerts-pta-nonprod-canadacentral-001"
      scopes                   = ["/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996"]
      description              = "Action will be triggered when percentage CPU for VM is greater than 90%"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 2
      target_resource_type     = "microsoft.compute/virtualmachines"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "microsoft.compute/virtualmachines"
          metric_name            = "Available Memory Percentage"
          aggregation            = "Average"
          operator               = "LessThanOrEqual"
          threshold              = 10
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-monitor-mail-alerts-canadacentral-001"
      ]
      tags = {
        ApplicationId           = "BCH – LIX -0000001597"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Capital Infrastructure Project Delivery"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Property Tax and Assessment"
      }
    }
  }
  log_search_alerts = {
    keyvault_secret_expired_alert_canadacentral = {
      name                              = "KeyVault-Secret-Expired-Alert-canadacentral"
      resource_group_name               = "rg-alerts-pta-nonprod-canadacentral-001"
      location                          = "canadacentral"
      scopes                            = ["/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996"]
      severity                          = 0
      evaluation_frequency              = "PT5M"
      window_duration                   = "PT30M"
      description                       = "Alert for expired secret in a Key Vault."
      display_name                      = "KeyVault-Secret-Expired-Alert-canadacentral"
      enabled                           = true
      auto_mitigation_enabled           = false
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = null
      target_resource_types             = null
      criteria = [
        {
          query                   = "        AzureDiagnostics\n        | where ResourceProvider == \"MICROSOFT.KEYVAULT\"\n        | where OperationName contains \"SecretExpired\"\n        "
          time_aggregation_method = "Count"
          threshold               = 1
          operator                = "GreaterThanOrEqual"
          resource_id_column      = "ResourceId"
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001597"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Capital Infrastructure Project Delivery"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Property Tax and Assessment"
      }
    }
    keyvault_secret_near_expiry_alert_canadacentral = {
      name                              = "KeyVault-Secret-Near-Expiry-Alert-canadacentral"
      resource_group_name               = "rg-alerts-pta-nonprod-canadacentral-001"
      location                          = "canadacentral"
      scopes                            = ["/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996"]
      severity                          = 1
      evaluation_frequency              = "PT5M"
      window_duration                   = "PT30M"
      description                       = "Alert for secret in a Key Vault is about to expire."
      display_name                      = "KeyVault-Secret-Near-Expiry-Alert-canadacentral"
      enabled                           = true
      auto_mitigation_enabled           = false
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = null
      target_resource_types             = null
      criteria = [
        {
          query                   = "        AzureDiagnostics\n        | where ResourceProvider == \"MICROSOFT.KEYVAULT\"\n        | where OperationName contains \"SecretNearExpiry\"\n        "
          time_aggregation_method = "Count"
          threshold               = 1
          operator                = "GreaterThanOrEqual"
          resource_id_column      = "ResourceId"
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001597"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Capital Infrastructure Project Delivery"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Property Tax and Assessment"
      }
    }
    resource_creation_alert_canadacentral = {
      name                              = "Resource-Creation-Alert-canadacentral"
      resource_group_name               = "rg-alerts-pta-nonprod-canadacentral-001"
      location                          = "canadacentral"
      scopes                            = ["/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996"]
      severity                          = 4
      evaluation_frequency              = "PT10M"
      window_duration                   = "PT30M"
      description                       = "Alert when a new resource is created."
      display_name                      = "Resource-Creation-Alert-canadacentral"
      enabled                           = true
      auto_mitigation_enabled           = false
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = null
      target_resource_types             = null
      criteria = [
        {
          query                   = "        AzureActivity\n        | where OperationNameValue has \"Microsoft.Resources/deployments/write\"\n        | where CategoryValue == \"Administrative\"\n        | where ActivityStatusValue == \"Success\"\n        "
          time_aggregation_method = "Count"
          threshold               = 10
          operator                = "GreaterThanOrEqual"
          resource_id_column      = "_ResourceId"
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001597"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Capital Infrastructure Project Delivery"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Property Tax and Assessment"
      }
    }
    storage_account_container_deletion_alert_canadacentral = {
      name                              = "Storage-Account-Container-Deletion-Alert-canadacentral"
      resource_group_name               = "rg-alerts-pta-nonprod-canadacentral-001"
      location                          = "canadacentral"
      scopes                            = ["/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996"]
      severity                          = 0
      evaluation_frequency              = "PT5M"
      window_duration                   = "PT30M"
      description                       = "Alert for the deletion of Storage Account Container."
      display_name                      = "Storage-Account-Container-Deletion-Alert-canadacentral"
      enabled                           = true
      auto_mitigation_enabled           = false
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = null
      target_resource_types             = null
      criteria = [
        {
          query                   = "        AzureActivity\n        | where ResourceProviderValue == \"MICROSOFT.STORAGE\" and OperationNameValue == \"MICROSOFT.STORAGE/STORAGEACCOUNTS/BLOBSERVICES/CONTAINERS/DELETE\"\n        "
          time_aggregation_method = "Count"
          threshold               = 1
          operator                = "GreaterThanOrEqual"
          resource_id_column      = "_ResourceId"
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001597"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Capital Infrastructure Project Delivery"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Property Tax and Assessment"
      }
    }
    storage_account_deletion_alert_canadacentral = {
      name                              = "Storage-Account-Deletion-Alert-canadacentral"
      resource_group_name               = "rg-alerts-pta-nonprod-canadacentral-001"
      location                          = "canadacentral"
      scopes                            = ["/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996"]
      severity                          = 0
      evaluation_frequency              = "PT5M"
      window_duration                   = "PT30M"
      description                       = "Alert for the deletion of Storage Account."
      display_name                      = "Storage-Account-Deletion-Alert-canadacentral"
      enabled                           = true
      auto_mitigation_enabled           = false
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = null
      target_resource_types             = null
      criteria = [
        {
          query                   = "        AzureActivity\n        | where ResourceProviderValue == \"MICROSOFT.STORAGE\" and OperationNameValue == \"MICROSOFT.STORAGE/STORAGEACCOUNTS/DELETE\"\n        "
          time_aggregation_method = "Count"
          threshold               = 1
          operator                = "GreaterThanOrEqual"
          resource_id_column      = "_ResourceId"
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001597"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Capital Infrastructure Project Delivery"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Property Tax and Assessment"
      }
    }
    sub_pta_nonprod_vm_heartbeat_lost = {
      name                              = "Sub-PTA-nonprod-VM-Heartbeat lost"
      resource_group_name               = "rg-shared-pta-app-nonprod-canadacentral-001"
      location                          = "canadacentral"
      scopes                            = ["/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996"]
      severity                          = 1
      evaluation_frequency              = "PT5M"
      window_duration                   = "PT5M"
      description                       = "This alert will be triggered when VM state is unhealthy for more than 5min"
      display_name                      = "Sub-PTA-nonprod-VM-Heartbeat lost"
      enabled                           = false
      auto_mitigation_enabled           = false
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = "P2D"
      target_resource_types             = ["microsoft.compute/virtualmachines"]
      criteria = [
        {
          query                   = "Heartbeat\n| where TimeGenerated > ago(1d)\n| summarize LastHeartbeat = max(TimeGenerated) by _ResourceId, Computer\n| extend TimeSinceLastHeartbeatSeconds = (now() - LastHeartbeat) / 1s\n| extend AgentState = iff(TimeSinceLastHeartbeatSeconds < 300, \"Healthy\", \"Unhealthy\")\n| where AgentState == \"Unhealthy\"\n| project _ResourceId, Computer, LastHeartbeat, TimeSinceLastHeartbeatSeconds, AgentState\n"
          time_aggregation_method = "Count"
          threshold               = 0
          operator                = "GreaterThan"
          resource_id_column      = "_ResourceId"
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001597"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Capital Infrastructure Project Delivery"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Property Tax and Assessment"
      }
    }
    vm_backup_failure_alert_canadacentral = {
      name                              = "VM-Backup-Failure-Alert-canadacentral"
      resource_group_name               = "rg-alerts-pta-nonprod-canadacentral-001"
      location                          = "canadacentral"
      scopes                            = ["/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996"]
      severity                          = 1
      evaluation_frequency              = "PT5M"
      window_duration                   = "PT30M"
      description                       = "Alert when there is a VM Backup failure"
      display_name                      = "VM-Backup-Failure-Alert-canadacentral"
      enabled                           = true
      auto_mitigation_enabled           = false
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = null
      target_resource_types             = ["Microsoft.Compute/virtualMachines"]
      criteria = [
        {
          query                   = "        AzureDiagnostics\n\t\t    | where Category == \"AzureBackupReport\"\n\t\t    | where OperationName == \"Job\"\n\t\t    | where ResultType != \"Success\"\n        "
          time_aggregation_method = "Count"
          threshold               = 1
          operator                = "GreaterThanOrEqual"
          resource_id_column      = "_ResourceId"
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001597"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Capital Infrastructure Project Delivery"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Property Tax and Assessment"
      }
    }
    vm_free_disk_space_pta_nonprod_alert_canadacentral = {
      name                = "VM-Free-Disk-Space-PTA--Nonprod-Alert-canadacentral"
      resource_group_name = "rg-pta-app-nonprod-canadacentral-001"
      location            = "canadacentral"
      scopes = [
        "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-pta-dev-canadacentral-001"
      ]
      severity                          = 2
      evaluation_frequency              = "PT5M"
      window_duration                   = "PT5M"
      description                       = "Triggered when disk space has consumed >85%"
      display_name                      = "VM-Free-Disk-Space-PTA--Nonprod-Alert-canadacentral"
      enabled                           = true
      auto_mitigation_enabled           = false
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = null
      target_resource_types             = ["Microsoft.Compute/virtualMachines"]
      criteria = [
        {
          query                   = "Perf\r\n| where TimeGenerated > ago(15m)\r\n| where ObjectName in (\"LogicalDisk\", \"Logical Disk\")\r\n| where CounterName == \"% Free Space\"\r\n| where InstanceName == \"_Total\"\r\n| summarize \r\n    FreePercent = avg(CounterValue),\r\n    TimeGenerated = max(TimeGenerated)\r\n  by Computer\r\n| extend UsedPercent = round(100 - FreePercent, 2)\r\n| where UsedPercent >= 85\r\n| project TimeGenerated, Computer, UsedPercent\r\n"
          time_aggregation_method = "Count"
          threshold               = 1
          operator                = "GreaterThan"
          resource_id_column      = null
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/lga-servicenow-integration_group/providers/microsoft.insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001597"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Capital Infrastructure Project Delivery"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Property Tax and Assessment"
      }
    }
    vm_free_disk_space_pta_nonprod_alert_canadacentral_shared_pta_app_nonprod = {
      name                = "VM-Free-Disk-Space-PTA--Nonprod-Alert-canadacentral"
      resource_group_name = "rg-shared-pta-app-nonprod-canadacentral-001"
      location            = "canadacentral"
      scopes = [
        "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-pta-uat-canadacentral-001"
      ]
      severity                          = 2
      evaluation_frequency              = "PT5M"
      window_duration                   = "PT5M"
      description                       = "Triggered when disk space has consumed >85%"
      display_name                      = "VM-Free-Disk-Space-PTA--Nonprod-Alert-canadacentral"
      enabled                           = true
      auto_mitigation_enabled           = false
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = "P2D"
      target_resource_types             = ["Microsoft.Compute/virtualMachines"]
      criteria = [
        {
          query                   = "Perf\r\n| where TimeGenerated > ago(15m)\r\n| where ObjectName in (\"LogicalDisk\", \"Logical Disk\")\r\n| where CounterName == \"% Free Space\"\r\n| where InstanceName == \"_Total\"\r\n| summarize \r\n    FreePercent = avg(CounterValue),\r\n    TimeGenerated = max(TimeGenerated)\r\n  by Computer\r\n| extend UsedPercent = round(100 - FreePercent, 2)\r\n| where UsedPercent >= 85\r\n| project TimeGenerated, Computer, UsedPercent\r\n"
          time_aggregation_method = "Count"
          threshold               = 1
          operator                = "GreaterThan"
          resource_id_column      = null
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/lga-servicenow-integration_group/providers/microsoft.insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001597"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Capital Infrastructure Project Delivery"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Property Tax and Assessment"
      }
    }
    vm_heartbeat_lost_alert_canadacentral = {
      name                              = "VM-Heartbeat-Lost-Alert-canadacentral"
      resource_group_name               = "rg-shared-pta-app-nonprod-canadacentral-001"
      location                          = "canadacentral"
      scopes                            = ["/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996"]
      severity                          = 0
      evaluation_frequency              = "PT5M"
      window_duration                   = "PT5M"
      description                       = "This alert will be triggered when VM state is unhealthy for more than 5min"
      display_name                      = "VM-Heartbeat-Lost-Alert-canadacentral"
      enabled                           = true
      auto_mitigation_enabled           = false
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = "P2D"
      target_resource_types             = ["microsoft.compute/virtualmachines"]
      criteria = [
        {
          query                   = "Heartbeat\n| where TimeGenerated > ago(1d)\n| summarize LastHeartbeat = max(TimeGenerated) by _ResourceId, Computer\n| extend TimeSinceLastHeartbeatSeconds = (now() - LastHeartbeat) / 1s\n| extend AgentState = iff(TimeSinceLastHeartbeatSeconds < 300, \"Healthy\", \"Unhealthy\")\n| where AgentState == \"Unhealthy\"\n| project _ResourceId, Computer, LastHeartbeat, TimeSinceLastHeartbeatSeconds, AgentState\n"
          time_aggregation_method = "Count"
          threshold               = 0
          operator                = "GreaterThan"
          resource_id_column      = "_ResourceId"
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/lga-servicenow-integration_group/providers/microsoft.insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001597"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Capital Infrastructure Project Delivery"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Property Tax and Assessment"
      }
    }
    vm_heartbeat_lost_canadacentral = {
      name                              = "VM-Heartbeat-Lost-canadacentral"
      resource_group_name               = "rg-shared-pta-app-nonprod-canadacentral-001"
      location                          = "canadacentral"
      scopes                            = ["/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996"]
      severity                          = 1
      evaluation_frequency              = "PT5M"
      window_duration                   = "PT5M"
      description                       = "This alert will be triggered when VM state is unhealthy for more than 5min"
      display_name                      = "VM-Heartbeat-Lost-canadacentral"
      enabled                           = false
      auto_mitigation_enabled           = false
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = "P2D"
      target_resource_types             = ["microsoft.compute/virtualmachines"]
      criteria = [
        {
          query                   = "Heartbeat\n| where TimeGenerated > ago(1d)\n| summarize LastHeartbeat = max(TimeGenerated) by _ResourceId, Computer\n| extend TimeSinceLastHeartbeatSeconds = (now() - LastHeartbeat) / 1s\n| extend AgentState = iff(TimeSinceLastHeartbeatSeconds < 300, \"Healthy\", \"Unhealthy\")\n| where AgentState == \"Unhealthy\"\n| project _ResourceId, Computer, LastHeartbeat, TimeSinceLastHeartbeatSeconds, AgentState\n"
          time_aggregation_method = "Count"
          threshold               = 0
          operator                = "GreaterThan"
          resource_id_column      = "_ResourceId"
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/lga-servicenow-integration_group/providers/microsoft.insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001597"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Capital Infrastructure Project Delivery"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Property Tax and Assessment"
      }
    }
    vm_windows_service_stopped_pta_nonprod_canadacentral = {
      name                = "VM-Windows-Service-Stopped-PTA-Nonprod-canadacentral"
      resource_group_name = "rg-shared-pta-app-nonprod-canadacentral-001"
      location            = "canadacentral"
      scopes = [
        "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourcegroups/rg-pta-app-nonprod-canadacentral-001"
      ]
      severity                          = 1
      evaluation_frequency              = "PT5M"
      window_duration                   = "PT5M"
      description                       = "Triggered when windows services are stopped"
      display_name                      = "VM-Windows-Service-Stopped-PTA-Nonprod-canadacentral"
      enabled                           = false
      auto_mitigation_enabled           = false
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = null
      target_resource_types             = ["microsoft.compute/virtualmachines"]
      criteria = [
        {
          query                   = "Perf\n| where ObjectName == \"Service\"\n| where CounterName == \"Service State\"\n| extend ServiceState = iff(CounterValue == 4, \"Running\", \"Stopped\")\n| where ServiceState == \"Stopped\"\n//| extend _ResourceId = strcat(\"/subscriptions/<SUB-ID>/resourceGroups/<RG-NAME>/providers/Microsoft.Compute/virtualMachines/\", Computer)\n| project TimeGenerated, Computer, InstanceName, ServiceState, _ResourceId\n"
          time_aggregation_method = "Count"
          threshold               = 1
          operator                = "GreaterThan"
          resource_id_column      = null
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001",
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-db-mail-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001597"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Capital Infrastructure Project Delivery"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Property Tax and Assessment"
      }
    }
    vm_windows_syslog_alert_dev_canadacentral = {
      name                = "VM-Windows-Syslog-Alert-dev-canadacentral"
      resource_group_name = "rg-pta-app-nonprod-canadacentral-001"
      location            = "canadacentral"
      scopes = [
        "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-pta-dev-canadacentral-001"
      ]
      severity                          = 3
      evaluation_frequency              = "PT5M"
      window_duration                   = "PT5M"
      description                       = "Triigered when there is a event for syslog error"
      display_name                      = "VM-Windows-Syslog-Alert-dev-canadacentral"
      enabled                           = false
      auto_mitigation_enabled           = false
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = "P2D"
      target_resource_types             = ["Microsoft.Compute/virtualMachines"]
      criteria = [
        {
          query                   = "// To create an alert for this query, click '+ New alert rule'\nunion Event, Syslog // Event table stores Windows event records, Syslog stores Linux records\n| where TimeGenerated > ago(1h)\n| where EventLevelName == \"Error\" // EventLevelName is used in the Event (Windows) records\nor SeverityLevel== \"err\" // SeverityLevel is used in Syslog (Linux) records"
          time_aggregation_method = "Count"
          threshold               = 1
          operator                = "GreaterThan"
          resource_id_column      = null
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/lga-servicenow-integration_group/providers/microsoft.insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001597"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Capital Infrastructure Project Delivery"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Property Tax and Assessment"
      }
    }
    vm_windows_syslog_alert_uat_canadacentral = {
      name                = "VM-Windows-Syslog-Alert-uat-canadacentral"
      resource_group_name = "rg-pta-app-nonprod-canadacentral-001"
      location            = "canadacentral"
      scopes = [
        "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-pta-uat-canadacentral-001"
      ]
      severity                          = 3
      evaluation_frequency              = "PT5M"
      window_duration                   = "PT5M"
      description                       = "Triigered when there is a event for syslog error"
      display_name                      = "VM-Windows-Syslog-Alert-uat-canadacentral"
      enabled                           = false
      auto_mitigation_enabled           = false
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = "P2D"
      target_resource_types             = ["Microsoft.Compute/virtualMachines"]
      criteria = [
        {
          query                   = "// To create an alert for this query, click '+ New alert rule'\nunion Event, Syslog // Event table stores Windows event records, Syslog stores Linux records\n| where TimeGenerated > ago(1h)\n| where EventLevelName == \"Error\" // EventLevelName is used in the Event (Windows) records\nor SeverityLevel== \"err\" // SeverityLevel is used in Syslog (Linux) records"
          time_aggregation_method = "Count"
          threshold               = 1
          operator                = "GreaterThan"
          resource_id_column      = null
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/CCAC6A90-8B47-44A9-88B2-520506C45219/resourceGroups/lga-servicenow-integration_group/providers/microsoft.insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        ApplicationId           = "BCH – LIX -0000001597"
        ApplicationServiceLevel = "Silver"
        BusinessUnit            = "Capital Infrastructure Project Delivery"
        CostCenterId            = "YT-01585.S.IMP.CLZ"
        Environment             = "NonProd"
        Name                    = "Property Tax and Assessment"
      }
    }
  }
  alert_processing_rules = {}
}

activity_log_alert_imports = {
  key_vault_deletion = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-alerts-pta-nonprod-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/KeyVault-Deletion-Alert-canadacentral"
  service_outage     = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-alerts-pta-nonprod-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/Service-Outage-Alert-canadacentral"
}

metric_alert_imports = {
  backup_alert                                           = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/Backup Alert"
  mi_sql_cpu_high_alert_canadacentral                    = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/MI-SQL-CPU-High-Alert-canadacentral"
  restore_job_failed_pta_canadacentral                   = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/Restore-Job-Failed-PTA-canadacentral"
  restore_job_failed_pta_nonprod_canadacentral           = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-shared-pta-app-nonprod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/Restore-Job-Failed-PTA-Nonprod-canadacentral"
  sql_db_cpu_alert_canadacentral                         = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-shared-pta-app-nonprod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/SQL-DB-CPU-Alert-canadacentral"
  sql_db_memory_alert_canadacentral                      = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-alerts-pta-nonprod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/SQL-DB-Memory-Alert-canadacentral"
  sql_db_pta_2025_cpu_alert_canadacentral                = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-shared-pta-app-nonprod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/SQL-DB-PTA-2025-CPU-Alert-canadacentral"
  sql_db_pta_system_cpu_alert_canadacentral              = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-shared-pta-app-nonprod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/SQL-DB-PTA-SYSTEM-CPU-Alert-canadacentral"
  sub_pta_nonprod_vm_cpu_usage_alert_canadacentral       = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-shared-pta-app-nonprod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/Sub-PTA-Nonprod-VM-CPU-Usage-Alert-canadacentral"
  vm_os_disk_iops_alert_canadacentral                    = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-alerts-pta-nonprod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/VM-OS-Disk-IOPS-Alert-canadacentral"
  vm_pta_nonprod_cpu_high_warning                        = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-alerts-pta-nonprod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/vm-pta-nonprod-cpu-high-warning"
  vm_pta_nonprod_cpu_high_warning_shared_pta_app_nonprod = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-shared-pta-app-nonprod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/vm-pta-nonprod-cpu-high-warning"
  vm_pta_nonprod_memory_high_warning                     = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-alerts-pta-nonprod-canadacentral-001/providers/Microsoft.Insights/metricAlerts/vm-pta-nonprod-memory-high-warning"
}

log_search_alert_imports = {
  keyvault_secret_expired_alert_canadacentral                               = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-alerts-pta-nonprod-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/KeyVault-Secret-Expired-Alert-canadacentral"
  keyvault_secret_near_expiry_alert_canadacentral                           = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-alerts-pta-nonprod-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/KeyVault-Secret-Near-Expiry-Alert-canadacentral"
  resource_creation_alert_canadacentral                                     = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-alerts-pta-nonprod-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/Resource-Creation-Alert-canadacentral"
  storage_account_container_deletion_alert_canadacentral                    = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-alerts-pta-nonprod-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/Storage-Account-Container-Deletion-Alert-canadacentral"
  storage_account_deletion_alert_canadacentral                              = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-alerts-pta-nonprod-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/Storage-Account-Deletion-Alert-canadacentral"
  sub_pta_nonprod_vm_heartbeat_lost                                         = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-shared-pta-app-nonprod-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/Sub-PTA-nonprod-VM-Heartbeat lost"
  vm_backup_failure_alert_canadacentral                                     = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-alerts-pta-nonprod-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/VM-Backup-Failure-Alert-canadacentral"
  vm_free_disk_space_pta_nonprod_alert_canadacentral                        = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/VM-Free-Disk-Space-PTA--Nonprod-Alert-canadacentral"
  vm_free_disk_space_pta_nonprod_alert_canadacentral_shared_pta_app_nonprod = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-shared-pta-app-nonprod-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/VM-Free-Disk-Space-PTA--Nonprod-Alert-canadacentral"
  vm_heartbeat_lost_alert_canadacentral                                     = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-shared-pta-app-nonprod-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/VM-Heartbeat-Lost-Alert-canadacentral"
  vm_heartbeat_lost_canadacentral                                           = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-shared-pta-app-nonprod-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/VM-Heartbeat-Lost-canadacentral"
  vm_windows_service_stopped_pta_nonprod_canadacentral                      = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-shared-pta-app-nonprod-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/VM-Windows-Service-Stopped-PTA-Nonprod-canadacentral"
  vm_windows_syslog_alert_dev_canadacentral                                 = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/VM-Windows-Syslog-Alert-dev-canadacentral"
  vm_windows_syslog_alert_uat_canadacentral                                 = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/VM-Windows-Syslog-Alert-uat-canadacentral"
}

# Not managed here:
#   actionrules 'alert suppression pta non-prod' (rg-alerts-pta-nonprod-canadacentral-001): azurerm rejects processing rule names with spaces; rename it in Azure to manage it
#   scheduledqueryrules 'VM-Patching-Failed-PTA-Nonprod-canadacentral' (rg-pta-app-nonprod-canadacentral-001): SystemAssigned identity (the wrapper has no identity input)
#   scheduledqueryrules 'VM-Pending-Update-PTA-canadacentral' (rg-pta-app-nonprod-canadacentral-001): SystemAssigned identity (the wrapper has no identity input)
alert_processing_rule_imports = {}

# SKU from az resource list. Developer bastions attach to the VNet, not a subnet.
bastion_host = {
  bh = {
    name               = "bh-pta-nonprod-canadacentral-001"
    resource_group_key = "app"
    location           = "canadacentral"
    sku                = "Developer"
    scale_units        = 2
    virtual_network_id = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-nonprod-canadacentral-001"
    zones              = []
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Property Tax and Assessment"
    }
  }
}

bastion_host_imports = {
  bh = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/bastionHosts/bh-pta-nonprod-canadacentral-001"
}

key_vault = {
  app = {
    name                            = "kvptanonprodcac001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    tenant_id                       = "8fbb85e8-0cbc-48c3-a2e9-528cef30ec27"
    sku_name                        = "premium"
    enabled_for_deployment          = true
    enabled_for_disk_encryption     = true
    enabled_for_template_deployment = true
    legacy_access_policies_enabled  = false
    public_network_access_enabled   = false
    purge_protection_enabled        = true
    soft_delete_retention_days      = 90
    network_acls = {
      bypass                     = "AzureServices"
      default_action             = "Deny"
      ip_rules                   = []
      virtual_network_subnet_ids = []
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Property Tax and Assessment"
    }
  }
}

key_vault_imports = {
  app = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvptanonprodcac001"
}

# Created by the platform (Defender/AMA default workspace).
log_analytics_workspace = {
  default_cca = {
    name                            = "defaultworkspace-770996e1-e364-4315-9ab9-0c703d5d0996-cca"
    resource_group_key              = "defaultresourcegroup_cca"
    location                        = "canadacentral"
    sku                             = "PerGB2018"
    retention_in_days               = 30
    daily_quota_gb                  = -1
    internet_ingestion_enabled      = "true"
    internet_query_enabled          = "true"
    local_authentication_enabled    = true
    allow_resource_only_permissions = true
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Property Tax and Assessment"
    }
  }
}

log_analytics_workspace_imports = {
  default_cca = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/defaultresourcegroup-cca/providers/Microsoft.OperationalInsights/workspaces/defaultworkspace-770996e1-e364-4315-9ab9-0c703d5d0996-cca"
}

# Its VNet flow log stays unmanaged.
network_watcher = {
  canadacentral = {
    name               = "NetworkWatcher_canadacentral_pta_app_nonprod"
    resource_group_key = "shared_app"
    location           = "canadacentral"
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Property Tax and Assessment"
    }
  }
}

network_watcher_imports = {
  canadacentral = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-shared-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkWatchers/NetworkWatcher_canadacentral_pta_app_nonprod"
}

public_ssh_key = {
  teskey = {
    name               = "teskey"
    resource_group_key = "app"
    location           = "canadacentral"
    public_key         = "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQDCmTeKHPT1q7e8euaScUYDlGkYEm9Q/ieNcsImEqdAHT5tZTXeznxwd/P9sRG2JtMc0SmNFJ16YvIsFZZmgzvY79YbbWDVqwPrqd+hdTiK050SUoMGeT3QuCyBlhqUMDMDKP7AdBrDUKGwBwWqaES1fEIYIqbZfVMKT8FlBVH+wGOAqOToWlgv65CR1piE+F8UuuGTcRe5t732LWZsnXEYp8G59sL9acG88P5uw1cEtvMLLRdbY+wS5/c//nSSzG22kQ89rTXbsLjMOI2BLJ8jq/TpicfuMMLsCMW0UERiLKIufGy83r6QGREB1G9G/MqYzJC5S4QaLlTB8ESYDnij1Zm9JdJDlHmFUGlf+xDvyqTrAoiGU/dIpfACtzeKyCNTOf2J2+0Xb248FGV9kjX5rM+8G8TM4r22lE2ouusqbQqhwZc36V53ytJRJJ2A5rupS0gTCul1cQC/96+95XZeuNaDxJro9eP/xnKiJCmhu+PA+Ynk/ZuMqTEBBFDHGAU= generated-by-azure"
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Property Tax and Assessment"
    }
  }
}

public_ssh_key_imports = {
  teskey = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Compute/sshPublicKeys/teskey"
}

# Alert settings were not exported; confirm before import with
# az backup vault show -g rg-pta-app-nonprod-canadacentral-001 -n rsv-pta-canadacentral-001 --query properties.monitoringSettings
recovery_services_vault = {
  app = {
    name                          = "rsv-pta-canadacentral-001"
    resource_group_key            = "app"
    location                      = "canadacentral"
    sku                           = "RS0"
    storage_mode_type             = "GeoRedundant"
    cross_region_restore_enabled  = true
    soft_delete_enabled           = true
    immutability                  = "Unlocked"
    public_network_access_enabled = false
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Property Tax and Assessment"
    }
  }
}

recovery_services_vault_imports = {
  app = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.RecoveryServices/vaults/rsv-pta-canadacentral-001"
}

# Azure Backup owns these; only the containers are adopted.
restore_point_collection = {
  vm_dev = {
    name                      = "AzureBackup_vm-pta-dev-canadacentral-001_6310668979513713073"
    resource_group_name       = "AzureBackupRG_canadacentral_1"
    location                  = "canadacentral"
    source_virtual_machine_id = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-pta-dev-canadacentral-001"
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Property Tax and Assessment"
    }
  }
  vm_uat = {
    name                      = "AzureBackup_vm-pta-uat-canadacentral-001_6310668978059190306"
    resource_group_name       = "AzureBackupRG_canadacentral_1"
    location                  = "canadacentral"
    source_virtual_machine_id = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-pta-uat-canadacentral-001"
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Property Tax and Assessment"
    }
  }
}

restore_point_collection_imports = {
  vm_dev = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/AzureBackupRG_canadacentral_1/providers/Microsoft.Compute/restorePointCollections/AzureBackup_vm-pta-dev-canadacentral-001_6310668979513713073"
  vm_uat = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/AzureBackupRG_canadacentral_1/providers/Microsoft.Compute/restorePointCollections/AzureBackup_vm-pta-uat-canadacentral-001_6310668978059190306"
}

# The export spells the identity's group as resourcegroups; ARM IDs are case-insensitive.
sql_server = {
  app = {
    name                                     = "sql-pta-nonprod-canadacentral-001"
    resource_group_key                       = "app"
    location                                 = "canadacentral"
    server_version                           = "12.0"
    administrator_login                      = "CloudSA152b9877"
    public_network_access_enabled            = false
    outbound_network_restriction_enabled     = false
    connection_policy                        = "Proxy"
    express_vulnerability_assessment_enabled = true
    primary_user_assigned_identity_id        = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-mid-pta-app-nonprod-canadacentral-001/providers/Microsoft.ManagedIdentity/userAssignedIdentities/mid-app-pta-nonprod-canadacentral-001"
    user_assigned_identity_ids = [
      "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-mid-pta-app-nonprod-canadacentral-001/providers/Microsoft.ManagedIdentity/userAssignedIdentities/mid-app-pta-nonprod-canadacentral-001"
    ]
    azuread_administrator = {
      azuread_authentication_only = true
      login_username              = "a-zdehaan.cloud@bchydro.onmicrosoft.com"
      object_id                   = "9a32fedc-9366-41e6-8c0a-b5170063d3e2"
      tenant_id                   = "8fbb85e8-0cbc-48c3-a2e9-528cef30ec27"
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Property Tax and Assessment"
    }
  }
  pam_poc = {
    name                                     = "sql-pta-nonprod-canadacentral-pam-poc-001"
    resource_group_key                       = "app_pam_poc"
    location                                 = "canadacentral"
    server_version                           = "12.0"
    administrator_login                      = "CloudSA23714ab6"
    public_network_access_enabled            = false
    outbound_network_restriction_enabled     = false
    connection_policy                        = "Proxy"
    express_vulnerability_assessment_enabled = true
    primary_user_assigned_identity_id        = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-mid-pta-app-nonprod-canadacentral-001/providers/Microsoft.ManagedIdentity/userAssignedIdentities/mid-app-pta-nonprod-canadacentral-001"
    user_assigned_identity_ids = [
      "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-mid-pta-app-nonprod-canadacentral-001/providers/Microsoft.ManagedIdentity/userAssignedIdentities/mid-app-pta-nonprod-canadacentral-001"
    ]
    azuread_administrator = {
      azuread_authentication_only = true
      login_username              = "a-zdehaan.cloud@bchydro.onmicrosoft.com"
      object_id                   = "9a32fedc-9366-41e6-8c0a-b5170063d3e2"
      tenant_id                   = "8fbb85e8-0cbc-48c3-a2e9-528cef30ec27"
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Property Tax and Assessment"
    }
  }
}

sql_server_imports = {
  app     = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Sql/servers/sql-pta-nonprod-canadacentral-001"
  pam_poc = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-PAM-POC/providers/Microsoft.Sql/servers/sql-pta-nonprod-canadacentral-pam-poc-001"
}

# blobServices came back empty, so blob_properties is left unset (no drift either way).
storage_account = {
  app = {
    name                              = "stptanonprodcac001"
    resource_group_key                = "app"
    location                          = "canadacentral"
    account_kind                      = "StorageV2"
    account_tier                      = "Standard"
    account_replication_type          = "ZRS"
    access_tier                       = "Hot"
    allow_nested_items_to_be_public   = false
    cross_tenant_replication_enabled  = false
    default_to_oauth_authentication   = false
    https_traffic_only_enabled        = true
    infrastructure_encryption_enabled = true
    is_hns_enabled                    = false
    min_tls_version                   = "TLS1_2"
    public_network_access_enabled     = false
    sftp_enabled                      = false
    shared_access_key_enabled         = true
    network_rules = {
      bypass         = ["AzureServices"]
      default_action = "Deny"
      ip_rules = [
        "155.190.0.9",
        "155.190.0.10",
        "142.52.203.224",
        "155.190.0.11",
        "155.190.0.8",
        "52.190.17.9"
      ]
      virtual_network_subnet_ids = [
        "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-nonprod-canadacentral-001/subnets/snet-sql-pta-nonprod-canadacentral-001"
      ]
      private_link_access = [
        {
          endpoint_resource_id = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourcegroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Sql/servers/*"
          endpoint_tenant_id   = "8fbb85e8-0cbc-48c3-a2e9-528cef30ec27"
        },
        {
          endpoint_resource_id = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/providers/Microsoft.Security/datascanners/storageDataScanner"
          endpoint_tenant_id   = "8fbb85e8-0cbc-48c3-a2e9-528cef30ec27"
        }
      ]
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Property Tax and Assessment"
    }
  }
  testing = {
    name                              = "sttesting153"
    resource_group_key                = "shared_app"
    location                          = "canadacentral"
    account_kind                      = "StorageV2"
    account_tier                      = "Standard"
    account_replication_type          = "LRS"
    access_tier                       = "Hot"
    allow_nested_items_to_be_public   = false
    cross_tenant_replication_enabled  = false
    default_to_oauth_authentication   = false
    https_traffic_only_enabled        = true
    infrastructure_encryption_enabled = false
    is_hns_enabled                    = false
    large_file_share_enabled          = true
    min_tls_version                   = "TLS1_2"
    public_network_access_enabled     = false
    sftp_enabled                      = false
    shared_access_key_enabled         = true
    network_rules = {
      bypass                     = ["AzureServices"]
      default_action             = "Deny"
      ip_rules                   = []
      virtual_network_subnet_ids = []
      private_link_access = [
        {
          endpoint_resource_id = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/providers/Microsoft.Security/datascanners/storageDataScanner"
          endpoint_tenant_id   = "8fbb85e8-0cbc-48c3-a2e9-528cef30ec27"
        }
      ]
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Property Tax and Assessment"
    }
  }
}

# Flow log storage. Deny_Public_Access_On_PaaS_Services_v0 denies any write
# while publicNetworkAccess is Enabled, so it is read, not adopted, until exempted.
storage_account_existing = {
  network_watcher = {
    name               = "stnwptanonprodcac"
    resource_group_key = "shared_app"
  }
}

storage_account_imports = {
  app     = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Storage/storageAccounts/stptanonprodcac001"
  testing = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-shared-pta-app-nonprod-canadacentral-001/providers/Microsoft.Storage/storageAccounts/sttesting153"
}

event_grid_system_topic = {
  app_storage = {
    name                        = "stptanonprodcac001-b644d4a9-4376-44bd-8540-02a81fbf3d60"
    resource_group_key          = "app"
    location                    = "canadacentral"
    topic_type                  = "microsoft.storage.storageaccounts"
    source_resource_id          = null
    exported_source_resource_id = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/microsoft.storage/storageaccounts/stptanonprodcac001"
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Property Tax and Assessment"
    }
  }
  network_watcher_storage = {
    name                        = "stnwptanonprodcac-69e28e03-6b43-41f2-9dd1-5ebb0adfa854"
    resource_group_key          = "shared_app"
    location                    = "canadacentral"
    topic_type                  = "microsoft.storage.storageaccounts"
    source_resource_id          = null
    exported_source_resource_id = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-shared-pta-app-nonprod-canadacentral-001/providers/microsoft.storage/storageaccounts/stnwptanonprodcac"
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Property Tax and Assessment"
    }
  }
  testing_storage = {
    name                        = "sttesting153-e66a2853-f0db-4612-99ca-10f2a0e625b7"
    resource_group_key          = "shared_app"
    location                    = "canadacentral"
    topic_type                  = "microsoft.storage.storageaccounts"
    source_resource_id          = null
    exported_source_resource_id = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-shared-pta-app-nonprod-canadacentral-001/providers/microsoft.storage/storageaccounts/sttesting153"
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Property Tax and Assessment"
    }
  }
}

event_grid_system_topic_imports = {
  app_storage             = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.EventGrid/systemTopics/stptanonprodcac001-b644d4a9-4376-44bd-8540-02a81fbf3d60"
  network_watcher_storage = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-shared-pta-app-nonprod-canadacentral-001/providers/Microsoft.EventGrid/systemTopics/stnwptanonprodcac-69e28e03-6b43-41f2-9dd1-5ebb0adfa854"
  testing_storage         = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-shared-pta-app-nonprod-canadacentral-001/providers/Microsoft.EventGrid/systemTopics/sttesting153-e66a2853-f0db-4612-99ca-10f2a0e625b7"
}

# Export reports isolationScope = None, which the wrapper models as null.
user_assigned_identity = {
  app = {
    name               = "mid-app-pta-nonprod-canadacentral-001"
    resource_group_key = "mid_app"
    location           = "canadacentral"
    isolation_scope    = null
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Property Tax and Assessment"
    }
  }
}

user_assigned_identity_imports = {
  app = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-mid-pta-app-nonprod-canadacentral-001/providers/Microsoft.ManagedIdentity/userAssignedIdentities/mid-app-pta-nonprod-canadacentral-001"
}

# UAT runs on disk-pta-nonprod-canadacentrall-001 after an
# OS disk swap; its original OS disk is now unattached and left unmanaged.
# Admin passwords come from windows_virtual_machine_admin_passwords (secure input only).
windows_virtual_machine = {
  dev = {
    name               = "vm-pta-dev-canadacentral-001"
    resource_group_key = "app"
    location           = "canadacentral"
    size               = "Standard_F2s_v2"
    zone               = null
    admin_username     = "a-ptadevf2sv2"
    computer_name      = "ptadevcac1"
    network_interface_ids = [
      "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkInterfaces/nic-vm-pta-dev-canadacentral-001"
    ]
    os_managed_disk_id                                     = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Compute/disks/vm-pta-dev-canadacentral-001_OsDisk_1_85b2df7ff6994f6981ce79d9afd86016"
    allow_extension_operations                             = true
    automatic_updates_enabled                              = false
    bypass_platform_safety_checks_on_user_schedule_enabled = true
    disk_controller_type                                   = "SCSI"
    encryption_at_host_enabled                             = true
    license_type                                           = "Windows_Server"
    patch_assessment_mode                                  = "AutomaticByPlatform"
    patch_mode                                             = "AutomaticByPlatform"
    provision_vm_agent                                     = true
    secure_boot_enabled                                    = true
    vm_agent_platform_updates_enabled                      = true
    vtpm_enabled                                           = true
    additional_capabilities = {
      hibernation_enabled = false
    }
    boot_diagnostics = null
    identity = {
      type = "SystemAssigned, UserAssigned"
      user_assigned_identity_ids = [
        "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-mid-pta-app-nonprod-canadacentral-001/providers/Microsoft.ManagedIdentity/userAssignedIdentities/mid-app-pta-nonprod-canadacentral-001"
      ]
    }
    os_disk = {
      name                 = "vm-pta-dev-canadacentral-001_OsDisk_1_85b2df7ff6994f6981ce79d9afd86016"
      caching              = "ReadWrite"
      disk_size_gb         = 127
      storage_account_type = "Premium_ZRS"
    }
    source_image_reference = {
      publisher = "MicrosoftWindowsServer"
      offer     = "WindowsServer"
      sku       = "2022-datacenter-g2"
      version   = "latest"
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Property Tax and Assessment"
    }
  }
  uat = {
    name               = "vm-pta-uat-canadacentral-001"
    resource_group_key = "app"
    location           = "canadacentral"
    size               = "Standard_F2s_v2"
    zone               = null
    admin_username     = "a-ptauatf2sv2"
    computer_name      = "ptauatcac1"
    network_interface_ids = [
      "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkInterfaces/nic-vm-pta-uat-canadacentral-001"
    ]
    os_managed_disk_id                                     = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Compute/disks/disk-pta-nonprod-canadacentrall-001"
    allow_extension_operations                             = true
    automatic_updates_enabled                              = false
    bypass_platform_safety_checks_on_user_schedule_enabled = true
    disk_controller_type                                   = "SCSI"
    encryption_at_host_enabled                             = true
    license_type                                           = "Windows_Server"
    patch_assessment_mode                                  = "AutomaticByPlatform"
    patch_mode                                             = "AutomaticByPlatform"
    provision_vm_agent                                     = true
    secure_boot_enabled                                    = true
    vm_agent_platform_updates_enabled                      = true
    vtpm_enabled                                           = true
    additional_capabilities = {
      hibernation_enabled = false
    }
    boot_diagnostics = null
    identity = {
      type = "SystemAssigned, UserAssigned"
      user_assigned_identity_ids = [
        "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-mid-pta-app-nonprod-canadacentral-001/providers/Microsoft.ManagedIdentity/userAssignedIdentities/mid-app-pta-nonprod-canadacentral-001"
      ]
    }
    os_disk = {
      name                 = "disk-pta-nonprod-canadacentrall-001"
      caching              = "ReadWrite"
      disk_size_gb         = 127
      storage_account_type = "Premium_LRS"
    }
    source_image_reference = {
      publisher = "MicrosoftWindowsServer"
      offer     = "WindowsServer"
      sku       = "2022-datacenter-g2"
      version   = "latest"
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Property Tax and Assessment"
    }
  }
}

windows_virtual_machine_imports = {
  dev = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-pta-dev-canadacentral-001"
  uat = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-pta-uat-canadacentral-001"
}

# nsg-pep reuses priority 200 across directions, which needs NSG wrapper 0.1.1.
# Protocols use the wrapper's casing (Tcp); Azure reports TCP, so a case-only
# update may appear.
# Rules owned by SQL MI's network intent policy (8 on nsg-sql) and the Defender
# JIT rule on nsg-app-dev are left out and stay as they are.
network_security_group = {
  app_dev = {
    name               = "nsg-app-pta-dev-canadacentral-001"
    resource_group_key = "app"
    location           = "canadacentral"
    security_rules = {
      allowonprem = {
        name                       = "AllowOnPrem"
        access                     = "Allow"
        direction                  = "Inbound"
        priority                   = 1001
        protocol                   = "*"
        source_port_range          = "*"
        destination_port_range     = "*"
        source_address_prefixes    = ["10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "142.52.0.0/16"]
        destination_address_prefix = "*"
      }
      allowbastionservice = {
        name                       = "AllowBastionService"
        access                     = "Allow"
        direction                  = "Inbound"
        priority                   = 1000
        protocol                   = "Tcp"
        source_port_range          = "*"
        destination_port_range     = "3389"
        source_address_prefix      = "168.63.129.16"
        destination_address_prefix = "*"
      }
      allowrunnerdeploy = {
        name                       = "AllowRunnerDeploy"
        access                     = "Allow"
        direction                  = "Inbound"
        priority                   = 1010
        protocol                   = "Tcp"
        source_port_range          = "8172"
        destination_port_range     = "8172"
        source_address_prefix      = "10.195.114.7"
        destination_address_prefix = "10.195.64.132"
      }
      allowcyberarkservers = {
        name                       = "AllowCyberArkServers"
        access                     = "Allow"
        direction                  = "Inbound"
        priority                   = 750
        protocol                   = "*"
        source_port_range          = "*"
        destination_port_range     = "*"
        source_address_prefixes    = ["10.195.116.4", "10.195.116.5"]
        destination_address_prefix = "*"
      }
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Property Tax and Assessment"
    }
  }
  app_uat = {
    name               = "nsg-app-pta-uat-canadacentral-001"
    resource_group_key = "app"
    location           = "canadacentral"
    security_rules = {
      allowonprem = {
        name                       = "AllowOnPrem"
        access                     = "Allow"
        direction                  = "Inbound"
        priority                   = 200
        protocol                   = "*"
        source_port_range          = "*"
        destination_port_range     = "*"
        source_address_prefixes    = ["10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "142.52.0.0/16"]
        destination_address_prefix = "*"
      }
      denyallinbound = {
        name                       = "DenyAllInbound"
        access                     = "Deny"
        direction                  = "Inbound"
        priority                   = 1000
        protocol                   = "*"
        source_port_range          = "*"
        destination_port_range     = "*"
        source_address_prefix      = "*"
        destination_address_prefix = "*"
      }
      allowbastionservice = {
        name                       = "AllowBastionService"
        access                     = "Allow"
        direction                  = "Inbound"
        priority                   = 120
        protocol                   = "Tcp"
        source_port_range          = "*"
        destination_port_range     = "3389"
        source_address_prefix      = "168.63.129.16"
        destination_address_prefix = "*"
      }
      allowcyberarkservers = {
        name                       = "AllowCyberArkServers"
        access                     = "Allow"
        direction                  = "Inbound"
        priority                   = 800
        protocol                   = "*"
        source_port_range          = "*"
        destination_port_range     = "*"
        source_address_prefixes    = ["10.195.116.4", "10.195.116.5"]
        destination_address_prefix = "*"
      }
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Property Tax and Assessment"
    }
  }
  pep = {
    name               = "nsg-pep-pta-nonprod-canadacentral-001"
    resource_group_key = "app"
    location           = "canadacentral"
    security_rules = {
      allowonprem = {
        name                       = "AllowOnPrem"
        access                     = "Allow"
        direction                  = "Inbound"
        priority                   = 200
        protocol                   = "*"
        source_port_range          = "*"
        destination_port_range     = "*"
        source_address_prefixes    = ["10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "142.52.0.0/16"]
        destination_address_prefix = "*"
      }
      denyallinbound = {
        name                       = "DenyAllInbound"
        access                     = "Deny"
        direction                  = "Inbound"
        priority                   = 1000
        protocol                   = "*"
        source_port_range          = "*"
        destination_port_range     = "*"
        source_address_prefix      = "*"
        destination_address_prefix = "*"
      }
      allowsqlinbound = {
        name                   = "AllowSQLInbound"
        access                 = "Allow"
        direction              = "Inbound"
        priority               = 100
        protocol               = "*"
        source_port_range      = "*"
        destination_port_range = "1433-65535"
        source_address_prefixes = [
          "10.0.0.0/8",
          "172.16.0.0/12",
          "192.168.0.0/16",
          "142.52.0.0/16",
          "155.190.0.0/16"
        ]
        destination_address_prefix = "*"
      }
      allowalloutboundtoonprem = {
        name                       = "AllowAllOutboundToOnprem"
        access                     = "Allow"
        direction                  = "Outbound"
        priority                   = 200
        protocol                   = "*"
        source_port_range          = "*"
        destination_port_range     = "*"
        source_address_prefix      = "*"
        destination_address_prefix = "*"
      }
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Property Tax and Assessment"
    }
  }
  sql = {
    name               = "nsg-sql-pta-nonprod-canadacentral-001"
    resource_group_key = "app"
    location           = "canadacentral"
    security_rules = {
      allowonprem = {
        name                       = "AllowOnPrem"
        access                     = "Allow"
        direction                  = "Inbound"
        priority                   = 200
        protocol                   = "*"
        source_port_range          = "*"
        destination_port_range     = "*"
        source_address_prefixes    = ["10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "142.52.0.0/16"]
        destination_address_prefix = "*"
      }
      denyallinbound = {
        name                       = "DenyAllInbound"
        access                     = "Deny"
        direction                  = "Inbound"
        priority                   = 1000
        protocol                   = "*"
        source_port_range          = "*"
        destination_port_range     = "*"
        source_address_prefix      = "*"
        destination_address_prefix = "*"
      }
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Property Tax and Assessment"
    }
  }
}

import_network_security_group = {
  app_dev = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-app-pta-dev-canadacentral-001"
  app_uat = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-app-pta-uat-canadacentral-001"
  pep     = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-pep-pta-nonprod-canadacentral-001"
  sql     = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-sql-pta-nonprod-canadacentral-001"
}

network_security_rule_imports = {
  "app_dev/allowonprem" = {
    nsg_key  = "app_dev"
    rule_key = "allowonprem"
    id       = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-app-pta-dev-canadacentral-001/securityRules/AllowOnPrem"
  }
  "app_dev/allowbastionservice" = {
    nsg_key  = "app_dev"
    rule_key = "allowbastionservice"
    id       = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-app-pta-dev-canadacentral-001/securityRules/AllowBastionService"
  }
  "app_dev/allowrunnerdeploy" = {
    nsg_key  = "app_dev"
    rule_key = "allowrunnerdeploy"
    id       = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-app-pta-dev-canadacentral-001/securityRules/AllowRunnerDeploy"
  }
  "app_dev/allowcyberarkservers" = {
    nsg_key  = "app_dev"
    rule_key = "allowcyberarkservers"
    id       = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-app-pta-dev-canadacentral-001/securityRules/AllowCyberArkServers"
  }
  "app_uat/allowonprem" = {
    nsg_key  = "app_uat"
    rule_key = "allowonprem"
    id       = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-app-pta-uat-canadacentral-001/securityRules/AllowOnPrem"
  }
  "app_uat/denyallinbound" = {
    nsg_key  = "app_uat"
    rule_key = "denyallinbound"
    id       = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-app-pta-uat-canadacentral-001/securityRules/DenyAllInbound"
  }
  "app_uat/allowbastionservice" = {
    nsg_key  = "app_uat"
    rule_key = "allowbastionservice"
    id       = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-app-pta-uat-canadacentral-001/securityRules/AllowBastionService"
  }
  "app_uat/allowcyberarkservers" = {
    nsg_key  = "app_uat"
    rule_key = "allowcyberarkservers"
    id       = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-app-pta-uat-canadacentral-001/securityRules/AllowCyberArkServers"
  }
  "pep/allowonprem" = {
    nsg_key  = "pep"
    rule_key = "allowonprem"
    id       = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-pep-pta-nonprod-canadacentral-001/securityRules/AllowOnPrem"
  }
  "pep/denyallinbound" = {
    nsg_key  = "pep"
    rule_key = "denyallinbound"
    id       = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-pep-pta-nonprod-canadacentral-001/securityRules/DenyAllInbound"
  }
  "pep/allowsqlinbound" = {
    nsg_key  = "pep"
    rule_key = "allowsqlinbound"
    id       = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-pep-pta-nonprod-canadacentral-001/securityRules/AllowSQLInbound"
  }
  "pep/allowalloutboundtoonprem" = {
    nsg_key  = "pep"
    rule_key = "allowalloutboundtoonprem"
    id       = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-pep-pta-nonprod-canadacentral-001/securityRules/AllowAllOutboundToOnprem"
  }
  "sql/allowonprem" = {
    nsg_key  = "sql"
    rule_key = "allowonprem"
    id       = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-sql-pta-nonprod-canadacentral-001/securityRules/AllowOnPrem"
  }
  "sql/denyallinbound" = {
    nsg_key  = "sql"
    rule_key = "denyallinbound"
    id       = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-sql-pta-nonprod-canadacentral-001/securityRules/DenyAllInbound"
  }
}

private_endpoint = {
  key_vault = {
    name                            = "pep-kv-pta-nonprod-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-nonprod-canadacentral-001/subnets/snet-pep-pta-nonprod-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvptanonprodcac001"
    private_service_connection_name = "kvptanonprodcac001"
    subresource_names               = ["vault"]
    network_interface_name          = null
    private_dns_zone_group_name     = "pta_nonprod_canadacentral_kv_zone_group"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.vaultcore.azure.net"
    ]
    ip_configurations = {}
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Property Tax and Assessment"
    }
  }
  sql_mi = {
    name                            = "pep-mi-sql-pta-nonprod-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-nonprod-canadacentral-001/subnets/snet-pep-pta-nonprod-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Sql/managedInstances/mi-sql-pta-nonprod-canadacentral-001"
    private_service_connection_name = "pep-mi-sql-pta-nonprod-canadacentral-001"
    subresource_names               = ["managedInstance"]
    network_interface_name          = "pep-mi-sql-pta-nonprod-canadacentral-001-nic"
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.6082b7ce55ac.database.windows.net"
    ]
    ip_configurations = {
      pep_mi_sql_pta_nonprod_canadacentral_001 = {
        name               = "pep-mi-sql-pta-nonprod-canadacentral-001"
        private_ip_address = "10.195.66.6"
        subresource_name   = "managedInstance"
        member_name        = "managedInstance"
      }
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Property Tax and Assessment"
    }
  }
  backup = {
    name                            = "pep-rsv-pta-backup-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-nonprod-canadacentral-001/subnets/snet-pep-pta-nonprod-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourcegroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.RecoveryServices/vaults/rsv-pta-canadacentral-001"
    private_service_connection_name = "pep-rsv-pta-backup-canadacentral-001_6e20a904-410e-45e5-accd-7c60ba0bc035"
    subresource_names               = ["AzureBackup"]
    network_interface_name          = null
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.cnc.backup.windowsazure.com",
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.queue.core.windows.net",
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net"
    ]
    ip_configurations = {}
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Property Tax and Assessment"
    }
  }
  sql = {
    name                            = "pep-sql-pta-nonprod-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-nonprod-canadacentral-001/subnets/snet-pep-pta-nonprod-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Sql/servers/sql-pta-nonprod-canadacentral-001"
    private_service_connection_name = "pep-sql-pta-nonprod-canadacentral-001"
    subresource_names               = ["sqlServer"]
    network_interface_name          = "pep-sql-pta-nonprod-canadacentral-001-nic"
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.database.windows.net"
    ]
    ip_configurations = {}
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Property Tax and Assessment"
    }
  }
  storage_blob = {
    name                            = "pep-st-blob-pta-nonprod-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-nonprod-canadacentral-001/subnets/snet-pep-pta-nonprod-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Storage/storageAccounts/stptanonprodcac001"
    private_service_connection_name = "pep-st-blob-pta-nonprod-canadacentral-001"
    subresource_names               = ["blob"]
    network_interface_name          = "pep-st-blob-pta-nonprod-canadacentral-001-nic"
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net"
    ]
    ip_configurations = {}
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Property Tax and Assessment"
    }
  }
  sql_mi_pam_poc = {
    name                            = "pep-mi-sql-pta-nonprod-canadacentral-PAM-POC-001"
    resource_group_key              = "app_pam_poc"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-nonprod-canadacentral-001/subnets/snet-pep-pta-nonprod-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-PAM-POC/providers/Microsoft.Sql/managedInstances/mi-sql-pta-nonprod-canadacentral-pam-poc-001"
    private_service_connection_name = "pep-mi-sql-pta-nonprod-canadacentral-PAM-POC-001"
    subresource_names               = ["managedInstance"]
    network_interface_name          = "pep-mi-sql-pta-nonprod-canadacentral-PAM-POC-001-nic"
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.6082b7ce55ac.database.windows.net"
    ]
    ip_configurations = {}
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Property Tax and Assessment"
    }
  }
  sql_pam_poc = {
    name                            = "pep-sql-pta-nonprod-canadacentral-PAM-POC-001"
    resource_group_key              = "app_pam_poc"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-nonprod-canadacentral-001/subnets/snet-pep-pta-nonprod-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-PAM-POC/providers/Microsoft.Sql/servers/sql-pta-nonprod-canadacentral-pam-poc-001"
    private_service_connection_name = "pep-sql-pta-nonprod-canadacentral-PAM-POC-001"
    subresource_names               = ["sqlServer"]
    network_interface_name          = "pep-sql-pta-nonprod-canadacentral-PAM-POC-001-nic"
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.database.windows.net"
    ]
    ip_configurations = {}
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Property Tax and Assessment"
    }
  }
}

private_endpoint_imports = {
  key_vault      = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-kv-pta-nonprod-canadacentral-001"
  sql_mi         = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-mi-sql-pta-nonprod-canadacentral-001"
  backup         = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-rsv-pta-backup-canadacentral-001"
  sql            = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-sql-pta-nonprod-canadacentral-001"
  storage_blob   = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-st-blob-pta-nonprod-canadacentral-001"
  sql_mi_pam_poc = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-PAM-POC/providers/Microsoft.Network/privateEndpoints/pep-mi-sql-pta-nonprod-canadacentral-PAM-POC-001"
  sql_pam_poc    = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-PAM-POC/providers/Microsoft.Network/privateEndpoints/pep-sql-pta-nonprod-canadacentral-PAM-POC-001"
}

# The two nic-vm-kt-test-* NICs have no VM and stay unmanaged.
network_interface = {
  dev = {
    name                           = "nic-vm-pta-dev-canadacentral-001"
    resource_group_key             = "app"
    location                       = "canadacentral"
    enabled                        = true
    accelerated_networking_enabled = false
    ip_forwarding_enabled          = false
    ip_configurations = {
      primary = {
        name                          = "internal"
        primary                       = true
        private_ip_address            = "10.195.64.132"
        private_ip_address_allocation = "Dynamic"
        subnet_id                     = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-nonprod-canadacentral-001/subnets/snet-app-pta-dev-canadacentral-001"
      }
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Property Tax and Assessment"
    }
  }
  uat = {
    name                           = "nic-vm-pta-uat-canadacentral-001"
    resource_group_key             = "app"
    location                       = "canadacentral"
    enabled                        = true
    accelerated_networking_enabled = false
    ip_forwarding_enabled          = false
    ip_configurations = {
      primary = {
        name                          = "internal"
        primary                       = true
        private_ip_address            = "10.195.64.4"
        private_ip_address_allocation = "Dynamic"
        subnet_id                     = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-nonprod-canadacentral-001/subnets/snet-app-pta-uat-canadacentral-001"
      }
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Property Tax and Assessment"
    }
  }
}

# No NIC-level NSGs; the NSGs are attached to subnets.
network_interface_nsg_associations = {}

# Disabled, as in Fabric and FIT: the VNet module's body omits subnets and
# peerings, and the only peering is the vWAN hub connection owned by
# tf-deploy-platform-connectivity. The SQL subnet's route table and delegation
# belong to SQL MI. defaultOutboundAccess is not reported, so Azure's default
# (enabled) is assumed; it is create-time only.
virtual_network = {
  app = {
    name               = "vnet-pta-nonprod-canadacentral-001"
    resource_group_key = "app"
    location           = "canadacentral"
    address_space      = ["10.195.64.0/22"]
    dns_servers = {
      dns_servers = ["10.195.1.4"]
    }
    ddos_protection_plan = {
      enable = true
      id     = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/ddosProtectionPlans/ddos-protection-plan"
    }
    subnets = {
      app_uat = {
        name                                          = "snet-app-pta-uat-canadacentral-001"
        address_prefixes                              = ["10.195.64.0/25"]
        default_outbound_access_enabled               = true
        private_endpoint_network_policies             = "Disabled"
        private_link_service_network_policies_enabled = true
        network_security_group = {
          id = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-app-pta-uat-canadacentral-001"
        }
        service_endpoint_policies       = {}
        service_endpoints_with_location = []
        delegations                     = []
      }
      app_dev = {
        name                                          = "snet-app-pta-dev-canadacentral-001"
        address_prefixes                              = ["10.195.64.128/25"]
        default_outbound_access_enabled               = true
        private_endpoint_network_policies             = "Disabled"
        private_link_service_network_policies_enabled = true
        network_security_group = {
          id = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-app-pta-dev-canadacentral-001"
        }
        service_endpoint_policies = {}
        service_endpoints_with_location = [
          {
            service   = "Microsoft.Storage"
            locations = ["canadacentral", "canadaeast"]
          }
        ]
        delegations = []
      }
      sql = {
        name                                          = "snet-sql-pta-nonprod-canadacentral-001"
        address_prefixes                              = ["10.195.65.0/24"]
        default_outbound_access_enabled               = true
        private_endpoint_network_policies             = "Disabled"
        private_link_service_network_policies_enabled = true
        network_security_group = {
          id = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-sql-pta-nonprod-canadacentral-001"
        }
        route_table = {
          id = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/routeTables/rt-mi-sql-pta-nonprod-canadacentral-001"
        }
        service_endpoint_policies = {}
        service_endpoints_with_location = [
          {
            service   = "Microsoft.Storage"
            locations = ["canadacentral", "canadaeast"]
          }
        ]
        delegations = [
          {
            name = "dlg-mi-sql-pta-nonprod-canadacentral-001"
            service_delegation = {
              name = "Microsoft.Sql/managedInstances"
              actions = [
                "Microsoft.Network/virtualNetworks/subnets/join/action",
                "Microsoft.Network/virtualNetworks/subnets/prepareNetworkPolicies/action",
                "Microsoft.Network/virtualNetworks/subnets/unprepareNetworkPolicies/action"
              ]
            }
          }
        ]
      }
      pep = {
        name                                          = "snet-pep-pta-nonprod-canadacentral-001"
        address_prefixes                              = ["10.195.66.0/23"]
        default_outbound_access_enabled               = true
        private_endpoint_network_policies             = "RouteTableEnabled"
        private_link_service_network_policies_enabled = true
        network_security_group = {
          id = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-pep-pta-nonprod-canadacentral-001"
        }
        service_endpoint_policies       = {}
        service_endpoints_with_location = []
        delegations                     = []
      }
    }
    tags = {
      ApplicationId           = "BCH – LIX -0000001597"
      ApplicationServiceLevel = "Silver"
      BusinessUnit            = "Capital Infrastructure Project Delivery"
      CostCenterId            = "YT-01585.S.IMP.CLZ"
      Environment             = "NonProd"
      Name                    = "Property Tax and Assessment"
    }
  }
}

virtual_network_imports = {
  app = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-nonprod-canadacentral-001"
}

virtual_network_subnet_imports = {
  pta_app_uat = {
    vnet_key   = "app"
    subnet_key = "app_uat"
    id         = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-nonprod-canadacentral-001/subnets/snet-app-pta-uat-canadacentral-001"
  }
  pta_app_dev = {
    vnet_key   = "app"
    subnet_key = "app_dev"
    id         = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-nonprod-canadacentral-001/subnets/snet-app-pta-dev-canadacentral-001"
  }
  pta_sql = {
    vnet_key   = "app"
    subnet_key = "sql"
    id         = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-nonprod-canadacentral-001/subnets/snet-sql-pta-nonprod-canadacentral-001"
  }
  pta_pep = {
    vnet_key   = "app"
    subnet_key = "pep"
    id         = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-nonprod-canadacentral-001/subnets/snet-pep-pta-nonprod-canadacentral-001"
  }
}

# =====================================================================
# Hub private DNS: links and records in the shared zones (connectivity subscription)
# =====================================================================

enable_hub_private_dns = true

hub_private_dns_zone_link = {
  "link-blob-pta-nonprod-canadacentral-001" = {
    name               = "link-blob-pta-nonprod-canadacentral-001"
    zone_name          = "privatelink.blob.core.windows.net"
    virtual_network_id = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-nonprod-canadacentral-001"
  }
  "link-files-pta-nonprod-canadacentral-001" = {
    name               = "link-files-pta-nonprod-canadacentral-001"
    zone_name          = "privatelink.file.core.windows.net"
    virtual_network_id = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-nonprod-canadacentral-001"
  }
  "link-pta-nonprod-canadacentral-001" = {
    name                 = "link-pta-nonprod-canadacentral-001"
    zone_name            = "bchydro.bc.ca"
    virtual_network_id   = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-nonprod-canadacentral-001"
    registration_enabled = true
  }
  "link-sql-pta-nonprod-canadacentral-001" = {
    name               = "link-sql-pta-nonprod-canadacentral-001"
    zone_name          = "privatelink.database.windows.net"
    virtual_network_id = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-nonprod-canadacentral-001"
  }
  "link-vault-pta-nonprod-canadacentral-001" = {
    name               = "link-vault-pta-nonprod-canadacentral-001"
    zone_name          = "privatelink.vaultcore.azure.net"
    virtual_network_id = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-nonprod-canadacentral-001"
  }
  "mi-sql-pta-privatelink-canadacentral" = {
    name               = "mi-sql-pta-privatelink-canadacentral"
    zone_name          = "privatelink.6082b7ce55ac.database.windows.net"
    virtual_network_id = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-nonprod-canadacentral-001"
  }
  "privatelink.agentsvc.azure-automation.net/link-pta-nonprod-canadacentral" = {
    name               = "link-pta-nonprod-canadacentral"
    zone_name          = "privatelink.agentsvc.azure-automation.net"
    virtual_network_id = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-nonprod-canadacentral-001"
  }
  "privatelink.cnc.backup.windowsazure.com/5kuztzayyvoh2" = {
    name               = "5kuztzayyvoh2"
    zone_name          = "privatelink.cnc.backup.windowsazure.com"
    virtual_network_id = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-nonprod-canadacentral-001"
  }
  "privatelink.monitor.azure.com/link-pta-nonprod-canadacentral" = {
    name               = "link-pta-nonprod-canadacentral"
    zone_name          = "privatelink.monitor.azure.com"
    virtual_network_id = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-nonprod-canadacentral-001"
  }
  "privatelink.ods.opinsights.azure.com/link-pta-nonprod-canadacentral" = {
    name               = "link-pta-nonprod-canadacentral"
    zone_name          = "privatelink.ods.opinsights.azure.com"
    virtual_network_id = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-nonprod-canadacentral-001"
  }
  "privatelink.oms.opinsights.azure.com/link-pta-nonprod-canadacentral" = {
    name               = "link-pta-nonprod-canadacentral"
    zone_name          = "privatelink.oms.opinsights.azure.com"
    virtual_network_id = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-nonprod-canadacentral-001"
  }
  "privatelink.queue.core.windows.net/5kuztzayyvoh2" = {
    name               = "5kuztzayyvoh2"
    zone_name          = "privatelink.queue.core.windows.net"
    virtual_network_id = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-nonprod-canadacentral-001"
  }
}

hub_private_dns_zone_link_imports = {
  "link-blob-pta-nonprod-canadacentral-001"                                  = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net/virtualNetworkLinks/link-blob-pta-nonprod-canadacentral-001"
  "link-files-pta-nonprod-canadacentral-001"                                 = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.file.core.windows.net/virtualNetworkLinks/link-files-pta-nonprod-canadacentral-001"
  "link-pta-nonprod-canadacentral-001"                                       = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/bchydro.bc.ca/virtualNetworkLinks/link-pta-nonprod-canadacentral-001"
  "link-sql-pta-nonprod-canadacentral-001"                                   = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.database.windows.net/virtualNetworkLinks/link-sql-pta-nonprod-canadacentral-001"
  "link-vault-pta-nonprod-canadacentral-001"                                 = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.vaultcore.azure.net/virtualNetworkLinks/link-vault-pta-nonprod-canadacentral-001"
  "mi-sql-pta-privatelink-canadacentral"                                     = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.6082b7ce55ac.database.windows.net/virtualNetworkLinks/mi-sql-pta-privatelink-canadacentral"
  "privatelink.agentsvc.azure-automation.net/link-pta-nonprod-canadacentral" = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.agentsvc.azure-automation.net/virtualNetworkLinks/link-pta-nonprod-canadacentral"
  "privatelink.cnc.backup.windowsazure.com/5kuztzayyvoh2"                    = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.cnc.backup.windowsazure.com/virtualNetworkLinks/5kuztzayyvoh2"
  "privatelink.monitor.azure.com/link-pta-nonprod-canadacentral"             = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.monitor.azure.com/virtualNetworkLinks/link-pta-nonprod-canadacentral"
  "privatelink.ods.opinsights.azure.com/link-pta-nonprod-canadacentral"      = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.ods.opinsights.azure.com/virtualNetworkLinks/link-pta-nonprod-canadacentral"
  "privatelink.oms.opinsights.azure.com/link-pta-nonprod-canadacentral"      = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.oms.opinsights.azure.com/virtualNetworkLinks/link-pta-nonprod-canadacentral"
  "privatelink.queue.core.windows.net/5kuztzayyvoh2"                         = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.queue.core.windows.net/virtualNetworkLinks/5kuztzayyvoh2"
}

hub_private_dns_a_record = {
  "app-dev.pta" = {
    name      = "app-dev.pta"
    zone_name = "bchydro.bc.ca"
    ttl       = 300
    records   = ["10.195.64.132"]
  }
  "app-uat.pta" = {
    name      = "app-uat.pta"
    zone_name = "bchydro.bc.ca"
    ttl       = 10
    records   = ["10.195.64.4"]
  }
}

hub_private_dns_a_record_imports = {
  "app-dev.pta" = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/bchydro.bc.ca/A/app-dev.pta"
  "app-uat.pta" = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/bchydro.bc.ca/A/app-uat.pta"
}
