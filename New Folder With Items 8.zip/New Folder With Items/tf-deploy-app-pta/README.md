# tf-deploy-app-pta

Terraform that adopts the existing **PTA** (Property Tax and Assessment)
resources into state, following the same layout as the Fabric deploy repo.

| Environment | Subscription | ID |
|---|---|---|
| `nonprod` | Sub-Pta-NonProd | `770996e1-e364-4315-9ab9-0c703d5d0996` |
| `prod` | Sub-Pta-Prod | `9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4` |

Use Terraform `>= 1.9, < 2.0`, one state per environment, and select
`envs/nonprod.tfvars` or `envs/prod.tfvars`. Adopt nonprod first; prod follows
the same runs and stages.

## Status

**Nonprod** is filled from the Azure resource export of 2026-10-20 and is
ready for the first import run. The Windows VMs, their NICs and the VNet are
filled in but switched off; they are adopted later, one stage at a time (see
[Staged adoption](#staged-adoption)).

**Prod** is filled from its own export of 2026-10-20 the same way, with the
same staged tiers (the VM and its NIC, then the VNet). Prod differs from
nonprod:

- The bastion is **Standard** SKU (zones 1-3) and uses the existing public IP
  `vnetptaprodcanadacentral001IPv4979`; the IP itself is not managed. Two
  other public IPs (`vnet-pta-prod-canadacentral-001-IPv4`,
  `vnetptaprodcanadacentral001IPv4770`) are not attached to anything.
- There is one Windows VM (`vm-pta-prod-canadacentral-001`, key `vm`), so the
  password variable is `{ vm = "..." }`. Its admin_password replace risk is
  the same as nonprod.
- No logical SQL server; SQL MI only (not managed).
- `pep-stnwfitprdcac001xdf` in `NetworkWatcherRG` is named for FIT but lives in
  the PTA subscription. Kept as exported.
- Alerts that stay out are listed at `alert_processing_rule_imports` in
  `envs/prod.tfvars`.

## Tiers

| File | Implementation | Nonprod |
|---|---|---|
| `resource_group.tf` | `tf-wrapper-avm-resource-group` 2.0.0 | 6 nonprod, 4 prod, enabled |
| `alerts.tf` | `tf-wrapper-avm-ptn-monitoring-amba-alz` 0.3.3 | 2 activity log, 13 metric, 14 log search alerts, enabled |
| `bastion_host.tf` | `tf-wrapper-avm-bastion-host` 0.0.1 | 1 Developer SKU, enabled |
| `key_vault.tf` | `tf-wrapper-avm-key-vault` 0.4.0 | 1, enabled |
| `log_analytics_workspace.tf` | `tf-wrapper-avm-log-analytics-workspace` 0.1.2 | 1, enabled |
| `network_watcher.tf` | `azurerm_network_watcher` | 1, enabled |
| `public_ssh_key.tf` | `tf-wrapper-avm-public-ssh-key` 0.1.0 | 1, enabled |
| `recovery_services_vault.tf` | `tf-wrapper-avm-recovery-services-vault` 0.1.0 | 1, enabled |
| `restore_point_collection.tf` | `azurerm_virtual_machine_restore_point_collection` | 2, enabled |
| `sql_server.tf` | `tf-wrapper-avm-sql-server` 0.1.0 | 2, enabled |
| `storage_account.tf` | `tf-wrapper-avm-storage-account` 0.3.0; read-only `azapi_resource` data source | 2 + 1 read-only, enabled |
| `event_grid_system_topic.tf` | `azurerm_eventgrid_system_topic` | 3, enabled |
| `user_assigned_identity.tf` | `tf-wrapper-avm-user-assigned-identity` 0.0.4 | 1, enabled |
| `windows_virtual_machine.tf` | `tf-wrapper-avm-virtual-machine-windows` 0.1.6, including NICs and NIC NSG associations | 2, disabled (separate run) |
| `virtual_network.tf` | `tf-wrapper-avm-virtual-network` 0.1.0 | 1 + 4 subnets, disabled (hub connection) |
| `network_security_group.tf` | `tf-wrapper-avm-network-security-group` 0.1.1 | 4 + 14 rules, enabled |
| `private_endpoint.tf` | `tf-wrapper-avm-private-endpoint` 0.1.2 | 7, enabled |
| `role_assignment.tf` | `tf-wrapper-avm-role-assignment` 0.3.6 | all off |
| `compute_disk.tf` | `removed` block only | - |

Event Grid topics, restore-point collections and the network watcher use
AzureRM directly, as Fabric does, so every exported property can be set.
Storage accounts go through the wrapper with every property passed
explicitly, since its secure defaults do not match the deployed accounts;
expect its policy `check` warnings on plan. Wrapper tags are switched off where the wrapper allows
it (`wrapper_tags_enabled = false`); the resource group, private endpoint,
NSG, Bastion, LAW, UAI, RSV, SQL, SSH key and monitoring wrappers still add
`managed-by`/`module` tags, so expect a tag update on those during import.

Storage accounts with public network access enabled are read with
`data.azapi_resource.storage_account_existing` (`storage_account_existing`
in tfvars) instead of being managed: `Deny_Public_Access_On_PaaS_Services_v0`
denies any write to them, adoption included. Move an account into
`storage_account` once it has a policy exemption. They are listed under
"Blocked by policy" in [WRAPPER-GAPS.md](WRAPPER-GAPS.md).

What stays unmanaged is in [WRAPPER-GAPS.md](WRAPPER-GAPS.md).

## Things to check before the first import

- Storage accounts import as an in-place update, not a plain import. The
  upstream AVM module (0.10.0) builds the AzAPI body itself: it sorts
  `ipRules`, omits `encryption.services.blob/file`, `dnsEndpointType` and
  `ipv6Rules`, sends `requireInfrastructureEncryption` only when true, and
  uses API version `2025-08-01`. None of these change a setting, but the
  apply is a full PUT of each account; later plans are clean. Anything else
  in the storage diff is a real change. Because it is a PUT, an Azure Policy
  deny on shared keys or public access would fail the apply.
- `storage_account.local_user_enabled` defaults to `true` (Azure's default,
  absent from the export) because the wrapper defaults it to `false`.
- `storage_account.infrastructure_encryption_enabled`,
  `sql_server.administrator_login` and `public_ssh_key.public_key` force
  replacement. They are copied from the export; a `replace` in the plan
  means one of them is wrong.
- Recovery Services vault `monitoringSettings` is null on the live vault,
  but the upstream module always writes it. Both alert flags default to
  `false` so adoption does not switch alerting on; the vault is allow-listed
  in `scripts/import_gate.sh` for that write.
- `KeyVault-Deletion-Alert-canadacentral` points at an action group whose
  ID contains a leading space (`actiongroups/ ag-servicenow-...`). It is
  kept as exported.
- NSG rule protocols are written as `Tcp` because the wrapper rejects upper
  case. Azure reports `TCP`, so a case-only update may appear.
- `AzureBackupRG_canadacentral_1` and
  `MA_defaultazuremonitorworkspace-cca_canadacentral_managed` are not
  managed. Azure refuses any write to them: the first has a `managedBy` the
  wrapper cannot express, the second carries an Azure Monitor deny
  assignment. Restore-point collections reference the backup group by name.

## Adoption

Every resource here already exists in Azure. Each tier has `enable_<type>`
and an import map; imports only run while the tier is enabled, and
validations check every import ID against the key, name, resource group and
`subscription_id`.

Before the first apply:

- Make sure auto-apply is off on the HCP workspace, so every apply is
  confirmed by hand after reading the plan.
- Optionally put a `CanNotDelete` lock on the app resource groups for the
  adoption window. A lock makes Azure refuse any delete, so an unexpected
  replace fails instead of destroying the resource. Do not lock
  `AzureBackupRG_canadacentral_1`; Azure Backup has to delete old restore
  points there.

  ```bash
  az lock create --name adoption-no-delete --lock-type CanNotDelete --resource-group <rg>
  az lock delete --name adoption-no-delete --resource-group <rg>   # afterwards
  ```

Each run, first or staged:

1. Run `.github/workflows/import-verify.yml` for the environment. It only
   plans, then runs `scripts/import_gate.sh`, which wraps
   `scripts/verify_zero_diff.sh`: it fails on anything other than imports and
   tag updates and reports any replace separately.
2. Fix diffs by correcting tfvars, never by changing Azure. Repeat until the
   gate passes. Never accept a replace or delete with `--allow-resource`.
   Accepted addresses go in `scripts/import_gate.sh`.
3. Run `.github/workflows/import-apply.yml` for the environment, with
   `confirm` set to `apply`. Read the check job's summary (gate output and
   plan: only imports and tag updates), then approve the apply job. It
   re-plans, re-runs the gate and refuses to apply if the change set moved
   since the check. Do not use `landing-zone-multi-env.yml` while imports
   are pending; it applies with `-auto-approve` and no gate.
4. Empty the import maps of the tiers that applied.

## Staged adoption

These tiers are complete in `envs/nonprod.tfvars` but switched off, because
adopting them can change or destroy something that is hard to get back. Each
gets its own import-verify and apply, after the first run has applied.

| Stage | Flags | Why it is held back |
|---|---|---|
| 1. Windows VMs | `enable_windows_virtual_machine`, `enable_network_interface` | Needs the admin passwords; a wrong plan would rebuild the VM and delete its OS disk |
| 2. Virtual network | `enable_virtual_network` | The vWAN hub connection is owned by the connectivity repo |

### Stage 1: Windows VMs

`admin_password` forces replacement in AzureRM, and the upstream VM module
does not ignore it. Right after import Terraform has no password in state, so
the plan may want to destroy and recreate the VM. A recreate builds a new VM
from the marketplace image, and because the OS disks have
`deleteOption: Delete`, the current OS disk is deleted with it. Fabric's
nonprod import-verify run with the same wrapper (0.1.6) showed only a tag
update on its Windows VM, so a replace is not expected, but check anyway.

1. Set `windows_virtual_machine_admin_passwords` as a **sensitive** variable
   on the HCP workspace (HCL: `{ dev = "...", uat = "..." }`). Use the real
   passwords, not random ones: a clean import never sends them to Azure, but
   if a VM were ever rebuilt it would get this value. Validation blocks the
   plan until both are set.
2. Set `enable_windows_virtual_machine = true` and
   `enable_network_interface = true`.
3. Run import-verify. Expected: two VM imports and two NIC imports.
4. If the plan shows a replace on either VM (look for `admin_password`),
   stop. Do not apply and do not allow-list it. The fix is to manage these
   two VMs with a plain `azurerm_windows_virtual_machine` resource that has
   `lifecycle { ignore_changes = [admin_password] }`, which the AVM wrapper
   cannot offer.
5. With a clean plan, apply as usual and empty
   `windows_virtual_machine_imports`.

The UAT VM runs on `disk-pta-nonprod-canadacentrall-001` after an OS disk
swap; its original OS disk is unattached and not managed.

### Stage 2: Virtual network

The VNet module sends a body without subnets or peerings, so the import plan
shows both being removed. The VNet's only peering is the vWAN hub connection
`peering-hub-to-pta-nonprod-canadacentral-001`, declared in
`tf-deploy-platform-connectivity`. Upstream tests confirm that subnets and
peerings created outside the module survive the update, but not vWAN hub
connections. This stage is the same as Fabric's and FIT's.

1. Agree a window with the connectivity team, so they can restore the hub
   connection from their repo if it drops.
2. Set `enable_virtual_network = true` and run import-verify. Expected: one
   VNet import and four subnet imports.
3. `defaultOutboundAccess` is not reported for any subnet, so it is set to
   Azure's default (`true`). It is create-time only: a subnet replace in the
   plan means that guess is wrong, so stop and correct it.
4. Apply, check the hub connection and connectivity from the VMs, then empty
   the VNet and subnet import maps.

The SQL subnet's route table and delegation, the eight
`Microsoft.Sql-managedInstances_UseOnly_*` rules on `nsg-sql` and the
Defender JIT rule on `nsg-app-dev` belong to SQL MI and Defender and are not
managed.

## Role assignments

`role_assignment.tf` uses one typed map: resource type, parent key, then
assignment key. Every `enable_<type>_role_assignment` is false and
`role_assignments = {}` in both environments. Nothing is inferred from the
export, and existing assignments need their own imports.

```hcl
enable_key_vault_role_assignment = true
role_assignments = {
  key_vault = {
    app = {
      secrets_user = {
        role_definition_id_or_name = "Key Vault Secrets User"
        principal_id               = "<approved-principal-object-id>"
      }
    }
  }
}
```

## Pipeline

| Workflow | Purpose |
|---|---|
| `import-verify.yml` | Plan and gate. Never applies. Run this first |
| `import-apply.yml` | Gate, approval on the `<env>` environment, re-gate, apply |
| `landing-zone-multi-env.yml` | Deploy pipeline, `workflow_dispatch` only |
| `tflint.yml` | HCL lint on push and PR |
| `trivy.yml` | IaC scan on PR and weekly |

`import-apply.yml` needs required reviewers on the `nonprod` and `prod`
GitHub Environments, or the apply job runs without stopping. Its check job
runs outside any environment, so `TF_API_TOKEN`, `TF_CLOUD_ORGANIZATION`
and `TFC_WORKSPACE_PREFIX` must be set at repo or org level.

`TFC_WORKSPACE_PREFIX` must be set before the first run (`az-pta`, matching Fabric's `az-fabric`).

This repo is now maintained by hand. Do not re-run
`generate-deploy-repos.py` over it.
