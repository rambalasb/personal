module "storage_account" {
  for_each = var.enable_storage_account ? var.storage_account : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-storage-account/azurerm"
  version = "0.3.0"

  name      = each.value.name
  parent_id = module.resource_group[each.value.resource_group_key].resource_id
  location  = coalesce(each.value.location, module.resource_group[each.value.resource_group_key].location)

  # Wrapper defaults differ from the deployed accounts, so every exported
  # property is passed through.
  account_kind                      = each.value.account_kind
  account_tier                      = each.value.account_tier
  account_replication_type          = each.value.account_replication_type
  access_tier                       = each.value.access_tier
  allow_nested_items_to_be_public   = each.value.allow_nested_items_to_be_public
  cross_tenant_replication_enabled  = each.value.cross_tenant_replication_enabled
  default_to_oauth_authentication   = each.value.default_to_oauth_authentication
  https_traffic_only_enabled        = each.value.https_traffic_only_enabled
  infrastructure_encryption_enabled = each.value.infrastructure_encryption_enabled
  is_hns_enabled                    = each.value.is_hns_enabled
  large_file_share_enabled          = each.value.large_file_share_enabled
  local_user_enabled                = each.value.local_user_enabled
  min_tls_version                   = each.value.min_tls_version
  public_network_access_enabled     = each.value.public_network_access_enabled
  sftp_enabled                      = each.value.sftp_enabled
  shared_access_key_enabled         = each.value.shared_access_key_enabled

  # Blob service properties were not exported; null leaves them unmanaged.
  blob_properties = each.value.blob_properties == null ? null : {
    container_delete_retention_policy = { days = each.value.blob_properties.container_delete_retention_policy.days }
    delete_retention_policy           = { days = each.value.blob_properties.delete_retention_policy.days }
  }

  network_rules = {
    bypass                     = each.value.network_rules.bypass
    default_action             = each.value.network_rules.default_action
    ip_rules                   = each.value.network_rules.ip_rules
    virtual_network_subnet_ids = each.value.network_rules.virtual_network_subnet_ids
    private_link_access        = each.value.network_rules.private_link_access
  }

  enable_telemetry     = false
  wrapper_tags_enabled = false
  tags                 = each.value.tags
}

import {
  for_each = var.enable_storage_account ? var.storage_account_imports : {}

  to = module.storage_account[each.key].module.storage_account.azapi_resource.this
  id = each.value
}

# Read-only: Deny_Public_Access_On_PaaS_Services_v0 denies any write to an
# account with public network access enabled. Move to storage_account once
# the account is exempted. AzAPI rather than azurerm so the access keys stay
# out of state.
data "azapi_resource" "storage_account_existing" {
  for_each = var.storage_account_existing

  type      = "Microsoft.Storage/storageAccounts@2025-08-01"
  name      = each.value.name
  parent_id = "/subscriptions/${var.subscription_id}/resourceGroups/${var.resource_group[each.value.resource_group_key].name}"
}
