# Wrapper gaps: `tf-deploy-app-pta`

Resources in the PTA subscriptions that this repo does not manage. Nonprod
counts are from the Azure resource export of 2026-10-20. Prod follows the
same patterns; prod-specific differences are in the README and the skipped
alerts are listed in `envs/prod.tfvars`. Prod columns below are from the
earlier resource list.

## Staged (nonprod)

Code and tfvars are complete; each is switched off and adopted in its own
run. See "Staged adoption" in the README.

| Resource | Reason |
|---|---|
| `vm-pta-dev-canadacentral-001`, `vm-pta-uat-canadacentral-001` (+ NICs) | Needs the admin passwords; `admin_password` may plan a replace |
| `vnet-pta-nonprod-canadacentral-001` (+ 4 subnets) | vWAN hub connection owned by the connectivity repo |

## Blocked by policy

Public network access is enabled, so `Deny_Public_Access_On_PaaS_Services_v0`
denies any write, and the wrapper adopts with a PUT. Read with
`data.azapi_resource.storage_account_existing` until exempted.

| Resource | Environment | Reason |
|---|---|---|
| `stnwptanonprodcac` (flow log storage) | nonprod | Disabling public access would stop flow logs, which rely on the trusted-services bypass |
| `sqlvahnwiqbvli57nk` | prod | Default action Allow; the name suggests SQL vulnerability assessment storage |
| `stptaprodcac001`, `stptaprodcac002` | prod | Have private endpoints, but public access is still enabled |

## Not managed

| Type | Nonprod | Prod | Reason |
|---|---:|---:|---|
| `microsoft.sql/managedinstances/databases` | 66 | ? | Not adopted with the instance |
| `microsoft.compute/virtualmachines/extensions` | 15 | ? | VM wrapper is called with `extensions = {}`; existing extensions are left alone |
| `microsoft.insights/metricalerts` | 0 | 6 | All 13 nonprod metric alerts are managed |
| `microsoft.insights/datacollectionrules` | 12 | 3 | Mostly VM Insights/OTel rules from test VMs; `tf-wrapper-avm-data-collection-stack` needs stream/destination modelling |
| `microsoft.insights/scheduledqueryrules` | 2 | 12 | `VM-Patching-Failed-*` and `VM-Pending-Update-*` have a system-assigned identity, which the monitoring wrapper cannot set |
| `microsoft.network/networkinterfaces` (private endpoint, test VM) | 9 | 6 | PE NICs belong to their endpoint; `nic-vm-kt-test-298`/`-301` have no VM |
| `microsoft.network/networksecuritygroups` rules | 9 | ? | 8 SQL MI intent-policy rules on `nsg-sql` and the Defender JIT rule on `nsg-app-dev` are owned by those services |
| `microsoft.sql/servers/databases` | 10 | ? | Wrapper called with `databases = {}` |
| `microsoft.compute/snapshots` | 4 | 0 | Ad hoc OS snapshots; no wrapper |
| `microsoft.sql/managedinstances` | 2 | 1 | `tf-wrapper-avm-sql-managed-instance` needs the admin password, subnet, vCores and storage size |
| `microsoft.network/serviceendpointpolicies` | 2 | 1 | Created by SQL MI |
| `microsoft.compute/disks` (unattached) | 1 | 0 | Original UAT OS disk left over from the OS disk swap; candidate for deletion |
| `microsoft.insights/activitylogalerts` | 1 | 4 | `VM-OS-Patch-Available-PTA-Nonprod-Alert` matches two statuses; the wrapper's `status` is a single string |
| `microsoft.alertsmanagement/actionrules` | 1 | 2 | `alert suppression pta non-prod`: AzureRM rejects processing rule names with spaces; rename it in Azure to manage it |
| `microsoft.network/routetables` | 1 | 1 | Created by SQL MI |
| `microsoft.network/networkintentpolicies` | 1 | 0 | Created by SQL MI |
| `microsoft.sql/virtualclusters` | 1 | 0 | Created by SQL MI |
| `microsoft.network/networkwatchers/flowlogs` | 1 | ? | No wrapper |
| `microsoft.monitor/accounts` | 1 | 1 | Platform default Azure Monitor workspace |
| `microsoft.insights/datacollectionendpoints` | 1 | 1 | Belongs to the default Azure Monitor workspace |
| `microsoft.maintenance/maintenanceconfigurations` | 1 | 1 | `tf-wrapper-avm-maintenance-configuration` 0.0.2 exists; not added yet |
| `microsoft.insights/actiongroups` | 0 | 1 | Alerts point at shared action groups in the management subscription |
| `microsoft.network/publicipaddresses` | 0 | 3 | No wrapper published |
