# Both attached disks are VM OS disks, owned inline by their VM. Drops any
# standalone disk from state without deleting it in Azure.
removed {
  from = module.compute_disk

  lifecycle {
    destroy = false
  }
}
