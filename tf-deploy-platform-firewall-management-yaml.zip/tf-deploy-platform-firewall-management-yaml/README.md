# tf-deploy-platform-firewall-management

Azure Firewall rules, IP groups, firewall policies and firewalls for the
connectivity subscription (`f3835bc1-9829-4ac8-9d7a-0999e0b29b90`), as YAML.
Changing a rule or an IP group means editing a YAML file. There is no Terraform
to write.

HCP workspace `az-platform-firewall`. Everything else in the subscription,
including the resource groups, belongs to `tf-deploy-platform-connectivity`.
`HANDOVER.md` has the boundary, the open items before the first apply, and the
reasons behind the less obvious settings.

> **Not applied yet.** The estate is still being adopted through the import
> blocks in `pending_imports_*.tf`. Until that apply lands, the pipelines only
> accept a plan that changes nothing in Azure, so hold rule changes until then.

## Layout

```text
config/
  ip-groups/<app>.yaml          IP groups, one file per app; shared.yaml,
                                onprem.yaml, baseline.yaml, transit.yaml for the rest
  rule-collection-groups/
    azfwpol-connectivity-001/   the live policy (both hub firewalls use it)
      rcg-<priority>-<name>/
        _group.yaml             group name and priority
        NNNN-<collection>.yaml  one rule collection per file
    azfwpol-connectivity-001-BACKUP-…/   March 2026 copy, attached to no firewall
  policies.yaml                 firewall policies
  firewalls.yaml                firewalls
  classic-rules.yaml            inline rules on the transit firewall (no policy)
  schema/                       JSON Schemas; VS Code picks them up automatically
firewall.tfvars                 subscription, tags, Log Analytics workspace IDs
```

The `.tf` files at the root only read `config/` and pass it to the wrapper
modules. `modules/config` types the YAML, fills defaults and fails the plan on
the usual mistakes.

## Finding things

```sh
# Collections for an app and environment
ls config/rule-collection-groups/azfwpol-connectivity-001/*/ | grep fit-prod

# Where an IP group is defined, and every rule that uses it
grep -rn '^ipgrp-vnet-fit-prod-canadacentral-001:' config/ip-groups
grep -rln 'ipgrp-vnet-fit-prod-canadacentral-001' config/rule-collection-groups/azfwpol-connectivity-001

# Which IP group holds an address (exact match only, not CIDR containment)
grep -rn '10.195.124' config/ip-groups
```

Leave the BACKUP policy out of searches unless you mean it; its rules are not
live.

## Changing an IP group

Edit `ip_addresses` in the group's entry. Every rule that names the group
follows; no rule file changes.

```yaml
ipgrp-vnet-newapp-prod-canadacentral-001:
  ip_addresses: ["10.195.44.0/22", "10.195.48.10"]
```

- **The key is the Azure name.** Renaming a key deletes the group and creates a
  new one, and fails while any rule still references the old name.
- **New group:** search for the addresses first; an existing group may already
  cover them. Otherwise add it to the app's file (a new app gets a new file), or
  `shared.yaml` if several apps use it. Addresses can be IPs, CIDRs or
  `a.b.c.d-a.b.c.e` ranges.
- `location` defaults to `canadacentral`. Both regions reference the same group.
- **Outside `rg-ip-groups-connectivity-global`** (six groups today), the key is
  `"<rg_key>/<name>"` with `name` and `rg_key` set, because two groups share a
  name across resource groups. `rg_key` is one of `ip_groups` (default),
  `hub_cc`, `hub_ce`, `shared_cc`, `backup_cc`. New groups should go in the
  default.

## Adding or changing a rule

Find the collection file and add to its `rules` list.

```yaml
# network rule
  - name: "r-allow-newapp-to-clz"
    protocols: ["TCP"]
    source_ip_groups: ["ipgrp-vnet-newapp-prod-canadacentral-001"]
    destination_ip_groups: ["ipgrp-cacentral-clz-subnets"]
    destination_ports: ["443"]

# application rule
  - name: "r-allow-database"
    protocols: ["Mssql:1433"]
    source_ip_groups: ["ipgrp-cacentral-hosted-runners"]
    destination_fqdns: ["*.database.windows.net"]
```

Write only the fields the rule uses; the rest default to empty.

| Field | Takes |
| --- | --- |
| `protocols` | network: `TCP`, `UDP`, `ICMP`, `Any`. application: `Https:443`, `Http:80`, `Mssql:1433` |
| `source_addresses`, `destination_addresses` | IPs, CIDRs, ranges, `*`; destinations also take service tags (`AzureMonitor`) |
| `source_ip_groups`, `destination_ip_groups` | IP group keys from `config/ip-groups/` |
| `destination_fqdns` | domain names, wildcards allowed |
| `destination_ports` | required on network rules; `"443"`, `"8000-8100"`, `"*"` |
| `destination_fqdn_tags`, `destination_urls`, `web_categories`, `terminate_tls` | application rules only |

A rule naming an IP group that no file defines fails the plan and lists the
missing names. Add the IP group in the same PR.

## Adding a rule collection

Add a file to the group's directory:

```yaml
# config/rule-collection-groups/azfwpol-connectivity-001/rcg-1000-…/1040-rc-allow-vnet-newapp-prod-canadacentral-001-inbound.yaml
name: "rc-allow-vnet-newapp-prod-canadacentral-001-inbound"
priority: 8200
action: "Allow"      # or Deny
type: "network"      # or application
rules:
  - …
```

- **File number: the next multiple of 10 after the highest in the directory.**
  It is not the priority. It keeps the order Azure stores collections in, which
  is what Terraform compares against. Never renumber existing files; doing so
  plans a rewrite of the whole group.
- **Priority** must be unique within the group (the plan fails otherwise) and
  sets evaluation order. Lower runs first.
- At least one rule. Azure allows an empty collection; Terraform cannot express
  one.

### A new application or environment

Every app/environment gets a priority band in
`rcg-1000-spoke-specific-canada-central` (and `rcg-20000-spoke-specific-canada-east`
if it is in Canada East). Take the next free range above the highest priority
in the group, about 200 wide:

| Position in band | Action | Collection |
| --- | --- | --- |
| start | Allow | `rc-allow-vnet-<app>-<env>-canadacentral-001-inbound` / `-outbound` |
| end | Deny | `rc-deny-vnet-<app>-<env>-canadacentral-001-inbound`, one rule: `Any` from the app's VNet IP group to `*`, all ports |

On-premises access goes in `rc-allow-net-onprem-to-central` in
`rcg-40000-onprem-to-spokes`, not in the band. Dev and prod share the firewalls
and the policy; they are kept apart by separate collections and separate IP
groups.

The VNet itself comes from `tf-deploy-platform-connectivity`, applied first.
Everything on this side (IP groups, collections, rules) goes in one PR.

## Less common changes

- **Rule collection group:** a directory under the policy with a `_group.yaml`
  (`name`, `priority`), then collections from `0010-`. The live policy's groups
  run 490, 500, 800, 1000, 20000, 39800, 40000, 64900; `rcg-64900-deny-all`
  stays last.
- **Firewall policy:** an entry in `config/policies.yaml`. Copy
  `azfwpol-connectivity-001` and drop `identity`, `insights` and
  `tls_certificate` unless it needs them. Its groups go in a directory named
  after the key.
- **Firewall:** an entry in `config/firewalls.yaml`, after its hub or VNet,
  subnets and public IPs exist in connectivity. Copy the hub or the transit
  firewall. Set `zones` and `diagnostic_settings` explicitly; without the
  latter it sends no logs.
- **A resource group this workspace does not read yet:** a variable in
  `variables.tf`, a data source in `data.tf`, an entry in `local.rg_names` in
  `locals.tf`, and the group in `unmanaged-detect.yml`'s scope.
- **TLS certificate rotation:** update `tls_certificate.key_vault_secret_id` in
  `config/policies.yaml`. The ID is version-pinned, so rotating in the key vault
  alone changes nothing.

## Before you open a PR

- **Do not tidy names.** Several live names are odd on purpose: a rule named
  `" r-allow-cyberark-1858 "` with spaces, `rc-deny-…` collections whose action
  is `Allow`. The YAML matches Azure; changing a name is a rename, and changing
  an action is a traffic decision for the app owner.
- **A misspelt field is dropped silently by Terraform** (`destination_port`
  instead of `destination_ports`). The schema check catches it; VS Code
  underlines it as you type.
- **Read the plan for replaces and destroys.** A new rule should show an
  in-place update of one rule collection group. A replace or destroy on
  anything you did not mean to change is a wrong key or name.

Checking locally:

```sh
pipx install check-jsonschema
check-jsonschema --schemafile config/schema/collection.schema.json config/rule-collection-groups/*/*/[0-9]*.yaml
check-jsonschema --schemafile config/schema/ip-groups.schema.json config/ip-groups/*.yaml

terraform init
terraform plan -var-file=firewall.tfvars
```

## Pipelines

| Workflow | Runs | Does |
| --- | --- | --- |
| `config-schema.yml` | PR and push touching `config/` | schema check on every YAML file |
| `tflint.yml`, `trivy.yml` | PR (tflint also on push) | static checks; no state access |
| `import-verify.yml` | manual | plan plus the zero-diff gate; never applies |
| `import-apply.yml` | manual, type `apply` | plan, gate, approval on the `firewall` environment, re-plan, apply |
| `unmanaged-detect.yml` | daily and manual | firewalls, policies and IP groups in Azure but not in state; skips until `vars.AZURE_CLIENT_ID` is set |

The plan and apply workflows share the `platform-firewall-management`
concurrency group, so one run touches the estate at a time. `import-apply.yml`
re-plans after approval and blocks the apply if the change set differs from
what was approved. `plan.json` is never uploaded, since it lists every rule in
the estate.

The `firewall` GitHub environment must have required reviewers; without them
the apply runs with no approval stop.
