# Policies, firewalls and classic rule collections, as read from
# config/policies.yaml, config/firewalls.yaml and config/classic-rules.yaml.

variable "policies" {
  type = map(object({
    location                 = string
    sku                      = string
    rg_key                   = optional(string, "hub_cc")
    threat_intelligence_mode = optional(string)
    dns = optional(object({
      proxy_enabled = optional(bool)
      servers       = optional(list(string))
    }))
    intrusion_detection = optional(object({
      mode           = optional(string)
      private_ranges = optional(list(string))
      signature_overrides = optional(list(object({
        id    = optional(string)
        state = optional(string)
      })))
      traffic_bypass = optional(list(object({
        description           = optional(string)
        destination_addresses = optional(set(string))
        destination_ip_groups = optional(set(string))
        destination_ports     = optional(set(string))
        name                  = string
        protocol              = string
        source_addresses      = optional(set(string))
        source_ip_groups      = optional(set(string))
      })))
    }))
    identity = optional(object({
      type         = string
      identity_ids = optional(set(string))
    }))
    insights = optional(object({
      enabled               = bool
      default_workspace_key = string
      retention_in_days     = optional(number)
      log_analytics_workspaces = optional(list(object({
        firewall_location = string
        workspace_key     = string
      })))
    }))
    tls_certificate = optional(object({
      name                = string
      key_vault_secret_id = string
    }))
  }))
}

# Defaults match tf-wrapper-avm-azure-firewall, so an omitted attribute behaves
# as it would passed straight to the wrapper.
variable "firewalls" {
  type = map(object({
    rg_key     = string
    location   = string
    sku_name   = string
    sku_tier   = string
    policy_key = optional(string)
    zones      = optional(set(string), [])
    virtual_hub = optional(object({
      public_ip_count = optional(number)
      virtual_hub_id  = string
    }))
    ip_configurations = optional(map(object({
      name                 = string
      public_ip_address_id = optional(string)
      subnet_id            = optional(string)
    })), {})
    management_ip_configuration = optional(object({
      name                 = string
      public_ip_address_id = string
      subnet_id            = string
    }))
    diagnostic_settings = optional(map(object({
      name                           = optional(string, null)
      workspace_key                  = string
      log_categories                 = optional(set(string), [])
      log_groups                     = optional(set(string), ["allLogs"])
      metric_categories              = optional(set(string), ["AllMetrics"])
      log_analytics_destination_type = optional(string, "Dedicated")
    })), {})
  }))

  validation {
    condition     = alltrue([for f in values(var.firewalls) : f.policy_key == null || contains(keys(var.policies), coalesce(f.policy_key, "-"))])
    error_message = "A firewall names a policy_key that config/policies.yaml does not define: ${join(", ", [for k, f in var.firewalls : "${k} -> ${f.policy_key}" if f.policy_key != null && !contains(keys(var.policies), coalesce(f.policy_key, "-"))])}."
  }
}

variable "classic_network_rule_collections" {
  type = map(object({
    firewall_key = string
    name         = string
    priority     = number
    action       = string
    rules = list(object({
      name                  = string
      protocols             = list(string)
      source_addresses      = optional(list(string), [])
      source_ip_groups      = optional(list(string), [])
      destination_addresses = optional(list(string), [])
      destination_ip_groups = optional(list(string), [])
      destination_fqdns     = optional(list(string), [])
      destination_ports     = list(string)
    }))
  }))
}

output "firewall_policies" {
  value = var.policies
}

output "firewalls" {
  value = var.firewalls
}

output "classic_network_rule_collections" {
  value = {
    for k, c in var.classic_network_rule_collections : k => {
      firewall_key = c.firewall_key
      name         = c.name
      priority     = c.priority
      action       = c.action
      rule = [
        for r in c.rules : {
          name                      = r.name
          protocols                 = r.protocols
          source_addresses          = r.source_addresses
          source_ip_group_keys      = r.source_ip_groups
          destination_addresses     = r.destination_addresses
          destination_fqdns         = r.destination_fqdns
          destination_ip_group_keys = r.destination_ip_groups
          destination_ports         = r.destination_ports
        }
      ]
    }
  }
}
