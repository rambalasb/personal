# IP groups and rules, as read from config/ip-groups and
# config/rule-collection-groups. Types give the defaults; validations turn the
# common mistakes into plan errors that name the file contents at fault.

# One entry per file in config/ip-groups, keyed by file name.
variable "ip_group_files" {
  type = map(map(object({
    ip_addresses = list(string)
    name         = optional(string)
    rg_key       = optional(string, "ip_groups")
    location     = optional(string, "canadacentral")
  })))

  validation {
    condition     = length(flatten([for f in values(var.ip_group_files) : keys(f)])) == length(distinct(flatten([for f in values(var.ip_group_files) : keys(f)])))
    error_message = "An IP group is defined in more than one file under config/ip-groups: ${join(", ", [for k in distinct(flatten([for f in values(var.ip_group_files) : keys(f)])) : k if length([for f in values(var.ip_group_files) : f if contains(keys(f), k)]) > 1])}."
  }
}

# Keyed "<policy>/<group>" from the directory under config/rule-collection-groups.
# collections come from that directory's numbered files, in file name order.
variable "rule_collection_groups" {
  type = map(object({
    name     = string
    priority = number
    collections = list(object({
      name     = string
      priority = number
      action   = string
      type     = string
      rules = list(object({
        name                  = string
        protocols             = list(string)
        source_addresses      = optional(list(string), [])
        source_ip_groups      = optional(list(string), [])
        destination_addresses = optional(list(string), [])
        destination_ip_groups = optional(list(string), [])
        destination_fqdns     = optional(list(string), [])
        destination_ports     = optional(list(string), [])
        destination_fqdn_tags = optional(list(string), [])
        destination_urls      = optional(list(string), [])
        web_categories        = optional(list(string), [])
        terminate_tls         = optional(bool, false)
      }))
    }))
  }))

  validation {
    condition     = alltrue(flatten([for g in values(var.rule_collection_groups) : [for c in g.collections : contains(["network", "application"], c.type) && contains(["Allow", "Deny"], c.action)]]))
    error_message = "Every collection needs type network or application, and action Allow or Deny."
  }

  validation {
    condition     = alltrue([for g in values(var.rule_collection_groups) : length(g.collections) == length(distinct([for c in g.collections : c.priority]))])
    error_message = "Two collections in one rule collection group share a priority: ${join(", ", [for k, g in var.rule_collection_groups : k if length(g.collections) != length(distinct([for c in g.collections : c.priority]))])}."
  }

  validation {
    condition     = alltrue(flatten([for g in values(var.rule_collection_groups) : [for c in g.collections : [for r in c.rules : length(r.destination_ports) > 0] if c.type == "network"]]))
    error_message = "Every network rule needs destination_ports: ${join(", ", flatten([for g in values(var.rule_collection_groups) : [for c in g.collections : [for r in c.rules : r.name if length(r.destination_ports) == 0] if c.type == "network"]]))}."
  }

  validation {
    condition     = alltrue(flatten([for g in values(var.rule_collection_groups) : [for c in g.collections : length(c.rules) > 0]]))
    error_message = "A collection has no rules. Azure cannot hold an empty collection through Terraform."
  }

  validation {
    condition = alltrue(flatten([
      for g in values(var.rule_collection_groups) : [
        for c in g.collections : [
          for r in c.rules : [
            for k in concat(r.source_ip_groups, r.destination_ip_groups) :
            contains(flatten([for f in values(var.ip_group_files) : keys(f)]), k)
          ]
        ]
      ]
    ]))
    error_message = "Rules name IP groups that no file under config/ip-groups defines: ${join(", ", distinct(flatten([for g in values(var.rule_collection_groups) : [for c in g.collections : [for r in c.rules : [for k in concat(r.source_ip_groups, r.destination_ip_groups) : k if !contains(flatten([for f in values(var.ip_group_files) : keys(f)]), k)]]]])))}."
  }

  validation {
    condition     = alltrue(flatten([for g in values(var.rule_collection_groups) : [for c in g.collections : [for r in c.rules : alltrue([for p in r.protocols : can(regex("^[A-Za-z]+:[0-9]+$", p))]) if c.type == "application"]]]))
    error_message = "Application rule protocols are written \"Https:443\", \"Http:80\" or \"Mssql:1433\"."
  }
}

output "ip_groups" {
  value = merge(values(var.ip_group_files)...)
}

output "firewall_rule_collection_groups" {
  value = {
    for k, g in var.rule_collection_groups : k => {
      name       = g.name
      policy_key = split("/", k)[0]
      priority   = g.priority
      network_rule_collection = [
        for c in g.collections : {
          name     = c.name
          priority = c.priority
          action   = c.action
          rule = [
            for r in c.rules : {
              name                      = r.name
              protocols                 = r.protocols
              source_addresses          = r.source_addresses
              source_ip_group_keys      = r.source_ip_groups
              destination_addresses     = r.destination_addresses
              destination_fqdns         = r.destination_fqdns
              destination_ip_group_keys = r.destination_ip_groups
              destination_ports         = r.destination_ports
            }
          ]
        } if c.type == "network"
      ]
      application_rule_collection = [
        for c in g.collections : {
          name     = c.name
          priority = c.priority
          action   = c.action
          rule = [
            for r in c.rules : {
              name                  = r.name
              protocols             = [for p in r.protocols : { type = split(":", p)[0], port = tonumber(split(":", p)[1]) }]
              source_addresses      = r.source_addresses
              source_ip_group_keys  = r.source_ip_groups
              destination_fqdns     = r.destination_fqdns
              destination_urls      = r.destination_urls
              destination_fqdn_tags = r.destination_fqdn_tags
              web_categories        = r.web_categories
              terminate_tls         = r.terminate_tls
            }
          ]
        } if c.type == "application"
      ]
    }
  }
}
