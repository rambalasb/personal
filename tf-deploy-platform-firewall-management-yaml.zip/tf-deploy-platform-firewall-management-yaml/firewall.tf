# Firewalls and firewall policies from config/firewalls.yaml and config/policies.yaml.
# Each policy carries its rule collection groups from config/rule-collection-groups/<policy>/.
# Keys in the YAML (policy_key, IP group names, workspace_key) are turned into IDs here.

module "firewall" {
  for_each = module.config.firewalls

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-azure-firewall/azurerm"
  version = "0.1.0"

  name                = each.key
  resource_group_name = local.rg_names[each.value.rg_key]
  location            = each.value.location
  firewall_sku_name   = each.value.sku_name
  firewall_sku_tier   = each.value.sku_tier

  firewall_policy_id                   = each.value.policy_key == null ? null : module.firewall_policy[each.value.policy_key].resource_id
  firewall_zones                       = each.value.zones
  firewall_virtual_hub                 = each.value.virtual_hub
  ip_configurations                    = each.value.ip_configurations
  firewall_management_ip_configuration = each.value.management_ip_configuration

  diagnostic_settings = {
    for k, d in each.value.diagnostic_settings : k => {
      name                           = d.name
      workspace_resource_id          = var.log_analytics_workspaces[d.workspace_key]
      log_categories                 = d.log_categories
      log_groups                     = d.log_groups
      metric_categories              = d.metric_categories
      log_analytics_destination_type = d.log_analytics_destination_type
    }
  }

  enable_telemetry = false
  tags             = local.common_tags
}

module "firewall_policy" {
  for_each = module.config.firewall_policies

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-azure-firewall-policy/azurerm"
  version = "0.1.1"

  name                = each.key
  resource_group_name = local.rg_names[each.value.rg_key]
  location            = each.value.location

  firewall_policy_sku                      = each.value.sku
  firewall_policy_threat_intelligence_mode = each.value.threat_intelligence_mode
  firewall_policy_dns                      = each.value.dns
  firewall_policy_intrusion_detection      = each.value.intrusion_detection
  firewall_policy_identity                 = each.value.identity
  firewall_policy_tls_certificate          = each.value.tls_certificate

  firewall_policy_insights = each.value.insights == null ? null : {
    enabled                            = each.value.insights.enabled
    default_log_analytics_workspace_id = var.log_analytics_workspaces[each.value.insights.default_workspace_key]
    retention_in_days                  = each.value.insights.retention_in_days
    log_analytics_workspace = each.value.insights.log_analytics_workspaces == null ? null : [
      for w in each.value.insights.log_analytics_workspaces : {
        firewall_location = w.firewall_location
        id                = var.log_analytics_workspaces[w.workspace_key]
      }
    ]
  }

  # Only this policy's groups, keyed by group name; the wrapper wires
  # firewall_policy_id internally.
  firewall_policy_rule_collection_groups = {
    for k, g in module.config.firewall_rule_collection_groups : g.name => {
      name     = g.name
      priority = g.priority
      network_rule_collection = [
        for c in g.network_rule_collection : {
          name     = c.name
          priority = c.priority
          action   = c.action
          rule = [
            for r in c.rule : {
              name                  = r.name
              protocols             = r.protocols
              source_addresses      = r.source_addresses
              source_ip_groups      = [for key in r.source_ip_group_keys : module.ip_group[key].resource_id]
              destination_addresses = r.destination_addresses
              destination_fqdns     = r.destination_fqdns
              destination_ip_groups = [for key in r.destination_ip_group_keys : module.ip_group[key].resource_id]
              destination_ports     = r.destination_ports
            }
          ]
        }
      ]
      application_rule_collection = [
        for c in g.application_rule_collection : {
          name     = c.name
          priority = c.priority
          action   = c.action
          rule = [
            for r in c.rule : {
              name                  = r.name
              protocols             = r.protocols
              source_addresses      = r.source_addresses
              source_ip_groups      = [for key in r.source_ip_group_keys : module.ip_group[key].resource_id]
              destination_fqdns     = r.destination_fqdns
              destination_urls      = r.destination_urls
              destination_fqdn_tags = r.destination_fqdn_tags
              web_categories        = r.web_categories
              terminate_tls         = r.terminate_tls
            }
          ]
        }
      ]
    } if g.policy_key == each.key
  }

  enable_telemetry = false
  tags             = local.common_tags
}
