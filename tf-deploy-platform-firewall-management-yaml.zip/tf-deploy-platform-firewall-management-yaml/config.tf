# Reads the firewall definitions from config/ and passes them through
# modules/config, whose typed variables apply defaults and fail the plan on a
# malformed file. Layout:
#
#   config/ip-groups/<file>.yaml                           IP groups, any number of files
#   config/policies.yaml                                   firewall policies
#   config/firewalls.yaml                                  firewalls
#   config/classic-rules.yaml                              classic collections (transit firewall)
#   config/rule-collection-groups/<policy>/<group>/
#     _group.yaml                                          the group's name and priority
#     <NNNN>-<collection>.yaml                             one collection each
#
# Collections are read in file name order, which is the order Terraform compares
# them in. The numbers keep Azure's own order; a new collection takes the next one.

locals {
  config_dir = "${path.module}/config"
  rcg_dir    = "${local.config_dir}/rule-collection-groups"

  rule_collection_groups = {
    for f in fileset(local.rcg_dir, "*/*/_group.yaml") : dirname(f) => merge(
      yamldecode(file("${local.rcg_dir}/${f}")),
      {
        collections = [
          for c in sort(fileset("${local.rcg_dir}/${dirname(f)}", "[0-9]*.yaml")) :
          yamldecode(file("${local.rcg_dir}/${dirname(f)}/${c}"))
        ]
      },
    )
  }
}

module "config" {
  source = "./modules/config"

  ip_group_files = {
    for f in fileset("${local.config_dir}/ip-groups", "*.yaml") :
    trimsuffix(f, ".yaml") => yamldecode(file("${local.config_dir}/ip-groups/${f}"))
  }

  policies                         = yamldecode(file("${local.config_dir}/policies.yaml"))
  firewalls                        = yamldecode(file("${local.config_dir}/firewalls.yaml"))
  classic_network_rule_collections = yamldecode(file("${local.config_dir}/classic-rules.yaml"))
  rule_collection_groups           = local.rule_collection_groups
}
