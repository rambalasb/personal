# Handover: platform firewall management

What this workspace owns, what it does not, what is left before the first
apply, and why some settings look the way they do. `README.md` covers making
changes.

## Contents

1. [Boundary with tf-deploy-platform-connectivity](#1-boundary-with-tf-deploy-platform-connectivity)
2. [What Terraform owns](#2-what-terraform-owns)
3. [What Terraform does not own](#3-what-terraform-does-not-own)
4. [Open items before the first apply](#4-open-items-before-the-first-apply)
5. [Known plan diffs on first import](#5-known-plan-diffs-on-first-import)
6. [Settings that must not be "corrected"](#6-settings-that-must-not-be-corrected)
7. [Module and provider gaps](#7-module-and-provider-gaps)
8. [Pipeline controls](#8-pipeline-controls)
9. [Drift detection](#9-drift-detection)
10. [Locations](#10-locations)
11. [Reproducing the inventory](#11-reproducing-the-inventory)

## 1. Boundary with tf-deploy-platform-connectivity

The split is by **resource type**, not by resource group. Three types belong
here wherever they sit in the subscription:

- `Microsoft.Network/azureFirewalls`
- `Microsoft.Network/firewallPolicies`
- `Microsoft.Network/ipGroups`

Everything else, including all 12 resource groups and the alerts that watch the
firewalls, belongs to `tf-deploy-platform-connectivity`.

Why a separate workspace:

1. **A rule change plans only the rules**, not the spoke VMs, bastions, DNS
   zones and hub connections.
2. **A rule apply cannot touch the network.** This state holds no VNet, hub or
   gateway, so no apply from here can modify one, whatever the plan says.
3. **Separate approvers.** The `firewall` environment can require a network
   security reviewer.

Resource groups are shared, so a group's name does not say who owns what is in
it:

| Resource group | Here | Also holds (connectivity-owned) |
| --- | --- | --- |
| `rg-hub-connectivity-canadacentral-001` | 1 firewall, 2 policies, 2 IP groups | vWAN hub, route tables, route maps, gateways, storage |
| `rg-hub-connectivity-canadaeast-001` | 1 firewall | vWAN hub, gateways |
| `rg-shared-connectivity-canadacentral-001` | transit firewall | VNet, public IP, subnets |
| `rg-ip-groups-connectivity-global` | 257 IP groups | nothing |
| `AzureBackupRG_canadacentral_1` | 4 IP groups, created there by hand | everything else |

The boundary is enforced in two places:

- `data.tf` reads the resource groups; it never manages them, so a firewall
  apply cannot retag or delete one.
- `unmanaged-detect.yml` here passes `--scope-type` for the three types;
  connectivity's passes `--exclude-type` for the same three. **If the boundary
  moves, both lists move together.** A type dropped from one and not added to
  the other is checked by neither, and nothing fails to tell you.

No state reference crosses the boundary. Connectivity's firewall alerts
(`conn_alerts.tf`) and vWAN route next-hops (`hub_vwan.tf`) point at the
firewalls by constructed resource ID.

## 2. What Terraform owns

**294 import blocks**: 31 in `pending_imports_firewall.tf` (23 resources, 8
diagnostic settings), 263 in `pending_imports_ip_groups.tf`. Rules and IP groups
reflect the 2026-10-21 export.

| Object | Count | Where |
| --- | --- | --- |
| Azure Firewall, secured hub (`AZFW_Hub`/Premium) | 2 | `azfw-connectivity-canadacentral-001`, `azfw-connectivity-canadaeast-001` |
| Azure Firewall, VNet (`AZFW_VNet`/Standard) | 1 | `azfw-transit-connectivity-canadacentral-001` |
| Firewall policy | 2 | `azfwpol-connectivity-001` (live), `azfwpol-connectivity-001-BACKUP-20260320-233016-UTC` |
| Rule collection group | 17 | 8 live, 9 backup |
| Rule collection | 166 | 122 live, 44 backup; six empty ones omitted (§3) |
| Rule | 652 | 538 live, 114 backup |
| Classic network rule collection | 1 | `rc-allow-ns2-to-bch` on the transit firewall, `classic_rules.tf` |
| IP group | 263 | 241 referenced by rules |
| Diagnostic setting | 8 | on the three firewalls. Policies do not support them. |

IP groups live here rather than in connectivity because a rule change and the
IP group it references change together.

### Diagnostic settings

Adopted as exported on 2026-09-28, in `config/firewalls.yaml`:

| Setting | Hub firewalls | Transit firewall | Workspace |
| --- | --- | --- | --- |
| `sendMetricsToLA` | AllMetrics, `AzureDiagnostics` | AllMetrics, `Dedicated` | la-siem-management |
| `FirewallPolicySettings` | allLogs | — | la-siem-management |
| `sendLogsToLA` | 16 named categories | allLogs | la-siem-security |

The hub firewalls ingest every log twice, and the 16 categories include both
the legacy `AzureFirewall*` and the resource-specific `AZFW*` ones, which
overlap. Trimming that is a cost decision for the workspace owners; change
`config/firewalls.yaml`, not the portal.

### The backup policy

`azfwpol-connectivity-001-BACKUP-20260320-233016-UTC` is a copy of the live
policy from 20 March 2026, attached to no firewall. It is managed so it is not
an unmanaged policy that `unmanaged-detect.yml` flags, and so its rules cannot
be edited in the portal without a trace. Attaching it to a firewall would put
its rules into effect.

Its `identity`, `insights` and `tls_certificate` are null, matching live. Do not
copy the live policy's values across: insights would start writing to the SIEM
workspace, and the UAMI would give an unused policy read on the TLS
certificate.

Its extra group, `rcg-300-cyberark-SIA-baseline`, is the pre-March layout. Its
four rules are on the live policy: the certs and dogwood rules in `rcg-800`, the
Windows and Linux rules in `rcg-1000`, with port 135 moved to an exception rule
in `rcg-490` and UDP dropped from the Linux rule.

## 3. What Terraform does not own

### Owned elsewhere

| Object | Owner | Note |
| --- | --- | --- |
| All 12 resource groups, and their `CanNotDelete` locks | `tf-deploy-platform-connectivity` | Read here through `data.tf`. None of the firewalls, policies or IP groups has its own lock. |
| `firewall-connectivity-health`, `firewall-connectivity-update` alerts | `tf-deploy-platform-connectivity` (`conn_alerts.tf`) | Watch the firewall; do not configure it. |
| vWAN route next-hops to the hub firewalls | `tf-deploy-platform-connectivity` (`hub_vwan.tf`) | Constructed IDs. |
| `mid-azfirewall-canadacentral-001` (policy UAMI) | `sub-identity-lz` | Identity subscription. |
| `kvfwtlscanadacentral` (TLS certificate key vault) | `sub-identity-lz` | The secret itself is not managed by any repo. |
| `la-siem-security-canadacentral-001` | security LZ | Insights and `sendLogsToLA`. |
| `la-siem-management-canadacentral-001` | management LZ | `sendMetricsToLA`, `FirewallPolicySettings`. |
| Policy assignments and exemptions | management groups | Inherited. |

### Six empty rule collections

The provider cannot represent a collection with no rules, so these are left
out of `config/`. None changes a traffic decision: an empty Allow permits
nothing and an empty Deny denies nothing. Deleting them in Azure would make the
configuration exact.

| Policy | Group | Collection | Priority | Action |
| --- | --- | --- | --- | --- |
| live | `rcg-1000-spoke-specific-canada-central` | `rc-allow-vnet-ertest-canadacentral-001-in` | 1211 | Allow |
| live | `rcg-1000-spoke-specific-canada-central` | `rc-allow-sap-aem-inbound` | 2520 | Allow |
| live | `rcg-1000-spoke-specific-canada-central` | `rc-deny-vnet-tibco-nonprod-canadacentral-in` | 5690 | Deny |
| live | `rcg-1000-spoke-specific-canada-central` | `rc-deny-ipgrp-vnet-pea-qa-canadacentral-001` | 7701 | Allow, despite the name |
| live | `rcg-20000-spoke-specific-canada-east` | `rc-allow-vnet-ertest-canadaeast-001-in` | 20210 | Allow |
| backup | `rcg-41000-spokes-to-onprem` | `rc-allow-net-fit-to-esb-nonprod` | 41100 | Allow |

## 4. Open items before the first apply

In the order they block progress.

1. **Re-run the speculative plan.** The 2026-09-28 plan resolved every import
   address but predates the classic collection, the 2026-10-05 refresh (45 new
   rules, 4 new collections, 3 changed rules, 20 new IP groups) and the tag and
   `api-version` fixes. Expect 294 imports and the diffs in §5.
2. **Review three rules created in the portal after 2026-10-01.** Adopted as
   live, since an import must match Azure; correct them after the first apply.
   - **`rc-deny-vnet-mft-prod-canadacentral-001` (priority 5080) is `Allow`.**
     Its one rule matches `ipgrp-vnet-mft-prod-canadacentral-001` to `*` on all
     ports, so the mft-prod VNet can reach anything. Almost certainly meant to
     be `Deny`.
   - `rc-deny-vnet-lims-stg-canadacentral-in` holds a rule named
     `r-deny-vnet-pea-dev-canadacentral-001-inbound`. It matches lims-stg
     correctly; only the name was copied.
   - A rule in `rc-allow-net-onprem-to-central` is named `r-allow-`.
3. **Configure required reviewers on the `firewall` GitHub environment.**
4. **Decide on the six empty collections** (§3): delete them in Azure, or
   leave the configuration knowingly inexact there.

After the first apply:

- Delete `pending_imports_firewall.tf`, `pending_imports_ip_groups.tf` and
  `scripts/gen_ip_groups.sh`, and re-plan; it should be empty.
- Replace the import workflows with a plan-on-PR / apply-on-merge pair. The
  zero-diff gate in `import-verify.yml` and `import-apply.yml` rejects any plan
  that changes Azure, which is every real rule change.

Settled:

- `log_analytics_workspaces.siem_security` carries the security
  subscription's ID (`7d54d6f7-…`), confirmed against the connectivity flow-log
  export. Connectivity had built it under the connectivity subscription's ID,
  which resolves to nothing.
- Import addresses: resolved by the 2026-09-28 plan.
- `rc-allow-ns2-to-bch` matches the 2026-10-05 export rule for rule.

## 5. Known plan diffs on first import

**Tags, additive.** `managed-by`, `solution`, `owner` and the wrappers' `module`
on the 268 tagged resources (3 firewalls, 2 policies, 263 IP groups).
`Environment` already matches (§6).

**21 IP groups rewrite with unchanged membership.** The IP-group wrapper types
`ip_addresses` as `set(string)`, so Terraform sorts and deduplicates it:

- 20 groups reorder. Every removed value reappears as an added one.
- `ipgrp-onprem-to-clzdb-subnets` drops duplicates: Azure holds 36 entries, 34
  unique (`10.60.0.0/16` and `10.244.21.54` are each listed twice). The first
  apply writes 34. Matching is unchanged, but it is a real write.

Neither can be fixed in YAML. It converges after one apply. Approve it, or waive
the 21 with `--allow-resource` on the `verify_zero_diff.sh` call. Beyond those
21, an `ip_addresses` diff means the addresses really differ from Azure.

**Not expected.** IP-group import IDs carry `?api-version=2024-05-01`, the
version the module declares; without it every group plans a `type` update. If
the IP-group wrapper moves API version, update the suffix in
`pending_imports_ip_groups.tf` and `scripts/gen_ip_groups.sh` with it.

## 6. Settings that must not be "corrected"

Each of these differs from a wrapper default or from what a reader would
expect, and is written out so a plan cannot quietly change a live network path.
They were read from the export, not yet confirmed against a live plan (§4.1).

**`azfwpol-connectivity-001`**

| Setting | Value | Why |
| --- | --- | --- |
| `threat_intelligence_mode` | `Deny` | Stricter than the module default `Alert`. |
| `intrusion_detection.mode` | `Deny` | A silent move to `Alert` would pass what it used to block. |
| `dns.proxy_enabled`, `servers` | `true`, `10.195.4.7` | FQDN rules resolve through the proxy; turning it off breaks every rule using `destination_fqdns`. The server is connectivity's DNS resolver inbound endpoint. |
| `sku` | `Premium` | Required by TLS inspection and IDPS. |
| `identity` | `mid-azfirewall-canadacentral-001` | Reads the TLS certificate from the key vault. |
| `tls_certificate.key_vault_secret_id` | version-pinned | An unversioned ID would let a rotation change what the firewall presents with no commit. The cost: rotation needs a change here. |

**Transit firewall.** `AZFW_VNet`/Standard with no policy, as live. Premium
would be a cost and behaviour change.

**`Environment = "Prod"`, capitalised.** Azure tag keys are case-insensitive; a
lowercase `environment` rewrites the existing tag on all 268 resources, and
anything matching `Prod` stops matching. `tf-deploy-platform-connectivity`
makes the same choice; change both together or neither.

**Cross-subscription IDs are literal.** The two workspace IDs in
`firewall.tfvars` and the identity and key vault IDs in `config/policies.yaml`
are written in full, so none can resolve under the wrong subscription.

## 7. Module and provider gaps

Wrapper versions: `tf-wrapper-avm-azure-firewall` 0.1.0,
`tf-wrapper-avm-azure-firewall-policy` 0.1.1, `tf-wrapper-avm-ip-group` 0.1.0.
No gap is currently waived in the pipelines.

| Module | Gap | Handling |
| --- | --- | --- |
| azurerm provider | A rule collection with zero rules cannot be represented. | Six omitted (§3). `modules/config` fails the plan on an empty collection. |
| tf-wrapper-avm-azure-firewall | No input for classic inline `networkRuleCollections`. | `classic_rules.tf` declares the transit firewall's one collection natively. Moving that firewall onto a policy retires the file and `config/classic-rules.yaml`. |
| tf-wrapper-avm-ip-group | `ip_addresses` is a set, so it sorts and deduplicates. | One converging apply (§5). |
| all three wrappers | Import blocks target the inner AVM resources. | `module.firewall[…].module.azure_firewall.azurerm_firewall.this`, `module.firewall_policy[…].module.firewall_policy.azurerm_firewall_policy.this`, `…module.rule_collection_group[…].azurerm_firewall_policy_rule_collection_group.this`, `module.ip_group[…].module.ip_group.azapi_resource.this` (azapi, not `azurerm_ip_group`). A wrong address fails validate without naming the right one; re-read the leaves from `.terraform/modules` if a wrapper bumps its AVM version. |

## 8. Pipeline controls

`import-apply.yml` puts two controls between approval and apply:

1. The apply job re-plans and re-runs `verify_zero_diff.sh`, so drift during
   the approval wait fails the run. It does not reuse the check job's saved
   plan, which would replay a recorded diff without re-reading Azure.
2. It hashes its own change set (actions, addresses, import IDs) and refuses
   to apply unless it matches the digest the check job published. A resource
   entering or leaving the plan between review and approval blocks the apply.

The gate suppresses only `timeouts`, the azapi config-only attributes (`type`,
`*_headers`), `body` by containment, and the telemetry types `modtm_telemetry`,
`random_uuid`, `time_sleep`. No rule attribute is waived: a rule list Terraform
would rewrite is what the gate exists to catch.

Artifacts hold the gate output and an address-level change list. `plan.json`
and `tfplan.binary` are never uploaded; a firewall plan's JSON lists every
source, destination, port and FQDN in the estate.

The concurrency group `platform-firewall-management` is not shared with
connectivity. The two workspaces own disjoint resources, so they may plan at
the same time.

## 9. Drift detection

| Question | Answered by | Status |
| --- | --- | --- |
| A resource in state changed in Azure | HCP drift detection on `az-platform-firewall` | **Enable it.** The only control that sees a portal change to a rule collection group, since groups are child resources. |
| A firewall, policy or IP group exists in Azure with no state entry | `unmanaged-detect.yml` | **Not running.** No federated credential, so it skips on `vars.AZURE_CLIENT_ID`. It skips rather than fails; read the job summary, not the green tick. To enable, set `vars.AZURE_CLIENT_ID`, `AZURE_TENANT_ID` and `AZURE_SUBSCRIPTION_ID` for a Reader identity with a federated credential for this repo. |
| Committed config disagrees with state | nothing | `terraform plan -detailed-exitcode` if it becomes worth watching. |

An unmanaged firewall policy is the most serious finding: it can carry
unreviewed rules, and attaching it to a firewall puts them into effect without
the approval gate. Azure Policy denying `firewallPolicies` and
`azureFirewalls` writes outside the pipeline identity would prevent it rather
than report it a day later.

## 10. Locations

|  |  |
| --- | --- |
| HCP organisation / workspace | `BC_Hydro` / `az-platform-firewall` |
| Subscription | `f3835bc1-9829-4ac8-9d7a-0999e0b29b90` (connectivity) |
| Environment settings | `firewall.tfvars` |
| Firewall definitions | `config/` |
| Concurrency group | `platform-firewall-management` |
| Sibling workspace | `az-platform-connectivity` (`tf-deploy-platform-connectivity`) |

## 11. Reproducing the inventory

```bash
SUB=f3835bc1-9829-4ac8-9d7a-0999e0b29b90
az account set --subscription "$SUB"

# the three owned types; compare against `terraform state list`
az resource list --subscription "$SUB" \
  --query "[?type=='Microsoft.Network/azureFirewalls' || type=='Microsoft.Network/firewallPolicies' || type=='Microsoft.Network/ipGroups'].{name:name,type:type,rg:resourceGroup}" \
  -o table

# rule collection groups are children, so absent from the listing above
for p in azfwpol-connectivity-001 azfwpol-connectivity-001-BACKUP-20260320-233016-UTC; do
  echo "== $p"
  az network firewall policy rule-collection-group list \
    --policy-name "$p" -g rg-hub-connectivity-canadacentral-001 \
    --query "[].{name:name,priority:priority}" -o table
done

# the transit firewall's classic inline rules
az network firewall show -n azfw-transit-connectivity-canadacentral-001 \
  -g rg-shared-connectivity-canadacentral-001 \
  --query "networkRuleCollections[].{name:name,priority:priority,action:action.type}" -o table

# diagnostic settings, never in a resource listing
for f in azfw-connectivity-canadacentral-001:rg-hub-connectivity-canadacentral-001 \
         azfw-connectivity-canadaeast-001:rg-hub-connectivity-canadaeast-001 \
         azfw-transit-connectivity-canadacentral-001:rg-shared-connectivity-canadacentral-001; do
  n=${f%%:*}; g=${f##*:}
  echo "== $n"
  az monitor diagnostic-settings list \
    --resource "/subscriptions/$SUB/resourceGroups/$g/providers/Microsoft.Network/azureFirewalls/$n" \
    -o json
done

# locks; the resource-group locks belong to connectivity
az lock list --subscription "$SUB" -o table

# empty rule collections
az network firewall policy rule-collection-group show \
  --policy-name azfwpol-connectivity-001 \
  -g rg-hub-connectivity-canadacentral-001 \
  -n rcg-1000-spoke-specific-canada-central \
  --query "ruleCollections[?length(rules)==\`0\`].{name:name,priority:priority}" -o table
```

To adopt IP groups that exist in Azure but are not in `config/`:

```sh
az network ip-group list -g rg-ip-groups-connectivity-global -o json > ipg.json
./scripts/gen_ip_groups.sh ipg.json --out ./generated
```

It writes YAML entries, import blocks and a drift report to `./generated` and
edits nothing in place. Move the entries into the right `config/ip-groups` file
and append the import blocks to `pending_imports_ip_groups.tf`.
