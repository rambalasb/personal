#!/usr/bin/env bash
# Generate YAML entries and import blocks for IP groups that exist in Azure but
# are not yet declared under config/ip-groups.
#
# A group that is not declared is invisible to a plan -- `for_each` skips it, so
# an apply neither reports it nor touches it. This reads the live groups and
# emits what is needed to bring them under management.
#
# `az resource list` is not enough input here: it returns properties as null,
# so it carries the names but not the members, and an ip_group without
# ip_addresses cannot be described.
#
# Usage:
#   az network ip-group list -g rg-ip-groups-connectivity-global -o json > ipg.json
#   gen_ip_groups.sh ipg.json [--config DIR] [--out DIR]
#
# --config  directory of IP group YAML files. Default ./config/ip-groups
# --out     directory for the generated files. Default ./generated
# --inner   the address of the resource inside the wrapper, relative to
#           module.ip_group["<name>"]. Defaults to the verified address for
#           Azure/avm-res-network-ipgroup 0.2.0, which uses azapi rather than
#           azurerm_ip_group. Re-read it if the wrapper bumps that version:
#             find .terraform/modules -path '*ipgroup*' -name '*.tf' \
#               | xargs grep -n '^resource "'
#
# Writes three files:
#   ip_groups.new.yaml.txt  YAML entries for the undeclared groups. Add them to
#                           the file under config/ip-groups for their app, or
#                           shared.yaml.
#   ip_groups.imports.txt   import blocks for the same groups. Append to
#                           pending_imports_ip_groups.tf; do not overwrite it.
#   drift.txt               declared groups whose members no longer match Azure.
#
# Nothing is edited in place. Review, then move the entries into position.

set -euo pipefail

die() { echo "error: $*" >&2; exit 2; }

[ $# -ge 1 ] || die "usage: gen_ip_groups.sh ipg.json [--config DIR] [--out DIR]"

src="$1"; shift
config="./config/ip-groups"
out="./generated"
inner="module.ip_group.azapi_resource.this"

while [ $# -gt 0 ]; do
  case "$1" in
    --config) config="${2:-}"; [ -n "$config" ] || die "--config needs a value"; shift 2 ;;
    --out)    out="${2:-}";    [ -n "$out" ]    || die "--out needs a value";    shift 2 ;;
    --inner)  inner="${2:-}";  [ -n "$inner" ]  || die "--inner needs a value";  shift 2 ;;
    *) die "unknown argument: $1" ;;
  esac
done

[ -f "$src" ]    || die "no such file: $src"
[ -d "$config" ] || die "no such directory: $config"
command -v jq >/dev/null      || die "jq not found"
command -v python3 >/dev/null || die "python3 not found"

mkdir -p "$out"

# Declared groups and their members, as JSON. The files are machine-written in
# one layout -- a top-level key per group, ip_addresses as a flow or block list
# -- so a line parse is enough. Keys holding "/" live in another resource group
# and are not in ipg.json.
python3 -I - "$config" > "$out/.declared.json" <<'PY'
import json, os, re, sys
d = sys.argv[1]
groups, key, in_list = {}, None, False
for f in sorted(os.listdir(d)):
    if not f.endswith(".yaml"):
        continue
    for line in open(os.path.join(d, f)):
        line = line.rstrip("\n")
        m = re.match(r'^"?([^"\s#][^":]*)"?:\s*$', line)
        if m:
            key, in_list = m.group(1), False
            groups[key] = []
            continue
        m = re.match(r'^\s+ip_addresses:\s*(\[.*\])\s*$', line)
        if m and key:
            groups[key] = json.loads(m.group(1)); in_list = False
            continue
        if re.match(r'^\s+ip_addresses:\s*$', line):
            in_list = True
            continue
        m = re.match(r'^\s+-\s+(".*")\s*$', line)
        if in_list and m and key:
            groups[key].append(json.loads(m.group(1)))
            continue
        in_list = False
print(json.dumps({k: v for k, v in groups.items() if "/" not in k}))
PY

jq -r 'keys[]' "$out/.declared.json" | sort > "$out/.declared"
jq -r '.[].name' "$src" | sort > "$out/.live"

declared=$(grep -c . "$out/.declared" || true)
live=$(grep -c . "$out/.live" || true)

# az network flattens properties onto the object; a raw ARM response does not.
# Accept both shapes.
comm -13 "$out/.declared" "$out/.live" > "$out/.new"
jq -r --rawfile new "$out/.new" '
  ($new | split("\n") | map(select(length > 0))) as $n
  | sort_by(.name)[] | select(.name as $x | $n | index($x))
  | "\(.name | tojson):\n  ip_addresses: \((.ipAddresses // .properties.ipAddresses // []) | tojson)"
    + (if .location != "canadacentral" then "\n  location: \(.location | tojson)" else "" end)
' "$src" > "$out/ip_groups.new.yaml.txt"

# Import blocks for the undeclared groups. The inner address is not verifiable
# from this repo -- the AVM module it points into is fetched at init.
{
  echo "# Generated fragment -- import blocks for groups not previously declared."
  echo "# Append to pending_imports_ip_groups.tf. Inner address: $inner"
  echo
  while IFS= read -r name; do
    [ -n "$name" ] || continue
    printf 'import {\n'
    printf '  to = module.ip_group["%s"].%s\n' "$name" "$inner"
    printf '  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/%s?api-version=2024-05-01"\n' "$name"
    printf '}\n'
  done < "$out/.new"
} > "$out/ip_groups.imports.txt"

new=$(grep -c . "$out/.new" || true)
gone=$(comm -23 "$out/.declared" "$out/.live" | grep -c . || true)

# Members that changed on a group already declared. HCP drift detection reports
# these too, but only once the workspace is running clean.
jq -r --slurpfile want "$out/.declared.json" '
  .[] | . as $g | ($want[0][$g.name]) as $w
  | select($w != null)
  | select(($w | sort) != ((.ipAddresses // .properties.ipAddresses // []) | sort))
  | .name
' "$src" | sort > "$out/drift.txt"

drift=$(grep -c . "$out/drift.txt" || true)

rm -f "$out/.declared" "$out/.declared.json" "$out/.live" "$out/.new"

cat <<EOF
declared in $config : $declared
live in Azure       : $live
to be added         : $new
declared but absent : $gone
member drift        : $drift

wrote $out/ip_groups.new.yaml.txt
      $out/ip_groups.imports.txt
      $out/drift.txt
EOF

[ "$gone" -eq 0 ] || echo "warning: $gone declared groups do not exist in Azure; check before applying" >&2
