# IP groups from config/ip-groups/*.yaml. The file a group sits in has no
# effect on Azure; it is only for finding things.

module "ip_group" {
  for_each = module.config.ip_groups

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-ip-group/azurerm"
  version = "0.1.0"

  name                = coalesce(each.value.name, each.key)
  resource_group_name = local.rg_names[each.value.rg_key]
  location            = each.value.location
  ip_addresses        = each.value.ip_addresses

  enable_telemetry = false
  tags             = local.common_tags
}
