# pending_imports_firewall.tf
# confirm AVM internal import addresses on first plan
# Firewalls, policies and rule collection groups all import into wrapper inner modules.
# The rule collection group address was read from source after `terraform init`, not
# inferred: the wrapper instantiates the AVM rule_collection_groups submodule as
# module.rule_collection_group, whose leaf is azurerm_firewall_policy_rule_collection_group.this.

import {
  to = module.firewall["azfw-connectivity-canadacentral-001"].module.azure_firewall.azurerm_firewall.this
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/azureFirewalls/azfw-connectivity-canadacentral-001"
}
import {
  to = module.firewall["azfw-connectivity-canadaeast-001"].module.azure_firewall.azurerm_firewall.this
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadaeast-001/providers/Microsoft.Network/azureFirewalls/azfw-connectivity-canadaeast-001"
}
import {
  to = module.firewall["azfw-transit-connectivity-canadacentral-001"].module.azure_firewall.azurerm_firewall.this
  id = "${local.sub}/resourceGroups/rg-shared-connectivity-canadacentral-001/providers/Microsoft.Network/azureFirewalls/azfw-transit-connectivity-canadacentral-001"
}
import {
  to = azurerm_firewall_network_rule_collection.classic["azfw-transit-connectivity-canadacentral-001/rc-allow-ns2-to-bch"]
  id = "${local.sub}/resourceGroups/rg-shared-connectivity-canadacentral-001/providers/Microsoft.Network/azureFirewalls/azfw-transit-connectivity-canadacentral-001/networkRuleCollections/rc-allow-ns2-to-bch"
}
import {
  to = module.firewall_policy["azfwpol-connectivity-001"].module.firewall_policy.azurerm_firewall_policy.this
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/firewallPolicies/azfwpol-connectivity-001"
}
import {
  to = module.firewall_policy["azfwpol-connectivity-001-BACKUP-20260320-233016-UTC"].module.firewall_policy.azurerm_firewall_policy.this
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/firewallPolicies/azfwpol-connectivity-001-BACKUP-20260320-233016-UTC"
}

import {
  to = module.firewall_policy["azfwpol-connectivity-001-BACKUP-20260320-233016-UTC"].module.rule_collection_group["rcg-1000-spoke-specific-canada-central"].azurerm_firewall_policy_rule_collection_group.this
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/firewallPolicies/azfwpol-connectivity-001-BACKUP-20260320-233016-UTC/ruleCollectionGroups/rcg-1000-spoke-specific-canada-central"
}
import {
  to = module.firewall_policy["azfwpol-connectivity-001-BACKUP-20260320-233016-UTC"].module.rule_collection_group["rcg-20000-spoke-specific-canada-east"].azurerm_firewall_policy_rule_collection_group.this
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/firewallPolicies/azfwpol-connectivity-001-BACKUP-20260320-233016-UTC/ruleCollectionGroups/rcg-20000-spoke-specific-canada-east"
}
import {
  to = module.firewall_policy["azfwpol-connectivity-001-BACKUP-20260320-233016-UTC"].module.rule_collection_group["rcg-300-cyberark-SIA-baseline"].azurerm_firewall_policy_rule_collection_group.this
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/firewallPolicies/azfwpol-connectivity-001-BACKUP-20260320-233016-UTC/ruleCollectionGroups/rcg-300-cyberark-SIA-baseline"
}
import {
  to = module.firewall_policy["azfwpol-connectivity-001-BACKUP-20260320-233016-UTC"].module.rule_collection_group["rcg-40000-onprem-to-spokes"].azurerm_firewall_policy_rule_collection_group.this
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/firewallPolicies/azfwpol-connectivity-001-BACKUP-20260320-233016-UTC/ruleCollectionGroups/rcg-40000-onprem-to-spokes"
}
import {
  to = module.firewall_policy["azfwpol-connectivity-001-BACKUP-20260320-233016-UTC"].module.rule_collection_group["rcg-41000-spokes-to-onprem"].azurerm_firewall_policy_rule_collection_group.this
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/firewallPolicies/azfwpol-connectivity-001-BACKUP-20260320-233016-UTC/ruleCollectionGroups/rcg-41000-spokes-to-onprem"
}
import {
  to = module.firewall_policy["azfwpol-connectivity-001-BACKUP-20260320-233016-UTC"].module.rule_collection_group["rcg-490-global-security-rexception"].azurerm_firewall_policy_rule_collection_group.this
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/firewallPolicies/azfwpol-connectivity-001-BACKUP-20260320-233016-UTC/ruleCollectionGroups/rcg-490-global-security-rexception"
}
import {
  to = module.firewall_policy["azfwpol-connectivity-001-BACKUP-20260320-233016-UTC"].module.rule_collection_group["rcg-500-global-security-baseline"].azurerm_firewall_policy_rule_collection_group.this
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/firewallPolicies/azfwpol-connectivity-001-BACKUP-20260320-233016-UTC/ruleCollectionGroups/rcg-500-global-security-baseline"
}
import {
  to = module.firewall_policy["azfwpol-connectivity-001-BACKUP-20260320-233016-UTC"].module.rule_collection_group["rcg-64900-deny-all"].azurerm_firewall_policy_rule_collection_group.this
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/firewallPolicies/azfwpol-connectivity-001-BACKUP-20260320-233016-UTC/ruleCollectionGroups/rcg-64900-deny-all"
}
import {
  to = module.firewall_policy["azfwpol-connectivity-001-BACKUP-20260320-233016-UTC"].module.rule_collection_group["rcg-800-global-internet-baseline"].azurerm_firewall_policy_rule_collection_group.this
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/firewallPolicies/azfwpol-connectivity-001-BACKUP-20260320-233016-UTC/ruleCollectionGroups/rcg-800-global-internet-baseline"
}
import {
  to = module.firewall_policy["azfwpol-connectivity-001"].module.rule_collection_group["rcg-1000-spoke-specific-canada-central"].azurerm_firewall_policy_rule_collection_group.this
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/firewallPolicies/azfwpol-connectivity-001/ruleCollectionGroups/rcg-1000-spoke-specific-canada-central"
}
import {
  to = module.firewall_policy["azfwpol-connectivity-001"].module.rule_collection_group["rcg-20000-spoke-specific-canada-east"].azurerm_firewall_policy_rule_collection_group.this
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/firewallPolicies/azfwpol-connectivity-001/ruleCollectionGroups/rcg-20000-spoke-specific-canada-east"
}
import {
  to = module.firewall_policy["azfwpol-connectivity-001"].module.rule_collection_group["rcg-39800-transit-to-spoke"].azurerm_firewall_policy_rule_collection_group.this
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/firewallPolicies/azfwpol-connectivity-001/ruleCollectionGroups/rcg-39800-transit-to-spoke"
}
import {
  to = module.firewall_policy["azfwpol-connectivity-001"].module.rule_collection_group["rcg-40000-onprem-to-spokes"].azurerm_firewall_policy_rule_collection_group.this
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/firewallPolicies/azfwpol-connectivity-001/ruleCollectionGroups/rcg-40000-onprem-to-spokes"
}
import {
  to = module.firewall_policy["azfwpol-connectivity-001"].module.rule_collection_group["rcg-490-global-security-rexception"].azurerm_firewall_policy_rule_collection_group.this
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/firewallPolicies/azfwpol-connectivity-001/ruleCollectionGroups/rcg-490-global-security-rexception"
}
import {
  to = module.firewall_policy["azfwpol-connectivity-001"].module.rule_collection_group["rcg-500-global-security-baseline"].azurerm_firewall_policy_rule_collection_group.this
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/firewallPolicies/azfwpol-connectivity-001/ruleCollectionGroups/rcg-500-global-security-baseline"
}
import {
  to = module.firewall_policy["azfwpol-connectivity-001"].module.rule_collection_group["rcg-64900-deny-all"].azurerm_firewall_policy_rule_collection_group.this
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/firewallPolicies/azfwpol-connectivity-001/ruleCollectionGroups/rcg-64900-deny-all"
}
import {
  to = module.firewall_policy["azfwpol-connectivity-001"].module.rule_collection_group["rcg-800-global-internet-baseline"].azurerm_firewall_policy_rule_collection_group.this
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/firewallPolicies/azfwpol-connectivity-001/ruleCollectionGroups/rcg-800-global-internet-baseline"
}

# Firewall diagnostic settings (8). Import id is <resource id>|<setting name>.
import {
  to = module.firewall["azfw-connectivity-canadacentral-001"].module.azure_firewall.azurerm_monitor_diagnostic_setting.this["metrics"]
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/azureFirewalls/azfw-connectivity-canadacentral-001|sendMetricsToLA"
}
import {
  to = module.firewall["azfw-connectivity-canadacentral-001"].module.azure_firewall.azurerm_monitor_diagnostic_setting.this["policy_settings"]
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/azureFirewalls/azfw-connectivity-canadacentral-001|FirewallPolicySettings"
}
import {
  to = module.firewall["azfw-connectivity-canadacentral-001"].module.azure_firewall.azurerm_monitor_diagnostic_setting.this["logs"]
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/azureFirewalls/azfw-connectivity-canadacentral-001|sendLogsToLA"
}
import {
  to = module.firewall["azfw-connectivity-canadaeast-001"].module.azure_firewall.azurerm_monitor_diagnostic_setting.this["metrics"]
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadaeast-001/providers/Microsoft.Network/azureFirewalls/azfw-connectivity-canadaeast-001|sendMetricsToLA"
}
import {
  to = module.firewall["azfw-connectivity-canadaeast-001"].module.azure_firewall.azurerm_monitor_diagnostic_setting.this["policy_settings"]
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadaeast-001/providers/Microsoft.Network/azureFirewalls/azfw-connectivity-canadaeast-001|FirewallPolicySettings"
}
import {
  to = module.firewall["azfw-connectivity-canadaeast-001"].module.azure_firewall.azurerm_monitor_diagnostic_setting.this["logs"]
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadaeast-001/providers/Microsoft.Network/azureFirewalls/azfw-connectivity-canadaeast-001|sendLogsToLA"
}
import {
  to = module.firewall["azfw-transit-connectivity-canadacentral-001"].module.azure_firewall.azurerm_monitor_diagnostic_setting.this["metrics"]
  id = "${local.sub}/resourceGroups/rg-shared-connectivity-canadacentral-001/providers/Microsoft.Network/azureFirewalls/azfw-transit-connectivity-canadacentral-001|sendMetricsToLA"
}
import {
  to = module.firewall["azfw-transit-connectivity-canadacentral-001"].module.azure_firewall.azurerm_monitor_diagnostic_setting.this["logs"]
  id = "${local.sub}/resourceGroups/rg-shared-connectivity-canadacentral-001/providers/Microsoft.Network/azureFirewalls/azfw-transit-connectivity-canadacentral-001|sendLogsToLA"
}
