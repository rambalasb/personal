locals {
  sub = data.azurerm_subscription.current.id

  common_tags = merge(var.tags, {
    Environment = var.environment # capitalised to match the live tag; Azure tag keys are case-insensitive
    managed-by  = "terraform"
    solution    = "tf-deploy-platform-firewall-management"
  })

  # Keyed the same way tf-deploy-platform-connectivity keys module.resource_group, so
  # the firewall/IP-group definitions carried over from that repo read
  # unchanged.
  rg_names = {
    hub_cc    = data.azurerm_resource_group.hub_cc.name
    hub_ce    = data.azurerm_resource_group.hub_ce.name
    shared_cc = data.azurerm_resource_group.shared_cc.name
    ip_groups = data.azurerm_resource_group.ip_groups.name
    backup_cc = data.azurerm_resource_group.backup_cc.name
  }
}
