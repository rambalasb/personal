# Classic inline network rule collections on azfw-transit-connectivity-canadacentral-001,
# the one firewall without a policy. The firewall wrapper (AVM) has no input for
# these, so they are declared natively against the wrapper's firewall.
# Remove this file when the transit firewall moves onto a firewall policy.

resource "azurerm_firewall_network_rule_collection" "classic" {
  for_each = module.config.classic_network_rule_collections

  name                = each.value.name
  azure_firewall_name = module.firewall[each.value.firewall_key].resource.name
  resource_group_name = local.rg_names[module.config.firewalls[each.value.firewall_key].rg_key]
  priority            = each.value.priority
  action              = each.value.action

  dynamic "rule" {
    for_each = each.value.rule
    content {
      name                  = rule.value.name
      protocols             = rule.value.protocols
      source_addresses      = rule.value.source_addresses
      source_ip_groups      = [for key in rule.value.source_ip_group_keys : module.ip_group[key].resource_id]
      destination_addresses = rule.value.destination_addresses
      destination_fqdns     = rule.value.destination_fqdns
      destination_ip_groups = [for key in rule.value.destination_ip_group_keys : module.ip_group[key].resource_id]
      destination_ports     = rule.value.destination_ports
    }
  }
}
