# Environment settings only. The firewall estate itself -- IP groups, policies,
# firewalls and rules -- is defined in config/ (see config.tf and README.md).

# Subscription
subscription_id = "f3835bc1-9829-4ac8-9d7a-0999e0b29b90"
environment     = "Prod"

# Tags
tags = {
  owner        = "connectivity-platform"
  CostCenterId = "80025906"
}

# Log Analytics workspaces
log_analytics_workspaces = {
  siem_security   = "/subscriptions/7d54d6f7-83d9-48cf-ac35-1068bcfd0561/resourceGroups/rg-siem-security-canadacentral-001/providers/Microsoft.OperationalInsights/workspaces/la-siem-security-canadacentral-001"
  siem_management = "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/rg-siem-management-canadacentral-001/providers/Microsoft.OperationalInsights/workspaces/la-siem-management-canadacentral-001"
}
