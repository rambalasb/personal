# =====================================================================
# Required inputs
# =====================================================================

variable "name" {
  type        = string
  description = "The name of the Static Web App. 2-60 characters; alphanumerics and hyphens; must start and end with an alphanumeric."
  nullable    = false

  validation {
    condition     = can(regex("^[a-zA-Z0-9]([a-zA-Z0-9-]{0,58}[a-zA-Z0-9])?$", var.name)) && length(var.name) >= 2
    error_message = "name must be 2-60 characters of alphanumerics and hyphens, starting and ending with an alphanumeric."
  }
}

variable "resource_group_name" {
  type        = string
  description = "The name of the Resource Group in which to create the Static Web App."
  nullable    = false
}

variable "location" {
  type        = string
  description = "The Azure region for the Static Web App resource. Static Web Apps are only offered in a subset of regions (e.g. westus2, centralus, eastus2, westeurope, eastasia); canadacentral is not one of them. Content is served globally regardless."
  nullable    = false

  validation {
    condition     = length(var.location) > 0
    error_message = "location must not be empty."
  }
}

# =====================================================================
# SKU
# =====================================================================

variable "sku_tier" {
  type        = string
  description = "SKU tier: 'Free' or 'Standard'. Must match sku_size."
  default     = "Standard"

  validation {
    condition     = contains(["Free", "Standard"], var.sku_tier)
    error_message = "sku_tier must be 'Free' or 'Standard'."
  }
}

variable "sku_size" {
  type        = string
  description = "SKU size: 'Free' or 'Standard'. Must match sku_tier."
  default     = "Standard"

  validation {
    condition     = contains(["Free", "Standard"], var.sku_size)
    error_message = "sku_size must be 'Free' or 'Standard'."
  }

  validation {
    condition     = var.sku_size == var.sku_tier
    error_message = "sku_size and sku_tier must be the same value."
  }
}

# =====================================================================
# Site configuration
# =====================================================================

variable "app_settings" {
  type        = map(string)
  description = "App settings (environment variables) exposed to the Static Web App's managed Functions API."
  default     = {}
  nullable    = false
}

variable "configuration_file_changes_enabled" {
  type        = bool
  description = "Whether changes to staticwebapp.config.json are permitted."
  default     = true
}

variable "preview_environments_enabled" {
  type        = bool
  description = "Whether preview (staging) environments are created for pull requests."
  default     = false
}

variable "public_network_access_enabled" {
  type        = bool
  description = "Whether the Static Web App is reachable from the public internet. Set false when exposing it only through a private endpoint (Standard SKU required)."
  default     = true
}

variable "basic_auth_enabled" {
  type        = bool
  description = "Whether password protection (basic auth) is enabled. basic_auth must be set when true. Requires the Standard SKU."
  default     = false
  nullable    = false
}

variable "basic_auth" {
  type = object({
    password     = string
    environments = string
  })
  description = "Password protection settings. environments is 'AllEnvironments' or 'StagingEnvironments'. Only evaluated when basic_auth_enabled = true. Source the password from Key Vault, never a literal."
  default     = null
  sensitive   = true

  validation {
    condition     = var.basic_auth == null || contains(["AllEnvironments", "StagingEnvironments"], try(var.basic_auth.environments, ""))
    error_message = "basic_auth.environments must be 'AllEnvironments' or 'StagingEnvironments'."
  }

  validation {
    condition     = !var.basic_auth_enabled || var.basic_auth != null
    error_message = "basic_auth must be set when basic_auth_enabled = true."
  }

  validation {
    condition     = var.basic_auth == null || !var.basic_auth_enabled || var.sku_tier == "Standard"
    error_message = "basic_auth requires sku_tier = 'Standard'."
  }
}

# =====================================================================
# Source repository
# =====================================================================

variable "repository_url" {
  type        = string
  description = "Repository URL to link to the Static Web App. Applied by an azapi_update_resource after creation; changes on the azurerm resource itself are ignored. Leave null when deploying with the API key from a pipeline."
  default     = null
}

variable "branch" {
  type        = string
  description = "Repository branch to deploy. Used only when repository_url is set; upstream defaults it to 'main'."
  default     = null
}

# =====================================================================
# Identity and custom domains
# =====================================================================

variable "managed_identities" {
  type = object({
    system_assigned            = optional(bool, false)
    user_assigned_resource_ids = optional(set(string), [])
  })
  description = "Managed identity configuration for the Static Web App."
  default     = {}
  nullable    = false
}

variable "custom_domains" {
  type = map(object({
    resource_group_name = optional(string)
    domain_name         = optional(string)
    ttl                 = optional(number, 300)
    validation_type     = optional(string, "cname-delegation")

    create_cname_records     = optional(bool, false)
    cname_name               = optional(string)
    cname_zone_name          = optional(string)
    cname_record             = optional(string)
    cname_target_resource_id = optional(string)

    create_txt_records = optional(bool, false)
    txt_name           = optional(string)
    txt_zone_name      = optional(string)
    txt_records        = optional(map(object({ value = string })))
  }))
  description = <<DESCRIPTION
Custom domains to bind to the Static Web App. Map key is an arbitrary logical name.

- `domain_name` - FQDN to bind. Derived from `cname_name` + `cname_zone_name` when unset.
- `validation_type` - `cname-delegation` (default) or `dns-txt-token` (needed for apex domains).
- `create_cname_records` / `create_txt_records` - create the DNS records in an Azure public DNS zone (`*_zone_name`, in `resource_group_name` or the site's RG).
- `cname_record` and `cname_target_resource_id` are mutually exclusive.
DESCRIPTION
  default     = {}
  nullable    = false

  validation {
    condition     = alltrue([for _, d in var.custom_domains : contains(["cname-delegation", "dns-txt-token"], d.validation_type)])
    error_message = "custom_domains[*].validation_type must be 'cname-delegation' or 'dns-txt-token'."
  }

  validation {
    condition     = alltrue([for _, d in var.custom_domains : !(d.cname_record != null && d.cname_target_resource_id != null)])
    error_message = "custom_domains[*]: set at most one of cname_record and cname_target_resource_id."
  }
}

# =====================================================================
# Private endpoints
# =====================================================================

variable "private_endpoints" {
  type = map(object({
    name = optional(string, null)
    role_assignments = optional(map(object({
      name                                   = optional(string, null)
      role_definition_id_or_name             = string
      principal_id                           = string
      description                            = optional(string, null)
      skip_service_principal_aad_check       = optional(bool, false)
      condition                              = optional(string, null)
      condition_version                      = optional(string, null)
      delegated_managed_identity_resource_id = optional(string, null)
      principal_type                         = optional(string, null)
    })), {})
    lock = optional(object({
      kind  = string
      name  = optional(string, null)
      notes = optional(string, null)
    }), null)
    tags                                    = optional(map(string), null)
    subnet_resource_id                      = string
    subresource_name                        = optional(string, null)
    private_dns_zone_group_name             = optional(string, "default")
    private_dns_zone_resource_ids           = optional(set(string), [])
    application_security_group_associations = optional(map(string), {})
    private_service_connection_name         = optional(string, null)
    network_interface_name                  = optional(string, null)
    location                                = optional(string, null)
    resource_group_name                     = optional(string, null)
    ip_configurations = optional(map(object({
      name               = string
      private_ip_address = string
      member_name        = optional(string)
    })), {})
  }))
  description = "Private endpoints to create on the Static Web App (subresource 'staticSites', DNS zone privatelink.<n>.azurestaticapps.net). Requires Standard SKU. Defaults to {} — the deploy repos create endpoints through tf-wrapper-avm-private-endpoint; a check warns when this is set."
  default     = {}
  nullable    = false

  validation {
    condition     = length(var.private_endpoints) == 0 || var.sku_tier == "Standard"
    error_message = "Private endpoints require sku_tier = 'Standard'."
  }
}

variable "private_endpoints_inherit_lock" {
  type        = bool
  description = "Whether private endpoints inherit the lock of the Static Web App."
  default     = true
}

variable "private_endpoints_manage_dns_zone_group" {
  type        = bool
  description = "Whether the module manages private DNS zone groups. Set false when Azure Policy manages them."
  default     = true
  nullable    = false
}

# =====================================================================
# Governance
# =====================================================================

variable "role_assignments" {
  type = map(object({
    role_definition_id_or_name             = string
    principal_id                           = string
    description                            = optional(string, null)
    skip_service_principal_aad_check       = optional(bool, false)
    condition                              = optional(string, null)
    condition_version                      = optional(string, null)
    delegated_managed_identity_resource_id = optional(string, null)
    principal_type                         = optional(string, null)
  }))
  description = "RBAC role assignments scoped to the Static Web App. Map key is an arbitrary logical name."
  default     = {}
  nullable    = false
}

variable "lock" {
  type = object({
    kind = string
    name = optional(string, null)
  })
  description = "Optional resource lock. kind must be 'CanNotDelete' or 'ReadOnly'."
  default     = null

  validation {
    condition     = var.lock == null || contains(["CanNotDelete", "ReadOnly"], try(var.lock.kind, ""))
    error_message = "lock.kind must be 'CanNotDelete' or 'ReadOnly' when lock is set."
  }
}

variable "all_child_resources_inherit_lock" {
  type        = bool
  description = "Whether child resources (custom domains, DNS records) inherit the lock."
  default     = true
}

variable "all_child_resources_inherit_tags" {
  type        = bool
  description = "Whether child resources inherit the tags."
  default     = true
}

variable "enable_telemetry" {
  type        = bool
  description = "Whether to enable AVM module telemetry. Set false to opt out."
  default     = true
  nullable    = false
}

variable "tags" {
  type        = map(string)
  description = "A map of tags to apply to the Static Web App. managed-by and module tags are added automatically."
  default     = null
}
