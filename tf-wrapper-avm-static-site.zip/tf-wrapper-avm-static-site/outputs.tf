output "resource_id" {
  description = "The Azure resource ID of the Static Web App."
  # Upstream marks this sensitive only because it is read off a resource that
  # carries api_key. An ID is not a secret, and deploy repos feed it to
  # tf-wrapper-avm-private-endpoint, so it is unwrapped here.
  value = nonsensitive(module.static_site.resource_id)
}

output "resource_name" {
  description = "The name of the Static Web App."
  value       = module.static_site.name
}

output "default_host_name" {
  description = "The default hostname of the Static Web App (e.g. <name>.<n>.azurestaticapps.net)."
  value       = module.static_site.resource_uri
}

output "domains" {
  description = "Custom domain hostnames and URLs bound to the Static Web App."
  value       = module.static_site.domains
}

output "api_key" {
  description = "The deployment API key (deployment token) of the Static Web App."
  sensitive   = true
  value       = module.static_site.api_key
}

output "resource_private_endpoints" {
  description = "Private endpoints created by the module, keyed as supplied in var.private_endpoints."
  value       = module.static_site.resource_private_endpoints
}

output "resource" {
  description = "The full azurerm_static_web_app object. Sensitive because it includes api_key."
  sensitive   = true
  value       = module.static_site.resource
}
