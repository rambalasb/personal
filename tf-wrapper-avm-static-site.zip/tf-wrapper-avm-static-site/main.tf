module "static_site" {
  source  = "Azure/avm-res-web-staticsite/azurerm"
  version = "0.7.0"

  # Required
  name                = var.name
  resource_group_name = var.resource_group_name
  location            = var.location

  # SKU
  sku_tier = var.sku_tier
  sku_size = var.sku_size

  # Site configuration
  app_settings                       = var.app_settings
  configuration_file_changes_enabled = var.configuration_file_changes_enabled
  preview_environments_enabled       = var.preview_environments_enabled
  public_network_access_enabled      = var.public_network_access_enabled
  basic_auth_enabled                 = var.basic_auth_enabled
  basic_auth                         = var.basic_auth

  # Source repository (applied via azapi_update_resource when repository_url is set)
  repository_url = var.repository_url
  branch         = var.branch

  # Identity, domains, networking
  managed_identities                      = var.managed_identities
  custom_domains                          = var.custom_domains
  private_endpoints                       = var.private_endpoints
  private_endpoints_inherit_lock          = var.private_endpoints_inherit_lock
  private_endpoints_manage_dns_zone_group = var.private_endpoints_manage_dns_zone_group

  # Governance
  role_assignments                 = var.role_assignments
  lock                             = var.lock
  all_child_resources_inherit_lock = var.all_child_resources_inherit_lock
  all_child_resources_inherit_tags = var.all_child_resources_inherit_tags
  enable_telemetry                 = var.enable_telemetry
  tags                             = local.module_tags
}
