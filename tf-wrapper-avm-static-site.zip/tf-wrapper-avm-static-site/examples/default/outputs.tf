output "resource_id" {
  value = module.static_site.resource_id
}

output "default_host_name" {
  value = module.static_site.default_host_name
}
