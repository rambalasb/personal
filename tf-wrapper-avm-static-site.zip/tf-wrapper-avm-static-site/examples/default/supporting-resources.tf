# random suffix to avoid name collisions on reruns
resource "random_string" "suffix" {
  length  = 6
  lower   = true
  upper   = false
  numeric = true
  special = false
}

# native supporting RG so the example tests standalone, without a sibling module.
# Static Web Apps are not offered in canadacentral; eastus2 is the nearest supported region.
resource "azurerm_resource_group" "this" {
  name     = "rg-avm-swa-default-test-${random_string.suffix.result}"
  location = "eastus2"
}
