module "static_site" {
  source = "../.."

  name                = "stapp-avm-swa-default-test-${random_string.suffix.result}"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location

  sku_tier = "Standard"
  sku_size = "Standard"

  preview_environments_enabled = false

  tags = {
    environment = "test"
  }

  enable_telemetry = false
}
