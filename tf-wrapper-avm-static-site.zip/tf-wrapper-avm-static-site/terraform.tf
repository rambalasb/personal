terraform {
  # Upstream avm-res-web-staticsite 0.7.0 requires >= 1.11 and azapi ~> 2.12.
  required_version = ">= 1.11, < 2.0"

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 4.3.0, < 5.0.0"
    }
    azapi = {
      source  = "Azure/azapi"
      version = "~> 2.12"
    }
  }
}
