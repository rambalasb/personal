check "tags_present" {
  assert {
    condition     = length(local.module_tags) > 0
    error_message = "Static Web App should have at least one tag for cost allocation and ownership tracking."
  }
}

check "private_endpoints_not_double_owned" {
  assert {
    condition     = length(var.private_endpoints) == 0
    error_message = "private_endpoints is set on the Static Web App. The tf-deploy-app-* repos declare endpoints through tf-wrapper-avm-private-endpoint as their own tier; declaring one in both places gives a single Azure resource two Terraform owners. Use one or the other."
  }
}

check "public_network_access_review" {
  assert {
    condition     = !var.public_network_access_enabled
    error_message = "public_network_access_enabled = true. If the site is internal, disable public access and expose it through a private endpoint (Standard SKU), or front it with Azure Front Door."
  }
}

check "free_sku_not_for_production" {
  assert {
    condition     = var.sku_tier == "Standard"
    error_message = "Static Web App is on the Free SKU. Free has no SLA, no private endpoints and no bring-your-own Functions; use Standard for anything beyond a sandbox."
  }
}

check "preview_environments_review" {
  assert {
    condition     = !var.preview_environments_enabled || var.basic_auth_enabled
    error_message = "Preview (staging) environments are enabled with no basic auth. Pull-request builds get public URLs; set preview_environments_enabled = false or protect them with basic_auth."
  }
}
