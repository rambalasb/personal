module "container_app_environment" {
  source  = "Azure/avm-res-app-managedenvironment/azurerm"
  version = "0.5.0"

  # Required
  name                = var.name
  resource_group_name = var.resource_group_name
  location            = var.location

  # Placement, kind & telemetry
  kind                               = var.kind
  parent_id                          = var.parent_id
  infrastructure_resource_group_name = var.infrastructure_resource_group_name
  enable_telemetry                   = var.enable_telemetry
  tags                               = local.module_tags

  # Networking (VNet, subnet, ingress, public access)
  vnet_configuration       = var.vnet_configuration
  infrastructure_subnet_id = var.infrastructure_subnet_id
  ingress_configuration    = var.ingress_configuration
  public_network_access    = var.public_network_access

  # Workload profiles & availability zones
  workload_profiles       = var.workload_profiles
  availability_zones      = var.availability_zones
  zone_redundancy_enabled = var.zone_redundancy_enabled

  # Logging, telemetry & diagnostics configuration
  app_logs_configuration       = var.app_logs_configuration
  app_insights_configuration   = var.app_insights_configuration
  open_telemetry_configuration = var.open_telemetry_configuration
  log_analytics_workspace      = var.log_analytics_workspace
  diagnostic_settings          = var.diagnostic_settings

  # Dapr, KEDA & peer (mTLS) configuration
  dapr_configuration         = var.dapr_configuration
  keda_configuration         = var.keda_configuration
  peer_authentication        = var.peer_authentication
  peer_traffic_configuration = var.peer_traffic_configuration

  # Encryption & custom domain
  disk_encryption_configuration = var.disk_encryption_configuration
  custom_domain_configuration   = var.custom_domain_configuration

  # Child resource collections
  certificates               = var.certificates
  managed_certificates       = var.managed_certificates
  dapr_components            = var.dapr_components
  dapr_subscriptions         = var.dapr_subscriptions
  dot_net_components         = var.dot_net_components
  java_components            = var.java_components
  http_route_configs         = var.http_route_configs
  maintenance_configurations = var.maintenance_configurations
  storages                   = var.storages

  # Identity, RBAC & locks
  managed_identities = var.managed_identities
  role_assignments   = var.role_assignments
  lock               = var.lock

  # Operation tuning
  timeouts = var.timeouts

  # --- Deprecated flat inputs (kept for back-compat; the AVM module emits its own
  #     deprecation warnings and steers callers to the object inputs above) ---
  infrastructure_resource_group                = var.infrastructure_resource_group
  internal_load_balancer_enabled               = var.internal_load_balancer_enabled
  public_network_access_enabled                = var.public_network_access_enabled
  zone_redundant                               = var.zone_redundant
  workload_profile                             = var.workload_profile
  peer_authentication_enabled                  = var.peer_authentication_enabled
  peer_traffic_encryption_enabled              = var.peer_traffic_encryption_enabled
  log_analytics_workspace_customer_id          = var.log_analytics_workspace_customer_id
  log_analytics_workspace_primary_shared_key   = var.log_analytics_workspace_primary_shared_key
  log_analytics_workspace_destination          = var.log_analytics_workspace_destination
  dapr_application_insights_connection_string  = var.dapr_application_insights_connection_string
  dapr_ai_connection_string                    = var.dapr_ai_connection_string
  dapr_ai_connection_string_version            = var.dapr_ai_connection_string_version
  dapr_ai_instrumentation_key                  = var.dapr_ai_instrumentation_key
  dapr_ai_instrumentation_key_version          = var.dapr_ai_instrumentation_key_version
  custom_domain_dns_suffix                     = var.custom_domain_dns_suffix
  custom_domain_certificate_value              = var.custom_domain_certificate_value
  custom_domain_certificate_password           = var.custom_domain_certificate_password
  custom_domain_certificate_key_vault_url      = var.custom_domain_certificate_key_vault_url
  custom_domain_certificate_key_vault_identity = var.custom_domain_certificate_key_vault_identity
  certificate_value                            = var.certificate_value
  certificate_value_version                    = var.certificate_value_version
  certificate_password                         = var.certificate_password
  certificate_password_version                 = var.certificate_password_version
  connection_string                            = var.connection_string
  connection_string_version                    = var.connection_string_version
  shared_key                                   = var.shared_key
  shared_key_version                           = var.shared_key_version
  key                                          = var.key
  key_version                                  = var.key_version
}
