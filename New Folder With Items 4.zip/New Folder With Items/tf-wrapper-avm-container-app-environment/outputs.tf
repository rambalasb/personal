output "resource_id" {
  description = "The resource ID of the Container Apps Managed Environment."
  value       = module.container_app_environment.resource_id
}

output "name" {
  description = "The name of the Container Apps Managed Environment."
  value       = module.container_app_environment.name
}

output "resource" {
  description = "The full resource object of the Container Apps Managed Environment."
  value       = module.container_app_environment.resource
}

output "default_domain" {
  description = "The default domain of the Container Apps Managed Environment (used to build app FQDNs)."
  value       = module.container_app_environment.default_domain
}

output "static_ip_address" {
  description = "The static IP address of the Container Apps Managed Environment."
  value       = module.container_app_environment.static_ip_address
}

output "docker_bridge_cidr" {
  description = "The Docker bridge CIDR of the Container Apps Managed Environment."
  value       = module.container_app_environment.docker_bridge_cidr
}

output "platform_reserved_cidr" {
  description = "The platform reserved CIDR of the Container Apps Managed Environment."
  value       = module.container_app_environment.platform_reserved_cidr
}

output "platform_reserved_dns_ip_address" {
  description = "The platform reserved DNS IP address of the Container Apps Managed Environment."
  value       = module.container_app_environment.platform_reserved_dns_ip_address
}

output "custom_domain_verification_id" {
  description = "The custom domain verification ID of the Container Apps Managed Environment."
  value       = module.container_app_environment.custom_domain_verification_id
  sensitive   = true
}

output "event_stream_endpoint" {
  description = "The event stream endpoint of the Container Apps Managed Environment."
  value       = module.container_app_environment.event_stream_endpoint
}

output "infrastructure_resource_group" {
  description = "The infrastructure resource group of the Container Apps Managed Environment."
  value       = module.container_app_environment.infrastructure_resource_group
}

output "managed_identities" {
  description = "The managed identities assigned to the Container Apps Managed Environment."
  value       = module.container_app_environment.managed_identities
}

output "dapr_ai_instrumentation_key" {
  description = "The Dapr AI instrumentation key of the Container Apps Managed Environment."
  value       = module.container_app_environment.dapr_ai_instrumentation_key
  sensitive   = true
}

output "certificate_resource_ids" {
  description = "Map of certificate resources connected to this environment, keyed by the input map key of var.certificates."
  value       = module.container_app_environment.certificate_resource_ids
}

output "managed_certificate_resource_ids" {
  description = "Map of managed certificate resources connected to this environment, keyed by the input map key of var.managed_certificates."
  value       = module.container_app_environment.managed_certificate_resource_ids
}

output "dapr_component_resource_ids" {
  description = "Map of Dapr component resources connected to this environment, keyed by the input map key of var.dapr_components."
  value       = module.container_app_environment.dapr_component_resource_ids
}

output "storage_resource_ids" {
  description = "Map of storage share resources connected to this environment, keyed by the input map key of var.storages."
  value       = module.container_app_environment.storage_resource_ids
}
