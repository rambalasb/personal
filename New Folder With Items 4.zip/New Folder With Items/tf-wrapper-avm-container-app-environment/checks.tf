# Post-plan/apply advisory checks. These surface as warnings (never block apply) and
# assert cross-configuration invariants that the AVM module does not enforce on its own.

# An internal-only environment (no public static IP) must sit in a delegated infrastructure
# subnet — supplied either via the vnet_configuration object or the flat infrastructure_subnet_id.
check "internal_vnet_requires_subnet" {
  assert {
    condition     = var.vnet_configuration == null || !coalesce(var.vnet_configuration.internal, false) || var.vnet_configuration.infrastructure_subnet_id != null || var.infrastructure_subnet_id != null
    error_message = "An internal Container App Environment (vnet_configuration.internal = true) requires an infrastructure subnet. Set vnet_configuration.infrastructure_subnet_id or infrastructure_subnet_id."
  }
}

# Same invariant via the deprecated flat internal_load_balancer_enabled input.
check "internal_lb_requires_subnet" {
  assert {
    condition     = var.internal_load_balancer_enabled != true || var.infrastructure_subnet_id != null || try(var.vnet_configuration.infrastructure_subnet_id, null) != null
    error_message = "internal_load_balancer_enabled = true requires an infrastructure subnet. Set infrastructure_subnet_id (or migrate to vnet_configuration)."
  }
}
