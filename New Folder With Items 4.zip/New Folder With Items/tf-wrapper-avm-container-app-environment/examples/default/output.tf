output "resource_id" {
  description = "The resource ID of the Container App Environment."
  value       = module.container_app_environment.resource_id
}

output "name" {
  description = "The name of the Container App Environment."
  value       = module.container_app_environment.name
}

output "default_domain" {
  description = "The default domain of the Container App Environment (used to build app FQDNs)."
  value       = module.container_app_environment.default_domain
}
