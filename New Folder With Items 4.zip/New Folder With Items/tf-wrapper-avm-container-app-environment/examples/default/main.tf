# Default example: deploys a Container App Environment on its own to confirm the wrapper works.
module "container_app_environment" {
  source = "../../"

  name                = "cae-default-${random_string.suffix.result}"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location

  # Zone redundancy requires an infrastructure subnet, which this standalone example doesn't provision.
  zone_redundant = false

  tags = {
    example  = "default"
    scenario = "container-app-environment"
  }
}
