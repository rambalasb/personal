# Prerequisite resources the wrapper needs to be tested standalone.
# A Container App Environment only requires a resource group to live in.

# Short random suffix keeps names collision-free when multiple people test in the same subscription.
resource "random_string" "suffix" {
  length  = 6
  lower   = true
  upper   = false
  numeric = true
  special = false
}

resource "azurerm_resource_group" "this" {
  name     = "rg-cae-default-${random_string.suffix.result}"
  location = "eastus"
}
