terraform {
  # Matches the wrapper's floor (AVM managed environment requires Terraform >= 1.10).
  required_version = ">= 1.10, < 2.0"

  required_providers {
    # azurerm creates the supporting resource group; the wrapper itself uses both azurerm and azapi.
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 4.0, < 5.0"
    }
    azapi = {
      source  = "Azure/azapi"
      version = "~> 2.7"
    }
    random = {
      source  = "hashicorp/random"
      version = "~> 3.5"
    }
  }
}

provider "azurerm" {
  features {}
}

provider "azapi" {}

provider "random" {}
