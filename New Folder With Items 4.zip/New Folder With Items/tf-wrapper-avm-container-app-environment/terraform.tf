terraform {
  # AVM avm-res-app-managedenvironment v0.5.0 requires Terraform >= 1.10.
  required_version = ">= 1.10, < 2.0"

  required_providers {
    # This AVM module uses BOTH azurerm and azapi internally, so the wrapper declares both.
    # azurerm floor (>= 4.0) is tighter than the >= 3.116 baseline of some sibling wrappers.
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 4.0, < 5.0"
    }
    azapi = {
      source  = "Azure/azapi"
      version = "~> 2.7"
    }
  }
}
