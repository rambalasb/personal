module "container_app_job" {
  source  = "Azure/avm-res-app-job/azurerm"
  version = "0.2.1"

  # Required
  name                                  = var.name
  resource_group_name                   = var.resource_group_name
  location                              = var.location
  container_app_environment_resource_id = var.container_app_environment_resource_id
  template                              = var.template

  # Trigger & execution behaviour
  trigger_config             = var.trigger_config
  replica_timeout_in_seconds = var.replica_timeout_in_seconds
  replica_retry_limit        = var.replica_retry_limit
  workload_profile_name      = var.workload_profile_name

  # Container registries & secrets
  registries = var.registries
  secrets    = var.secrets

  # Identity
  managed_identities = var.managed_identities

  # Telemetry & tagging
  enable_telemetry = var.enable_telemetry
  tags             = local.module_tags
}
