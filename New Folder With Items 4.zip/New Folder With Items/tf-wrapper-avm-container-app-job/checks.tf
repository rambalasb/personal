# Post-plan/apply advisory checks. These surface as warnings (never block apply) and
# assert cross-configuration invariants that the AVM module does not enforce on its own.
# (AVM validates that exactly one trigger type is set, but not the fields within it.)

check "schedule_trigger_requires_cron" {
  assert {
    condition     = try(var.trigger_config.schedule_trigger_config, null) == null || try(var.trigger_config.schedule_trigger_config.cron_expression, null) != null
    error_message = "A schedule-triggered Container App Job requires trigger_config.schedule_trigger_config.cron_expression to be set (e.g. \"0 */6 * * *\")."
  }
}

check "replica_timeout_is_positive" {
  assert {
    condition     = var.replica_timeout_in_seconds >= 1
    error_message = "replica_timeout_in_seconds must be a positive number of seconds (the Azure default is 300)."
  }
}
