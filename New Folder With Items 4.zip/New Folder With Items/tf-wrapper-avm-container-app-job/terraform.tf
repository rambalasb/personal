terraform {
  required_version = ">= 1.9, < 2.0"

  required_providers {
    # AVM avm-res-app-job v0.2.1 requires azurerm ~> 4.0, so this constraint is tighter
    # than the >= 3.116 baseline used by some sibling wrappers.
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 4.0, < 5.0"
    }
  }
}
