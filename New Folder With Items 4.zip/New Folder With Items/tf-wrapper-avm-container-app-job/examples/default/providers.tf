terraform {
  required_version = ">= 1.9, < 2.0"

  required_providers {
    # The wrapper and the supporting resources are all azurerm-based.
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 4.0, < 5.0"
    }
    random = {
      source  = "hashicorp/random"
      version = "~> 3.5"
    }
  }
}

provider "azurerm" {
  features {}
}

provider "random" {}
