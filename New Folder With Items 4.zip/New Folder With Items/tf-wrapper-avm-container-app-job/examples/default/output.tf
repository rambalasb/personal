output "resource_id" {
  description = "The resource ID of the Container App Job."
  value       = module.container_app_job.resource_id
}

output "container_app_job_name" {
  description = "The name of the Container App Job."
  value       = module.container_app_job.container_app_job_name
}
