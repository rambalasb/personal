# Default example: deploys a manually-triggered Container App Job into the supporting
# environment to confirm the wrapper works. Uses the Microsoft "quickstart-jobs" image.
module "container_app_job" {
  source = "../../"

  name                                  = "caj-default-${random_string.suffix.result}"
  location                              = azurerm_resource_group.this.location
  resource_group_name                   = azurerm_resource_group.this.name
  container_app_environment_resource_id = azurerm_container_app_environment.this.id

  # A Container App Job template takes a single container object.
  template = {
    container = {
      name   = "main"
      image  = "mcr.microsoft.com/k8se/quickstart-jobs:latest"
      cpu    = 0.25
      memory = "0.5Gi"
    }
  }

  # Manual trigger: run one replica to completion when started on demand.
  trigger_config = {
    manual_trigger_config = {
      parallelism              = 1
      replica_completion_count = 1
    }
  }

  replica_timeout_in_seconds = 300

  tags = {
    example  = "default"
    scenario = "container-app-job"
  }
}
