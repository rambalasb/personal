# Post-plan/apply advisory checks. These surface as warnings (never block apply) and
# assert compliance / availability invariants that the AVM module does not enforce.

check "external_ingress_enforces_https" {
  assert {
    condition     = var.ingress == null || !var.ingress.external_enabled || !var.ingress.allow_insecure_connections
    error_message = "An externally-exposed Container App should not allow insecure (HTTP) connections. Set ingress.allow_insecure_connections = false."
  }
}

check "external_ingress_has_warm_replica" {
  assert {
    condition     = var.ingress == null || !var.ingress.external_enabled || (var.template.min_replicas != null && var.template.min_replicas >= 1)
    error_message = "A publicly-exposed Container App that scales to zero incurs cold-start latency on the first request. Set template.min_replicas >= 1 for availability."
  }
}
