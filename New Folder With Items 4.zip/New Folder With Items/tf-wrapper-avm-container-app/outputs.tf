output "resource_id" {
  description = "The resource ID of the Container App."
  value       = module.container_app.resource_id
}

output "name" {
  description = "The name of the Container App."
  value       = module.container_app.name
}

output "location" {
  description = "The Azure region where the Container App is located."
  value       = module.container_app.location
}

output "environment_id" {
  description = "The ID of the Container App Environment hosting this Container App."
  value       = module.container_app.environment_id
}

output "fqdn_url" {
  description = "The HTTPS URL (ingress FQDN) that can be used to access the deployed Container App."
  value       = module.container_app.fqdn_url
}

output "latest_revision_name" {
  description = "The name of the latest revision of the Container App."
  value       = module.container_app.latest_revision_name
}

output "latest_revision_fqdn" {
  description = "The FQDN of the latest revision of the Container App."
  value       = module.container_app.latest_revision_fqdn
}

output "latest_ready_revision_name" {
  description = "The name of the latest ready revision of the Container App."
  value       = module.container_app.latest_ready_revision_name
}

output "outbound_ip_addresses" {
  description = "The outbound IP addresses of the Container App."
  value       = module.container_app.outbound_ip_addresses
}

output "custom_domains" {
  description = "The custom domains configured for the Container App ingress."
  value       = module.container_app.custom_domains
}

output "custom_domain_verification_id" {
  description = "The custom domain verification ID for the Container App (used to prove domain ownership)."
  value       = module.container_app.custom_domain_verification_id
  sensitive   = true
}

output "identity" {
  description = "The managed identities assigned to the Container App."
  value       = module.container_app.identity
}
