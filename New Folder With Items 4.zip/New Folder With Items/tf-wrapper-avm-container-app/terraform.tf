terraform {
  # AVM avm-res-app-containerapp v0.9.0 requires Terraform ~> 1.11.
  required_version = ">= 1.11, < 2.0"

  required_providers {
    # This AVM module is implemented entirely with the azapi provider and does NOT use
    # hashicorp/azurerm, so — unlike most sibling wrappers — only azapi is declared here.
    azapi = {
      source  = "Azure/azapi"
      version = "~> 2.5"
    }
  }
}
