module "container_app" {
  source  = "Azure/avm-res-app-containerapp/azurerm"
  version = "0.9.0"

  # Required
  name                                  = var.name
  resource_group_name                   = var.resource_group_name
  container_app_environment_resource_id = var.container_app_environment_resource_id
  template                              = var.template

  # Placement & metadata
  location              = var.location
  resource_group_id     = var.resource_group_id
  kind                  = var.kind
  workload_profile_name = var.workload_profile_name
  enable_telemetry      = var.enable_telemetry
  tags                  = local.module_tags

  # Revisions & scaling
  revision_mode          = var.revision_mode
  max_inactive_revisions = var.max_inactive_revisions

  # Ingress & networking
  ingress = var.ingress

  # App configuration: Dapr, registries, secrets, service binding, runtime
  dapr       = var.dapr
  registries = var.registries
  secrets    = var.secrets
  service    = var.service
  runtime    = var.runtime

  # Identity, RBAC & authentication
  managed_identities = var.managed_identities
  identity_settings  = var.identity_settings
  role_assignments   = var.role_assignments
  auth_configs       = var.auth_configs

  # Locks & operation tuning
  lock     = var.lock
  timeouts = var.timeouts
}
