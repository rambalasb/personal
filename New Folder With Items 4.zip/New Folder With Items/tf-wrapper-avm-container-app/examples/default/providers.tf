terraform {
  # Matches the wrapper's floor (AVM container app requires Terraform ~> 1.11).
  required_version = ">= 1.11, < 2.0"

  required_providers {
    # The wrapper is azapi-only, but this example also creates a supporting Container App
    # Environment via azurerm, so both providers are declared here at the root.
    azapi = {
      source  = "Azure/azapi"
      version = "~> 2.5"
    }
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 4.0, < 5.0"
    }
    random = {
      source  = "hashicorp/random"
      version = "~> 3.5"
    }
  }
}

provider "azurerm" {
  features {}
}

provider "azapi" {}

provider "random" {}
