# Prerequisite resources the wrapper needs to be tested standalone.
# A Container App must be placed inside a Container App Environment, which needs a resource group.

resource "random_string" "suffix" {
  length  = 6
  lower   = true
  upper   = false
  numeric = true
  special = false
}

resource "azurerm_resource_group" "this" {
  name     = "rg-ca-default-${random_string.suffix.result}"
  location = "canadacentral"
}

# Supporting Container App Environment (raw azurerm resource) that hosts the app under test.
resource "azurerm_container_app_environment" "this" {
  name                = "cae-ca-default-${random_string.suffix.result}"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location
}
