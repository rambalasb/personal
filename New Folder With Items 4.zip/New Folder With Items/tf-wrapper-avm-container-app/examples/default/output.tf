output "resource_id" {
  description = "The resource ID of the Container App."
  value       = module.container_app.resource_id
}

output "name" {
  description = "The name of the Container App."
  value       = module.container_app.name
}

output "fqdn_url" {
  description = "The HTTPS URL (ingress FQDN) of the deployed Container App."
  value       = module.container_app.fqdn_url
}
