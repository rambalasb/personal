# Default example: deploys a single Container App into the supporting environment to confirm
# the wrapper works. Uses the Microsoft "quickstart" hello-world image.
module "container_app" {
  source = "../../"

  name                                  = "ca-default-${random_string.suffix.result}"
  resource_group_name                   = azurerm_resource_group.this.name
  location                              = azurerm_resource_group.this.location
  container_app_environment_resource_id = azurerm_container_app_environment.this.id

  # min_replicas = 1 keeps a warm instance (satisfies the wrapper's cold-start check).
  template = {
    min_replicas = 1
    containers = [{
      name   = "main"
      image  = "mcr.microsoft.com/k8se/quickstart:latest"
      cpu    = 0.25
      memory = "0.5Gi"
    }]
  }

  # External ingress with HTTPS enforced (allow_insecure_connections = false keeps the
  # wrapper's external-ingress check green) routing all traffic to the latest revision.
  ingress = {
    external_enabled           = true
    target_port                = 80
    allow_insecure_connections = false
    traffic_weight = [{
      latest_revision = true
      percentage      = 100
    }]
  }

  tags = {
    example  = "default"
    scenario = "container-app"
  }
}
