check "tags_present" {
  assert {
    condition     = length(local.module_tags) > 0
    error_message = "User Assigned Identity should have at least one tag for cost allocation and ownership tracking."
  }
}

check "lock_kind_valid_when_set" {
  assert {
    condition     = var.lock == null || contains(["CanNotDelete", "ReadOnly"], try(var.lock.kind, ""))
    error_message = "When lock is set, lock.kind must be 'CanNotDelete' or 'ReadOnly'."
  }
}
