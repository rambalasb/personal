output "resource_id" {
  description = "The Azure resource ID of the User Assigned Identity."
  value       = module.user_assigned_identity.resource_id
}

output "resource_name" {
  description = "The name of the User Assigned Identity."
  value       = module.user_assigned_identity.resource_name
}

output "client_id" {
  description = "The client ID of the User Assigned Identity."
  value       = module.user_assigned_identity.client_id
}

output "principal_id" {
  description = "The principal (object) ID of the User Assigned Identity, used to grant it access to other resources."
  value       = module.user_assigned_identity.principal_id
}

output "tenant_id" {
  description = "The tenant ID the identity belongs to."
  value       = module.user_assigned_identity.tenant_id
}

output "resource" {
  description = "The full User Assigned Identity object."
  value       = module.user_assigned_identity.resource
}
