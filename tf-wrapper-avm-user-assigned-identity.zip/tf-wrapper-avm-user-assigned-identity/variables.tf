# =====================================================================
# Required inputs
# =====================================================================

variable "name" {
  type        = string
  description = "The name of the User Assigned Identity. 3-128 characters; alphanumerics, hyphens, underscores; must start with a letter or number."

  validation {
    condition     = can(regex("^[a-zA-Z0-9][a-zA-Z0-9_-]{2,127}$", var.name))
    error_message = "name must be 3-128 characters, start with a letter or digit, and contain only alphanumerics, hyphens, and underscores."
  }
}

variable "resource_group_name" {
  type        = string
  description = "The name of the Resource Group in which to create the User Assigned Identity."
}

variable "location" {
  type        = string
  description = "The Azure region where the User Assigned Identity will be deployed."

  validation {
    condition     = length(var.location) > 0
    error_message = "location must not be empty."
  }
}

# =====================================================================
# Optional toggles
# =====================================================================

variable "enable_telemetry" {
  type        = bool
  description = "Whether to enable AVM module telemetry. Set false to opt out."
  default     = true
}

variable "federated_identity_credentials" {
  type = map(object({
    audience = list(string)
    issuer   = string
    name     = string
    subject  = string
  }))
  description = "Map of federated identity credentials for OIDC/workload-identity federation. Map key is an arbitrary logical name."
  default     = {}
}

variable "role_assignments" {
  type = map(object({
    role_definition_id_or_name             = string
    scope                                  = string
    condition                              = optional(string, null)
    condition_version                      = optional(string, null)
    delegated_managed_identity_resource_id = optional(string, null)
    description                            = optional(string, null)
    skip_service_principal_aad_check       = optional(bool, false)
  }))
  nullable    = false
  description = "Map of RBAC role assignments where the User Assigned Identity is the principal. Supply scope and role_definition_id_or_name per entry."
  default     = {}
}

variable "lock" {
  type = object({
    kind = string
    name = optional(string, null)
  })
  description = "Optional resource lock. kind must be 'CanNotDelete' or 'ReadOnly'."
  default     = null

  validation {
    condition     = var.lock == null || contains(["CanNotDelete", "ReadOnly"], try(var.lock.kind, ""))
    error_message = "lock.kind must be 'CanNotDelete' or 'ReadOnly' when lock is set."
  }
}

variable "tags" {
  type        = map(string)
  description = "A map of tags to apply to the User Assigned Identity."
  default     = null
}
