module "user_assigned_identity" {
  source  = "Azure/avm-res-managedidentity-userassignedidentity/azurerm"
  version = "0.5.0"

  # Required
  name                = var.name
  resource_group_name = var.resource_group_name
  location            = var.location

  # Optional
  enable_telemetry               = var.enable_telemetry
  federated_identity_credentials = var.federated_identity_credentials
  role_assignments               = var.role_assignments
  lock                           = var.lock
  tags                           = local.module_tags
}
