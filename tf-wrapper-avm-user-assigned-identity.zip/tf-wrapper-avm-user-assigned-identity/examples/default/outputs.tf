output "resource_id" {
  value = module.managed_identity.resource_id
}

output "principal_id" {
  value = module.managed_identity.principal_id
}

output "client_id" {
  value = module.managed_identity.client_id
}
