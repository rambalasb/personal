module "managed_identity" {
  source = "../.."

  name                = "id-avm-mi-ra-test-${random_string.suffix.result}"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location

  enable_telemetry = false
}

# native role assignment so the example exercises the identity standalone
resource "azurerm_role_assignment" "mi_reader" {
  scope                = azurerm_resource_group.this.id
  role_definition_name = "Reader"
  principal_id         = module.managed_identity.principal_id
  principal_type       = "ServicePrincipal"
}
