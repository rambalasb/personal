output "identity_principal_id" {
  value = module.managed_identity.principal_id
}

output "role_assignment_id" {
  value = azurerm_role_assignment.mi_reader.id
}
