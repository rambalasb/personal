# imports.tf
# One-time adoption of existing Azure resources into the wrapper modules.
# Each block targets the AVM module's INTERNAL resource address:
#   module.<wrapper>[key].module.<avm>.<resource>
# azapi = resource group / storage / recovery vault (AVM uses azapi_resource);
# azurerm = key vault / identity / alerts.
# Assumes every enable_* flag is true. Remove this file after the first apply.
#
# NOT validated by a real plan here — run `terraform plan` and reconcile
# AVM-default diffs before applying.

locals {
  sub = data.azurerm_subscription.current.id
}

# ── Resource groups (azapi, count -> this[0]) ──────────────────────────
import {
  to = module.resource_group["siem"].module.resource_group.azapi_resource.this[0]
  id = "${local.sub}/resourceGroups/rg-siem-identity-canadacentral-001"
}
import {
  to = module.resource_group["alerts"].module.resource_group.azapi_resource.this[0]
  id = "${local.sub}/resourceGroups/rg-alerts-identity-canadacentral-001"
}
import {
  to = module.resource_group["mid"].module.resource_group.azapi_resource.this[0]
  id = "${local.sub}/resourceGroups/rg-mid-identity-canadacentral-001"
}
import {
  to = module.resource_group["shared"].module.resource_group.azapi_resource.this[0]
  id = "${local.sub}/resourceGroups/rg-shared-identity-canadacentral-001"
}

# ── Key vaults (azurerm) ───────────────────────────────────────────────
import {
  to = module.key_vault["fwtls"].module.key_vault.azurerm_key_vault.this
  id = "${local.sub}/resourceGroups/rg-mid-identity-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvfwtlscanadacentral"
}
import {
  to = module.key_vault["idn"].module.key_vault.azurerm_key_vault.this
  id = "${local.sub}/resourceGroups/rg-siem-identity-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvidncanadacentral"
}

# ── User-assigned identities (azurerm) ─────────────────────────────────
import {
  to = module.user_assigned_identity["azfirewall"].module.user_assigned_identity.azurerm_user_assigned_identity.this
  id = "${local.sub}/resourceGroups/rg-mid-identity-canadacentral-001/providers/Microsoft.ManagedIdentity/userAssignedIdentities/mid-azfirewall-canadacentral-001"
}
import {
  to = module.user_assigned_identity["dev-autmn"].module.user_assigned_identity.azurerm_user_assigned_identity.this
  id = "${local.sub}/resourceGroups/rg-mid-identity-canadacentral-001/providers/Microsoft.ManagedIdentity/userAssignedIdentities/mid-dev-autmn-canadacentral-001"
}
import {
  to = module.user_assigned_identity["prod-autmn"].module.user_assigned_identity.azurerm_user_assigned_identity.this
  id = "${local.sub}/resourceGroups/rg-mid-identity-canadacentral-001/providers/Microsoft.ManagedIdentity/userAssignedIdentities/mid-prod-autmn-canadacentral-001"
}

# ── Storage account (azapi) ────────────────────────────────────────────
import {
  to = module.storage_account["nwidn"].module.storage_account.azapi_resource.this
  id = "${local.sub}/resourceGroups/rg-shared-identity-canadacentral-001/providers/Microsoft.Storage/storageAccounts/stnwidncanadacentral"
}

# ── Recovery Services vault (azapi) ────────────────────────────────────
import {
  to = module.recovery_services_vault["identity"].module.recovery_services_vault.azapi_resource.this
  id = "${local.sub}/resourceGroups/rg-siem-identity-canadacentral-001/providers/Microsoft.RecoveryServices/vaults/rsv-identity-canadacentral-001"
}

# ── Alerts (azurerm, embedded in the amba-alz wrapper -> monitoring[0]) ─
import {
  to = module.monitoring[0].azurerm_monitor_metric_alert.this["backup"]
  id = "${local.sub}/resourceGroups/rg-siem-identity-canadacentral-001/providers/Microsoft.Insights/metricAlerts/Backup Alert"
}
import {
  to = module.monitoring[0].azurerm_monitor_activity_log_alert.this["service_outage"]
  id = "${local.sub}/resourceGroups/rg-alerts-identity-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/Service-Outage-Alert-canadacentral"
}
import {
  to = module.monitoring[0].azurerm_monitor_activity_log_alert.this["keyvault_deletion"]
  id = "${local.sub}/resourceGroups/rg-alerts-identity-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/KeyVault-Deletion-Alert-canadacentral"
}
import {
  to = module.monitoring[0].azurerm_monitor_scheduled_query_rules_alert_v2.this["kv_secret_expired"]
  id = "${local.sub}/resourceGroups/rg-alerts-identity-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/KeyVault-Secret-Expired-Alert-canadacentral"
}
import {
  to = module.monitoring[0].azurerm_monitor_scheduled_query_rules_alert_v2.this["kv_secret_near_expiry"]
  id = "${local.sub}/resourceGroups/rg-alerts-identity-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/KeyVault-Secret-Near-Expiry-Alert-canadacentral"
}
import {
  to = module.monitoring[0].azurerm_monitor_scheduled_query_rules_alert_v2.this["resource_creation"]
  id = "${local.sub}/resourceGroups/rg-alerts-identity-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/Resource-Creation-Alert-canadacentral"
}
import {
  to = module.monitoring[0].azurerm_monitor_scheduled_query_rules_alert_v2.this["storage_container_deletion"]
  id = "${local.sub}/resourceGroups/rg-alerts-identity-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/Storage-Account-Container-Deletion-Alert-canadacentral"
}
import {
  to = module.monitoring[0].azurerm_monitor_scheduled_query_rules_alert_v2.this["storage_deletion"]
  id = "${local.sub}/resourceGroups/rg-alerts-identity-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/Storage-Account-Deletion-Alert-canadacentral"
}
