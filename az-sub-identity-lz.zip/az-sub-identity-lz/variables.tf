# =====================================================================
# 1. Shared inputs — apply across every resource in this deployment.
# =====================================================================

variable "environment" {
  type        = string
  description = "Deployment environment label (e.g., prod, nonprod)."
}

variable "location" {
  type        = string
  description = "Default Azure region for resources that do not override it."
  default     = "canadacentral"
}

variable "tags" {
  type        = map(string)
  description = "Baseline tags merged onto every resource."
  default     = {}
}

# --- Monitoring (amba-alz wrapper) --------------------------------------

# Action groups live in the management subscription and already exist, so
# they are referenced by ID rather than created here.
variable "action_group_mail_id" {
  type        = string
  description = "Resource ID of the email action group (backup / service health)."

  validation {
    condition     = can(regex("^/subscriptions/", var.action_group_mail_id))
    error_message = "action_group_mail_id must be a full action group resource ID starting with /subscriptions/, not a placeholder or empty string."
  }
}

variable "action_group_servicenow_id" {
  type        = string
  description = "Resource ID of the ServiceNow action group (governance / security alerts)."

  validation {
    condition     = can(regex("^/subscriptions/", var.action_group_servicenow_id))
    error_message = "action_group_servicenow_id must be a full action group resource ID starting with /subscriptions/, not a placeholder or empty string."
  }
}

# AMBA baseline toggle inside the wrapper. Off by default: this root is
# subscription-scoped, while the AMBA policy rollout needs management-group
# permissions. Turn on only when deploying with MG-scope rights.
variable "enable_amba" {
  type        = bool
  description = "Deploy the AMBA-ALZ baseline via the wrapper. Requires management-group permissions and root_management_group_name."
  default     = false
}

variable "root_management_group_name" {
  type        = string
  description = "ALZ intermediate root management group ID. Required only when enable_amba = true."
  default     = null
}

# =====================================================================
# 2. Feature flags — gate each wrapper on/off for this deployment.
# =====================================================================

variable "enable_resource_group" {
  type    = bool
  default = false
}

variable "enable_key_vault" {
  type    = bool
  default = false
}

variable "enable_user_assigned_identity" {
  type    = bool
  default = false
}

variable "enable_recovery_services_vault" {
  type    = bool
  default = false
}

variable "enable_storage_account" {
  type    = bool
  default = false
}

variable "enable_monitoring" {
  type        = bool
  description = "Deploy monitoring (all alerts, and the AMBA baseline when enable_amba = true) via the amba-alz wrapper."
  default     = false
}

variable "enable_network_watcher" {
  type        = bool
  description = "Adopt the existing Network Watcher into state (via import). Does not create a new one."
  default     = false
}

variable "enable_event_grid_system_topic" {
  type        = bool
  description = "Adopt the existing storage Event Grid system topic into state (via import). Does not create a new one."
  default     = false
}

# =====================================================================
# 3. Per-wrapper config maps, keyed by instance role. *_key fields bind
#    a resource to a resource_group map key.
# =====================================================================

variable "resource_group" {
  type = map(object({
    name     = string
    location = optional(string)
    tags     = optional(map(string), {})
  }))
  description = "Resource groups to deploy, keyed by role (siem, alerts, mid, shared)."
  default     = {}
}

variable "key_vault" {
  type = map(object({
    name                            = string
    resource_group_key              = string
    location                        = optional(string)
    sku_name                        = optional(string, "standard")
    purge_protection_enabled        = optional(bool, true)
    soft_delete_retention_days      = optional(number, 90)
    public_network_access_enabled   = optional(bool, false)
    enabled_for_deployment          = optional(bool, false)
    enabled_for_disk_encryption     = optional(bool, false)
    enabled_for_template_deployment = optional(bool, false)
    legacy_access_policies_enabled  = optional(bool, false)
    legacy_access_policies = optional(map(object({
      object_id               = string
      application_id          = optional(string)
      certificate_permissions = optional(list(string), [])
      key_permissions         = optional(list(string), [])
      secret_permissions      = optional(list(string), [])
      storage_permissions     = optional(list(string), [])
    })), {})
    network_acls = optional(object({
      bypass                     = optional(string, "None")
      default_action             = optional(string, "Deny")
      ip_rules                   = optional(list(string), [])
      virtual_network_subnet_ids = optional(set(string), [])
    }), {})
    tags = optional(map(string), {})
  }))
  description = "Key vaults to deploy, keyed by role. Required when enable_key_vault = true."
  default     = {}
}

variable "user_assigned_identity" {
  type = map(object({
    name               = string
    resource_group_key = string
    location           = optional(string)
    tags               = optional(map(string), {})
  }))
  description = "User-assigned identities to deploy, keyed by role. Required when enable_user_assigned_identity = true."
  default     = {}
}

variable "recovery_services_vault" {
  type = map(object({
    name                                           = string
    resource_group_key                             = string
    location                                       = optional(string)
    sku                                            = optional(string, "Standard")
    storage_mode_type                              = optional(string, "GeoRedundant")
    cross_region_restore_enabled                   = optional(bool, true)
    soft_delete_enabled                            = optional(bool, true)
    immutability                                   = optional(string, "Unlocked")
    public_network_access_enabled                  = optional(bool, true)
    alerts_for_all_job_failures_enabled            = optional(bool, true)
    alerts_for_critical_operation_failures_enabled = optional(bool, true)
    tags                                           = optional(map(string), {})
  }))
  description = "Recovery Services vaults to deploy, keyed by role. Required when enable_recovery_services_vault = true."
  default     = {}
}

variable "storage_account" {
  type = map(object({
    name                              = string
    resource_group_key                = string
    location                          = optional(string)
    account_kind                      = optional(string, "StorageV2")
    account_tier                      = optional(string, "Standard")
    account_replication_type          = optional(string, "LRS")
    access_tier                       = optional(string, "Hot")
    min_tls_version                   = optional(string, "TLS1_2")
    https_traffic_only_enabled        = optional(bool, true)
    shared_access_key_enabled         = optional(bool, false)
    public_network_access_enabled     = optional(bool, false)
    cross_tenant_replication_enabled  = optional(bool, false)
    infrastructure_encryption_enabled = optional(bool, false)
    network_rules = optional(object({
      bypass                     = optional(set(string), ["AzureServices"])
      default_action             = optional(string, "Deny")
      ip_rules                   = optional(set(string), [])
      virtual_network_subnet_ids = optional(set(string), [])
      private_link_access = optional(list(object({
        endpoint_resource_id = string
        endpoint_tenant_id   = optional(string)
      })))
    }), {})
    tags = optional(map(string), {})
  }))
  description = "Storage accounts to deploy, keyed by role. Required when enable_storage_account = true."
  default     = {}
}
