# ── Shared ─────────────────────────────────────────────────────────────
environment = "prod"
location    = "canadacentral"

tags = {
  owner = "identity-platform"
}

# ── Monitoring (amba-alz wrapper) ──────────────────────────────────────
# action_group_mail_id / action_group_servicenow_id are supplied by the
# pipeline as sensitive workspace variables.

# AMBA baseline off: this root is subscription-scoped. Set true (with
# root_management_group_name) only when deploying with MG-scope permissions,
# and drop the backup / service_outage alerts to avoid duplicates.
enable_amba = false
# root_management_group_name = "alz"

# ── Feature flags ──────────────────────────────────────────────────────
enable_resource_group          = true
enable_key_vault               = true
enable_user_assigned_identity  = true
enable_recovery_services_vault = true
enable_storage_account         = true
enable_monitoring              = true

# Adopt existing Azure-managed resources into state via import (no create).
enable_network_watcher         = true
enable_event_grid_system_topic = true

# ── Resource groups ────────────────────────────────────────────────────
resource_group = {
  "siem"   = { name = "rg-siem-identity-canadacentral-001" }
  "alerts" = { name = "rg-alerts-identity-canadacentral-001" }
  "mid"    = { name = "rg-mid-identity-canadacentral-001" }
  "shared" = { name = "rg-shared-identity-canadacentral-001" }
}

# ── Key vaults ─────────────────────────────────────────────────────────
key_vault = {
  # Access-policy vault, private only.
  "fwtls" = {
    name                           = "kvfwtlscanadacentral"
    resource_group_key             = "mid"
    sku_name                       = "premium"
    purge_protection_enabled       = false
    soft_delete_retention_days     = 90
    public_network_access_enabled  = false
    legacy_access_policies_enabled = true
    legacy_access_policies = {
      "policy1" = {
        object_id               = "ec395925-29f4-4aea-8c73-d259eebfae60"
        certificate_permissions = ["Get", "List", "Update", "Create", "Import", "Delete", "Recover", "Backup", "Restore", "ManageContacts", "ManageIssuers", "GetIssuers", "ListIssuers", "SetIssuers", "DeleteIssuers"]
        key_permissions         = ["Get", "List", "Update", "Create", "Import", "Delete", "Recover", "Backup", "Restore", "GetRotationPolicy", "SetRotationPolicy", "Rotate"]
        secret_permissions      = ["Get", "List", "Set", "Delete", "Recover", "Backup", "Restore"]
      }
      "policy2" = {
        object_id               = "39b857c4-f63b-4799-9333-3e41ae1893a5"
        certificate_permissions = ["Get", "List", "Update", "Create", "Import", "Delete", "Recover", "Backup", "Restore", "ManageContacts", "ManageIssuers", "GetIssuers", "ListIssuers", "SetIssuers", "DeleteIssuers"]
        secret_permissions      = ["Get", "List", "Set", "Delete", "Recover", "Backup", "Restore"]
      }
      "policy3" = {
        object_id               = "ccbfdac6-97ec-4bf6-b80c-a299289a969c"
        certificate_permissions = ["Get", "List", "Update", "Create", "Import", "Delete", "Recover", "Backup", "Restore", "ManageContacts", "ManageIssuers", "GetIssuers", "ListIssuers", "SetIssuers", "DeleteIssuers"]
        key_permissions         = ["Get", "List", "Update", "Create", "Import", "Delete", "Recover", "Backup", "Restore", "GetRotationPolicy", "SetRotationPolicy", "Rotate"]
        secret_permissions      = ["Get", "List", "Set", "Delete", "Recover", "Backup", "Restore"]
      }
    }
    network_acls = {
      bypass         = "AzureServices"
      default_action = "Deny"
    }
  }

  # RBAC vault, public with an IP allow-list.
  "idn" = {
    name                            = "kvidncanadacentral"
    resource_group_key              = "siem"
    sku_name                        = "premium"
    purge_protection_enabled        = true
    soft_delete_retention_days      = 7
    public_network_access_enabled   = true
    enabled_for_deployment          = true
    enabled_for_disk_encryption     = true
    enabled_for_template_deployment = true
    network_acls = {
      bypass         = "AzureServices"
      default_action = "Deny"
      ip_rules       = ["155.190.0.0/16"]
    }
  }
}

# ── User-assigned identities ───────────────────────────────────────────
user_assigned_identity = {
  "azfirewall" = { name = "mid-azfirewall-canadacentral-001", resource_group_key = "mid" }
  "dev-autmn"  = { name = "mid-dev-autmn-canadacentral-001", resource_group_key = "mid" }
  "prod-autmn" = { name = "mid-prod-autmn-canadacentral-001", resource_group_key = "mid" }
}

# ── Recovery Services vault ────────────────────────────────────────────
recovery_services_vault = {
  "identity" = {
    name                          = "rsv-identity-canadacentral-001"
    resource_group_key            = "siem"
    sku                           = "Standard"
    storage_mode_type             = "GeoRedundant"
    cross_region_restore_enabled  = true
    soft_delete_enabled           = true
    immutability                  = "Unlocked"
    public_network_access_enabled = true
  }
}

# ── Storage account ────────────────────────────────────────────────────
storage_account = {
  "nwidn" = {
    name                          = "stnwidncanadacentral"
    resource_group_key            = "shared"
    account_kind                  = "StorageV2"
    account_tier                  = "Standard"
    account_replication_type      = "LRS"
    access_tier                   = "Hot"
    shared_access_key_enabled     = false
    public_network_access_enabled = true
    network_rules = {
      bypass         = ["AzureServices"]
      default_action = "Allow"
      # Defender-for-Storage malware scanner endpoint (Azure-managed).
      private_link_access = [{
        endpoint_resource_id = "/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0/providers/Microsoft.Security/datascanners/StorageDataScanner"
        endpoint_tenant_id   = "8fbb85e8-0cbc-48c3-a2e9-528cef30ec27"
      }]
    }
  }
}
