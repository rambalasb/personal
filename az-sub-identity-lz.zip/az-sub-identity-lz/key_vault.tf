# key_vault.tf
# Dependencies: resource_group (resource_group_name picked via resource_group_key).

module "key_vault" {
  for_each = var.enable_key_vault ? var.key_vault : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-key-vault/azurerm"
  version = "0.2.0"

  name                            = each.value.name
  resource_group_name             = module.resource_group[each.value.resource_group_key].name
  location                        = coalesce(each.value.location, module.resource_group[each.value.resource_group_key].location)
  tenant_id                       = data.azurerm_client_config.current.tenant_id
  sku_name                        = each.value.sku_name
  purge_protection_enabled        = each.value.purge_protection_enabled
  soft_delete_retention_days      = each.value.soft_delete_retention_days
  public_network_access_enabled   = each.value.public_network_access_enabled
  enabled_for_deployment          = each.value.enabled_for_deployment
  enabled_for_disk_encryption     = each.value.enabled_for_disk_encryption
  enabled_for_template_deployment = each.value.enabled_for_template_deployment
  legacy_access_policies_enabled  = each.value.legacy_access_policies_enabled
  legacy_access_policies          = each.value.legacy_access_policies
  network_acls                    = each.value.network_acls
  tags                            = merge(local.common_tags, each.value.tags)
}
