output "resource_group_ids" {
  description = "Resource group IDs, keyed by role."
  value       = { for k, m in module.resource_group : k => m.resource_id }
}

output "key_vault_ids" {
  description = "Key vault resource IDs, keyed by role."
  value       = { for k, m in module.key_vault : k => m.resource_id }
}

output "user_assigned_identity_ids" {
  description = "User-assigned identity resource IDs, keyed by role."
  value       = { for k, m in module.user_assigned_identity : k => m.resource_id }
}

output "recovery_services_vault_ids" {
  description = "Recovery Services vault resource IDs, keyed by role."
  value       = { for k, m in module.recovery_services_vault : k => m.resource_id }
}

output "storage_account_ids" {
  description = "Storage account resource IDs, keyed by role."
  value       = { for k, m in module.storage_account : k => m.resource_id }
}
