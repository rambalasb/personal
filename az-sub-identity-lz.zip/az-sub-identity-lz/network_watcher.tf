# network_watcher.tf
# Native + import: the AVM module (avm-res-network-networkwatcher, via
# tf-wrapper-avm-network-watcher) manages only flow logs / connection monitors on
# an existing watcher — it can't create the watcher itself. Import adopts it.

resource "azurerm_network_watcher" "identity" {
  for_each = var.enable_network_watcher ? toset(["identity"]) : toset([])

  name                = "NetworkWatcher_canadacentral_identity"
  resource_group_name = module.resource_group["shared"].name
  location            = var.location
  tags                = local.common_tags
}

import {
  for_each = var.enable_network_watcher ? toset(["identity"]) : toset([])

  to = azurerm_network_watcher.identity[each.key]
  id = "${data.azurerm_subscription.current.id}/resourceGroups/rg-shared-identity-canadacentral-001/providers/Microsoft.Network/networkWatchers/NetworkWatcher_canadacentral_identity"
}
