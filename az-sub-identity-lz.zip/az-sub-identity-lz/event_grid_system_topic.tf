# event_grid_system_topic.tf
# Native + import: the AVM module (avm-res-eventgrid-systemtopic) has no released
# version yet, so no wrapper exists. Switch to it once it ships. Import adopts the
# existing Azure-managed topic instead of creating one.

resource "azurerm_eventgrid_system_topic" "storage" {
  for_each = var.enable_event_grid_system_topic ? toset(["nwidn"]) : toset([])

  name                = "stnwidncanadacentral-bb43e3f7-7be0-4dc3-99e9-10766e4990c0"
  resource_group_name = module.resource_group["shared"].name
  location            = var.location
  source_resource_id  = module.storage_account["nwidn"].resource_id # module output keeps ID casing canonical
  topic_type          = "microsoft.storage.storageaccounts"
  tags                = local.common_tags
}

import {
  for_each = var.enable_event_grid_system_topic ? toset(["nwidn"]) : toset([])

  to = azurerm_eventgrid_system_topic.storage[each.key]
  id = "${data.azurerm_subscription.current.id}/resourceGroups/rg-shared-identity-canadacentral-001/providers/Microsoft.EventGrid/systemTopics/stnwidncanadacentral-bb43e3f7-7be0-4dc3-99e9-10766e4990c0"
}
