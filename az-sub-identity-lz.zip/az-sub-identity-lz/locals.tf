# Deployment order is inferred from module.<producer>[key] references:
#   1. resource_group          (no dependencies)
#   2. key_vault / user_assigned_identity / recovery_services_vault / storage_account
#      (all depend on resource_group)
#   3. monitoring              (consumes the amba-alz wrapper; depends on RSV for the backup scope)
#
# Alert definitions live here because their scopes are computed references
# (RSV resource_id, subscription) that tfvars cannot express.
# They are passed into the amba-alz wrapper in monitoring.tf.

locals {
  common_tags = merge(var.tags, {
    environment = var.environment
    managed-by  = "terraform"
    solution    = "az-sub-identity-lz"
  })

  subscription_scope = data.azurerm_subscription.current.id
  alerts_rg_name     = module.resource_group["alerts"].name

  # Metric alerts -> azurerm_monitor_metric_alert
  metric_alerts = {
    backup = {
      name                     = "Backup Alert"
      resource_group_name      = module.resource_group["siem"].name
      scopes                   = [module.recovery_services_vault["identity"].resource_id]
      description              = ""
      severity                 = 3
      frequency                = "PT15M"
      window_size              = "PT6H"
      auto_mitigate            = true
      target_resource_type     = "Microsoft.RecoveryServices/vaults"
      target_resource_location = var.location
      criteria = [{
        metric_namespace = "Microsoft.RecoveryServices/vaults"
        metric_name      = "BackupHealthEvent"
        aggregation      = "Count"
        operator         = "GreaterThan"
        threshold        = 0
      }]
      action_group_ids = [var.action_group_mail_id]
    }
  }

  # Activity log alerts -> azurerm_monitor_activity_log_alert
  activity_log_alerts = {
    service_outage = {
      name                = "Service-Outage-Alert-canadacentral"
      resource_group_name = local.alerts_rg_name
      scopes              = [local.subscription_scope]
      location            = "global"
      description         = "Azure Landing Zone Service Health Alert"
      criteria = {
        category = "ServiceHealth"
        service_health = {
          events    = []
          locations = ["Global"]
          services  = []
        }
      }
      action_group_ids = [var.action_group_mail_id]
    }

    keyvault_deletion = {
      name                = "KeyVault-Deletion-Alert-canadacentral"
      resource_group_name = local.alerts_rg_name
      scopes              = [local.subscription_scope]
      location            = "global"
      description         = "This alert will monitor any deletion of key vault"
      criteria = {
        category       = "Administrative"
        operation_name = "Microsoft.KeyVault/vaults/delete"
      }
      action_group_ids = [var.action_group_servicenow_id]
    }
  }

  # Log search alerts -> azurerm_monitor_scheduled_query_rules_alert_v2
  log_search_alerts = {
    kv_secret_expired = {
      name                 = "KeyVault-Secret-Expired-Alert-canadacentral"
      resource_group_name  = local.alerts_rg_name
      location             = var.location
      scopes               = [local.subscription_scope]
      severity             = 0
      evaluation_frequency = "PT5M"
      window_duration      = "PT30M"
      description          = "Alert for expired secret in a Key Vault."
      display_name         = "KeyVault-Secret-Expired-Alert-canadacentral"
      criteria = [{
        query                   = "        AzureDiagnostics\n        | where ResourceProvider == \"MICROSOFT.KEYVAULT\"\n        | where OperationName contains \"SecretExpired\"\n        "
        time_aggregation_method = "Count"
        threshold               = 1
        operator                = "GreaterThanOrEqual"
        resource_id_column      = "ResourceId"
        failing_periods = {
          minimum_failing_periods_to_trigger_alert = 1
          number_of_evaluation_periods             = 1
        }
      }]
      action_group_ids = [var.action_group_servicenow_id]
    }

    kv_secret_near_expiry = {
      name                 = "KeyVault-Secret-Near-Expiry-Alert-canadacentral"
      resource_group_name  = local.alerts_rg_name
      location             = var.location
      scopes               = [local.subscription_scope]
      severity             = 1
      evaluation_frequency = "PT5M"
      window_duration      = "PT30M"
      description          = "Alert for secret in a Key Vault is about to expire."
      display_name         = "KeyVault-Secret-Near-Expiry-Alert-canadacentral"
      criteria = [{
        query                   = "        AzureDiagnostics\n        | where ResourceProvider == \"MICROSOFT.KEYVAULT\"\n        | where OperationName contains \"SecretNearExpiry\"\n        "
        time_aggregation_method = "Count"
        threshold               = 1
        operator                = "GreaterThanOrEqual"
        resource_id_column      = "ResourceId"
        failing_periods = {
          minimum_failing_periods_to_trigger_alert = 1
          number_of_evaluation_periods             = 1
        }
      }]
      action_group_ids = [var.action_group_servicenow_id]
    }

    resource_creation = {
      name                 = "Resource-Creation-Alert-canadacentral"
      resource_group_name  = local.alerts_rg_name
      location             = var.location
      scopes               = [local.subscription_scope]
      severity             = 4
      evaluation_frequency = "PT10M"
      window_duration      = "PT30M"
      description          = "Alert when a new resource is created."
      display_name         = "Resource-Creation-Alert-canadacentral"
      criteria = [{
        query                   = "        AzureActivity\n        | where OperationNameValue has \"Microsoft.Resources/deployments/write\"\n        | where CategoryValue == \"Administrative\"\n        | where ActivityStatusValue == \"Success\"\n        "
        time_aggregation_method = "Count"
        threshold               = 10
        operator                = "GreaterThanOrEqual"
        resource_id_column      = "_ResourceId"
        failing_periods = {
          minimum_failing_periods_to_trigger_alert = 1
          number_of_evaluation_periods             = 1
        }
      }]
      action_group_ids = [var.action_group_servicenow_id]
    }

    storage_container_deletion = {
      name                 = "Storage-Account-Container-Deletion-Alert-canadacentral"
      resource_group_name  = local.alerts_rg_name
      location             = var.location
      scopes               = [local.subscription_scope]
      severity             = 0
      evaluation_frequency = "PT5M"
      window_duration      = "PT30M"
      description          = "Alert for the deletion of Storage Account Container."
      display_name         = "Storage-Account-Container-Deletion-Alert-canadacentral"
      criteria = [{
        query                   = "        AzureActivity\n        | where ResourceProviderValue == \"MICROSOFT.STORAGE\" and OperationNameValue == \"MICROSOFT.STORAGE/STORAGEACCOUNTS/BLOBSERVICES/CONTAINERS/DELETE\"\n        "
        time_aggregation_method = "Count"
        threshold               = 1
        operator                = "GreaterThanOrEqual"
        resource_id_column      = "_ResourceId"
        failing_periods = {
          minimum_failing_periods_to_trigger_alert = 1
          number_of_evaluation_periods             = 1
        }
      }]
      action_group_ids = [var.action_group_servicenow_id]
    }

    storage_deletion = {
      name                 = "Storage-Account-Deletion-Alert-canadacentral"
      resource_group_name  = local.alerts_rg_name
      location             = var.location
      scopes               = [local.subscription_scope]
      severity             = 0
      evaluation_frequency = "PT5M"
      window_duration      = "PT30M"
      description          = "Alert for the deletion of Storage Account."
      display_name         = "Storage-Account-Deletion-Alert-canadacentral"
      criteria = [{
        query                   = "        AzureActivity\n        | where ResourceProviderValue == \"MICROSOFT.STORAGE\" and OperationNameValue == \"MICROSOFT.STORAGE/STORAGEACCOUNTS/DELETE\"\n        "
        time_aggregation_method = "Count"
        threshold               = 1
        operator                = "GreaterThanOrEqual"
        resource_id_column      = "_ResourceId"
        failing_periods = {
          minimum_failing_periods_to_trigger_alert = 1
          number_of_evaluation_periods             = 1
        }
      }]
      action_group_ids = [var.action_group_servicenow_id]
    }
  }
}
