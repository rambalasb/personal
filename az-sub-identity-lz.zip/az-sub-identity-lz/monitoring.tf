# monitoring.tf
# Pulls the combined AMBA + alerts wrapper from the registry. Alert definitions
# are built in locals.tf and passed in. AMBA baseline is off unless enable_amba
# is set (needs management-group permissions).

module "monitoring" {
  count = var.enable_monitoring ? 1 : 0

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-monitoring-amba-alz/azurerm"
  version = "0.1.0"

  enable_amba                = var.enable_amba
  location                   = var.location
  root_management_group_name = var.root_management_group_name

  metric_alerts       = local.metric_alerts
  activity_log_alerts = local.activity_log_alerts
  log_search_alerts   = local.log_search_alerts
  tags                = local.common_tags

  depends_on = [module.resource_group, module.recovery_services_vault]
}
