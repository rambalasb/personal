module "ephemeral_credential" {
  source = "../.."

  password = {
    length      = 24
    special     = true
    upper       = true
    lower       = true
    numeric     = true
    min_lower   = 2
    min_upper   = 2
    min_numeric = 2
    min_special = 2
  }

  # Without this the password would only exist during this apply.
  retrievable_secret = {
    key_vault_id = azurerm_key_vault.this.id
    name         = "example-admin-password"
    content_type = "password"
  }

  time_rotating = {
    rotation_days = 90
  }

  tags = { environment = "example" }

  enable_telemetry = false
}
