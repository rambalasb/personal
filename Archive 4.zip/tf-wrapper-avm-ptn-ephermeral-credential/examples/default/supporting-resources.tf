# random suffix to avoid name collisions on reruns
resource "random_string" "suffix" {
  length  = 6
  lower   = true
  upper   = false
  numeric = true
  special = false
}

data "azurerm_client_config" "current" {}

# native supporting RG so the example tests standalone, without a sibling module
resource "azurerm_resource_group" "this" {
  name     = "rg-avm-ephcred-default-test-${random_string.suffix.result}"
  location = "canadacentral"
}

# Access-policy mode rather than RBAC so the example grants itself data-plane
# access without waiting on role assignment propagation.
resource "azurerm_key_vault" "this" {
  name                       = "kv-ephcred-${random_string.suffix.result}"
  resource_group_name        = azurerm_resource_group.this.name
  location                   = azurerm_resource_group.this.location
  tenant_id                  = data.azurerm_client_config.current.tenant_id
  sku_name                   = "standard"
  soft_delete_retention_days = 7
  purge_protection_enabled   = false

  access_policy {
    tenant_id = data.azurerm_client_config.current.tenant_id
    object_id = data.azurerm_client_config.current.object_id

    # Get is needed as well as Set: the module reads the secret back through an
    # ephemeral resource after writing it.
    secret_permissions = ["Get", "List", "Set", "Delete", "Purge", "Recover"]
  }
}
