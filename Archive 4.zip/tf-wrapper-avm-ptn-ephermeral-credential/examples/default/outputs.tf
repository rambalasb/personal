# The credential outputs are ephemeral and cannot be surfaced from a root
# module. Read the secret from Key Vault, or consume the module from another
# module during the same apply.

output "retrievable_secret_id" {
  value = module.ephemeral_credential.retrievable_secret_id
}

output "retrievable_secret_name" {
  value = module.ephemeral_credential.retrievable_secret_name
}

output "value_wo_version" {
  value = module.ephemeral_credential.value_wo_version
}
