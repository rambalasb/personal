# Generates a password or TLS private key that never lands in state. The value
# is only persisted if retrievable_secret points it at a Key Vault, and even
# then it is written through value_wo rather than stored by Terraform.
module "ephemeral_credential" {
  source  = "Azure/avm-ptn-ephemeral-credential/azure"
  version = "0.1.1"

  # Credential type — exactly one of these
  password    = var.password
  private_key = var.private_key

  # Optional Key Vault landing spot
  retrievable_secret = local.retrievable_secret

  # Rotation
  time_rotating = var.time_rotating

  # Module behavior
  enable_telemetry = var.enable_telemetry
}
