locals {
  module_tags = merge(
    var.tags == null ? {} : var.tags,
    {
      managed-by = "terraform"
      module     = "tf-wrapper-avm-ptn-ephermeral-credential"
    }
  )

  # The credential itself is ephemeral, so the Key Vault secret is the only
  # thing that can carry tags.
  retrievable_secret = var.retrievable_secret == null ? null : merge(
    var.retrievable_secret,
    {
      tags = merge(local.module_tags, var.retrievable_secret.tags == null ? {} : var.retrievable_secret.tags)
    }
  )

  generates_password    = var.password != null
  generates_private_key = var.private_key != null
}
