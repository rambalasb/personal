# 1.11 is the floor for the upstream module: it builds on ephemeral resources
# and write-only arguments, and its outputs are ephemeral.
terraform {
  required_version = ">= 1.11, < 2.0"

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.0"
    }
  }
}
