# Ephemeral outputs exist whether or not the matching input was set — Terraform
# does not accept null for an ephemeral value, so upstream falls back to a dummy
# key. Only read the outputs matching the credential type you configured.

output "password_result" {
  description = "The generated password, or the Key Vault value when retrievable_secret is set. Only valid when password is set. Available during apply only."
  value       = module.ephemeral_credential.password_result
  ephemeral   = true
}

output "private_key_algorithm" {
  description = "Algorithm of the generated private key. Only valid when private_key is set."
  value       = module.ephemeral_credential.private_key_algorithm
  ephemeral   = true
}

output "public_key_openssh" {
  description = "Public key in OpenSSH authorized_keys format, with a trailing newline. Not populated for ECDSA P224. Only valid when private_key is set."
  value       = module.ephemeral_credential.public_key_openssh
  ephemeral   = true
}

output "public_key_pem" {
  description = "Public key in PEM format, with a trailing newline. Only valid when private_key is set."
  value       = module.ephemeral_credential.public_key_pem
  ephemeral   = true
}

output "public_key_fingerprint_md5" {
  description = "MD5 fingerprint of the public key. Only valid when private_key is set."
  value       = module.ephemeral_credential.public_key_fingerprint_md5
  ephemeral   = true
}

output "public_key_fingerprint_sha256" {
  description = "SHA256 fingerprint of the public key. Only valid when private_key is set."
  value       = module.ephemeral_credential.public_key_fingerprint_sha256
  ephemeral   = true
}

output "retrievable_secret_id" {
  description = "Resource ID of the Key Vault secret holding the credential, or null when retrievable_secret is unset."
  value       = module.ephemeral_credential.retrievable_secret_id
}

output "retrievable_secret_name" {
  description = "Name of the Key Vault secret holding the credential, or null when retrievable_secret is unset."
  value       = module.ephemeral_credential.retrievable_secret_name
}

output "value_wo_version" {
  description = "Unix timestamp that changes on each rotation. Pass this as the value_wo_version of any write-only argument the credential feeds, so the consuming resource picks up the new value."
  value       = module.ephemeral_credential.value_wo_version
}
