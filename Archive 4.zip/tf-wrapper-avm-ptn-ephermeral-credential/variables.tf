# =====================================================================
# Credential type — set exactly one of password or private_key
# =====================================================================

variable "password" {
  type = object({
    length           = number
    lower            = optional(bool)
    min_lower        = optional(number)
    min_numeric      = optional(number)
    min_special      = optional(number)
    min_upper        = optional(number)
    numeric          = optional(bool)
    override_special = optional(string)
    special          = optional(bool)
    upper            = optional(bool)
  })
  description = "Generate a random password. length is the total character count; the min_* attributes set floors per character class and must sum to no more than length. override_special replaces the default special set '!@#$%&*()-_=+[]{}<>:?'. Mutually exclusive with private_key."
  default     = null

  validation {
    condition     = var.password == null || var.password.length >= 12
    error_message = "password.length must be at least 12. Shorter generated passwords fail Azure's complexity rules on several resource types."
  }

  validation {
    condition     = var.password == null || var.password.length <= 128
    error_message = "password.length must be 128 or less."
  }

  # random_password fails at apply if the class minimums cannot fit in length.
  # coalesce rather than try: the attributes exist and are null when unset.
  validation {
    condition = var.password == null || (
      coalesce(var.password.min_lower, 0) +
      coalesce(var.password.min_upper, 0) +
      coalesce(var.password.min_numeric, 0) +
      coalesce(var.password.min_special, 0)
    ) <= var.password.length
    error_message = "password min_lower + min_upper + min_numeric + min_special must not exceed password.length."
  }

  validation {
    condition     = var.password == null || var.private_key == null
    error_message = "Set either password or private_key, not both. The upstream module generates one credential per module instance."
  }
}

variable "private_key" {
  type = object({
    algorithm   = string
    ecdsa_curve = optional(string)
    rsa_bits    = optional(number)
  })
  description = "Generate a TLS private key. algorithm is 'RSA', 'ECDSA' or 'ED25519'. ecdsa_curve applies to ECDSA only ('P224', 'P256', 'P384', 'P521'); rsa_bits applies to RSA only. Mutually exclusive with password."
  default     = null

  validation {
    condition     = var.private_key == null || contains(["RSA", "ECDSA", "ED25519"], var.private_key.algorithm)
    error_message = "private_key.algorithm must be 'RSA', 'ECDSA' or 'ED25519'."
  }

  validation {
    condition     = var.private_key == null || var.private_key.ecdsa_curve == null || contains(["P224", "P256", "P384", "P521"], var.private_key.ecdsa_curve)
    error_message = "private_key.ecdsa_curve must be 'P224', 'P256', 'P384' or 'P521'."
  }

  validation {
    condition     = var.private_key == null || coalesce(var.private_key.rsa_bits, 2048) >= 2048
    error_message = "private_key.rsa_bits must be at least 2048."
  }

  # Only the matching algorithm's tuning attribute is read; the other is a
  # silent no-op that usually means the wrong algorithm was selected.
  validation {
    condition     = var.private_key == null || var.private_key.rsa_bits == null || var.private_key.algorithm == "RSA"
    error_message = "private_key.rsa_bits is only read when algorithm is 'RSA'."
  }

  validation {
    condition     = var.private_key == null || var.private_key.ecdsa_curve == null || var.private_key.algorithm == "ECDSA"
    error_message = "private_key.ecdsa_curve is only read when algorithm is 'ECDSA'."
  }
}

# =====================================================================
# Optional Key Vault landing spot
# =====================================================================

variable "retrievable_secret" {
  type = object({
    content_type    = optional(string)
    expiration_date = optional(string)
    key_vault_id    = string
    name            = string
    not_before_date = optional(string)
    tags            = optional(map(string))
    timeouts = optional(object({
      create = optional(string)
      delete = optional(string)
      read   = optional(string)
      update = optional(string)
    }))
  })
  description = "Write the generated credential to a Key Vault secret so it can be read back later. Leave null to keep the credential purely ephemeral — it is then only available during the apply that produced it. expiration_date and not_before_date are UTC RFC3339 ('YYYY-MM-DDTHH:MM:SSZ')."
  default     = null

  validation {
    condition     = var.retrievable_secret == null || can(regex("^[a-zA-Z0-9-]{1,127}$", var.retrievable_secret.name))
    error_message = "retrievable_secret.name must be 1-127 characters of alphanumerics and hyphens."
  }

  validation {
    condition     = var.retrievable_secret == null || can(regex("(?i)/providers/Microsoft.KeyVault/vaults/", var.retrievable_secret.key_vault_id))
    error_message = "retrievable_secret.key_vault_id must be a full Key Vault resource ID."
  }

  validation {
    condition     = var.retrievable_secret == null || var.retrievable_secret.expiration_date == null || can(regex("^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z$", var.retrievable_secret.expiration_date))
    error_message = "retrievable_secret.expiration_date must be UTC RFC3339, for example '2027-01-01T00:00:00Z'."
  }

  validation {
    condition     = var.retrievable_secret == null || var.retrievable_secret.not_before_date == null || can(regex("^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z$", var.retrievable_secret.not_before_date))
    error_message = "retrievable_secret.not_before_date must be UTC RFC3339, for example '2027-01-01T00:00:00Z'."
  }

  validation {
    condition     = var.retrievable_secret == null || var.password != null || var.private_key != null
    error_message = "retrievable_secret needs a credential to store. Set password or private_key."
  }
}

# =====================================================================
# Rotation
# =====================================================================

variable "time_rotating" {
  type = object({
    rfc3339          = optional(string)
    rotation_days    = optional(number)
    rotation_hours   = optional(number)
    rotation_minutes = optional(number)
    rotation_months  = optional(number)
    rotation_rfc3339 = optional(string)
    rotation_years   = optional(number)
    triggers         = optional(map(string), {})
  })
  description = "Rotation schedule. Once the rotation timestamp passes, the next apply regenerates the credential and writes a new secret version. rfc3339 is the base timestamp and defaults to the time of first apply. Changes to password or private_key already force regeneration regardless of this setting."
  default     = null

  # time_rotating with no offset never rotates.
  validation {
    condition = var.time_rotating == null || anytrue([
      var.time_rotating.rotation_days != null,
      var.time_rotating.rotation_hours != null,
      var.time_rotating.rotation_minutes != null,
      var.time_rotating.rotation_months != null,
      var.time_rotating.rotation_years != null,
      var.time_rotating.rotation_rfc3339 != null,
    ])
    error_message = "time_rotating must set at least one of rotation_days, rotation_hours, rotation_minutes, rotation_months, rotation_years or rotation_rfc3339."
  }

  validation {
    condition     = var.time_rotating == null || var.time_rotating.rfc3339 == null || can(regex("^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z$", var.time_rotating.rfc3339))
    error_message = "time_rotating.rfc3339 must be UTC RFC3339, for example '2026-01-01T00:00:00Z'."
  }

  validation {
    condition     = var.time_rotating == null || var.time_rotating.rotation_rfc3339 == null || can(regex("^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z$", var.time_rotating.rotation_rfc3339))
    error_message = "time_rotating.rotation_rfc3339 must be UTC RFC3339, for example '2027-01-01T00:00:00Z'."
  }

  validation {
    condition     = var.time_rotating == null || var.password != null || var.private_key != null
    error_message = "time_rotating has nothing to rotate. Set password or private_key."
  }

  # Rotating a stored private key would leave the Key Vault copy and the
  # generated key out of step, so upstream only supports it for passwords.
  validation {
    condition     = var.time_rotating == null || var.retrievable_secret == null || var.password != null
    error_message = "time_rotating cannot be combined with retrievable_secret for private keys. It is supported for passwords only."
  }
}

# =====================================================================
# Module behavior
# =====================================================================

variable "enable_telemetry" {
  type        = bool
  description = "Whether to enable AVM module telemetry. Set false to opt out."
  default     = true
  nullable    = false
}

variable "tags" {
  type        = map(string)
  description = "A map of tags to apply to the Key Vault secret. Ignored when retrievable_secret is null, because an ephemeral credential is not a resource and cannot be tagged."
  default     = null
}
