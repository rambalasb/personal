check "credential_type_declared" {
  assert {
    condition     = local.generates_password || local.generates_private_key
    error_message = "Neither password nor private_key is set. The module still emits a 10-character default password, which is almost certainly not what was intended."
  }
}

check "rotation_declared" {
  assert {
    condition     = var.time_rotating != null || local.generates_private_key
    error_message = "No time_rotating schedule is set, so the credential is generated once and never rotates on its own. Regeneration then only happens when password or private_key changes."
  }
}

check "stored_secret_expires" {
  assert {
    condition     = var.retrievable_secret == null || var.time_rotating != null || var.retrievable_secret.expiration_date != null
    error_message = "retrievable_secret is set with neither expiration_date nor time_rotating, so the Key Vault secret never expires and never rotates."
  }
}

# Upstream derives expiration_date from the rotation timestamp when the secret
# does not set one, which keeps Key Vault expiry and rotation aligned.
check "expiry_not_pinned_against_rotation" {
  assert {
    condition     = var.retrievable_secret == null || var.time_rotating == null || var.retrievable_secret.expiration_date == null
    error_message = "retrievable_secret.expiration_date overrides the expiry derived from time_rotating. The secret can then expire on a different schedule than the rotation."
  }
}

check "password_uses_all_character_classes" {
  assert {
    condition = !local.generates_password || alltrue([
      coalesce(var.password.special, true),
      coalesce(var.password.upper, true),
      coalesce(var.password.lower, true),
      coalesce(var.password.numeric, true),
    ])
    error_message = "One or more password character classes are disabled. Azure rejects admin passwords that do not draw on at least three of upper, lower, numeric and special."
  }
}

check "ecdsa_curve_supports_public_key_outputs" {
  assert {
    condition     = !local.generates_private_key || var.private_key.ecdsa_curve != "P224"
    error_message = "ECDSA curve P224 is set. The public_key_openssh and fingerprint outputs are not populated for this curve."
  }
}

check "ephemeral_credential_is_reachable" {
  assert {
    condition     = var.retrievable_secret != null || var.time_rotating == null
    error_message = "time_rotating is set without retrievable_secret. The rotated credential exists only during the apply that generates it, so every consumer must read it from this module in the same run."
  }
}
