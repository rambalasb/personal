locals {
  module_tags = merge(
    var.tags == null ? {} : var.tags,
    {
      managed-by = "terraform"
      module     = "tf-wrapper-avm-ptn-azuremonitorwindowsagent"
    }
  )

  # The extension itself is an azapi resource and takes no tags; only the three
  # data collection resources can carry them.
  workspace_tags                = merge(local.module_tags, var.workspace_tags)
  data_collection_endpoint_tags = merge(local.module_tags, var.data_collection_endpoint_tags)
  data_collection_rule_tags     = merge(local.module_tags, var.data_collection_rule_tags)

  # Placeholder carried by the upstream module's default. It is used as a data
  # flow destination name, not an ID.
  upstream_default_destination_id = "2-90d1-e814dab6067e"
}
