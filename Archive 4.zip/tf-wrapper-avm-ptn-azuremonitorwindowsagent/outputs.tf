output "resource_id" {
  description = "The Azure resource ID of the Azure Monitor Windows Agent extension."
  value       = module.azure_monitor_windows_agent.resource_id
}

output "name" {
  description = "The name of the agent extension resource."
  value       = var.name
}
