# This example cannot be fully self-contained: the agent extension attaches to
# an Azure Local (Azure Stack HCI) cluster, which is registered from on-premises
# hardware and cannot be created by Terraform. Point the locals below at a
# cluster that is already registered and Arc-connected, then apply.
locals {
  cluster_resource_group_name = "rg-azure-local-cluster"
  cluster_name                = "azure-local-cluster"

  # Arc-enabled servers that make up the cluster, by machine name.
  cluster_node_names = ["node01", "node02"]
}

# random suffix to avoid name collisions on reruns
resource "random_string" "suffix" {
  length  = 6
  lower   = true
  upper   = false
  numeric = true
  special = false
}

data "azurerm_resource_group" "cluster" {
  name = local.cluster_resource_group_name
}

data "azapi_resource" "cluster" {
  type      = "Microsoft.AzureStackHCI/clusters@2024-04-01"
  name      = local.cluster_name
  parent_id = data.azurerm_resource_group.cluster.id
}

# 'default' is the Arc setting every registered cluster gets.
data "azapi_resource" "arc_setting" {
  type      = "Microsoft.AzureStackHCI/clusters/arcSettings@2024-04-01"
  name      = "default"
  parent_id = data.azapi_resource.cluster.id
}

# The nodes are Arc machines in the same resource group as the cluster.
data "azurerm_arc_machine" "nodes" {
  for_each = toset(local.cluster_node_names)

  name                = each.value
  resource_group_name = data.azurerm_resource_group.cluster.name
}
