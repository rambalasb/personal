module "azure_monitor_windows_agent" {
  source = "../.."

  arc_setting_id      = data.azapi_resource.arc_setting.id
  arc_server_ids      = { for name, node in data.azurerm_arc_machine.nodes : name => node.id }
  resource_group_name = data.azurerm_resource_group.cluster.name

  # Workspace, endpoint and rule are all created here rather than referenced.
  create_data_collection_resources   = true
  data_collection_resources_location = data.azurerm_resource_group.cluster.location
  workspace_name                     = "law-amwa-example-${random_string.suffix.result}"
  data_collection_endpoint_name      = "dce-amwa-example-${random_string.suffix.result}"
  data_collection_rule_name          = "dcr-amwa-example-${random_string.suffix.result}"

  # Must differ from workspace_name: both become destination names in the rule.
  data_collection_rule_destination_id = "events-amwa-example-${random_string.suffix.result}"

  retention_in_days = 30

  tags = { environment = "example" }

  enable_telemetry = false
}
