output "resource_id" {
  value = module.azure_monitor_windows_agent.resource_id
}

output "name" {
  value = module.azure_monitor_windows_agent.name
}
