# =====================================================================
# Required inputs
# =====================================================================

variable "arc_setting_id" {
  type        = string
  description = "Resource ID of the Azure Local (Azure Stack HCI) cluster's Arc setting, normally the one named 'default'. The agent extension is created as a child of this resource."

  validation {
    condition     = can(regex("(?i)/providers/Microsoft.AzureStackHCI/clusters/[^/]+/arcSettings/[^/]+$", var.arc_setting_id))
    error_message = "arc_setting_id must be a Microsoft.AzureStackHCI/clusters/arcSettings resource ID."
  }
}

variable "arc_server_ids" {
  type        = map(string)
  description = "Arc-enabled servers to associate with the data collection rule. Key is the server name, value is its Microsoft.HybridCompute/machines resource ID. One association is created per entry."
  nullable    = false

  validation {
    condition     = alltrue([for id in values(var.arc_server_ids) : can(regex("(?i)/providers/Microsoft.HybridCompute/machines/[^/]+$", id))])
    error_message = "Every arc_server_ids value must be a Microsoft.HybridCompute/machines resource ID."
  }
}

variable "resource_group_name" {
  type        = string
  description = "Resource group holding the data collection resources. When create_data_collection_resources is false this is still read, so it must name a real group."

  validation {
    condition     = length(var.resource_group_name) > 0 && length(var.resource_group_name) <= 90
    error_message = "resource_group_name must be 1-90 characters."
  }
}

# =====================================================================
# Extension
# =====================================================================

variable "name" {
  type        = string
  description = "Name of the extension resource on the Arc setting. The extension type sent to Azure is always 'AzureMonitorWindowsAgent' regardless of this name."
  default     = "AzureMonitorWindowsAgent"

  validation {
    condition     = can(regex("^[a-zA-Z0-9._-]{1,64}$", var.name))
    error_message = "name must be 1-64 characters of alphanumerics, dots, underscores and hyphens."
  }
}

# =====================================================================
# Data collection — create here, or point at existing resources
# =====================================================================

variable "create_data_collection_resources" {
  type        = bool
  description = "Whether to create the Log Analytics workspace, data collection endpoint and data collection rule. Set false to associate the servers with a rule that already exists."
  default     = false
  nullable    = false
}

variable "data_collection_rule_resource_id" {
  type        = string
  description = "Resource ID of an existing data collection rule. Required when create_data_collection_resources is false; ignored otherwise."
  default     = null

  validation {
    condition     = var.data_collection_rule_resource_id == null || can(regex("(?i)/providers/Microsoft.Insights/dataCollectionRules/[^/]+$", coalesce(var.data_collection_rule_resource_id, "x")))
    error_message = "data_collection_rule_resource_id must be a Microsoft.Insights/dataCollectionRules resource ID."
  }

  validation {
    condition     = var.create_data_collection_resources || var.data_collection_rule_resource_id != null
    error_message = "data_collection_rule_resource_id is required when create_data_collection_resources is false."
  }
}

variable "data_collection_resources_location" {
  type        = string
  description = "Azure region for the workspace, endpoint and rule. Required when create_data_collection_resources is true."
  default     = ""
  nullable    = false

  validation {
    condition     = !var.create_data_collection_resources || length(var.data_collection_resources_location) > 0
    error_message = "data_collection_resources_location is required when create_data_collection_resources is true."
  }
}

variable "data_collection_endpoint_name" {
  type        = string
  description = "Name of the data collection endpoint to create. Required when create_data_collection_resources is true."
  default     = null

  validation {
    condition     = !var.create_data_collection_resources || var.data_collection_endpoint_name != null
    error_message = "data_collection_endpoint_name is required when create_data_collection_resources is true."
  }
}

variable "data_collection_rule_name" {
  type        = string
  description = "Name of the data collection rule to create. Required when create_data_collection_resources is true."
  default     = null

  validation {
    condition     = !var.create_data_collection_resources || var.data_collection_rule_name != null
    error_message = "data_collection_rule_name is required when create_data_collection_resources is true."
  }
}

variable "data_collection_rule_destination_id" {
  type        = string
  description = "Name given to the second Log Analytics destination inside the created rule — the one the Microsoft-Event data flow targets. Despite the name this is a label, not a resource ID, and it must differ from workspace_name."
  default     = "2-90d1-e814dab6067e"
  nullable    = false

  validation {
    condition     = length(var.data_collection_rule_destination_id) > 0
    error_message = "data_collection_rule_destination_id must not be empty."
  }
}

variable "data_collection_rule_association_name" {
  type        = string
  description = "Name for every data collection rule association. Leave empty to let the module derive a stable per-server name from the server and rule IDs, which is what you want for more than one server."
  default     = ""
  nullable    = false
}

variable "counter_specifiers" {
  type        = list(string)
  description = "Windows performance counters collected by the created rule, in '\\Object(Instance)\\Counter' form. Only read when create_data_collection_resources is true."
  default = [
    "\\Memory\\Available Bytes",
    "\\Network Interface(*)\\Bytes Total/sec",
    "\\Processor(_Total)\\% Processor Time",
    "\\RDMA Activity(*)\\RDMA Inbound Bytes/sec",
    "\\RDMA Activity(*)\\RDMA Outbound Bytes/sec"
  ]
  nullable = false
}

variable "x_path_queries" {
  type        = list(string)
  description = "Windows event log XPath queries collected by the created rule. Only read when create_data_collection_resources is true."
  default = [
    "Microsoft-Windows-SDDC-Management/Operational!*[System[(EventID=3000 or EventID=3001 or EventID=3002 or EventID=3003 or EventID=3004)]]",
    "microsoft-windows-health/operational!*"
  ]
  nullable = false
}

# =====================================================================
# Log Analytics workspace
# =====================================================================

variable "workspace_name" {
  type        = string
  description = "Name of the Log Analytics workspace to create. Required when create_data_collection_resources is true. Also used as the name of the rule's first destination."
  default     = null

  validation {
    condition     = !var.create_data_collection_resources || var.workspace_name != null
    error_message = "workspace_name is required when create_data_collection_resources is true."
  }

  validation {
    condition     = var.workspace_name == null || can(regex("^[a-zA-Z0-9][a-zA-Z0-9-]{2,61}[a-zA-Z0-9]$", coalesce(var.workspace_name, "xxxx")))
    error_message = "workspace_name must be 4-63 characters of alphanumerics and hyphens, and must not start or end with a hyphen."
  }
}

variable "sku" {
  type        = string
  description = "Workspace pricing SKU. 'PerGB2018' is the current default for new workspaces."
  default     = "PerGB2018"

  validation {
    condition     = contains(["Free", "PerNode", "Premium", "Standard", "Standalone", "Unlimited", "CapacityReservation", "PerGB2018", "LACluster"], var.sku)
    error_message = "sku must be one of: Free, PerNode, Premium, Standard, Standalone, Unlimited, CapacityReservation, PerGB2018, LACluster."
  }
}

variable "retention_in_days" {
  type        = number
  description = "Workspace data retention. 7 is only accepted on the Free tier; otherwise 30 through 730."
  default     = 30

  validation {
    condition     = var.retention_in_days == 7 || (var.retention_in_days >= 30 && var.retention_in_days <= 730)
    error_message = "retention_in_days must be 7 (Free tier only) or between 30 and 730."
  }
}

variable "cmk_for_query_forced" {
  type        = bool
  description = "Whether query results must be stored with a customer-managed key. Requires a workspace linked to a Log Analytics cluster."
  default     = false
}

variable "immediate_data_purge_on_30_days_enabled" {
  type        = bool
  description = "Whether ingested data is purged immediately at 30 days. Azure only accepts this when retention_in_days is 30."
  default     = false

  validation {
    condition     = !var.immediate_data_purge_on_30_days_enabled || var.retention_in_days == 30
    error_message = "immediate_data_purge_on_30_days_enabled requires retention_in_days to be 30."
  }
}

# =====================================================================
# Governance
# =====================================================================

variable "role_assignments" {
  type = map(object({
    role_definition_id_or_name             = string
    principal_id                           = string
    description                            = optional(string, null)
    skip_service_principal_aad_check       = optional(bool, false)
    condition                              = optional(string, null)
    condition_version                      = optional(string, null)
    delegated_managed_identity_resource_id = optional(string, null)
    principal_type                         = optional(string, null)
  }))
  description = "RBAC role assignments scoped to the agent extension resource. Common roles: 'Azure Connected Machine Resource Administrator', 'Monitoring Contributor', 'Reader'."
  default     = {}
  nullable    = false
}

variable "lock" {
  type = object({
    kind = string
    name = optional(string, null)
  })
  description = "Optional resource lock on the agent extension. kind must be 'CanNotDelete' or 'ReadOnly'."
  default     = null

  validation {
    condition     = var.lock == null || contains(["CanNotDelete", "ReadOnly"], try(var.lock.kind, ""))
    error_message = "lock.kind must be 'CanNotDelete' or 'ReadOnly' when lock is set."
  }
}

# =====================================================================
# Tags
# =====================================================================

variable "tags" {
  type        = map(string)
  description = "A map of tags applied to every data collection resource this module creates. The agent extension itself cannot be tagged."
  default     = null
}

variable "workspace_tags" {
  type        = map(string)
  description = "Extra tags for the Log Analytics workspace, merged over tags."
  default     = {}
  nullable    = false
}

variable "data_collection_endpoint_tags" {
  type        = map(string)
  description = "Extra tags for the data collection endpoint, merged over tags."
  default     = {}
  nullable    = false
}

variable "data_collection_rule_tags" {
  type        = map(string)
  description = "Extra tags for the data collection rule, merged over tags."
  default     = {}
  nullable    = false
}

# =====================================================================
# Module behavior
# =====================================================================

variable "enable_telemetry" {
  type        = bool
  description = "Whether to enable AVM module telemetry. Set false to opt out."
  default     = true
  nullable    = false
}
