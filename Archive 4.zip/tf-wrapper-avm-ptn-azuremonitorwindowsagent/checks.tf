check "servers_are_associated" {
  assert {
    condition     = length(var.arc_server_ids) > 0
    error_message = "arc_server_ids is empty. The agent extension is installed on the cluster but no server is associated with a data collection rule, so nothing is ingested."
  }
}

check "destination_name_is_explicit" {
  assert {
    condition     = !var.create_data_collection_resources || var.data_collection_rule_destination_id != local.upstream_default_destination_id
    error_message = "data_collection_rule_destination_id is still the upstream placeholder '${local.upstream_default_destination_id}'. It names the rule's event destination and is worth setting to something readable."
  }
}

# The module writes both destinations into one destinations block; duplicate
# names are rejected by the data collection rule API.
check "destination_names_are_distinct" {
  assert {
    condition     = !var.create_data_collection_resources || var.data_collection_rule_destination_id != var.workspace_name
    error_message = "data_collection_rule_destination_id matches workspace_name. A data collection rule cannot declare two destinations with the same name."
  }
}

check "single_association_name_is_unambiguous" {
  assert {
    condition     = var.data_collection_rule_association_name == "" || length(var.arc_server_ids) <= 1
    error_message = "data_collection_rule_association_name is set with more than one server in arc_server_ids. Every association would be given the same name. Leave it empty so the module derives a distinct name per server."
  }
}

check "created_rule_collects_something" {
  assert {
    condition     = !var.create_data_collection_resources || length(var.counter_specifiers) > 0 || length(var.x_path_queries) > 0
    error_message = "create_data_collection_resources is true but both counter_specifiers and x_path_queries are empty, so the rule collects nothing."
  }
}

check "free_tier_retention" {
  assert {
    condition     = var.retention_in_days != 7 || var.sku == "Free"
    error_message = "retention_in_days is 7, which Azure only accepts on the Free SKU. The current sku is '${var.sku}'."
  }
}

check "extension_name_matches_type" {
  assert {
    condition     = var.name == "AzureMonitorWindowsAgent"
    error_message = "name is '${var.name}' but the extension type sent to Azure is always 'AzureMonitorWindowsAgent'. A different name makes the resource harder to match against the agent Azure reports on the cluster."
  }
}
