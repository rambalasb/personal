# Installs the Azure Monitor Windows Agent extension on an Azure Local
# (Azure Stack HCI) cluster's Arc setting, and associates each Arc-enabled
# server in the cluster with a data collection rule.
module "azure_monitor_windows_agent" {
  source  = "Azure/avm-ptn-azuremonitorwindowsagent/azurerm"
  version = "2.0.0"

  # Required
  arc_setting_id      = var.arc_setting_id
  arc_server_ids      = var.arc_server_ids
  resource_group_name = var.resource_group_name

  # Extension
  name = var.name

  # Data collection — either created here or referenced by ID
  create_data_collection_resources                      = var.create_data_collection_resources
  data_collection_resources_location                    = var.data_collection_resources_location
  data_collection_endpoint_name                         = var.data_collection_endpoint_name
  data_collection_rule_name                             = var.data_collection_rule_name
  data_collection_rule_resource_id                      = var.data_collection_rule_resource_id
  data_collection_rule_destination_id                   = var.data_collection_rule_destination_id
  azurerm_monitor_data_collection_rule_association_name = var.data_collection_rule_association_name

  # What the rule collects
  counter_specifiers = var.counter_specifiers
  x_path_queries     = var.x_path_queries

  # Workspace, only created when create_data_collection_resources is true
  workspace_name                          = var.workspace_name
  sku                                     = var.sku
  retention_in_days                       = var.retention_in_days
  cmk_for_query_forced                    = var.cmk_for_query_forced
  immediate_data_purge_on_30_days_enabled = var.immediate_data_purge_on_30_days_enabled

  # Governance
  role_assignments = var.role_assignments
  lock             = var.lock

  # Tags
  workspace_tags                = local.workspace_tags
  data_collection_endpoint_tags = local.data_collection_endpoint_tags
  data_collection_rule_tags     = local.data_collection_rule_tags

  # Module behavior
  enable_telemetry = var.enable_telemetry
}
