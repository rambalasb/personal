# imports.tf
# Adoption of the live DMZ subscription, inventory 2026-11-23
# (scripts/export_full_inventory.sh). 16 import blocks.
#
# Addresses were read from the AVM module versions the wrappers pin
# (resource-group 0.4.0, key-vault 0.11.0, virtual-network 0.17.1,
# storage-account 0.10.0, network-watcher 0.3.2). If the first plan says an
# address does not exist, the registry wrapper pins a different AVM version
# from the local tf-wrapper-avm-* folder; fix the address, not the config.
#
# Delete these blocks once the import apply has run and a re-plan is empty.

# ── Resource groups (azapi) ──────────────────────────────────────────────────
import {
  to = module.resource_group["shared"].module.resource_group.azapi_resource.this
  id = "${local.sub}/resourceGroups/rg-dmz-shared-canadacentral-001"
}
import {
  to = module.resource_group["nonprod"].module.resource_group.azapi_resource.this
  id = "${local.sub}/resourceGroups/rg-dmz-nonprod-canadacentral-001"
}
import {
  to = module.resource_group["prod"].module.resource_group.azapi_resource.this
  id = "${local.sub}/resourceGroups/rg-dmz-prod-canadacentral-001"
}
import {
  to = module.resource_group["network_watcher"].module.resource_group.azapi_resource.this
  id = "${local.sub}/resourceGroups/NetworkWatcherRG"
}

# ── Virtual network (azapi), subnets, diagnostics (azurerm) ──────────────────
import {
  to = module.virtual_network.module.virtual_network.azapi_resource.vnet
  id = "${local.sub}/resourceGroups/rg-dmz-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dmz-nonprod-canadacentral-001?api-version=2024-07-01"
}
import {
  to = module.virtual_network.module.virtual_network.module.subnet["snet-dmz-nonprod-agw-canadacentral-001"].azapi_resource.subnet[0]
  id = "${local.sub}/resourceGroups/rg-dmz-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dmz-nonprod-canadacentral-001/subnets/snet-dmz-nonprod-agw-canadacentral-001?api-version=2024-07-01"
}
import {
  to = module.virtual_network.module.virtual_network.module.subnet["snet-dmz-nonprod-pep-canadacentral-001"].azapi_resource.subnet[0]
  id = "${local.sub}/resourceGroups/rg-dmz-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dmz-nonprod-canadacentral-001/subnets/snet-dmz-nonprod-pep-canadacentral-001?api-version=2024-07-01"
}
import {
  to = module.virtual_network.module.virtual_network.azurerm_monitor_diagnostic_setting.this["logs"]
  id = "${local.sub}/resourceGroups/rg-dmz-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dmz-nonprod-canadacentral-001|sendLogsToLA"
}
import {
  to = module.virtual_network.module.virtual_network.azurerm_monitor_diagnostic_setting.this["metrics"]
  id = "${local.sub}/resourceGroups/rg-dmz-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dmz-nonprod-canadacentral-001|sendMetricsToLA"
}

# ── Key Vault, its private endpoint (DNS zone group inline), diagnostics ─────
import {
  to = module.key_vault.module.key_vault.azurerm_key_vault.this
  id = "${local.sub}/resourceGroups/rg-dmz-shared-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvdmzcac001"
}
import {
  to = module.key_vault.module.key_vault.azurerm_private_endpoint.this["vault"]
  id = "${local.sub}/resourceGroups/rg-dmz-nonprod-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-kvdmzcac001"
}
import {
  to = module.key_vault.module.key_vault.azurerm_monitor_diagnostic_setting.this["logs"]
  id = "${local.sub}/resourceGroups/rg-dmz-shared-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvdmzcac001|sendLogstoLA"
}

# ── Network Watcher (native), flow-log storage (azapi), flow log (azapi) ─────
import {
  to = azurerm_network_watcher.this
  id = "${local.sub}/resourceGroups/NetworkWatcherRG/providers/Microsoft.Network/networkWatchers/NetworkWatcher_canadacentral"
}
import {
  to = module.flow_log_storage.module.storage_account.azapi_resource.this
  id = "${local.sub}/resourceGroups/NetworkWatcherRG/providers/Microsoft.Storage/storageAccounts/stnwdmzcanadacentral001?api-version=2025-08-01"
}
import {
  to = module.flow_log_storage.module.storage_account.module.diagnostic_setting_storage_account.azapi_resource.this["metrics"]
  id = "${local.sub}/resourceGroups/NetworkWatcherRG/providers/Microsoft.Storage/storageAccounts/stnwdmzcanadacentral001/providers/Microsoft.Insights/diagnosticSettings/sendLogstoLA?api-version=2021-05-01-preview"
}
import {
  to = module.network_watcher.module.network_watcher.azapi_resource.flow_logs["vnet-dmz-nonprod-canadacentral-001-rg-dmz-nonprod-canada-flowlog"]
  id = "${local.sub}/resourceGroups/NetworkWatcherRG/providers/Microsoft.Network/networkWatchers/NetworkWatcher_canadacentral/flowLogs/vnet-dmz-nonprod-canadacentral-001-rg-dmz-nonprod-canada-flowlog?api-version=2023-11-01"
}
