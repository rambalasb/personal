locals {
  sub = data.azurerm_subscription.current.id

  # managed-by and solution are added; the gate allows tag additions. The policy
  # tags come from var.tags so they are sent unchanged.
  common_tags = merge(var.tags, {
    managed-by = "terraform"
    solution   = "tf-deploy-dmz"
  })
}
