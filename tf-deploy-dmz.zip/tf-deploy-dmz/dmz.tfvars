# Passed explicitly (-var-file=dmz.tfvars), not auto-loaded, to match the
# connectivity, identity and firewall repos.

subscription_id = "baad6a23-36ca-492f-9fe7-3015244998c6" # Sub-DMZ
location        = "canadacentral"

# The live tags on every resource, set by the tag policies (tenant-root
# assignment d299326f572053428c3561f4, and the subscription assignment
# 7f93b0b2c91b510b8962a020 that ran on 2026-11-13). Environment is "Prod" even
# on the nonprod resources; keep it that way here until the policy changes, or
# the two will keep rewriting each other.
tags = {
  CostCenterId = "YT-02091.S.IMP"
  Environment  = "Prod"
}

security_workspace_id   = "/subscriptions/7d54d6f7-83d9-48cf-ac35-1068bcfd0561/resourceGroups/rg-siem-security-canadacentral-001/providers/Microsoft.OperationalInsights/workspaces/la-siem-security-canadacentral-001"
security_workspace_guid = "9c9a382f-30e1-4ace-ab51-a73661e7bb9e"
management_workspace_id = "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/rg-siem-management-canadacentral-001/providers/Microsoft.OperationalInsights/workspaces/la-siem-management-canadacentral-001"

ddos_protection_plan_id       = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/ddosProtectionPlans/ddos-protection-plan"
dns_servers                   = ["10.195.1.4"]
key_vault_private_dns_zone_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.vaultcore.azure.net"
