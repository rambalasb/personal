terraform {
  # tf-wrapper-avm-key-vault 0.4.0 needs Terraform 1.11 and azurerm 4.81.
  required_version = ">= 1.11, < 2.0"

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 4.81, < 5.0"
    }
    # The resource-group, virtual-network, storage-account and network-watcher
    # wrappers are AzAPI-based.
    azapi = {
      source  = "Azure/azapi"
      version = "~> 2.4"
    }
    modtm = {
      source  = "Azure/modtm"
      version = "~> 0.3"
    }
    random = {
      source  = "hashicorp/random"
      version = "~> 3.6"
    }
  }

  # CLI-driven workspace az-dmz (ws-kW4tziNCvvK75u7q) in project az-dmz. It
  # needs the Azure dynamic credentials for the DMZ subscription before the
  # first run (see README.md, "Before the first run").
  cloud {
    organization = "BC_Hydro"

    workspaces {
      name    = "az-dmz"
      project = "az-dmz"
    }
  }
}

provider "azurerm" {
  subscription_id     = var.subscription_id
  storage_use_azuread = true
  features {}
}

provider "azapi" {
  subscription_id = var.subscription_id
}
