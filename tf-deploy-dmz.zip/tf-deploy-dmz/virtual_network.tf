# virtual_network.tf
# vnet-dmz-nonprod-canadacentral-001 and its two subnets.
#
# NOT managed here: the peering RemoteVnetToHubPeering_a8db0ae7-... on this
# VNet. vWAN creates it for the hub connection peering-dmz-nonprod-canadacentral-001,
# which tf-deploy-platform-connectivity owns (hub_vwan.tf). Declaring it here
# as well would give it two owners. `peerings = {}` leaves it alone: the AVM
# module manages peerings as separate child resources, and the VNet body it
# sends carries no peerings.

module "virtual_network" {
  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-virtual-network/azurerm"
  version = "0.1.0"

  name          = "vnet-dmz-nonprod-canadacentral-001"
  parent_id     = module.resource_group["nonprod"].resource_id
  location      = var.location
  address_space = ["10.195.130.0/23"]

  subnets = {
    "snet-dmz-nonprod-agw-canadacentral-001" = {
      name                              = "snet-dmz-nonprod-agw-canadacentral-001"
      address_prefixes                  = ["10.195.131.0/24"]
      private_endpoint_network_policies = "Disabled"
      delegations = [
        # The portal named the delegation after the subnet.
        { name = "snet-dmz-nonprod-agw-canadacentral-001", service_delegation = { name = "Microsoft.Network/applicationGateways" } }
      ]
    }
    "snet-dmz-nonprod-pep-canadacentral-001" = {
      name             = "snet-dmz-nonprod-pep-canadacentral-001"
      address_prefixes = ["10.195.130.0/24"]
      # Must stay RouteTableEnabled. It was Disabled until 2026-11-20 and that
      # stopped on-prem traffic reaching the Key Vault private endpoint through
      # the hub firewall (RITM0541373). Every other PE subnet in the estate is
      # Enabled or RouteTableEnabled.
      private_endpoint_network_policies             = "RouteTableEnabled"
      private_link_service_network_policies_enabled = false
    }
  }

  peerings = {}

  ddos_protection_plan = {
    id     = var.ddos_protection_plan_id
    enable = true
  }

  dns_servers = { dns_servers = var.dns_servers }

  diagnostic_settings = {
    logs = {
      name                  = "sendLogsToLA"
      log_groups            = ["allLogs"]
      metric_categories     = []
      workspace_resource_id = var.security_workspace_id
    }
    metrics = {
      name                  = "sendMetricsToLA"
      log_groups            = []
      metric_categories     = ["AllMetrics"]
      workspace_resource_id = var.management_workspace_id
    }
  }

  enable_telemetry = false
  tags             = local.common_tags
}
