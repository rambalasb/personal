# =====================================================================
# Shared inputs. tenant_id comes from the provider environment (ARM_TENANT_ID).
#
# This repo owns the DMZ subscription (Sub-DMZ). Everything in it was built in
# the Azure portal between 2026-07-22 and 2026-11-20, plus the Front Door
# onboarding scripts; nothing else deploys here. See README.md, "What is
# managed" for which tiers are adopted so far.
# =====================================================================

variable "subscription_id" {
  type        = string
  description = "DMZ subscription this repo manages."
}

variable "location" {
  type    = string
  default = "canadacentral"
}

variable "tags" {
  type        = map(string)
  description = "Tags every resource carries. Must match what the tag policies set, or each apply and the next remediation overwrite each other."
  default     = {}
}

# --- Cross-subscription references (read by ID, never managed here) ------

variable "security_workspace_id" {
  type        = string
  description = "la-siem-security-canadacentral-001 resource ID (Sub-Security). Logs go here."
}

variable "security_workspace_guid" {
  type        = string
  description = "Customer ID (GUID) of la-siem-security-canadacentral-001. Traffic analytics needs it alongside the resource ID."
}

variable "management_workspace_id" {
  type        = string
  description = "la-siem-management-canadacentral-001 resource ID (Sub-Management). Metrics go here."
}

variable "ddos_protection_plan_id" {
  type        = string
  description = "Shared DDoS plan in the connectivity subscription."
}

variable "dns_servers" {
  type        = list(string)
  description = "Custom DNS servers on the VNet (the DNS resolver inbound endpoint)."
}

variable "key_vault_private_dns_zone_id" {
  type        = string
  description = "privatelink.vaultcore.azure.net in the connectivity subscription."
}
