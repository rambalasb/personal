# network_watcher.tf
# NetworkWatcher_canadacentral, its VNet flow log, and the storage account the
# flow log writes to. Traffic analytics goes to la-siem-security.

# Native: the wrapper reads an existing watcher but cannot create one (same
# pattern as tf-deploy-platform-connectivity).
resource "azurerm_network_watcher" "this" {
  name                = "NetworkWatcher_canadacentral"
  resource_group_name = module.resource_group["network_watcher"].name
  location            = var.location
  tags                = local.common_tags
}

module "flow_log_storage" {
  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-storage-account/azurerm"
  version = "0.3.0"

  name      = "stnwdmzcanadacentral001"
  parent_id = module.resource_group["network_watcher"].resource_id
  location  = var.location

  account_kind             = "StorageV2"
  account_tier             = "Standard"
  account_replication_type = "LRS" # wrapper default is ZRS
  access_tier              = "Hot"

  # Live value. Wrapper default is true, and changing it forces a new account.
  infrastructure_encryption_enabled = false

  shared_access_key_enabled        = false
  default_to_oauth_authentication  = true
  public_network_access_enabled    = false
  allow_nested_items_to_be_public  = false
  cross_tenant_replication_enabled = false
  min_tls_version                  = "TLS1_2"
  https_traffic_only_enabled       = true

  network_rules = {
    bypass         = ["AzureServices"]
    default_action = "Deny"
  }

  # Policy-created (same lower-case "t" spelling as the Key Vault one). An
  # account-level diagnostic setting carries metrics only.
  diagnostic_settings_storage_account = {
    metrics = {
      name = "sendLogstoLA"
      metrics = [
        { category = "Capacity" },
        { category = "Transaction" },
      ]
      workspace_resource_id = var.security_workspace_id
    }
  }

  enable_telemetry = false
  tags             = local.common_tags
}

module "network_watcher" {
  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-network-watcher/azurerm"
  version = "0.1.0"

  network_watcher_id   = azurerm_network_watcher.this.id
  network_watcher_name = azurerm_network_watcher.this.name
  resource_group_name  = module.resource_group["network_watcher"].name
  location             = var.location

  flow_logs = {
    "vnet-dmz-nonprod-canadacentral-001-rg-dmz-nonprod-canada-flowlog" = {
      name               = "vnet-dmz-nonprod-canadacentral-001-rg-dmz-nonprod-canada-flowlog"
      enabled            = true
      version            = 2
      target_resource_id = module.virtual_network.resource_id
      storage_account_id = module.flow_log_storage.resource_id
      retention_policy = {
        enabled = true
        days    = 90
      }
      traffic_analytics = {
        enabled               = true
        interval_in_minutes   = 60
        workspace_id          = var.security_workspace_guid
        workspace_region      = "canadacentral"
        workspace_resource_id = var.security_workspace_id
      }
    }
  }

  enable_telemetry = false
  tags             = local.common_tags
}
