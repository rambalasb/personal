# resource_group.tf
# All four resource groups in the subscription. NetworkWatcherRG was created by
# Azure when the VNet was built; it is adopted because it holds the watcher,
# flow log and flow-log storage this repo manages.
# rg-dmz-prod-canadacentral-001 is empty today.

locals {
  resource_groups = {
    shared          = { name = "rg-dmz-shared-canadacentral-001" }
    nonprod         = { name = "rg-dmz-nonprod-canadacentral-001" }
    prod            = { name = "rg-dmz-prod-canadacentral-001" }
    network_watcher = { name = "NetworkWatcherRG" }
  }
}

module "resource_group" {
  for_each = local.resource_groups

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-resource-group/azurerm"
  version = "2.0.0"

  name     = each.value.name
  location = var.location

  enable_telemetry = false
  tags             = local.common_tags
}
