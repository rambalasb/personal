# key_vault.tf
# kvdmzcac001 holds the Front Door certificates. Its private endpoint sits in
# the nonprod VNet's PE subnet but in a different resource group from the vault.
#
# Values below are the live configuration (inventory 2026-11-23). Two of them
# are not reversible in Azure, so do not "improve" them here without a change
# request:
#   - purge_protection_enabled: off today. Turning it on is one-way.
#   - the PE's DNS zone group "default" was added by hand on 2026-11-19 for
#     RITM0541373; removing it breaks name resolution for the Citrix upload path.

module "key_vault" {
  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-key-vault/azurerm"
  version = "0.4.0"

  name                = "kvdmzcac001"
  resource_group_name = module.resource_group["shared"].name
  location            = var.location
  tenant_id           = data.azurerm_client_config.current.tenant_id

  sku_name                       = "standard"
  purge_protection_enabled       = false
  soft_delete_retention_days     = 90
  public_network_access_enabled  = false
  legacy_access_policies_enabled = false # RBAC authorization

  network_acls = {
    bypass         = "AzureServices"
    default_action = "Deny"
  }

  private_endpoints = {
    vault = {
      name                            = "pep-kvdmzcac001"
      resource_group_name             = module.resource_group["nonprod"].name
      location                        = var.location
      subnet_resource_id              = module.virtual_network.subnets["snet-dmz-nonprod-pep-canadacentral-001"].resource_id
      private_service_connection_name = "pep-kvdmzcac001"
      network_interface_name          = "pep-kvdmzcac001-nic"
      private_dns_zone_group_name     = "default"
      private_dns_zone_resource_ids   = [var.key_vault_private_dns_zone_id]
      tags                            = local.common_tags
    }
  }

  # Created by the deploy-if-not-exists policy (PolicyDeployment_2606635729864015904,
  # 2026-10-26). Keep the name exactly, lower-case "t" included: a diagnostic
  # setting cannot be renamed, and a rename deletes and recreates it.
  diagnostic_settings = {
    logs = {
      name                           = "sendLogstoLA"
      log_categories                 = ["AuditEvent"]
      log_groups                     = []
      metric_categories              = []
      log_analytics_destination_type = "AzureDiagnostics"
      workspace_resource_id          = var.security_workspace_id
    }
  }

  enable_telemetry = false
  tags             = local.common_tags
}
