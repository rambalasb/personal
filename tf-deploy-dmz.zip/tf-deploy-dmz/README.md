# tf-deploy-dmz

Manages the DMZ subscription (`baad6a23-36ca-492f-9fe7-3015244998c6`,
Sub-DMZ, `canadacentral`) through the `tf-wrapper-avm-*` modules. The structure,
gate and pipelines are copied from `tf-deploy-platform-connectivity`.

Everything in this subscription was built in the Azure portal (deployment
history: VNet, App Gateway and Front Door on 2026-07-22, Key Vault on
2026-10-26), and the Front Door children by the `afd-onboard-*.sh` scripts. No
other pipeline or workspace deploys here, so this repo adopts it all, tier by
tier.

**Nothing has been applied yet.**

## What is managed

**16 import blocks** in `imports.tf`, reconciled against the 2026-11-23 inventory
(`full-inventory-dmz-20261123-162717`, from `scripts/export_full_inventory.sh`).

| Tier | File | Contents | Imports | Status |
|---|---|---|---|---|
| 1. Foundation | `resource_group.tf`, `key_vault.tf`, `network_watcher.tf` | 4 RGs; `kvdmzcac001` + `pep-kvdmzcac001` (DNS zone group inline) + `sendLogstoLA`; `NetworkWatcher_canadacentral`, `stnwdmzcanadacentral001` + `sendLogstoLA`, VNet flow log | 11 | **in this repo** |
| 1. Network | `virtual_network.tf` | `vnet-dmz-nonprod-canadacentral-001`, 2 subnets, `sendLogsToLA` + `sendMetricsToLA` | 5 | **in this repo** |
| 2. App Gateway | — | `agw-dmz-nonprod-canadacentral-001`, `pip-agw-…`, 2 diagnostic settings | — | waiting on a decision (below) |
| 3. Front Door WAF | — | `wafglobal001`, `wafext001`, `wafIntTemplate`, `wafExtTemplate` | — | waiting on the HTTPDDoS check (below) |
| 4. Front Door | — | `afd-dmz-global-001`, `afd-dmz-ext-global-001`: 2 endpoints, 30 domains, 16 origin groups/origins/routes, rule set + 2 rules, 2 security policies, 21 secrets, 6 diagnostic settings | — | last; re-export first |

Until a tier lands, its resources are listed in `.github/inventory-waivers.txt`
so the daily unmanaged report stays readable. Remove a line in the same change
that imports it.

## What is deliberately not managed here

| Object | Owner | Why |
|---|---|---|
| Peering `RemoteVnetToHubPeering_a8db0ae7-…` on the DMZ VNet | `tf-deploy-platform-connectivity` (`hub_vwan.tf`, hub connection `peering-dmz-nonprod-canadacentral-001`) | vWAN creates it for the hub connection. Two owners would fight. `peerings = {}` leaves it untouched. |
| `privatelink.vaultcore.azure.net`, the DDoS plan, the DNS resolver IP | `tf-deploy-platform-connectivity` | Referenced by ID through `dmz.tfvars`. |
| `la-siem-security`, `la-siem-management` | security / management subscriptions | Referenced by ID. |
| `pep-kvdmzcac001-nic` | the private endpoint | Created and named through the PE; waived in the unmanaged report. |
| Subscription diagnostic setting `sendSecurityActivityLogtoLA`, Defender plans, ASC policy assignments | platform | Subscription-level settings owned outside this repo. |

## Two policies write to these resources

1. **Tag Modify policies.** The tenant-root assignment `d299326f572053428c3561f4`
   (identity `72bf20de-…`, ran 2026-09-09) and a subscription assignment
   `7f93b0b2c91b510b8962a020` (ran 2026-11-13, since removed) set
   `CostCenterId=YT-02091.S.IMP` and `Environment=Prod` on every resource,
   nonprod included. `dmz.tfvars` sends exactly those values. If the policy's
   values change, change `tags` in the same week, or each apply and the next
   remediation will overwrite each other.
2. **Deploy-if-not-exists diagnostics.** `PolicyDeployment_2606635729864015904`
   created the Key Vault's `sendLogstoLA` on 2026-10-26. The policy only acts when
   a matching setting is missing, so managing it here, unchanged, keeps the
   policy compliant. **Never rename a diagnostic setting** (lower-case "t" in
   `sendLogstoLA` included): a rename is a delete and recreate, and the policy
   may add its own copy in between.

## Values that must not drift back

| Setting | Live value | Why |
|---|---|---|
| `snet-dmz-nonprod-pep-…` `private_endpoint_network_policies` | `RouteTableEnabled` | Was `Disabled` until 2026-11-20 and stopped on-prem traffic reaching the Key Vault PE through the hub firewall (RITM0541373). |
| `pep-kvdmzcac001` DNS zone group `default` → `privatelink.vaultcore.azure.net` | present | Added by hand 2026-11-19; without it `kvdmzcac001` does not resolve to 10.195.130.5. |
| Key Vault `purge_protection_enabled` | `false` | Turning it on is one-way. Do it as its own change if wanted. |
| Storage `infrastructure_encryption_enabled` | `false` | Wrapper default is `true`; changing it replaces the account. |
| Storage `account_replication_type` | `LRS` | Wrapper default is `ZRS`. |

## Before the first run

1. **HCP Terraform workspace `az-dmz`** (project `az-dmz`, CLI-driven, created 2026-11-23) in the `BC_Hydro` organization,
   with Azure dynamic credentials (OIDC) for an identity that has
   **Contributor** on Sub-DMZ, plus **Reader** on the connectivity
   (`f3835bc1…`), security (`7d54d6f7…`) and management (`ccac6a90…`)
   subscriptions for the cross-subscription IDs. Contributor is enough: this
   tier creates no role assignments.
2. **Repository secret `TF_API_TOKEN`** for HCP Terraform, as in the connectivity repo.
3. **GitHub environment `dmz` with required reviewers.** Without reviewers the
   apply job runs straight through.
4. **The registry wrapper versions this repo pins** (`resource-group 2.0.0`,
   `key-vault 0.4.0`, `virtual-network 0.1.0`, `storage-account 0.3.0`,
   `network-watcher 0.1.0`). The config was validated locally against the
   `tf-wrapper-avm-*` folders, which resolve to AVM resource-group 0.4.0,
   key-vault 0.11.0, virtual-network 0.17.1, storage-account 0.10.0 and
   network-watcher 0.3.2. If the registry versions pin different AVM versions,
   the first plan fails on an import address; fix the address in `imports.tf`.
5. Optional, for `unmanaged-detect.yml`: repository variables `AZURE_CLIENT_ID`,
   `AZURE_TENANT_ID`, `AZURE_SUBSCRIPTION_ID` for a Reader identity with a GitHub
   federated credential. Without them the job skips (green, but did nothing).

## The first plan: what to look for

Run `import-verify.yml`. Expect 16 imports and tag additions (`managed-by`,
`solution`, and the wrappers' `module`) only. These are the places where a
real diff is most likely; read each before adding a waiver:

- **Diagnostic setting destination type.** The VNet settings have no
  `logAnalyticsDestinationType` set; the wrapper defaults to `Dedicated`. If the
  plan shows `log_analytics_destination_type` changing, that is a real change
  to the table the logs land in; set it to match, do not waive it.
- **Key Vault diagnostics.** Live has `AzurePolicyEvaluationDetails` and
  `AllMetrics` present but disabled; the config sends only `AuditEvent`. A plan
  that removes disabled entries is cosmetic; one that adds or removes an
  *enabled* category is not.
- **Storage body.** The wrapper sends `isLocalUserEnabled`, `isSftpEnabled` and
  `isNfsV3Enabled = false`; Azure omits them when unset. Under `--subset-attr body`
  that shows as a body difference. It is a no-op in Azure (false is the
  default), so it is a candidate for a reviewed waiver.
- **Private endpoint DNS zone config name.** Live is `vaultcore` (portal name).
  azurerm may plan to rename it to the zone name, which recreates the zone group:
  a short DNS outage for the Key Vault. If it shows, stop and fix it before applying.
- **Resource group tags.** RG tags were not in the export. If the plan removes a
  tag from an RG, add that tag to the config; the gate fails tag removals.

## Pipelines

Same three as connectivity, sharing the `sub-dmz` concurrency group:

- `import-verify.yml`: fmt, validate, plan, drift report, zero-diff gate. Never
  applies. `workflow_dispatch` only.
- `import-apply.yml`: `check` plans, gates and publishes a change-set digest;
  `apply` waits for the `dmz` environment approval, re-plans, re-gates, checks
  the digest still matches, applies, then re-plans to confirm it is empty.
  Type `apply` in the `confirm` input.
- `unmanaged-detect.yml`: daily at 14:45 UTC, diffs `az resource list` against
  state, using `.github/inventory-waivers.txt`.

`tflint.yml` and `trivy.yml` run on pull requests. `scripts/verify_zero_diff.sh`
and `scripts/detect_unmanaged.sh` are copies of the connectivity ones; keep them
in step.

## Running locally

```bash
terraform init
terraform plan -var-file=dmz.tfvars -out=tfplan.binary
terraform show -json tfplan.binary > plan.json
bash scripts/verify_zero_diff.sh plan.json --subset-attr body \
  --ignore-attr response_export_values --ignore-attr retry --ignore-attr timeouts \
  --ignore-attr ignore_null_property --ignore-attr ignore_casing \
  --ignore-attr ignore_missing_property --ignore-attr schema_validation_enabled \
  --ignore-attr read_query_parameters --ignore-attr create_headers \
  --ignore-attr update_headers --ignore-attr delete_headers --ignore-attr read_headers \
  --ignore-attr locks --ignore-type time_sleep --ignore-type random_uuid \
  --ignore-type modtm_telemetry --ignore-type terraform_data \
  --allow-file scripts/zero_diff_allow.txt
```

## Next tiers

- **App Gateway (tier 2).** It is a Standard_v2 placeholder: empty backend pool,
  HTTP listener on public IP `4.229.145.209`, no WAF. Decide whether to keep the
  public listener or move to WAF_v2 before importing; importing the placeholder
  as-is only locks it in.
- **Front Door WAF (tier 3).** `wafglobal001` and `wafext001` use
  `Microsoft_HTTPDDoSRuleSet_1.0`, which `tf-wrapper-avm-front-door-waf-policy`
  does not document. Plan the two template policies first; if the wrapper drops
  the rule set from the live policies, manage those two with `azapi_resource`.
- **Front Door (tier 4).** About 120 child objects through
  `tf-wrapper-avm-cdn-profile`. Generate the imports from `children/afd-*.json`
  of a fresh export, and stop on any `must be replaced`: a replaced custom
  domain loses its validation and certificate.
