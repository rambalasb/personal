#!/usr/bin/env bash
# Quick list of every resource in the DMZ subscription (tf-deploy-dmz).
# Takes about a minute. For full properties, diagnostics, RBAC and Front Door
# child objects, use export_full_inventory.sh instead.
#
# Run in Azure Cloud Shell (bash):
#   bash ~/list_resources.sh
#
# Writes to ~/clouddrive/dmz-resources/:
#   resource-groups.csv   name, location, tags
#   resources.csv         resource group, name, type, location, sku, kind, tags, id
#   resources.json        same rows, full az output
#   type-counts.txt       count per resource type
set -euo pipefail

SUB=${SUB:-baad6a23-36ca-492f-9fe7-3015244998c6}
OUT=${OUT:-$HOME/clouddrive/dmz-resources}
mkdir -p "$OUT" && cd "$OUT"
az account set --subscription "$SUB"
echo "subscription: $(az account show --query name -o tsv) ($SUB)"

az group list -o json > resource-groups.json
jq -r '["name","location","tags"],
       (sort_by(.name|ascii_downcase)[] | [.name, .location, (.tags // {} | tostring)]) | @csv' \
  resource-groups.json > resource-groups.csv

az resource list -o json > resources.json
jq -r '["resourceGroup","name","type","location","sku","kind","tags","id"],
       (sort_by((.resourceGroup|ascii_downcase), (.type|ascii_downcase), (.name|ascii_downcase))[]
        | [.resourceGroup, .name, .type, .location, (.sku.name // ""), (.kind // ""),
           (.tags // {} | tostring), .id]) | @csv' \
  resources.json > resources.csv

jq -r '[.[].type | ascii_downcase] | group_by(.) | sort_by(-length, .[0])[] | "\(length)\t\(.[0])"' \
  resources.json > type-counts.txt

echo
echo "resource groups: $(jq length resource-groups.json)"
echo "resources:       $(jq length resources.json)"
echo
cat type-counts.txt
echo
echo "files in $OUT (download resources.csv to open in Excel)"
