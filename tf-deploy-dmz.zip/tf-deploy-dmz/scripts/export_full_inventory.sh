#!/usr/bin/env bash
# Full inventory of the DMZ subscription (baad6a23...) for the new
# tf-deploy-dmz repo (nothing imported yet). Copied from
# tf-deploy-platform-connectivity/scripts/export_full_inventory.sh. Step [14b]
# is DMZ-specific: Front Door child objects (domains, endpoints, routes, origin
# groups, origins, rule sets, rules, security policies, secrets), which are not
# in Terraform and are changed by the afd-onboard-*.sh scripts.
# The firewall / vWAN steps are kept so the layout matches the connectivity
# export; they produce empty files when the subscription has none.
#
# Run in Azure Cloud Shell (bash): it needs az, jq, GNU xargs and sha1sum.
# On macOS use gxargs/gsha1sum from `brew install findutils coreutils`.
#
#   mkdir -p ~/clouddrive/full-inventory-dmz && cd ~/clouddrive/full-inventory-dmz
#   bash ~/export_full_inventory.sh 2> errors.txt
#
# Cloud Shell drops idle sessions after 20 minutes. The two per-resource steps
# run in parallel and cache each result under cache/, so re-running after a
# disconnect resumes instead of starting over. Delete cache/ before an export
# on a later date, or it returns stale results.
#
# Done when the summary shows equal resource / diag / props counts and
# "export failures: 0". Anything else: re-run, then read errors.txt.

SUB=${SUB:-baad6a23-36ca-492f-9fe7-3015244998c6}
OUT=${OUT:-$HOME/clouddrive/full-inventory-dmz}
PAR=${PAR:-8}
mkdir -p "$OUT" && cd "$OUT" || exit 1
rm -rf props children
mkdir -p props children cache/diag cache/props cache/err
az account set --subscription "$SUB" || exit 1
az config set extension.use_dynamic_install=yes_without_prompt -o none

echo "[1] top-level resources"
az resource list --subscription "$SUB" -o json > azure-inventory.json
jq -r 'sort_by(.id)[] | [.id, .type, .location] | @tsv' azure-inventory.json > azure-inventory.tsv

echo "[2] resource groups + subscription"
az graph query -q "ResourceContainers | where subscriptionId =~ '$SUB' | project id, type, location" \
  --subscriptions "$SUB" --first 1000 -o json > resource-containers.json
jq -r '.data[] | [.id, .type, .location] | @tsv' resource-containers.json >> azure-inventory.tsv

echo "[3] firewall rule collection groups (ids; full rules in step 15)"
az network firewall policy list --query "[].[resourceGroup,name]" -o tsv | while read -r g n; do
  az network firewall policy rule-collection-group list -g "$g" --policy-name "$n" --query "[].id" -o tsv
done | sed 's/$/\tMicrosoft.Network\/firewallPolicies\/ruleCollectionGroups\t-/' >> azure-inventory.tsv

echo "[4] private DNS vnet links"
az network private-dns zone list --query "[].[resourceGroup,name]" -o tsv | while read -r g n; do
  az network private-dns link vnet list -g "$g" -z "$n" --query "[].id" -o tsv
done | sed 's/$/\tMicrosoft.Network\/privateDnsZones\/virtualNetworkLinks\t-/' >> azure-inventory.tsv

echo "[5] vWAN hub connections + route tables"
az network vhub list --query "[].[resourceGroup,name]" -o tsv | while read -r g n; do
  az network vhub connection list -g "$g" --vhub-name "$n" --query "[].id" -o tsv \
    | sed 's/$/\tMicrosoft.Network\/virtualHubs\/hubVirtualNetworkConnections\t-/'
  az network vhub route-table list -g "$g" --vhub-name "$n" --query "[].id" -o tsv \
    | sed 's/$/\tMicrosoft.Network\/virtualHubs\/hubRouteTables\t-/'
done >> azure-inventory.tsv
sort -u -o azure-inventory.tsv azure-inventory.tsv

echo "[6] IP groups"
az network ip-group list -o json > ip-groups.json

echo "[7] classic inline firewall rules"
az network firewall list --query "[].[resourceGroup,name]" -o tsv | while read -r g n; do
  az network firewall show -g "$g" -n "$n" -o json \
    | jq --arg fw "$n" --arg rg "$g" '{firewall:$fw, resourceGroup:$rg,
        networkRuleCollections:.networkRuleCollections,
        applicationRuleCollections:.applicationRuleCollections,
        natRuleCollections:.natRuleCollections}'
done | jq -s '.' > classic-firewall-rules.json

echo "[8] role assignments (inherited = assigned above this subscription)"
az role assignment list --all --include-inherited \
  --query "[].{role:roleDefinitionName,principal:principalId,principalName:principalName,principalType:principalType,scope:scope}" \
  -o json | jq --arg sub "/subscriptions/$SUB" \
    '[.[] | . + {inherited: ((.scope | ascii_downcase | startswith($sub | ascii_downcase)) | not)}]' \
  > role-assignments.json

key() { printf %s "$1" | sha1sum | cut -c1-40; }
diag_one() {
  id=$1; h=$(key "$id"); f=cache/diag/$h; e=cache/err/diag-$h
  [ -s "$f" ] && return 0
  if out=$(az monitor diagnostic-settings list --resource "$id" -o json 2>"$e"); then
    printf '== %s\n%s\n' "$id" "$out" > "$f.tmp" && mv "$f.tmp" "$f"
  elif grep -q ResourceTypeNotSupported "$e"; then
    printf '== %s\nUNSUPPORTED\n' "$id" > "$f"
  else
    echo "EXPORT-FAILED diag $id: $(tr '\n' ' ' < "$e")" >&2
  fi
  rm -f "$e"
}
props_one() {
  id=$1; h=$(key "$id"); f=cache/props/$h; e=cache/err/props-$h
  [ -s "$f" ] && return 0
  if ! az resource show --ids "$id" -o json > "$f.tmp" 2>"$e"; then
    # az picks the newest api-version the provider advertises; some regions do not serve it yet
    ver=$(grep -o "supported api-versions are '[^']*'" "$e" | head -1 | grep -oE '[0-9]{4}-[0-9]{2}-[0-9]{2}(-preview)?' | grep -v preview | tail -1)
    [ -n "$ver" ] && az resource show --ids "$id" --api-version "$ver" -o json > "$f.tmp" 2>"$e"
  fi
  if [ -s "$f.tmp" ] && jq -e . "$f.tmp" >/dev/null 2>&1; then
    mv "$f.tmp" "$f"
  else
    rm -f "$f.tmp"; echo "EXPORT-FAILED props $id: $(tr '\n' ' ' < "$e")" >&2
  fi
  rm -f "$e"
}
export -f key diag_one props_one

echo "[9] diagnostic settings per resource ($PAR in parallel, resumable)"
jq -r '.[].id' azure-inventory.json | xargs -d '\n' -P "$PAR" -I{} bash -c 'diag_one "$1"' _ {}
: > diagnostic-settings.txt
jq -r '.[].id' azure-inventory.json | while read -r id; do
  f=cache/diag/$(key "$id"); [ -s "$f" ] || continue
  body=$(tail -n +2 "$f")
  [ "$body" = "[]" ] || [ "$body" = "UNSUPPORTED" ] || cat "$f" >> diagnostic-settings.txt
done
az monitor diagnostic-settings subscription list -o json > subscription-diagnostic-settings.json

echo "[10] locks"
az lock list -o json > locks.json

echo "[11] policy assignments + exemptions"
az policy assignment list --disable-scope-strict-match -o json > policy-assignments.json
az policy exemption list --disable-scope-strict-match -o json > policy-exemptions.json

echo "[12] federated credentials"
: > federated-credentials.txt
az identity list --query "[].[resourceGroup,name]" -o tsv | while read -r g n; do
  echo "== $n" >> federated-credentials.txt
  az identity federated-credential list --identity-name "$n" -g "$g" -o json >> federated-credentials.txt
done

echo "[13] full properties per resource ($PAR in parallel, resumable)"
jq -r '.[].id' azure-inventory.json | xargs -d '\n' -P "$PAR" -I{} bash -c 'props_one "$1"' _ {}
# Group case-insensitively: Azure returns some types in two casings, and two
# spellings writing the same file would overwrite each other.
jq -r '[.[].type | ascii_downcase] | unique[]' azure-inventory.json | while read -r t; do
  jq -r --arg t "$t" '.[] | select((.type|ascii_downcase)==$t) | .id' azure-inventory.json | while read -r id; do
    f=cache/props/$(key "$id"); [ -s "$f" ] && cat "$f"
  done | jq -s '.' > "props/$(echo "$t" | tr '/' '_').json"
done

echo "[14] child resources, full objects"
az network vnet list -o json          > .vnets.json
az network nsg list -o json           > .nsgs.json
az group list --query "[].name" -o tsv | while read -r g; do
  az network route-table list -g "$g" -o json || echo "EXPORT-FAILED route-tables $g" >&2
done | jq -s 'add // []' > .rts.json
az network express-route list -o json > .ercs.json
az network lb list -o json            > .lbs.json
jq '[.[] | .subnets[]?]'                .vnets.json > children/vnet-subnets.json
jq '[.[] | .virtualNetworkPeerings[]?]' .vnets.json > children/vnet-peerings.json
jq '[.[] | .securityRules[]?]'          .nsgs.json  > children/nsg-rules.json
jq '[.[] | .routes[]?]'                 .rts.json   > children/route-table-routes.json
jq '[.[] | .peerings[]?]'               .ercs.json  > children/erc-peerings.json
jq '[.[] | .backendAddressPools[]?]'    .lbs.json   > children/lb-pools.json
jq '[.[] | .probes[]?]'                 .lbs.json   > children/lb-probes.json
jq '[.[] | .loadBalancingRules[]?]'     .lbs.json   > children/lb-rules.json
rm -f .vnets.json .nsgs.json .rts.json .ercs.json .lbs.json

# per <output file> <az args with $g/$n>  -- reads "rg name" pairs on stdin
per() {
  out=$1; shift
  while read -r g n; do
    [ -n "$n" ] || continue
    eval "az $* -o json" || echo "EXPORT-FAILED $out $g/$n" >&2
  done | jq -s 'add // []' > "children/$out"
}
az network private-dns zone list --query "[].[resourceGroup,name]" -o tsv \
  | per pdns-vnet-links.json 'network private-dns link vnet list -g "$g" -z "$n"'
az network vhub list --query "[].[resourceGroup,name]" -o tsv > .hubs.tsv
per vhub-connections.json    'network vhub connection list -g "$g" --vhub-name "$n"'    < .hubs.tsv
per vhub-route-tables.json   'network vhub route-table list -g "$g" --vhub-name "$n"'   < .hubs.tsv
per vhub-route-maps.json     'network vhub route-map list -g "$g" --vhub-name "$n"'     < .hubs.tsv
per vhub-routing-intent.json 'network vhub routing-intent list -g "$g" --vhub "$n"'     < .hubs.tsv
per vhub-bgp.json            'network vhub bgpconnection list -g "$g" --vhub-name "$n"' < .hubs.tsv
rm -f .hubs.tsv
# Returns [] in current CLI versions; the four connections are inside
# props/microsoft.network_expressroutegateways.json (expressRouteConnections).
az network express-route gateway list --query "[].[resourceGroup,name]" -o tsv \
  | per ergw-connections.json 'network express-route gateway connection list -g "$g" --gateway-name "$n"'
az network vpn-gateway list --query "[].[resourceGroup,name]" -o tsv \
  | per vpn-connections.json 'network vpn-gateway connection list -g "$g" --gateway-name "$n"'
az backup vault list --query "[].[resourceGroup,name]" -o tsv \
  | per rsv-backup-policies.json 'backup policy list -g "$g" --vault-name "$n"'
az dns-resolver list --query "[].[resourceGroup,name]" -o tsv > .resolvers.tsv
per dnsr-inbound.json  'dns-resolver inbound-endpoint list -g "$g" --dns-resolver-name "$n"'  < .resolvers.tsv
per dnsr-outbound.json 'dns-resolver outbound-endpoint list -g "$g" --dns-resolver-name "$n"' < .resolvers.tsv
rm -f .resolvers.tsv
az dns-resolver forwarding-ruleset list --query "[].[resourceGroup,name]" -o tsv \
  | per frs-rules.json 'dns-resolver forwarding-rule list -g "$g" --ruleset-name "$n"'
az vm list --query "[].[resourceGroup,name]" -o tsv \
  | per vm-extensions.json 'vm extension list -g "$g" --vm-name "$n"'
az network private-dns zone list --query "[].[resourceGroup,name]" -o tsv \
  | per pdns-record-sets.json 'network private-dns record-set list -g "$g" -z "$n"'
az network private-endpoint list --query "[].[resourceGroup,name]" -o tsv \
  | per pe-dns-zone-groups.json 'network private-endpoint dns-zone-group list -g "$g" --endpoint-name "$n"'
az backup vault list --query "[].[resourceGroup,name]" -o tsv \
  | per rsv-protected-items.json 'backup item list -g "$g" --vault-name "$n"'
# Flow logs are listed by region, not by watcher; $n is the location here.
az network watcher list --query "[].[resourceGroup,location]" -o tsv | sort -u -k2,2 \
  | per flow-logs.json 'network watcher flow-log list --location "$n"'
# No az command group for traffic collectors; read the child collection directly.
az resource list --resource-type Microsoft.NetworkFunction/azureTrafficCollectors --query "[].id" -o tsv \
  | while read -r id; do
      az rest --method get --url "https://management.azure.com$id/collectorPolicies?api-version=2022-11-01" \
        --query value -o json || echo "EXPORT-FAILED collector-policies $id" >&2
    done | jq -s 'add // []' > children/traffic-collector-policies.json
# Assignments are extension resources on each VM; Resource Graph lists them all at once.
az graph query -q "maintenanceresources | where subscriptionId =~ '$SUB' | where type =~ 'microsoft.maintenance/configurationassignments'" \
  --subscriptions "$SUB" --first 1000 -o json | jq '.data' > children/maintenance-assignments.json

echo "[14b] Front Door child objects"
# GET a collection URL and follow nextLink; prints the merged value array.
arm_list() {
  url="https://management.azure.com$1"
  while [ -n "$url" ]; do
    page=$(az rest --method get --url "$url" -o json) || { echo "EXPORT-FAILED arm $1" >&2; return 1; }
    printf '%s\n' "$page" | jq '.value // []'
    url=$(printf '%s\n' "$page" | jq -r '.nextLink // empty')
  done | jq -s 'add // []'
}
AFD_API=2024-02-01
az resource list --resource-type Microsoft.Cdn/profiles --query "[].id" -o tsv > .afd.tsv
for kind in customDomains afdEndpoints originGroups ruleSets securityPolicies secrets; do
  while read -r p; do
    [ -n "$p" ] && arm_list "$p/$kind?api-version=$AFD_API"
  done < .afd.tsv | jq -s 'add // []' > "children/afd-$kind.json"
done
jq -r '.[].id' children/afd-afdEndpoints.json | while read -r e; do
  arm_list "$e/routes?api-version=$AFD_API"
done | jq -s 'add // []' > children/afd-routes.json
jq -r '.[].id' children/afd-originGroups.json | while read -r g; do
  arm_list "$g/origins?api-version=$AFD_API"
done | jq -s 'add // []' > children/afd-origins.json
jq -r '.[].id' children/afd-ruleSets.json | while read -r r; do
  arm_list "$r/rules?api-version=$AFD_API"
done | jq -s 'add // []' > children/afd-rules.json
rm -f .afd.tsv
# App Gateway listeners/rules/pools, PLS + PE connections and WAF policy rules
# are inside props/ (full resource bodies); these are flattened for reading.
jq '[.[] | {appgw:.name} + (.properties.httpListeners[]? // {})]' \
  props/microsoft.network_applicationgateways.json > children/appgw-listeners.json 2>/dev/null || echo '[]' > children/appgw-listeners.json
jq '[.[] | {appgw:.name} + (.properties.requestRoutingRules[]? // {})]' \
  props/microsoft.network_applicationgateways.json > children/appgw-routing-rules.json 2>/dev/null || echo '[]' > children/appgw-routing-rules.json
jq '[.[] | {appgw:.name} + (.properties.backendAddressPools[]? // {})]' \
  props/microsoft.network_applicationgateways.json > children/appgw-backend-pools.json 2>/dev/null || echo '[]' > children/appgw-backend-pools.json
jq '[.[] | {pls:.name} + (.properties.privateEndpointConnections[]? // {})]' \
  props/microsoft.network_privatelinkservices.json > children/pls-connections.json 2>/dev/null || echo '[]' > children/pls-connections.json

echo "[15] firewall rule collection groups, full rules"
az network firewall policy list --query "[].[resourceGroup,name]" -o tsv | while read -r g n; do
  az network firewall policy rule-collection-group list -g "$g" --policy-name "$n" -o json \
    || echo "EXPORT-FAILED rule-collection-groups $g/$n" >&2
done | jq -s 'add // []' > rule-collection-groups.json

echo "[16] subscription settings"
az security pricing list -o json > defender-plans.json
az role definition list --custom-role-only true --scope "/subscriptions/$SUB" -o json > custom-role-definitions.json
az provider list --query "[?registrationState=='Registered'].namespace" -o json > registered-providers.json
az tag list --resource-id "/subscriptions/$SUB" -o json > subscription-tags.json

echo "[17] bundle"
ZIP="full-inventory-dmz-$(date +%Y%m%d-%H%M%S).zip"
zip -qr "$ZIP" azure-inventory.json azure-inventory.tsv resource-containers.json \
  ip-groups.json classic-firewall-rules.json role-assignments.json rule-collection-groups.json \
  diagnostic-settings.txt subscription-diagnostic-settings.json locks.json \
  policy-assignments.json policy-exemptions.json federated-credentials.txt \
  defender-plans.json custom-role-definitions.json registered-providers.json subscription-tags.json \
  props children errors.txt
echo
echo "resources: $(jq length azure-inventory.json) | diag cached: $(ls cache/diag | grep -vc tmp) | props cached: $(ls cache/props | grep -vc tmp)"
echo "export failures: $(grep -c EXPORT-FAILED errors.txt 2>/dev/null || echo '?')"
echo "zip -> $OUT/$ZIP"
echo "Cloud Shell: download \"$OUT/$ZIP\""
