#!/usr/bin/env bash
# Assert that a Terraform plan containing pending imports changes nothing real.
#
# Why not `terraform plan -detailed-exitcode`: a plan with pending import blocks
# always exits 2, because importing *is* a change to state. That check cannot
# distinguish "adopting 40 resources cleanly" from "about to destroy your
# production key vault". This one can.
#
# Usage:
#   terraform plan -var-file=nonprod.tfvars -out=tfplan.binary
#   terraform show -json tfplan.binary > plan.json
#   verify_zero_diff.sh plan.json [--strict] [--ignore-attr NAME]... \
#                                 [--ignore-type TYPE]... [--subset-attr NAME]... \
#                                 [--allow-resource ADDRESS]... [--allow-file PATH]
#
# --ignore-attr  skip one attribute name across all resources. Needed for the
#                config-only knobs on azapi_resource, which terraform import
#                cannot populate, so they read as null -> value on every plan.
# --subset-attr  pass an attribute when the planned value is contained in the
#                current one rather than equal to it. Required for azapi_resource
#                `body`; see contained() for the caveat.
# --allow-resource
#                let one named resource address through despite a real diff, for
#                a delta that has been reviewed and accepted. Reported loudly and
#                counted. Use for a module that cannot express the live state,
#                never to quiet a tfvars mistake.
# --allow-file   reviewed waivers, one per line: ADDRESS | DIFF | REASON. DIFF is
#                the exact "attrs:" text the gate prints for that resource; if
#                the plan's diff is anything else, the resource fails. Entries
#                with no matching diff are listed as stale. # starts a comment.
# --ignore-type  skip a resource type outright. For types that make no cloud
#                API call at all (time_sleep, random_uuid, modtm_telemetry,
#                terraform_data without provisioners), a create is not a change
#                to Azure. Skipped counts are always
#                printed, never hidden.
#
# Passes when every resource change is a no-op or an import, tolerating
# tag additions (see --strict). A tag that exists in Azure and would be removed
# or changed always fails. Exits 0 pass, 1 fail, 2 usage error.

set -euo pipefail

if [ $# -lt 1 ]; then
  echo "usage: $(basename "$0") <plan.json> [--strict] [--ignore-attr NAME]... [--ignore-type TYPE]... [--subset-attr NAME]... [--allow-resource ADDRESS]... [--allow-file PATH]" >&2
  exit 2
fi

if ! command -v python3 >/dev/null 2>&1; then
  echo "error: python3 is required" >&2
  exit 2
fi

exec python3 - "$@" <<'PYTHON'
import json
import sys
from pathlib import Path

argv = sys.argv[1:]
plan_path = argv[0]
strict = "--strict" in argv
ignored = {"tags", "tags_all"} if not strict else set()
ignored_types = set()
subset_attrs = set()
allowed = set()
allow_file = None
i = 0
while i < len(argv):
    if argv[i] == "--ignore-attr" and i + 1 < len(argv):
        ignored.add(argv[i + 1])
        i += 2
        continue
    if argv[i] == "--ignore-type" and i + 1 < len(argv):
        ignored_types.add(argv[i + 1])
        i += 2
        continue
    if argv[i] == "--subset-attr" and i + 1 < len(argv):
        subset_attrs.add(argv[i + 1])
        i += 2
        continue
    if argv[i] == "--allow-resource" and i + 1 < len(argv):
        allowed.add(argv[i + 1])
        i += 2
        continue
    if argv[i] == "--allow-file" and i + 1 < len(argv):
        allow_file = argv[i + 1]
        i += 2
        continue
    i += 1

pinned = {}
if allow_file:
    try:
        for n, raw in enumerate(Path(allow_file).read_text(encoding="utf-8").splitlines(), 1):
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            parts = [p.strip() for p in line.split("|")]
            if len(parts) != 3 or not all(parts):
                print(f"error: {allow_file}:{n}: expected ADDRESS | DIFF | REASON", file=sys.stderr)
                raise SystemExit(2)
            if parts[0] in pinned:
                print(f"error: {allow_file}:{n}: duplicate entry for {parts[0]}", file=sys.stderr)
                raise SystemExit(2)
            pinned[parts[0]] = (parts[1], parts[2])
    except OSError as exc:
        print(f"error: cannot read allow file {allow_file}: {exc}", file=sys.stderr)
        raise SystemExit(2)
pinned_seen = set()

try:
    plan = json.loads(Path(plan_path).read_text(encoding="utf-8"))
except Exception as exc:
    print(f"error: cannot read plan JSON {plan_path}: {exc}", file=sys.stderr)
    raise SystemExit(2)

RESET, RED, GREEN, YELLOW = "\033[0m", "\033[31m", "\033[32m", "\033[33m"
if not sys.stdout.isatty():
    RESET = RED = GREEN = YELLOW = ""


def contained(after, before):
    """True when every leaf the config intends to send already has that value
    upstream. `terraform import` on azapi_resource captures the whole ARM
    response into `body`, while the module's body is a deliberate subset, so
    plain equality reports a diff on every azapi import no matter how correct
    the tfvars are. Containment is the question actually worth asking.

    An empty map whose key is absent upstream counts as contained: it asserts no
    leaves, and ARM omits the key when it holds nothing. An empty map against a
    populated one is still a diff -- that would be a clearing write.

    This is weaker than equality: a PUT with a partial body can still reset a
    field the module never mentions. It narrows the noise, it does not prove
    the write is inert."""
    if isinstance(after, dict):
        if not isinstance(before, dict):
            return False
        # An empty map in the config clears whatever is upstream, so it is
        # contained only when there is nothing there to clear. Without this the
        # loop below iterates nothing and returns True, which would let a
        # clearing write through unreported.
        if not after:
            return not before
        for key, val in after.items():
            # A null in the config body means "not managed here", not "remove".
            if val is None:
                continue
            if key not in before:
                # An empty map asserts no leaves, so there is nothing upstream it
                # could contradict, and ARM omits the key entirely when it holds
                # nothing. Sending {} there writes nothing. Deliberately not
                # extended to []: "absent" cannot be assumed to mean "empty list".
                if val == {}:
                    continue
                return False
            if not contained(val, before[key]):
                return False
        return True
    if isinstance(after, list):
        if not isinstance(before, list) or len(after) != len(before):
            return False
        return all(contained(x, y) for x, y in zip(after, before))
    return after == before


def _empty(v):
    return v is None or v == {} or v == [] or v == ""


def cleared_paths(after, before, path=""):
    """Paths where the config sends null (or leaves a key out) and Azure holds a
    real value. contained() skips nulls, but a PUT without the field resets it:
    this is how a VNet's DNS servers and the NxDomainRedirect links slipped
    through."""
    out = []
    if isinstance(after, dict) and isinstance(before, dict) and after:
        for key, val in after.items():
            sub = f"{path}.{key}" if path else key
            if key not in before:
                continue
            if val is None:
                if not _empty(before[key]):
                    out.append(sub)
                continue
            out.extend(cleared_paths(val, before[key], sub))
    elif isinstance(after, list) and isinstance(before, list) and len(after) == len(before):
        for i, (x, y) in enumerate(zip(after, before)):
            out.extend(cleared_paths(x, y, f"{path}[{i}]"))
    return out


def differing_paths(after, before, path=""):
    """Leaf paths where the config contradicts Azure, for the failure report."""
    if isinstance(after, dict) and isinstance(before, dict):
        out = []
        for key, val in after.items():
            sub = f"{path}.{key}" if path else key
            if val is None or (key not in before and val == {}):
                continue
            if key not in before:
                out.append(sub)
            elif not contained(val, before[key]):
                out.extend(differing_paths(val, before[key], sub) or [sub])
        return out
    if isinstance(after, list) and isinstance(before, list) and len(after) == len(before):
        out = []
        for i, (x, y) in enumerate(zip(after, before)):
            if not contained(x, y):
                out.extend(differing_paths(x, y, f"{path}[{i}]") or [f"{path}[{i}]"])
        return out
    return [path] if not contained(after, before) else []


def tag_losses(before, after):
    """Tag keys that exist in Azure and would be removed or rewritten."""
    b = before if isinstance(before, dict) else {}
    a = after if isinstance(after, dict) else {}
    removed = sorted(k for k in b if k not in a)
    changed = sorted(k for k in b if k in a and a[k] != b[k])
    return removed, changed


def describe(attr, before, after):
    """One attr label for the report, with the offending paths when known."""
    b = before.get(attr) if isinstance(before, dict) else None
    a = after.get(attr) if isinstance(after, dict) else None
    parts = []
    if attr in ("tags", "tags_all"):
        removed, changed = tag_losses(b, a)
        if removed:
            parts.append("removes " + ", ".join(removed))
        if changed:
            parts.append("changes " + ", ".join(changed))
    else:
        diff = list(dict.fromkeys(p.lstrip(".") or "whole value" for p in differing_paths(a, b)))
        clears = [p.lstrip(".") for p in cleared_paths(a, b)]
        if a is None and not _empty(b):
            diff, clears = [], ["whole value"]
        if diff:
            parts.append("differs " + ", ".join(diff[:6]) + (" ..." if len(diff) > 6 else ""))
        if clears:
            parts.append("clears " + ", ".join(clears[:6]) + (" ..." if len(clears) > 6 else ""))
    return f"{attr} ({'; '.join(parts)})" if parts else attr


def changed_attrs(before, after, after_unknown=None, subset=frozenset()):
    """Top-level attributes that actually differ. Terraform reports the whole
    object on both sides, so a diff has to be computed rather than counted."""
    before = before if isinstance(before, dict) else {}
    after = after if isinstance(after, dict) else {}
    unknown = after_unknown if isinstance(after_unknown, dict) else {}
    diff = []
    for key in sorted(set(before) | set(after)):
        b, a = before.get(key), after.get(key)
        if b == a:
            continue
        # A value Terraform will only learn at apply time is reported as null
        # in `after` and flagged in `after_unknown`. That is Terraform learning
        # a value, not a change to the resource. Only an exact True is skipped;
        # a nested structure means some inner value really is changing.
        if unknown.get(key) is True:
            continue
        if key in subset and contained(a, b) and not cleared_paths(a, b):
            continue
        diff.append(key)
    return diff


imported, noop, tolerated, violations, replacements, skipped, waived, reads = [], [], [], [], [], [], [], []

for rc in plan.get("resource_changes", []):
    addr = rc.get("address", "?")
    change = rc.get("change", {}) or {}
    actions = change.get("actions", [])
    importing = change.get("importing")
    unknown = change.get("after_unknown")

    # A data source is a GET. It cannot change Azure, so a `read` is never a
    # violation. Terraform usually resolves data sources during plan and leaves
    # them out of resource_changes entirely, but defers the read to apply when
    # an argument is not yet known -- and then it does appear here.
    if rc.get("mode") == "data" or actions == ["read"]:
        reads.append(addr)
        continue

    if rc.get("type") in ignored_types:
        if actions != ["no-op"]:
            skipped.append((addr, "/".join(actions) or "unknown"))
        continue

    if importing is not None:
        imported.append((addr, importing.get("id", "?")))

    if actions == ["no-op"]:
        if importing is None:
            noop.append(addr)
        continue

    if actions == ["update"]:
        before, after = change.get("before"), change.get("after")
        attrs = changed_attrs(before, after, unknown, subset_attrs)
        remaining = [a for a in attrs if a not in ignored]
        for t in ("tags", "tags_all"):
            if t in attrs and t in ignored and not (isinstance(unknown, dict) and unknown.get(t) is True):
                b = before.get(t) if isinstance(before, dict) else None
                a = after.get(t) if isinstance(after, dict) else None
                if any(tag_losses(b, a)):
                    remaining.append(t)
        remaining = [describe(a, before, after) for a in remaining]
        if not remaining:
            tolerated.append((addr, attrs))
            continue
        if addr in allowed:
            waived.append((addr, remaining))
            continue
        if addr in pinned:
            pinned_seen.add(addr)
            if ", ".join(remaining) == pinned[addr][0]:
                waived.append((addr, remaining))
                continue
            remaining = remaining + [f"allow-file expects: {pinned[addr][0]}"]
        violations.append((addr, "update", remaining))
        continue

    # delete+create (in either order) is a replacement. Called out separately
    # because it is categorically worse than an update: it destroys the live
    # resource and everything in it. Usually caused by a mismatch on a ForceNew
    # attribute -- a role assignment's scope casing or description here.
    if set(actions) == {"delete", "create"}:
        replacements.append((addr, changed_attrs(change.get("before"), change.get("after"), unknown, subset_attrs)))
        continue

    violations.append((addr, "/".join(actions) or "unknown", []))

print(f"resources importing : {len(imported)}")
print(f"unchanged (no-op)   : {len(noop)}")
if reads:
    print(f"data sources read   : {len(reads)}")
    for addr in reads:
        print(f"    · {addr}")
if tolerated:
    label = "tolerated"
    print(f"{YELLOW}{label:<20}: {len(tolerated)}{RESET}")
    for addr, attrs in tolerated:
        print(f"    ~ {addr}  [{', '.join(attrs)}]")

if skipped:
    label = "skipped (--ignore-type)"
    print(f"{YELLOW}{label:<20}: {len(skipped)}{RESET}")
    for addr, action in skipped:
        print(f"    · {addr}  [{action}]")

if waived:
    print()
    print(f"{YELLOW}WAIVED{RESET}: {len(waived)} resource(s) have a real diff that was explicitly")
    print("        accepted via --allow-resource or --allow-file. These DO change Azure.")
    for addr, attrs in waived:
        print(f"    ! {addr}  attrs: {', '.join(attrs)}")
        if addr in pinned:
            print(f"        reason: {pinned[addr][1]}")

stale = sorted(set(pinned) - pinned_seen)
if stale:
    print()
    print(f"{YELLOW}STALE{RESET}: {len(stale)} allow-file entr(y/ies) matched no diff in this plan.")
    print("        Remove them once the resource is applied or the diff is gone.")
    for addr in stale:
        print(f"    - {addr}")

if replacements:
    print()
    print(f"{RED}FAIL{RESET}: {len(replacements)} resource(s) would be DESTROYED AND RECREATED.")
    print("      This is not a diff to reconcile -- it destroys the live resource")
    print("      and everything inside it. It means a ForceNew attribute in tfvars")
    print("      disagrees with reality (a role assignment's scope casing or its")
    print("      description are the usual causes here).")
    print()
    for addr, attrs in replacements:
        detail = f"  attrs: {', '.join(attrs)}" if attrs else ""
        print(f"    {RED}replace {RESET} {addr}{detail}")
    print()
    raise SystemExit(1)

if not imported and not noop and not tolerated and not violations:
    print(f"{RED}FAIL{RESET}: the plan contains no resource changes at all.")
    print("      Either the import blocks were already applied and removed, or")
    print("      every enable_* flag is false for this tfvars file.")
    raise SystemExit(1)

if violations:
    print()
    print(f"{RED}FAIL{RESET}: {len(violations)} resource(s) would be modified in Azure.")
    print("      An import is supposed to adopt what exists, not change it.")
    print("      Each line below is a place where tfvars does not match reality.")
    print()
    for addr, action, attrs in violations:
        detail = f"  attrs: {', '.join(attrs)}" if attrs else ""
        print(f"    {RED}{action:<8}{RESET} {addr}{detail}")
    print()
    print("      Fix by copying the live value out of the ARM export into the")
    print("      matching tfvars field -- do not 'fix' it by changing Azure.")
    raise SystemExit(1)

print()
print(f"{GREEN}PASS{RESET}: plan adopts {len(imported)} resource(s) and changes nothing else.")
if tolerated and not strict:
    print("      Tolerated updates are listed above. Tag changes there only add")
    print("      keys (the wrapper's managed-by/module tags); removing or changing")
    print("      an existing tag fails the gate. Anything else listed there")
    print("      was passed by --ignore-attr or --subset-attr -- check those flags")
    print("      still describe what you mean before trusting a PASS.")
raise SystemExit(0)
PYTHON
