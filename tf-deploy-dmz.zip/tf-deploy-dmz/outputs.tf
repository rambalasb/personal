output "resource_group_ids" {
  description = "Resource group IDs, keyed by role."
  value       = { for k, m in module.resource_group : k => m.resource_id }
}

output "virtual_network_id" {
  value = module.virtual_network.resource_id
}

output "key_vault_id" {
  value = module.key_vault.resource_id
}
