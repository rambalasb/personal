output "resource_id" {
  description = "The Azure resource ID of the Application Gateway."
  value       = module.application_gateway.resource_id
}

output "application_gateway_id" {
  description = "The resource ID of the Application Gateway (alias exposed by the AVM module)."
  value       = module.application_gateway.application_gateway_id
}

output "application_gateway_name" {
  description = "The name of the Application Gateway."
  value       = module.application_gateway.application_gateway_name
}

output "public_ip_id" {
  description = "The resource ID of the public IP used by the gateway frontend."
  value       = module.application_gateway.public_ip_id
}

output "new_public_ip_address" {
  description = "The public IP address allocated when the module creates the frontend public IP."
  value       = module.application_gateway.new_public_ip_address
}
