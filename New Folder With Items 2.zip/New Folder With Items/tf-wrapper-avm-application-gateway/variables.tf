# =====================================================================
# Required inputs
# =====================================================================

variable "name" {
  type        = string
  description = "Name of the Application Gateway. 1-80 chars; alphanumerics, underscores, periods, hyphens. Must start with alphanumeric."

  validation {
    condition     = can(regex("^[a-zA-Z0-9][a-zA-Z0-9._-]{0,78}[a-zA-Z0-9_]$", var.name))
    error_message = "name must be 1-80 characters, start with an alphanumeric, and contain only alphanumerics, underscores, periods, or hyphens."
  }
}

variable "resource_group_name" {
  type        = string
  description = "Name of the Resource Group where the Application Gateway will be deployed."

  validation {
    condition     = length(var.resource_group_name) > 0 && length(var.resource_group_name) <= 90
    error_message = "resource_group_name must be 1-90 characters."
  }
}

variable "location" {
  type        = string
  description = "Azure region where the Application Gateway will be deployed."

  validation {
    condition     = length(var.location) > 0
    error_message = "location must not be empty."
  }
}

variable "gateway_ip_configuration" {
  type = object({
    name      = optional(string)
    subnet_id = string
  })
  description = "IP configuration binding the gateway to its dedicated subnet. subnet_id must reference a subnet used only by this Application Gateway."
}

variable "frontend_ports" {
  type = map(object({
    name = string
    port = number
  }))
  description = "Frontend ports the gateway listens on, keyed by a logical name. Referenced by http_listeners via frontend_port_name."
}

variable "backend_address_pools" {
  type = map(object({
    name         = string
    fqdns        = optional(set(string))
    ip_addresses = optional(set(string))
  }))
  description = "Backend address pools, keyed by a logical name. Provide fqdns and/or ip_addresses. Referenced by request_routing_rules via backend_address_pool_name."
}

variable "backend_http_settings" {
  type = map(object({
    cookie_based_affinity                = optional(string, "Disabled")
    dedicated_backend_connection_enabled = optional(bool, false)
    name                                 = string
    port                                 = number
    protocol                             = string
    affinity_cookie_name                 = optional(string)
    host_name                            = optional(string)
    path                                 = optional(string)
    pick_host_name_from_backend_address  = optional(bool)
    probe_name                           = optional(string)
    request_timeout                      = optional(number)
    trusted_root_certificate_names       = optional(list(string))
    authentication_certificate = optional(list(object({
      name = string
    })))
    connection_draining = optional(object({
      drain_timeout_sec          = number
      enable_connection_draining = bool
    }))
  }))
  description = "Backend HTTP settings (port, protocol, timeouts, affinity), keyed by a logical name. Referenced by request_routing_rules via backend_http_settings_name."
}

variable "http_listeners" {
  type = map(object({
    name                           = string
    frontend_port_name             = string
    frontend_ip_configuration_name = optional(string)
    firewall_policy_id             = optional(string)
    require_sni                    = optional(bool)
    host_name                      = optional(string)
    host_names                     = optional(list(string))
    ssl_certificate_name           = optional(string)
    ssl_profile_name               = optional(string)
    custom_error_configuration = optional(list(object({
      status_code           = string
      custom_error_page_url = string
    })))
  }))
  description = "HTTP listeners, keyed by a logical name. frontend_port_name must match a key/name in frontend_ports. Set ssl_certificate_name for HTTPS listeners."
}

variable "request_routing_rules" {
  type = map(object({
    name                        = string
    rule_type                   = string
    http_listener_name          = string
    backend_address_pool_name   = string
    priority                    = number
    url_path_map_name           = optional(string)
    backend_http_settings_name  = string
    redirect_configuration_name = optional(string)
    rewrite_rule_set_name       = optional(string)
  }))
  description = "Routing rules wiring a listener to a backend pool + HTTP settings. rule_type is 'Basic' or 'PathBasedRouting'. priority is required and must be unique."
}

# =====================================================================
# Sizing
# =====================================================================

variable "sku" {
  type = object({
    name     = string
    tier     = string
    capacity = optional(number, 2)
  })
  description = "Gateway SKU. name/tier must be 'Standard_v2' or 'WAF_v2'. Use 'WAF_v2' to attach a WAF policy. capacity is ignored when autoscale_configuration is set."
  default = {
    name     = "Standard_v2"
    tier     = "Standard_v2"
    capacity = 2
  }

  validation {
    condition     = contains(["Standard_v2", "WAF_v2"], var.sku.name) && contains(["Standard_v2", "WAF_v2"], var.sku.tier)
    error_message = "sku.name and sku.tier must each be 'Standard_v2' or 'WAF_v2'."
  }
}

variable "autoscale_configuration" {
  type = object({
    min_capacity = optional(number, 1)
    max_capacity = optional(number, 2)
  })
  description = "Autoscale bounds. When set, the gateway scales between min_capacity and max_capacity and the fixed sku.capacity is ignored. Leave null for fixed capacity."
  default     = null
}

variable "zones" {
  type        = set(string)
  description = "Availability zones for the gateway. Defaults to all three zones. Set to [] for regions without zone support."
  default     = ["1", "2", "3"]

  validation {
    condition     = alltrue([for z in var.zones : contains(["1", "2", "3"], z)])
    error_message = "Each zone must be '1', '2', or '3'."
  }
}

# =====================================================================
# Frontend public IP
# =====================================================================

variable "public_ip_address_configuration" {
  type = object({
    resource_group_name              = optional(string)
    location                         = optional(string)
    create_public_ip_enabled         = optional(bool, true)
    public_ip_name                   = optional(string)
    public_ip_resource_id            = optional(string)
    allocation_method                = optional(string, "Static")
    ddos_protection_mode             = optional(string, "VirtualNetworkInherited")
    ddos_protection_plan_resource_id = optional(string)
    domain_name_label                = optional(string)
    idle_timeout_in_minutes          = optional(number, 4)
    ip_version                       = optional(string, "IPv4")
    public_ip_prefix_resource_id     = optional(string)
    reverse_fqdn                     = optional(string)
    sku                              = optional(string, "Standard")
    sku_tier                         = optional(string, "Regional")
    tags                             = optional(map(any), {})
    zones                            = optional(list(string))
  })
  description = "Public frontend IP. By default the module creates a Standard static public IP — set public_ip_name. To reuse an existing IP set create_public_ip_enabled = false and public_ip_resource_id."
  default     = {}
}

# =====================================================================
# TLS / health probes / WAF policy
# =====================================================================

variable "ssl_certificates" {
  type = map(object({
    name                = string
    data                = optional(string)
    password            = optional(string)
    key_vault_secret_id = optional(string)
  }))
  description = "SSL certificates for HTTPS listeners, keyed by a logical name. Provide either data+password (PFX) or key_vault_secret_id."
  default     = null
}

variable "probe_configurations" {
  type = map(object({
    name                                      = string
    host                                      = optional(string)
    interval                                  = number
    timeout                                   = number
    unhealthy_threshold                       = number
    protocol                                  = string
    port                                      = optional(number)
    path                                      = string
    pick_host_name_from_backend_http_settings = optional(bool)
    minimum_servers                           = optional(number)
    match = optional(object({
      body        = optional(string)
      status_code = optional(list(string))
    }))
  }))
  description = "Custom health probes, keyed by a logical name. Referenced from backend_http_settings via probe_name."
  default     = null
}

variable "app_gateway_waf_policy_resource_id" {
  type        = string
  description = "Resource ID of a WAF policy to associate at the gateway level. Requires sku name/tier 'WAF_v2'. Leave null for no WAF."
  default     = null

  validation {
    condition     = var.app_gateway_waf_policy_resource_id == null || (var.sku.name == "WAF_v2" && var.sku.tier == "WAF_v2")
    error_message = "app_gateway_waf_policy_resource_id requires sku name and tier 'WAF_v2'."
  }
}

# =====================================================================
# AVM interfaces
# =====================================================================

variable "managed_identities" {
  type = object({
    system_assigned            = optional(bool, false)
    user_assigned_resource_ids = optional(set(string), [])
  })
  description = "Managed identity configuration. A user-assigned identity is required to read SSL certificates from Key Vault."
  default     = {}
}

variable "role_assignments" {
  type = map(object({
    role_definition_id_or_name             = string
    principal_id                           = string
    description                            = optional(string, null)
    skip_service_principal_aad_check       = optional(bool, false)
    condition                              = optional(string, null)
    condition_version                      = optional(string, null)
    delegated_managed_identity_resource_id = optional(string, null)
    principal_type                         = optional(string, null)
  }))
  description = "Role assignments to create on the Application Gateway, keyed by a logical name."
  default     = {}
}

variable "diagnostic_settings" {
  type = map(object({
    name                                     = optional(string, null)
    log_categories                           = optional(set(string), [])
    log_groups                               = optional(set(string), ["allLogs"])
    metric_categories                        = optional(set(string), ["AllMetrics"])
    log_analytics_destination_type           = optional(string, "Dedicated")
    workspace_resource_id                    = optional(string, null)
    storage_account_resource_id              = optional(string, null)
    event_hub_authorization_rule_resource_id = optional(string, null)
    event_hub_name                           = optional(string, null)
    marketplace_partner_resource_id          = optional(string, null)
  }))
  description = "Diagnostic settings for the Application Gateway, keyed by a logical name."
  default     = {}
}

variable "lock" {
  type = object({
    kind = string
    name = optional(string, null)
  })
  description = "Optional resource lock. kind must be 'CanNotDelete' or 'ReadOnly'."
  default     = null

  validation {
    condition     = var.lock == null || contains(["CanNotDelete", "ReadOnly"], try(var.lock.kind, ""))
    error_message = "lock.kind must be 'CanNotDelete' or 'ReadOnly' when lock is set."
  }
}

# =====================================================================
# Module behavior
# =====================================================================

variable "enable_telemetry" {
  type        = bool
  description = "Whether to enable AVM module telemetry. Set false to opt out."
  default     = true
}

variable "tags" {
  type        = map(string)
  description = "A map of tags to apply to the Application Gateway."
  default     = null
}