terraform {
  required_version = ">= 1.9, < 2.0"

  required_providers {
    # AVM avm-res-network-applicationgateway v0.5.2 requires azurerm >= 3.117, so this
    # constraint is one patch tighter than the >= 3.116 baseline used by sibling wrappers.
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 3.117, < 5.0"
    }
  }
}
