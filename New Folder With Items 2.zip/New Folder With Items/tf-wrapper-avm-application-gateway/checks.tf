# Post-plan/apply advisory checks. These surface as warnings (never block apply) and
# assert cross-configuration invariants that the AVM module does not enforce on its own.

check "waf_sku_has_waf_policy" {
  assert {
    condition     = var.sku.tier != "WAF_v2" || var.waf_configuration != null || var.app_gateway_waf_policy_resource_id != null
    error_message = "A WAF_v2 tier Application Gateway should have a WAF configured. Provide either waf_configuration or app_gateway_waf_policy_resource_id."
  }
}

check "waf_policy_only_on_waf_sku" {
  assert {
    condition     = (var.waf_configuration == null && var.app_gateway_waf_policy_resource_id == null) || var.sku.tier == "WAF_v2"
    error_message = "waf_configuration / app_gateway_waf_policy_resource_id only take effect on a WAF_v2 tier. Set sku.tier = \"WAF_v2\" or remove the WAF settings."
  }
}

check "capacity_or_autoscale" {
  assert {
    condition     = var.autoscale_configuration != null || (var.sku.capacity != null && var.sku.capacity >= 1)
    error_message = "When autoscale_configuration is not set, sku.capacity must be a fixed value >= 1."
  }
}

check "zone_redundancy_recommended" {
  assert {
    condition     = length(var.zones) > 1
    error_message = "For production resilience, deploy the Application Gateway across more than one availability zone (e.g. zones = [\"1\", \"2\", \"3\"])."
  }
}
