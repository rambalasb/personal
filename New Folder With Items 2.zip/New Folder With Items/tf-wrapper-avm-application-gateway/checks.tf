check "waf_sku_for_internet_facing" {
  assert {
    condition     = var.sku.name == "WAF_v2"
    error_message = "Application Gateway SKU is '${var.sku.name}'. Internet-facing gateways should use 'WAF_v2' with an attached WAF policy. Use 'Standard_v2' only for internal traffic with no WAF requirement."
  }
}

check "zonal_redundancy" {
  assert {
    condition     = length(var.zones) >= 2 || length(var.zones) == 0
    error_message = "Application Gateway is configured with ${length(var.zones)} zone(s). Use 2 or more zones for zonal resilience, or [] in regions without availability zones."
  }
}

check "public_ip_allocation_is_static" {
  assert {
    condition     = try(var.public_ip_address_configuration.allocation_method, "Static") == "Static"
    error_message = "Application Gateway v2 requires a Static public IP allocation. Set public_ip_address_configuration.allocation_method = 'Static'."
  }
}
