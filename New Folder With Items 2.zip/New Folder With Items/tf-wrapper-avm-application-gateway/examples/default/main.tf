module "application_gateway" {
  source = "../.."

  name                = "agw-avm-default-test-${random_string.suffix.result}"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location

  gateway_ip_configuration = {
    name      = "appGatewayIpConfig"
    subnet_id = azurerm_subnet.appgw.id
  }

  # reuse the pre-created public IP rather than letting the module create one
  public_ip_address_configuration = {
    create_public_ip_enabled = false
    public_ip_resource_id    = azurerm_public_ip.this.id
  }

  frontend_ports = {
    port_80 = {
      name = "port-80"
      port = 80
    }
  }

  http_listeners = {
    listener_http = {
      name               = "listener-http"
      frontend_port_name = "port-80"
    }
  }

  backend_address_pools = {
    pool_default = {
      name  = "pool-default"
      fqdns = ["backend.example.com"]
    }
  }

  backend_http_settings = {
    http_default = {
      name                  = "http-default"
      port                  = 80
      protocol              = "Http"
      cookie_based_affinity = "Disabled"
    }
  }

  request_routing_rules = {
    rule_basic = {
      name                       = "rule-basic"
      rule_type                  = "Basic"
      priority                   = 100
      http_listener_name         = "listener-http"
      backend_address_pool_name  = "pool-default"
      backend_http_settings_name = "http-default"
    }
  }

  sku = {
    name     = "Standard_v2"
    tier     = "Standard_v2"
    capacity = 2
  }

  enable_telemetry = false
}
