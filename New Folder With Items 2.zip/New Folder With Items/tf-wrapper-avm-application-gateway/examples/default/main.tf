module "application_gateway" {
  source = "../.."

  name                = "appgw-avm-default-${random_string.suffix.result}"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location

  gateway_ip_configuration = {
    name      = "gw-ipcfg"
    subnet_id = azurerm_subnet.appgw.id
  }

  # module creates the frontend public IP; a name is mandatory
  public_ip_address_configuration = {
    public_ip_name = "pip-appgw-${random_string.suffix.result}"
  }

  frontend_ports = {
    port80 = { name = "fe-port-80", port = 80 }
  }

  backend_address_pools = {
    pool1 = { name = "be-pool", ip_addresses = ["10.0.2.10"] }
  }

  backend_http_settings = {
    http = {
      name                  = "be-http"
      port                  = 80
      protocol              = "Http"
      cookie_based_affinity = "Disabled"
    }
  }

  http_listeners = {
    l1 = {
      name               = "http-listener"
      frontend_port_name = "fe-port-80"
    }
  }

  request_routing_rules = {
    r1 = {
      name                       = "rule1"
      rule_type                  = "Basic"
      http_listener_name         = "http-listener"
      backend_address_pool_name  = "be-pool"
      backend_http_settings_name = "be-http"
      priority                   = 100
    }
  }

  enable_telemetry = false
}
