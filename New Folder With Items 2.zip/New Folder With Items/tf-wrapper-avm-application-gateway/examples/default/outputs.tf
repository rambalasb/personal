output "resource_id" {
  value = module.application_gateway.resource_id
}

output "application_gateway_name" {
  value = module.application_gateway.application_gateway_name
}

output "new_public_ip_address" {
  value = module.application_gateway.new_public_ip_address
}
