output "resource_id" {
  value = module.application_gateway.resource_id
}

output "application_gateway_name" {
  value = module.application_gateway.application_gateway_name
}

output "public_ip_id" {
  value = module.application_gateway.public_ip_id
}
