module "application_gateway" {
  source  = "Azure/avm-res-network-applicationgateway/azurerm"
  version = "0.5.2"

  # Required
  name                     = var.name
  resource_group_name      = var.resource_group_name
  location                 = var.location
  gateway_ip_configuration = var.gateway_ip_configuration
  frontend_ports           = var.frontend_ports
  http_listeners           = var.http_listeners
  backend_address_pools    = var.backend_address_pools
  backend_http_settings    = var.backend_http_settings
  request_routing_rules    = var.request_routing_rules

  # SKU, scaling & availability
  sku                     = var.sku
  autoscale_configuration = var.autoscale_configuration
  zones                   = var.zones
  enable_telemetry        = var.enable_telemetry
  tags                    = local.module_tags

  # Frontend IP & public IP
  public_ip_address_configuration       = var.public_ip_address_configuration
  frontend_ip_configuration_public_name = var.frontend_ip_configuration_public_name
  frontend_ip_configuration_private     = var.frontend_ip_configuration_private
  private_link_configuration            = var.private_link_configuration

  # Protocol & gateway-wide behaviour
  http2_enable = var.http2_enable
  fips_enabled = var.fips_enabled
  global       = var.global

  # WAF
  waf_configuration                  = var.waf_configuration
  app_gateway_waf_policy_resource_id = var.app_gateway_waf_policy_resource_id
  force_firewall_policy_association  = var.force_firewall_policy_association

  # Certificates & SSL
  ssl_certificates           = var.ssl_certificates
  ssl_policy                 = var.ssl_policy
  ssl_profile                = var.ssl_profile
  trusted_client_certificate = var.trusted_client_certificate
  trusted_root_certificate   = var.trusted_root_certificate
  authentication_certificate = var.authentication_certificate

  # Routing extras: redirects, rewrites, URL path maps, probes, custom errors
  redirect_configuration      = var.redirect_configuration
  rewrite_rule_set            = var.rewrite_rule_set
  url_path_map_configurations = var.url_path_map_configurations
  probe_configurations        = var.probe_configurations
  custom_error_configuration  = var.custom_error_configuration

  # Identity, RBAC, locks, diagnostics
  managed_identities  = var.managed_identities
  role_assignments    = var.role_assignments
  lock                = var.lock
  diagnostic_settings = var.diagnostic_settings

  # azapi operation tuning
  timeouts = var.timeouts
}
