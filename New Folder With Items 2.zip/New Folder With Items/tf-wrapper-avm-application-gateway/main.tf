module "application_gateway" {
  source  = "Azure/avm-res-network-applicationgateway/azurerm"
  version = "0.5.2"

  # Required
  name                = var.name
  resource_group_name = var.resource_group_name
  location            = var.location

  gateway_ip_configuration = var.gateway_ip_configuration
  frontend_ports           = var.frontend_ports
  backend_address_pools    = var.backend_address_pools
  backend_http_settings    = var.backend_http_settings
  http_listeners           = var.http_listeners
  request_routing_rules    = var.request_routing_rules

  # Sizing
  sku                     = var.sku
  autoscale_configuration = var.autoscale_configuration
  zones                   = var.zones

  # Frontend public IP — module-created by default (see public_ip_address_configuration)
  public_ip_address_configuration = var.public_ip_address_configuration

  # TLS / health probes / WAF policy linkage
  ssl_certificates                   = var.ssl_certificates
  probe_configurations               = var.probe_configurations
  app_gateway_waf_policy_resource_id = var.app_gateway_waf_policy_resource_id

  # AVM interfaces
  managed_identities  = var.managed_identities
  role_assignments    = var.role_assignments
  diagnostic_settings = var.diagnostic_settings
  lock                = var.lock
  enable_telemetry    = var.enable_telemetry
  tags                = local.module_tags
}
