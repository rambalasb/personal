module "application_insights" {
  source  = "Azure/avm-res-insights-component/azurerm"
  version = "0.4.0"

  # Required (workspace-based: workspace_id is the Log Analytics workspace ID)
  name                = var.name
  resource_group_name = var.resource_group_name
  location            = var.location
  workspace_id        = var.workspace_id

  # Component configuration
  application_type                      = var.application_type
  retention_in_days                     = var.retention_in_days
  sampling_percentage                   = var.sampling_percentage
  daily_data_cap_in_gb                  = var.daily_data_cap_in_gb
  daily_data_cap_notifications_disabled = var.daily_data_cap_notifications_disabled
  local_authentication_disabled         = var.local_authentication_disabled
  internet_ingestion_enabled            = var.internet_ingestion_enabled
  internet_query_enabled                = var.internet_query_enabled
  disable_ip_masking                    = var.disable_ip_masking

  # AVM interfaces
  role_assignments    = var.role_assignments
  diagnostic_settings = var.diagnostic_settings
  lock                = var.lock
  enable_telemetry    = var.enable_telemetry
  tags                = local.module_tags
}
