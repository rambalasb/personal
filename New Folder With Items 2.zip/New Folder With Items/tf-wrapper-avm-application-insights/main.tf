module "application_insights" {
  source  = "Azure/avm-res-insights-component/azurerm"
  version = "0.4.0"

  # Required
  name                = var.name
  resource_group_name = var.resource_group_name
  location            = var.location
  workspace_id        = var.workspace_id

  # Component core
  application_type  = var.application_type
  retention_in_days = var.retention_in_days
  enable_telemetry  = var.enable_telemetry
  tags              = local.module_tags

  # Data volume & sampling
  daily_data_cap_in_gb                  = var.daily_data_cap_in_gb
  daily_data_cap_notifications_disabled = var.daily_data_cap_notifications_disabled
  sampling_percentage                   = var.sampling_percentage

  # Privacy, auth & profiler
  disable_ip_masking                  = var.disable_ip_masking
  local_authentication_disabled       = var.local_authentication_disabled
  force_customer_storage_for_profiler = var.force_customer_storage_for_profiler
  linked_storage_account              = var.linked_storage_account

  # Networking
  internet_ingestion_enabled = var.internet_ingestion_enabled
  internet_query_enabled     = var.internet_query_enabled
  monitor_private_link_scope = var.monitor_private_link_scope

  # RBAC, locks, diagnostics
  role_assignments    = var.role_assignments
  lock                = var.lock
  diagnostic_settings = var.diagnostic_settings

  # azapi operation tuning
  retry    = var.retry
  timeouts = var.timeouts
}
