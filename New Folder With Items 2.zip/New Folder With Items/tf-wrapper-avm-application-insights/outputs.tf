output "resource_id" {
  description = "The Azure resource ID of the Application Insights component."
  value       = module.application_insights.resource_id
}

output "name" {
  description = "The name of the Application Insights component."
  value       = module.application_insights.name
}

output "instrumentation_key" {
  description = "The instrumentation key for the component. Prefer connection_string for new SDKs."
  value       = module.application_insights.instrumentation_key
  sensitive   = true
}

output "connection_string" {
  description = "The connection string for the component. Use this to configure the Application Insights SDK."
  value       = module.application_insights.connection_string
  sensitive   = true
}

output "app_id" {
  description = "The App ID used with the Application Insights Data Access API."
  value       = module.application_insights.app_id
  sensitive   = true
}
