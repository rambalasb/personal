output "resource_id" {
  description = "The resource ID of the Application Insights component."
  value       = module.application_insights.resource_id
}

output "name" {
  description = "The name of the Application Insights component."
  value       = module.application_insights.name
}

output "resource" {
  description = "The full azurerm_application_insights resource output object."
  value       = module.application_insights.resource
}

output "app_id" {
  description = "The App ID of the Application Insights component."
  value       = module.application_insights.app_id
  sensitive   = true
}

output "connection_string" {
  description = "The connection string of the Application Insights component."
  value       = module.application_insights.connection_string
  sensitive   = true
}

output "instrumentation_key" {
  description = "The instrumentation key of the Application Insights component."
  value       = module.application_insights.instrumentation_key
}
