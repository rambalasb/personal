output "resource_id" {
  description = "The resource ID of the Application Insights component."
  value       = module.application_insights.resource_id
}

output "name" {
  description = "The name of the Application Insights component."
  value       = module.application_insights.name
}
