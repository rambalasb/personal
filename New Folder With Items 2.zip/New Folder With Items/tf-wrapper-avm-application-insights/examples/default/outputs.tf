output "resource_id" {
  value = module.application_insights.resource_id
}

output "name" {
  value = module.application_insights.name
}

output "connection_string" {
  value     = module.application_insights.connection_string
  sensitive = true
}
