module "application_insights" {
  source = "../.."

  name                = "appi-avm-appi-default-test-${random_string.suffix.result}"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location
  workspace_id        = azurerm_log_analytics_workspace.this.id

  application_type = "web"
  enable_telemetry = false
}
