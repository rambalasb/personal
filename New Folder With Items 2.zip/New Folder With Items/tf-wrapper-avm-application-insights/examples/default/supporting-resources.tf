# random suffix to avoid name collisions on reruns
resource "random_string" "suffix" {
  length  = 6
  lower   = true
  upper   = false
  numeric = true
  special = false
}

# native supporting RG so the example tests standalone
resource "azurerm_resource_group" "this" {
  name     = "rg-avm-appi-default-test-${random_string.suffix.result}"
  location = "canadacentral"
}

# workspace-based App Insights requires a Log Analytics workspace to back it
resource "azurerm_log_analytics_workspace" "this" {
  name                = "law-appi-${random_string.suffix.result}"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location
  sku                 = "PerGB2018"
  retention_in_days   = 30
}
