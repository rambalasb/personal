check "local_authentication_disabled" {
  assert {
    condition     = var.local_authentication_disabled
    error_message = "Application Insights allows local (instrumentation key) authentication. Set local_authentication_disabled = true to require Entra ID auth where your SDKs support it."
  }
}

check "full_sampling" {
  assert {
    condition     = var.sampling_percentage == 100
    error_message = "sampling_percentage is ${var.sampling_percentage}. Below 100, telemetry is dropped and dashboards/alerts may undercount. Reduce only deliberately for cost control."
  }
}
