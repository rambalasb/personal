# Post-plan/apply advisory checks. These surface as warnings (never block apply) and
# assert compliance / cross-configuration invariants that the AVM module does not enforce.

check "local_authentication_disabled" {
  assert {
    condition     = var.local_authentication_disabled
    error_message = "Application Insights should disable local (API key) authentication in favour of Azure AD. Set local_authentication_disabled = true to comply."
  }
}

check "private_link_scope_disables_public_access" {
  assert {
    condition     = length(var.monitor_private_link_scope) == 0 || (!var.internet_ingestion_enabled && !var.internet_query_enabled)
    error_message = "When a monitor_private_link_scope is configured, public access should be closed. Set internet_ingestion_enabled = false and internet_query_enabled = false."
  }
}

check "retention_is_supported_value" {
  assert {
    condition     = contains([0, 30, 60, 90, 120, 180, 270, 365, 550, 730], var.retention_in_days)
    error_message = "retention_in_days must be 0 (unlimited) or one of the Azure-supported values: 30, 60, 90, 120, 180, 270, 365, 550, 730."
  }
}
