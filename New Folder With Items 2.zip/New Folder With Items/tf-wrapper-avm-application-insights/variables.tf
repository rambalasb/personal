# =====================================================================
# Required inputs
# =====================================================================

variable "name" {
  type        = string
  description = "Name of the Application Insights component. 1-255 chars; alphanumerics, periods, underscores, hyphens, parentheses. Cannot end with a period."

  validation {
    condition     = can(regex("^[A-Za-z0-9._()-]{1,254}[A-Za-z0-9_()-]$", var.name))
    error_message = "name must be 1-255 characters of alphanumerics, periods, underscores, hyphens, or parentheses, and must not end with a period."
  }
}

variable "resource_group_name" {
  type        = string
  description = "Name of the Resource Group where Application Insights will be deployed."

  validation {
    condition     = length(var.resource_group_name) > 0 && length(var.resource_group_name) <= 90
    error_message = "resource_group_name must be 1-90 characters."
  }
}

variable "location" {
  type        = string
  description = "Azure region where Application Insights will be deployed."

  validation {
    condition     = length(var.location) > 0
    error_message = "location must not be empty."
  }
}

variable "workspace_id" {
  type        = string
  description = "Resource ID of the Log Analytics workspace that backs this component. Required — classic (non-workspace) Application Insights is retired."

  validation {
    condition     = can(regex("/workspaces/", var.workspace_id))
    error_message = "workspace_id must be a Log Analytics workspace resource ID (containing '/workspaces/')."
  }
}

# =====================================================================
# Component configuration
# =====================================================================

variable "application_type" {
  type        = string
  description = "Application type the component monitors. Most workloads use 'web'."
  default     = "web"

  validation {
    condition     = contains(["ios", "java", "MobileCenter", "Node.JS", "other", "phone", "store", "web"], var.application_type)
    error_message = "application_type must be one of: ios, java, MobileCenter, Node.JS, other, phone, store, web."
  }
}

variable "retention_in_days" {
  type        = number
  description = "Data retention in days for the component's own data."
  default     = 90

  validation {
    condition     = contains([30, 60, 90, 120, 180, 270, 365, 550, 730], var.retention_in_days)
    error_message = "retention_in_days must be one of: 30, 60, 90, 120, 180, 270, 365, 550, 730."
  }
}

variable "sampling_percentage" {
  type        = number
  description = "Percentage of telemetry ingested. 100 keeps everything; lower values reduce cost at the expense of data fidelity."
  default     = 100

  validation {
    condition     = var.sampling_percentage > 0 && var.sampling_percentage <= 100
    error_message = "sampling_percentage must be greater than 0 and at most 100."
  }
}

variable "daily_data_cap_in_gb" {
  type        = number
  description = "Daily ingestion cap in GB. Ingestion stops for the day once exceeded."
  default     = 100

  validation {
    condition     = var.daily_data_cap_in_gb > 0
    error_message = "daily_data_cap_in_gb must be greater than 0."
  }
}

variable "daily_data_cap_notifications_disabled" {
  type        = bool
  description = "Whether to disable email notifications when the daily data cap is reached."
  default     = false
}

variable "local_authentication_disabled" {
  type        = bool
  description = "Whether to disable non-Entra (API key / instrumentation key) authentication. Recommended true to require Entra ID auth."
  default     = false
}

variable "internet_ingestion_enabled" {
  type        = bool
  description = "Whether telemetry can be ingested from the public internet. Set false when using Private Link."
  default     = true
}

variable "internet_query_enabled" {
  type        = bool
  description = "Whether the component can be queried from the public internet. Set false when using Private Link."
  default     = true
}

variable "disable_ip_masking" {
  type        = bool
  description = "Whether to store client IP addresses unmasked. Leave false to mask IPs (recommended for privacy)."
  default     = false
}

# =====================================================================
# AVM interfaces
# =====================================================================

variable "role_assignments" {
  type = map(object({
    role_definition_id_or_name             = string
    principal_id                           = string
    description                            = optional(string, null)
    skip_service_principal_aad_check       = optional(bool, false)
    condition                              = optional(string, null)
    condition_version                      = optional(string, null)
    delegated_managed_identity_resource_id = optional(string, null)
    principal_type                         = optional(string, null)
  }))
  description = "Role assignments to create on the Application Insights component, keyed by a logical name."
  default     = {}
}

variable "diagnostic_settings" {
  type = map(object({
    name = optional(string, null)
    logs = optional(set(object({
      category       = optional(string, null)
      category_group = optional(string, null)
      enabled        = optional(bool, true)
      retention_policy = optional(object({
        days    = optional(number, 0)
        enabled = optional(bool, false)
      }), {})
    })), [])
    metrics = optional(set(object({
      category = optional(string, null)
      enabled  = optional(bool, true)
      retention_policy = optional(object({
        days    = optional(number, 0)
        enabled = optional(bool, false)
      }), {})
    })), [])
    log_analytics_destination_type           = optional(string, "Dedicated")
    workspace_resource_id                    = optional(string, null)
    storage_account_resource_id              = optional(string, null)
    event_hub_authorization_rule_resource_id = optional(string, null)
    event_hub_name                           = optional(string, null)
    marketplace_partner_resource_id          = optional(string, null)
  }))
  description = "Diagnostic settings for the component, keyed by a logical name."
  default     = {}
}

variable "lock" {
  type = object({
    kind = string
    name = optional(string, null)
  })
  description = "Optional resource lock. kind must be 'CanNotDelete' or 'ReadOnly'."
  default     = null

  validation {
    condition     = var.lock == null || contains(["CanNotDelete", "ReadOnly"], try(var.lock.kind, ""))
    error_message = "lock.kind must be 'CanNotDelete' or 'ReadOnly' when lock is set."
  }
}

# =====================================================================
# Module behavior
# =====================================================================

variable "enable_telemetry" {
  type        = bool
  description = "Whether to enable AVM module telemetry. Set false to opt out."
  default     = true
}

variable "tags" {
  type        = map(string)
  description = "A map of tags to apply to the Application Insights component."
  default     = null
}
