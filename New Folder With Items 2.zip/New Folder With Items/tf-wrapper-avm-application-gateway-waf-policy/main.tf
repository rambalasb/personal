module "waf_policy" {
  source  = "Azure/avm-res-network-applicationgatewaywebapplicationfirewallpolicy/azurerm"
  version = "0.2.0"

  # Required
  name                = var.name
  resource_group_name = var.resource_group_name
  location            = var.location
  managed_rules       = var.managed_rules

  # Rules & policy behaviour
  custom_rules    = var.custom_rules
  policy_settings = var.policy_settings

  # RBAC & locks
  role_assignments = var.role_assignments
  lock             = var.lock

  # Telemetry, tagging & operation tuning
  enable_telemetry = var.enable_telemetry
  tags             = local.module_tags
  timeouts         = var.timeouts
}
