output "resource_id" {
  value = module.waf_policy.resource_id
}

output "name" {
  value = module.waf_policy.name
}

output "http_listener_ids" {
  value = module.waf_policy.http_listener_ids
}

output "path_based_rule_ids" {
  value = module.waf_policy.path_based_rule_ids
}
