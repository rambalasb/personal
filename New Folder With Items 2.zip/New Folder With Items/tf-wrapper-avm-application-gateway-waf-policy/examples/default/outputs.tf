output "resource_id" {
  value = module.waf_policy.resource_id
}

output "name" {
  value = module.waf_policy.name
}
