module "waf_policy" {
  source = "../.."

  name                = "waf-avm-default-test-${random_string.suffix.result}"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location

  # minimal valid ruleset; OWASP 3.2 is the WAF default
  managed_rules = {
    managed_rule_set = {
      owasp = {
        type    = "OWASP"
        version = "3.2"
      }
    }
  }

  enable_telemetry = false
}
