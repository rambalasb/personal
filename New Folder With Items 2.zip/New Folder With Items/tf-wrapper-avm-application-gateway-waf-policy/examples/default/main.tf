module "waf_policy" {
  source = "../.."

  name                = "wafpolicyavmdefault${random_string.suffix.result}"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location

  managed_rules = {
    managed_rule_set = {
      owasp = {
        type    = "OWASP"
        version = "3.2"
      }
    }
  }

  policy_settings = {
    enabled = true
    mode    = "Prevention"
  }

  enable_telemetry = false
}
