terraform {
  required_version = ">= 1.9, < 2.0"

  required_providers {
    # AVM avm-res-network-applicationgatewaywebapplicationfirewallpolicy v0.2.0 requires
    # azurerm ~> 4.2, so this constraint is tighter than the >= 3.116 baseline used by
    # some sibling wrappers.
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 4.2, < 5.0"
    }
  }
}
