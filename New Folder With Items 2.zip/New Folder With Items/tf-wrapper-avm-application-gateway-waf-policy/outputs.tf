output "resource_id" {
  description = "The Azure resource ID of the WAF policy. Pass this to an Application Gateway via app_gateway_waf_policy_resource_id."
  value       = module.waf_policy.resource_id
}

output "name" {
  description = "The name of the WAF policy."
  value       = module.waf_policy.name
}
