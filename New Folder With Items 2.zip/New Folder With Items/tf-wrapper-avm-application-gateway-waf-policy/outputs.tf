output "resource_id" {
  description = "The ID of the WAF Policy."
  value       = module.waf_policy.resource_id
}

output "name" {
  description = "The name of the WAF Policy."
  value       = module.waf_policy.name
}

output "http_listener_ids" {
  description = "The IDs of the HTTP Listeners associated with the WAF Policy."
  value       = module.waf_policy.http_listener_ids
}

output "path_based_rule_ids" {
  description = "The IDs of the Path Based Rules associated with the WAF Policy."
  value       = module.waf_policy.path_based_rule_ids
}
