# =====================================================================
# Required inputs
# =====================================================================

variable "name" {
  type        = string
  description = "Name of the Application Gateway WAF policy. 1-128 chars; alphanumerics, underscores, periods, hyphens. Must start with alphanumeric."

  validation {
    condition     = can(regex("^[a-zA-Z0-9][a-zA-Z0-9._-]{0,126}[a-zA-Z0-9_]$", var.name))
    error_message = "name must be 1-128 characters, start with an alphanumeric, and contain only alphanumerics, underscores, periods, or hyphens."
  }
}

variable "resource_group_name" {
  type        = string
  description = "Name of the Resource Group where the WAF policy will be deployed."

  validation {
    condition     = length(var.resource_group_name) > 0 && length(var.resource_group_name) <= 90
    error_message = "resource_group_name must be 1-90 characters."
  }
}

variable "location" {
  type        = string
  description = "Azure region where the WAF policy will be deployed."

  validation {
    condition     = length(var.location) > 0
    error_message = "location must not be empty."
  }
}

variable "managed_rules" {
  type = object({
    exclusion = optional(map(object({
      match_variable          = string
      selector                = string
      selector_match_operator = string
      excluded_rule_set = optional(object({
        type    = optional(string)
        version = optional(string)
        rule_group = optional(list(object({
          excluded_rules  = optional(list(string))
          rule_group_name = string
        })))
      }))
    })))
    managed_rule_set = map(object({
      type    = optional(string)
      version = string
      rule_group_override = optional(map(object({
        rule_group_name = string
        rule = optional(list(object({
          action  = optional(string)
          enabled = optional(bool)
          id      = string
        })))
      })))
    }))
  })
  description = "Managed rule sets applied by the policy. managed_rule_set is keyed by a logical name; type defaults to OWASP and version is required (e.g. '3.2')."
}

# =====================================================================
# Policy behavior
# =====================================================================

variable "policy_settings" {
  type = object({
    enabled                                   = optional(bool)
    file_upload_limit_in_mb                   = optional(number)
    js_challenge_cookie_expiration_in_minutes = optional(number)
    max_request_body_size_in_kb               = optional(number)
    mode                                      = optional(string)
    request_body_check                        = optional(bool)
    request_body_enforcement                  = optional(bool)
    request_body_inspect_limit_in_kb          = optional(number)
    log_scrubbing = optional(object({
      enabled = optional(bool)
      rule = optional(list(object({
        enabled                 = optional(bool)
        match_variable          = string
        selector                = optional(string)
        selector_match_operator = optional(string)
      })))
    }))
  })
  description = "Top-level policy settings. mode is 'Prevention' (block) or 'Detection' (log only); enabled toggles enforcement. Leave null for AVM defaults (Prevention)."
  default     = null

  validation {
    condition     = try(var.policy_settings.mode, null) == null || contains(["Prevention", "Detection"], try(var.policy_settings.mode, ""))
    error_message = "policy_settings.mode must be 'Prevention' or 'Detection'."
  }
}

variable "custom_rules" {
  type = map(object({
    action               = string
    enabled              = optional(bool)
    group_rate_limit_by  = optional(string)
    name                 = optional(string)
    priority             = number
    rate_limit_duration  = optional(string)
    rate_limit_threshold = optional(number)
    rule_type            = string
    match_conditions = map(object({
      match_values       = optional(list(string))
      negation_condition = optional(bool)
      operator           = string
      transforms         = optional(set(string))
      match_variables = list(object({
        selector      = optional(string)
        variable_name = string
      }))
    }))
  }))
  description = "Custom rules evaluated before managed rules, keyed by a logical name. action is 'Allow', 'Block', or 'Log'; rule_type is 'MatchRule' or 'RateLimitRule'."
  default     = null
}

# =====================================================================
# AVM interfaces
# =====================================================================

variable "role_assignments" {
  type = map(object({
    role_definition_id_or_name             = string
    principal_id                           = string
    description                            = optional(string, null)
    skip_service_principal_aad_check       = optional(bool, false)
    condition                              = optional(string, null)
    condition_version                      = optional(string, null)
    delegated_managed_identity_resource_id = optional(string, null)
    principal_type                         = optional(string, null)
  }))
  description = "Role assignments to create on the WAF policy, keyed by a logical name."
  default     = {}
}

variable "lock" {
  type = object({
    kind = string
    name = optional(string, null)
  })
  description = "Optional resource lock. kind must be 'CanNotDelete' or 'ReadOnly'."
  default     = null

  validation {
    condition     = var.lock == null || contains(["CanNotDelete", "ReadOnly"], try(var.lock.kind, ""))
    error_message = "lock.kind must be 'CanNotDelete' or 'ReadOnly' when lock is set."
  }
}

# =====================================================================
# Module behavior
# =====================================================================

variable "enable_telemetry" {
  type        = bool
  description = "Whether to enable AVM module telemetry. Set false to opt out."
  default     = true
}

variable "tags" {
  type        = map(string)
  description = "A map of tags to apply to the WAF policy."
  default     = null
}
