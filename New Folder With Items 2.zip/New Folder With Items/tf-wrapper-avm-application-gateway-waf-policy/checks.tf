check "mode_is_prevention" {
  assert {
    condition     = try(var.policy_settings.mode, "Prevention") == "Prevention"
    error_message = "WAF policy mode is 'Detection'. Detection only logs traffic — switch to 'Prevention' to block malicious requests once tuning is complete."
  }
}

check "has_managed_rule_set" {
  assert {
    condition     = length(var.managed_rules.managed_rule_set) > 0
    error_message = "WAF policy has no managed_rule_set entries. Attach at least one managed rule set (e.g. OWASP 3.2) for baseline protection."
  }
}
