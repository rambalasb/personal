# Post-plan/apply advisory checks. These surface as warnings (never block apply) and
# assert compliance / cross-configuration invariants that the AVM module does not enforce.

check "waf_mode_is_prevention" {
  assert {
    condition     = var.policy_settings == null || var.policy_settings.mode == null || var.policy_settings.mode == "Prevention"
    error_message = "The WAF policy is in 'Detection' mode and will only log, not block, malicious traffic. Set policy_settings.mode = \"Prevention\" to actively enforce."
  }
}

check "at_least_one_managed_rule_set" {
  assert {
    condition     = length(var.managed_rules.managed_rule_set) > 0
    error_message = "The WAF policy defines no managed rule set, providing no baseline protection. Add at least one managed_rules.managed_rule_set entry (e.g. OWASP 3.2)."
  }
}

check "rate_limit_rules_have_threshold" {
  assert {
    condition = var.custom_rules == null || alltrue([
      for _, r in var.custom_rules :
      r.rule_type != "RateLimitRule" || (r.rate_limit_threshold != null && r.rate_limit_duration != null)
    ])
    error_message = "Custom rules of rule_type 'RateLimitRule' must set both rate_limit_threshold and rate_limit_duration."
  }
}
