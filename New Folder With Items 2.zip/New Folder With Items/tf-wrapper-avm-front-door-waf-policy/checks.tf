# Post-plan/apply advisory checks. These surface as warnings (never block apply) and
# assert compliance / cross-configuration invariants that the AVM module does not enforce.

check "waf_mode_is_prevention" {
  assert {
    condition     = var.mode == "Prevention"
    error_message = "The WAF policy is in 'Detection' mode and will only log, not block, malicious traffic. Set mode = \"Prevention\" to actively enforce."
  }
}

check "at_least_one_managed_rule_set" {
  assert {
    condition     = length(var.managed_rules) > 0
    error_message = "The WAF policy defines no managed rule set, providing no baseline protection. Add at least one managed_rules entry (e.g. Microsoft_DefaultRuleSet 2.1)."
  }
}

check "bot_protection_requires_premium" {
  assert {
    condition = var.sku_name == "Premium_AzureFrontDoor" || !anytrue([
      for r in var.managed_rules : contains(["BotProtection", "Microsoft_BotManagerRuleSet"], r.type)
    ])
    error_message = "Bot protection managed rule sets (BotProtection / Microsoft_BotManagerRuleSet) require the 'Premium_AzureFrontDoor' SKU. Set sku_name = \"Premium_AzureFrontDoor\" or remove the bot rule set."
  }
}
