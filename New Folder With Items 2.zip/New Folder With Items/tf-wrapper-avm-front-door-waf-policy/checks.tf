check "mode_is_prevention" {
  assert {
    condition     = var.mode == "Prevention"
    error_message = "WAF policy mode is 'Detection'. Detection only logs traffic — switch to 'Prevention' to block malicious requests once tuning is complete."
  }
}

check "policy_has_rules" {
  assert {
    condition     = length(var.managed_rules) > 0 || length(var.custom_rules) > 0
    error_message = "WAF policy has no managed_rules or custom_rules — it inspects nothing. Add a managed rule set (Premium) or custom rules for it to be effective."
  }
}
