module "front_door_waf_policy" {
  source  = "Azure/avm-res-network-frontdoorwebapplicationfirewallpolicy/azurerm"
  version = "0.1.0"

  # Required (the resource is global — no location)
  name                = var.name
  resource_group_name = var.resource_group_name
  sku_name            = var.sku_name
  mode                = var.mode

  # Rules
  managed_rules = var.managed_rules
  custom_rules  = var.custom_rules

  # Policy behavior
  enabled                           = var.enabled
  request_body_check_enabled        = var.request_body_check_enabled
  redirect_url                      = var.redirect_url
  custom_block_response_body        = var.custom_block_response_body
  custom_block_response_status_code = var.custom_block_response_status_code

  # AVM interfaces
  role_assignments = var.role_assignments
  lock             = var.lock
  enable_telemetry = var.enable_telemetry
  tags             = local.module_tags
}
