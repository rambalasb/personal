output "resource_id" {
  description = "The Azure resource ID of the Front Door WAF policy. Associate it via a Front Door security policy."
  value       = module.front_door_waf_policy.resource_id
}

output "resource" {
  description = "The full azurerm_cdn_frontdoor_firewall_policy resource object."
  value       = module.front_door_waf_policy.resource
}
