output "resource_id" {
  description = "The resource ID of the Front Door WAF Policy."
  value       = module.front_door_waf_policy.resource_id
}

output "resource" {
  description = "The full azurerm_cdn_frontdoor_firewall_policy resource output object."
  value       = module.front_door_waf_policy.resource
}
