output "resource_id" {
  value = module.front_door_waf_policy.resource_id
}

output "resource" {
  value = module.front_door_waf_policy.resource
}
