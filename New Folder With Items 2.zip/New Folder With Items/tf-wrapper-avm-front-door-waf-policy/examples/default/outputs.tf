output "resource_id" {
  value = module.front_door_waf_policy.resource_id
}
