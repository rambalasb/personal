module "front_door_waf_policy" {
  source = "../.."

  # name allows lowercase letters and numbers only, no hyphens
  name                = "fdwafdefaulttest${random_string.suffix.result}"
  resource_group_name = azurerm_resource_group.this.name
  sku_name            = "Premium_AzureFrontDoor"
  mode                = "Prevention"

  # managed rules require Premium SKU
  managed_rules = [
    {
      type    = "Microsoft_DefaultRuleSet"
      action  = "Block"
      version = "2.1"
    }
  ]

  enable_telemetry = false
}
