module "front_door_waf_policy" {
  source = "../.."

  name                = "fdwaf${random_string.suffix.result}"
  resource_group_name = azurerm_resource_group.this.name
  sku_name            = "Standard_AzureFrontDoor"
  mode                = "Prevention"

  # Standard SKU: custom rules only (managed rules require Premium)
  custom_rules = [{
    name     = "blockrange"
    priority = 1
    type     = "MatchRule"
    action   = "Block"
    match_conditions = [{
      match_variable = "RemoteAddr"
      operator       = "IPMatch"
      match_values   = ["192.0.2.0/24"]
    }]
  }]

  enable_telemetry = false
}
