# =====================================================================
# Required inputs
# =====================================================================

variable "name" {
  type        = string
  description = "Name of the Front Door WAF policy. 1-80 chars, lowercase letters and digits only (no hyphens, spaces, or uppercase)."

  validation {
    condition     = can(regex("^[a-z0-9]{1,80}$", var.name))
    error_message = "name must be 1-80 characters of lowercase letters and digits only."
  }
}

variable "resource_group_name" {
  type        = string
  description = "Name of the Resource Group where the WAF policy will be deployed."

  validation {
    condition     = length(var.resource_group_name) > 0 && length(var.resource_group_name) <= 90
    error_message = "resource_group_name must be 1-90 characters."
  }
}

# =====================================================================
# Profile
# =====================================================================

variable "sku_name" {
  type        = string
  description = "Front Door SKU the policy attaches to. 'Standard_AzureFrontDoor' (custom rules only) or 'Premium_AzureFrontDoor' (custom + managed rules)."
  default     = "Standard_AzureFrontDoor"

  validation {
    condition     = contains(["Standard_AzureFrontDoor", "Premium_AzureFrontDoor"], var.sku_name)
    error_message = "sku_name must be 'Standard_AzureFrontDoor' or 'Premium_AzureFrontDoor'."
  }
}

variable "mode" {
  type        = string
  description = "Policy enforcement mode. 'Prevention' blocks matching traffic; 'Detection' only logs."
  default     = "Prevention"

  validation {
    condition     = contains(["Prevention", "Detection"], var.mode)
    error_message = "mode must be 'Prevention' or 'Detection'."
  }
}

# =====================================================================
# Rules
# =====================================================================

variable "managed_rules" {
  type = list(object({
    type    = string
    action  = string
    version = string
    exclusions = optional(list(object({
      match_variable = string
      selector       = string
      operator       = string
    })))
    overrides = optional(list(object({
      rule_group_name = string
      rules = optional(list(object({
        rule_id = string
        enabled = optional(bool, false)
        action  = string
        exclusions = optional(list(object({
          match_variable = string
          selector       = string
          operator       = string
        })))
      })))
      exclusions = optional(list(object({
        match_variable = string
        selector       = string
        operator       = string
      })))
    })))
  }))
  description = "Managed rule sets. Requires sku_name = 'Premium_AzureFrontDoor'. Defaults to [] (no managed rules) so a Standard policy is valid out of the box; supply rule sets (e.g. Microsoft_DefaultRuleSet) on Premium."
  default     = []

  validation {
    condition     = length(var.managed_rules) == 0 || var.sku_name == "Premium_AzureFrontDoor"
    error_message = "managed_rules require sku_name = 'Premium_AzureFrontDoor'. Standard supports custom_rules only — set managed_rules = [] or upgrade the SKU."
  }
}

variable "custom_rules" {
  type = list(object({
    name                           = string
    priority                       = number
    type                           = string
    action                         = string
    enabled                        = optional(bool, true)
    rate_limit_duration_in_minutes = optional(number, 1)
    rate_limit_threshold           = optional(number, 10)
    match_conditions = list(object({
      match_variable     = string
      operator           = string
      match_values       = list(string)
      selector           = optional(string, null)
      negation_condition = optional(bool, null)
      transforms         = optional(list(string), [])
    }))
  }))
  description = "Custom rules. type is 'MatchRule' or 'RateLimitRule'; action is 'Allow', 'Block', 'Log', or 'Redirect'. Supported on both Standard and Premium."
  default     = []
}

# =====================================================================
# Policy behavior
# =====================================================================

variable "enabled" {
  type        = bool
  description = "Whether the policy is enabled."
  default     = true
}

variable "request_body_check_enabled" {
  type        = bool
  description = "Whether managed rules inspect the contents of the HTTP request body."
  default     = true
}

variable "redirect_url" {
  type        = string
  description = "URL to redirect blocked requests to when a rule action is 'Redirect'. Leave null otherwise."
  default     = null
}

variable "custom_block_response_body" {
  type        = string
  description = "Base64-encoded body returned for blocked requests. Leave null for the default response."
  default     = null
}

variable "custom_block_response_status_code" {
  type        = number
  description = "HTTP status code returned for blocked requests. One of 200, 403, 405, 406, 429, or null."
  default     = null

  validation {
    condition     = var.custom_block_response_status_code == null || contains([200, 403, 405, 406, 429], var.custom_block_response_status_code)
    error_message = "custom_block_response_status_code must be one of 200, 403, 405, 406, 429, or null."
  }
}

# =====================================================================
# AVM interfaces
# =====================================================================

variable "role_assignments" {
  type = map(object({
    role_definition_id_or_name             = string
    principal_id                           = string
    description                            = optional(string, null)
    skip_service_principal_aad_check       = optional(bool, false)
    condition                              = optional(string, null)
    condition_version                      = optional(string, null)
    delegated_managed_identity_resource_id = optional(string, null)
    principal_type                         = optional(string, null)
  }))
  description = "Role assignments to create on the WAF policy, keyed by a logical name."
  default     = {}
}

variable "lock" {
  type = object({
    kind = string
    name = optional(string, null)
  })
  description = "Optional resource lock. kind must be 'CanNotDelete' or 'ReadOnly'."
  default     = null

  validation {
    condition     = var.lock == null || contains(["CanNotDelete", "ReadOnly"], try(var.lock.kind, ""))
    error_message = "lock.kind must be 'CanNotDelete' or 'ReadOnly' when lock is set."
  }
}

# =====================================================================
# Module behavior
# =====================================================================

variable "enable_telemetry" {
  type        = bool
  description = "Whether to enable AVM module telemetry. Set false to opt out."
  default     = true
}

variable "tags" {
  type        = map(string)
  description = "A map of tags to apply to the WAF policy."
  default     = null
}
