output "resource_id" {
  description = "The Azure resource ID of the CDN / Front Door profile."
  value       = module.cdn_profile.resource_id
}

output "resource_name" {
  description = "The name of the profile."
  value       = module.cdn_profile.resource_name
}

output "system_assigned_mi_principal_id" {
  description = "Principal ID of the system-assigned managed identity, if enabled."
  value       = module.cdn_profile.system_assigned_mi_principal_id
}

output "frontdoor_endpoints" {
  description = "Map of Front Door endpoints created on the profile, keyed by the input map key."
  value       = module.cdn_profile.frontdoor_endpoints
}

output "frontdoor_firewall_policies" {
  description = "Map of Front Door WAF policies created inline on the profile."
  value       = module.cdn_profile.frontdoor_firewall_policies
}
