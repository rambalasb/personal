output "resource_id" {
  description = "The resource ID of the CDN / Front Door profile."
  value       = module.cdn_profile.resource_id
}

output "resource_name" {
  description = "The resource name of the CDN / Front Door profile."
  value       = module.cdn_profile.resource_name
}

output "resource" {
  description = "The full CDN / Front Door profile resource output object."
  value       = module.cdn_profile.resource
}

output "system_assigned_mi_principal_id" {
  description = "The principal ID of the system-assigned managed identity, if enabled."
  value       = module.cdn_profile.system_assigned_mi_principal_id
}

output "cdn_endpoints" {
  description = "Map of classic CDN endpoints created on the profile."
  value       = module.cdn_profile.cdn_endpoints
}

output "cdn_endpoint_custom_domains" {
  description = "Map of classic CDN endpoint custom domains created on the profile."
  value       = module.cdn_profile.cdn_endpoint_custom_domains
}

output "frontdoor_endpoints" {
  description = "Map of Front Door endpoints created on the profile."
  value       = module.cdn_profile.frontdoor_endpoints
}

output "frontdoor_custom_domains" {
  description = "Map of Front Door custom domains created on the profile."
  value       = module.cdn_profile.frontdoor_custom_domains
}

output "frontdoor_origin_groups" {
  description = "Map of Front Door origin groups created on the profile."
  value       = module.cdn_profile.frontdoor_origin_groups
}

output "frontdoor_origins" {
  description = "Map of Front Door origins created on the profile."
  value       = module.cdn_profile.frontdoor_origins
}

output "frontdoor_rule_sets" {
  description = "Map of Front Door rule sets created on the profile."
  value       = module.cdn_profile.frontdoor_rule_sets
}

output "frontdoor_rules" {
  description = "Map of Front Door rules created on the profile."
  value       = module.cdn_profile.frontdoor_rules
}

output "frontdoor_firewall_policies" {
  description = "Map of Front Door (WAF) firewall policies created on the profile."
  value       = module.cdn_profile.frontdoor_firewall_policies
}

output "frontdoor_security_policies" {
  description = "Map of Front Door security policies created on the profile."
  value       = module.cdn_profile.frontdoor_security_policies
}
