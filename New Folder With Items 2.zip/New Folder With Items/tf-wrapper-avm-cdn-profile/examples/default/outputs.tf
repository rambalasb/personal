output "resource_id" {
  value = module.cdn_profile.resource_id
}

output "resource_name" {
  value = module.cdn_profile.resource_name
}
