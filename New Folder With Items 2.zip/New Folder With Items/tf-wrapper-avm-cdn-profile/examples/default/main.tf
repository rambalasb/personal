module "cdn_profile" {
  source = "../.."

  name                = "cdn-avm-default-${random_string.suffix.result}"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location
  sku                 = "Standard_AzureFrontDoor"

  enable_telemetry = false
}
