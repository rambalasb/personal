module "cdn_profile" {
  source = "../.."

  name                = "cdn-avm-default-test-${random_string.suffix.result}"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location

  # classic CDN sku; keeps the default example off Front Door collections
  sku = "Standard_Microsoft"

  enable_telemetry = false
}
