# Post-plan/apply advisory checks. These surface as warnings (never block apply) and
# assert cross-configuration invariants that the AVM module does not enforce on its own.

check "classic_cdn_requires_cdn_sku" {
  assert {
    condition     = length(var.cdn_endpoints) == 0 || !local.is_front_door_sku
    error_message = "cdn_endpoints are only valid on a classic CDN SKU ('Standard_Microsoft' or 'Standard_ChinaCdn'). The configured sku '${var.sku}' is an Azure Front Door SKU — use the front_door_* variables instead."
  }
}

check "front_door_requires_front_door_sku" {
  assert {
    condition = local.is_front_door_sku || (
      length(var.front_door_endpoints) == 0 &&
      length(var.front_door_origin_groups) == 0 &&
      length(var.front_door_routes) == 0 &&
      length(var.front_door_firewall_policies) == 0
    )
    error_message = "front_door_* configuration requires an Azure Front Door SKU ('Standard_AzureFrontDoor' or 'Premium_AzureFrontDoor'). The configured sku '${var.sku}' is a classic CDN SKU — use the cdn_endpoints variable instead."
  }
}

check "front_door_routes_have_endpoints" {
  assert {
    condition     = length(var.front_door_routes) == 0 || length(var.front_door_endpoints) > 0
    error_message = "front_door_routes are configured but no front_door_endpoints are defined. Routes must be associated with a Front Door endpoint."
  }
}

check "firewall_policies_require_premium_for_managed_rules" {
  assert {
    condition     = alltrue([for _, p in var.front_door_firewall_policies : length(p.managed_rules) == 0 || p.sku_name == "Premium_AzureFrontDoor"])
    error_message = "Front Door managed WAF rules require a 'Premium_AzureFrontDoor' firewall policy sku_name."
  }
}
