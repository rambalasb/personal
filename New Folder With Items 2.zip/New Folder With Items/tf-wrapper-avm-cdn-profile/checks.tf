check "prefer_front_door_sku" {
  assert {
    condition     = contains(["Standard_AzureFrontDoor", "Premium_AzureFrontDoor"], var.sku)
    error_message = "Profile SKU is '${var.sku}' (classic CDN). Azure CDN Standard from Microsoft (classic) is retiring — prefer 'Standard_AzureFrontDoor' or 'Premium_AzureFrontDoor' for new workloads."
  }
}

check "premium_sku_for_managed_waf" {
  assert {
    condition     = length(var.front_door_firewall_policies) == 0 || var.sku == "Premium_AzureFrontDoor"
    error_message = "Inline Front Door WAF policies with managed rule sets require the 'Premium_AzureFrontDoor' SKU. Standard supports custom rules only."
  }
}
