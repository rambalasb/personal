locals {
  module_tags = merge(
    var.tags == null ? {} : var.tags,
    {
      managed-by = "terraform"
      module     = "tf-wrapper-avm-cdn-profile"
    }
  )

  # Whether the configured SKU is an Azure Front Door (standard/premium) tier.
  # Classic Microsoft/China CDN SKUs drive cdn_endpoints; Front Door SKUs drive
  # the front_door_* collections. Surfaced as advisory checks in checks.tf.
  is_front_door_sku = contains(["Standard_AzureFrontDoor", "Premium_AzureFrontDoor"], var.sku)
}
