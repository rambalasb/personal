# =====================================================================
# Required inputs
# =====================================================================

variable "name" {
  type        = string
  description = "Name of the CDN / Front Door profile. 1-260 chars; alphanumerics and hyphens. Must start and end with an alphanumeric."

  validation {
    condition     = can(regex("^[a-zA-Z0-9][a-zA-Z0-9-]{0,258}[a-zA-Z0-9]$", var.name))
    error_message = "name must be 1-260 characters, start and end with an alphanumeric, and contain only alphanumerics and hyphens."
  }
}

variable "resource_group_name" {
  type        = string
  description = "Name of the Resource Group where the profile will be deployed."

  validation {
    condition     = length(var.resource_group_name) > 0 && length(var.resource_group_name) <= 90
    error_message = "resource_group_name must be 1-90 characters."
  }
}

variable "location" {
  type        = string
  description = "Azure region for the profile resource. Front Door is a global service; this sets the resource's metadata region."

  validation {
    condition     = length(var.location) > 0
    error_message = "location must not be empty."
  }
}

# =====================================================================
# Profile
# =====================================================================

variable "sku" {
  type        = string
  description = "Profile SKU. Front Door: 'Standard_AzureFrontDoor' or 'Premium_AzureFrontDoor' (Premium is required for managed WAF rules and Private Link origins). Classic CDN: 'Standard_Microsoft' or 'Standard_ChinaCdn'."
  default     = "Standard_AzureFrontDoor"

  validation {
    condition     = contains(["Standard_AzureFrontDoor", "Premium_AzureFrontDoor", "Standard_Microsoft", "Standard_ChinaCdn"], var.sku)
    error_message = "sku must be one of: Standard_AzureFrontDoor, Premium_AzureFrontDoor, Standard_Microsoft, Standard_ChinaCdn."
  }
}

variable "response_timeout_seconds" {
  type        = number
  description = "Send/receive timeout on forwarding requests to the origin (Front Door). Between 16 and 240 seconds."
  default     = 120

  validation {
    condition     = var.response_timeout_seconds >= 16 && var.response_timeout_seconds <= 240
    error_message = "response_timeout_seconds must be between 16 and 240."
  }
}

# =====================================================================
# Front Door composition (optional)
#
# These maps are cross-referenced by their map KEY, not by resource ID
# (e.g. an origin's origin_group_key points at an origin_groups key). They
# pass straight through to the AVM module, which validates their shape.
# =====================================================================

variable "front_door_endpoints" {
  type        = any
  description = "Front Door endpoints, keyed by a logical name."
  default     = {}
}

variable "front_door_origin_groups" {
  type        = any
  description = "Front Door origin groups (health probe + load balancing), keyed by a logical name."
  default     = {}
}

variable "front_door_origins" {
  type        = any
  description = "Front Door origins, keyed by a logical name. Each references its group via origin_group_key."
  default     = {}
}

variable "front_door_routes" {
  type        = any
  description = "Front Door routes, keyed by a logical name. Wire endpoint_key, origin_group_key, and origin_keys together."
  default     = {}
}

variable "front_door_custom_domains" {
  type        = any
  description = "Front Door custom domains, keyed by a logical name."
  default     = {}
}

variable "front_door_firewall_policies" {
  type        = any
  description = "Front Door WAF policies created inline with the profile, keyed by a logical name. For a standalone policy use the front-door-waf-policy wrapper instead."
  default     = {}
}

variable "front_door_security_policies" {
  type        = any
  description = "Front Door security policies that associate a WAF policy with endpoints/domains, keyed by a logical name."
  default     = {}
}

variable "front_door_secrets" {
  type        = any
  description = "Front Door secrets (Key Vault certificates), keyed by a logical name."
  default     = {}
}

variable "front_door_rule_sets" {
  type        = set(string)
  description = "Set of Front Door rule set names to create on the profile."
  default     = []
}

variable "front_door_rules" {
  type        = any
  description = "Front Door rules engine rules, keyed by a logical name."
  default     = {}
}

# =====================================================================
# Classic CDN composition (optional)
# =====================================================================

variable "cdn_endpoints" {
  type        = any
  description = "Classic CDN endpoints, keyed by a logical name. Only used with classic CDN SKUs."
  default     = {}
}

variable "cdn_endpoint_custom_domains" {
  type        = any
  description = "Classic CDN endpoint custom domains, keyed by a logical name."
  default     = {}
}

# =====================================================================
# AVM interfaces
# =====================================================================

variable "managed_identities" {
  type = object({
    system_assigned            = optional(bool, false)
    user_assigned_resource_ids = optional(set(string), [])
  })
  description = "Managed identity configuration for the profile."
  default     = {}
}

variable "role_assignments" {
  type = map(object({
    role_definition_id_or_name             = string
    principal_id                           = string
    description                            = optional(string, null)
    skip_service_principal_aad_check       = optional(bool, false)
    condition                              = optional(string, null)
    condition_version                      = optional(string, null)
    delegated_managed_identity_resource_id = optional(string, null)
    principal_type                         = optional(string, null)
  }))
  description = "Role assignments to create on the profile, keyed by a logical name."
  default     = {}
}

variable "diagnostic_settings" {
  type = map(object({
    name                                     = optional(string, null)
    log_categories                           = optional(set(string), [])
    log_groups                               = optional(set(string), ["allLogs"])
    metric_categories                        = optional(set(string), ["AllMetrics"])
    log_analytics_destination_type           = optional(string, "Dedicated")
    workspace_resource_id                    = optional(string, null)
    storage_account_resource_id              = optional(string, null)
    event_hub_authorization_rule_resource_id = optional(string, null)
    event_hub_name                           = optional(string, null)
    marketplace_partner_resource_id          = optional(string, null)
  }))
  description = "Diagnostic settings for the profile, keyed by a logical name."
  default     = {}
}

variable "lock" {
  type = object({
    kind = string
    name = optional(string, null)
  })
  description = "Optional resource lock. kind must be 'CanNotDelete' or 'ReadOnly'."
  default     = null

  validation {
    condition     = var.lock == null || contains(["CanNotDelete", "ReadOnly"], try(var.lock.kind, ""))
    error_message = "lock.kind must be 'CanNotDelete' or 'ReadOnly' when lock is set."
  }
}

# =====================================================================
# Module behavior
# =====================================================================

variable "enable_telemetry" {
  type        = bool
  description = "Whether to enable AVM module telemetry. Set false to opt out."
  default     = true
}

variable "tags" {
  type        = map(string)
  description = "A map of tags to apply to the profile."
  default     = null
}
