# Adopts all 6 resource groups in the identity subscription. The original 4
# came from the ARM export; rg-onboarding-prod and rg-Lifecycleworkflows-prod
# were added later and were never in that export -- their tags are unconfirmed.
# Imports 6 existing resource groups. Delete the import blocks below once
# `terraform apply` has adopted them into state.

module "resource_group" {
  for_each = var.enable_resource_group ? var.resource_group : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-resource-group/azurerm"
  version = "2.0.0"

  name     = each.value.name
  location = each.value.location

  enable_telemetry = false
  tags             = merge(local.common_tags, each.value.tags)
}

import {
  for_each = var.enable_resource_group ? var.resource_group_imports : {}

  to = module.resource_group[each.key].module.resource_group.azapi_resource.this
  id = each.value
}
