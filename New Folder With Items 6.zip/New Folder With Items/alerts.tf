# Dependencies: resource_group (alerts land in rg-alerts-identity and rg-siem-identity).
# Adopts the 7 monitor alerts exported from the identity subscription.
# Imports 7 existing alerts. Delete the import blocks below once
# `terraform apply` has adopted them into state.
#
# enable_amba stays false: the AMBA baseline assigns policy across the
# management group hierarchy, which is well outside adopting these alerts.
# Each alert carries its own literal resource_group_name because that is the
# wrapper's interface; var.alert.resource_group_key only positions AMBA itself.

module "monitoring" {
  count = var.enable_monitoring ? 1 : 0

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-monitoring-amba-alz/azurerm"
  version = "0.1.0"

  enable_amba                = var.enable_amba
  location                   = module.resource_group[var.alert.resource_group_key].location
  root_management_group_name = var.alert.root_management_group_name

  metric_alerts       = var.alert.metric_alerts
  activity_log_alerts = var.alert.activity_log_alerts
  log_search_alerts   = var.alert.log_search_alerts
  tags                = local.common_tags

  depends_on = [module.resource_group]
}

import {
  for_each = var.enable_monitoring ? var.metric_alert_imports : {}

  to = module.monitoring[0].azurerm_monitor_metric_alert.this[each.key]
  id = each.value
}

import {
  for_each = var.enable_monitoring ? var.activity_log_alert_imports : {}

  to = module.monitoring[0].azurerm_monitor_activity_log_alert.this[each.key]
  id = each.value
}

import {
  for_each = var.enable_monitoring ? var.log_search_alert_imports : {}

  to = module.monitoring[0].azurerm_monitor_scheduled_query_rules_alert_v2.this[each.key]
  id = each.value
}
