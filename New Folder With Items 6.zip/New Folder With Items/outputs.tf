output "resource_group_ids" {
  value       = { for k, v in module.resource_group : k => v.resource_id }
  description = "Resource IDs of adopted resource groups, by instance key."
}

output "user_assigned_identity_ids" {
  value       = { for k, v in module.user_assigned_identity : k => v.resource_id }
  description = "Resource IDs of adopted user assigned identities, by instance key."
}

output "key_vault_ids" {
  value       = { for k, v in module.key_vault : k => v.resource_id }
  description = "Resource IDs of adopted key vaults, by instance key."
}

output "storage_account_ids" {
  value       = { for k, v in module.storage_account : k => v.resource_id }
  description = "Resource IDs of adopted storage accounts, by instance key."
}
