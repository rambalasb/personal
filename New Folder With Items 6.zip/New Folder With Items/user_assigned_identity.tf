# Dependencies: resource_group (per-instance binding via resource_group_key).
# Adopts the 3 user assigned identities exported from rg-mid-identity.
# Imports 3 existing user assigned identities. Delete the import blocks below
# once `terraform apply` has adopted them into state.

module "user_assigned_identity" {
  for_each = var.enable_user_assigned_identity ? var.user_assigned_identity : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-user-assigned-identity/azurerm"
  version = "0.0.4"

  name                = each.value.name
  resource_group_name = module.resource_group[each.value.resource_group_key].name
  location            = each.value.location

  isolation_scope  = each.value.isolation_scope
  enable_telemetry = false
  tags             = merge(local.common_tags, each.value.tags)
}

import {
  for_each = var.enable_user_assigned_identity ? var.user_assigned_identity_imports : {}

  to = module.user_assigned_identity[each.key].module.user_assigned_identity.azurerm_user_assigned_identity.this
  id = each.value
}
