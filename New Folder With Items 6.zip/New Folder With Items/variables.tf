# =====================================================================
# 1. Shared infrastructure variables
# =====================================================================

variable "subscription_id" {
  type        = string
  description = "Subscription ID that hosts the identity resource groups being adopted. Must match the subscription the ARM exports were taken from — not any subscription merely referenced by ID elsewhere in those exports (e.g. shared action groups)."

  validation {
    condition     = can(regex("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$", var.subscription_id))
    error_message = "subscription_id must be a valid GUID."
  }
}

variable "tags" {
  type        = map(string)
  description = "Tags merged onto every adopted resource, on top of whatever the wrapper itself adds (managed-by/module) and each resource's own tags."
  default     = {}
}

# =====================================================================
# 2. Feature flags
# =====================================================================

variable "enable_resource_group" {
  type        = bool
  description = "Whether to adopt the resource groups."
  default     = false
}

variable "enable_user_assigned_identity" {
  type        = bool
  description = "Whether to adopt the user assigned identities."
  default     = false
}

variable "enable_key_vault" {
  type        = bool
  description = "Whether to adopt the key vaults."
  default     = false
}

variable "enable_storage_account" {
  type        = bool
  description = "Whether to adopt the storage account."
  default     = false
}

variable "enable_monitoring" {
  type        = bool
  description = "Deploy monitoring (all alerts, and the AMBA baseline when enable_amba = true) via the amba-alz wrapper."
  default     = false
}

# =====================================================================
# 3. Per-wrapper config maps
# =====================================================================

variable "resource_group" {
  type = map(object({
    name     = string
    location = string
    tags     = optional(map(string), {})
  }))
  description = "Map of resource groups to adopt, keyed by a logical instance name."
  default     = {}
}

variable "user_assigned_identity" {
  type = map(object({
    name               = string
    resource_group_key = string
    location           = string
    isolation_scope    = optional(string)
    tags               = optional(map(string), {})
  }))
  description = "Map of user assigned identities to adopt, keyed by a logical instance name. resource_group_key must match a key in var.resource_group. isolation_scope must match the live value ('Regional' or omitted) or the import will not be a no-op."
  default     = {}
}

variable "key_vault" {
  type = map(object({
    name                            = string
    resource_group_key              = string
    location                        = string
    tenant_id                       = string
    sku_name                        = optional(string, "premium")
    purge_protection_enabled        = optional(bool, true)
    soft_delete_retention_days      = optional(number, null)
    public_network_access_enabled   = optional(bool, true)
    enabled_for_deployment          = optional(bool, false)
    enabled_for_disk_encryption     = optional(bool, false)
    enabled_for_template_deployment = optional(bool, false)
    legacy_access_policies_enabled  = optional(bool, false)
    legacy_access_policies = optional(map(object({
      object_id               = string
      application_id          = optional(string, null)
      certificate_permissions = optional(list(string), [])
      key_permissions         = optional(list(string), [])
      secret_permissions      = optional(list(string), [])
      storage_permissions     = optional(list(string), [])
    })), {})
    network_acls = optional(object({
      bypass                     = optional(string, "AzureServices")
      default_action             = optional(string, "Deny")
      ip_rules                   = optional(list(string), [])
      virtual_network_subnet_ids = optional(list(string), [])
    }), null)
    tags = optional(map(string), {})
  }))
  description = "Map of key vaults to adopt, keyed by a logical instance name. resource_group_key must match a key in var.resource_group."
  default     = {}
}

variable "storage_account" {
  type = map(object({
    name                              = string
    resource_group_key                = string
    location                          = string
    account_kind                      = optional(string, "StorageV2")
    account_tier                      = optional(string, "Standard")
    account_replication_type          = string
    access_tier                       = optional(string, "Hot")
    min_tls_version                   = optional(string, "TLS1_2")
    allow_nested_items_to_be_public   = optional(bool, false)
    shared_access_key_enabled         = optional(bool, false)
    public_network_access_enabled     = optional(bool, false)
    local_user_enabled                = optional(bool, false)
    cross_tenant_replication_enabled  = optional(bool, false)
    https_traffic_only_enabled        = optional(bool, true)
    default_to_oauth_authentication   = optional(bool, true)
    infrastructure_encryption_enabled = optional(bool, true)
    is_hns_enabled                    = optional(bool, false)
    network_rules = optional(object({
      bypass                     = optional(list(string), ["AzureServices"])
      default_action             = optional(string, "Deny")
      ip_rules                   = optional(list(string), [])
      virtual_network_subnet_ids = optional(list(string), [])
      private_link_access = optional(list(object({
        endpoint_resource_id = string
        endpoint_tenant_id   = optional(string)
      })))
    }), null)
    containers = optional(map(object({
      name          = string
      public_access = optional(string, "None")
    })), {})
    tags = optional(map(string), {})
  }))
  description = "Map of storage accounts to adopt, keyed by a logical instance name. resource_group_key must match a key in var.resource_group."
  default     = {}
}

# =====================================================================
# 4. Import ID maps — one per wrapper, keyed by the same instance key.
#    Populated only while adoption is pending; empty once applied and
#    the import blocks are deleted.
# =====================================================================

variable "resource_group_imports" {
  type        = map(string)
  description = "Azure resource IDs (with ?api-version=) of existing resource groups to adopt, keyed by instance identifier."
  default     = {}

  validation {
    condition     = alltrue([for v in values(var.resource_group_imports) : strcontains(v, "?api-version=")])
    error_message = "resource_group_imports targets azapi_resource; every ID must end with ?api-version=<version>."
  }
}

variable "user_assigned_identity_imports" {
  type        = map(string)
  description = "Azure resource IDs of existing user assigned identities to adopt, keyed by instance identifier."
  default     = {}
}

variable "key_vault_imports" {
  type        = map(string)
  description = "Azure resource IDs of existing key vaults to adopt, keyed by instance identifier."
  default     = {}
}

variable "key_vault_access_policy_imports" {
  type = map(object({
    vault_key  = string
    policy_key = string
    id         = string
  }))
  description = "Existing key vault legacy access policies to adopt. Keyed '<vault_key>/<policy_key>'; policy_key is free-form but must match the key used in the vault's legacy_access_policies map."
  default     = {}
}

variable "storage_account_imports" {
  type        = map(string)
  description = "Azure resource IDs of existing storage accounts to adopt, keyed by instance identifier."
  default     = {}
}

variable "storage_account_container_imports" {
  type = map(object({
    account_key   = string
    container_key = string
    id            = string
  }))
  description = "Existing blob containers to adopt. Keyed '<account_key>/<container_key>'; container_key must equal the container's Azure name."
  default     = {}

  validation {
    condition     = alltrue([for v in values(var.storage_account_container_imports) : strcontains(v.id, "?api-version=")])
    error_message = "storage_account_container_imports targets azapi_resource; every id must end with ?api-version=<version>."
  }
}

# ── Monitoring / alerts ────────────────────────────────────────────────

variable "enable_amba" {
  type        = bool
  description = "Deploy the AMBA-ALZ policy baseline across the management group hierarchy. Leave false when only adopting existing alerts."
  default     = false
}

variable "enable_network_watcher" {
  type        = bool
  description = "Manage the network watcher."
  default     = false
}

variable "enable_event_grid_system_topic" {
  type        = bool
  description = "Manage the Event Grid system topic."
  default     = false
}

# Alert types mirror tf-wrapper-avm-monitoring-amba-alz exactly so values pass
# straight through. resource_group_name on each alert is a literal name, not a
# key, because that is the wrapper's interface.
variable "alert" {
  type = object({
    resource_group_key         = string
    root_management_group_name = optional(string)

    metric_alerts = optional(map(object({
      name                     = string
      resource_group_name      = string
      scopes                   = list(string)
      description              = optional(string)
      enabled                  = optional(bool, true)
      auto_mitigate            = optional(bool, true)
      frequency                = optional(string, "PT1M")
      window_size              = optional(string, "PT5M")
      severity                 = optional(number, 3)
      target_resource_type     = optional(string)
      target_resource_location = optional(string)
      criteria = optional(list(object({
        metric_namespace       = string
        metric_name            = string
        aggregation            = string
        operator               = string
        threshold              = number
        skip_metric_validation = optional(bool, false)
      })), [])
      action_group_ids   = optional(list(string), [])
      webhook_properties = optional(map(string), {})
      tags               = optional(map(string), {})
    })), {})

    activity_log_alerts = optional(map(object({
      name                = string
      resource_group_name = string
      scopes              = list(string)
      location            = optional(string, "global")
      description         = optional(string)
      enabled             = optional(bool, true)
      criteria = object({
        category          = string
        operation_name    = optional(string)
        resource_provider = optional(string)
        resource_type     = optional(string)
        resource_group    = optional(string)
        resource_id       = optional(string)
        caller            = optional(string)
        level             = optional(string)
        status            = optional(string)
        sub_status        = optional(string)
        service_health = optional(object({
          events    = optional(list(string))
          locations = optional(list(string))
          services  = optional(list(string))
        }))
      })
      action_group_ids   = optional(list(string), [])
      webhook_properties = optional(map(string), {})
      tags               = optional(map(string), {})
    })), {})

    log_search_alerts = optional(map(object({
      name                              = string
      resource_group_name               = string
      location                          = string
      scopes                            = list(string)
      severity                          = optional(number, 3)
      evaluation_frequency              = optional(string, "PT5M")
      window_duration                   = optional(string, "PT5M")
      description                       = optional(string)
      display_name                      = optional(string)
      enabled                           = optional(bool, true)
      auto_mitigation_enabled           = optional(bool, false)
      skip_query_validation             = optional(bool, false)
      mute_actions_after_alert_duration = optional(string)
      query_time_range_override         = optional(string)
      target_resource_types             = optional(list(string))
      criteria = list(object({
        query                   = string
        time_aggregation_method = string
        threshold               = number
        operator                = string
        resource_id_column      = optional(string)
        metric_measure_column   = optional(string)
        failing_periods = optional(object({
          minimum_failing_periods_to_trigger_alert = number
          number_of_evaluation_periods             = number
        }))
      }))
      action_group_ids  = optional(list(string), [])
      custom_properties = optional(map(string), {})
      tags              = optional(map(string), {})
    })), {})
  })
  description = "Monitor alerts to adopt. resource_group_key positions the AMBA baseline only; each alert names its own resource group."
  default = {
    resource_group_key = "alerts_identity"
  }
}

variable "network_watcher" {
  type = map(object({
    name               = string
    resource_group_key = string
    location           = string
    tags               = optional(map(string), {})
  }))
  description = "Network watchers to adopt, keyed by a logical instance name."
  default     = {}
}

variable "event_grid_system_topic" {
  type = map(object({
    name               = string
    resource_group_key = string
    location           = string
    topic_type         = string
    source_resource_id = optional(string)
    tags               = optional(map(string), {})
  }))
  description = "Event Grid system topics to adopt. Leave source_resource_id unset when adopting; it is ForceNew and the live value's casing differs from a module output."
  default     = {}
}

variable "metric_alert_imports" {
  type        = map(string)
  description = "Existing metric alerts to adopt, keyed by the key used in var.alert.metric_alerts."
  default     = {}
}

variable "activity_log_alert_imports" {
  type        = map(string)
  description = "Existing activity log alerts to adopt, keyed by the key used in var.alert.activity_log_alerts."
  default     = {}
}

variable "log_search_alert_imports" {
  type        = map(string)
  description = "Existing scheduled query rule alerts to adopt, keyed by the key used in var.alert.log_search_alerts."
  default     = {}
}

variable "network_watcher_imports" {
  type        = map(string)
  description = "Existing network watchers to adopt, keyed by the key used in var.network_watcher."
  default     = {}
}

variable "event_grid_system_topic_imports" {
  type        = map(string)
  description = "Existing Event Grid system topics to adopt, keyed by the key used in var.event_grid_system_topic."
  default     = {}
}
