# identity-lz

Adopts the existing identity subscription (`b6dc12b1-645d-4a43-b08f-50c862f793d0`,
`canadacentral`) into Terraform using `import {}` blocks against the
`tf-wrapper-avm-*` modules in `modules/`. The original 4 resource groups came
from ARM exports in `existing-sub-identity/`; the rest was reconciled against
`az resource list` afterwards.

## What was adopted

- **6 resource groups** — rg-mid-identity, rg-alerts-identity, rg-siem-identity, rg-shared-identity, rg-onboarding-prod, rg-Lifecycleworkflows-prod
- **3 user assigned identities** — mid-dev-autmn, mid-prod-autmn, mid-azfirewall
- **4 key vaults** — kvfwtlscanadacentral, kvidncanadacentral, kvidndevops, kvonboardingprodcac001 (access policies included; secrets/keys/private-endpoint-connections excluded — see `UNSUPPORTED.md`)
- **1 storage account + 1 container** — stnwidncanadacentral / insights-metrics-pt1m
- **7 monitor alerts** — 2 activity log alerts, 5 scheduled query rules
- **1 network watcher** — NetworkWatcher_canadacentral_identity (native resource; the AVM module only manages flow logs and connection monitors)
- **1 EventGrid system topic** — the Defender-for-Storage topic on stnwidncanadacentral (adoption only; its event subscription stays with Defender)

28 import blocks, covering all 6 resource groups. Left out:
`AzureActiveDirectory/guestUsages`, which is not supported. 12 child objects
are also excluded — see `UNSUPPORTED.md` for exactly which and why.

**Confirmed against live on 2026-09-02**, via `az resource show` over every
resource, `az group list` for the groups and `az storage container show` for
the container: all four key vaults, the storage account (including the Defender
`StorageDataScanner` access rule), its `insights-metrics-pt1m` container, the
three user-assigned identities, all four access policies with their permission
lists, and all seven alerts match this tfvars field for field — including the
ServiceNow action group ID byte-for-byte, lowercase subscription GUID and
leading space included. All six resource groups carry no tags, so `tags = {}`
is correct for each.

The one diff still expected on adoption is the key vault access-policy
set-vs-list ordering in `MODULE_GAPS.md`, which is a wrapper defect rather than
a config error. `kvonboardingprodcac001`'s firewall — `bypass = "None"` with 59 pinned
service-tag CIDRs — is mirrored from the portal rather than simplified, so the
import is a no-op; see the note on that block before editing it.

Every place the live configuration differs from a wrapper's hardened default
— `infrastructure_encryption_enabled`, `purge_protection_enabled`,
`legacy_access_policies_enabled`, network ACL bypass settings, and others —
is written explicitly into `identity.tfvars` and explained in
`REMEDIATION.md`. That's what keeps the first `terraform plan` from silently
hardening a live system instead of just adopting it.

**Every imported resource will still show a tag-only diff on first plan.**
The wrapper adds `managed-by`/`module` tags on top of whatever's live, and
this deployment's `common_tags` (currently empty) merges in too. That's
expected — `verify_zero_diff.sh` knows to ignore it.

## Running the import (your steps, not something already done)

```bash
cd deployments/identity-lz
terraform init
terraform plan -var-file=identity.tfvars -out=tfplan.binary
terraform show -json tfplan.binary > plan.json
./scripts/verify_zero_diff.sh plan.json   # must PASS before applying
terraform apply tfplan.binary
# then delete every import{} block in this directory and re-plan — it should be empty
```

If `verify_zero_diff.sh` fails, check the failure against `REMEDIATION.md`
first — it's more likely a divergence that was missed than a random diff.

## Pipelines

All share the `sub-identity-lz` concurrency group, so one run touches the
subscription at a time. Only `unmanaged-detect.yml` runs on a schedule; the rest
are `workflow_dispatch` only.

- `import-verify.yml` — plan and gate, never applies. Safe to run any time.
- `import-apply.yml` — two jobs in one run. `check` plans, gates, and publishes
  a digest of the change set; `apply` sits behind the `identity` GitHub
  environment and needs an approver.
- `unmanaged-detect.yml` — daily read-only diff of Azure's inventory against
  state, finding resources HCP Terraform's own drift detection cannot see. No
  apply path by design. See
  [Unmanaged resources](#unmanaged-resources).

**The `identity` environment must have required reviewers configured.** Without
them the job runs straight through and there is no approval stop.

Two controls sit between approval and apply, covering different failures:

1. The apply job re-plans and re-runs `verify_zero_diff.sh`, so attribute-level
   drift that appeared during the approval wait fails the run. It does not
   consume the check job's plan — applying a saved plan would replay a recorded
   diff without re-reading Azure.
2. It then compares its own change set against the digest the check job
   published, so a resource entering or leaving the plan between review and
   approval blocks the apply. The approver's summary shows the digest that has
   to match.

Neither `plan.json` nor `tfplan.binary` is uploaded — they carry resolved
attribute values. The artifacts hold the gate output and an address-level
change list only.

### Unmanaged resources

Drift is two questions, and they are answered in two places.

**HCP Terraform's own drift detection** (enabled on the `az-platform-identity`
workspace) runs a refresh-only comparison and reports when a resource *already
in state* has changed in Azure. That is the half Terraform can answer from
state alone.

**`unmanaged-detect.yml`** answers the other half, which HCP structurally
cannot: a
resource that exists in Azure but has no state entry. A refresh-only plan
compares each managed resource to its real counterpart, so something created by
hand is invisible to it — there is nothing to compare against. This workflow
reads Azure's inventory with `az resource list` and diffs it against
`terraform show -json`, in both directions:

| signal | meaning | what to do |
|---|---|---|
| **unmanaged** | in Azure, inside scope, no state entry | adopt it with an import block, delete it, or waive it |
| **ghost** | in state, absent from Azure | find out why it went; do **not** apply to "fix" it — an apply recreates it |

Scope is the set of resource groups appearing in state, so the report covers
what this workspace is responsible for and stays quiet about resources another
workspace owns. Adopt a new resource group and it comes into scope on its own.
`workflow_dispatch` takes a `scope_resource_groups` override for inventorying a
group before anything in it is adopted.

There is no waiver list. If a resource turns out to be legitimately unmanaged,
create `.github/inventory-waivers.txt` — one ARM ID or glob per line, with a
reason — and the job picks it up automatically. Prefer adopting or deleting over
waiving: every entry is something nobody will be told about again.

Anything unmanaged or ghosted opens (or comments on) a single reused GitHub
issue and fails the run.

Two limits worth knowing. Only **top-level** ARM resources are compared —
Azure's inventory APIs do not enumerate child resources such as a blob
container, a backup policy, or a subnet, so treating one in state as missing
from Azure would be a false positive every run. Child resources in state are
counted and listed separately instead. And the job needs runner-side Azure
credentials (`AZURE_CLIENT_ID`, `AZURE_TENANT_ID`, `AZURE_SUBSCRIPTION_ID`),
which the Terraform pipelines do not use since they authenticate through HCP;
without them it skips rather than failing a scheduled run.

While state is empty the report is `INCONCLUSIVE`, not a pass — an empty scope
has proved nothing, and a clean verdict there would read as a clean bill of
health for the subscription.

**Not covered by either.** Whether the committed config still agrees with state
— a tfvars edit merged without an apply. The deleted `-detailed-exitcode` check
was the only thing watching for that.

## Reports

- `REMEDIATION.md` — every divergence from wrapper defaults, why it matters, and what breaks if it's ever "corrected" carelessly
- `UNSUPPORTED.md` — everything not imported, and why

