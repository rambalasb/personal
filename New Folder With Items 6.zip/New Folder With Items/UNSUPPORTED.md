# Unsupported resources — `identity-lz`

Counted against the live subscription, not against the original ARM export —
the export covered only 4 of the 6 resource groups and predates three
resources created since.

| | Live | Imported |
|---|---|---|
| Resource groups | 6 | 6 |
| Tracked resources (`az resource list`) | 18 | 17 |
| Child / data-plane objects | 20 | 8 |
| **Import blocks in this deployment** | | **28** |

One tracked resource and 12 child objects are not imported. None are invented
workarounds — each is either a type with no matching wrapper or provider
resource, data-plane content whose value isn't retrievable from a template
export, or a child object with nowhere to attach.

## Tracked resources not imported

| ARM type | Name | Resource ID | Why skipped | What to do |
|---|---|---|---|---|
| `Microsoft.AzureActiveDirectory/guestUsages` | bchydro.onmicrosoft.com | `/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0/resourceGroups/rg-Lifecycleworkflows-prod-canadacentral-001/providers/Microsoft.AzureActiveDirectory/guestUsages/bchydro.onmicrosoft.com` | No `azurerm` resource exists for this type, and no AVM module covers it. It is a tenant-scoped B2B collaboration billing link with a single property (`tenantId`), created 2026-08-17 outside this adoption. Its resource group **is** imported. | Leave unmanaged. `azapi_resource` could hold it, but a one-property directory-billing link is not worth the wrapper. Revisit only if Entra External ID configuration moves into Terraform. |

## Child objects not imported

| ARM type | Name | Resource ID | Why skipped | What to do |
|---|---|---|---|---|
| `Microsoft.EventGrid/systemTopics/eventSubscriptions` | StorageAntimalwareSubscription | `/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0/resourceGroups/rg-shared-identity-canadacentral-001/providers/Microsoft.EventGrid/systemTopics/stnwidncanadacentral-bb43e3f7-7be0-4dc3-99e9-10766e4990c0/eventSubscriptions/StorageAntimalwareSubscription` | The parent system topic **is** now imported, so this is no longer blocked by a missing wrapper — it is skipped because Microsoft Defender for Storage creates and owns both, and re-provisions them when malware scanning is toggled. Terraform would fight the platform. | Importable today via `azurerm_eventgrid_system_topic_event_subscription` if you decide Terraform should own it. Recommended: leave it to Defender and keep the topic import as adoption-only. |
| `Microsoft.KeyVault/vaults/keys` | azkv-fw-tls-cert (kvfwtlscanadacentral) | `/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0/resourceGroups/rg-mid-identity-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvfwtlscanadacentral/keys/azkv-fw-tls-cert` | Data-plane content. Key material is retrieved through runtime-only ARM functions and is never present in a template export. | Leave unmanaged by Terraform, or import manually once the value is known out-of-band. |
| `Microsoft.KeyVault/vaults/keys` | azkv-firewall-tls-root-cert (kvidncanadacentral) | `/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0/resourceGroups/rg-siem-identity-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvidncanadacentral/keys/azkv-firewall-tls-root-cert` | Data-plane content, value not in the export. | Same as above. |
| `Microsoft.KeyVault/vaults/secrets` | azkv-fw-tls-cert (kvfwtlscanadacentral) | `/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0/resourceGroups/rg-mid-identity-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvfwtlscanadacentral/secrets/azkv-fw-tls-cert` | Data-plane content — `listSecrets` is runtime-only. | Leave unmanaged, or import manually once the value is known. |
| `Microsoft.KeyVault/vaults/secrets` | azkv-firewall-tls-root-cert (kvidncanadacentral) | `/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0/resourceGroups/rg-siem-identity-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvidncanadacentral/secrets/azkv-firewall-tls-root-cert` | Data-plane content, value not in the export. | Same as above. |
| `Microsoft.KeyVault/vaults/secrets` | DoNotDelete-FitNonProdOraclePrivateKey (kvidncanadacentral) | `/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0/resourceGroups/rg-siem-identity-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvidncanadacentral/secrets/DoNotDelete-FitNonProdOraclePrivateKey` | Data-plane content, value not in the export. | Same as above. |
| `Microsoft.KeyVault/vaults/secrets` | DoNotDelete-PresharedKey (kvidncanadacentral) | `/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0/resourceGroups/rg-siem-identity-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvidncanadacentral/secrets/DoNotDelete-PresharedKey` | Data-plane content, value not in the export. | Same as above. |
| `Microsoft.KeyVault/vaults/secrets` | DoNotDelete-PresharedKeyCAE (kvidncanadacentral) | `/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0/resourceGroups/rg-siem-identity-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvidncanadacentral/secrets/DoNotDelete-PresharedKeyCAE` | Data-plane content, value not in the export. | Same as above. |
| `Microsoft.KeyVault/vaults/privateEndpointConnections` | pep-azfw-connectivity-canadacentral-001 (kvfwtlscanadacentral) | `/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0/resourceGroups/rg-mid-identity-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvfwtlscanadacentral/privateEndpointConnections/pep-azfw-connectivity-canadacentral-001` | The underlying `Microsoft.Network/privateEndpoints` resource lives in the connectivity subscription, so there is no ID in this subscription to import the endpoint against. The vault-side connection-approval object is not independently importable through the key-vault wrapper. | When the connectivity subscription is adopted, add a `private_endpoints` entry to this vault's wrapper config pointing at that endpoint's subnet. Do not try to import the connection object directly. |
| `Microsoft.KeyVault/vaults/privateEndpointConnections` | pep-kvidndevops (kvidndevops) | `/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0/resourceGroups/rg-siem-identity-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvidndevops/privateEndpointConnections/pep-kvidndevops` | Same reason. | Same as above. |

## Not unsupported, but not separately imported either

The storage account's `blobServices/default`, `fileServices/default`,
`queueServices/default`, and `tableServices/default` children aren't listed
above — they're not skipped, they're **folded into `storage_account["shared"]`'s
own configuration** (`network_rules`, and `blob_properties` left
intentionally unset — see `REMEDIATION.md`) rather than imported as separate
resources, per how the AVM storage-account module models them.

## Open items

`key_vault["onboarding_prod"]` (kvonboardingprodcac001) is imported and all its
values are confirmed against live as of 2026-08-28. Two carry ongoing risk:

- `purge_protection_enabled = false` — live value, and a divergence from the
  wrapper default. See `REMEDIATION.md`.
- `network_acls` mirrors live: `bypass = "None"` with 59 Microsoft-published
  service tag CIDRs (Azure DevOps plus canadacentral service endpoints) in
  `ip_rules`, re-verified against the portal on 2026-09-02. The import is a
  no-op, which is the point — the alternative, an empty `ip_rules` with
  `bypass = "AzureServices"`, would have stripped the vault's firewall
  allowances at apply and cut off callers outside Key Vault's trusted-services
  list, Azure DevOps agents included. The cost of mirroring is that these
  ranges track Microsoft's revision schedule, so each revision shows up as a
  plan diff here. Re-baseline from the portal when that happens. A private
  endpoint or `virtual_network_subnet_ids` remains the durable answer.

Resource group tags: confirmed on 2026-09-02 with `az group list`. All six
groups carry no tags — five return `null`, one returns `{}` — so `tags = {}` in
`identity.tfvars` is a correct transcription for every group, including the two
that were never in an ARM export.

A template export cannot answer this: a resource group's own tags are not part
of its exported template, which is why `az group list` was used.
