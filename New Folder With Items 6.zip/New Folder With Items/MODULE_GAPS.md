# Module gaps — `identity-lz`

Unresolved AVM module limitations affecting resources this deployment adopts.
Each was verified against module source, not release notes; versions in
brackets were checked and still carry the issue.

Waivers referenced below are `--allow-resource` flags passed to
`scripts/verify_zero_diff.sh` from `.github/workflows/import-verify.yml`. A
waived resource is reported under `WAIVED` in the gate output and printed in
full, never hidden.

A gap is waived permanently only when nothing can remove the diff — no tfvars
value and no published module version. A cosmetic gap that converges on the
first apply may carry a transitional waiver while the adoption is in flight, and
the row says so; those flags come out once a post-apply plan is clean.

Distinct from `UNSUPPORTED.md`, which lists resources with no wrapper at all —
everything here **is** imported, but the module forces or omits a value.

| Module | Version | Issue | Why it is unresolved | How it is handled |
|---|---|---|---|---|
| Azure/avm-res-keyvault-vault/azurerm | 0.10.2 (also 0.11.0) | Access-policy permissions are typed set(string), but the provider attribute they feed (azurerm_key_vault_access_policy.*_permissions) is list(string). Terraform sorts string sets on conversion, so the provider always receives them alphabetically while Azure returns its own order. | No tfvars value can produce Azure's order - the sort happens inside the module. Permissions are identical; only ordering differs. | Not waived. Membership is identical so the apply changes nothing, and it converges. The gate fails on the four policies until then. Confirmed as ordering on a plan: every - entry reappears as a + entry, and ap2 is both the only policy with an empty key_permissions and the only one that does not diff on that attribute. |

## Upgrade note

`avm-res-recoveryservices-vault` 1.2.0 fixes none of the above and changes
`soft_delete_enabled` from `bool` to `string` (`Enabled` / `Disabled` /
`AlwaysOn`), which this deployment's `true` would fail validation against.
