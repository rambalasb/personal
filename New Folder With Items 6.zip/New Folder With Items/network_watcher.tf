# Dependencies: resource_group (per-instance binding via resource_group_key).
# The AVM network watcher module manages flow logs and connection monitors on an
# existing watcher; it cannot create the watcher itself, so this is a native
# resource plus an import.
# Imports 1 existing network watcher. Delete the import block below once
# `terraform apply` has adopted it into state.

resource "azurerm_network_watcher" "this" {
  for_each = var.enable_network_watcher ? var.network_watcher : {}

  name                = each.value.name
  resource_group_name = module.resource_group[each.value.resource_group_key].name
  location            = each.value.location
  tags                = merge(local.common_tags, each.value.tags)
}

import {
  for_each = var.enable_network_watcher ? var.network_watcher_imports : {}

  to = azurerm_network_watcher.this[each.key]
  id = each.value
}
