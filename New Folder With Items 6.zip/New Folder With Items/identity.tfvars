# ── Shared ─────────────────────────────────────────────────────────────
subscription_id = "b6dc12b1-645d-4a43-b08f-50c862f793d0"
tags            = {}

# ── Feature flags ──────────────────────────────────────────────────────
# All false: adoption runs one resource type per branch, so this file always
# reflects what is actually in state. Each phase flips exactly one flag to
# true and leaves the earlier ones true -- they accumulate. A flag going
# back to false on an adopted resource empties its for_each and plans a
# destroy, so they only ever move one way.
#
# enable_resource_group must be true for any other flag to work: every other
# module indexes module.resource_group[key] directly.
# enable_amba stays false permanently -- AMBA assigns policy across the
# management group hierarchy, well outside adopting this subscription.
enable_resource_group         = false
enable_user_assigned_identity = false
enable_key_vault              = false
enable_storage_account        = false

# ── Module config (mirrors live configuration) ──────────────────────────

# Tags not present in a template export — left {} for every resource group.
resource_group = {
  "mid_identity" = {
    name     = "rg-mid-identity-canadacentral-001"
    location = "canadacentral"
    tags     = {}
  }
  "alerts_identity" = {
    name     = "rg-alerts-identity-canadacentral-001"
    location = "canadacentral"
    tags     = {}
  }
  "siem_identity" = {
    name     = "rg-siem-identity-canadacentral-001"
    location = "canadacentral"
    tags     = {}
  }
  "shared_identity" = {
    name     = "rg-shared-identity-canadacentral-001"
    location = "canadacentral"
    tags     = {}
  }
  # Added after the original adoption. Confirm live tags before applying --
  # these two were never in the ARM export the rest of this file came from.
  "onboarding_prod" = {
    name     = "rg-onboarding-prod-canadacentral-001"
    location = "canadacentral"
    tags     = {}
  }
  "lifecycleworkflows_prod" = {
    name     = "rg-Lifecycleworkflows-prod-canadacentral-001"
    location = "canadacentral"
    tags     = {}
  }
}

user_assigned_identity = {
  "dev_autmn" = {
    name               = "mid-dev-autmn-canadacentral-001"
    resource_group_key = "mid_identity"
    location           = "canadacentral"
    tags               = {}
  }
  "prod_autmn" = {
    name               = "mid-prod-autmn-canadacentral-001"
    resource_group_key = "mid_identity"
    location           = "canadacentral"
    tags               = {}
  }
  # Live value is "Regional"; the other two identities have it unset.
  "azfirewall" = {
    name               = "mid-azfirewall-canadacentral-001"
    resource_group_key = "mid_identity"
    location           = "canadacentral"
    isolation_scope    = "Regional"
    tags               = {}
  }
}

key_vault = {
  "fw_tls" = {
    name               = "kvfwtlscanadacentral"
    resource_group_key = "mid_identity"
    location           = "canadacentral"
    tenant_id          = "8fbb85e8-0cbc-48c3-a2e9-528cef30ec27"

    sku_name                        = "premium" # live value "Premium"; wrapper requires lowercase
    purge_protection_enabled        = false     # live value; see REMEDIATION.md
    soft_delete_retention_days      = 90
    public_network_access_enabled   = false
    enabled_for_deployment          = false
    enabled_for_disk_encryption     = false
    enabled_for_template_deployment = false
    legacy_access_policies_enabled  = true # live value; see REMEDIATION.md

    # Order here is cosmetic and cannot be made to match Azure: the AVM module
    # types these as set(string), so Terraform sorts them before they reach the
    # provider's list(string) attribute. The resulting plan diff is a reorder of
    # identical permissions, which Azure treats as a set. It converges after one
    # apply. Kept in ARM order for readability only.
    # ap* keys are opaque and object_id is a bare directory GUID. Annotated
    # where the principal is a managed identity in this subscription; resolve
    # the rest with `az ad sp show --id <object_id> --query displayName`, or
    # `az ad user show` / `az ad group show` if it is not a service principal.
    legacy_access_policies = {
      # Principal is outside this subscription's managed identities.
      "ap1" = {
        object_id               = "ec395925-29f4-4aea-8c73-d259eebfae60"
        key_permissions         = ["Get", "List", "Update", "Create", "Import", "Delete", "Recover", "Backup", "Restore", "GetRotationPolicy", "SetRotationPolicy", "Rotate"]
        secret_permissions      = ["Get", "List", "Set", "Delete", "Recover", "Backup", "Restore"]
        certificate_permissions = ["Get", "List", "Update", "Create", "Import", "Delete", "Recover", "Backup", "Restore", "ManageContacts", "ManageIssuers", "GetIssuers", "ListIssuers", "SetIssuers", "DeleteIssuers"]
      }
      # mid-azfirewall-canadacentral-001 (user-assigned identity, this
      # subscription). key_permissions is empty because the firewall needs only
      # the TLS certificate and its secret.
      "ap2" = {
        object_id               = "39b857c4-f63b-4799-9333-3e41ae1893a5"
        key_permissions         = []
        secret_permissions      = ["Get", "List", "Set", "Delete", "Recover", "Backup", "Restore"]
        certificate_permissions = ["Get", "List", "Update", "Create", "Import", "Delete", "Recover", "Backup", "Restore", "ManageContacts", "ManageIssuers", "GetIssuers", "ListIssuers", "SetIssuers", "DeleteIssuers"]
      }
      # Principal is outside this subscription's managed identities.
      "ap3" = {
        object_id               = "ccbfdac6-97ec-4bf6-b80c-a299289a969c"
        key_permissions         = ["Get", "List", "Update", "Create", "Import", "Delete", "Recover", "Backup", "Restore", "GetRotationPolicy", "SetRotationPolicy", "Rotate"]
        secret_permissions      = ["Get", "List", "Set", "Delete", "Recover", "Backup", "Restore"]
        certificate_permissions = ["Get", "List", "Update", "Create", "Import", "Delete", "Recover", "Backup", "Restore", "ManageContacts", "ManageIssuers", "GetIssuers", "ListIssuers", "SetIssuers", "DeleteIssuers"]
      }
    }

    network_acls = {
      bypass                     = "AzureServices" # live value; wrapper defaults bypass to "None"
      default_action             = "Deny"
      ip_rules                   = []
      virtual_network_subnet_ids = []
    }

    tags = {}
  }

  "idn" = {
    name               = "kvidncanadacentral"
    resource_group_key = "siem_identity"
    location           = "canadacentral"
    tenant_id          = "8fbb85e8-0cbc-48c3-a2e9-528cef30ec27"

    sku_name                        = "premium"
    purge_protection_enabled        = true
    soft_delete_retention_days      = 7
    public_network_access_enabled   = true # live value; see REMEDIATION.md
    enabled_for_deployment          = true # live value; see REMEDIATION.md
    enabled_for_disk_encryption     = true # live value; see REMEDIATION.md
    enabled_for_template_deployment = true # live value; see REMEDIATION.md
    legacy_access_policies_enabled  = false
    legacy_access_policies          = {}

    network_acls = {
      bypass                     = "AzureServices" # live value; wrapper defaults bypass to "None"
      default_action             = "Deny"
      ip_rules                   = ["155.190.0.0/16"]
      virtual_network_subnet_ids = []
    }

    tags = {}
  }

  "idn_devops" = {
    name               = "kvidndevops"
    resource_group_key = "siem_identity"
    location           = "canadacentral"
    tenant_id          = "8fbb85e8-0cbc-48c3-a2e9-528cef30ec27"

    sku_name                        = "standard" # live value "Standard"; see REMEDIATION.md
    purge_protection_enabled        = true
    soft_delete_retention_days      = 90
    public_network_access_enabled   = false
    enabled_for_deployment          = false
    enabled_for_disk_encryption     = false
    enabled_for_template_deployment = true # live value; see REMEDIATION.md
    legacy_access_policies_enabled  = true # live value; see REMEDIATION.md

    legacy_access_policies = {
      # Principal is outside this subscription's managed identities. Resolve
      # with `az ad sp show --id <object_id> --query displayName`.
      "ap1" = {
        object_id               = "b1994337-b261-4c15-a17a-7e4e0eababbe"
        key_permissions         = ["Get", "List", "Update", "Create", "Import", "Delete", "Recover", "Backup", "Restore", "GetRotationPolicy", "SetRotationPolicy", "Rotate"]
        secret_permissions      = ["Get", "List", "Set", "Delete", "Recover", "Backup", "Restore"]
        certificate_permissions = ["Get", "List", "Update", "Create", "Import", "Delete", "Recover", "Backup", "Restore", "ManageContacts", "ManageIssuers", "GetIssuers", "ListIssuers", "SetIssuers", "DeleteIssuers"]
      }
    }

    network_acls = {
      bypass                     = "AzureServices" # live value; wrapper defaults bypass to "None"
      default_action             = "Deny"
      ip_rules                   = []
      virtual_network_subnet_ids = []
    }

    tags = {
      DoNotDelete = "yes"
      Owner       = "Terraform Intergation"
    }
  }

  # Created 2026-08-14, after the original adoption. RBAC-authorised, so no
  # legacy access policies to flatten.
  # Values confirmed against live 2026-08-28.
  "onboarding_prod" = {
    name               = "kvonboardingprodcac001"
    resource_group_key = "onboarding_prod"
    location           = "canadacentral"
    tenant_id          = "8fbb85e8-0cbc-48c3-a2e9-528cef30ec27"

    sku_name                        = "premium"
    purge_protection_enabled        = false # live value; see REMEDIATION.md
    soft_delete_retention_days      = 90
    public_network_access_enabled   = true # live value; the firewall below is what restricts it
    enabled_for_deployment          = false
    enabled_for_disk_encryption     = false
    enabled_for_template_deployment = false
    legacy_access_policies_enabled  = false
    legacy_access_policies          = {}

    # Mirrors live exactly so the import is a no-op: bypass "None" and the 59
    # Microsoft service tag CIDRs (Azure DevOps plus canadacentral endpoints)
    # that are pinned on the vault. Verified against the portal.
    #
    # The cost of mirroring rather than simplifying: these ranges track
    # Microsoft's published service tags, so a plan diff appears here whenever
    # Microsoft revises them. Re-baseline from the portal when that happens --
    # do not "fix" it by emptying the list, which would remove the vault's
    # firewall allowances and cut off anything outside Key Vault's
    # trusted-services list, Azure DevOps agents included.
    network_acls = {
      bypass         = "None"
      default_action = "Deny"
      ip_rules = [
        "13.71.170.208/28",
        "13.71.175.160/27",
        "20.48.200.192/27",
        "20.48.200.224/28",
        "20.200.90.162/32",
        "20.200.91.36/32",
        "40.82.184.6/32",
        "40.82.184.43/32",
        "40.85.206.95/32",
        "52.237.24.126/32",
        "52.237.32.212/32",
        "20.104.170.166/32",
        "20.104.170.192/32",
        "40.69.106.240/28",
        "40.69.111.0/27",
        "52.139.111.0/27",
        "52.139.111.32/28",
        "52.242.30.112/32",
        "52.242.35.152/32",
        "52.242.36.40/32",
        "4.172.0.0/15",
        "4.174.0.0/16",
        "4.229.128.0/17",
        "4.248.128.0/17",
        "9.129.51.64/26",
        "9.129.55.64/27",
        "9.129.58.128/28",
        "13.88.224.0/19",
        "13.104.151.192/26",
        "13.104.152.0/25",
        "13.104.208.176/28",
        "13.104.212.192/26",
        "13.104.223.192/26",
        "20.20.128.0/24",
        "20.20.134.0/24",
        "20.33.97.0/24",
        "20.33.107.0/24",
        "20.33.114.0/24",
        "20.33.151.0/24",
        "20.33.187.0/24",
        "20.38.114.0/25",
        "20.38.144.0/21",
        "20.39.128.0/20",
        "20.60.42.0/23",
        "20.47.40.0/24",
        "20.48.224.0/19",
        "20.60.242.0/23",
        "20.63.0.0/17",
        "20.95.20.0/24",
        "20.135.184.0/22",
        "20.150.16.0/24",
        "20.150.31.0/24",
        "20.150.71.0/24",
        "20.150.100.0/24",
        "20.151.0.0/16",
        "20.153.15.0/24",
        "20.157.26.0/24",
        "20.157.52.0/24",
        "52.228.0.0/17",
      ]
      virtual_network_subnet_ids = []
    }

    # Live tag key is misspelled ("CostCente") with an empty value. Reproduced
    # so the import is a no-op; fix in Azure and here together, not here alone.
    tags = {
      CostCente = ""
    }
  }
}

# blob_properties is intentionally omitted below (module default null) — the
# live account has versioning and delete-retention off, which is exactly what
# an unset blob_properties block leaves alone. See REMEDIATION.md.
# resourceAccessRules (Microsoft Defender's StorageDataScanner) maps onto
# network_rules.private_link_access, which the wrapper does support.
storage_account = {
  "shared" = {
    name               = "stnwidncanadacentral"
    resource_group_key = "shared_identity"
    location           = "canadacentral"

    account_kind                      = "StorageV2"
    account_tier                      = "Standard"
    account_replication_type          = "LRS"
    access_tier                       = "Hot"
    min_tls_version                   = "TLS1_2"
    allow_nested_items_to_be_public   = false
    shared_access_key_enabled         = false
    public_network_access_enabled     = true # live value; see REMEDIATION.md
    local_user_enabled                = true # live value; see REMEDIATION.md
    cross_tenant_replication_enabled  = false
    https_traffic_only_enabled        = true
    default_to_oauth_authentication   = false # live value; see REMEDIATION.md
    infrastructure_encryption_enabled = false # live value; IMMUTABLE — see REMEDIATION.md
    is_hns_enabled                    = false

    network_rules = {
      bypass                     = ["AzureServices"]
      default_action             = "Allow" # live value; see REMEDIATION.md
      ip_rules                   = []
      virtual_network_subnet_ids = []
      private_link_access = [
        {
          endpoint_resource_id = "/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0/providers/Microsoft.Security/datascanners/StorageDataScanner"
          endpoint_tenant_id   = "8fbb85e8-0cbc-48c3-a2e9-528cef30ec27"
        }
      ]
    }

    containers = {
      "insights-metrics-pt1m" = {
        name          = "insights-metrics-pt1m"
        public_access = "None"
      }
    }

    tags = {}
  }
}

# ── Imports — delete this section after `terraform apply` adopts them ──

resource_group_imports = {
  "mid_identity"    = "/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0/resourceGroups/rg-mid-identity-canadacentral-001?api-version=2025-04-01"
  "alerts_identity" = "/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0/resourceGroups/rg-alerts-identity-canadacentral-001?api-version=2025-04-01"
  "siem_identity"   = "/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0/resourceGroups/rg-siem-identity-canadacentral-001?api-version=2025-04-01"
  "shared_identity" = "/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0/resourceGroups/rg-shared-identity-canadacentral-001?api-version=2025-04-01"

  "onboarding_prod"         = "/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0/resourceGroups/rg-onboarding-prod-canadacentral-001?api-version=2025-04-01"
  "lifecycleworkflows_prod" = "/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0/resourceGroups/rg-Lifecycleworkflows-prod-canadacentral-001?api-version=2025-04-01"
}

user_assigned_identity_imports = {
  "dev_autmn"  = "/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0/resourceGroups/rg-mid-identity-canadacentral-001/providers/Microsoft.ManagedIdentity/userAssignedIdentities/mid-dev-autmn-canadacentral-001"
  "prod_autmn" = "/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0/resourceGroups/rg-mid-identity-canadacentral-001/providers/Microsoft.ManagedIdentity/userAssignedIdentities/mid-prod-autmn-canadacentral-001"
  "azfirewall" = "/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0/resourceGroups/rg-mid-identity-canadacentral-001/providers/Microsoft.ManagedIdentity/userAssignedIdentities/mid-azfirewall-canadacentral-001"
}

key_vault_imports = {
  "fw_tls"     = "/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0/resourceGroups/rg-mid-identity-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvfwtlscanadacentral"
  "idn"        = "/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0/resourceGroups/rg-siem-identity-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvidncanadacentral"
  "idn_devops" = "/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0/resourceGroups/rg-siem-identity-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvidndevops"

  "onboarding_prod" = "/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0/resourceGroups/rg-onboarding-prod-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvonboardingprodcac001"
}

key_vault_access_policy_imports = {
  "fw_tls/ap1" = {
    vault_key  = "fw_tls"
    policy_key = "ap1"
    id         = "/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0/resourceGroups/rg-mid-identity-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvfwtlscanadacentral/objectId/ec395925-29f4-4aea-8c73-d259eebfae60"
  }
  "fw_tls/ap2" = {
    vault_key  = "fw_tls"
    policy_key = "ap2"
    id         = "/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0/resourceGroups/rg-mid-identity-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvfwtlscanadacentral/objectId/39b857c4-f63b-4799-9333-3e41ae1893a5"
  }
  "fw_tls/ap3" = {
    vault_key  = "fw_tls"
    policy_key = "ap3"
    id         = "/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0/resourceGroups/rg-mid-identity-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvfwtlscanadacentral/objectId/ccbfdac6-97ec-4bf6-b80c-a299289a969c"
  }
  "idn_devops/ap1" = {
    vault_key  = "idn_devops"
    policy_key = "ap1"
    id         = "/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0/resourceGroups/rg-siem-identity-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvidndevops/objectId/b1994337-b261-4c15-a17a-7e4e0eababbe"
  }
}

storage_account_imports = {
  "shared" = "/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0/resourceGroups/rg-shared-identity-canadacentral-001/providers/Microsoft.Storage/storageAccounts/stnwidncanadacentral"
}

# api-version must match the type the AVM module declares on
# azapi_resource.containers, which is 2023-01-01.
storage_account_container_imports = {
  "shared/insights-metrics-pt1m" = {
    account_key   = "shared"
    container_key = "insights-metrics-pt1m"
    id            = "/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0/resourceGroups/rg-shared-identity-canadacentral-001/providers/Microsoft.Storage/storageAccounts/stnwidncanadacentral/blobServices/default/containers/insights-metrics-pt1m?api-version=2023-01-01"
  }
}

# ── Monitoring / network watcher / event grid ─────────────────────────
# Values transcribed from the ARM export. Action group IDs are reproduced
# byte-for-byte, including the export's inconsistent subscription-GUID casing
# and the leading space in the ServiceNow action group's name — Terraform
# compares these as strings, so "tidying" them would produce a diff.
enable_monitoring              = false
enable_amba                    = false
enable_network_watcher         = false
enable_event_grid_system_topic = false

alert = {
  resource_group_key = "alerts_identity"

  activity_log_alerts = {
    "keyvault_deletion" = {
      name                = "KeyVault-Deletion-Alert-canadacentral"
      resource_group_name = "rg-alerts-identity-canadacentral-001"
      scopes              = ["/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0"]
      location            = "global"
      description         = "This alert will monitor any deletion of key vault"
      enabled             = true
      criteria = {
        category       = "Administrative"
        operation_name = "Microsoft.KeyVault/vaults/delete"
      }
      action_group_ids = ["/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"]
      tags             = {}
    }
    "service_outage" = {
      name                = "Service-Outage-Alert-canadacentral"
      resource_group_name = "rg-alerts-identity-canadacentral-001"
      scopes              = ["/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0"]
      location            = "global"
      description         = "Azure Landing Zone Service Health Alert"
      enabled             = true
      criteria = {
        category = "ServiceHealth"
        service_health = {
          events    = []
          locations = ["Global"]
          services  = []
        }
      }
      action_group_ids = ["/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-monitor-mail-alerts-canadacentral-001"]
      tags             = {}
    }
  }

  log_search_alerts = {
    "kv_secret_expired" = {
      name                    = "KeyVault-Secret-Expired-Alert-canadacentral"
      resource_group_name     = "rg-alerts-identity-canadacentral-001"
      location                = "canadacentral"
      scopes                  = ["/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0"]
      severity                = 0
      evaluation_frequency    = "PT5M"
      window_duration         = "PT30M"
      description             = "Alert for expired secret in a Key Vault."
      display_name            = "KeyVault-Secret-Expired-Alert-canadacentral"
      enabled                 = true
      auto_mitigation_enabled = false
      skip_query_validation   = false
      target_resource_types   = []
      criteria = [{
        query                   = "        AzureDiagnostics\n        | where ResourceProvider == \"MICROSOFT.KEYVAULT\"\n        | where OperationName contains \"SecretExpired\"\n        "
        time_aggregation_method = "Count"
        threshold               = 1
        operator                = "GreaterThanOrEqual"
        resource_id_column      = "ResourceId"
        failing_periods = {
          minimum_failing_periods_to_trigger_alert = 1
          number_of_evaluation_periods             = 1
        }
      }]
      action_group_ids  = ["/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"]
      custom_properties = {}
      tags              = {}
    }
    "kv_secret_near_expiry" = {
      name                    = "KeyVault-Secret-Near-Expiry-Alert-canadacentral"
      resource_group_name     = "rg-alerts-identity-canadacentral-001"
      location                = "canadacentral"
      scopes                  = ["/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0"]
      severity                = 1
      evaluation_frequency    = "PT5M"
      window_duration         = "PT30M"
      description             = "Alert for secret in a Key Vault is about to expire."
      display_name            = "KeyVault-Secret-Near-Expiry-Alert-canadacentral"
      enabled                 = true
      auto_mitigation_enabled = false
      skip_query_validation   = false
      target_resource_types   = []
      criteria = [{
        query                   = "        AzureDiagnostics\n        | where ResourceProvider == \"MICROSOFT.KEYVAULT\"\n        | where OperationName contains \"SecretNearExpiry\"\n        "
        time_aggregation_method = "Count"
        threshold               = 1
        operator                = "GreaterThanOrEqual"
        resource_id_column      = "ResourceId"
        failing_periods = {
          minimum_failing_periods_to_trigger_alert = 1
          number_of_evaluation_periods             = 1
        }
      }]
      action_group_ids  = ["/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"]
      custom_properties = {}
      tags              = {}
    }
    "resource_creation" = {
      name                    = "Resource-Creation-Alert-canadacentral"
      resource_group_name     = "rg-alerts-identity-canadacentral-001"
      location                = "canadacentral"
      scopes                  = ["/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0"]
      severity                = 4
      evaluation_frequency    = "PT10M"
      window_duration         = "PT30M"
      description             = "Alert when a new resource is created."
      display_name            = "Resource-Creation-Alert-canadacentral"
      enabled                 = true
      auto_mitigation_enabled = false
      skip_query_validation   = false
      target_resource_types   = []
      criteria = [{
        query                   = "        AzureActivity\n        | where OperationNameValue has \"Microsoft.Resources/deployments/write\"\n        | where CategoryValue == \"Administrative\"\n        | where ActivityStatusValue == \"Success\"\n        "
        time_aggregation_method = "Count"
        threshold               = 10
        operator                = "GreaterThanOrEqual"
        resource_id_column      = "_ResourceId"
        failing_periods = {
          minimum_failing_periods_to_trigger_alert = 1
          number_of_evaluation_periods             = 1
        }
      }]
      action_group_ids  = ["/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"]
      custom_properties = {}
      tags              = {}
    }
    "storage_container_deletion" = {
      name                    = "Storage-Account-Container-Deletion-Alert-canadacentral"
      resource_group_name     = "rg-alerts-identity-canadacentral-001"
      location                = "canadacentral"
      scopes                  = ["/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0"]
      severity                = 0
      evaluation_frequency    = "PT5M"
      window_duration         = "PT30M"
      description             = "Alert for the deletion of Storage Account Container."
      display_name            = "Storage-Account-Container-Deletion-Alert-canadacentral"
      enabled                 = true
      auto_mitigation_enabled = false
      skip_query_validation   = false
      target_resource_types   = []
      criteria = [{
        query                   = "        AzureActivity\n        | where ResourceProviderValue == \"MICROSOFT.STORAGE\" and OperationNameValue == \"MICROSOFT.STORAGE/STORAGEACCOUNTS/BLOBSERVICES/CONTAINERS/DELETE\"\n        "
        time_aggregation_method = "Count"
        threshold               = 1
        operator                = "GreaterThanOrEqual"
        resource_id_column      = "_ResourceId"
        failing_periods = {
          minimum_failing_periods_to_trigger_alert = 1
          number_of_evaluation_periods             = 1
        }
      }]
      action_group_ids  = ["/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"]
      custom_properties = {}
      tags              = {}
    }
    "storage_deletion" = {
      name                    = "Storage-Account-Deletion-Alert-canadacentral"
      resource_group_name     = "rg-alerts-identity-canadacentral-001"
      location                = "canadacentral"
      scopes                  = ["/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0"]
      severity                = 0
      evaluation_frequency    = "PT5M"
      window_duration         = "PT30M"
      description             = "Alert for the deletion of Storage Account."
      display_name            = "Storage-Account-Deletion-Alert-canadacentral"
      enabled                 = true
      auto_mitigation_enabled = false
      skip_query_validation   = false
      target_resource_types   = []
      criteria = [{
        query                   = "        AzureActivity\n        | where ResourceProviderValue == \"MICROSOFT.STORAGE\" and OperationNameValue == \"MICROSOFT.STORAGE/STORAGEACCOUNTS/DELETE\"\n        "
        time_aggregation_method = "Count"
        threshold               = 1
        operator                = "GreaterThanOrEqual"
        resource_id_column      = "_ResourceId"
        failing_periods = {
          minimum_failing_periods_to_trigger_alert = 1
          number_of_evaluation_periods             = 1
        }
      }]
      action_group_ids  = ["/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/lga-servicenow-integration_group/providers/microsoft.insights/actiongroups/ ag-servicenow-alerts-canadacentral-001"]
      custom_properties = {}
      tags              = {}
    }
  }
}

network_watcher = {
  "identity" = {
    name               = "NetworkWatcher_canadacentral_identity"
    resource_group_key = "shared_identity"
    location           = "canadacentral"
    tags               = {}
  }
}

# source_resource_id intentionally omitted — see event_grid_system_topic.tf.
event_grid_system_topic = {
  "shared" = {
    name               = "stnwidncanadacentral-bb43e3f7-7be0-4dc3-99e9-10766e4990c0"
    resource_group_key = "shared_identity"
    location           = "canadacentral"
    topic_type         = "microsoft.storage.storageaccounts"
    tags               = {}
  }
}

activity_log_alert_imports = {
  "keyvault_deletion" = "/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0/resourceGroups/rg-alerts-identity-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/KeyVault-Deletion-Alert-canadacentral"
  "service_outage"    = "/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0/resourceGroups/rg-alerts-identity-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/Service-Outage-Alert-canadacentral"
}

log_search_alert_imports = {
  "kv_secret_expired"          = "/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0/resourceGroups/rg-alerts-identity-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/KeyVault-Secret-Expired-Alert-canadacentral"
  "kv_secret_near_expiry"      = "/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0/resourceGroups/rg-alerts-identity-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/KeyVault-Secret-Near-Expiry-Alert-canadacentral"
  "resource_creation"          = "/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0/resourceGroups/rg-alerts-identity-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/Resource-Creation-Alert-canadacentral"
  "storage_container_deletion" = "/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0/resourceGroups/rg-alerts-identity-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/Storage-Account-Container-Deletion-Alert-canadacentral"
  "storage_deletion"           = "/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0/resourceGroups/rg-alerts-identity-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/Storage-Account-Deletion-Alert-canadacentral"
}

network_watcher_imports = {
  "identity" = "/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0/resourceGroups/rg-shared-identity-canadacentral-001/providers/Microsoft.Network/networkWatchers/NetworkWatcher_canadacentral_identity"
}

event_grid_system_topic_imports = {
  "shared" = "/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0/resourceGroups/rg-shared-identity-canadacentral-001/providers/Microsoft.EventGrid/systemTopics/stnwidncanadacentral-bb43e3f7-7be0-4dc3-99e9-10766e4990c0"
}

