# Dependencies: resource_group (per-instance binding via resource_group_key).
# Adopts the 1 storage account exported from rg-shared-identity.
# blob_properties is intentionally left unset (null) — the live account has
# versioning and delete-retention off, which matches what an unset
# blob_properties block already leaves alone. See REMEDIATION.md.
# Imports 1 existing storage account plus 1 existing container. Delete the
# import blocks below once `terraform apply` has adopted them into state.

module "storage_account" {
  for_each = var.enable_storage_account ? var.storage_account : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-storage-account/azurerm"
  version = "0.1.0"

  name                = each.value.name
  resource_group_name = module.resource_group[each.value.resource_group_key].name
  location            = each.value.location

  # Mirrors the live configuration. Divergences from the wrapper's secure
  # defaults are listed in REMEDIATION.md.
  account_kind                      = each.value.account_kind
  account_tier                      = each.value.account_tier
  account_replication_type          = each.value.account_replication_type
  access_tier                       = each.value.access_tier
  min_tls_version                   = each.value.min_tls_version
  allow_nested_items_to_be_public   = each.value.allow_nested_items_to_be_public
  shared_access_key_enabled         = each.value.shared_access_key_enabled
  public_network_access_enabled     = each.value.public_network_access_enabled
  local_user_enabled                = each.value.local_user_enabled
  cross_tenant_replication_enabled  = each.value.cross_tenant_replication_enabled
  https_traffic_only_enabled        = each.value.https_traffic_only_enabled
  default_to_oauth_authentication   = each.value.default_to_oauth_authentication
  infrastructure_encryption_enabled = each.value.infrastructure_encryption_enabled
  is_hns_enabled                    = each.value.is_hns_enabled
  network_rules                     = each.value.network_rules
  containers                        = each.value.containers

  enable_telemetry = false
  tags             = merge(local.common_tags, each.value.tags)
}

import {
  for_each = var.enable_storage_account ? var.storage_account_imports : {}

  to = module.storage_account[each.key].module.storage_account.azurerm_storage_account.this
  id = each.value
}

# Containers are a for_each map inside the AVM module, so the container's own
# key is part of the address. Flattened to "<account_key>/<container_key>".
import {
  for_each = var.enable_storage_account ? var.storage_account_container_imports : {}

  to = module.storage_account[each.value.account_key].module.storage_account.azapi_resource.containers[each.value.container_key]
  id = each.value.id
}
