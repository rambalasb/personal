# Dependencies: resource_group (per-instance binding via resource_group_key).
# avm-res-eventgrid-systemtopic has no released version, so no wrapper exists.
# Native resource plus an import until it ships.
#
# source_resource_id is deliberately left unset. It is Optional+Computed and
# ForceNew, and the live value carries lowercase provider casing
# (microsoft.storage/storageaccounts) that differs from the canonical casing a
# module output returns. Setting it would plan a replacement of the topic on a
# pure casing difference; leaving it unset adopts whatever is live.
# Set it only when creating a topic from scratch.

resource "azurerm_eventgrid_system_topic" "this" {
  for_each = var.enable_event_grid_system_topic ? var.event_grid_system_topic : {}

  name                = each.value.name
  resource_group_name = module.resource_group[each.value.resource_group_key].name
  location            = each.value.location
  topic_type          = each.value.topic_type
  source_resource_id  = each.value.source_resource_id
  tags                = merge(local.common_tags, each.value.tags)
}

import {
  for_each = var.enable_event_grid_system_topic ? var.event_grid_system_topic_imports : {}

  to = azurerm_eventgrid_system_topic.this[each.key]
  id = each.value
}
