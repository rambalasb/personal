# Dependencies: resource_group (per-instance binding via resource_group_key).
# Adopts all 4 key vaults in the subscription: 3 from the ARM export
# (rg-mid-identity, rg-siem-identity) plus kvonboardingprodcac001, created
# after that export and still carrying TODO(live) values in identity.tfvars.
# Secrets, keys, and private endpoint connections are NOT imported — see
# UNSUPPORTED.md. Imports 4 existing key vaults plus their legacy access
# policies. Delete the import blocks below once `terraform apply` has adopted
# them into state.

module "key_vault" {
  for_each = var.enable_key_vault ? var.key_vault : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-key-vault/azurerm"
  version = "0.2.0"

  name                = each.value.name
  resource_group_name = module.resource_group[each.value.resource_group_key].name
  location            = each.value.location
  tenant_id           = each.value.tenant_id

  # Mirrors the live configuration. Divergences from the wrapper's secure
  # defaults are listed in REMEDIATION.md.
  sku_name                        = each.value.sku_name
  purge_protection_enabled        = each.value.purge_protection_enabled
  soft_delete_retention_days      = each.value.soft_delete_retention_days
  public_network_access_enabled   = each.value.public_network_access_enabled
  enabled_for_deployment          = each.value.enabled_for_deployment
  enabled_for_disk_encryption     = each.value.enabled_for_disk_encryption
  enabled_for_template_deployment = each.value.enabled_for_template_deployment
  legacy_access_policies_enabled  = each.value.legacy_access_policies_enabled
  legacy_access_policies          = each.value.legacy_access_policies
  network_acls                    = each.value.network_acls

  enable_telemetry = false
  tags             = merge(local.common_tags, each.value.tags)
}

import {
  for_each = var.enable_key_vault ? var.key_vault_imports : {}

  to = module.key_vault[each.key].module.key_vault.azurerm_key_vault.this
  id = each.value
}

# Legacy access policies are a for_each map inside the AVM module, so the
# policy's own key is part of the address. Flattened to "<vault_key>/<policy_key>".
import {
  for_each = var.enable_key_vault ? var.key_vault_access_policy_imports : {}

  to = module.key_vault[each.value.vault_key].module.key_vault.azurerm_key_vault_access_policy.this[each.value.policy_key]
  id = each.value.id
}
