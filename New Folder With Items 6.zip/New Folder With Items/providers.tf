terraform {
  required_version = ">= 1.10, < 2.0"

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 4.37.0, < 5.0.0"
    }
    azapi = {
      source  = "Azure/azapi"
      version = ">= 1.15, < 3.0"
    }
  }

  cloud {
    organization = "BC_Hydro"

    workspaces {
      name = "az-platform-identity"
    }
  }
}

provider "azurerm" {
  subscription_id     = var.subscription_id
  storage_use_azuread = true
  features {}
}

provider "azapi" {
  subscription_id = var.subscription_id
}
