# Remediation report — `identity-lz`

Every row below is a place where the live resource differs from the wrapper's
hardened default. Adopting a wrapper default silently on first apply would
change a production system, so the divergence is mirrored into
`identity.tfvars` instead and recorded here. Ordered by blast radius.

## storage_account["shared"] — stnwidncanadacentral
Resource ID: `/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0/resourceGroups/rg-shared-identity-canadacentral-001/providers/Microsoft.Storage/storageAccounts/stnwidncanadacentral`

| Setting | Live (imported) | Wrapper default | tfvars change | Impact |
|---|---|---|---|---|
| `infrastructure_encryption_enabled` | `false` (absent from export → Azure default) | `true` | `storage_account.shared.infrastructure_encryption_enabled = false` | **Cannot be changed in place.** Leaving this unset would plan a destroy-and-recreate of a live storage account. Written explicitly to prevent that. |
| `network_rules.default_action` | `Allow` | `Deny` | `storage_account.shared.network_rules.default_action = "Allow"` | Denies everything not explicitly allowed if flipped to the default. Enumerate current callers (Network Watcher's own diagnostics/flow-log writers, at minimum) before ever tightening this. |
| `public_network_access_enabled` | `true` (`Enabled`) | `false` | `storage_account.shared.public_network_access_enabled = true` | Reachable only via private endpoint if adopted. No private endpoint exists for this account in the export, so flipping this would cut off every current caller at once. |
| `default_to_oauth_authentication` | `false` | `true` | `storage_account.shared.default_to_oauth_authentication = false` | Portal-only default; does not itself block key-based access (see `shared_access_key_enabled` below, which is already `false` on both sides). Low impact, but still an explicit gap between live and wrapper intent. |
| `network_rules.resource_access_rules` | Live has one entry: Microsoft Defender's `StorageDataScanner` resource-access rule (tenant `8fbb85e8-0cbc-48c3-a2e9-528cef30ec27`) | — | **Not expressible.** `tf-wrapper-avm-storage-account`'s `network_rules` variable (AVM 0.6.8) has no `resource_access_rules` attribute. | The import still succeeds, but Terraform cannot express this rule — a future apply cannot accidentally remove it (Terraform doesn't know it exists), but nothing in this deployment can add or manage it either. If Defender for Storage scanning ever needs re-authorizing, it has to happen outside Terraform. |
| `blob_properties` | Versioning off, blob delete-retention off | `versioning_enabled = true`, `delete_retention_policy = {enabled: true, days: 7}` (only if the object is supplied at all) | **Left unset (`null`)**, not supplied as a partial object | The wrapper's `blob_properties` variable defaults to `null` and is wrapped in a `dynamic` block that disappears entirely when null — Azure keeps whatever is already configured. Supplying a *partial* object here to "confirm" versioning/retention are off would instead pull in AVM 0.6.8's `optional()` defaults for every attribute not named, silently turning versioning and 7-day soft delete **on**. Leaving it unset is the correct mirror, not a gap — flagged here so the next reader doesn't assume it was missed. |

## key_vault["fw_tls"] — kvfwtlscanadacentral
Resource ID: `/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0/resourceGroups/rg-mid-identity-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvfwtlscanadacentral`

| Setting | Live (imported) | Wrapper default | tfvars change | Impact |
|---|---|---|---|---|
| `purge_protection_enabled` | `false` (`enablePurgeProtection` absent from export) | `true` | `key_vault.fw_tls.purge_protection_enabled = false` | **One-way if flipped.** Adopting the default would turn purge protection on permanently — safe to do deliberately later, but should never happen as a side effect of an import. |
| `legacy_access_policies_enabled` | `true` (`enableRbacAuthorization: false`) | `false` | `key_vault.fw_tls.legacy_access_policies_enabled = true`, plus 3 `legacy_access_policies` entries mirrored | Adopting the default (RBAC) would revoke all 3 existing access-policy principals' access at the moment of apply, including whatever principal manages the firewall's TLS certificate. Every principal needs an equivalent RBAC role assignment in place *first* if this is ever migrated deliberately. |
| `sku_name` | `"premium"` (export: `"Premium"`) | `"premium"` | `key_vault.fw_tls.sku_name = "premium"` | Case only — the wrapper validates against lowercase `"standard"`/`"premium"`. No functional divergence, just written explicitly so the string matches what the wrapper accepts. |
| `network_acls.bypass` | `"AzureServices"` | `"None"` | `key_vault.fw_tls.network_acls.bypass = "AzureServices"` | Adopting the default would block Azure platform services (e.g. diagnostic settings, some resource providers) from reaching the vault even when otherwise permitted. |

## key_vault["idn"] — kvidncanadacentral
Resource ID: `/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0/resourceGroups/rg-siem-identity-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvidncanadacentral`

| Setting | Live (imported) | Wrapper default | tfvars change | Impact |
|---|---|---|---|---|
| `public_network_access_enabled` | `true` (`Enabled`) | `false` | `key_vault.idn.public_network_access_enabled = true` | Adopting the default would restrict this vault to private endpoints only. No private endpoint exists in this export for `idn` — flipping this would cut off every current caller. |
| `enabled_for_deployment` / `enabled_for_disk_encryption` / `enabled_for_template_deployment` | all `true` | all `false` | all three set to `true` | Adopting the defaults would block VMs, Azure Disk Encryption, and ARM template deployments from retrieving secrets/certs from this vault, respectively. |
| `network_acls.bypass` | `"AzureServices"` | `"None"` | `key_vault.idn.network_acls.bypass = "AzureServices"` | Same as `fw_tls` above. |
| `network_acls.ip_rules` | `["155.190.0.0/16"]` | `[]` | mirrored explicitly | Informational — this is additive allow-listing, not a hardening gap. Included for completeness of the network ACL object (must be supplied in full, not partially, per the wrapper's nested-object rule). |

## key_vault["idn_devops"] — kvidndevops
Resource ID: `/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0/resourceGroups/rg-siem-identity-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvidndevops`

| Setting | Live (imported) | Wrapper default | tfvars change | Impact |
|---|---|---|---|---|
| `legacy_access_policies_enabled` | `true` (`enableRbacAuthorization: false`) | `false` | set `true`, plus 1 `legacy_access_policies` entry mirrored | Same class of risk as `fw_tls` above — adopting the default revokes the one existing access-policy principal's access at apply time. |
| `sku_name` | `"standard"` (export: `"Standard"`) | `"premium"` | `key_vault.idn_devops.sku_name = "standard"` | Real divergence, not just case. Standard→premium is allowed later if HSM-backed keys are ever needed; premium→standard is not, so getting this right on adoption matters. |
| `enabled_for_template_deployment` | `true` | `false` | set `true` | Adopting the default would block ARM template deployments from retrieving secrets from this vault — this vault's own tags (`Owner: Terraform Intergation`) suggest it backs automation that likely depends on this. |
| `network_acls.bypass` | `"AzureServices"` | `"None"` | set `"AzureServices"` | Same as `fw_tls` above. |

## Zero-diff verification — what is suppressed, and what is not

`verify_zero_diff.sh` runs against the import plan with the flags in
`.github/workflows/import-verify.yml`. The bar for suppressing a diff is that
nothing can remove it — the write never reaches Azure at all, or no tfvars value
and no module version would help. A diff that a tfvars value would fix is left
to fail. A diff that is cosmetic and converges on the first apply is also left
to fail, so the module-side cause stays visible rather than being buried under a
permanent exception.

### Suppressed — no write reaches Azure

| Diff | Flag | Why it is not a change |
|---|---|---|
| `response_export_values`, `retry`, `timeouts`, `ignore_null_property`, `ignore_casing`, `ignore_missing_property`, `schema_validation_enabled`, `read_query_parameters`, `create/update/delete/read_headers` on `azapi_resource` | `--ignore-attr` | Config-only provider knobs. `terraform import` cannot populate them, so they read as null → value on every azapi plan. No module change fixes this — it is how the provider represents its own behaviour. `type` and `body` are deliberately **not** ignored: those are the payload actually sent. |
| `time_sleep`, `random_uuid`, `modtm_telemetry` | `--ignore-type` | No cloud API call exists for these types, so a `create` is not a change to Azure. Counts are still printed, never hidden. |
| `body` on `azapi_resource`, when the planned body is contained in the live one | `--subset-attr body` | Import captures the whole ARM response into `body`; the module's body is a deliberate subset, so plain equality reports a diff on every azapi import no matter how correct the tfvars are. Weaker than equality: a partial PUT can still reset a field the module never mentions. |

### Not suppressed — cosmetic, converges on first apply

One item, failing the gate deliberately: applying it changes nothing in Azure,
and it has a module-side cause worth keeping visible rather than burying under
an exception.

**The four key vault access policies.** `key_vault["fw_tls"]` `ap1`/`ap2`/`ap3`
and `key_vault["idn_devops"]` `ap1` plan an update on
`certificate_permissions`, `key_permissions` and `secret_permissions`. The AVM
module types permissions as `set(string)`, so Terraform sorts them before they
reach the provider's `list(string)` attribute and no ordering written into
`identity.tfvars` can match what Azure returns. Ordering, not membership, is
confirmed twice over by the plan: every `-` entry reappears as a `+` entry, and
`ap2` is both the only policy with an empty `key_permissions` and the only one
that does not diff on that attribute. A module change to `list(string)` would
remove it at source.

The three backup policies are the same class of diff — date prefix only,
verified field by field against `az backup policy show` — but they are currently
waived rather than left to fail; see `The waivers` above for why, and when to
take those three flags back out.

### Real, but the intended result of adoption

Tag-only updates on the three key vaults, the storage account, the three user
assigned identities and the four resource groups. These do write to Azure — see
`Every instance` below — but they are the point of bringing a resource under
Terraform, not drift. Ignored by default; `--strict` turns them back on.

## Every instance

`enable_telemetry` was set to `false` on every module block so the import
plan stays clean (the AVM default of `true` creates one extra
`random_uuid`/`modtm_telemetry` deployment resource per module, which would
otherwise show as a `create` and fail zero-diff verification). It can be set
back to `true` in a later change once adoption is complete — doing so creates
that one small resource per module and changes nothing about the imported
resources themselves.

Every imported resource will show a tag-only diff on first plan: the wrapper
adds `managed-by`/`module` tags, and this deployment's (currently empty)
`common_tags` is merged on top. This is expected and tolerated by
`verify_zero_diff.sh`.

The wrappers' own `checks.tf` files will warn about several of the rows
above (purge protection, legacy access policies, public network access,
`infrastructure_encryption_enabled`, etc.). Those warnings are non-blocking
and are the intended signal — they are not a defect in the generated code,
and silencing them by editing the wrapper would defeat the purpose of this
report.
