# tf-deploy-app-auritas

Terraform that adopts the existing **Auritas** resources into state, following
the same layout as the Fit, PTA and Fabric deploy repos.

| Environment | Subscription | ID |
|---|---|---|
| `nonprod` | Sub-Auritas-NonProd | `1193f1e2-8eb0-42a9-8d99-415231eaebc7` |
| `prod` | Sub-Auritas-Prod | `a91a891c-4a13-426c-972a-0ddea5db8f07` |

Use Terraform `>= 1.9, < 2.0`, one state per environment, and select
`envs/nonprod.tfvars` or `envs/prod.tfvars`. Adopt nonprod first; prod follows
the same runs and stages.

## Status

Both environments are filled from the Azure resource export of 2026-11-03
and are ready for the first import run. The jump VM (nonprod only) and the
VNets are filled in but switched off; they are adopted later, one stage at a
time (see [Staged adoption](#staged-adoption)).

The web app and the function app (Linux containers on the ASE) are not in
this repo yet; see WRAPPER-GAPS. Their App Service plan, ASE, Application
Insights and private endpoints are.

Prod differs from nonprod:

- No jump VM, Bastion, Recovery Services vault or Event Grid system topics.
- `LogAnalyticsDefaultResources` holds the default query pack; the group is
  adopted, the query pack is not.
- The ASE private DNS zone has two VNet links and there is no local
  `privatelink.cnc.backup.windowsazure.com` zone.

## Tiers

| File | Implementation | Nonprod | Prod |
|---|---|---|---|
| `resource_group.tf` | `tf-wrapper-avm-resource-group` 2.0.0 | 5, enabled | 5, enabled |
| `alerts.tf` | `tf-wrapper-avm-ptn-monitoring-amba-alz` 0.3.3 | 1 activity log, enabled | 1 activity log, enabled |
| `app_service_environment.tf` | `tf-wrapper-avm-app-service-environment` 0.1.0 | 1, enabled | 1, enabled |
| `app_service_plan.tf` | `tf-wrapper-avm-app-service-plan` 0.1.0 | 1, enabled | 1, enabled |
| `application_insights.tf` | `tf-wrapper-avm-application-insights` 0.1.0 | 1, enabled | 1, enabled |
| `bastion_host.tf` | `tf-wrapper-avm-bastion-host` 0.0.1 | 1, enabled | - |
| `container_registry.tf` | `tf-wrapper-avm-container-registry` 0.1.0; read-only `azapi_resource` data source | 0 + 1 read-only, enabled | 0 + 1 read-only, enabled |
| `event_grid_system_topic.tf` | `azurerm_eventgrid_system_topic` | 2, enabled | - |
| `windows_virtual_machine.tf` | `tf-wrapper-avm-virtual-machine-windows` 0.1.6 | 1, disabled | - |
| `log_analytics_workspace.tf` | `tf-wrapper-avm-log-analytics-workspace` 0.1.2 | 1, enabled | 1, enabled |
| `nat_gateway.tf` | `tf-wrapper-avm-nat-gateway` 0.1.0 | 1, enabled | 1, enabled |
| `windows_virtual_machine.tf` | NIC inventory and NSG association, owned by the VM wrapper | 1, disabled | - |
| `network_watcher.tf` | `azurerm_network_watcher` | 1, enabled | 1, enabled |
| `private_dns_zone.tf` | `tf-wrapper-avm-private-dns-zone` 1.0.0 | 2 + 2 VNet links, enabled | 1 + 2 VNet links, enabled |
| `private_endpoint.tf` | `tf-wrapper-avm-private-endpoint` 0.1.2 | 7 (2 disconnected, off), enabled | 4, enabled |
| `public_ip_prefix.tf` | `tf-wrapper-avm-public-ip-prefix` 0.1.1 | 1, enabled | 1, enabled |
| `recovery_services_vault.tf` | `tf-wrapper-avm-recovery-services-vault` 0.1.0 | 1, enabled | - |
| `restore_point_collection.tf` | `azurerm_virtual_machine_restore_point_collection` | 1, enabled | - |
| `storage_account.tf` | `azurerm_storage_account`; read-only `azapi_resource` data source | 2, enabled | 2, enabled |
| `virtual_network.tf` | `tf-wrapper-avm-virtual-network` 0.1.0 | 1 + 2 subnets, disabled | 1 + 2 subnets, disabled |
| `role_assignment.tf` | `tf-wrapper-avm-role-assignment` 0.3.6 | all off | all off |
| `compute_disk.tf` | `removed` block only | - | - |

The container registries have public network access enabled, so they are read
with `data.azapi_resource.container_registry_existing`
(`container_registry_existing` in tfvars) instead of being managed:
`Deny_Public_Access_On_PaaS_Services_v0` denies any write to them, adoption
included. Move a registry into `container_registry` once it has a policy
exemption, or once public access is turned off. Both storage accounts in each
environment already have public access disabled and are managed.

Wrapper tags are switched off where the wrapper allows it; the LAW, RSV, App
Service, App Insights, DNS zone and monitoring wrappers still add
`managed-by`/`module` tags, so expect a tag update on those.

What stays unmanaged is in [WRAPPER-GAPS.md](WRAPPER-GAPS.md).

## Things to check before the first import

- **ASE:** `zone_redundancy_enabled` (true in both environments) and the subnet
  force replacement. Both match the export, and every setting is passed
  because the wrapper defaults differ from the deployed ASE.
  `clusterSettings` has `DisableTls1.0 = 1`, so `tls_1_enabled = false`;
  the networking values (FTP off, remote debug on, new private endpoint
  connections allowed) come from `properties.networkingConfiguration`.
- **App Service plan:** Linux `I1v2` with 2 workers; prod is zone redundant,
  nonprod is not. Worker count and zone balancing are set explicitly.
- **App Insights:** the daily cap was not exported; 100 GB is assumed.
- **NAT gateway:** `StandardV2`, zones 1-3, with its public IP prefix. Both
  subnets in each VNet use it; that association is part of the VNet stage.
- **Private endpoints (nonprod):** `pep-appauritasnonprodcac` and the
  `pep-app-auritas-nonprod-canadacentral-001` in the network resource group
  are Disconnected from the web app. They are in tfvars with
  `enabled = false`. Delete them in Azure, or switch them on deliberately.
- **Private DNS zone (nonprod):** a local
  `privatelink.cnc.backup.windowsazure.com` lives in the network resource
  group alongside the hub's zone of the same name. It is adopted as is.
- **Empty resource group (nonprod):** `testrg` holds nothing. It is adopted;
  delete it in Azure and drop it from tfvars if it is not needed.
- **Recovery Services vault** `monitoringSettings` is null on the live
  vault, but the upstream module always writes it. Both alert flags default
  to `false`, and the vault is allowed in `scripts/import_gate.sh` for that
  write.
- `AzureBackupRG_canadacentral_1` is not managed. Azure Backup owns it
  (`managedBy` is `Microsoft.RecoveryServices`), and ARM rejects any PUT that
  drops `managedBy`. The restore-point collection inside it names the group
  directly via `resource_group_name`.

## Adoption

Every resource here already exists in Azure. Each tier has `enable_<type>`
and an import map; imports only run while the tier is enabled, and
validations check every import ID against the key, name, resource group and
`subscription_id`.

Before the first apply:

- Make sure auto-apply is off on the HCP workspace, so every apply is
  confirmed by hand after reading the plan.
- Prod resource groups already carry `CanNotDelete` locks, so an unexpected
  replace fails there instead of destroying the resource. Nonprod has none;
  optionally add one to the app resource groups for the adoption window. Do
  not lock `AzureBackupRG_canadacentral_1`; Azure Backup has to delete old
  restore points there.

  ```bash
  az lock create --name adoption-no-delete --lock-type CanNotDelete --resource-group <rg>
  az lock delete --name adoption-no-delete --resource-group <rg>   # afterwards
  ```

Each run, first or staged:

1. Run `.github/workflows/import-verify.yml` for the environment. It only
   plans, then runs `scripts/import_gate.sh`, which wraps
   `scripts/verify_zero_diff.sh`: it fails on anything other than imports and
   tag updates and reports any replace separately.
2. Fix diffs by correcting tfvars, never by changing Azure. Repeat until the
   gate passes. Never accept a replace or delete with `--allow-resource`.
   Accepted addresses go in `scripts/import_gate.sh`.
3. Run `.github/workflows/import-apply.yml` for the environment, with
   `confirm` set to `apply`. Read the check job's summary (gate output and
   plan: only imports and tag updates), then approve the apply job. It
   re-plans, re-runs the gate and refuses to apply if the change set moved
   since the check. Do not use `landing-zone-multi-env.yml` while imports
   are pending; it applies with `-auto-approve` and no gate.
4. Empty the import maps of the tiers that applied.


## Staged adoption

These tiers are complete in tfvars but switched off, because adopting them
can change or destroy something that is hard to get back. Each gets its own
import-verify and apply, after the first run has applied.

| Stage | Flags | Why it is held back |
|---|---|---|
| 1. Jump VM (nonprod) | `enable_windows_virtual_machine`, `enable_network_interface` | Blocked by the wrapper's image list (below); a wrong plan would rebuild the VM |
| 2. Virtual network | `enable_virtual_network` | The vWAN hub connection is owned by the connectivity repo |

### Stage 1: Jump VM (nonprod)

`auritascacjumpp1` runs `MicrosoftWindowsServer/WindowsServer/2025-datacenter-azure-edition`.
`tf-wrapper-avm-virtual-machine-windows` 0.1.6 only accepts the CIS images
and the grandfathered `2022-datacenter-g2` and `2025-datacenter-g2`, so the
plan fails validation until that sku is added to the wrapper's grandfathered
list. The image is ForceNew; do not change it in tfvars.

1. Add `microsoftwindowsserver/windowsserver/2025-datacenter-azure-edition`
   to both image checks in the wrapper's grandfathered list, publish it, and bump the version in
   `windows_virtual_machine.tf`.
2. Set the real admin password as the sensitive HCP variable
   `windows_virtual_machine_admin_passwords` (`{ jump = "..." }`). Validation
   blocks the plan until it is set.
3. Set `enable_windows_virtual_machine = true` and
   `enable_network_interface = true`, then run import-verify. Expected: one
   VM import and one NIC import. The five extensions stay unmanaged.
4. Any replace on the VM means a ForceNew value (image, size, zone, OS disk)
   disagrees with Azure. Stop, correct tfvars and plan again.
5. Apply and empty `windows_virtual_machine_imports`.

### Stage: Virtual network

The VNet module sends a body without subnets or peerings, so the import plan
shows both being removed. Each VNet's only peering is its vWAN hub connection,
declared in `tf-deploy-platform-connectivity`. Upstream tests confirm that
subnets and peerings created outside the module survive the update, but not
vWAN hub connections. This stage is the same as Fit's, Fabric's and PTA's.

1. Agree a window with the connectivity team, so they can restore the hub
   connection from their repo if it drops.
2. Set `enable_virtual_network = true` and run import-verify. Expected: one
   import per VNet and per subnet.
3. `defaultOutboundAccess` is taken from the export where Azure reports it,
   otherwise Azure's default (`true`). It is create-time only: a subnet
   replace in the plan means that value is wrong, so stop and correct it.
4. Apply, check the hub connection, the ASE and the NAT gateway association, then empty the VNet and
   subnet import maps.

## Role assignments

`role_assignment.tf` uses one typed map: resource type, parent key, then
assignment key. Every `enable_<type>_role_assignment` is false and
`role_assignments = {}` in both environments. Nothing is inferred from the
export, and existing assignments need their own imports.

## Pipeline

| Workflow | Purpose |
|---|---|
| `import-verify.yml` | Plan and gate. Never applies. Run this first |
| `import-apply.yml` | Gate, approval on the `<env>` environment, re-gate, apply |
| `landing-zone-multi-env.yml` | Deploy pipeline, `workflow_dispatch` only |
| `state-rm.yml` | Remove one address from state without touching Azure |
| `tflint.yml` | HCL lint on push and PR |
| `trivy.yml` | IaC scan on PR and weekly |

`import-apply.yml` needs required reviewers on the `nonprod` and `prod`
GitHub Environments, or the apply job runs without stopping. Its check job
runs outside any environment, so `TF_API_TOKEN`, `TF_CLOUD_ORGANIZATION`
and `TFC_WORKSPACE_PREFIX` must be set at repo or org level.

`TFC_WORKSPACE_PREFIX` must be set before the first run (`az-auritas`, matching Fit's `az-fit`).
