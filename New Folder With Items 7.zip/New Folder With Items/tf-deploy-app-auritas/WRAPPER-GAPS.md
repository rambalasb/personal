# Wrapper gaps: `tf-deploy-app-auritas`

Resources in the Auritas subscriptions that this repo does not manage. Counts
are from the Azure resource export of 2026-11-03.

## Staged

Code and tfvars are complete; each is switched off and adopted in its own
run. See "Staged adoption" in the README.

| Resource | Environment | Reason |
|---|---|---|
| `auritascacjumpp1` (+ NIC) | nonprod | Image `2025-datacenter-azure-edition` is not on the Windows wrapper's grandfathered list |
| `vnet-auritas-<env>-canadacentral-001` (+ 2 subnets) | both | vWAN hub connection owned by the connectivity repo |

## Blocked by policy

Public network access is enabled, so `Deny_Public_Access_On_PaaS_Services_v0`
denies any write, adoption included. Read with
`data.azapi_resource.container_registry_existing` until exempted.

| Resource | Environment | Reason |
|---|---|---|
| `acrauritasnonprod` | nonprod | Premium, zone redundant, public access enabled with default action Allow |
| `acrauritasprod` | prod | Premium, public access enabled with default action Allow |

## Needs a tier

| Resource | Environment | Reason |
|---|---|---|
| `app-auritas-nonprod-canadacentral-001`, `funcauritasnonprodcac` | nonprod | Linux container sites on the ASE. Fit's web-app tier models a Windows `site_config` only; these need a Linux container `site_config` and a function-app tier (`tf-wrapper-avm-function-app` 0.1.2). Every apply rewrites the full app settings, so they are staged like Fit's web app |
| `appauritasprodcac`, `funcauritasprodcac` | prod | Same; `appauritasprodcac` uses sidecar containers (`linuxFxVersion = sitecontainers`) |

## Not managed

| Type | Nonprod | Prod | Reason |
|---|---:|---:|---|
| `microsoft.web/certificates` | 2 | 2 | No wrapper published |
| `microsoft.network/networkinterfaces` | 8 | 4 | PE NICs belong to their endpoint; the jump VM NIC goes with the VM (staged) |
| `microsoft.compute/virtualmachines/extensions` | 5 | 0 | VM wrapper is called with `extensions = {}` |
| `microsoft.compute/disks` | 1 | 0 | OS disk is owned inline by its VM |
| `microsoft.network/networkwatchers/flowlogs` | 1 | 1 | No wrapper |
| `microsoft.insights/actiongroups` | 1 | 1 | App Insights smart detection group; created by Azure |
| `microsoft.operationalinsights/querypacks` | 0 | 1 | `DefaultQueryPack`, created by the portal |
| `microsoft.network/privatednszones` record sets | ? | ? | Created by the ASE |
| `microsoft.network/virtualnetworks` peerings | 1 | 1 | Hub peering is owned by the connectivity repo |
| `AzureBackupRG_canadacentral_1` | 1 | 0 | `managedBy` Azure Backup; ARM rejects a PUT that drops it |
