module "nat_gateway" {
  for_each = var.enable_nat_gateway ? var.nat_gateway : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-nat-gateway/azurerm"
  version = "0.1.0"

  name                          = each.value.name
  parent_id                     = module.resource_group[each.value.resource_group_key].resource_id
  location                      = coalesce(each.value.location, module.resource_group[each.value.resource_group_key].location)
  sku_name                      = each.value.sku_name
  idle_timeout_in_minutes       = each.value.idle_timeout_in_minutes
  public_ip_prefix_resource_ids = each.value.public_ip_prefix_resource_ids
  zones                         = each.value.zones
  tags                          = each.value.tags

  enable_telemetry = false
}

import {
  for_each = var.enable_nat_gateway ? var.nat_gateway_imports : {}

  to = module.nat_gateway[each.key].module.nat_gateway.azapi_resource.this
  id = "${each.value}?api-version=2025-03-01"
}