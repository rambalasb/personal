module "public_ip_prefix" {
  for_each = var.enable_public_ip_prefix ? var.public_ip_prefix : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-public-ip-prefix/azurerm"
  version = "0.1.1"

  name                = each.value.name
  resource_group_name = module.resource_group[each.value.resource_group_key].name
  location            = coalesce(each.value.location, module.resource_group[each.value.resource_group_key].location)
  prefix_length       = each.value.prefix_length
  ip_version          = each.value.ip_version
  sku_name            = each.value.sku_name
  sku_tier            = each.value.sku_tier
  zones               = each.value.zones == null ? toset([]) : each.value.zones
  tags                = each.value.tags

  enable_telemetry = false
}

import {
  for_each = var.enable_public_ip_prefix ? var.public_ip_prefix_imports : {}

  to = module.public_ip_prefix[each.key].module.public_ip_prefix.azurerm_public_ip_prefix.this
  id = each.value
}