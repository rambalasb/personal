#!/usr/bin/env bash
# The import zero-diff gate, shared by import-verify.yml and import-apply.yml so
# the plan that gets applied passes exactly the check that was reviewed.
#
# Usage: import_gate.sh <env> <plan.json>
set -eo pipefail
ENV_NAME="${1:?usage: import_gate.sh <env> <plan.json>}"
PLAN="${2:?usage: import_gate.sh <env> <plan.json>}"
HERE="$(cd "$(dirname "$0")" && pwd)"

# Known module-side writes, carried over from tf-deploy-app-fit. Add an address
# here only after reading its diff in the import-verify summary.
allow=()
if [ "$ENV_NAME" = "nonprod" ]; then
  # AVM always writes monitoringSettings (null live) and drops fields the
  # vault already holds at their defaults; tfvars keeps alerting off.
  allow+=(--allow-resource "module.recovery_services_vault[\"app\"].module.recovery_services_vault.azapi_resource.this")
  # Import reads unset samplingPercentage as 0; unset means 100% (no sampling).
  allow+=(--allow-resource "module.application_insights[\"app\"].module.application_insights.azurerm_application_insights.this")
  # The upstream module sends no body; a private DNS zone has no settable
  # properties, so only the imported etag drops out.
  allow+=(--allow-resource "module.private_dns_zone[\"ase\"].module.private_dns_zone.azapi_resource.private_dns_zone")
  # The upstream module sends no body; a private DNS zone has no settable
  # properties, so only the imported etag drops out.
  allow+=(--allow-resource "module.private_dns_zone[\"backup\"].module.private_dns_zone.azapi_resource.private_dns_zone")
  # AVM always patches the ASE networking configuration; the values match
  # the export (PE connections on, FTP off, remote debug on).
  allow+=(--allow-resource "module.app_service_environment[\"app\"].module.app_service_environment.module.networking_configuration.azapi_update_resource.networking")
elif [ "$ENV_NAME" = "prod" ]; then
  # Import reads unset samplingPercentage as 0; unset means 100% (no sampling).
  allow+=(--allow-resource "module.application_insights[\"app\"].module.application_insights.azurerm_application_insights.this")
  # The upstream module sends no body; a private DNS zone has no settable
  # properties, so only the imported etag drops out.
  allow+=(--allow-resource "module.private_dns_zone[\"ase\"].module.private_dns_zone.azapi_resource.private_dns_zone")
  # AVM always patches the ASE networking configuration; the values match
  # the export (PE connections on, FTP off, remote debug on).
  allow+=(--allow-resource "module.app_service_environment[\"app\"].module.app_service_environment.module.networking_configuration.azapi_update_resource.networking")
fi
bash "$HERE/verify_zero_diff.sh" "$PLAN" "${allow[@]}" \
  --ignore-attr response_export_values \
  --ignore-attr retry \
  --ignore-attr timeouts \
  --ignore-attr ignore_null_property \
  --ignore-attr ignore_casing \
  --ignore-attr ignore_missing_property \
  --ignore-attr schema_validation_enabled \
  --subset-attr body \
  --ignore-type time_sleep \
  --ignore-type random_uuid \
  --ignore-type modtm_telemetry \
  --ignore-type terraform_data
