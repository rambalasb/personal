module "app_service_environment" {
  for_each = var.enable_app_service_environment ? var.app_service_environment : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-app-service-environment/azurerm"
  version = "0.1.0"

  name                                   = each.value.name
  subscription_id                        = var.subscription_id
  resource_group_name                    = module.resource_group[each.value.resource_group_key].name
  location                               = coalesce(each.value.location, module.resource_group[each.value.resource_group_key].location)
  subnet_id                              = each.value.subnet_id
  internal_load_balancing_mode           = each.value.internal_load_balancing_mode
  zone_redundancy_enabled                = each.value.zone_redundancy_enabled
  internal_encryption_enabled            = each.value.internal_encryption_enabled
  ftp_enabled                            = each.value.ftp_enabled
  remote_debug_enabled                   = each.value.remote_debug_enabled
  allow_new_private_endpoint_connections = each.value.allow_new_private_endpoint_connections
  # false adds the DisableTls1.0 cluster setting; true leaves clusterSettings
  # untouched, so it must match the live ASE.
  tls_1_enabled               = each.value.tls_1_enabled
  inbound_ip_address_override = each.value.inbound_ip_address_override
  upgrade_preference          = each.value.upgrade_preference
  dedicated_host_count        = each.value.dedicated_host_count
  tags                        = each.value.tags

  managed_identities = {
    system_assigned            = each.value.system_assigned_identity
    user_assigned_resource_ids = []
  }

  role_assignments    = {}
  diagnostic_settings = {}
  lock                = null
  enable_telemetry    = false
}

import {
  for_each = var.enable_app_service_environment ? var.app_service_environment_imports : {}

  to = module.app_service_environment[each.key].module.app_service_environment.azapi_resource.this
  id = each.value
}
