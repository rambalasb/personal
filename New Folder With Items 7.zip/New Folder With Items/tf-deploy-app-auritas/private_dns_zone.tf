module "private_dns_zone" {
  for_each = var.enable_private_dns_zone ? var.private_dns_zone : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-private-dns-zone/azurerm"
  version = "1.0.0"

  domain_name           = each.value.name
  subscription_id       = var.subscription_id
  resource_group_name   = module.resource_group[each.value.resource_group_key].name
  virtual_network_links = each.value.virtual_network_links
  tags                  = each.value.tags

  # Record sets the ASE created stay unmanaged.
  role_assignments = {}
  lock             = null
  enable_telemetry = false
}

import {
  for_each = var.enable_private_dns_zone ? var.private_dns_zone_imports : {}

  to = module.private_dns_zone[each.key].module.private_dns_zone.azapi_resource.private_dns_zone
  id = each.value
}

import {
  for_each = var.enable_private_dns_zone ? var.private_dns_zone_link_imports : {}

  to = module.private_dns_zone[each.value.zone_key].module.private_dns_zone.module.virtual_network_links[each.value.link_key].azapi_resource.private_dns_zone_network_link
  id = each.value.id
}
