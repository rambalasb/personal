# tf-deploy-app-openai

Terraform that adopts the existing **OpenAI** (Reg AI) resources into state,
following the same layout as the Fit, PTA and Fabric deploy repos. The repo is
named after the subscriptions.

| Environment | Subscription | ID |
|---|---|---|
| `nonprod` | Sub-OpenAI-NonProd | `79fa77c1-d916-47f8-b388-33c03f29c5ea` |
| `prod` | Sub-OpenAI-Prod | `ab6893cb-e4ea-447e-a514-0ae1b4929416` |

Use Terraform `>= 1.9, < 2.0`, one state per environment, and select
`envs/nonprod.tfvars` or `envs/prod.tfvars`. Adopt nonprod first; prod follows
the same runs and stages.

## Status

Both environments are filled from the Azure resource export of 2026-11-03
and are ready for the first import run. The VM and its NIC, and the VNet, are
filled in but switched off; they are adopted later, one stage at a time (see
[Staged adoption](#staged-adoption)).

The application tier is mostly outside this repo for now: the Azure OpenAI
and Document Intelligence accounts, the PostgreSQL flexible server, the
Cosmos DB account, and the web and function apps (Linux containers). Their
private endpoints, alerts, plan, registry, Key Vault and storage are here.
WRAPPER-GAPS says what each one needs.

Prod differs from nonprod:

- A default Log Analytics workspace, Azure Monitor workspace, data
  collection endpoint and three data collection rules (VM insights); only the
  workspace is adopted.
- Three alert processing rules, all with spaces in their names; not managed.
- `app-delete` and `app-stop` alerts match a single `Started` status and are
  managed; in nonprod they use `containsAny` and are not.
- Only one Network Watcher (nonprod has one in Canada East too).

## Tiers

| File | Implementation | Nonprod | Prod |
|---|---|---|---|
| `resource_group.tf` | `tf-wrapper-avm-resource-group` 2.0.0 | 7, enabled | 8, enabled |
| `alerts.tf` | `tf-wrapper-avm-ptn-monitoring-amba-alz` 0.3.3 | 5 activity log, 20 metric, 4 log search, enabled | 7 activity log, 20 metric, 4 log search, enabled |
| `app_service_plan.tf` | `tf-wrapper-avm-app-service-plan` 0.1.0 | 1, enabled | 1, enabled |
| `application_insights.tf` | `tf-wrapper-avm-application-insights` 0.1.0 | 1, enabled | 1, enabled |
| `bastion_host.tf` | `tf-wrapper-avm-bastion-host` 0.0.1 | 1, enabled | 1, enabled |
| `container_registry.tf` | `tf-wrapper-avm-container-registry` 0.1.0; read-only `azapi_resource` data source | 1, enabled | 1, enabled |
| `event_grid_system_topic.tf` | `azurerm_eventgrid_system_topic` | 1, enabled | 1, enabled |
| `key_vault.tf` | `tf-wrapper-avm-key-vault` 0.4.0 | 1, enabled | 1, enabled |
| `linux_virtual_machine.tf` | `tf-wrapper-avm-virtual-machine-linux` 0.0.7 | 1, disabled | 1, disabled |
| `log_analytics_workspace.tf` | `tf-wrapper-avm-log-analytics-workspace` 0.1.2 | - | 1, enabled |
| `network_interface.tf` | NIC inventory for the VM | 1, disabled | 1, disabled |
| `network_watcher.tf` | `azurerm_network_watcher` | 2, enabled | 1, enabled |
| `private_endpoint.tf` | `tf-wrapper-avm-private-endpoint` 0.1.2 | 11, enabled | 11, enabled |
| `public_ssh_key.tf` | `azurerm_ssh_public_key` | 2, enabled | 2, enabled |
| `recovery_services_vault.tf` | `tf-wrapper-avm-recovery-services-vault` 0.1.0 | 1, enabled | 1, enabled |
| `restore_point_collection.tf` | `azurerm_virtual_machine_restore_point_collection` | 1, enabled | 1, enabled |
| `storage_account.tf` | `azurerm_storage_account`; read-only `azapi_resource` data source | 1, enabled | 1, enabled |
| `virtual_network.tf` | `tf-wrapper-avm-virtual-network` 0.1.0 | 1 + 3 subnets, disabled | 1 + 3 subnets, disabled |
| `role_assignment.tf` | `tf-wrapper-avm-role-assignment` 0.3.6 | all off | all off |
| `compute_disk.tf` | `removed` block only | - | - |

Storage, Key Vault and the container registries already have public access
disabled, so nothing is read-only.

Wrapper tags are switched off where the wrapper allows it; the LAW, RSV, App
Service, App Insights, container registry and monitoring wrappers still add
`managed-by`/`module` tags, so expect a tag update on those.

What stays unmanaged is in [WRAPPER-GAPS.md](WRAPPER-GAPS.md).

## Things to check before the first import

- **App Service plan:** Linux `P1v3`, 1 worker, not on an ASE. Worker count
  and zone balancing are set explicitly.
- **App Insights:** the daily cap was not exported; 100 GB is assumed.
- **Container registry:** Premium, admin user enabled, public access off,
  retention policy disabled. `retention_policy_in_days = null` keeps the
  policy off; the wrapper default (7) would switch it on.
- **Storage:** `allowBlobPublicAccess` is true on the live account, which
  is kept as is. Public network access is disabled, so the policy does not
  block it. `private_link_access` holds the Defender data scanner.
- **Key Vault:** lives in the SIEM resource group. `softDeleteRetentionInDays`
  is not reported, so 90 (the Azure default) is set.
- **Alerts:** the action group IDs pointing at ServiceNow contain a leading
  space (`actionGroups/ ag-...`). Kept as exported. Several metric alerts
  scope resources this repo does not manage (OpenAI, Cosmos DB, PostgreSQL,
  web apps); the alerts themselves are adopted.
- **Recovery Services vault** `monitoringSettings` is null on the live
  vault, but the upstream module always writes it. Both alert flags default
  to `false`, and the vault is allowed in `scripts/import_gate.sh` for that
  write.
- **Prod resource groups** already carry `CanNotDelete` locks, including
  `MA_defaultazuremonitorworkspace-cca_canadacentral_managed`, which is not
  adopted (`managedBy` the Azure Monitor workspace).
- `AzureBackupRG_canadacentral_1` is not managed. Azure Backup owns it
  (`managedBy` is `Microsoft.RecoveryServices`), and ARM rejects any PUT that
  drops `managedBy`. The restore-point collection inside it names the group
  directly via `resource_group_name`.

## Adoption

Every resource here already exists in Azure. Each tier has `enable_<type>`
and an import map; imports only run while the tier is enabled, and
validations check every import ID against the key, name, resource group and
`subscription_id`.

Before the first apply:

- Make sure auto-apply is off on the HCP workspace, so every apply is
  confirmed by hand after reading the plan.
- Prod resource groups already carry `CanNotDelete` locks, so an unexpected
  replace fails there instead of destroying the resource. Nonprod has none;
  optionally add one to the app resource groups for the adoption window. Do
  not lock `AzureBackupRG_canadacentral_1`; Azure Backup has to delete old
  restore points there.

  ```bash
  az lock create --name adoption-no-delete --lock-type CanNotDelete --resource-group <rg>
  az lock delete --name adoption-no-delete --resource-group <rg>   # afterwards
  ```

Each run, first or staged:

1. Run `.github/workflows/import-verify.yml` for the environment. It only
   plans, then runs `scripts/import_gate.sh`, which wraps
   `scripts/verify_zero_diff.sh`: it fails on anything other than imports and
   tag updates and reports any replace separately.
2. Fix diffs by correcting tfvars, never by changing Azure. Repeat until the
   gate passes. Never accept a replace or delete with `--allow-resource`.
   Accepted addresses go in `scripts/import_gate.sh`.
3. Run `.github/workflows/import-apply.yml` for the environment, with
   `confirm` set to `apply`. Read the check job's summary (gate output and
   plan: only imports and tag updates), then approve the apply job. It
   re-plans, re-runs the gate and refuses to apply if the change set moved
   since the check. Do not use `landing-zone-multi-env.yml` while imports
   are pending; it applies with `-auto-approve` and no gate.
4. Empty the import maps of the tiers that applied.


## Staged adoption

These tiers are complete in tfvars but switched off, because adopting them
can change or destroy something that is hard to get back. Each gets its own
import-verify and apply, after the first run has applied.

| Stage | Flags | Why it is held back |
|---|---|---|
| 1. VM | `enable_linux_virtual_machine`, `enable_network_interface` | Blocked by the wrapper's image list (below); a wrong plan would rebuild the VM |
| 2. Virtual network | `enable_virtual_network` | The vWAN hub connection is owned by the connectivity repo |

### Stage 1: VM

`vm-openai-<env>-canadacentral-001` runs `RedHat/RHEL/9_6`.
`tf-wrapper-avm-virtual-machine-linux` 0.0.7 only accepts `rhel-byos`
images and the grandfathered `RedHat/RHEL/8_10` and `810-gen2`, so the plan
fails validation until that sku is added. The image is ForceNew; do not
change it in tfvars. The exported version `Latest` passes (the check is
case-insensitive) and is kept as exported.

1. Add `redhat/rhel/9_6` to both image checks in the wrapper's grandfathered
   list, publish it, and bump the version in `linux_virtual_machine.tf`.
2. The VMs use SSH keys only; the exported public keys are in tfvars.
3. Set `enable_linux_virtual_machine = true` and
   `enable_network_interface = true`, then run import-verify. Expected: one
   VM import and one NIC import. Extensions and (prod) run commands stay
   unmanaged.
4. Any replace on the VM means a ForceNew value (image, size, zone, OS disk)
   disagrees with Azure. Stop, correct tfvars and plan again.
5. Apply and empty `linux_virtual_machine_imports`.

Trusted Launch is off on these VMs (secure boot and vTPM false); the wrapper
reports that as a warning, not an error.

### Stage: Virtual network

The VNet module sends a body without subnets or peerings, so the import plan
shows both being removed. Each VNet's only peering is its vWAN hub connection,
declared in `tf-deploy-platform-connectivity`. Upstream tests confirm that
subnets and peerings created outside the module survive the update, but not
vWAN hub connections. This stage is the same as Fit's, Fabric's and PTA's.

1. Agree a window with the connectivity team, so they can restore the hub
   connection from their repo if it drops.
2. Set `enable_virtual_network = true` and run import-verify. Expected: one
   import per VNet and per subnet.
3. `defaultOutboundAccess` is taken from the export where Azure reports it,
   otherwise Azure's default (`true`). It is create-time only: a subnet
   replace in the plan means that value is wrong, so stop and correct it.
4. Apply, check the hub connection, the web app VNet integration and the VM, then empty the VNet and
   subnet import maps.

## Role assignments

`role_assignment.tf` uses one typed map: resource type, parent key, then
assignment key. Every `enable_<type>_role_assignment` is false and
`role_assignments = {}` in both environments. Nothing is inferred from the
export, and existing assignments need their own imports.

## Pipeline

| Workflow | Purpose |
|---|---|
| `import-verify.yml` | Plan and gate. Never applies. Run this first |
| `import-apply.yml` | Gate, approval on the `<env>` environment, re-gate, apply |
| `landing-zone-multi-env.yml` | Deploy pipeline, `workflow_dispatch` only |
| `state-rm.yml` | Remove one address from state without touching Azure |
| `tflint.yml` | HCL lint on push and PR |
| `trivy.yml` | IaC scan on PR and weekly |

`import-apply.yml` needs required reviewers on the `nonprod` and `prod`
GitHub Environments, or the apply job runs without stopping. Its check job
runs outside any environment, so `TF_API_TOKEN`, `TF_CLOUD_ORGANIZATION`
and `TFC_WORKSPACE_PREFIX` must be set at repo or org level.

`TFC_WORKSPACE_PREFIX` must be set before the first run (`az-openai`, matching Fit's `az-fit`).
