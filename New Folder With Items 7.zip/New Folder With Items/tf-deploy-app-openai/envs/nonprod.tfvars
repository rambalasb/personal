# Sub-OpenAI-NonProd (79fa77c1-d916-47f8-b388-33c03f29c5ea)
# Values come from the Azure resource export of 2026-11-03.
# The VM (and its NIC) and the VNet are off for the first apply;
# adopt them in separate runs.

subscription_id = "79fa77c1-d916-47f8-b388-33c03f29c5ea"

enable_resource_group           = true
enable_monitoring               = true
enable_app_service_plan         = true
enable_application_insights     = true
enable_bastion_host             = true
enable_container_registry       = true
enable_event_grid_system_topic  = true
enable_key_vault                = true
enable_linux_virtual_machine    = false
enable_log_analytics_workspace  = false
enable_network_interface        = false
enable_network_watcher          = true
enable_private_endpoint         = true
enable_public_ssh_key           = true
enable_recovery_services_vault  = true
enable_restore_point_collection = true
enable_storage_account          = true
enable_virtual_network          = false

enable_resource_group_role_assignment           = false
enable_monitoring_role_assignment               = false
enable_app_service_plan_role_assignment         = false
enable_application_insights_role_assignment     = false
enable_bastion_host_role_assignment             = false
enable_container_registry_role_assignment       = false
enable_event_grid_system_topic_role_assignment  = false
enable_key_vault_role_assignment                = false
enable_linux_virtual_machine_role_assignment    = false
enable_log_analytics_workspace_role_assignment  = false
enable_network_interface_role_assignment        = false
enable_network_watcher_role_assignment          = false
enable_private_endpoint_role_assignment         = false
enable_public_ssh_key_role_assignment           = false
enable_recovery_services_vault_role_assignment  = false
enable_restore_point_collection_role_assignment = false
enable_storage_account_role_assignment          = false
enable_virtual_network_role_assignment          = false

role_assignments = {}

# AzureBackupRG_canadacentral_1 is left out: managedBy Microsoft.RecoveryServices; ARM rejects a PUT that drops it.
resource_group = {
  app_canadaeast = {
    name     = "rg-openai-nonprod-app-canadaeast-001"
    location = "canadaeast"
    tags = {
      CostCenterId = "80045905"
      Environment  = "NonProd"
    }
  }
  alerts_canadaeast = {
    name     = "rg-openai-nonprod-alerts-canadaeast-001"
    location = "canadaeast"
    tags = {
      CostCenterId = "80045905"
      Environment  = "NonProd"
    }
  }
  siem = {
    name     = "rg-openai-nonprod-siem-canadacentral-001"
    location = "canadacentral"
    tags = {
      CostCenterId = "80045905"
      Environment  = "NonProd"
    }
  }
  network = {
    name     = "rg-openai-nonprod-network-canadacentral-001"
    location = "canadacentral"
    tags = {
      CostCenterId = "80045905"
      Environment  = "NonProd"
    }
  }
  app = {
    name     = "rg-openai-nonprod-app-canadacentral-001"
    location = "canadacentral"
    tags = {
      CostCenterId = "80045905"
      Environment  = "NonProd"
    }
  }
  networkwatcherrg = {
    name     = "NetworkWatcherRG"
    location = "canadacentral"
    tags = {
      CostCenterId = "80045905"
      Environment  = "NonProd"
    }
  }
  alerts = {
    name     = "rg-openai-nonprod-alerts-canadacentral-001"
    location = "canadacentral"
    tags = {
      CostCenterId = "80045905"
      Environment  = "NonProd"
    }
  }
}

import_resource_group = {
  app_canadaeast    = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadaeast-001"
  alerts_canadaeast = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-alerts-canadaeast-001"
  siem              = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-siem-canadacentral-001"
  network           = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-network-canadacentral-001"
  app               = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadacentral-001"
  networkwatcherrg  = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/NetworkWatcherRG"
  alerts            = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-alerts-canadacentral-001"
}

alert = {
  resource_group_key         = "alerts"
  root_management_group_name = null
  tags                       = {}
  activity_log_alerts = {
    openai_delete_ce = {
      name                = "openai-delete-alert-openai-nonprod-ce"
      resource_group_name = "rg-openai-nonprod-alerts-canadaeast-001"
      scopes              = ["/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea"]
      location            = "global"
      description         = "Fires when an OpenAI account deletion is attempted"
      enabled             = true
      criteria = {
        category       = "Administrative"
        operation_name = "Microsoft.CognitiveServices/accounts/delete"
        status         = "Started"
      }
      action_group_keys = []
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/lga-servicenow-integration_group/providers/Microsoft.Insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      webhook_properties = {}
      tags = {
        CostCenterId = "80045905"
        Environment  = "NonProd"
      }
    }
    kv_delete = {
      name                = "kv-delete-alert-openai-nonprod-cc"
      resource_group_name = "rg-openai-nonprod-siem-canadacentral-001"
      scopes              = ["/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea"]
      location            = "global"
      description         = "Fires when a Key Vault deletion is attempted"
      enabled             = true
      criteria = {
        category       = "Administrative"
        operation_name = "Microsoft.KeyVault/vaults/delete"
        status         = "Started"
      }
      action_group_keys = []
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/lga-servicenow-integration_group/providers/Microsoft.Insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      webhook_properties = {}
      tags = {
        CostCenterId = "80045905"
        Environment  = "NonProd"
      }
    }
    cosmosdb_delete = {
      name                = "cosmosdb-delete-alert-openai-nonprod-cc"
      resource_group_name = "rg-openai-nonprod-alerts-canadacentral-001"
      scopes              = ["/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea"]
      location            = "global"
      description         = "Fires when a CosmosDB account deletion is attempted"
      enabled             = true
      criteria = {
        category       = "Administrative"
        operation_name = "Microsoft.DocumentDB/databaseAccounts/delete"
        status         = "Started"
      }
      action_group_keys = []
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/lga-servicenow-integration_group/providers/Microsoft.Insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      webhook_properties = {}
      tags = {
        CostCenterId = "80045905"
        Environment  = "NonProd"
      }
    }
    psql_delete = {
      name                = "psql-delete-alert-openai-nonprod-cc"
      resource_group_name = "rg-openai-nonprod-alerts-canadacentral-001"
      scopes              = ["/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea"]
      location            = "global"
      description         = "Fires when a PostgreSQL Flexible Server deletion is attempted"
      enabled             = true
      criteria = {
        category       = "Administrative"
        operation_name = "Microsoft.DBforPostgreSQL/flexibleServers/delete"
        status         = "Started"
      }
      action_group_keys = []
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/lga-servicenow-integration_group/providers/Microsoft.Insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      webhook_properties = {}
      tags = {
        CostCenterId = "80045905"
        Environment  = "NonProd"
      }
    }
    docintel_delete = {
      name                = "docintel-delete-alert-openai-nonprod-cc"
      resource_group_name = "rg-openai-nonprod-alerts-canadacentral-001"
      scopes              = ["/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea"]
      location            = "global"
      description         = "Fires when a Document Intelligence account deletion is attempted"
      enabled             = true
      criteria = {
        category       = "Administrative"
        operation_name = "Microsoft.CognitiveServices/accounts/delete"
        status         = "Started"
      }
      action_group_keys = []
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/lga-servicenow-integration_group/providers/Microsoft.Insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      webhook_properties = {}
      tags = {
        CostCenterId = "80045905"
        Environment  = "NonProd"
      }
    }
  }
  metric_alerts = {
    openai_servererror_ce = {
      name                = "openai-servererror-alert-openai-nonprod-ce"
      resource_group_name = "rg-openai-nonprod-alerts-canadaeast-001"
      scopes = [
        "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadaeast-001/providers/Microsoft.CognitiveServices/accounts/oai-openai-nonprod-ce-001"
      ]
      description              = "Fires when OpenAI returns server-side errors (5xx)"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT15M"
      severity                 = 1
      target_resource_type     = "Microsoft.CognitiveServices/accounts"
      target_resource_location = "canadaeast"
      criteria = [
        {
          metric_namespace       = "Microsoft.CognitiveServices/accounts"
          metric_name            = "ServerErrors"
          aggregation            = "Total"
          operator               = "GreaterThan"
          threshold              = 0
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/lga-servicenow-integration_group/providers/Microsoft.Insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        CostCenterId = "80045905"
        Environment  = "NonProd"
      }
    }
    openai_blockedcalls_ce = {
      name                = "openai-blockedcalls-alert-openai-nonprod-ce"
      resource_group_name = "rg-openai-nonprod-alerts-canadaeast-001"
      scopes = [
        "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadaeast-001/providers/Microsoft.CognitiveServices/accounts/oai-openai-nonprod-ce-001"
      ]
      description              = "Fires when OpenAI calls are blocked due to rate or quota limits"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT15M"
      severity                 = 1
      target_resource_type     = "Microsoft.CognitiveServices/accounts"
      target_resource_location = "canadaeast"
      criteria = [
        {
          metric_namespace       = "Microsoft.CognitiveServices/accounts"
          metric_name            = "BlockedCalls"
          aggregation            = "Total"
          operator               = "GreaterThan"
          threshold              = 0
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/lga-servicenow-integration_group/providers/Microsoft.Insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        CostCenterId = "80045905"
        Environment  = "NonProd"
      }
    }
    openai_availability_ce = {
      name                = "openai-availability-alert-openai-nonprod-ce"
      resource_group_name = "rg-openai-nonprod-alerts-canadaeast-001"
      scopes = [
        "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadaeast-001/providers/Microsoft.CognitiveServices/accounts/oai-openai-nonprod-ce-001"
      ]
      description              = "Fires when OpenAI availability drops below 99%"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT15M"
      severity                 = 0
      target_resource_type     = "Microsoft.CognitiveServices/accounts"
      target_resource_location = "canadaeast"
      criteria = [
        {
          metric_namespace       = "Microsoft.CognitiveServices/accounts"
          metric_name            = "AzureOpenAIAvailabilityRate"
          aggregation            = "Average"
          operator               = "LessThan"
          threshold              = 99
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/lga-servicenow-integration_group/providers/Microsoft.Insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        CostCenterId = "80045905"
        Environment  = "NonProd"
      }
    }
    openai_responsetime_ce = {
      name                = "openai-responsetime-alert-openai-nonprod-ce"
      resource_group_name = "rg-openai-nonprod-alerts-canadaeast-001"
      scopes = [
        "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadaeast-001/providers/Microsoft.CognitiveServices/accounts/oai-openai-nonprod-ce-001"
      ]
      description              = "Fires when OpenAI response latency deviates from dynamic baseline"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT1H"
      severity                 = 2
      target_resource_type     = "Microsoft.CognitiveServices/accounts"
      target_resource_location = "canadaeast"
      dynamic_criteria = {
        metric_namespace         = "Microsoft.CognitiveServices/accounts"
        metric_name              = "AzureOpenAITimeToResponse"
        aggregation              = "Average"
        operator                 = "GreaterOrLessThan"
        alert_sensitivity        = "Medium"
        evaluation_total_count   = 4
        evaluation_failure_count = 4
        ignore_data_before       = null
        skip_metric_validation   = false
        dimensions               = []
      }
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/lga-servicenow-integration_group/providers/Microsoft.Insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        CostCenterId = "80045905"
        Environment  = "NonProd"
      }
    }
    openai_tokenconsumption_ce = {
      name                = "openai-tokenconsumption-alert-openai-nonprod-ce"
      resource_group_name = "rg-openai-nonprod-alerts-canadaeast-001"
      scopes = [
        "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadaeast-001/providers/Microsoft.CognitiveServices/accounts/oai-openai-nonprod-ce-001"
      ]
      description              = "Fires when processed inference tokens deviate from dynamic baseline"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT1H"
      severity                 = 2
      target_resource_type     = "Microsoft.CognitiveServices/accounts"
      target_resource_location = "canadaeast"
      dynamic_criteria = {
        metric_namespace         = "Microsoft.CognitiveServices/accounts"
        metric_name              = "TokenTransaction"
        aggregation              = "Total"
        operator                 = "GreaterOrLessThan"
        alert_sensitivity        = "Medium"
        evaluation_total_count   = 4
        evaluation_failure_count = 4
        ignore_data_before       = null
        skip_metric_validation   = false
        dimensions               = []
      }
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/rg-alerts-management-canadacentral-001/providers/Microsoft.Insights/actionGroups/ag-monitor-mail-alerts-canadacentral-001"
      ]
      tags = {
        CostCenterId = "80045905"
        Environment  = "NonProd"
      }
    }
    app_httpresponsetime = {
      name                = "app-httpresponsetime-alert-openai-nonprod-cc"
      resource_group_name = "rg-openai-nonprod-alerts-canadacentral-001"
      scopes = [
        "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadacentral-001/providers/Microsoft.Web/sites/app-openai-nonprod-canadacentral-001"
      ]
      description              = "Fires when HttpResponseTime deviates from dynamic baseline"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT1H"
      severity                 = 2
      target_resource_type     = "Microsoft.Web/sites"
      target_resource_location = "canadacentral"
      dynamic_criteria = {
        metric_namespace         = "Microsoft.Web/sites"
        metric_name              = "HttpResponseTime"
        aggregation              = "Average"
        operator                 = "GreaterOrLessThan"
        alert_sensitivity        = "Medium"
        evaluation_total_count   = 4
        evaluation_failure_count = 4
        ignore_data_before       = null
        skip_metric_validation   = false
        dimensions               = []
      }
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-monitor-mail-alerts-canadacentral-001"
      ]
      tags = {
        CostCenterId = "80045905"
        Environment  = "NonProd"
      }
    }
    psql_cpu = {
      name                = "psql-cpu-alert-openai-nonprod-cc"
      resource_group_name = "rg-openai-nonprod-alerts-canadacentral-001"
      scopes = [
        "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadacentral-001/providers/Microsoft.DBforPostgreSQL/flexibleServers/psql-openai-nonprod-cc-001"
      ]
      description              = "Fires when PostgreSQL CPU usage exceeds 90%"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT15M"
      severity                 = 1
      target_resource_type     = "Microsoft.DBforPostgreSQL/flexibleServers"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.DBforPostgreSQL/flexibleServers"
          metric_name            = "cpu_percent"
          aggregation            = "Average"
          operator               = "GreaterThan"
          threshold              = 90
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/lga-servicenow-integration_group/providers/Microsoft.Insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        CostCenterId = "80045905"
        Environment  = "NonProd"
      }
    }
    psql_connection = {
      name                = "psql-connection-alert-openai-nonprod-cc"
      resource_group_name = "rg-openai-nonprod-alerts-canadacentral-001"
      scopes = [
        "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadacentral-001/providers/Microsoft.DBforPostgreSQL/flexibleServers/psql-openai-nonprod-cc-001"
      ]
      description              = "Fires when active connections exceed 80% of server limit"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT15M"
      severity                 = 1
      target_resource_type     = "Microsoft.DBforPostgreSQL/flexibleServers"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.DBforPostgreSQL/flexibleServers"
          metric_name            = "active_connections"
          aggregation            = "Average"
          operator               = "GreaterThan"
          threshold              = 675
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/lga-servicenow-integration_group/providers/Microsoft.Insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        CostCenterId = "80045905"
        Environment  = "NonProd"
      }
    }
    cosmosdb_ruconsumption = {
      name                = "cosmosdb-ruconsumption-alert-openai-nonprod-cc"
      resource_group_name = "rg-openai-nonprod-alerts-canadacentral-001"
      scopes = [
        "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadacentral-001/providers/Microsoft.DocumentDB/databaseAccounts/cdb-openai-nonprod-canadacentral-001"
      ]
      description              = "Fires when normalized RU consumption exceeds 80% — throttling is imminent"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT15M"
      severity                 = 1
      target_resource_type     = "Microsoft.DocumentDB/databaseAccounts"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.DocumentDB/databaseAccounts"
          metric_name            = "NormalizedRUConsumption"
          aggregation            = "Maximum"
          operator               = "GreaterThan"
          threshold              = 80
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/rg-alerts-management-canadacentral-001/providers/Microsoft.Insights/actionGroups/ag-monitor-mail-alerts-canadacentral-001"
      ]
      tags = {
        CostCenterId = "80045905"
        Environment  = "NonProd"
      }
    }
    app_http5xx = {
      name                = "app-http5xx-alert-openai-nonprod-cc"
      resource_group_name = "rg-openai-nonprod-alerts-canadacentral-001"
      scopes = [
        "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadacentral-001/providers/Microsoft.Web/sites/app-openai-nonprod-canadacentral-001"
      ]
      description              = "Fires when Http5xx server errors exceed 5"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT15M"
      severity                 = 1
      target_resource_type     = "Microsoft.Web/sites"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Web/sites"
          metric_name            = "Http5xx"
          aggregation            = "Total"
          operator               = "GreaterThan"
          threshold              = 5
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/lga-servicenow-integration_group/providers/Microsoft.Insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        CostCenterId = "80045905"
        Environment  = "NonProd"
      }
    }
    app_cputime = {
      name                = "app-cputime-alert-openai-nonprod-cc"
      resource_group_name = "rg-openai-nonprod-alerts-canadacentral-001"
      scopes = [
        "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadacentral-001/providers/Microsoft.Web/sites/app-openai-nonprod-canadacentral-001"
      ]
      description              = "Fires when CpuTime exceeds 300 seconds"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT15M"
      severity                 = 2
      target_resource_type     = "Microsoft.Web/sites"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Web/sites"
          metric_name            = "CpuTime"
          aggregation            = "Total"
          operator               = "GreaterThan"
          threshold              = 300
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/lga-servicenow-integration_group/providers/Microsoft.Insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        CostCenterId = "80045905"
        Environment  = "NonProd"
      }
    }
    app_http4xx = {
      name                = "app-http4xx-alert-openai-nonprod-cc"
      resource_group_name = "rg-openai-nonprod-alerts-canadacentral-001"
      scopes = [
        "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadacentral-001/providers/Microsoft.Web/sites/app-openai-nonprod-canadacentral-001"
      ]
      description              = "Fires when Http4xx errors deviate from dynamic baseline"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT1H"
      severity                 = 1
      target_resource_type     = "Microsoft.Web/sites"
      target_resource_location = "canadacentral"
      dynamic_criteria = {
        metric_namespace         = "Microsoft.Web/sites"
        metric_name              = "Http4xx"
        aggregation              = "Total"
        operator                 = "GreaterOrLessThan"
        alert_sensitivity        = "Medium"
        evaluation_total_count   = 4
        evaluation_failure_count = 4
        ignore_data_before       = null
        skip_metric_validation   = false
        dimensions               = []
      }
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-monitor-mail-alerts-canadacentral-001"
      ]
      tags = {
        CostCenterId = "80045905"
        Environment  = "NonProd"
      }
    }
    app_healthcheck = {
      name                = "app-healthcheck-alert-openai-nonprod-cc"
      resource_group_name = "rg-openai-nonprod-alerts-canadacentral-001"
      scopes = [
        "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadacentral-001/providers/Microsoft.Web/sites/app-openai-nonprod-canadacentral-001"
      ]
      description              = "Fires when Health Check status drops below 100"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT15M"
      severity                 = 1
      target_resource_type     = "Microsoft.Web/sites"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Web/sites"
          metric_name            = "HealthCheckStatus"
          aggregation            = "Average"
          operator               = "LessThan"
          threshold              = 100
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-monitor-mail-alerts-canadacentral-001"
      ]
      tags = {
        CostCenterId = "80045905"
        Environment  = "NonProd"
      }
    }
    cosmosdb_throttled_requests = {
      name                = "cosmosdb-throttled-requests-alert-openai-nonprod-cc"
      resource_group_name = "rg-openai-nonprod-alerts-canadacentral-001"
      scopes = [
        "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadacentral-001/providers/Microsoft.DocumentDB/databaseAccounts/cdb-openai-nonprod-canadacentral-001"
      ]
      description              = "Fires when CosmosDB returns 429 throttling errors"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT15M"
      severity                 = 1
      target_resource_type     = "Microsoft.DocumentDB/databaseAccounts"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.DocumentDB/databaseAccounts"
          metric_name            = "TotalRequests"
          aggregation            = "Count"
          operator               = "GreaterThan"
          threshold              = 0
          skip_metric_validation = false
          dimensions = [
            {
              name     = "StatusCode"
              operator = "Include"
              values   = ["429"]
            }
          ]
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-monitor-mail-alerts-canadacentral-001",
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-db-mail-alerts-canadacentral-001"
      ]
      tags = {
        CostCenterId = "80045905"
        Environment  = "NonProd"
      }
    }
    psql_storage = {
      name                = "psql-storage-alert-openai-nonprod-cc"
      resource_group_name = "rg-openai-nonprod-alerts-canadacentral-001"
      scopes = [
        "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadacentral-001/providers/Microsoft.DBforPostgreSQL/flexibleServers/psql-openai-nonprod-cc-001"
      ]
      description              = "Fires when PostgreSQL storage usage exceeds 85% — server will go read-only if full"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT15M"
      window_size              = "PT1H"
      severity                 = 1
      target_resource_type     = "Microsoft.DBforPostgreSQL/flexibleServers"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.DBforPostgreSQL/flexibleServers"
          metric_name            = "storage_percent"
          aggregation            = "Average"
          operator               = "GreaterThan"
          threshold              = 85
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/lga-servicenow-integration_group/providers/Microsoft.Insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        CostCenterId = "80045905"
        Environment  = "NonProd"
      }
    }
    cosmosdb_availability = {
      name                = "cosmosdb-availability-alert-openai-nonprod-cc"
      resource_group_name = "rg-openai-nonprod-alerts-canadacentral-001"
      scopes = [
        "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadacentral-001/providers/Microsoft.DocumentDB/databaseAccounts/cdb-openai-nonprod-canadacentral-001"
      ]
      description              = "Fires when CosmosDB service availability drops below 99.9%"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT1H"
      severity                 = 0
      target_resource_type     = "Microsoft.DocumentDB/databaseAccounts"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.DocumentDB/databaseAccounts"
          metric_name            = "ServiceAvailability"
          aggregation            = "Average"
          operator               = "LessThan"
          threshold              = 99.9
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/lga-servicenow-integration_group/providers/Microsoft.Insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        CostCenterId = "80045905"
        Environment  = "NonProd"
      }
    }
    docintel_clienterror = {
      name                = "docintel-clienterror-alert-openai-nonprod-cc"
      resource_group_name = "rg-openai-nonprod-alerts-canadacentral-001"
      scopes = [
        "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadacentral-001/providers/Microsoft.CognitiveServices/accounts/doc-openai-nonprod-cc-001"
      ]
      description              = "Fires when Document Intelligence client errors deviate from baseline"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT1H"
      severity                 = 2
      target_resource_type     = "Microsoft.CognitiveServices/accounts"
      target_resource_location = "canadacentral"
      dynamic_criteria = {
        metric_namespace         = "Microsoft.CognitiveServices/accounts"
        metric_name              = "ClientErrors"
        aggregation              = "Total"
        operator                 = "GreaterOrLessThan"
        alert_sensitivity        = "Medium"
        evaluation_total_count   = 4
        evaluation_failure_count = 4
        ignore_data_before       = null
        skip_metric_validation   = false
        dimensions               = []
      }
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-monitor-mail-alerts-canadacentral-001"
      ]
      tags = {
        CostCenterId = "80045905"
        Environment  = "NonProd"
      }
    }
    docintel_servererror = {
      name                = "docintel-servererror-alert-openai-nonprod-cc"
      resource_group_name = "rg-openai-nonprod-alerts-canadacentral-001"
      scopes = [
        "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadacentral-001/providers/Microsoft.CognitiveServices/accounts/doc-openai-nonprod-cc-001"
      ]
      description              = "Fires when Document Intelligence returns server-side errors"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT15M"
      severity                 = 1
      target_resource_type     = "Microsoft.CognitiveServices/accounts"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.CognitiveServices/accounts"
          metric_name            = "ServerErrors"
          aggregation            = "Total"
          operator               = "GreaterThan"
          threshold              = 0
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-monitor-mail-alerts-canadacentral-001"
      ]
      tags = {
        CostCenterId = "80045905"
        Environment  = "NonProd"
      }
    }
    docintel_latency = {
      name                = "docintel-latency-alert-openai-nonprod-cc"
      resource_group_name = "rg-openai-nonprod-alerts-canadacentral-001"
      scopes = [
        "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadacentral-001/providers/Microsoft.CognitiveServices/accounts/doc-openai-nonprod-cc-001"
      ]
      description              = "Fires when Document Intelligence latency deviates from dynamic baseline"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT1H"
      severity                 = 2
      target_resource_type     = "Microsoft.CognitiveServices/accounts"
      target_resource_location = "canadacentral"
      dynamic_criteria = {
        metric_namespace         = "Microsoft.CognitiveServices/accounts"
        metric_name              = "Latency"
        aggregation              = "Average"
        operator                 = "GreaterOrLessThan"
        alert_sensitivity        = "Medium"
        evaluation_total_count   = 4
        evaluation_failure_count = 4
        ignore_data_before       = null
        skip_metric_validation   = false
        dimensions               = []
      }
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-monitor-mail-alerts-canadacentral-001"
      ]
      tags = {
        CostCenterId = "80045905"
        Environment  = "NonProd"
      }
    }
    docintel_blockedcalls = {
      name                = "docintel-blockedcalls-alert-openai-nonprod-cc"
      resource_group_name = "rg-openai-nonprod-alerts-canadacentral-001"
      scopes = [
        "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadacentral-001/providers/Microsoft.CognitiveServices/accounts/doc-openai-nonprod-cc-001"
      ]
      description              = "Fires when Document Intelligence calls are throttled or blocked"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT15M"
      severity                 = 1
      target_resource_type     = "Microsoft.CognitiveServices/accounts"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.CognitiveServices/accounts"
          metric_name            = "BlockedCalls"
          aggregation            = "Total"
          operator               = "GreaterThan"
          threshold              = 0
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-monitor-mail-alerts-canadacentral-001"
      ]
      tags = {
        CostCenterId = "80045905"
        Environment  = "NonProd"
      }
    }
  }
  log_search_alerts = {
    kv_secret_near_expiry = {
      name                = "kv-secret-near-expiry-alert-openai-nonprod-cc"
      resource_group_name = "rg-openai-nonprod-siem-canadacentral-001"
      location            = "canadacentral"
      scopes = [
        "/subscriptions/7d54d6f7-83d9-48cf-ac35-1068bcfd0561/resourceGroups/rg-siem-security-canadacentral-001/providers/Microsoft.OperationalInsights/workspaces/la-siem-security-canadacentral-001"
      ]
      severity                          = 1
      evaluation_frequency              = "PT5M"
      window_duration                   = "PT30M"
      description                       = "Fires when one or more Key Vault secrets are expiring within 30 days"
      display_name                      = null
      enabled                           = true
      auto_mitigation_enabled           = true
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = null
      target_resource_types             = null
      criteria = [
        {
          query                   = "AzureDiagnostics\n| where ResourceProvider == \"MICROSOFT.KEYVAULT\"\n| where OperationName contains \"SecretNearExpiry\"\n"
          time_aggregation_method = "Count"
          threshold               = 1
          operator                = "GreaterThanOrEqual"
          resource_id_column      = null
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/lga-servicenow-integration_group/providers/Microsoft.Insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        CostCenterId = "80045905"
        Environment  = "NonProd"
      }
    }
    kv_secret_expired = {
      name                = "kv-secret-expired-alert-openai-nonprod-cc"
      resource_group_name = "rg-openai-nonprod-siem-canadacentral-001"
      location            = "canadacentral"
      scopes = [
        "/subscriptions/7d54d6f7-83d9-48cf-ac35-1068bcfd0561/resourceGroups/rg-siem-security-canadacentral-001/providers/Microsoft.OperationalInsights/workspaces/la-siem-security-canadacentral-001"
      ]
      severity                          = 0
      evaluation_frequency              = "PT5M"
      window_duration                   = "PT30M"
      description                       = "Fires when one or more Key Vault secrets have already expired"
      display_name                      = null
      enabled                           = true
      auto_mitigation_enabled           = true
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = null
      target_resource_types             = null
      criteria = [
        {
          query                   = "AzureDiagnostics\n    | where ResourceProvider == \"MICROSOFT.KEYVAULT\"\n    | where OperationName contains \"SecretExpired\"\n"
          time_aggregation_method = "Count"
          threshold               = 1
          operator                = "GreaterThanOrEqual"
          resource_id_column      = null
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/lga-servicenow-integration_group/providers/Microsoft.Insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        CostCenterId = "80045905"
        Environment  = "NonProd"
      }
    }
    storage_delete = {
      name                = "storage-delete-alert-openai-nonprod-cc"
      resource_group_name = "rg-openai-nonprod-alerts-canadacentral-001"
      location            = "canadacentral"
      scopes = [
        "/subscriptions/7d54d6f7-83d9-48cf-ac35-1068bcfd0561/resourceGroups/rg-siem-security-canadacentral-001/providers/Microsoft.OperationalInsights/workspaces/la-siem-security-canadacentral-001"
      ]
      severity                          = 0
      evaluation_frequency              = "PT5M"
      window_duration                   = "PT30M"
      description                       = "Fires when someone attempts to delete a storage account"
      display_name                      = null
      enabled                           = true
      auto_mitigation_enabled           = true
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = null
      target_resource_types             = null
      criteria = [
        {
          query                   = "AzureActivity\n| where ResourceProviderValue == \"MICROSOFT.STORAGE\"\n| where OperationNameValue == \"Microsoft.Storage/storageAccounts/delete\"\n| where SubscriptionId == \"79fa77c1-d916-47f8-b388-33c03f29c5ea\"\n"
          time_aggregation_method = "Count"
          threshold               = 1
          operator                = "GreaterThanOrEqual"
          resource_id_column      = null
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/lga-servicenow-integration_group/providers/Microsoft.Insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        CostCenterId = "80045905"
        Environment  = "NonProd"
      }
    }
    storage_container_delete = {
      name                = "storage-container-delete-alert-openai-nonprod-cc"
      resource_group_name = "rg-openai-nonprod-alerts-canadacentral-001"
      location            = "canadacentral"
      scopes = [
        "/subscriptions/7d54d6f7-83d9-48cf-ac35-1068bcfd0561/resourceGroups/rg-siem-security-canadacentral-001/providers/Microsoft.OperationalInsights/workspaces/la-siem-security-canadacentral-001"
      ]
      severity                          = 0
      evaluation_frequency              = "PT5M"
      window_duration                   = "PT30M"
      description                       = "Fires when someone attempts to delete a storage container"
      display_name                      = null
      enabled                           = true
      auto_mitigation_enabled           = true
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = null
      target_resource_types             = null
      criteria = [
        {
          query                   = "AzureActivity\n| where ResourceProviderValue == \"MICROSOFT.STORAGE\"\n| where OperationNameValue == \"Microsoft.Storage/storageAccounts/blobServices/containers/delete\"\n| where SubscriptionId == \"79fa77c1-d916-47f8-b388-33c03f29c5ea\"\n"
          time_aggregation_method = "Count"
          threshold               = 1
          operator                = "GreaterThanOrEqual"
          resource_id_column      = null
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/lga-servicenow-integration_group/providers/Microsoft.Insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        CostCenterId = "80045905"
        Environment  = "NonProd"
      }
    }
  }
  alert_processing_rules = {}
}

activity_log_alert_imports = {
  openai_delete_ce = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-alerts-canadaeast-001/providers/Microsoft.Insights/activityLogAlerts/openai-delete-alert-openai-nonprod-ce"
  kv_delete        = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-siem-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/kv-delete-alert-openai-nonprod-cc"
  cosmosdb_delete  = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-alerts-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/cosmosdb-delete-alert-openai-nonprod-cc"
  psql_delete      = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-alerts-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/psql-delete-alert-openai-nonprod-cc"
  docintel_delete  = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-alerts-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/docintel-delete-alert-openai-nonprod-cc"
}

metric_alert_imports = {
  openai_servererror_ce       = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-alerts-canadaeast-001/providers/Microsoft.Insights/metricAlerts/openai-servererror-alert-openai-nonprod-ce"
  openai_blockedcalls_ce      = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-alerts-canadaeast-001/providers/Microsoft.Insights/metricAlerts/openai-blockedcalls-alert-openai-nonprod-ce"
  openai_availability_ce      = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-alerts-canadaeast-001/providers/Microsoft.Insights/metricAlerts/openai-availability-alert-openai-nonprod-ce"
  openai_responsetime_ce      = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-alerts-canadaeast-001/providers/Microsoft.Insights/metricAlerts/openai-responsetime-alert-openai-nonprod-ce"
  openai_tokenconsumption_ce  = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-alerts-canadaeast-001/providers/Microsoft.Insights/metricAlerts/openai-tokenconsumption-alert-openai-nonprod-ce"
  app_httpresponsetime        = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-alerts-canadacentral-001/providers/Microsoft.Insights/metricAlerts/app-httpresponsetime-alert-openai-nonprod-cc"
  psql_cpu                    = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-alerts-canadacentral-001/providers/Microsoft.Insights/metricAlerts/psql-cpu-alert-openai-nonprod-cc"
  psql_connection             = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-alerts-canadacentral-001/providers/Microsoft.Insights/metricAlerts/psql-connection-alert-openai-nonprod-cc"
  cosmosdb_ruconsumption      = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-alerts-canadacentral-001/providers/Microsoft.Insights/metricAlerts/cosmosdb-ruconsumption-alert-openai-nonprod-cc"
  app_http5xx                 = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-alerts-canadacentral-001/providers/Microsoft.Insights/metricAlerts/app-http5xx-alert-openai-nonprod-cc"
  app_cputime                 = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-alerts-canadacentral-001/providers/Microsoft.Insights/metricAlerts/app-cputime-alert-openai-nonprod-cc"
  app_http4xx                 = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-alerts-canadacentral-001/providers/Microsoft.Insights/metricAlerts/app-http4xx-alert-openai-nonprod-cc"
  app_healthcheck             = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-alerts-canadacentral-001/providers/Microsoft.Insights/metricAlerts/app-healthcheck-alert-openai-nonprod-cc"
  cosmosdb_throttled_requests = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-alerts-canadacentral-001/providers/Microsoft.Insights/metricAlerts/cosmosdb-throttled-requests-alert-openai-nonprod-cc"
  psql_storage                = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-alerts-canadacentral-001/providers/Microsoft.Insights/metricAlerts/psql-storage-alert-openai-nonprod-cc"
  cosmosdb_availability       = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-alerts-canadacentral-001/providers/Microsoft.Insights/metricAlerts/cosmosdb-availability-alert-openai-nonprod-cc"
  docintel_clienterror        = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-alerts-canadacentral-001/providers/Microsoft.Insights/metricAlerts/docintel-clienterror-alert-openai-nonprod-cc"
  docintel_servererror        = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-alerts-canadacentral-001/providers/Microsoft.Insights/metricAlerts/docintel-servererror-alert-openai-nonprod-cc"
  docintel_latency            = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-alerts-canadacentral-001/providers/Microsoft.Insights/metricAlerts/docintel-latency-alert-openai-nonprod-cc"
  docintel_blockedcalls       = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-alerts-canadacentral-001/providers/Microsoft.Insights/metricAlerts/docintel-blockedcalls-alert-openai-nonprod-cc"
}

log_search_alert_imports = {
  kv_secret_near_expiry    = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-siem-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/kv-secret-near-expiry-alert-openai-nonprod-cc"
  kv_secret_expired        = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-siem-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/kv-secret-expired-alert-openai-nonprod-cc"
  storage_delete           = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-alerts-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/storage-delete-alert-openai-nonprod-cc"
  storage_container_delete = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-alerts-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/storage-container-delete-alert-openai-nonprod-cc"
}

# Not managed here:
#   activitylogalerts 'app-plan-write-alert-openai-nonprod-cc' (rg-openai-nonprod-alerts-canadacentral-001): `status` uses containsAny ['started']; the wrapper's single `status` writes `equals`, so adoption would rewrite the condition
#   activitylogalerts 'app-delete-alert-openai-nonprod-cc' (rg-openai-nonprod-alerts-canadacentral-001): `status` uses containsAny ['started']; the wrapper's single `status` writes `equals`, so adoption would rewrite the condition
#   activitylogalerts 'app-start-alert-openai-nonprod-cc' (rg-openai-nonprod-alerts-canadacentral-001): `status` uses containsAny ['started']; the wrapper's single `status` writes `equals`, so adoption would rewrite the condition
#   activitylogalerts 'app-stop-alert-openai-nonprod-cc' (rg-openai-nonprod-alerts-canadacentral-001): `status` uses containsAny ['started']; the wrapper's single `status` writes `equals`, so adoption would rewrite the condition
alert_processing_rule_imports = {}

app_service_plan = {
  app = {
    name                            = "asp-openai-nonprod-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    os_type                         = "Linux"
    sku_name                        = "P1v3"
    worker_count                    = 1
    maximum_elastic_worker_count    = 1
    per_site_scaling_enabled        = false
    premium_plan_auto_scale_enabled = false
    zone_balancing_enabled          = false
    app_service_environment_id      = null
    tags = {
      CostCenterId = "80045905"
      Environment  = "NonProd"
    }
  }
}

app_service_plan_imports = {
  app = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadacentral-001/providers/Microsoft.Web/serverFarms/asp-openai-nonprod-canadacentral-001"
}

# The daily cap is not in the export (100 is the provider default); confirm with
# az monitor app-insights component billing show.
application_insights = {
  app = {
    name                          = "ai-openai-nonprod-canadacentral-001"
    resource_group_key            = "app"
    location                      = "canadacentral"
    workspace_id                  = "/subscriptions/7d54d6f7-83d9-48cf-ac35-1068bcfd0561/resourceGroups/rg-siem-security-canadacentral-001/providers/Microsoft.OperationalInsights/workspaces/la-siem-security-canadacentral-001"
    application_type              = "web"
    retention_in_days             = 30
    daily_data_cap_in_gb          = 100
    sampling_percentage           = 100
    internet_ingestion_enabled    = false
    internet_query_enabled        = true
    local_authentication_disabled = false
    disable_ip_masking            = false
    tags = {
      CostCenterId = "80045905"
      Environment  = "NonProd"
    }
  }
}

application_insights_imports = {
  app = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadacentral-001/providers/Microsoft.Insights/components/ai-openai-nonprod-canadacentral-001"
}

bastion_host = {
  app = {
    name               = "vnet-openai-nonprod-canadacentral-001-bastion"
    resource_group_key = "network"
    location           = "canadacentral"
    sku                = "Developer"
    scale_units        = 2
    virtual_network_id = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-nonprod-canadacentral-001"
    zones              = []
    copy_paste_enabled = true
    tags = {
      CostCenterId = "80045905"
      Environment  = "NonProd"
    }
  }
}

bastion_host_imports = {
  app = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-network-canadacentral-001/providers/Microsoft.Network/bastionHosts/vnet-openai-nonprod-canadacentral-001-bastion"
}

# zone_redundancy_enabled forces replacement. Retention is disabled on the live
# registry, so retention_policy_in_days stays null; admin_enabled matches the export.
container_registry = {
  app = {
    name                          = "acropenainonprodcc001"
    resource_group_key            = "app"
    location                      = "canadacentral"
    sku                           = "Premium"
    admin_enabled                 = true
    anonymous_pull_enabled        = false
    data_endpoint_enabled         = false
    export_policy_enabled         = true
    quarantine_policy_enabled     = false
    retention_policy_in_days      = null
    trust_policy_enabled          = false
    public_network_access_enabled = false
    network_rule_bypass_option    = "None"
    network_rule_set              = null
    zone_redundancy_enabled       = false
    tags = {
      CostCenterId = "80045905"
      Environment  = "NonProd"
    }
  }
}

container_registry_existing = {}

container_registry_imports = {
  app = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadacentral-001/providers/Microsoft.ContainerRegistry/registries/acropenainonprodcc001"
}

event_grid_system_topic = {
  app_storage = {
    name                        = "stopenainonprodcac001-a0d8b176-e05d-4cbb-a209-cda828e415a1"
    resource_group_key          = "app"
    location                    = "canadacentral"
    topic_type                  = "microsoft.storage.storageaccounts"
    source_resource_id          = null
    exported_source_resource_id = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadacentral-001/providers/microsoft.storage/storageaccounts/stopenainonprodcac001"
    tags = {
      CostCenterId = "80045905"
      Environment  = "NonProd"
    }
  }
}

event_grid_system_topic_imports = {
  app_storage = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadacentral-001/providers/Microsoft.EventGrid/systemTopics/stopenainonprodcac001-a0d8b176-e05d-4cbb-a209-cda828e415a1"
}

# softDeleteRetentionInDays is not reported, which means Azure's default of 90.
key_vault = {
  app = {
    name                            = "kvopenainonprodcc001"
    resource_group_key              = "siem"
    location                        = "canadacentral"
    tenant_id                       = "8fbb85e8-0cbc-48c3-a2e9-528cef30ec27"
    sku_name                        = "premium"
    enabled_for_deployment          = false
    enabled_for_disk_encryption     = true
    enabled_for_template_deployment = true
    legacy_access_policies_enabled  = false
    public_network_access_enabled   = false
    purge_protection_enabled        = true
    soft_delete_retention_days      = 90
    network_acls = {
      bypass                     = "AzureServices"
      default_action             = "Deny"
      ip_rules                   = []
      virtual_network_subnet_ids = []
    }
    tags = {
      CostCenterId = "80045905"
      Environment  = "NonProd"
    }
  }
}

key_vault_imports = {
  app = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-siem-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvopenainonprodcc001"
}

# Switched off for the first apply; adopt in its own run. SSH keys only, so no
# password is needed. The OS disk is owned inline; extensions and run commands stay unmanaged.
linux_virtual_machine = {
  app = {
    name               = "vm-openai-nonprod-canadacentral-001"
    resource_group_key = "app"
    location           = "canadacentral"
    size               = "Standard_D2s_v4"
    zone               = null
    admin_username     = "azure_admin"
    admin_ssh_public_keys = [
      "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAACAQCqSuz4vaooT6vou6bgZFNMxOl7oSuKEkoGhv7rjyfPTQmtQQ5Ey+4pAMqHWqMCWtGVMrPf+A4aDSmSdVhzZyTHPAKuAOF/tDOpbQwZKzEwFyf5dSI8fu48uWeesBdEr8I6TlX2HF0bTw+nHrAp8di/7cXjVbM/lU3J175LSHFNCHOGGvYXHgwHYfDpLzStnwu+v4Sd5ZR9X/e0Q+bgqcPoiNTmlice5Fh08U9G2wJh4GByNsbx2Ec5PdU+4BbwUrgYJXnkgRs+b/zRT81wz/zKZUb2TSQuCwvxTXgt8pM70UbkILcsUnm7CxYxgqTC+lHfWExq+cI9YNVNeNkcg3+HvadIPQEdy/rvW2nx6uS1oDLVhNmcJRHT0dXMekOhCFQOX+P8QsE9syTZQP6uKql5vO4Lsq0joMpdQBO2KhabvJxJmhRsJeThjVHMp2xKonsUVV7732rVzwO9WpTYiYpjwbE5ND1Tv7aBEEYqkN5UIyI3lNLCcUbPoYkkFvD1flhtk7tmeZByht7BWcLYja6o/bVeQlprmcfOEIsmOmHxW8mlCj0o0RJcQIuBlRJwd93yZCofWfghzMAVVkLt4t0SLqcQMOwFQ/AxhJKSxg7t56+6rQdqcmHBVlGE2xyJqyMos6nS3TkOOIEaIuAj6klvuuM3Kh6Zt63XjcgL7hdNLw==\n"
    ]
    computer_name = "vm-openai-nonprod-canadacentral-001"
    network_interface_ids = [
      "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadacentral-001/providers/Microsoft.Network/networkInterfaces/vm-openai-nonprod-canadacentral-001-nic"
    ]
    os_managed_disk_id                                     = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadacentral-001/providers/Microsoft.Compute/disks/vm-openai-nonprod-canadacentral-001_OsDisk_1_b21400a9f39a4063b2bb23684e2922b5"
    allow_extension_operations                             = true
    bypass_platform_safety_checks_on_user_schedule_enabled = false
    disk_controller_type                                   = "SCSI"
    encryption_at_host_enabled                             = false
    license_type                                           = "RHEL_BYOS"
    patch_assessment_mode                                  = "AutomaticByPlatform"
    patch_mode                                             = "ImageDefault"
    provision_vm_agent                                     = true
    secure_boot_enabled                                    = false
    vtpm_enabled                                           = false
    additional_capabilities = {
      hibernation_enabled = false
    }
    boot_diagnostics = null
    identity = {
      type                       = "SystemAssigned"
      user_assigned_identity_ids = []
    }
    os_disk = {
      name                 = "vm-openai-nonprod-canadacentral-001_OsDisk_1_b21400a9f39a4063b2bb23684e2922b5"
      caching              = "ReadWrite"
      disk_size_gb         = 64
      storage_account_type = "StandardSSD_LRS"
    }
    source_image_reference = {
      publisher = "RedHat"
      offer     = "RHEL"
      sku       = "9_6"
      version   = "Latest"
    }
    tags = {
      CostCenterId = "80045905"
      Environment  = "NonProd"
    }
  }
}

linux_virtual_machine_imports = {
  app = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-openai-nonprod-canadacentral-001"
}

log_analytics_workspace = {}

log_analytics_workspace_imports = {}

network_interface = {
  app_primary = {
    name                           = "vm-openai-nonprod-canadacentral-001-nic"
    resource_group_key             = "app"
    location                       = "canadacentral"
    enabled                        = true
    accelerated_networking_enabled = false
    ip_forwarding_enabled          = false
    ip_configurations = {
      primary = {
        name                          = "internal"
        primary                       = true
        private_ip_address            = "10.195.30.4"
        private_ip_address_allocation = "Dynamic"
        subnet_id                     = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-nonprod-canadacentral-001/subnets/snet-openai-nonprod-mgmt-canadacentral-001"
      }
    }
    tags = {
      CostCenterId = "80045905"
      Environment  = "NonProd"
    }
  }
}

# No NIC-level NSGs.
network_interface_nsg_associations = {}

network_watcher = {
  canadacentral = {
    name               = "NetworkWatcher_canadacentral"
    resource_group_key = "networkwatcherrg"
    location           = "canadacentral"
    tags = {
      CostCenterId = "80045905"
      Environment  = "NonProd"
    }
  }
  canadaeast = {
    name               = "NetworkWatcher_canadaeast"
    resource_group_key = "networkwatcherrg"
    location           = "canadaeast"
    tags = {
      CostCenterId = "80045905"
      Environment  = "NonProd"
    }
  }
}

network_watcher_imports = {
  canadacentral = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/NetworkWatcherRG/providers/Microsoft.Network/networkWatchers/NetworkWatcher_canadacentral"
  canadaeast    = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/NetworkWatcherRG/providers/Microsoft.Network/networkWatchers/NetworkWatcher_canadaeast"
}

private_endpoint = {
  openai = {
    enabled                         = true
    name                            = "pep-oai-openai-nonprod-ce-001"
    resource_group_key              = "app_canadaeast"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-nonprod-canadacentral-001/subnets/snet-openai-nonprod-pep-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadaeast-001/providers/Microsoft.CognitiveServices/accounts/oai-openai-nonprod-ce-001"
    private_service_connection_name = "oai-openai-nonprod-ce-001-psc"
    subresource_names               = ["account"]
    network_interface_name          = null
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.openai.azure.com"
    ]
    ip_configurations = {}
    tags = {
      CostCenterId = "80045905"
      Environment  = "NonProd"
    }
  }
  container_registry = {
    enabled                         = true
    name                            = "pep-acropenainonprodcc001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-nonprod-canadacentral-001/subnets/snet-openai-nonprod-pep-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadacentral-001/providers/Microsoft.ContainerRegistry/registries/acropenainonprodcc001"
    private_service_connection_name = "acropenainonprodcc001-psc"
    subresource_names               = ["registry"]
    network_interface_name          = null
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.azurecr.io"
    ]
    ip_configurations = {}
    tags = {
      CostCenterId = "80045905"
      Environment  = "NonProd"
    }
  }
  key_vault = {
    enabled                         = true
    name                            = "pep-kvopenainonprodcc001"
    resource_group_key              = "siem"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-nonprod-canadacentral-001/subnets/snet-openai-nonprod-pep-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-siem-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvopenainonprodcc001"
    private_service_connection_name = "kvopenainonprodcc001-psc"
    subresource_names               = ["vault"]
    network_interface_name          = null
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.vaultcore.azure.net"
    ]
    ip_configurations = {}
    tags = {
      CostCenterId = "80045905"
      Environment  = "NonProd"
    }
  }
  storage_queue = {
    enabled                         = true
    name                            = "pep-queue-stopenainonprodcac001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-nonprod-canadacentral-001/subnets/snet-openai-nonprod-pep-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadacentral-001/providers/Microsoft.Storage/storageAccounts/stopenainonprodcac001"
    private_service_connection_name = "stopenainonprodcac001-queue-psc"
    subresource_names               = ["queue"]
    network_interface_name          = null
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.queue.core.windows.net"
    ]
    ip_configurations = {}
    tags = {
      CostCenterId = "80045905"
      Environment  = "NonProd"
    }
  }
  storage_blob = {
    enabled                         = true
    name                            = "pep-blob-stopenainonprodcac001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-nonprod-canadacentral-001/subnets/snet-openai-nonprod-pep-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadacentral-001/providers/Microsoft.Storage/storageAccounts/stopenainonprodcac001"
    private_service_connection_name = "stopenainonprodcac001-blob-psc"
    subresource_names               = ["blob"]
    network_interface_name          = null
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net"
    ]
    ip_configurations = {}
    tags = {
      CostCenterId = "80045905"
      Environment  = "NonProd"
    }
  }
  web_app = {
    enabled                         = true
    name                            = "pep-app-openai-nonprod-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-nonprod-canadacentral-001/subnets/snet-openai-nonprod-pep-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadacentral-001/providers/Microsoft.Web/sites/app-openai-nonprod-canadacentral-001"
    private_service_connection_name = "app-openai-nonprod-canadacentral-001-psc"
    subresource_names               = ["sites"]
    network_interface_name          = null
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.azurewebsites.net"
    ]
    ip_configurations = {}
    tags = {
      CostCenterId = "80045905"
      Environment  = "NonProd"
    }
  }
  cosmos_db = {
    enabled                         = true
    name                            = "pep-cdb-openai-nonprod-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-nonprod-canadacentral-001/subnets/snet-openai-nonprod-pep-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadacentral-001/providers/Microsoft.DocumentDB/databaseAccounts/cdb-openai-nonprod-canadacentral-001"
    private_service_connection_name = "cdb-openai-nonprod-canadacentral-001-psc"
    subresource_names               = ["Sql"]
    network_interface_name          = null
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.documents.azure.com"
    ]
    ip_configurations = {}
    tags = {
      CostCenterId = "80045905"
      Environment  = "NonProd"
    }
  }
  postgresql = {
    enabled                         = true
    name                            = "pep-psql-openai-nonprod-cc-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-nonprod-canadacentral-001/subnets/snet-openai-nonprod-pep-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadacentral-001/providers/Microsoft.DBforPostgreSQL/flexibleServers/psql-openai-nonprod-cc-001"
    private_service_connection_name = "psql-openai-nonprod-cc-001-psc"
    subresource_names               = ["postgresqlServer"]
    network_interface_name          = null
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.postgres.database.azure.com"
    ]
    ip_configurations = {}
    tags = {
      CostCenterId = "80045905"
      Environment  = "NonProd"
    }
  }
  document_intelligence = {
    enabled                         = true
    name                            = "pep-doc-openai-nonprod-cc-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-nonprod-canadacentral-001/subnets/snet-openai-nonprod-pep-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadacentral-001/providers/Microsoft.CognitiveServices/accounts/doc-openai-nonprod-cc-001"
    private_service_connection_name = "doc-openai-nonprod-cc-001-psc"
    subresource_names               = ["account"]
    network_interface_name          = null
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.cognitiveservices.azure.com"
    ]
    ip_configurations = {}
    tags = {
      CostCenterId = "80045905"
      Environment  = "NonProd"
    }
  }
  function_app = {
    enabled                         = true
    name                            = "pep-func-openai-nonprod-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-nonprod-canadacentral-001/subnets/snet-openai-nonprod-pep-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadacentral-001/providers/Microsoft.Web/sites/func-openai-nonprod-canadacentral-001"
    private_service_connection_name = "func-openai-nonprod-canadacentral-001-psc"
    subresource_names               = ["sites"]
    network_interface_name          = null
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.azurewebsites.net"
    ]
    ip_configurations = {}
    tags = {
      CostCenterId = "80045905"
      Environment  = "NonProd"
    }
  }
  backup = {
    enabled                         = true
    name                            = "pep-rsv-openai-nonprod-backup-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-nonprod-canadacentral-001/subnets/snet-openai-nonprod-pep-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourcegroups/rg-openai-nonprod-app-canadacentral-001/providers/Microsoft.RecoveryServices/vaults/rsv-openai-nonprod-canadacentral-001"
    private_service_connection_name = "pep-rsv-openai-nonprod-backup-canadacentral-001_54c6523f-50bf-48a9-8d63-39b37f70c029"
    subresource_names               = ["AzureBackup"]
    network_interface_name          = null
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net",
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.cnc.backup.windowsazure.com",
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.queue.core.windows.net"
    ]
    ip_configurations = {}
    tags = {
      CostCenterId = "80045905"
      Environment  = "NonProd"
    }
  }
}

private_endpoint_imports = {
  openai                = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadaeast-001/providers/Microsoft.Network/privateEndpoints/pep-oai-openai-nonprod-ce-001"
  container_registry    = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-acropenainonprodcc001"
  key_vault             = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-siem-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-kvopenainonprodcc001"
  storage_queue         = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-queue-stopenainonprodcac001"
  storage_blob          = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-blob-stopenainonprodcac001"
  web_app               = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-app-openai-nonprod-canadacentral-001"
  cosmos_db             = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-cdb-openai-nonprod-canadacentral-001"
  postgresql            = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-psql-openai-nonprod-cc-001"
  document_intelligence = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-doc-openai-nonprod-cc-001"
  function_app          = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-func-openai-nonprod-canadacentral-001"
  backup                = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-rsv-openai-nonprod-backup-canadacentral-001"
}

# Managed with azurerm_ssh_public_key directly; the AVM module rejects hyphens.
public_ssh_key = {
  openai_key = {
    name               = "openai_key"
    resource_group_key = "app"
    location           = "canadacentral"
    public_key         = "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQC9EZWcTw9c7p+BDrYAX9DexHggVaTuy8rTtUR7Hi+CTez/we+giSrj6BesxWbHQh/ehqignl+tzcfHoFMwwwRHFEAksYeUurtP0baI02s/HE7ety5wP+suGsv+s8o/dA8GUBznWtu5EcLWsFZ0Shi0nUmuo7d1kmsn93Sb6Yl/KbLZ3ny1rPodDEjXvrFk4P/TbZ7wEr8cIOzlUEjOX2IY5Eho6OSUdbWBhTrcKvRWNkysNUyjwewCpk17Q/BQwbq5aFaTIFii4CGQXa7QAfwkc2Mhc+9DYAc0hrIKP7vUOR3JJEzKi3vL+b626dpw3yWFygNAXbe3l+wGQp7qmbK+qfgKkKzyXBaSGMUhnOXTJdBJe3nMIfJkaBHnfqrYYXgfgvW15AEHhM1CG7bvv/K44CtovtW52Yd+DnL0pOXlBHHyqXZ1WmVcIWSaXcs8PXBanu3d0rp29WxtUdW/z3fSzgSUOMv0v+rMHmqHPw2aK+/2thByyKWgcTgXwP69PGk= generated-by-azure"
    tags = {
      CostCenterId = "80045905"
      Environment  = "NonProd"
    }
  }
  ssh_public = {
    name               = "ssh_public_key"
    resource_group_key = "app"
    location           = "canadacentral"
    public_key         = "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQDhX4PtMNpR5hSF9w6sKW4s8X3dwReD4Cr/gf0OYktElVeEMwc2JXg8SvvCiAWpzOiV0DNZ5x3io6zkSiMAVoRmCwezfD9M19TYjN0OD5PSIR6sJVZ/mCI4Inq4bgMAmdPHfKhquZ4F6u5myo/+A0tQdlZSnS0OCR4IfG/BFgsQvHFPmYbsSly12WXj/enp99sbMtYN/PzgJcBekc1oqGWgih8+wgLBxxWnlhmPA7rwBgnkq5T+3z6eibjQzPatB+8TR92oqQZuJVtXvFFGkaJd20gdDpJgK43nB6oDrpRRMeEnv/FGNTX4sFCNwimMvZ0rzvlWalozSCcPuaPjwvtEQGg0q7sCsgH4ixOxHjBMUao9nGkO35jqeuSNPezN2jfgoZ/8VDOpFj9akfk3VOMWiH6dBKaecJSFOCfFXz/UjFNXCsXrzhTt/2oubCvRoK07tJqCdYcRMpcQWrqmo9BigNvz5hJ1BGlRoW55PFEknl+1PEAe9OwAEKhagAKnxbE= generated-by-azure"
    tags = {
      CostCenterId = "80045905"
      Environment  = "NonProd"
    }
  }
}

public_ssh_key_imports = {
  openai_key = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadacentral-001/providers/Microsoft.Compute/sshPublicKeys/openai_key"
  ssh_public = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadacentral-001/providers/Microsoft.Compute/sshPublicKeys/ssh_public_key"
}

# monitoringSettings is null on the live vault; alert flags default to false
# so adoption does not switch alerting on.
recovery_services_vault = {
  app = {
    name                          = "rsv-openai-nonprod-canadacentral-001"
    resource_group_key            = "app"
    location                      = "canadacentral"
    sku                           = "RS0"
    storage_mode_type             = "LocallyRedundant"
    cross_region_restore_enabled  = false
    soft_delete_enabled           = true
    immutability                  = "Disabled"
    public_network_access_enabled = false
    tags = {
      CostCenterId = "80045905"
      Environment  = "NonProd"
    }
  }
}

recovery_services_vault_imports = {
  app = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadacentral-001/providers/Microsoft.RecoveryServices/vaults/rsv-openai-nonprod-canadacentral-001"
}

# Azure Backup owns these; only the containers are adopted.
restore_point_collection = {
  app = {
    name                      = "AzureBackup_vm-openai-nonprod-canadacentral-001_6310774532632997146"
    resource_group_name       = "AzureBackupRG_canadacentral_1"
    location                  = "canadacentral"
    source_virtual_machine_id = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-openai-nonprod-canadacentral-001"
    tags = {
      CostCenterId = "80045905"
      Environment  = "NonProd"
    }
  }
}

restore_point_collection_imports = {
  app = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/AzureBackupRG_canadacentral_1/providers/Microsoft.Compute/restorePointCollections/AzureBackup_vm-openai-nonprod-canadacentral-001_6310774532632997146"
}

# Blob service properties were not exported, so blob_properties stays null.
storage_account = {
  app = {
    name                              = "stopenainonprodcac001"
    resource_group_key                = "app"
    location                          = "canadacentral"
    account_kind                      = "StorageV2"
    account_tier                      = "Standard"
    account_replication_type          = "ZRS"
    access_tier                       = "Hot"
    allow_nested_items_to_be_public   = true
    cross_tenant_replication_enabled  = false
    default_to_oauth_authentication   = true
    https_traffic_only_enabled        = true
    infrastructure_encryption_enabled = false
    is_hns_enabled                    = false
    large_file_share_enabled          = null
    min_tls_version                   = "TLS1_2"
    public_network_access_enabled     = false
    sftp_enabled                      = false
    shared_access_key_enabled         = true
    blob_properties                   = null
    network_rules = {
      bypass                     = ["AzureServices"]
      default_action             = "Deny"
      ip_rules                   = []
      virtual_network_subnet_ids = []
      private_link_access = [
        {
          endpoint_resource_id = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/providers/Microsoft.Security/datascanners/storageDataScanner"
          endpoint_tenant_id   = "8fbb85e8-0cbc-48c3-a2e9-528cef30ec27"
        }
      ]
    }
    tags = {
      CostCenterId = "80045905"
      Environment  = "NonProd"
    }
  }
}

storage_account_existing = {}

storage_account_imports = {
  app = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-app-canadacentral-001/providers/Microsoft.Storage/storageAccounts/stopenainonprodcac001"
}

# vnet-openai-nonprod-canadacentral-001 peerings (unmanaged): RemoteVnetToHubPeering_a8db0ae7-e4bd-4112-a74f-86be5b004e19
# Disabled for now, as in Fit and Fabric: the VNet module's body omits subnets and
# peerings, so the import plan removes them, and the only peering is the vWAN
# hub connection owned by tf-deploy-platform-connectivity. Adopt it with the
# connectivity team on hand to restore the hub connection.
# defaultOutboundAccess is taken from the export where reported, otherwise Azure's
# default (enabled). It is create-time only, so a replace in the plan means the
# value is wrong. The hub peering stays unmanaged.
virtual_network = {
  app = {
    name               = "vnet-openai-nonprod-canadacentral-001"
    resource_group_key = "network"
    location           = "canadacentral"
    address_space      = ["10.195.28.0/22"]
    ddos_protection_plan = {
      enable = true
      id     = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/ddosProtectionPlans/ddos-protection-plan"
    }
    subnets = {
      app = {
        name                                          = "snet-openai-nonprod-app-canadacentral-001"
        address_prefixes                              = ["10.195.29.0/24"]
        default_outbound_access_enabled               = true
        private_endpoint_network_policies             = "Disabled"
        private_link_service_network_policies_enabled = true
        service_endpoint_policies                     = {}
        service_endpoints_with_location               = []
        delegations = [
          {
            name = "Microsoft.Web/serverFarms"
            service_delegation = {
              name    = "Microsoft.Web/serverFarms"
              actions = ["Microsoft.Network/virtualNetworks/subnets/action"]
            }
          }
        ]
      }
      mgmt = {
        name                                          = "snet-openai-nonprod-mgmt-canadacentral-001"
        address_prefixes                              = ["10.195.30.0/24"]
        default_outbound_access_enabled               = true
        private_endpoint_network_policies             = "Disabled"
        private_link_service_network_policies_enabled = true
        service_endpoint_policies                     = {}
        service_endpoints_with_location               = []
        delegations                                   = []
      }
      pep = {
        name                                          = "snet-openai-nonprod-pep-canadacentral-001"
        address_prefixes                              = ["10.195.28.0/24"]
        default_outbound_access_enabled               = true
        private_endpoint_network_policies             = "RouteTableEnabled"
        private_link_service_network_policies_enabled = true
        service_endpoint_policies                     = {}
        service_endpoints_with_location = [
          {
            service   = "Microsoft.AzureCosmosDB"
            locations = ["*"]
          }
        ]
        delegations = []
      }
    }
    tags = {
      CostCenterId = "80045905"
      Environment  = "NonProd"
    }
  }
}

virtual_network_imports = {
  app = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-nonprod-canadacentral-001"
}

virtual_network_subnet_imports = {
  app_app = {
    vnet_key   = "app"
    subnet_key = "app"
    id         = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-nonprod-canadacentral-001/subnets/snet-openai-nonprod-app-canadacentral-001"
  }
  app_mgmt = {
    vnet_key   = "app"
    subnet_key = "mgmt"
    id         = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-nonprod-canadacentral-001/subnets/snet-openai-nonprod-mgmt-canadacentral-001"
  }
  app_pep = {
    vnet_key   = "app"
    subnet_key = "pep"
    id         = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-nonprod-canadacentral-001/subnets/snet-openai-nonprod-pep-canadacentral-001"
  }
}
