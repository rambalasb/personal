# tf-deploy-app-spo

Terraform that adopts the existing **SPO** (SharePoint Online / Power Platform)
network resources into state, following the same layout as the Fit, PTA and
Fabric deploy repos.

| Environment | Subscription | ID |
|---|---|---|
| `nonprod` | Sub-SPO-NonProd | `b8ee8f40-3a3f-4583-b3a2-d34541c46fec` |
| `prod` | Sub-SPO-Prod | `0832c60a-a0fb-4cf4-9add-b555c50e4815` |

Use Terraform `>= 1.9, < 2.0`, one state per environment, and select
`envs/nonprod.tfvars` or `envs/prod.tfvars`. Adopt nonprod first; prod follows
the same runs and stages.

## Status

Both environments are filled from the Azure resource export of 2026-11-03
and are ready for the first import run. The VNets are filled in but switched
off (see [Staged adoption](#staged-adoption)).

The subscriptions hold network plumbing for Power Platform VNet support: a
VNet per region with an app subnet delegated to
`Microsoft.PowerPlatform/enterprisePolicies` and a private endpoint subnet,
NSGs, a Key Vault with an endpoint in each region, and the flow log storage
account. The two Power Platform enterprise policies per environment have no
wrapper yet; see WRAPPER-GAPS.

Prod differs from nonprod:

- `rg-spo-prod-app-language-001` holds `spolanguageservice`, a Cognitive
  Services (Language) account with public access enabled. The group is
  adopted; the account is not.
- Nonprod has a third VNet, `rg-spo-nonprod-network-canadaeast-001` (see
  below).

## Tiers

| File | Implementation | Nonprod | Prod |
|---|---|---|---|
| `resource_group.tf` | `tf-wrapper-avm-resource-group` 2.0.0 | 7, enabled | 8, enabled |
| `key_vault.tf` | `tf-wrapper-avm-key-vault` 0.4.0 | 1, enabled | 1, enabled |
| `network_security_group.tf` | `tf-wrapper-avm-network-security-group` 0.1.1 | 4, no custom rules, enabled | 4, no custom rules, enabled |
| `network_watcher.tf` | `azurerm_network_watcher` | 2, enabled | 2, enabled |
| `private_endpoint.tf` | `tf-wrapper-avm-private-endpoint` 0.1.2 | 3, enabled | 3, enabled |
| `storage_account.tf` | `azurerm_storage_account`; read-only `azapi_resource` data source | 1, enabled | 1, enabled |
| `virtual_network.tf` | `tf-wrapper-avm-virtual-network` 0.1.0 | 3 + 6 subnets, disabled | 2 + 4 subnets, disabled |
| `role_assignment.tf` | `tf-wrapper-avm-role-assignment` 0.3.6 | all off | all off |

No storage account here has public access enabled, so nothing is read-only.
The app and SIEM resource groups in Canada East, and the app group in Canada
Central, are empty; they are adopted as they are.

What stays unmanaged is in [WRAPPER-GAPS.md](WRAPPER-GAPS.md).

## Things to check before the first import

- **NSGs:** all four per environment have only the default rules. Import
  should show no rule changes.
- **Key Vault:** RBAC mode, public access disabled, purge protection on. One
  vault per environment in Canada Central, with a private endpoint in each
  region (`key_vault` and `key_vault_canadaeast`).
- **Stray VNet (nonprod):** `rg-spo-nonprod-network-canadaeast-001` is a VNet
  named after its resource group. It reuses the address space of
  `vnet-spo-nonprod-canadaeast-001` (`10.196.125.0/24`), has no peering and no
  delegation. It looks created by mistake. It is in tfvars as
  `rg_network_canadaeast` with the other VNets; confirm with the SPO team and
  delete it in Azure instead of adopting it if it is not used.
- **Prod resource groups** already carry `CanNotDelete` locks. They are
  separate resources and stay unmanaged.

## Adoption

Every resource here already exists in Azure. Each tier has `enable_<type>`
and an import map; imports only run while the tier is enabled, and
validations check every import ID against the key, name, resource group and
`subscription_id`.

Before the first apply:

- Make sure auto-apply is off on the HCP workspace, so every apply is
  confirmed by hand after reading the plan.
- Prod resource groups already carry `CanNotDelete` locks, so an unexpected
  replace fails there instead of destroying the resource. Nonprod has none;
  optionally add one to the network resource groups for the adoption window.

  ```bash
  az lock create --name adoption-no-delete --lock-type CanNotDelete --resource-group <rg>
  az lock delete --name adoption-no-delete --resource-group <rg>   # afterwards
  ```

Each run, first or staged:

1. Run `.github/workflows/import-verify.yml` for the environment. It only
   plans, then runs `scripts/import_gate.sh`, which wraps
   `scripts/verify_zero_diff.sh`: it fails on anything other than imports and
   tag updates and reports any replace separately.
2. Fix diffs by correcting tfvars, never by changing Azure. Repeat until the
   gate passes. Never accept a replace or delete with `--allow-resource`.
   Accepted addresses go in `scripts/import_gate.sh`.
3. Run `.github/workflows/import-apply.yml` for the environment, with
   `confirm` set to `apply`. Read the check job's summary (gate output and
   plan: only imports and tag updates), then approve the apply job. It
   re-plans, re-runs the gate and refuses to apply if the change set moved
   since the check. Do not use `landing-zone-multi-env.yml` while imports
   are pending; it applies with `-auto-approve` and no gate.
4. Empty the import maps of the tiers that applied.


## Staged adoption

This tier is complete in tfvars but switched off, because adopting it can
drop the hub connection. It gets its own import-verify and apply, after the
first run has applied.

| Stage | Flags | Why it is held back |
|---|---|---|
| Virtual network | `enable_virtual_network` | The vWAN hub connections are owned by the connectivity repo |

The app subnets are delegated to `Microsoft.PowerPlatform/enterprisePolicies`
and are in use by the enterprise policies. A subnet replace would break the
Power Platform environments that use them, so read the plan closely.

### Stage: Virtual network

The VNet module sends a body without subnets or peerings, so the import plan
shows both being removed. Each VNet's only peering is its vWAN hub connection,
declared in `tf-deploy-platform-connectivity`. Upstream tests confirm that
subnets and peerings created outside the module survive the update, but not
vWAN hub connections. This stage is the same as Fit's, Fabric's and PTA's.

1. Agree a window with the connectivity team, so they can restore the hub
   connection from their repo if it drops.
2. Set `enable_virtual_network = true` and run import-verify. Expected: one
   import per VNet and per subnet.
3. `defaultOutboundAccess` is taken from the export where Azure reports it,
   otherwise Azure's default (`true`). It is create-time only: a subnet
   replace in the plan means that value is wrong, so stop and correct it.
4. Apply, check the hub connection and the Power Platform network injection, then empty the VNet and
   subnet import maps.

## Role assignments

`role_assignment.tf` uses one typed map: resource type, parent key, then
assignment key. Every `enable_<type>_role_assignment` is false and
`role_assignments = {}` in both environments. Nothing is inferred from the
export, and existing assignments need their own imports.

## Pipeline

| Workflow | Purpose |
|---|---|
| `import-verify.yml` | Plan and gate. Never applies. Run this first |
| `import-apply.yml` | Gate, approval on the `<env>` environment, re-gate, apply |
| `landing-zone-multi-env.yml` | Deploy pipeline, `workflow_dispatch` only |
| `state-rm.yml` | Remove one address from state without touching Azure |
| `tflint.yml` | HCL lint on push and PR |
| `trivy.yml` | IaC scan on PR and weekly |

`import-apply.yml` needs required reviewers on the `nonprod` and `prod`
GitHub Environments, or the apply job runs without stopping. Its check job
runs outside any environment, so `TF_API_TOKEN`, `TF_CLOUD_ORGANIZATION`
and `TFC_WORKSPACE_PREFIX` must be set at repo or org level.

`TFC_WORKSPACE_PREFIX` must be set before the first run (`az-spo`, matching Fit's `az-fit`).
