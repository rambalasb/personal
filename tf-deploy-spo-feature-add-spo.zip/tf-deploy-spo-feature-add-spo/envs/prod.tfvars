# Sub-SPO-Prod (0832c60a-a0fb-4cf4-9add-b555c50e4815)
# Values come from the Azure resource export of 2026-11-03.
# The VNets are off for the first apply; adopt them in a separate run.

subscription_id = "0832c60a-a0fb-4cf4-9add-b555c50e4815"

enable_resource_group         = true
enable_key_vault              = true
enable_network_security_group = true
enable_network_watcher        = true
enable_private_endpoint       = true
enable_storage_account        = true
enable_virtual_network        = false

enable_resource_group_role_assignment         = false
enable_key_vault_role_assignment              = false
enable_network_security_group_role_assignment = false
enable_network_watcher_role_assignment        = false
enable_private_endpoint_role_assignment       = false
enable_storage_account_role_assignment        = false
enable_virtual_network_role_assignment        = false

role_assignments = {}

# The existing CanNotDelete locks are separate resources and stay unmanaged.
resource_group = {
  app = {
    name     = "rg-spo-prod-app-canadacentral-001"
    location = "canadacentral"
    tags = {
      CostCenterId = "80030609"
      Environment  = "Prod"
    }
  }
  network = {
    name     = "rg-spo-prod-network-canadacentral-001"
    location = "canadacentral"
    tags = {
      CostCenterId = "80030609"
      Environment  = "Prod"
    }
  }
  siem = {
    name     = "rg-spo-prod-siem-canadacentral-001"
    location = "canadacentral"
    tags = {
      CostCenterId = "80030609"
      Environment  = "Prod"
    }
  }
  networkwatcherrg = {
    name     = "NetworkWatcherRG"
    location = "canadacentral"
    tags = {
      CostCenterId = "80030609"
      Environment  = "Prod"
    }
  }
  app_language = {
    name     = "rg-spo-prod-app-language-001"
    location = "canadacentral"
    tags = {
      CostCenterId = "80030609"
      Environment  = "Prod"
    }
  }
  app_canadaeast = {
    name     = "rg-spo-prod-app-canadaeast-001"
    location = "canadaeast"
    tags = {
      CostCenterId = "80030609"
      Environment  = "Prod"
    }
  }
  network_canadaeast = {
    name     = "rg-spo-prod-network-canadaeast-001"
    location = "canadaeast"
    tags = {
      CostCenterId = "80030609"
      Environment  = "Prod"
    }
  }
  siem_canadaeast = {
    name     = "rg-spo-prod-siem-canadaeast-001"
    location = "canadaeast"
    tags = {
      CostCenterId = "80030609"
      Environment  = "Prod"
    }
  }
}

import_resource_group = {
  app                = "/subscriptions/0832c60a-a0fb-4cf4-9add-b555c50e4815/resourceGroups/rg-spo-prod-app-canadacentral-001"
  network            = "/subscriptions/0832c60a-a0fb-4cf4-9add-b555c50e4815/resourceGroups/rg-spo-prod-network-canadacentral-001"
  siem               = "/subscriptions/0832c60a-a0fb-4cf4-9add-b555c50e4815/resourceGroups/rg-spo-prod-siem-canadacentral-001"
  networkwatcherrg   = "/subscriptions/0832c60a-a0fb-4cf4-9add-b555c50e4815/resourceGroups/NetworkWatcherRG"
  app_language       = "/subscriptions/0832c60a-a0fb-4cf4-9add-b555c50e4815/resourceGroups/rg-spo-prod-app-language-001"
  app_canadaeast     = "/subscriptions/0832c60a-a0fb-4cf4-9add-b555c50e4815/resourceGroups/rg-spo-prod-app-canadaeast-001"
  network_canadaeast = "/subscriptions/0832c60a-a0fb-4cf4-9add-b555c50e4815/resourceGroups/rg-spo-prod-network-canadaeast-001"
  siem_canadaeast    = "/subscriptions/0832c60a-a0fb-4cf4-9add-b555c50e4815/resourceGroups/rg-spo-prod-siem-canadaeast-001"
}

key_vault = {
  app = {
    name                            = "kvspoprodcac001"
    resource_group_key              = "siem"
    location                        = "canadacentral"
    tenant_id                       = "8fbb85e8-0cbc-48c3-a2e9-528cef30ec27"
    sku_name                        = "premium"
    enabled_for_deployment          = true
    enabled_for_disk_encryption     = false
    enabled_for_template_deployment = true
    legacy_access_policies_enabled  = false
    public_network_access_enabled   = false
    purge_protection_enabled        = true
    soft_delete_retention_days      = 90
    network_acls = {
      bypass                     = "AzureServices"
      default_action             = "Deny"
      ip_rules                   = []
      virtual_network_subnet_ids = []
    }
    tags = {
      CostCenterId = "80030609"
      Environment  = "Prod"
    }
  }
}

key_vault_imports = {
  app = "/subscriptions/0832c60a-a0fb-4cf4-9add-b555c50e4815/resourceGroups/rg-spo-prod-siem-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvspoprodcac001"
}

# Protocols are normalised to the wrapper's casing (Tcp/Icmp); Azure reports
# them upper case, which may show as a case-only update on import.
network_security_group = {
  app = {
    name               = "nsg-spo-prod-app-canadacentral-001"
    resource_group_key = "network"
    location           = "canadacentral"
    security_rules     = {}
    tags = {
      CostCenterId = "80030609"
      Environment  = "Prod"
    }
  }
  pep = {
    name               = "nsg-spo-prod-pep-canadacentral-001"
    resource_group_key = "network"
    location           = "canadacentral"
    security_rules     = {}
    tags = {
      CostCenterId = "80030609"
      Environment  = "Prod"
    }
  }
  app_canadaeast = {
    name               = "nsg-spo-prod-app-canadaeast-001"
    resource_group_key = "network_canadaeast"
    location           = "canadaeast"
    security_rules     = {}
    tags = {
      CostCenterId = "80030609"
      Environment  = "Prod"
    }
  }
  pep_canadaeast = {
    name               = "nsg-spo-prod-pep-canadaeast-001"
    resource_group_key = "network_canadaeast"
    location           = "canadaeast"
    security_rules     = {}
    tags = {
      CostCenterId = "80030609"
      Environment  = "Prod"
    }
  }
}

import_network_security_group = {
  app            = "/subscriptions/0832c60a-a0fb-4cf4-9add-b555c50e4815/resourceGroups/rg-spo-prod-network-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-spo-prod-app-canadacentral-001"
  pep            = "/subscriptions/0832c60a-a0fb-4cf4-9add-b555c50e4815/resourceGroups/rg-spo-prod-network-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-spo-prod-pep-canadacentral-001"
  app_canadaeast = "/subscriptions/0832c60a-a0fb-4cf4-9add-b555c50e4815/resourceGroups/rg-spo-prod-network-canadaeast-001/providers/Microsoft.Network/networkSecurityGroups/nsg-spo-prod-app-canadaeast-001"
  pep_canadaeast = "/subscriptions/0832c60a-a0fb-4cf4-9add-b555c50e4815/resourceGroups/rg-spo-prod-network-canadaeast-001/providers/Microsoft.Network/networkSecurityGroups/nsg-spo-prod-pep-canadaeast-001"
}

network_security_rule_imports = {}

network_watcher = {
  canadacentral = {
    name               = "NetworkWatcher_canadacentral"
    resource_group_key = "networkwatcherrg"
    location           = "canadacentral"
    tags = {
      CostCenterId = "80030609"
      Environment  = "Prod"
    }
  }
  canadaeast = {
    name               = "NetworkWatcher_canadaeast"
    resource_group_key = "networkwatcherrg"
    location           = "canadaeast"
    tags = {
      CostCenterId = "80030609"
      Environment  = "Prod"
    }
  }
}

network_watcher_imports = {
  canadacentral = "/subscriptions/0832c60a-a0fb-4cf4-9add-b555c50e4815/resourceGroups/NetworkWatcherRG/providers/Microsoft.Network/networkWatchers/NetworkWatcher_canadacentral"
  canadaeast    = "/subscriptions/0832c60a-a0fb-4cf4-9add-b555c50e4815/resourceGroups/NetworkWatcherRG/providers/Microsoft.Network/networkWatchers/NetworkWatcher_canadaeast"
}

private_endpoint = {
  key_vault = {
    enabled                         = true
    name                            = "pep-kv-spo-prod-canadacentral-001"
    resource_group_key              = "siem"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/0832c60a-a0fb-4cf4-9add-b555c50e4815/resourceGroups/rg-spo-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-spo-prod-canadacentral-001/subnets/snet-spo-prod-pep-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/0832c60a-a0fb-4cf4-9add-b555c50e4815/resourceGroups/rg-spo-prod-siem-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvspoprodcac001"
    private_service_connection_name = "pep-kv-spo-prod-canadacentral-001"
    subresource_names               = ["vault"]
    network_interface_name          = "pep-kv-spo-prod-canadacentral-001-nic"
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.vaultcore.azure.net"
    ]
    ip_configurations = {}
    tags = {
      CostCenterId = "80030609"
      Environment  = "Prod"
    }
  }
  network_watcher_storage = {
    enabled                         = true
    name                            = "pep-stnwspoprd001xd"
    resource_group_key              = "networkwatcherrg"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/0832c60a-a0fb-4cf4-9add-b555c50e4815/resourceGroups/rg-spo-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-spo-prod-canadacentral-001/subnets/snet-spo-prod-pep-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/0832c60a-a0fb-4cf4-9add-b555c50e4815/resourcegroups/NetworkWatcherRG/providers/Microsoft.Storage/storageAccounts/stnwspoprd001xd"
    private_service_connection_name = "pep-stnwspoprd001xd"
    subresource_names               = ["blob"]
    network_interface_name          = "pep-stnwspoprd001xd-nic"
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net"
    ]
    ip_configurations = {}
    tags = {
      CostCenterId = "80030609"
      Environment  = "Prod"
    }
  }
  key_vault_canadaeast = {
    enabled                         = true
    name                            = "pep-kv-spo-prod-canadaeast-001"
    resource_group_key              = "siem"
    location                        = "canadaeast"
    subnet_resource_id              = "/subscriptions/0832c60a-a0fb-4cf4-9add-b555c50e4815/resourceGroups/rg-spo-prod-network-canadaeast-001/providers/Microsoft.Network/virtualNetworks/vnet-spo-prod-canadaeast-001/subnets/snet-spo-prod-pep-canadaeast-001"
    private_connection_resource_id  = "/subscriptions/0832c60a-a0fb-4cf4-9add-b555c50e4815/resourceGroups/rg-spo-prod-siem-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvspoprodcac001"
    private_service_connection_name = "pep-kv-spo-prod-canadaeast-001"
    subresource_names               = ["vault"]
    network_interface_name          = "pep-kv-spo-prod-canadaeast-001-nic"
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.vaultcore.azure.net"
    ]
    ip_configurations = {}
    tags = {
      CostCenterId = "80030609"
      Environment  = "Prod"
    }
  }
}

private_endpoint_imports = {
  key_vault               = "/subscriptions/0832c60a-a0fb-4cf4-9add-b555c50e4815/resourceGroups/rg-spo-prod-siem-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-kv-spo-prod-canadacentral-001"
  network_watcher_storage = "/subscriptions/0832c60a-a0fb-4cf4-9add-b555c50e4815/resourceGroups/NetworkWatcherRG/providers/Microsoft.Network/privateEndpoints/pep-stnwspoprd001xd"
  key_vault_canadaeast    = "/subscriptions/0832c60a-a0fb-4cf4-9add-b555c50e4815/resourceGroups/rg-spo-prod-siem-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-kv-spo-prod-canadaeast-001"
}

# Blob service properties were not exported, so blob_properties stays null.
storage_account = {
  network_watcher = {
    name                              = "stnwspoprd001xd"
    resource_group_key                = "networkwatcherrg"
    location                          = "canadacentral"
    account_kind                      = "StorageV2"
    account_tier                      = "Standard"
    account_replication_type          = "LRS"
    access_tier                       = "Hot"
    allow_nested_items_to_be_public   = false
    cross_tenant_replication_enabled  = false
    default_to_oauth_authentication   = true
    https_traffic_only_enabled        = true
    infrastructure_encryption_enabled = false
    is_hns_enabled                    = false
    large_file_share_enabled          = null
    min_tls_version                   = "TLS1_2"
    public_network_access_enabled     = false
    sftp_enabled                      = false
    shared_access_key_enabled         = false
    blob_properties                   = null
    network_rules = {
      bypass                     = ["AzureServices"]
      default_action             = "Deny"
      ip_rules                   = []
      virtual_network_subnet_ids = []
      private_link_access        = []
    }
    tags = {
      CostCenterId = "80030609"
      Environment  = "Prod"
    }
  }
}

storage_account_existing = {}

storage_account_imports = {
  network_watcher = "/subscriptions/0832c60a-a0fb-4cf4-9add-b555c50e4815/resourceGroups/NetworkWatcherRG/providers/Microsoft.Storage/storageAccounts/stnwspoprd001xd"
}

# vnet-spo-prod-canadacentral-001 peerings (unmanaged): RemoteVnetToHubPeering_a8db0ae7-e4bd-4112-a74f-86be5b004e19
# vnet-spo-prod-canadaeast-001 peerings (unmanaged): RemoteVnetToHubPeering_38d55ab0-6c38-42de-bbf1-330ef44c8e89
# Disabled for now, as in Fit and Fabric: the VNet module's body omits subnets and
# peerings, so the import plan removes them, and the only peering is the vWAN
# hub connection owned by tf-deploy-platform-connectivity. Adopt it with the
# connectivity team on hand to restore the hub connection.
# defaultOutboundAccess is taken from the export where reported, otherwise Azure's
# default (enabled). It is create-time only, so a replace in the plan means the
# value is wrong. The hub peering stays unmanaged.
virtual_network = {
  app = {
    name               = "vnet-spo-prod-canadacentral-001"
    resource_group_key = "network"
    location           = "canadacentral"
    address_space      = ["10.195.124.0/24"]
    ddos_protection_plan = {
      enable = true
      id     = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/ddosProtectionPlans/ddos-protection-plan"
    }
    encryption = {
      enabled     = false
      enforcement = "AllowUnencrypted"
    }
    subnets = {
      pep = {
        name                                          = "snet-spo-prod-pep-canadacentral-001"
        address_prefixes                              = ["10.195.124.0/25"]
        default_outbound_access_enabled               = false
        private_endpoint_network_policies             = "RouteTableEnabled"
        private_link_service_network_policies_enabled = true
        network_security_group = {
          id = "/subscriptions/0832c60a-a0fb-4cf4-9add-b555c50e4815/resourceGroups/rg-spo-prod-network-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-spo-prod-pep-canadacentral-001"
        }
        service_endpoint_policies       = {}
        service_endpoints_with_location = []
        delegations                     = []
      }
      app = {
        name                                          = "snet-spo-prod-app-canadacentral-001"
        address_prefixes                              = ["10.195.124.128/25"]
        default_outbound_access_enabled               = false
        private_endpoint_network_policies             = "RouteTableEnabled"
        private_link_service_network_policies_enabled = true
        network_security_group = {
          id = "/subscriptions/0832c60a-a0fb-4cf4-9add-b555c50e4815/resourceGroups/rg-spo-prod-network-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-spo-prod-app-canadacentral-001"
        }
        service_endpoint_policies       = {}
        service_endpoints_with_location = []
        delegations = [
          {
            name = "Microsoft.PowerPlatform/enterprisePolicies"
            service_delegation = {
              name    = "Microsoft.PowerPlatform/enterprisePolicies"
              actions = ["Microsoft.Network/virtualNetworks/subnets/join/action"]
            }
          }
        ]
      }
    }
    tags = {
      CostCenterId = "80030609"
      Environment  = "Prod"
    }
  }
  app_canadaeast = {
    name               = "vnet-spo-prod-canadaeast-001"
    resource_group_key = "network_canadaeast"
    location           = "canadaeast"
    address_space      = ["10.196.124.0/24"]
    ddos_protection_plan = {
      enable = true
      id     = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/ddosProtectionPlans/ddos-protection-plan"
    }
    encryption = {
      enabled     = false
      enforcement = "AllowUnencrypted"
    }
    subnets = {
      app_canadaeast = {
        name                                          = "snet-spo-prod-app-canadaeast-001"
        address_prefixes                              = ["10.196.124.128/25"]
        default_outbound_access_enabled               = false
        private_endpoint_network_policies             = "RouteTableEnabled"
        private_link_service_network_policies_enabled = true
        network_security_group = {
          id = "/subscriptions/0832c60a-a0fb-4cf4-9add-b555c50e4815/resourceGroups/rg-spo-prod-network-canadaeast-001/providers/Microsoft.Network/networkSecurityGroups/nsg-spo-prod-app-canadaeast-001"
        }
        service_endpoint_policies       = {}
        service_endpoints_with_location = []
        delegations = [
          {
            name = "Microsoft.PowerPlatform/enterprisePolicies"
            service_delegation = {
              name    = "Microsoft.PowerPlatform/enterprisePolicies"
              actions = ["Microsoft.Network/virtualNetworks/subnets/join/action"]
            }
          }
        ]
      }
      pep_canadaeast = {
        name                                          = "snet-spo-prod-pep-canadaeast-001"
        address_prefixes                              = ["10.196.124.0/25"]
        default_outbound_access_enabled               = false
        private_endpoint_network_policies             = "RouteTableEnabled"
        private_link_service_network_policies_enabled = true
        network_security_group = {
          id = "/subscriptions/0832c60a-a0fb-4cf4-9add-b555c50e4815/resourceGroups/rg-spo-prod-network-canadaeast-001/providers/Microsoft.Network/networkSecurityGroups/nsg-spo-prod-pep-canadaeast-001"
        }
        service_endpoint_policies       = {}
        service_endpoints_with_location = []
        delegations                     = []
      }
    }
    tags = {
      CostCenterId = "80030609"
      Environment  = "Prod"
    }
  }
}

virtual_network_imports = {
  app            = "/subscriptions/0832c60a-a0fb-4cf4-9add-b555c50e4815/resourceGroups/rg-spo-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-spo-prod-canadacentral-001"
  app_canadaeast = "/subscriptions/0832c60a-a0fb-4cf4-9add-b555c50e4815/resourceGroups/rg-spo-prod-network-canadaeast-001/providers/Microsoft.Network/virtualNetworks/vnet-spo-prod-canadaeast-001"
}

virtual_network_subnet_imports = {
  app_pep = {
    vnet_key   = "app"
    subnet_key = "pep"
    id         = "/subscriptions/0832c60a-a0fb-4cf4-9add-b555c50e4815/resourceGroups/rg-spo-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-spo-prod-canadacentral-001/subnets/snet-spo-prod-pep-canadacentral-001"
  }
  app_app = {
    vnet_key   = "app"
    subnet_key = "app"
    id         = "/subscriptions/0832c60a-a0fb-4cf4-9add-b555c50e4815/resourceGroups/rg-spo-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-spo-prod-canadacentral-001/subnets/snet-spo-prod-app-canadacentral-001"
  }
  app_canadaeast_app_canadaeast = {
    vnet_key   = "app_canadaeast"
    subnet_key = "app_canadaeast"
    id         = "/subscriptions/0832c60a-a0fb-4cf4-9add-b555c50e4815/resourceGroups/rg-spo-prod-network-canadaeast-001/providers/Microsoft.Network/virtualNetworks/vnet-spo-prod-canadaeast-001/subnets/snet-spo-prod-app-canadaeast-001"
  }
  app_canadaeast_pep_canadaeast = {
    vnet_key   = "app_canadaeast"
    subnet_key = "pep_canadaeast"
    id         = "/subscriptions/0832c60a-a0fb-4cf4-9add-b555c50e4815/resourceGroups/rg-spo-prod-network-canadaeast-001/providers/Microsoft.Network/virtualNetworks/vnet-spo-prod-canadaeast-001/subnets/snet-spo-prod-pep-canadaeast-001"
  }
}
