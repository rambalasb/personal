# Wrapper gaps: `tf-deploy-app-spo`

Resources in the SPO subscriptions that this repo does not manage. Counts are
from the Azure resource export of 2026-11-03.

## Staged

| Resource | Environment | Reason |
|---|---|---|
| `vnet-spo-<env>-canadacentral-001`, `vnet-spo-<env>-canadaeast-001` (+ subnets) | both | vWAN hub connection owned by the connectivity repo |
| `rg-spo-nonprod-network-canadaeast-001` (VNet) | nonprod | Likely created by mistake; confirm before adopting |

## Needs a tier

| Resource | Environment | Reason |
|---|---|---|
| `bch-powerplatform-<env>-networkpolicy`, `ep-spo-<env>-test-001` | both | `Microsoft.PowerPlatform/enterprisePolicies` has no AVM module and no `azurerm` resource; it needs an `azapi_resource` tier (WRAPPER-BACKLOG section D) |
| `spolanguageservice` | prod | Cognitive Services account. `tf-wrapper-avm-cognitive-services-account` is built but not yet used by any deploy repo; pin it once published. Public access is enabled, so it would also be blocked by `Deny_Public_Access_On_PaaS_Services_v0` |

## Not managed

| Type | Nonprod | Prod | Reason |
|---|---:|---:|---|
| `microsoft.network/networkinterfaces` | 3 | 3 | PE NICs belong to their endpoint |
| `microsoft.network/virtualnetworks` peerings | 2 | 2 | Hub peerings are owned by the connectivity repo |
