module "network_security_group" {
  for_each = var.enable_network_security_group ? var.network_security_group : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-network-security-group/azurerm"
  version = "0.1.1"

  name                = each.value.name
  resource_group_name = module.resource_group[each.value.resource_group_key].name
  location            = coalesce(each.value.location, module.resource_group[each.value.resource_group_key].location)
  security_rules      = each.value.security_rules
  tags                = each.value.tags

  enable_telemetry = false
}

import {
  for_each = var.enable_network_security_group ? var.import_network_security_group : {}

  to = module.network_security_group[each.key].module.network_security_group.azurerm_network_security_group.this
  id = each.value
}

import {
  for_each = var.enable_network_security_group ? var.network_security_rule_imports : {}

  to = module.network_security_group[each.value.nsg_key].module.network_security_group.azurerm_network_security_rule.this[each.value.rule_key]
  id = each.value.id
}