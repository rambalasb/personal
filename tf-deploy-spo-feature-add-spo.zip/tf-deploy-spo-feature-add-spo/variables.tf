variable "subscription_id" {
  type        = string
  description = "Azure subscription this environment adopts resources into."

  validation {
    condition     = can(regex("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$", var.subscription_id))
    error_message = "subscription_id must be an Azure subscription UUID."
  }
}

variable "enable_resource_group" {
  type        = bool
  description = "Whether Terraform manages and imports the existing resource groups."
  default     = false
}

variable "resource_group" {
  type = map(object({
    name     = string
    location = string
    lock = optional(object({
      kind = string
      name = optional(string)
    }))
    managed_by = optional(string)
    tags       = optional(map(string), {})
  }))
  description = "Existing resource groups to adopt, keyed by stable instance roles."
  default     = {}
}

variable "import_resource_group" {
  type        = map(string)
  description = "Existing resource group IDs, keyed by the matching resource_group instance."
  default     = {}

  validation {
    condition = alltrue([
      for group_key, resource_id in var.import_resource_group :
      resource_id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[group_key].name, "")}"
    ])
    error_message = "Each import_resource_group entry must match its resource_group key, name and subscription_id."
  }
}

variable "enable_key_vault" {
  type        = bool
  description = "Whether Terraform manages and imports the existing Key Vaults."
  default     = false
}

variable "key_vault" {
  type = map(object({
    name                            = string
    resource_group_key              = string
    location                        = optional(string)
    tenant_id                       = string
    sku_name                        = optional(string, "premium")
    enabled_for_deployment          = optional(bool, false)
    enabled_for_disk_encryption     = optional(bool, false)
    enabled_for_template_deployment = optional(bool, false)
    legacy_access_policies_enabled  = optional(bool, false)
    public_network_access_enabled   = optional(bool, true)
    purge_protection_enabled        = optional(bool, true)
    soft_delete_retention_days      = optional(number, 90)
    network_acls = optional(object({
      bypass                     = optional(string, "None")
      default_action             = optional(string, "Deny")
      ip_rules                   = optional(list(string), [])
      virtual_network_subnet_ids = optional(set(string), [])
    }), {})
    tags = optional(map(string), {})
  }))
  description = "Existing vault-level configuration to adopt without keys, secrets or child resources."
  default     = {}

  validation {
    condition = alltrue([
      for vault in values(var.key_vault) :
      contains(keys(var.resource_group), vault.resource_group_key) && (!var.enable_key_vault || var.enable_resource_group)
    ])
    error_message = "Each Key Vault must reference a managed resource group, enabled when vault adoption is enabled."
  }

  validation {
    condition     = alltrue([for vault in values(var.key_vault) : !vault.legacy_access_policies_enabled])
    error_message = "This vault-only adoption configuration requires RBAC; legacy policy adoption is not configured."
  }

  validation {
    condition     = alltrue([for vault in values(var.key_vault) : vault.soft_delete_retention_days >= 7 && vault.soft_delete_retention_days <= 90])
    error_message = "Key Vault soft-delete retention must be between 7 and 90 days."
  }
}

variable "key_vault_imports" {
  type        = map(string)
  description = "Existing Key Vault IDs, keyed by the matching key_vault instance."
  default     = {}

  validation {
    condition = alltrue([
      for vault_key, resource_id in var.key_vault_imports :
      resource_id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[var.key_vault[vault_key].resource_group_key].name, "")}/providers/Microsoft.KeyVault/vaults/${try(var.key_vault[vault_key].name, "")}"
    ])
    error_message = "Each key_vault_imports entry must match its vault key, name, resource group and subscription_id."
  }
}

variable "enable_network_security_group" {
  type        = bool
  description = "Whether Terraform manages and imports the existing NSGs and their custom rules."
  default     = false
}

variable "network_security_group" {
  type = map(object({
    name               = string
    resource_group_key = string
    location           = optional(string)
    security_rules = optional(map(object({
      name                         = string
      access                       = string
      direction                    = string
      priority                     = number
      protocol                     = string
      description                  = optional(string)
      source_port_range            = optional(string)
      source_port_ranges           = optional(set(string))
      destination_port_range       = optional(string)
      destination_port_ranges      = optional(set(string))
      source_address_prefix        = optional(string)
      source_address_prefixes      = optional(set(string))
      destination_address_prefix   = optional(string)
      destination_address_prefixes = optional(set(string))
    })), {})
    tags = optional(map(string), {})
  }))
  description = "Existing NSGs and custom rules to adopt, without extra tags or RBAC."
  default     = {}

  validation {
    condition = alltrue([
      for nsg in values(var.network_security_group) :
      contains(keys(var.resource_group), nsg.resource_group_key) && (!var.enable_network_security_group || var.enable_resource_group)
    ])
    error_message = "Each NSG must reference a managed resource group, enabled when NSG adoption is enabled."
  }
}

variable "import_network_security_group" {
  type        = map(string)
  description = "Existing NSG IDs, keyed by network_security_group."
  default     = {}

  validation {
    condition = alltrue([
      for nsg_key, resource_id in var.import_network_security_group :
      resource_id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[var.network_security_group[nsg_key].resource_group_key].name, "")}/providers/Microsoft.Network/networkSecurityGroups/${try(var.network_security_group[nsg_key].name, "")}"
    ])
    error_message = "Each import_network_security_group entry must match its NSG key, name, resource group and subscription_id."
  }
}

variable "network_security_rule_imports" {
  type = map(object({
    nsg_key  = string
    rule_key = string
    id       = string
  }))
  description = "Existing custom rule IDs and their wrapper map keys; verify the pinned nested rule resource address."
  default     = {}

  validation {
    condition = alltrue([
      for rule in values(var.network_security_rule_imports) :
      rule.id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[var.network_security_group[rule.nsg_key].resource_group_key].name, "")}/providers/Microsoft.Network/networkSecurityGroups/${try(var.network_security_group[rule.nsg_key].name, "")}/securityRules/${try(var.network_security_group[rule.nsg_key].security_rules[rule.rule_key].name, "")}"
    ])
    error_message = "Each rule import must match its NSG key, rule key, exported rule name, resource group and subscription_id."
  }
}

variable "enable_network_watcher" {
  type        = bool
  description = "Whether Terraform manages and imports the existing Network Watchers."
  default     = false
}

variable "network_watcher" {
  type = map(object({
    name               = string
    resource_group_key = string
    location           = optional(string)
    tags               = optional(map(string), {})
  }))
  description = "Existing Network Watchers to adopt directly with AzureRM."
  default     = {}

  validation {
    condition = alltrue([
      for watcher in values(var.network_watcher) :
      contains(keys(var.resource_group), watcher.resource_group_key) && (!var.enable_network_watcher || var.enable_resource_group)
    ])
    error_message = "Each Network Watcher must reference a managed resource group, enabled when watcher adoption is enabled."
  }
}

variable "network_watcher_imports" {
  type        = map(string)
  description = "Existing Network Watcher IDs, keyed by the matching network_watcher instance."
  default     = {}

  validation {
    condition = alltrue([
      for watcher_key, resource_id in var.network_watcher_imports :
      resource_id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[var.network_watcher[watcher_key].resource_group_key].name, "")}/providers/Microsoft.Network/networkWatchers/${try(var.network_watcher[watcher_key].name, "")}"
    ])
    error_message = "Each network_watcher_imports entry must match its watcher key, name, resource group and subscription_id."
  }
}

variable "enable_private_endpoint" {
  type        = bool
  description = "Whether Terraform manages and imports the existing private endpoints."
  default     = false
}

variable "private_endpoint" {
  type = map(object({
    enabled                         = optional(bool, true)
    name                            = string
    resource_group_key              = string
    location                        = optional(string)
    subnet_resource_id              = string
    private_connection_resource_id  = string
    private_service_connection_name = optional(string)
    subresource_names               = optional(list(string))
    network_interface_name          = optional(string)
    private_dns_zone_group_name     = optional(string)
    private_dns_zone_resource_ids   = optional(list(string), [])
    ip_configurations = optional(map(object({
      name               = string
      private_ip_address = string
      subresource_name   = string
      member_name        = optional(string, "default")
    })), {})
    tags = optional(map(string), {})
  }))
  description = "Existing private endpoints to adopt, owning their generated NICs."
  default     = {}

  validation {
    condition = alltrue([
      for endpoint in values(var.private_endpoint) :
      contains(keys(var.resource_group), endpoint.resource_group_key) && (!var.enable_private_endpoint || !endpoint.enabled || var.enable_resource_group)
    ])
    error_message = "Each endpoint must reference a managed resource group, enabled when that endpoint is managed."
  }
}

variable "private_endpoint_imports" {
  type        = map(string)
  description = "Existing endpoint IDs, keyed by private_endpoint and filtered by global/per-entry enable flags."
  default     = {}

  validation {
    condition = alltrue([
      for endpoint_key, resource_id in var.private_endpoint_imports :
      resource_id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[var.private_endpoint[endpoint_key].resource_group_key].name, "")}/providers/Microsoft.Network/privateEndpoints/${try(var.private_endpoint[endpoint_key].name, "")}"
    ])
    error_message = "Each private_endpoint_imports entry must match its endpoint key, name, resource group and subscription_id."
  }
}

variable "enable_storage_account" {
  type        = bool
  description = "Whether Terraform manages and imports the existing storage accounts."
  default     = false
}

variable "storage_account" {
  type = map(object({
    name                              = string
    resource_group_key                = string
    location                          = optional(string)
    account_kind                      = optional(string, "StorageV2")
    account_tier                      = string
    account_replication_type          = string
    access_tier                       = string
    allow_nested_items_to_be_public   = bool
    cross_tenant_replication_enabled  = optional(bool, false)
    default_to_oauth_authentication   = bool
    https_traffic_only_enabled        = optional(bool, true)
    infrastructure_encryption_enabled = bool
    is_hns_enabled                    = optional(bool, false)
    large_file_share_enabled          = optional(bool)
    min_tls_version                   = optional(string, "TLS1_2")
    public_network_access_enabled     = bool
    sftp_enabled                      = optional(bool, false)
    shared_access_key_enabled         = optional(bool, true)
    blob_properties = optional(object({
      container_delete_retention_policy = object({ days = optional(number) })
      delete_retention_policy           = object({ days = optional(number) })
    }))
    network_rules = object({
      bypass                     = set(string)
      default_action             = string
      ip_rules                   = optional(set(string), [])
      virtual_network_subnet_ids = optional(set(string), [])
      private_link_access = optional(list(object({
        endpoint_resource_id = string
        endpoint_tenant_id   = optional(string)
      })), [])
    })
    tags = optional(map(string), {})
  }))
  description = "Existing storage accounts to adopt directly with AzureRM. infrastructure_encryption_enabled forces replacement, so it must match the export."
  default     = {}

  validation {
    condition = alltrue([
      for account in values(var.storage_account) :
      contains(keys(var.resource_group), account.resource_group_key) && (!var.enable_storage_account || var.enable_resource_group)
    ])
    error_message = "Each storage account must reference a managed resource group, enabled when account adoption is enabled."
  }
}

variable "storage_account_existing" {
  type = map(object({
    name               = string
    resource_group_key = string
  }))
  description = "Storage accounts read with a data source instead of managed, because policy denies writes to them."
  default     = {}

  validation {
    condition     = alltrue([for account in values(var.storage_account_existing) : contains(keys(var.resource_group), account.resource_group_key)])
    error_message = "Each existing storage account must reference a resource_group key."
  }
}

variable "storage_account_imports" {
  type        = map(string)
  description = "Existing storage account IDs, keyed by the matching storage_account instance."
  default     = {}

  validation {
    condition = alltrue([
      for account_key, resource_id in var.storage_account_imports :
      resource_id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[var.storage_account[account_key].resource_group_key].name, "")}/providers/Microsoft.Storage/storageAccounts/${try(var.storage_account[account_key].name, "")}"
    ])
    error_message = "Each storage_account_imports entry must match its account key, name, resource group and subscription_id."
  }
}

variable "enable_virtual_network" {
  type        = bool
  description = "Whether Terraform manages and imports the existing virtual networks and their subnets."
  default     = false
}

variable "virtual_network" {
  type = map(object({
    name               = string
    resource_group_key = string
    location           = optional(string)
    address_space      = set(string)
    dns_servers = optional(object({
      dns_servers = list(string)
    }))
    ddos_protection_plan = optional(object({
      id     = string
      enable = bool
    }))
    enable_vm_protection    = optional(bool, false)
    flow_timeout_in_minutes = optional(number)
    encryption = optional(object({
      enabled     = bool
      enforcement = string
    }))
    subnets = optional(map(object({
      name                                          = string
      address_prefixes                              = list(string)
      private_endpoint_network_policies             = optional(string, "Enabled")
      private_link_service_network_policies_enabled = optional(bool, true)
      default_outbound_access_enabled               = optional(bool, false)
      nat_gateway = optional(object({
        id = string
      }))
      network_security_group = optional(object({
        id = string
      }))
      route_table = optional(object({
        id = string
      }))
      service_endpoint_policies = optional(map(object({
        id = string
      })))
      service_endpoints_with_location = optional(list(object({
        service   = string
        locations = optional(list(string), ["*"])
      })))
      delegations = optional(list(object({
        name = string
        service_delegation = object({
          name    = string
          actions = optional(list(string), [])
        })
      })), [])
    })), {})
    tags = optional(map(string), {})
  }))
  description = "Existing VNets/subnets; delegation actions are retained as inventory, not forwarded."
  default     = {}

  validation {
    condition = alltrue([
      for vnet in values(var.virtual_network) :
      contains(keys(var.resource_group), vnet.resource_group_key) && (!var.enable_virtual_network || var.enable_resource_group)
    ])
    error_message = "Each VNet must reference a managed resource group, enabled when network adoption is enabled."
  }
}

variable "virtual_network_imports" {
  type        = map(string)
  description = "Existing VNet IDs, keyed by the matching virtual_network instance."
  default     = {}

  validation {
    condition = alltrue([
      for vnet_key, resource_id in var.virtual_network_imports :
      resource_id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[var.virtual_network[vnet_key].resource_group_key].name, "")}/providers/Microsoft.Network/virtualNetworks/${try(var.virtual_network[vnet_key].name, "")}"
    ])
    error_message = "Each virtual_network_imports entry must match its VNet key, name, resource group and subscription_id."
  }
}

variable "virtual_network_subnet_imports" {
  type = map(object({
    vnet_key   = string
    subnet_key = string
    id         = string
  }))
  description = "Existing bare subnet IDs and their owning VNet/subnet keys; the import block appends the API version."
  default     = {}

  validation {
    condition = alltrue([
      for subnet in values(var.virtual_network_subnet_imports) :
      subnet.id == "/subscriptions/${var.subscription_id}/resourceGroups/${try(var.resource_group[var.virtual_network[subnet.vnet_key].resource_group_key].name, "")}/providers/Microsoft.Network/virtualNetworks/${try(var.virtual_network[subnet.vnet_key].name, "")}/subnets/${try(var.virtual_network[subnet.vnet_key].subnets[subnet.subnet_key].name, "")}"
    ])
    error_message = "Each subnet import must match its VNet/subnet keys, names, resource group and subscription_id."
  }
}
