# tf-deploy-shared-services

Deploys the App Gateway + WAF footprint for the NonProd Shared Services subscription.

`nonprod.tfvars` ships with `frontend_ports` / `http_listeners` /
`backend_address_pools` / `backend_http_settings` / `request_routing_rules`
empty — populate them once the backend targets are known.
