terraform {
  required_version = ">= 1.9, < 2.0"

  required_providers {
    # tf-wrapper-avm-application-gateway-waf-policy requires azurerm ~> 4.2.
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 4.2, < 5.0"
    }
  }

  # No cloud/backend block here on purpose — CI (shared-services-remote-test.yml)
  # generates one at run time and owns the TFC workspace. For local runs, add
  # your own backend or `cloud` block (or pass -backend-config) before init.
}

provider "azurerm" {
  features {}
  # Storage accounts disable shared keys, so data-plane calls must use the run identity's AAD token.
  storage_use_azuread = true
}
