# =====================================================================
# 1. Shared infrastructure variables
# =====================================================================

variable "environment" {
  type        = string
  description = "Deployment environment label (e.g., nonprod, prod)."
}

variable "tags" {
  type        = map(string)
  description = "Baseline tags applied to all resources. Merged with per-instance tags."
  default     = {}
}

# =====================================================================
# 2. Feature flags — one per wrapper. Default false: environments
#    explicitly opt in via tfvars.
# =====================================================================

variable "enable_resource_group" {
  type    = bool
  default = false
}

variable "enable_virtual_network" {
  type    = bool
  default = false
}

variable "enable_waf_policy" {
  type    = bool
  default = false
}

variable "enable_application_gateway" {
  type    = bool
  default = false
}

# =====================================================================
# 3. Per-wrapper config maps — one map(object) per wrapper, keyed by
#    the instance identifier. <producer>_key fields are the
#    cross-resource binding glue added on top of each wrapper's own
#    variables.
# =====================================================================

variable "resource_group" {
  type = map(object({
    name       = string
    location   = string
    managed_by = optional(string)
    lock = optional(object({
      kind = string
      name = optional(string)
    }))
    tags = optional(map(string), {})
  }))
  description = "Resource groups to deploy, keyed by role. Required when enable_resource_group = true."
  default     = {}
}

variable "virtual_network" {
  type = map(object({
    name               = string
    resource_group_key = string           # references a key in var.resource_group
    location           = optional(string) # falls back to the RG's location
    address_space      = set(string)
    dns_servers        = optional(set(string))
    subnets = optional(map(object({
      name           = optional(string) # defaults to the subnet's map key
      address_prefix = optional(string)
    })), {})
    tags = optional(map(string), {})
  }))
  description = "Virtual networks to deploy, keyed by instance role. Required when enable_virtual_network = true."
  default     = {}
}

variable "waf_policy" {
  type = map(object({
    name               = string
    resource_group_key = string           # references a key in var.resource_group
    location           = optional(string) # falls back to the RG's location
    mode               = optional(string, "Detection")
    managed_rule_set = map(object({
      type    = optional(string)
      version = string
    }))
    tags = optional(map(string), {})
  }))
  description = "WAF policies to deploy, keyed by instance role. Required when enable_waf_policy = true."
  default     = {}
}

variable "application_gateway" {
  type = map(object({
    name               = string
    resource_group_key = string           # references a key in var.resource_group
    location           = optional(string) # falls back to the RG's location
    vnet_key           = string           # references a key in var.virtual_network
    subnet_key         = string           # references a subnet key on that vnet instance
    waf_policy_key     = optional(string) # references a key in var.waf_policy

    sku_name     = optional(string, "WAF_v2")
    sku_tier     = optional(string, "WAF_v2")
    sku_capacity = optional(number, 2)
    zones        = optional(set(string), ["1", "2", "3"])

    # Private-only frontend. No public IP is created or attached — see
    # application_gateway.tf.
    private_ip_address            = optional(string) # required if private_ip_address_allocation = "Static"
    private_ip_address_allocation = optional(string, "Dynamic")

    # App-specific routing config — left empty by default. Populate per
    # environment once the app team's backend targets are known.
    frontend_ports = optional(map(object({
      name = string
      port = number
    })), {})
    http_listeners = optional(map(object({
      name                           = string
      frontend_port_name             = string
      frontend_ip_configuration_name = optional(string) # defaults to the private frontend IP config
      host_name                      = optional(string)
      host_names                     = optional(list(string))
    })), {})
    backend_address_pools = optional(map(object({
      name         = string
      fqdns        = optional(set(string))
      ip_addresses = optional(set(string))
    })), {})
    backend_http_settings = optional(map(object({
      name                  = string
      port                  = number
      protocol              = string
      cookie_based_affinity = optional(string, "Disabled")
      probe_name            = optional(string)
    })), {})
    request_routing_rules = optional(map(object({
      name                       = string
      rule_type                  = string
      priority                   = number
      http_listener_name         = string
      backend_address_pool_name  = optional(string)
      backend_http_settings_name = optional(string)
    })), {})

    tags = optional(map(string), {})
  }))
  description = "Application Gateways to deploy, keyed by instance role. Required when enable_application_gateway = true."
  default     = {}
}
