# Shared Services NonProd subscription: 0fdc6acd-d006-4051-af9c-df8adb16bd0a
# Set this as ARM_SUBSCRIPTION_ID / vars.AZURE_SUBSCRIPTION_ID on whatever
# runs this tfvars file — see README.md.

# ── Shared ─────────────────────────────────────────────────────────────
environment = "nonprod"

tags = {
  owner       = "platform-team"
  cost-center = "shared-services"
}

# ── Feature flags ──────────────────────────────────────────────────────
enable_resource_group      = true
enable_virtual_network     = true
enable_waf_policy          = true
enable_application_gateway = true

# ── Module config (maps keyed by instance role) ─────────────────────────

resource_group = {
  "shared-services" = {
    name     = "rg-appgw-sharedsvc-np"
    location = "canadacentral"
  }
}

# Microsoft-recommended sizing for an App Gateway v2 subnet: the whole /24
# is dedicated to the gateway (no other resources share it), matching the
# app team's request to use the entire VNet as the App Gateway subnet.
virtual_network = {
  "shared-services" = {
    name               = "vnet-appgw-sharedsvc-np"
    resource_group_key = "shared-services"
    address_space      = ["10.195.134.0/24"]
    dns_servers        = ["10.195.1.4"]
    subnets = {
      "appgw" = {
        name           = "snet-appgw-sharedsvc-np"
        address_prefix = "10.195.134.0/24"
      }
    }
  }
}

# Baseline managed rule sets: OWASP CRS + Bot Manager. mode = "Detection" per
# the app team's request — logs/scores traffic without blocking. Trips the
# wrapper's waf_mode_is_prevention advisory check (a warning, not a failure);
# switch to "Prevention" once the policy has been tuned against real traffic.
waf_policy = {
  "appgw" = {
    name               = "waf-appgw-sharedsvc-np"
    resource_group_key = "shared-services"
    mode               = "Detection"
    managed_rule_set = {
      owasp = {
        type    = "OWASP"
        version = "3.2"
      }
      bot_manager = {
        type    = "Microsoft_BotManagerRuleSet"
        version = "1.0"
      }
    }
  }
}

# Private listener only — no public IP. sku WAF_v2.
# frontend_ports / http_listeners / backend_address_pools /
# backend_http_settings / request_routing_rules are intentionally left empty:
# populate them once the app team's real backend targets are known, e.g.:
#
#   frontend_ports = {
#     port_443 = { name = "port-443", port = 443 }
#   }
#   http_listeners = {
#     listener_https = { name = "listener-https", frontend_port_name = "port-443" }
#   }
#   backend_address_pools = {
#     pool_default = { name = "pool-default", fqdns = ["app.internal.example.com"] }
#   }
#   backend_http_settings = {
#     http_default = { name = "http-default", port = 443, protocol = "Https" }
#   }
#   request_routing_rules = {
#     rule_basic = {
#       name = "rule-basic", rule_type = "Basic", priority = 100
#       http_listener_name = "listener-https"
#       backend_address_pool_name  = "pool-default"
#       backend_http_settings_name = "http-default"
#     }
#   }
application_gateway = {
  "appgw" = {
    name               = "agw-sharedsvc-np"
    resource_group_key = "shared-services"
    vnet_key           = "shared-services"
    subnet_key         = "appgw"
    waf_policy_key     = "appgw"
    sku_name           = "WAF_v2"
    sku_tier           = "WAF_v2"
  }
}
