# Outputs are maps keyed by the instance identifier so callers can look up
# any specific instance. Empty maps when the wrapper's enable_* flag is false.

output "resource_group_ids" {
  description = "Resource IDs of every deployed resource group, keyed by instance identifier."
  value       = { for k, m in module.resource_group : k => m.resource_id }
}

output "resource_group_names" {
  description = "Names of every deployed resource group, keyed by instance identifier."
  value       = { for k, m in module.resource_group : k => m.name }
}

output "virtual_network_ids" {
  description = "Resource IDs of every deployed virtual network, keyed by instance identifier."
  value       = { for k, m in module.virtual_network : k => m.resource_id }
}

output "virtual_network_subnets" {
  description = "Subnet maps of every deployed virtual network, keyed by instance identifier."
  value       = { for k, m in module.virtual_network : k => m.subnets }
}

output "waf_policy_ids" {
  description = "Resource IDs of every deployed WAF policy, keyed by instance identifier."
  value       = { for k, m in module.waf_policy : k => m.resource_id }
}

output "application_gateway_ids" {
  description = "Resource IDs of every deployed Application Gateway, keyed by instance identifier."
  value       = { for k, m in module.application_gateway : k => m.resource_id }
}

output "application_gateway_names" {
  description = "Names of every deployed Application Gateway, keyed by instance identifier."
  value       = { for k, m in module.application_gateway : k => m.application_gateway_name }
}
