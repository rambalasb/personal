# waf_policy.tf
# Dependencies: resource_group (resource_group_name, picked via resource_group_key).
#
# Baseline managed rule sets: OWASP CRS (the standard Core Rule Set) plus the
# Bot Manager rule set, per the app team's request. mode defaults to
# "Detection" here — logs and scores traffic without blocking it. This trips
# the wrapper's own `waf_mode_is_prevention` advisory check (a warning, not a
# failure): expected while the policy is being tuned. Switch mode to
# "Prevention" once false positives have been triaged.

module "waf_policy" {
  for_each = var.enable_waf_policy ? var.waf_policy : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-application-gateway-waf-policy/azurerm"
  version = "0.1.0"

  name                = each.value.name
  resource_group_name = module.resource_group[each.value.resource_group_key].name
  location            = coalesce(each.value.location, module.resource_group[each.value.resource_group_key].location)

  managed_rules = {
    managed_rule_set = each.value.managed_rule_set
  }

  policy_settings = {
    mode = each.value.mode
  }

  enable_telemetry = false
  tags             = merge(local.common_tags, each.value.tags)
}
