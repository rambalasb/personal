# virtual_network.tf
# Dependencies: resource_group (parent_id = RG resource_id, picked via resource_group_key).

module "virtual_network" {
  for_each = var.enable_virtual_network ? var.virtual_network : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-virtual-network/azurerm"
  version = "0.1.0"

  name          = each.value.name
  parent_id     = module.resource_group[each.value.resource_group_key].resource_id
  location      = coalesce(each.value.location, module.resource_group[each.value.resource_group_key].location)
  address_space = each.value.address_space
  dns_servers   = each.value.dns_servers == null ? null : { dns_servers = tolist(each.value.dns_servers) }
  subnets = {
    for k, s in each.value.subnets : k => merge(s, { name = coalesce(s.name, k) })
  }
  tags = merge(local.common_tags, each.value.tags)
}
