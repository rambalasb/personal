# Deployment order — Terraform infers this automatically from the per-instance
# module.<producer>[each.value.<producer>_key] references in each consumer file.
#   1. resource_group        (no dependencies)
#   2. virtual_network       (depends on: resource_group)
#   3. waf_policy             (depends on: resource_group)
#   4. application_gateway   (depends on: resource_group, virtual_network, waf_policy)

locals {
  common_tags = merge(var.tags, {
    environment = var.environment
    managed-by  = "terraform"
    solution    = "tf-deploy-shared-services"
  })
}
