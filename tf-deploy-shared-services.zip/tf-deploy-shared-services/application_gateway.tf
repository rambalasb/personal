# application_gateway.tf
# Dependencies: resource_group, virtual_network (subnet_id), waf_policy.
#
# Private listener only: public_ip_address_configuration.create_public_ip_enabled
# is forced false and no public frontend IP config is set, so the module never
# creates or attaches a public IP. frontend_ip_configuration_private supplies
# the only frontend, on the App Gateway's own subnet.
#
# http_listeners / backend_address_pools / backend_http_settings /
# request_routing_rules / frontend_ports come straight from each instance's
# tfvars and are empty by default — the app team populates these once the
# real backend targets are known. An instance with none of them defined plans
# fine but will fail to apply (Azure requires at least one listener and rule
# on a real gateway).

module "application_gateway" {
  for_each = var.enable_application_gateway ? var.application_gateway : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-application-gateway/azurerm"
  version = "0.1.0"

  name                = each.value.name
  resource_group_name = module.resource_group[each.value.resource_group_key].name
  location            = coalesce(each.value.location, module.resource_group[each.value.resource_group_key].location)

  gateway_ip_configuration = {
    name      = "appgw-ipconfig"
    subnet_id = module.virtual_network[each.value.vnet_key].subnets[each.value.subnet_key].resource_id
  }

  public_ip_address_configuration = {
    create_public_ip_enabled = false
  }

  frontend_ip_configuration_private = {
    name                          = "${each.value.name}-feip-private"
    private_ip_address            = each.value.private_ip_address
    private_ip_address_allocation = each.value.private_ip_address_allocation
  }

  frontend_ports = each.value.frontend_ports
  http_listeners = {
    for k, l in each.value.http_listeners : k => merge(l, {
      frontend_ip_configuration_name = coalesce(l.frontend_ip_configuration_name, "${each.value.name}-feip-private")
    })
  }
  backend_address_pools = each.value.backend_address_pools
  backend_http_settings = each.value.backend_http_settings
  request_routing_rules = each.value.request_routing_rules

  sku = {
    name     = each.value.sku_name
    tier     = each.value.sku_tier
    capacity = each.value.sku_capacity
  }
  zones = each.value.zones

  app_gateway_waf_policy_resource_id = (
    each.value.waf_policy_key == null ? null : module.waf_policy[each.value.waf_policy_key].resource_id
  )

  enable_telemetry = false
  tags             = merge(local.common_tags, each.value.tags)
}
