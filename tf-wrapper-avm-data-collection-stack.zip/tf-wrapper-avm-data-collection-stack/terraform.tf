terraform {
  required_version = ">= 1.12, < 2.0"
}
