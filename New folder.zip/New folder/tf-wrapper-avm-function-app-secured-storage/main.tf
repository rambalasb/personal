module "function_app_secured_storage" {
  source  = "Azure/avm-ptn-function-app-storage-private-endpoints/azurerm"
  version = "0.3.0"

  # Required
  name                = var.name
  resource_group_name = var.resource_group_name
  location            = var.location
  os_type             = var.os_type

  # Feature flags — control which components this pattern creates
  create_service_plan                  = var.create_service_plan
  create_secure_storage_account        = var.create_secure_storage_account
  use_external_managed_dns_for_storage = var.use_external_managed_dns_for_storage

  # Component configuration objects
  service_plan      = var.service_plan
  storage_account   = var.storage_account
  private_dns_zones = var.private_dns_zones

  # Bring-your-own component references (used when the matching flag is false)
  service_plan_resource_id                  = var.service_plan_resource_id
  storage_account_name                      = var.storage_account_name
  storage_account_access_key                = var.storage_account_access_key
  storage_account_primary_connection_string = var.storage_account_primary_connection_string
  storage_key_vault_secret_id               = var.storage_key_vault_secret_id
  storage_contentshare_name                 = var.storage_contentshare_name
  storage_shares_to_mount                   = var.storage_shares_to_mount

  # Function App runtime & site configuration
  app_settings                = var.app_settings
  site_config                 = var.site_config
  functions_extension_version = var.functions_extension_version
  connection_strings          = var.connection_strings
  auto_heal_setting           = var.auto_heal_setting
  daily_memory_time_quota     = var.daily_memory_time_quota
  content_share_force_disabled = var.content_share_force_disabled
  builtin_logging_enabled     = var.builtin_logging_enabled
  zip_deploy_file             = var.zip_deploy_file
  app_service_active_slot     = var.app_service_active_slot
  deployment_slots            = var.deployment_slots
  deployment_slots_inherit_lock = var.deployment_slots_inherit_lock

  # Authentication & client certificates
  auth_settings                      = var.auth_settings
  auth_settings_v2                   = var.auth_settings_v2
  client_affinity_enabled            = var.client_affinity_enabled
  client_certificate_enabled         = var.client_certificate_enabled
  client_certificate_mode            = var.client_certificate_mode
  client_certificate_exclusion_paths = var.client_certificate_exclusion_paths
  key_vault_reference_identity_id    = var.key_vault_reference_identity_id

  # Networking & private endpoints
  public_network_access_enabled           = var.public_network_access_enabled
  https_only                              = var.https_only
  virtual_network_subnet_id               = var.virtual_network_subnet_id
  private_endpoint_subnet_resource_id     = var.private_endpoint_subnet_resource_id
  private_endpoints                       = var.private_endpoints
  private_endpoints_inherit_lock          = var.private_endpoints_inherit_lock
  private_endpoints_manage_dns_zone_group = var.private_endpoints_manage_dns_zone_group
  private_dns_zone_resource_group_name    = var.private_dns_zone_resource_group_name
  private_dns_zone_subscription_id        = var.private_dns_zone_subscription_id
  zone_key_for_link                       = var.zone_key_for_link
  custom_domains                          = var.custom_domains

  # Observability
  enable_application_insights = var.enable_application_insights
  application_insights        = var.application_insights
  diagnostic_settings         = var.diagnostic_settings
  logs                        = var.logs

  # Publishing / deployment auth
  ftp_publish_basic_authentication_enabled       = var.ftp_publish_basic_authentication_enabled
  webdeploy_publish_basic_authentication_enabled = var.webdeploy_publish_basic_authentication_enabled

  # Backup
  backup = var.backup

  # Identity, RBAC, locks
  managed_identities             = var.managed_identities
  role_assignments               = var.role_assignments
  lock                           = var.lock
  all_child_resources_inherit_lock = var.all_child_resources_inherit_lock

  # Tagging & telemetry
  all_child_resources_inherit_tags = var.all_child_resources_inherit_tags
  enable_telemetry                 = var.enable_telemetry
  tags                             = local.module_tags

  # Operation tuning
  timeouts = var.timeouts
}
