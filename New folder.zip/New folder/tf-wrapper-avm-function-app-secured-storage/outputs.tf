output "resource_id" {
  description = "The resource ID of the Function App."
  value       = module.function_app_secured_storage.resource_id
  sensitive   = true
}

output "name" {
  description = "The name of the Function App."
  value       = module.function_app_secured_storage.name
}

output "resource" {
  description = "The full Function App resource output object."
  value       = module.function_app_secured_storage.resource
  sensitive   = true
}

output "service_plan_resource" {
  description = "The App Service Plan resource, if one was created by this module (create_service_plan = true)."
  value       = module.function_app_secured_storage.service_plan_resource
}

output "storage_account_resource" {
  description = "The secure Storage Account resource, if one was created by this module (create_secure_storage_account = true)."
  value       = module.function_app_secured_storage.storage_account_resource
  sensitive   = true
}

output "function_app_private_dns_zone" {
  description = "The private DNS zone resource linked to the Function App, if configured via private_dns_zones and zone_key_for_link."
  value       = module.function_app_secured_storage.function_app_private_dns_zone
}

output "function_app_private_dns_zone_id" {
  description = "The resource ID of the private DNS zone linked to the Function App, if configured."
  value       = module.function_app_secured_storage.function_app_private_dns_zone_id
}
