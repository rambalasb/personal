output "resource_id" {
  value     = module.function_app_secured_storage.resource_id
  sensitive = true
}

output "name" {
  value = module.function_app_secured_storage.name
}
