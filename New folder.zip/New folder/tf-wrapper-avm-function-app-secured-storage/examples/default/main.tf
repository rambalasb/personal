module "function_app_secured_storage" {
  source = "../.."

  name                = "func-avm-${random_string.suffix.result}"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location
  os_type             = "Linux"

  # let the pattern create the plan, storage account, and private DNS zones
  create_service_plan                  = true
  create_secure_storage_account        = true
  use_external_managed_dns_for_storage = false

  service_plan = {
    name     = "asp-func-avm-${random_string.suffix.result}"
    sku_name = "P1v2"
  }

  # storage account name: 3-24 lowercase alphanumerics, globally unique
  storage_account = {
    name = "stfuncavm${random_string.suffix.result}"
    # public access denied; only Azure services and the workload subnets reach the account
    network_rules = {
      bypass                     = ["AzureServices"]
      default_action             = "Deny"
      virtual_network_subnet_ids = [azurerm_subnet.private_endpoints.id, azurerm_subnet.app_service.id]
    }
  }

  # module creates these zones and links them to the VNet for the storage private endpoints
  private_dns_zones = {
    blob = {
      domain_name         = "privatelink.blob.core.windows.net"
      resource_group_name = azurerm_resource_group.this.name
      virtual_network_links = {
        vnet = {
          vnetlinkname = "privatelink-blob-link"
          vnetid       = azurerm_virtual_network.this.id
        }
      }
    }
    file = {
      domain_name         = "privatelink.file.core.windows.net"
      resource_group_name = azurerm_resource_group.this.name
      virtual_network_links = {
        vnet = {
          vnetlinkname = "privatelink-file-link"
          vnetid       = azurerm_virtual_network.this.id
        }
      }
    }
    queue = {
      domain_name         = "privatelink.queue.core.windows.net"
      resource_group_name = azurerm_resource_group.this.name
      virtual_network_links = {
        vnet = {
          vnetlinkname = "privatelink-queue-link"
          vnetid       = azurerm_virtual_network.this.id
        }
      }
    }
    table = {
      domain_name         = "privatelink.table.core.windows.net"
      resource_group_name = azurerm_resource_group.this.name
      virtual_network_links = {
        vnet = {
          vnetlinkname = "privatelink-table-link"
          vnetid       = azurerm_virtual_network.this.id
        }
      }
    }
  }

  private_endpoint_subnet_resource_id = azurerm_subnet.private_endpoints.id

  # VNet integration so the app reaches storage over the private endpoints
  virtual_network_subnet_id = azurerm_subnet.app_service.id

  # matches the private-endpoint-secured intent asserted in checks.tf
  public_network_access_enabled = false
  https_only                    = true

  enable_telemetry = false
}
