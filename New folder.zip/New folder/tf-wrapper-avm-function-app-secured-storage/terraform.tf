terraform {
  # AVM avm-ptn-function-app-storage-private-endpoints v0.3.0 requires Terraform ~> 1.10.
  required_version = ">= 1.10, < 2.0"

  required_providers {
    # The pattern module is azapi-based and its nested AVM resource modules (function app,
    # service plan, storage account, private DNS zone) require azurerm. The upstream module
    # pins azurerm to >= 4.21.1, < 5.0, so the wrapper honors that floor.
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 4.21.1, < 5.0"
    }
    azapi = {
      source  = "Azure/azapi"
      version = "~> 2.4"
    }
  }
}
