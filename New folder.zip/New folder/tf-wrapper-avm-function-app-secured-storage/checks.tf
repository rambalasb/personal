# Post-plan/apply advisory checks. These surface as warnings (never block apply) and
# assert compliance / cross-component invariants that the pattern module does not enforce.

# This pattern is "private endpoint-secured storage" — leaving public network access on
# defeats its purpose.
check "public_network_access_disabled" {
  assert {
    condition     = !var.public_network_access_enabled
    error_message = "public_network_access_enabled is true, which contradicts the private-endpoint-secured intent of this pattern. Set public_network_access_enabled = false and reach the Function App via its private endpoint."
  }
}

check "https_only_enforced" {
  assert {
    condition     = var.https_only
    error_message = "The Function App should enforce HTTPS-only traffic. Set https_only = true."
  }
}

check "byo_storage_requires_name" {
  assert {
    condition     = var.create_secure_storage_account || var.storage_account_name != null
    error_message = "When create_secure_storage_account = false you must supply an existing storage account via storage_account_name (and its access key / connection string / key vault secret)."
  }
}

check "byo_service_plan_requires_id" {
  assert {
    condition     = var.create_service_plan || var.service_plan_resource_id != null
    error_message = "When create_service_plan = false you must supply an existing plan via service_plan_resource_id."
  }
}
