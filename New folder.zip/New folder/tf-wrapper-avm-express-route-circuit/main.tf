module "express_route_circuit" {
  source  = "Azure/avm-res-network-expressroutecircuit/azurerm"
  version = "0.3.3"

  # Required
  name                = var.name
  resource_group_name = var.resource_group_name
  location            = var.location
  sku                 = var.sku

  # Connectivity: provider-based vs ExpressRoute Direct
  service_provider_name          = var.service_provider_name
  peering_location               = var.peering_location
  bandwidth_in_mbps              = var.bandwidth_in_mbps
  express_route_port_resource_id = var.express_route_port_resource_id
  bandwidth_in_gbps              = var.bandwidth_in_gbps
  allow_classic_operations       = var.allow_classic_operations
  authorization_key              = var.authorization_key
  enable_telemetry               = var.enable_telemetry
  exr_circuit_tags               = local.module_tags

  # Peerings & authorizations
  peerings                             = var.peerings
  express_route_circuit_authorizations = var.express_route_circuit_authorizations

  # Connections: Global Reach, ER gateway, VNet gateway
  circuit_connections = var.circuit_connections
  er_gw_connections   = var.er_gw_connections
  vnet_gw_connections = var.vnet_gw_connections

  # RBAC, locks, diagnostics
  role_assignments    = var.role_assignments
  lock                = var.lock
  diagnostic_settings = var.diagnostic_settings
}
