# Post-plan/apply advisory checks. These surface as warnings (never block apply) and
# assert cross-configuration invariants that the AVM module does not enforce on its own.

# An ExpressRoute circuit is provisioned via EITHER a service provider OR ExpressRoute
# Direct (an ExpressRoute Port) — never both, never neither.
check "provider_or_erdirect" {
  assert {
    condition     = (var.service_provider_name != null) != (var.express_route_port_resource_id != null)
    error_message = "Provide exactly one provisioning path: a provider-based circuit (service_provider_name) OR an ExpressRoute Direct circuit (express_route_port_resource_id), not both or neither."
  }
}

check "provider_bandwidth_present" {
  assert {
    condition     = var.service_provider_name == null || var.bandwidth_in_mbps != null
    error_message = "A provider-based circuit (service_provider_name set) requires bandwidth_in_mbps."
  }
}

check "erdirect_bandwidth_present" {
  assert {
    condition     = var.express_route_port_resource_id == null || var.bandwidth_in_gbps != null
    error_message = "An ExpressRoute Direct circuit (express_route_port_resource_id set) requires bandwidth_in_gbps."
  }
}
