locals {
  # The AVM module applies circuit tags from `exr_circuit_tags`; its root `tags` variable is
  # unused upstream. We merge both caller-supplied maps (plus org defaults) and feed the
  # result into `exr_circuit_tags` so either input is honored.
  module_tags = merge(
    var.tags == null ? {} : var.tags,
    var.exr_circuit_tags == null ? {} : var.exr_circuit_tags,
    {
      managed-by = "terraform"
      module     = "tf-wrapper-avm-express-route-circuit"
    }
  )
}
