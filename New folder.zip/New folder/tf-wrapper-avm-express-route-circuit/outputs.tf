output "resource_id" {
  description = "The resource ID of the ExpressRoute circuit."
  value       = module.express_route_circuit.resource_id
}

output "name" {
  description = "The resource name of the ExpressRoute circuit."
  value       = module.express_route_circuit.name
}

output "peerings" {
  description = "Map of ExpressRoute Circuit peering configurations created on the circuit."
  value       = module.express_route_circuit.peerings
}

output "authorization_keys" {
  description = "Map of authorization keys for the ExpressRoute circuit, keyed by the input map key."
  value       = module.express_route_circuit.authorization_keys
  sensitive   = true
}

output "authorization_used_status" {
  description = "Map of authorization usage status for each ExpressRoute circuit authorization."
  value       = module.express_route_circuit.authorization_used_status
}

output "express_route_gateway_connections" {
  description = "Map of ExpressRoute gateway connections created from the circuit."
  value       = module.express_route_circuit.express_route_gateway_connections
}

output "virtual_network_gateway_connections" {
  description = "Map of virtual network gateway connections created from the circuit."
  value       = module.express_route_circuit.virtual_network_gateway_connections
}
