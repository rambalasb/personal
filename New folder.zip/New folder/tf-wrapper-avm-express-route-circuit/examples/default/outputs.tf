output "resource_id" {
  value = module.express_route_circuit.resource_id
}

output "name" {
  value = module.express_route_circuit.name
}
