module "express_route_circuit" {
  source = "../.."

  name                = "erc-avm-${random_string.suffix.result}"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location

  sku = {
    tier   = "Standard"
    family = "MeteredData"
  }

  # provider-based circuit
  service_provider_name = "Equinix"
  peering_location      = "Silicon Valley"
  bandwidth_in_mbps     = 50

  enable_telemetry = false
}
