# Post-plan/apply advisory checks. These surface as warnings (never block apply) and
# assert cross-configuration invariants that the AVM module does not enforce on its own.

check "hub_firewall_requires_virtual_hub" {
  assert {
    condition     = var.firewall_sku_name != "AZFW_Hub" || var.firewall_virtual_hub != null
    error_message = "An 'AZFW_Hub' SKU firewall must be deployed into a Virtual WAN hub. Provide firewall_virtual_hub."
  }
}

check "vnet_firewall_requires_ip_configuration" {
  assert {
    condition     = var.firewall_sku_name != "AZFW_VNet" || length(var.ip_configurations) > 0 || (var.firewall_ip_configuration != null && length(var.firewall_ip_configuration) > 0)
    error_message = "An 'AZFW_VNet' SKU firewall must have at least one ip_configurations entry (with a subnet_id)."
  }
}

check "basic_tier_requires_management_ip" {
  assert {
    condition     = var.firewall_sku_tier != "Basic" || var.firewall_sku_name != "AZFW_VNet" || var.firewall_management_ip_configuration != null
    error_message = "The 'Basic' tier on an 'AZFW_VNet' firewall requires a dedicated management IP configuration. Provide firewall_management_ip_configuration (with an AzureFirewallManagementSubnet)."
  }
}

check "zone_redundancy_recommended" {
  assert {
    condition     = length(var.firewall_zones) > 1
    error_message = "For production resilience, deploy the Azure Firewall across more than one availability zone (e.g. firewall_zones = [\"1\", \"2\", \"3\"])."
  }
}
