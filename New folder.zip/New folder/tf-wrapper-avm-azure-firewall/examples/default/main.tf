module "azure_firewall" {
  source = "../.."

  name                = "fw-avm-${random_string.suffix.result}"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location
  firewall_sku_name   = "AZFW_VNet"
  firewall_sku_tier   = "Standard"

  ip_configurations = {
    primary = {
      name                 = "ipconfig1"
      subnet_id            = azurerm_subnet.firewall.id
      public_ip_address_id = azurerm_public_ip.firewall.id
    }
  }

  enable_telemetry = false
}
