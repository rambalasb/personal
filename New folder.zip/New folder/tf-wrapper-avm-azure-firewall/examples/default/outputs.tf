output "resource_id" {
  value = module.azure_firewall.resource_id
}
