output "resource_id" {
  description = "The resource ID of the Azure Firewall."
  value       = module.azure_firewall.resource_id
}

output "resource" {
  description = "The full azurerm_firewall resource output object (id, name, ip_configuration, virtual_hub, etc.)."
  value       = module.azure_firewall.resource
}
