module "azure_firewall" {
  source  = "Azure/avm-res-network-azurefirewall/azurerm"
  version = "0.4.0"

  # Required
  name                = var.name
  resource_group_name = var.resource_group_name
  location            = var.location
  firewall_sku_name   = var.firewall_sku_name
  firewall_sku_tier   = var.firewall_sku_tier

  # Policy, zones & SNAT
  firewall_policy_id         = var.firewall_policy_id
  firewall_zones             = var.firewall_zones
  firewall_private_ip_ranges = var.firewall_private_ip_ranges
  enable_telemetry           = var.enable_telemetry
  tags                       = local.module_tags

  # IP configuration (VNet-based firewalls)
  ip_configurations                    = var.ip_configurations
  firewall_management_ip_configuration = var.firewall_management_ip_configuration
  firewall_ip_configuration            = var.firewall_ip_configuration # deprecated upstream; exposed for completeness

  # Virtual hub (secured-hub firewalls)
  firewall_virtual_hub = var.firewall_virtual_hub

  # RBAC, locks, diagnostics
  role_assignments    = var.role_assignments
  lock                = var.lock
  diagnostic_settings = var.diagnostic_settings

  # azapi operation tuning
  firewall_timeouts = var.firewall_timeouts
}
