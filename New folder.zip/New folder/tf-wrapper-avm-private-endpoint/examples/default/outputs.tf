output "resource_id" {
  value = module.private_endpoint.resource_id
}

output "name" {
  value = module.private_endpoint.name
}
