module "private_endpoint" {
  source = "../.."

  name                           = "pe-avm-${random_string.suffix.result}"
  location                       = azurerm_resource_group.this.location
  resource_group_name            = azurerm_resource_group.this.name
  subnet_resource_id             = azurerm_subnet.this.id
  private_connection_resource_id = azurerm_storage_account.this.id
  subresource_names              = ["blob"]

  enable_telemetry = false
}
