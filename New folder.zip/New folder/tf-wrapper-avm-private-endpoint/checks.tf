# Post-deploy invariant: a private endpoint can apply successfully while its
# connection sits in "Pending" (manual-approval private links) or "Rejected".
# The azurerm_private_endpoint resource does not expose the connection status,
# so we read it through a scoped data source and assert it landed in "Approved".
# This surfaces as a warning — it never blocks or rolls back the apply.

check "private_endpoint_connection_approved" {
  data "azurerm_private_endpoint_connection" "this" {
    name                = module.private_endpoint.name
    resource_group_name = var.resource_group_name
  }

  assert {
    condition = alltrue([
      for connection in data.azurerm_private_endpoint_connection.this.private_service_connection :
      connection.status == "Approved"
    ])
    error_message = "Private endpoint '${module.private_endpoint.name}' has a connection that is not in an 'Approved' state. Manual-approval private links must be approved on the target resource."
  }
}
