###############################################################################
# Required variables
###############################################################################

variable "name" {
  type        = string
  description = "The name of the private endpoint resource."

  validation {
    condition     = length(var.name) >= 1 && length(var.name) <= 80
    error_message = "name must be between 1 and 80 characters."
  }
}

variable "location" {
  type        = string
  description = "Azure region where the private endpoint should be deployed."

  validation {
    condition     = length(var.location) > 0
    error_message = "location must not be empty."
  }
}

variable "resource_group_name" {
  type        = string
  description = "The name of the resource group where the private endpoint will be deployed."

  validation {
    condition     = length(var.resource_group_name) >= 1 && length(var.resource_group_name) <= 90
    error_message = "resource_group_name must be between 1 and 90 characters."
  }
}

variable "subnet_resource_id" {
  type        = string
  description = "Azure resource ID of the Subnet from which Private IP Addresses will be allocated for this Private Endpoint. Changing this forces a new resource to be created."

  validation {
    condition     = can(regex("^/subscriptions/.+/resourceGroups/.+/providers/Microsoft\\.Network/virtualNetworks/.+/subnets/.+$", var.subnet_resource_id))
    error_message = "subnet_resource_id must be a valid subnet resource ID (/subscriptions/.../virtualNetworks/.../subnets/...)."
  }
}

variable "private_connection_resource_id" {
  type        = string
  description = "Resource ID of the Private Link enabled remote resource which this Private Endpoint should be connected to."

  validation {
    condition     = can(regex("^/subscriptions/.+/resourceGroups/.+/providers/.+$", var.private_connection_resource_id))
    error_message = "private_connection_resource_id must be a valid Azure resource ID."
  }
}

###############################################################################
# Optional variables
###############################################################################

variable "subresource_names" {
  type        = list(string)
  description = "List of subresource names which the Private Endpoint is able to connect to (e.g. [\"blob\"], [\"vault\"], [\"sqlServer\"]). Set null to omit."
  default     = null
}

variable "private_service_connection_name" {
  type        = string
  description = "Name of the Private Service Connection. If null, the AVM module derives a default name."
  default     = null
}

variable "network_interface_name" {
  type        = string
  description = "Custom name of the network interface attached to the private endpoint. Changing this forces a new resource to be created. If null, Azure generates a default name."
  default     = null
}

variable "private_dns_zone_group_name" {
  type        = string
  description = "Name of the Private DNS Zone Group. If null, the AVM module derives a default name when private_dns_zone_resource_ids is set."
  default     = null
}

variable "private_dns_zone_resource_ids" {
  type        = list(string)
  description = "List of Private DNS Zone resource IDs to include within the private_dns_zone_group. Leave empty to skip DNS zone group creation."
  default     = []
}

variable "application_security_group_association_ids" {
  type        = set(string)
  description = "Set of Application Security Group resource IDs to associate with the private endpoint's network interface."
  default     = []
}

variable "ip_configurations" {
  type = map(object({
    name               = string
    private_ip_address = string
    subresource_name   = string
    member_name        = optional(string, "default")
  }))
  description = <<-DESCRIPTION
  Map of IP configuration blocks for assigning static private IP addresses to the endpoint. Each entry supports:
  - `name`               - (Required) Name of the IP configuration.
  - `private_ip_address` - (Required) The static private IP address to assign.
  - `subresource_name`   - (Required) The subresource (group ID) this IP configuration targets.
  - `member_name`        - (Optional) Member name within the subresource. Defaults to "default".
  DESCRIPTION
  default     = {}
}

variable "lock" {
  type = object({
    kind = string
    name = optional(string, null)
  })
  description = <<-DESCRIPTION
  Resource lock to apply to the private endpoint.
  - `kind` - (Required) The lock level. Possible values: `CanNotDelete`, `ReadOnly`.
  - `name` - (Optional) The name of the lock. If null, a name is generated.
  Set the whole object to null to apply no lock.
  DESCRIPTION
  default     = null

  validation {
    condition     = var.lock == null ? true : contains(["CanNotDelete", "ReadOnly"], var.lock.kind)
    error_message = "lock.kind must be either 'CanNotDelete' or 'ReadOnly'."
  }
}

variable "role_assignments" {
  type = map(object({
    role_definition_id_or_name             = string
    principal_id                           = string
    description                            = optional(string, null)
    skip_service_principal_aad_check       = optional(bool, false)
    condition                              = optional(string, null)
    condition_version                      = optional(string, null)
    delegated_managed_identity_resource_id = optional(string, null)
    principal_type                         = optional(string, null)
  }))
  description = <<-DESCRIPTION
  Map of role assignments to create on the private endpoint. Each entry supports:
  - `role_definition_id_or_name`             - (Required) Built-in role name or a role definition resource ID.
  - `principal_id`                           - (Required) Object ID of the principal (user, group, or service principal).
  - `description`                            - (Optional) Description of the role assignment.
  - `skip_service_principal_aad_check`       - (Optional) Skip the AAD check for service principals. Defaults to false.
  - `condition`                              - (Optional) ABAC condition for the assignment.
  - `condition_version`                      - (Optional) Version of the condition syntax ("2.0").
  - `delegated_managed_identity_resource_id` - (Optional) Resource ID of the delegated managed identity.
  - `principal_type`                         - (Optional) The principal type: User, Group, or ServicePrincipal.
  DESCRIPTION
  default     = {}
}

variable "enable_telemetry" {
  type        = bool
  description = "Controls whether telemetry is collected by the underlying AVM module. Set false to opt out."
  default     = true
}

variable "tags" {
  type        = map(string)
  description = "A map of tags to apply to the private endpoint. Merged with module-managed tags in locals."
  default     = {}
}
