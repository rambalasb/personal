locals {
  module_tags = merge(
    var.tags,
    {
      managed-by = "terraform"
      module     = "tf-wrapper-avm-private-endpoint"
    }
  )
}
