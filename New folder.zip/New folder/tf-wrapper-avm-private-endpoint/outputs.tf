output "resource_id" {
  description = "The resource ID of the private endpoint."
  value       = module.private_endpoint.resource_id
}

output "name" {
  description = "The name of the private endpoint."
  value       = module.private_endpoint.name
}

output "resource" {
  description = "The full private endpoint resource object, including computed attributes such as the assigned private IP addresses and network interface."
  value       = module.private_endpoint.resource
}
