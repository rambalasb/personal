module "private_endpoint" {
  source  = "Azure/avm-res-network-privateendpoint/azurerm"
  version = "0.2.0" # exact pin — see https://github.com/Azure/terraform-azurerm-avm-res-network-privateendpoint/releases

  # Required
  name                           = var.name
  location                       = var.location
  resource_group_name            = var.resource_group_name
  subnet_resource_id             = var.subnet_resource_id
  private_connection_resource_id = var.private_connection_resource_id

  # Optional — pass-through (null/empty lets AVM apply its own defaults)
  subresource_names                          = var.subresource_names
  private_service_connection_name            = var.private_service_connection_name
  network_interface_name                     = var.network_interface_name
  private_dns_zone_group_name                = var.private_dns_zone_group_name
  private_dns_zone_resource_ids              = var.private_dns_zone_resource_ids
  application_security_group_association_ids = var.application_security_group_association_ids
  ip_configurations                          = var.ip_configurations
  lock                                       = var.lock
  role_assignments                           = var.role_assignments
  enable_telemetry                           = var.enable_telemetry
  tags                                       = local.module_tags
}
