terraform {
  required_version = ">= 1.9, < 2.0"

  required_providers {
    # AVM avm-res-network-ipgroup v0.2.0 requires azurerm ~> 4.0, so this constraint is
    # tighter than the >= 3.116 baseline used by some sibling wrappers.
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 4.0, < 5.0"
    }
    # Required because the ip_addresses variable validation calls the provider-defined
    # functions provider::assert::cidrv4() / provider::assert::ipv4(). Without this
    # provider declared, the module fails to initialize.
    assert = {
      source  = "hashicorp/assert"
      version = "~> 0.15.0"
    }
  }
}
