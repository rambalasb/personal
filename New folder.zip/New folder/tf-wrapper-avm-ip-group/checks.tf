# Post-plan/apply advisory check. Surfaces as a warning (never blocks apply). The AVM
# module already validates the format of each ip_addresses entry, so this only guards
# against the most common mistake: an empty group.

check "ip_group_not_empty" {
  assert {
    condition     = length(var.ip_addresses) > 0
    error_message = "The IP Group has no entries. Add at least one IP address, range, or CIDR block to ip_addresses, otherwise referencing firewall/NSG rules have nothing to match."
  }
}
