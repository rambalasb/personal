module "ip_group" {
  source  = "Azure/avm-res-network-ipgroup/azurerm"
  version = "0.2.0"

  # Required
  name                = var.name
  resource_group_name = var.resource_group_name
  location            = var.location
  ip_addresses        = var.ip_addresses

  # RBAC & locks
  role_assignments = var.role_assignments
  lock             = var.lock

  # Telemetry & tagging
  enable_telemetry = var.enable_telemetry
  tags             = local.module_tags
}
