output "resource_id" {
  description = "The resource ID of the created IP Group."
  value       = module.ip_group.resource_id
}

output "name" {
  description = "The name of the IP Group."
  value       = module.ip_group.name
}

output "ip_address" {
  description = "The list of IP addresses, ranges, and CIDR blocks contained in the IP Group."
  value       = module.ip_group.ip_address
}
