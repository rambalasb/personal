output "resource_id" {
  value = module.ip_group.resource_id
}

output "name" {
  value = module.ip_group.name
}

output "ip_address" {
  value = module.ip_group.ip_address
}
