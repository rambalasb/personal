module "ip_group" {
  source = "../.."

  name                = "ipg-avm-${random_string.suffix.result}"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location

  ip_addresses = [
    "10.0.0.0/24",
    "10.1.0.0/24",
  ]

  enable_telemetry = false
}
