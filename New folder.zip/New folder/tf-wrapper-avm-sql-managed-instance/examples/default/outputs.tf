output "resource_id" {
  value = module.sql_managed_instance.resource_id
}
