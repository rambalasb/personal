module "sql_managed_instance" {
  source = "../.."

  name                = "sqlmi-avm-${random_string.suffix.result}"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location

  administrator_login          = "sqladmin"
  administrator_login_password = random_password.this.result

  license_type       = "BasePrice"
  sku_name           = "GP_Gen5"
  vcores             = 4
  storage_size_in_gb = 32

  # delegated subnet with NSG + route table associations (see supporting-resources.tf)
  subnet_id = azurerm_subnet.this.id

  enable_telemetry = false

  depends_on = [
    azurerm_subnet_network_security_group_association.this,
    azurerm_subnet_route_table_association.this,
  ]
}
