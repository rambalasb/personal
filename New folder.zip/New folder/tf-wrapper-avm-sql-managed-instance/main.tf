module "sql_managed_instance" {
  source  = "Azure/avm-res-sql-managedinstance/azurerm"
  version = "0.3.1"

  # Required
  name                         = var.name
  resource_group_name          = var.resource_group_name
  location                     = var.location
  administrator_login          = var.administrator_login
  administrator_login_password = var.administrator_login_password
  license_type                 = var.license_type
  sku_name                     = var.sku_name
  vcores                       = var.vcores
  storage_size_in_gb           = var.storage_size_in_gb
  subnet_id                    = var.subnet_id

  # Engine format, pricing & service tier
  database_format       = var.database_format
  pricing_model         = var.pricing_model
  is_general_purpose_v2 = var.is_general_purpose_v2
  collation             = var.collation
  timezone_id           = var.timezone_id
  enable_telemetry      = var.enable_telemetry
  tags                  = local.module_tags

  # Compute & storage sizing
  memory_size_in_gb    = var.memory_size_in_gb
  storage_iops         = var.storage_iops
  storage_account_type = var.storage_account_type

  # Networking
  proxy_override                          = var.proxy_override
  public_data_endpoint_enabled            = var.public_data_endpoint_enabled
  minimum_tls_version                     = var.minimum_tls_version
  dns_zone_partner_id                     = var.dns_zone_partner_id
  private_endpoints                       = var.private_endpoints
  private_endpoints_manage_dns_zone_group = var.private_endpoints_manage_dns_zone_group

  # Security: AAD admin, threat protection, TDE, alerts, vulnerability assessment
  active_directory_administrator     = var.active_directory_administrator
  advanced_threat_protection_enabled = var.advanced_threat_protection_enabled
  service_principal_enabled          = var.service_principal_enabled
  transparent_data_encryption        = var.transparent_data_encryption
  security_alert_policy              = var.security_alert_policy
  vulnerability_assessment           = var.vulnerability_assessment
  storage_account_resource_id        = var.storage_account_resource_id

  # Availability & maintenance
  zone_redundant_enabled         = var.zone_redundant_enabled
  maintenance_configuration_name = var.maintenance_configuration_name

  # Databases & failover group
  databases      = var.databases
  failover_group = var.failover_group

  # Identity, RBAC, locks, diagnostics
  managed_identities  = var.managed_identities
  role_assignments    = var.role_assignments
  lock                = var.lock
  diagnostic_settings = var.diagnostic_settings

  # azapi operation tuning
  retry    = var.retry
  timeout  = var.timeout
  timeouts = var.timeouts
}
