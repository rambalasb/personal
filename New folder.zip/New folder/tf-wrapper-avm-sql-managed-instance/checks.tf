# Post-plan/apply advisory checks. These surface as warnings (never block apply) and
# assert compliance / cross-configuration invariants that the AVM module does not enforce.

check "gpv2_not_zone_redundant" {
  assert {
    condition     = !var.is_general_purpose_v2 || !var.zone_redundant_enabled
    error_message = "Zone redundancy is not available for the Next-gen General Purpose (GPv2) tier. Set zone_redundant_enabled = false when is_general_purpose_v2 = true."
  }
}

check "public_endpoint_disabled_with_private_endpoints" {
  assert {
    condition     = length(var.private_endpoints) == 0 || !coalesce(var.public_data_endpoint_enabled, false)
    error_message = "When private endpoints are configured, the public data endpoint should be disabled. Set public_data_endpoint_enabled = false."
  }
}

check "tls_minimum_1_2" {
  assert {
    condition     = var.minimum_tls_version == "1.2"
    error_message = "minimum_tls_version should be '1.2' to enforce modern TLS. Lower versions (1.0/1.1) are deprecated."
  }
}
