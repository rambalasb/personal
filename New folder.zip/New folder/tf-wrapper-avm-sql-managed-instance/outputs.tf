output "resource_id" {
  description = "The resource ID of the SQL Managed Instance."
  value       = module.sql_managed_instance.resource_id
}

output "resource" {
  description = "The full azurerm_mssql_managed_instance resource output object."
  value       = module.sql_managed_instance.resource
}

output "identity" {
  description = "Managed identities (system- and user-assigned) for the SQL Managed Instance, sourced from a stateful AzAPI read so principal_id is known at plan time on subsequent applies."
  value       = module.sql_managed_instance.identity
}

output "service_principal" {
  description = "The system-assigned service principal details for the SQL Managed Instance. Required for Windows Authentication with Microsoft Entra ID."
  value       = module.sql_managed_instance.service_principal
}

output "private_endpoints" {
  description = "A map of the private endpoints created for the SQL Managed Instance."
  value       = module.sql_managed_instance.private_endpoints
}

output "database_format" {
  description = "The internal database format (update policy) reflecting the SQL engine version. Possible values are 'AlwaysUpToDate', 'SQLServer2022', or 'SQLServer2025'."
  value       = module.sql_managed_instance.database_format
}

output "is_general_purpose_v2" {
  description = "Whether the SQL Managed Instance is using the Next-gen General Purpose (GPv2) service tier."
  value       = module.sql_managed_instance.is_general_purpose_v2
}

output "pricing_model" {
  description = "The pricing model of the SQL Managed Instance ('Regular' or 'Freemium')."
  value       = module.sql_managed_instance.pricing_model
}

output "memory_size_in_gb" {
  description = "The actual memory size in GB allocated to the SQL Managed Instance."
  value       = module.sql_managed_instance.memory_size_in_gb
}

output "storage_iops" {
  description = "The actual storage IOPS allocated to the SQL Managed Instance."
  value       = module.sql_managed_instance.storage_iops
}
