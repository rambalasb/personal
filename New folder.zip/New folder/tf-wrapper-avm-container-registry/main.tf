module "container_registry" {
  source  = "Azure/avm-res-containerregistry-registry/azurerm"
  version = "0.5.1"

  # Required
  name                = var.name
  resource_group_name = var.resource_group_name
  location            = var.location

  # Registry core
  sku                     = var.sku
  admin_enabled           = var.admin_enabled
  zone_redundancy_enabled = var.zone_redundancy_enabled
  georeplications         = var.georeplications
  enable_telemetry        = var.enable_telemetry
  tags                    = local.module_tags

  # Access & content policies
  anonymous_pull_enabled    = var.anonymous_pull_enabled
  data_endpoint_enabled     = var.data_endpoint_enabled
  export_policy_enabled     = var.export_policy_enabled
  quarantine_policy_enabled = var.quarantine_policy_enabled
  retention_policy_in_days  = var.retention_policy_in_days
  enable_trust_policy       = var.enable_trust_policy
  scope_maps                = var.scope_maps

  # Networking
  public_network_access_enabled           = var.public_network_access_enabled
  network_rule_bypass_option              = var.network_rule_bypass_option
  network_rule_set                        = var.network_rule_set
  private_endpoints                       = var.private_endpoints
  private_endpoints_manage_dns_zone_group = var.private_endpoints_manage_dns_zone_group

  # Identity, encryption, RBAC, locks, diagnostics
  managed_identities   = var.managed_identities
  customer_managed_key = var.customer_managed_key
  role_assignments     = var.role_assignments
  lock                 = var.lock
  diagnostic_settings  = var.diagnostic_settings
}
