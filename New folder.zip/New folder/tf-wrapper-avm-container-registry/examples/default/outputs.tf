output "resource_id" {
  value = module.container_registry.resource_id
}

output "name" {
  value = module.container_registry.name
}
