module "container_registry" {
  source = "../.."

  # registry names are alphanumeric only, globally unique
  name                = "cravm${random_string.suffix.result}"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location

  sku = "Standard"

  enable_telemetry = false
}
