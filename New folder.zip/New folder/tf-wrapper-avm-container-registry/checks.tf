# Post-plan/apply advisory checks. These surface as warnings (never block apply) and
# assert compliance / cross-configuration invariants that the AVM module does not enforce.

check "admin_user_disabled" {
  assert {
    condition     = !var.admin_enabled
    error_message = "The Container Registry admin user should be disabled in favour of Azure AD / token auth. Set admin_enabled = false to comply."
  }
}

check "premium_required_for_network_rules" {
  assert {
    condition     = var.network_rule_set == null || var.sku == "Premium"
    error_message = "network_rule_set requires the 'Premium' SKU. Set sku = \"Premium\" or remove network_rule_set."
  }
}

check "premium_required_for_private_endpoints" {
  assert {
    condition     = length(var.private_endpoints) == 0 || var.sku == "Premium"
    error_message = "Private endpoints require the 'Premium' SKU. Set sku = \"Premium\" or remove private_endpoints."
  }
}

check "public_access_disabled_with_private_endpoints" {
  assert {
    condition     = length(var.private_endpoints) == 0 || !var.public_network_access_enabled
    error_message = "When private endpoints are configured, public network access should be disabled. Set public_network_access_enabled = false."
  }
}

check "export_policy_requires_public_access_disabled" {
  assert {
    condition     = var.export_policy_enabled || !var.public_network_access_enabled
    error_message = "Disabling export_policy_enabled requires public_network_access_enabled = false (Azure rejects the combination otherwise)."
  }
}
