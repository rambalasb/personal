terraform {
  required_version = ">= 1.9, < 2.0"

  required_providers {
    # AVM avm-res-containerregistry-registry v0.5.1 requires azurerm >= 4, so this
    # constraint intentionally differs from sibling wrappers that allow >= 3.116.
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 4.0, < 5.0"
    }
  }
}
