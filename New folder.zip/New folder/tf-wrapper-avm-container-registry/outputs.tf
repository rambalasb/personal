output "resource_id" {
  description = "The resource ID of the Container Registry."
  value       = module.container_registry.resource_id
}

output "name" {
  description = "The name of the Container Registry."
  value       = module.container_registry.name
}

output "resource" {
  description = "The full azurerm_container_registry resource output object."
  value       = module.container_registry.resource
}

output "system_assigned_mi_principal_id" {
  description = "The principal ID of the Container Registry's system-assigned managed identity, if enabled."
  value       = module.container_registry.system_assigned_mi_principal_id
}

output "private_endpoints" {
  description = "Map of private endpoints created for the Container Registry, keyed by the input map key. Each value is the full azurerm_private_endpoint resource."
  value       = module.container_registry.private_endpoints
}

output "scope_maps" {
  description = "Map of scope maps (and their registry tokens/passwords) created on the Container Registry, keyed by the input map key."
  value       = module.container_registry.scope_maps
}
