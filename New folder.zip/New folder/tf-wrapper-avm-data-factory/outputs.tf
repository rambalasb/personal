output "resource_id" {
  description = "The resource ID of the Data Factory."
  value       = module.data_factory.resource_id
}

output "name" {
  description = "The name of the Data Factory."
  value       = module.data_factory.name
}

output "resource" {
  description = "The full azurerm_data_factory resource output object."
  value       = module.data_factory.resource
}

output "private_endpoints" {
  description = "Map of private endpoints created for the Data Factory, keyed by the input map key. Each value is the full azurerm_private_endpoint resource."
  value       = module.data_factory.private_endpoints
}
