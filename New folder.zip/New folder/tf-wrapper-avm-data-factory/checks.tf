# Post-plan/apply advisory checks. These surface as warnings (never block apply) and
# assert cross-configuration invariants that the AVM module does not enforce on its own.

check "public_access_disabled_with_private_endpoints" {
  assert {
    condition     = length(var.private_endpoints) == 0 || !var.public_network_enabled
    error_message = "When private endpoints are configured, public network access should be disabled. Set public_network_enabled = false."
  }
}

check "customer_managed_key_requires_identity" {
  assert {
    condition     = var.customer_managed_key_id == null || var.customer_managed_key_identity_id != null
    error_message = "customer_managed_key_id requires customer_managed_key_identity_id (the user-assigned identity with access to the key) to be set as well."
  }
}

check "single_source_control_configuration" {
  assert {
    condition     = var.github_configuration == null || var.vsts_configuration == null
    error_message = "A Data Factory can be linked to only one source control system. Set either github_configuration or vsts_configuration, not both."
  }
}
