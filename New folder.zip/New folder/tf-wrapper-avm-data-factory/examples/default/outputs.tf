output "resource_id" {
  value = module.data_factory.resource_id
}

output "name" {
  value = module.data_factory.name
}
