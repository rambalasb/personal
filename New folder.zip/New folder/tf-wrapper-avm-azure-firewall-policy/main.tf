module "firewall_policy" {
  source  = "Azure/avm-res-network-firewallpolicy/azurerm"
  version = "0.3.4"

  # Required
  name                = var.name
  resource_group_name = var.resource_group_name
  location            = var.location

  # SKU & threat intelligence
  firewall_policy_sku                           = var.firewall_policy_sku
  firewall_policy_threat_intelligence_mode      = var.firewall_policy_threat_intelligence_mode
  firewall_policy_threat_intelligence_allowlist = var.firewall_policy_threat_intelligence_allowlist
  enable_telemetry                              = var.enable_telemetry
  tags                                          = local.module_tags

  # DNS & explicit proxy
  firewall_policy_dns            = var.firewall_policy_dns
  firewall_policy_explicit_proxy = var.firewall_policy_explicit_proxy

  # Identity
  firewall_policy_identity = var.firewall_policy_identity

  # Insights & intrusion detection
  firewall_policy_insights            = var.firewall_policy_insights
  firewall_policy_intrusion_detection = var.firewall_policy_intrusion_detection

  # SNAT, base policy & SQL
  firewall_policy_auto_learn_private_ranges_enabled = var.firewall_policy_auto_learn_private_ranges_enabled
  firewall_policy_private_ip_ranges                 = var.firewall_policy_private_ip_ranges
  firewall_policy_base_policy_id                    = var.firewall_policy_base_policy_id
  firewall_policy_sql_redirect_allowed              = var.firewall_policy_sql_redirect_allowed

  # TLS inspection
  firewall_policy_tls_certificate = var.firewall_policy_tls_certificate

  # RBAC, locks, diagnostics
  role_assignments    = var.role_assignments
  lock                = var.lock
  diagnostic_settings = var.diagnostic_settings

  # azapi operation tuning
  firewall_policy_timeouts = var.firewall_policy_timeouts
}
