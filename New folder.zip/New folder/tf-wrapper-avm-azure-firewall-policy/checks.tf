# Post-plan/apply advisory checks. These surface as warnings (never block apply) and
# assert cross-configuration invariants that the AVM module does not enforce on its own.

check "valid_sku" {
  assert {
    condition     = var.firewall_policy_sku == null || contains(["Standard", "Premium", "Basic"], coalesce(var.firewall_policy_sku, "Standard"))
    error_message = "firewall_policy_sku must be one of 'Standard', 'Premium', or 'Basic' (or null to use the AVM default)."
  }
}

check "premium_required_for_tls_inspection" {
  assert {
    condition     = var.firewall_policy_tls_certificate == null || var.firewall_policy_sku == "Premium"
    error_message = "TLS inspection (firewall_policy_tls_certificate) requires the 'Premium' SKU. Set firewall_policy_sku = \"Premium\"."
  }
}

check "premium_required_for_intrusion_detection" {
  assert {
    condition     = var.firewall_policy_intrusion_detection == null || var.firewall_policy_sku == "Premium"
    error_message = "IDPS (firewall_policy_intrusion_detection) requires the 'Premium' SKU. Set firewall_policy_sku = \"Premium\"."
  }
}

check "threat_intel_not_off" {
  assert {
    condition     = var.firewall_policy_threat_intelligence_mode == null || var.firewall_policy_threat_intelligence_mode != "Off"
    error_message = "Threat intelligence is turned 'Off'. Set firewall_policy_threat_intelligence_mode to 'Alert' or 'Deny' to benefit from Microsoft threat intelligence."
  }
}
