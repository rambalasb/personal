module "firewall_policy" {
  source = "../.."

  name                = "fwp-avm-${random_string.suffix.result}"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location

  enable_telemetry = false
}
