output "resource_id" {
  value = module.firewall_policy.resource_id
}
