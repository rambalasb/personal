output "resource_id" {
  description = "The resource ID of the Firewall Policy."
  value       = module.firewall_policy.resource_id
}

output "resource" {
  description = "The full azurerm_firewall_policy resource output object (id, firewalls, child_policies, rule_collection_groups, etc.)."
  value       = module.firewall_policy.resource
}
