# Post-plan/apply advisory checks. These surface as warnings (never block apply) and
# assert cross-configuration invariants that the AVM module does not enforce on its own.

check "nic_has_ip_configuration" {
  assert {
    condition     = length(var.ip_configurations) > 0
    error_message = "A network interface must have at least one ip_configurations entry."
  }
}

check "static_ip_has_address" {
  assert {
    condition = alltrue([
      for _, c in var.ip_configurations :
      c.private_ip_address_allocation != "Static" || c.private_ip_address != null
    ])
    error_message = "Any ip configuration using 'Static' private_ip_address_allocation must also set private_ip_address."
  }
}
