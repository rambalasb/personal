module "network_interface" {
  source  = "Azure/avm-res-network-networkinterface/azurerm"
  version = "0.1.1"

  # Required
  name                = var.name
  resource_group_name = var.resource_group_name
  location            = var.location
  ip_configurations   = var.ip_configurations

  # NIC behaviour
  accelerated_networking_enabled = var.accelerated_networking_enabled
  ip_forwarding_enabled          = var.ip_forwarding_enabled
  dns_servers                    = var.dns_servers
  internal_dns_name_label        = var.internal_dns_name_label
  edge_zone                      = var.edge_zone
  enable_telemetry               = var.enable_telemetry
  tags                           = local.module_tags

  # Security groups
  network_security_group_ids     = var.network_security_group_ids
  application_security_group_ids = var.application_security_group_ids

  # Load balancer / application gateway / NAT associations
  application_gateway_backend_address_pool_association = var.application_gateway_backend_address_pool_association
  load_balancer_backend_address_pool_association       = var.load_balancer_backend_address_pool_association
  nat_rule_association                                 = var.nat_rule_association

  # Locks
  lock = var.lock
}
