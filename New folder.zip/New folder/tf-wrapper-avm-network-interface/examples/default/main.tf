module "network_interface" {
  source = "../.."

  name                = "nic-avm-${random_string.suffix.result}"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location

  # map key is arbitrary; subnet_id points at the supporting subnet
  ip_configurations = {
    primary = {
      name                          = "ipconfig1"
      subnet_id                     = azurerm_subnet.this.id
      private_ip_address_allocation = "Dynamic"
      primary                       = true
    }
  }

  enable_telemetry = false
}
