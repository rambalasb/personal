# random suffix to avoid name collisions on reruns
resource "random_string" "suffix" {
  length  = 6
  lower   = true
  upper   = false
  numeric = true
  special = false
}

# native supporting RG so the example tests standalone, without a sibling module
resource "azurerm_resource_group" "this" {
  name     = "rg-avm-nic-default-test-${random_string.suffix.result}"
  location = "canadacentral"
}

# a NIC ip_configuration requires a subnet_id, so stand up a minimal VNet/subnet
resource "azurerm_virtual_network" "this" {
  name                = "vnet-avm-nic-default-test-${random_string.suffix.result}"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location
  address_space       = ["10.0.0.0/16"]
}

resource "azurerm_subnet" "this" {
  name                 = "snet-avm-nic-default-test-${random_string.suffix.result}"
  resource_group_name  = azurerm_resource_group.this.name
  virtual_network_name = azurerm_virtual_network.this.name
  address_prefixes     = ["10.0.1.0/24"]
}
