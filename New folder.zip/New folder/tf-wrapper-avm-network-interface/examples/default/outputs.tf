output "resource_id" {
  value = module.network_interface.resource_id
}
