output "resource_id" {
  description = "The resource ID of the network interface."
  value       = module.network_interface.resource_id
}

output "resource" {
  description = "The full azurerm_network_interface resource output object."
  value       = module.network_interface.resource
}

output "location" {
  description = "The Azure region where the network interface is deployed."
  value       = module.network_interface.location
}

output "resource_group_name" {
  description = "The name of the resource group containing the network interface."
  value       = module.network_interface.resource_group_name
}
