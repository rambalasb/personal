# Post-plan/apply advisory check. Surfaces as a warning (never blocks apply). This is a
# pattern module driven by deeply nested maps, so checks are kept minimal to avoid false
# positives.

check "at_least_one_virtual_hub" {
  assert {
    condition     = length(var.virtual_hubs) > 0
    error_message = "No virtual_hubs are defined, so the module will not deploy any hub, firewall, gateway, bastion, or DNS resource. Add at least one entry to virtual_hubs."
  }
}
