module "alz_connectivity_vwan" {
  source  = "Azure/avm-ptn-alz-connectivity-virtual-wan/azurerm"
  version = "0.16.0"

  # Core topology: hubs, shared vWAN/DDoS settings, and route maps
  virtual_hubs         = var.virtual_hubs
  virtual_wan_settings = var.virtual_wan_settings
  route_maps           = var.route_maps

  # Naming conventions
  default_naming_convention          = var.default_naming_convention
  default_naming_convention_sequence = var.default_naming_convention_sequence

  # Telemetry & tagging
  enable_telemetry = var.enable_telemetry
  tags             = local.module_tags

  # azapi operation tuning
  retry    = var.retry
  timeouts = var.timeouts
}
