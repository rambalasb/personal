# random suffix to avoid name collisions on reruns
resource "random_string" "suffix" {
  length  = 6
  lower   = true
  upper   = false
  numeric = true
  special = false
}

# the pattern module attaches hubs to an existing RG via default_parent_id and does not create RGs itself
resource "azurerm_resource_group" "hub" {
  name     = "rg-avm-vwan-default-test-${random_string.suffix.result}"
  location = "canadacentral"
}
