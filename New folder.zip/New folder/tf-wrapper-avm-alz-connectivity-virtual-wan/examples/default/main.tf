module "alz_connectivity_vwan" {
  source = "../.."

  # single hub in one region; the vWAN lands in this hub's RG by default
  virtual_hubs = {
    primary = {
      location                  = "canadacentral"
      default_hub_address_space = "10.100.0.0/23"
      default_parent_id         = azurerm_resource_group.hub.id

      # optional hub components disabled to keep the default example lightweight (just vWAN + hub)
      enabled_resources = {
        firewall                              = false
        firewall_policy                       = false
        bastion                               = false
        virtual_network_gateway_express_route = false
        virtual_network_gateway_vpn           = false
        private_dns_zones                     = false
        private_dns_resolver                  = false
        sidecar_virtual_network               = false
      }
    }
  }

  # skip the shared DDoS protection plan, which is created by default
  virtual_wan_settings = {
    enabled_resources = {
      ddos_protection_plan = false
    }
  }

  enable_telemetry = false
}
