output "resource_id" {
  value = module.alz_connectivity_vwan.resource_id
}

output "name" {
  value = module.alz_connectivity_vwan.name
}

output "virtual_hub_resource_ids" {
  value = module.alz_connectivity_vwan.virtual_hub_resource_ids
}
