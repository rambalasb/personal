output "resource_id" {
  description = "The resource ID of the Virtual WAN."
  value       = module.alz_connectivity_vwan.resource_id
}

output "name" {
  description = "The name of the Virtual WAN."
  value       = module.alz_connectivity_vwan.name
}

output "virtual_hub_resource_ids" {
  description = "The resource IDs of the virtual hubs associated with the Virtual WAN."
  value       = module.alz_connectivity_vwan.virtual_hub_resource_ids
}

output "virtual_hub_resource_names" {
  description = "The names of the virtual hubs associated with the Virtual WAN."
  value       = module.alz_connectivity_vwan.virtual_hub_resource_names
}

output "virtual_hub_bgp_connection_resource_ids" {
  description = "The resource IDs of the Virtual Hub BGP connections (NVA peers), keyed by `<virtual_hub_key>-<bgp_connection_key>`."
  value       = module.alz_connectivity_vwan.virtual_hub_bgp_connection_resource_ids
}

output "firewall_resource_ids" {
  description = "The resource IDs of the firewalls associated with the Virtual WAN, grouped by hub key."
  value       = module.alz_connectivity_vwan.firewall_resource_ids
}

output "firewall_resource_names" {
  description = "The names of the firewalls associated with the Virtual WAN, grouped by hub key."
  value       = module.alz_connectivity_vwan.firewall_resource_names
}

output "firewall_policy_resource_ids" {
  description = "The resource IDs of the firewall policies associated with the Virtual WAN."
  value       = module.alz_connectivity_vwan.firewall_policy_resource_ids
}

output "firewall_private_ip_address" {
  description = "The private IP addresses of the firewalls associated with the Virtual WAN, grouped by hub key."
  value       = module.alz_connectivity_vwan.firewall_private_ip_address
}

output "firewall_public_ip_addresses" {
  description = "The public IP addresses of the firewalls associated with the Virtual WAN, grouped by hub key."
  value       = module.alz_connectivity_vwan.firewall_public_ip_addresses
}

output "express_route_gateway_resource_ids" {
  description = "The resource IDs of the ExpressRoute gateways associated with the Virtual WAN."
  value       = module.alz_connectivity_vwan.express_route_gateway_resource_ids
}

output "express_route_gateway_resources" {
  description = "The resource objects of the ExpressRoute gateways associated with the Virtual WAN."
  value       = module.alz_connectivity_vwan.express_route_gateway_resources
}

output "bastion_host_resource_ids" {
  description = "The resource IDs of the bastion hosts associated with the Virtual WAN, grouped by hub key."
  value       = module.alz_connectivity_vwan.bastion_host_resource_ids
}

output "bastion_host_dns_names" {
  description = "The bastion host DNS names associated with the Virtual WAN, grouped by hub key."
  value       = module.alz_connectivity_vwan.bastion_host_dns_names
}

output "bastion_host_public_ip_address" {
  description = "The public IP addresses of the bastion hosts associated with the Virtual WAN, grouped by hub key."
  value       = module.alz_connectivity_vwan.bastion_host_public_ip_address
}

output "dns_server_ip_address" {
  description = "The private IP addresses of the DNS servers associated with the Virtual WAN."
  value       = module.alz_connectivity_vwan.dns_server_ip_address
}

output "private_dns_resolver_resource_ids" {
  description = "The resource IDs of the private DNS resolvers associated with the Virtual WAN, grouped by hub key."
  value       = module.alz_connectivity_vwan.private_dns_resolver_resource_ids
}

output "private_dns_resolver_resources" {
  description = "The private DNS resolvers associated with the Virtual WAN, grouped by hub key."
  value       = module.alz_connectivity_vwan.private_dns_resolver_resources
}

output "private_dns_zone_resource_ids" {
  description = "The resource IDs of the private DNS zones."
  value       = module.alz_connectivity_vwan.private_dns_zone_resource_ids
}

output "private_link_private_dns_zones_maps" {
  description = "Final configuration applied to the private DNS zones and associated virtual network links."
  value       = module.alz_connectivity_vwan.private_link_private_dns_zones_maps
}

output "sidecar_virtual_network_resource_ids" {
  description = "The resource IDs of the sidecar virtual networks associated with the Virtual WAN, grouped by hub key."
  value       = module.alz_connectivity_vwan.sidecar_virtual_network_resource_ids
}

output "sidecar_virtual_network_resources" {
  description = "The sidecar virtual networks associated with the Virtual WAN, grouped by hub key."
  value       = module.alz_connectivity_vwan.sidecar_virtual_network_resources
}

output "route_map_resource_ids_by_name" {
  description = "A map of route map name to resource ID."
  value       = module.alz_connectivity_vwan.route_map_resource_ids_by_name
}

output "route_map_resources" {
  description = "The route map resource objects, grouped by the arbitrary map key supplied in the route_maps variable."
  value       = module.alz_connectivity_vwan.route_map_resources
}
