terraform {
  required_version = ">= 1.9, < 2.0"

  required_providers {
    # AVM avm-ptn-alz-connectivity-virtual-wan v0.16.0 requires azurerm ~> 4.0, so this
    # constraint is tighter than the >= 3.116 baseline used by some sibling wrappers.
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 4.0, < 5.0"
    }
    # Required because the virtual_wan_settings variable validation calls the
    # provider-defined function provider::azapi::parse_resource_id(). Without this
    # provider declared, the module fails to initialize.
    azapi = {
      source  = "Azure/azapi"
      version = "~> 2.4"
    }
  }
}
