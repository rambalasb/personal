module "role_assignment" {
  source = "../.."

  role_assignments_azure_resource_manager = {
    reader = {
      principal_id         = data.azurerm_client_config.current.object_id
      principal_type       = "ServicePrincipal"
      scope                = azurerm_resource_group.this.id
      role_definition_name = "Reader"
    }
  }
}
