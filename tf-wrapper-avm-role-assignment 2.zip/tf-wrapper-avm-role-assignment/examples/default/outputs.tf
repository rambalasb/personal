output "role_assignments" {
  value = module.role_assignment.role_assignments
}

output "all_principals" {
  value = module.role_assignment.all_principals
}

output "scope_resource_id" {
  value = azurerm_resource_group.this.id
}
