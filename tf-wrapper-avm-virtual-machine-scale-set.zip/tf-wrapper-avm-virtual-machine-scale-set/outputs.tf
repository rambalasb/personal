output "resource_id" {
  description = "The Azure resource ID of the scale set."
  value       = module.vmss.resource_id
}

output "name" {
  description = "The name of the scale set."
  value       = module.vmss.resource_name
}

output "os_type" {
  description = "The OS the scale set was deployed with."
  value       = var.os_type
}

output "admin_username" {
  description = "The admin username configured on the instances."
  value       = var.admin_username
}
