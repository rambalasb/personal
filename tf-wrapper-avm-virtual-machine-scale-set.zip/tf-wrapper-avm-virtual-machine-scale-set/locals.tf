locals {
  is_linux   = var.os_type == "Linux"
  is_windows = var.os_type == "Windows"

  module_tags = merge(
    var.tags == null ? {} : var.tags,
    {
      managed-by = "terraform"
      module     = "tf-wrapper-avm-virtual-machine-scale-set"
      os-type    = lower(var.os_type)
    }
  )

  # Same approved images as the VM wrappers. Gen2 is required for Trusted Launch.
  default_image = {
    Linux = {
      publisher = "redhat"
      offer     = "rhel-byos"
      sku       = "rhel-lvm98-gen2"
      version   = "latest"
    }
    Windows = {
      publisher = "center-for-internet-security-inc"
      offer     = "cis-windows-server"
      sku       = "cis-windows-server2022-l1-gen2"
      version   = "latest"
    }
  }
  source_image_reference = coalesce(var.source_image_reference, local.default_image[var.os_type])

  # Both approved images are paid Marketplace offers; without a plan block the
  # deployment is rejected.
  plan_avm = var.plan != null ? var.plan : {
    name      = local.source_image_reference.sku
    product   = local.source_image_reference.offer
    publisher = local.source_image_reference.publisher
  }

  # RHEL_BYOS only when the image actually is BYOS; forcing it on another image
  # makes Azure demand Red Hat Cloud Access enrolment.
  license_type_avm = local.is_windows ? "Windows_Server" : (
    var.license_type != null ? var.license_type : (
      lower(local.source_image_reference.offer) == "rhel-byos" ? "RHEL_BYOS" : null
    )
  )

  # The module rejects AutomaticByPlatform patching, Rolling upgrades and
  # automatic repair without a health extension, and its own defaults turn the
  # first and last on. Defaults here follow whether one is configured.
  has_health_extension = var.application_health_extension != null

  health_extension = local.has_health_extension ? [{
    auto_upgrade_minor_version_enabled        = true
    extensions_to_provision_after_vm_creation = toset([])
    failure_suppression_enabled               = null
    force_extension_execution_on_change       = ""
    name                                      = local.is_linux ? "ApplicationHealthLinux" : "ApplicationHealthWindows"
    publisher                                 = "Microsoft.ManagedServices"
    type                                      = local.is_linux ? "ApplicationHealthLinux" : "ApplicationHealthWindows"
    type_handler_version                      = "2.0"
    protected_settings_from_key_vault         = null
    settings = jsonencode({ for k, v in {
      protocol          = var.application_health_extension.protocol
      port              = var.application_health_extension.port
      requestPath       = var.application_health_extension.request_path
      intervalInSeconds = var.application_health_extension.interval_in_seconds
      numberOfProbes    = var.application_health_extension.number_of_probes
      gracePeriod       = var.application_health_extension.grace_period
    } : k => v if v != null })
  }] : []

  extensions_avm = setunion(var.extensions, local.health_extension)

  automatic_instance_repair_avm = var.automatic_instance_repair != null ? var.automatic_instance_repair : (
    local.has_health_extension ? { enabled = true, grace_period = "PT30M" } : null
  )

  # Must be passed explicitly: a null here would pick up the module's
  # AutomaticByPlatform default, which fails without a health extension.
  patch_mode = var.patch_mode != null ? var.patch_mode : (
    local.has_health_extension ? "AutomaticByPlatform" : (local.is_linux ? "ImageDefault" : "AutomaticByOS")
  )

  # Azure rejects enableAutomaticUpdates = false unless patchMode is Manual.
  enable_automatic_updates = var.enable_automatic_updates != null ? var.enable_automatic_updates : local.patch_mode != "Manual"

  admin_ssh_keys = [
    for i, key in var.admin_ssh_public_keys : {
      id         = "key${i}"
      public_key = key
      username   = var.admin_username
    }
  ]

  os_profile = local.is_linux ? {
    custom_data = null
    linux_configuration = {
      admin_username                  = var.admin_username
      computer_name_prefix            = var.computer_name_prefix
      disable_password_authentication = true
      patch_assessment_mode           = var.patch_assessment_mode
      patch_mode                      = local.patch_mode
      provision_vm_agent              = var.provision_vm_agent
      admin_ssh_key_id                = toset([for k in local.admin_ssh_keys : k.id])
      secret = length(var.secrets) == 0 ? null : toset([
        for s in var.secrets : {
          key_vault_id = s.key_vault_id
          certificate  = toset([for c in s.certificate : { url = c.url }])
        }
      ])
    }
    windows_configuration = null
    } : {
    custom_data         = null
    linux_configuration = null
    windows_configuration = {
      admin_username           = var.admin_username
      computer_name_prefix     = var.computer_name_prefix
      enable_automatic_updates = local.enable_automatic_updates
      hotpatching_enabled      = var.hotpatching_enabled
      patch_assessment_mode    = var.patch_assessment_mode
      patch_mode               = local.patch_mode
      provision_vm_agent       = var.provision_vm_agent
      timezone                 = var.timezone
      secret = length(var.secrets) == 0 ? null : toset([
        for s in var.secrets : {
          key_vault_id = s.key_vault_id
          certificate  = toset([for c in s.certificate : { url = c.url, store = c.store }])
        }
      ])
      winrm_listener = length(var.winrm_listeners) == 0 ? null : var.winrm_listeners
    }
  }
}
