module "virtual_machine_scale_set" {
  source = "../.."

  os_type   = "Linux"
  name      = "vmsslin${random_string.suffix.result}"
  parent_id = azurerm_resource_group.this.id
  location  = azurerm_resource_group.this.location
  sku_name  = "Standard_D2s_v5"
  instances = 2

  # Image left at the Linux default (redhat/rhel-byos/rhel-lvm98-gen2) so CI
  # exercises the plan block and RHEL_BYOS license wiring. Same subscription
  # prerequisites as the Linux VM wrapper:
  #   az vm image terms accept --publisher redhat --offer rhel-byos \
  #     --plan rhel-lvm98-gen2

  os_disk = {
    caching              = "ReadWrite"
    storage_account_type = "Standard_LRS"
  }

  admin_username        = "azureuser"
  admin_ssh_public_keys = [tls_private_key.this.public_key_openssh]

  # exercises the health extension path: AutomaticByPlatform patching and
  # automatic repair both switch on from this
  application_health_extension = {
    protocol = "tcp"
    port     = 22
  }

  network_interface = [{
    name    = "nic-primary"
    primary = true
    ip_configuration = [{
      name      = "ipconfig1"
      primary   = true
      subnet_id = azurerm_subnet.this.id
    }]
  }]

  enable_telemetry = false
}
