output "resource_id" {
  value = module.virtual_machine_scale_set.resource_id
}

output "name" {
  value = module.virtual_machine_scale_set.name
}

output "admin_username" {
  value = module.virtual_machine_scale_set.admin_username
}
