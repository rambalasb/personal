module "virtual_machine_scale_set" {
  source = "../.."

  os_type   = "Windows"
  name      = "vmsswin${random_string.suffix.result}"
  parent_id = azurerm_resource_group.this.id
  location  = azurerm_resource_group.this.location
  sku_name  = "Standard_D2s_v5"
  instances = 1

  # Windows hostnames cap the prefix at 9 characters
  computer_name_prefix = "vmsswin"

  # Image left at the Windows default (CIS Windows Server 2022 L1 Gen2).
  # Requires the CIS terms to be accepted on the target subscription:
  #   az vm image terms accept --publisher center-for-internet-security-inc \
  #     --offer cis-windows-server --plan cis-windows-server2022-l1-gen2

  os_disk = {
    caching              = "ReadWrite"
    storage_account_type = "Standard_LRS"
  }

  admin_username         = "azureadmin"
  admin_password         = random_password.admin.result
  admin_password_version = "v1"

  network_interface = [{
    name    = "nic-primary"
    primary = true
    ip_configuration = [{
      name      = "ipconfig1"
      primary   = true
      subnet_id = azurerm_subnet.this.id
    }]
  }]

  enable_telemetry = false
}
