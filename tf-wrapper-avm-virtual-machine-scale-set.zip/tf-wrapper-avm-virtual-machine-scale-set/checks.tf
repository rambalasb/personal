check "encryption_at_host_enabled" {
  assert {
    condition     = var.encryption_at_host_enabled == true
    error_message = "Scale sets should have encryption_at_host_enabled = true."
  }
}

# The scale set module has no securityType/UEFI inputs, so Trusted Launch comes
# from the Azure default for Gen2 images on API 2024-07-01+. Read it back
# rather than assume it.
check "trusted_launch_enabled" {
  data "azapi_resource" "vmss_security" {
    type                   = "Microsoft.Compute/virtualMachineScaleSets@2024-11-01"
    resource_id            = module.vmss.resource_id
    response_export_values = ["properties.virtualMachineProfile.securityProfile"]
  }

  assert {
    condition = (
      try(data.azapi_resource.vmss_security.output.properties.virtualMachineProfile.securityProfile.securityType, "") == "TrustedLaunch" &&
      try(data.azapi_resource.vmss_security.output.properties.virtualMachineProfile.securityProfile.uefiSettings.secureBootEnabled, false) == true &&
      try(data.azapi_resource.vmss_security.output.properties.virtualMachineProfile.securityProfile.uefiSettings.vTpmEnabled, false) == true
    )
    error_message = "Scale set is not running Trusted Launch with secure boot and vTPM. Check the image is Gen2 and the SKU supports Trusted Launch."
  }
}

check "winrm_https_when_listener_configured" {
  assert {
    condition     = alltrue([for l in var.winrm_listeners : l.protocol == "Https"])
    error_message = "WinRM listeners should use Https only. Http listeners expose management traffic in plaintext."
  }
}

check "windows_settings_ignored_on_linux" {
  assert {
    condition     = var.os_type == "Windows" || (length(var.winrm_listeners) == 0 && var.timezone == null && var.enable_automatic_updates == null && var.hotpatching_enabled == false)
    error_message = "winrm_listeners, timezone, enable_automatic_updates and hotpatching_enabled are Windows only and are ignored for Linux scale sets."
  }
}
