# =====================================================================
# Required inputs
# =====================================================================

variable "os_type" {
  type        = string
  description = "Operating system of the scale set instances. 'Linux' or 'Windows'. Selects the credential model, the approved image and the license type; changing it replaces the scale set."

  validation {
    condition     = contains(["Linux", "Windows"], var.os_type)
    error_message = "os_type must be 'Linux' or 'Windows'."
  }
}

variable "name" {
  type        = string
  description = "The name of the scale set. Must be 1-64 characters. Also the default computer name prefix, so Windows scale sets need computer_name_prefix when name is longer than 9 characters."

  validation {
    condition     = can(regex("^.{1,64}$", var.name))
    error_message = "name must be 1-64 characters."
  }
}

variable "parent_id" {
  type        = string
  description = "Resource ID of the Resource Group the scale set is deployed into. This module takes the RG's resource ID, not its name — pass module.resource_group[key].resource_id."

  validation {
    condition     = can(regex("^/subscriptions/[^/]+/resourceGroups/[^/]+$", var.parent_id))
    error_message = "parent_id must be a resource group resource ID: /subscriptions/{sub}/resourceGroups/{rg}."
  }
}

variable "location" {
  type        = string
  description = "Azure region for the scale set."

  validation {
    condition     = length(var.location) > 0
    error_message = "location must not be empty."
  }
}

variable "network_interface" {
  type = set(object({
    dns_servers                   = optional(set(string), [])
    enable_accelerated_networking = optional(bool, false)
    enable_ip_forwarding          = optional(bool, false)
    name                          = string
    network_security_group_id     = optional(string)
    primary                       = optional(bool, false)
    ip_configuration = set(object({
      application_gateway_backend_address_pool_ids = optional(set(string), [])
      application_security_group_ids               = optional(set(string), [])
      load_balancer_backend_address_pool_ids       = optional(set(string), [])
      name                                         = string
      primary                                      = optional(bool, false)
      subnet_id                                    = optional(string)
      version                                      = optional(string, "IPv4")
      public_ip_address = optional(set(object({
        domain_name_label       = optional(string)
        idle_timeout_in_minutes = optional(number)
        name                    = string
        public_ip_prefix_id     = optional(string)
        sku_name                = optional(string)
        sku_tier                = optional(string)
        version                 = optional(string)
        ip_tag = optional(set(object({
          tag  = string
          type = string
        })))
      })))
    }))
  }))
  description = "NIC configurations applied to every instance. At least one is required, and exactly one should be primary."

  validation {
    condition     = length(var.network_interface) > 0
    error_message = "At least one network_interface entry is required."
  }
}

# =====================================================================
# Authentication
# =====================================================================

variable "admin_username" {
  type        = string
  description = "Local admin username on every instance. Windows limits this to 20 characters."
  default     = "azureuser"

  validation {
    condition     = !contains(["administrator", "admin", "user", "user1", "test", "user2", "test1", "user3", "admin1", "1", "123", "a", "actuser", "adm", "admin2", "aspnet", "backup", "console", "david", "guest", "john", "owner", "root", "server", "sql", "support", "support_388945a0", "sys", "test2", "test3", "user4", "user5"], lower(var.admin_username))
    error_message = "Admin username is a reserved Azure value. Pick a different username."
  }

  validation {
    condition     = var.os_type != "Windows" || can(regex("^.{1,20}$", var.admin_username))
    error_message = "Windows admin username must be 1-20 characters."
  }
}

variable "admin_ssh_public_keys" {
  type        = list(string)
  description = "Linux only. SSH public keys for the admin user. Required for Linux — password authentication is permanently disabled and the scale set module cannot generate a key."
  default     = []

  validation {
    condition     = var.os_type != "Linux" || length(var.admin_ssh_public_keys) > 0
    error_message = "Linux scale sets require at least one admin_ssh_public_keys entry."
  }

  validation {
    condition     = var.os_type != "Windows" || length(var.admin_ssh_public_keys) == 0
    error_message = "admin_ssh_public_keys is Linux only; leave it empty for Windows."
  }
}

variable "admin_password" {
  type        = string
  description = "Windows only. Admin password, sent write-only and never stored in state. Required for Windows; rejected for Linux."
  default     = null
  sensitive   = true
  ephemeral   = true

  validation {
    condition     = var.os_type != "Windows" || var.admin_password != null
    error_message = "Windows scale sets require admin_password."
  }

  validation {
    condition     = var.os_type != "Linux" || var.admin_password == null
    error_message = "Linux scale sets use SSH keys only; admin_password must be null."
  }
}

# The password is write-only, so Terraform cannot see when it changes.
variable "admin_password_version" {
  type        = string
  description = "Windows only. Bump this whenever admin_password changes so the new value is sent. Required when admin_password is set."
  default     = null

  validation {
    condition     = var.os_type != "Windows" || var.admin_password_version != null
    error_message = "admin_password_version is required for Windows scale sets."
  }
}

variable "computer_name_prefix" {
  type        = string
  description = "Prefix for instance hostnames. Defaults to name. Windows allows at most 9 characters; Linux at most 58."
  default     = null
}

# =====================================================================
# Image
# =====================================================================

variable "source_image_reference" {
  type = object({
    publisher = string
    offer     = string
    sku       = string
    version   = string
  })
  description = "Marketplace image. Leave null for the approved default per OS: RHEL 9.8 BYOS (LVM, Gen 2) for Linux, CIS Windows Server 2022 L1 Gen 2 for Windows. Same image standard as the VM wrappers."
  default     = null

  validation {
    condition = var.source_image_reference == null || (
      var.os_type == "Linux" ?
      lower(var.source_image_reference.publisher) == "redhat" && lower(var.source_image_reference.offer) == "rhel-byos" && lower(var.source_image_reference.sku) == "rhel-lvm98-gen2" :
      lower(var.source_image_reference.publisher) == "center-for-internet-security-inc" && lower(var.source_image_reference.offer) == "cis-windows-server" && contains(["cis-windows-server2022-l1-gen2", "cis-windows-server2025-l1-gen2"], lower(var.source_image_reference.sku))
    )
    error_message = "source_image_reference must be the approved image for os_type: redhat/rhel-byos/rhel-lvm98-gen2 for Linux, or center-for-internet-security-inc/cis-windows-server/cis-windows-server{2022,2025}-l1-gen2 for Windows."
  }

  validation {
    condition     = var.source_image_reference == null || lower(try(var.source_image_reference.version, "")) == "latest"
    error_message = "source_image_reference.version must be 'latest'."
  }
}

# =====================================================================
# Size, capacity, placement
# =====================================================================

variable "sku_name" {
  type        = string
  description = "Instance size. Restricted to the D, E and F families, matching the VM wrappers. Defaults to Standard_D2ds_v5."
  default     = "Standard_D2ds_v5"

  validation {
    condition     = can(regex("^Standard_(D|E|F)[0-9]", var.sku_name))
    error_message = "sku_name must be a D-series, E-series, or F-series SKU (e.g. Standard_D4s_v5, Standard_E4s_v5, Standard_F8s_v2) per the agreed VM sizing standard."
  }
}

variable "instances" {
  type        = number
  description = "Instance count. When an autoscale setting owns capacity, add \"sku.capacity\" to ignore_body_changes so plans don't fight it."
  default     = 2

  validation {
    condition     = var.instances >= 0 && var.instances <= 1000
    error_message = "instances must be between 0 and 1000."
  }
}

variable "zones" {
  type        = set(string)
  description = "Availability Zones to spread instances across. Set to [] in regions without zones."
  default     = ["1", "2", "3"]
}

variable "zone_balance" {
  type        = bool
  description = "Strictly balance instances across zones. Requires zones."
  default     = false
}

variable "platform_fault_domain_count" {
  type        = number
  description = "Fault domain count. 1 enables max spreading. Forces replacement."
  default     = 1
}

variable "single_placement_group" {
  type        = bool
  description = "Limit the scale set to one placement group (100 instances)."
  default     = null
}

variable "proximity_placement_group_id" {
  type        = string
  description = "Proximity Placement Group resource ID. Conflicts with capacity_reservation_group_id."
  default     = null
}

variable "capacity_reservation_group_id" {
  type        = string
  description = "Capacity Reservation Group resource ID."
  default     = null
}

variable "additional_capabilities" {
  type = object({
    ultra_ssd_enabled   = optional(bool)
    hibernation_enabled = optional(bool)
  })
  description = "UltraSSD and hibernation support. Changing hibernation_enabled replaces the scale set."
  default     = null
}

# =====================================================================
# Disks & security
# =====================================================================

variable "os_disk" {
  type = object({
    caching                   = string
    disk_encryption_set_id    = optional(string)
    disk_size_gb              = optional(number)
    storage_account_type      = string
    write_accelerator_enabled = optional(bool, false)
    delete_option             = optional(string, "Delete")
    diff_disk_settings = optional(object({
      option    = string
      placement = optional(string)
    }))
  })
  description = "OS disk configuration."
  default = {
    caching              = "ReadWrite"
    storage_account_type = "Premium_LRS"
  }
}

variable "data_disk" {
  type = set(object({
    caching                        = string
    create_option                  = optional(string)
    delete_option                  = optional(string)
    disk_encryption_set_id         = optional(string)
    disk_size_gb                   = optional(number)
    lun                            = optional(number)
    storage_account_type           = string
    ultra_ssd_disk_iops_read_write = optional(number)
    ultra_ssd_disk_mbps_read_write = optional(number)
    write_accelerator_enabled      = optional(bool)
  }))
  description = "Data disks created on every instance."
  default     = []
}

variable "disk_controller_type" {
  type        = string
  description = "Disk controller type. 'SCSI' or 'NVMe'. Linux defaults to SCSI."
  default     = null
}

variable "encryption_at_host_enabled" {
  type        = bool
  description = "Whether encryption at host (including temp disk) is enabled."
  default     = true
}

variable "proxy_agent_settings" {
  type = object({
    enabled                   = optional(bool, true)
    key_incarnation_id        = optional(number)
    add_proxy_agent_extension = optional(bool)
    imds = optional(object({
      mode                                      = optional(string)
      in_vm_access_control_profile_reference_id = optional(string)
    }))
    wire_server = optional(object({
      mode                                      = optional(string)
      in_vm_access_control_profile_reference_id = optional(string)
    }))
  })
  description = "Metadata Security Protocol settings for the Guest Proxy Agent. The image must support MSP."
  default     = null
}

# =====================================================================
# Health, repair, upgrades, patching
# =====================================================================

variable "application_health_extension" {
  type = object({
    protocol            = string
    port                = optional(number)
    request_path        = optional(string)
    interval_in_seconds = optional(number, 5)
    number_of_probes    = optional(number, 1)
    grace_period        = optional(number)
  })
  description = <<DESC
Application Health extension added to every instance (ApplicationHealthLinux or ApplicationHealthWindows, picked from os_type).

Required for Rolling upgrades and automatic instance repair, and switches the patch_mode default to AutomaticByPlatform. Leave null for a scale set with no health signal.

- protocol: 'tcp', 'http' or 'https'
- port: required for tcp; defaults to 80/443 for http/https
- request_path: required for http/https
DESC
  default     = null

  validation {
    condition     = var.application_health_extension == null || contains(["tcp", "http", "https"], try(var.application_health_extension.protocol, ""))
    error_message = "application_health_extension.protocol must be 'tcp', 'http' or 'https'."
  }

  validation {
    condition     = var.application_health_extension == null || try(var.application_health_extension.protocol, "") != "tcp" || try(var.application_health_extension.port, null) != null
    error_message = "application_health_extension.port is required when protocol is 'tcp'."
  }

  validation {
    condition     = var.application_health_extension == null || try(var.application_health_extension.protocol, "") == "tcp" || try(var.application_health_extension.request_path, null) != null
    error_message = "application_health_extension.request_path is required when protocol is 'http' or 'https'."
  }
}

variable "automatic_instance_repair" {
  type = object({
    enabled      = bool
    grace_period = optional(string)
  })
  description = "Automatic instance repair. Leave null to enable it (PT30M grace) whenever application_health_extension is set, and leave it off otherwise. Needs the health extension."
  default     = null
}

variable "upgrade_policy" {
  type = object({
    upgrade_mode = optional(string, "Manual")
    rolling_upgrade_policy = optional(object({
      cross_zone_upgrades_enabled             = optional(bool)
      max_batch_instance_percent              = optional(number)
      max_unhealthy_instance_percent          = optional(number)
      max_unhealthy_upgraded_instance_percent = optional(number)
      pause_time_between_batches              = optional(string)
      prioritize_unhealthy_instances_enabled  = optional(bool)
      maximum_surge_instances_enabled         = optional(bool)
    }), {})
  })
  description = "Upgrade policy. Rolling requires application_health_extension and all four core rolling_upgrade_policy fields."
  default     = { upgrade_mode = "Manual" }

  validation {
    condition     = contains(["Automatic", "Manual", "Rolling"], try(var.upgrade_policy.upgrade_mode, "Manual"))
    error_message = "upgrade_policy.upgrade_mode must be 'Automatic', 'Manual' or 'Rolling'."
  }
}

variable "patch_mode" {
  type        = string
  description = "In-guest patch mode. Leave null for AutomaticByPlatform when application_health_extension is set, otherwise ImageDefault (Linux) or AutomaticByOS (Windows). Linux accepts ImageDefault/AutomaticByPlatform; Windows accepts Manual/AutomaticByOS/AutomaticByPlatform."
  default     = null

  validation {
    condition = var.patch_mode == null || (
      var.os_type == "Linux" ? contains(["ImageDefault", "AutomaticByPlatform"], var.patch_mode) : contains(["Manual", "AutomaticByOS", "AutomaticByPlatform"], var.patch_mode)
    )
    error_message = "patch_mode must be ImageDefault or AutomaticByPlatform for Linux, or Manual, AutomaticByOS or AutomaticByPlatform for Windows."
  }
}

variable "patch_assessment_mode" {
  type        = string
  description = "Patch assessment mode. 'AutomaticByPlatform' or 'ImageDefault'."
  default     = "ImageDefault"

  validation {
    condition     = contains(["AutomaticByPlatform", "ImageDefault"], var.patch_assessment_mode)
    error_message = "patch_assessment_mode must be 'AutomaticByPlatform' or 'ImageDefault'."
  }
}

variable "provision_vm_agent" {
  type        = bool
  description = "Whether to provision the VM agent. Required for extensions and platform patching."
  default     = true
}

variable "termination_notification" {
  type = object({
    enabled = bool
    timeout = optional(string, "PT5M")
  })
  description = "Scheduled-event termination notification."
  default     = null
}

# =====================================================================
# Windows-only settings
# =====================================================================

variable "enable_automatic_updates" {
  type        = bool
  description = "Windows only. Leave null to derive from patch_mode (Azure requires true unless patch_mode is Manual)."
  default     = null
}

variable "hotpatching_enabled" {
  type        = bool
  description = "Windows only. Hotpatching needs an Azure Edition image, which the approved CIS images are not, so this stays false."
  default     = false
}

variable "timezone" {
  type        = string
  description = "Windows only. Instance time zone, e.g. 'Eastern Standard Time'."
  default     = null
}

variable "winrm_listeners" {
  type = set(object({
    certificate_url = optional(string)
    protocol        = string
  }))
  description = "Windows only. WinRM listeners. Https only — see checks.tf."
  default     = []
}

# =====================================================================
# Extensions, secrets, data
# =====================================================================

variable "extensions" {
  type = set(object({
    auto_upgrade_minor_version_enabled        = optional(bool, true)
    extensions_to_provision_after_vm_creation = optional(set(string), [])
    failure_suppression_enabled               = optional(bool)
    force_extension_execution_on_change       = optional(string, "")
    name                                      = string
    publisher                                 = string
    settings                                  = optional(string)
    type                                      = string
    type_handler_version                      = string
    protected_settings_from_key_vault = optional(object({
      secret_url      = string
      source_vault_id = string
    }), null)
  }))
  description = "Extensions on every instance. Don't add an Application Health extension here — use application_health_extension."
  default     = []

  validation {
    condition     = !anytrue([for e in var.extensions : contains(["ApplicationHealthLinux", "ApplicationHealthWindows"], e.type)])
    error_message = "Configure the Application Health extension through application_health_extension, not extensions."
  }
}

variable "extension_protected_settings" {
  type        = map(string)
  description = "JSON protected settings per extension, keyed by extension name. Write-only; never stored in state."
  default     = null
  sensitive   = true
  ephemeral   = true
}

variable "extension_protected_settings_version" {
  type        = map(string)
  description = "Version per extension name. Bump an entry whenever its protected settings change."
  default     = null
}

variable "extensions_time_budget" {
  type        = string
  description = "ISO 8601 duration allowed for all extensions to start. 15-120 minutes."
  default     = "PT1H30M"
}

variable "extension_operations_enabled" {
  type        = bool
  description = "Whether extension operations are allowed. Forces replacement."
  default     = true
}

variable "secrets" {
  type = list(object({
    key_vault_id = string
    certificate = set(object({
      url   = string
      store = optional(string)
    }))
  }))
  description = "Key Vault certificates installed on every instance. certificate.store is required for Windows and ignored for Linux."
  default     = []

  validation {
    condition     = var.os_type != "Windows" || alltrue(flatten([for s in var.secrets : [for c in s.certificate : c.store != null]]))
    error_message = "Every secrets certificate needs a store on Windows (e.g. 'My')."
  }
}

variable "custom_data" {
  type        = string
  description = "Base64-encoded custom data. Write-only. Requires custom_data_version."
  default     = null
  sensitive   = true

  validation {
    condition     = var.custom_data == null || can(base64decode(var.custom_data))
    error_message = "custom_data must be null or a valid Base64-encoded string."
  }
}

variable "custom_data_version" {
  type        = string
  description = "Bump whenever custom_data changes."
  default     = null
}

variable "user_data_base64" {
  type        = string
  description = "Base64-encoded user data. Write-only. Requires user_data_base64_version."
  default     = null
  ephemeral   = true
}

variable "user_data_base64_version" {
  type        = string
  description = "Bump whenever user_data_base64 changes."
  default     = null
}

# =====================================================================
# Spot
# =====================================================================

variable "priority" {
  type        = string
  description = "'Regular' or 'Spot'. Forces replacement."
  default     = "Regular"

  validation {
    condition     = contains(["Regular", "Spot"], var.priority)
    error_message = "priority must be 'Regular' or 'Spot'."
  }
}

variable "eviction_policy" {
  type        = string
  description = "Spot only. 'Deallocate' or 'Delete'."
  default     = null
}

variable "max_bid_price" {
  type        = number
  description = "Spot only. Max price in USD; -1 disables eviction by price."
  default     = -1
}

variable "priority_mix" {
  type = object({
    base_regular_count            = optional(number)
    regular_percentage_above_base = optional(number)
  })
  description = "Spot only. Regular/Spot mix."
  default     = null
}

# =====================================================================
# Identity & RBAC
# =====================================================================

variable "user_assigned_identity_resource_ids" {
  type        = set(string)
  description = "User-assigned managed identities for the instances. Flexible scale sets from this module do not support system-assigned identity."
  default     = []
}

variable "role_assignments" {
  type = map(object({
    role_definition_id_or_name             = string
    principal_id                           = string
    description                            = optional(string, null)
    skip_service_principal_aad_check       = optional(bool, false)
    condition                              = optional(string, null)
    condition_version                      = optional(string, null)
    delegated_managed_identity_resource_id = optional(string, null)
    principal_type                         = optional(string, null)
  }))
  description = "RBAC role assignments scoped to the scale set."
  default     = {}
}

# =====================================================================
# Licensing
# =====================================================================

variable "license_type" {
  type        = string
  description = "Leave null to derive: 'Windows_Server' for Windows (mandatory Azure Hybrid Benefit), 'RHEL_BYOS' for the RHEL BYOS image. Set explicitly only to override the Linux value."
  default     = null

  validation {
    condition     = var.license_type == null || var.os_type != "Windows" || var.license_type == "Windows_Server"
    error_message = "license_type must be 'Windows_Server' for Windows. Azure Hybrid Benefit is required on all Windows VMs from this platform."
  }
}

variable "plan" {
  type = object({
    name      = string
    product   = string
    publisher = string
  })
  description = "Marketplace plan. Leave null to derive it from source_image_reference — both approved images are paid offers that need one."
  default     = null
}

# =====================================================================
# Diagnostics, locks, tags, telemetry
# =====================================================================

variable "boot_diagnostics" {
  type = object({
    storage_account_uri = optional(string)
  })
  description = "Boot diagnostics. {} uses a managed storage account; null disables."
  default     = {}
}

variable "lock" {
  type = object({
    name = optional(string, null)
    kind = string
  })
  description = "Resource lock. kind must be 'CanNotDelete' or 'ReadOnly'."
  default     = null

  validation {
    condition     = var.lock == null || contains(["CanNotDelete", "ReadOnly"], try(var.lock.kind, ""))
    error_message = "lock.kind must be 'CanNotDelete' or 'ReadOnly' when set."
  }
}

variable "tags" {
  type        = map(string)
  description = "Tags applied to the scale set."
  default     = null
}

variable "enable_telemetry" {
  type        = bool
  description = "Whether to enable AVM module telemetry."
  default     = true
}

# =====================================================================
# Long-tail toggles
# =====================================================================

variable "network_api_version" {
  type        = string
  description = "Microsoft.Network API version used for instance NICs."
  default     = "2020-11-01"
}

variable "ignore_body_changes" {
  type = object({
    compute_virtual_machine_scale_sets = optional(list(string), [])
    authorization_locks                = optional(list(string), [])
    authorization_role_assignments     = optional(list(string), [])
  })
  description = "Body paths azapi ignores after creation, for properties owned out of band. Add \"sku.capacity\" under compute_virtual_machine_scale_sets when an autoscale setting manages instance count. Needs Terraform 1.11+."
  default     = {}
}

variable "timeouts" {
  type = object({
    create = optional(string)
    delete = optional(string)
    read   = optional(string)
    update = optional(string)
  })
  description = "Operation timeouts for the scale set."
  default     = null
}
