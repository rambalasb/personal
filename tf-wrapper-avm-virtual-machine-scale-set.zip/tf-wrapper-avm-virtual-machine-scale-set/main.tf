module "vmss" {
  source  = "Azure/avm-res-compute-virtualmachinescaleset/azurerm"
  version = "0.11.1"

  # Required
  name              = var.name
  parent_id         = var.parent_id
  location          = var.location
  network_interface = var.network_interface

  # OS profile — built per os_type in locals; Linux is SSH-only.
  os_profile             = local.os_profile
  admin_ssh_keys         = local.is_linux ? local.admin_ssh_keys : null
  admin_password         = var.admin_password
  admin_password_version = var.admin_password_version

  # Image — source_image_id is not exposed so the approved-image standard holds.
  source_image_reference = local.source_image_reference
  source_image_id        = null
  plan                   = local.plan_avm
  license_type           = local.license_type_avm

  # Size, capacity, placement
  sku_name                      = var.sku_name
  instances                     = var.instances
  zones                         = var.zones
  zone_balance                  = var.zone_balance
  platform_fault_domain_count   = var.platform_fault_domain_count
  single_placement_group        = var.single_placement_group
  proximity_placement_group_id  = var.proximity_placement_group_id
  capacity_reservation_group_id = var.capacity_reservation_group_id
  additional_capabilities       = var.additional_capabilities

  # Disks & security
  os_disk                    = var.os_disk
  data_disk                  = var.data_disk
  disk_controller_type       = var.disk_controller_type
  encryption_at_host_enabled = var.encryption_at_host_enabled
  proxy_agent_settings       = var.proxy_agent_settings

  # Health, repair, upgrades
  automatic_instance_repair = local.automatic_instance_repair_avm
  upgrade_policy            = var.upgrade_policy
  termination_notification  = var.termination_notification

  # Extensions, data
  extension                           = local.extensions_avm
  extension_protected_setting         = var.extension_protected_settings
  extension_protected_setting_version = var.extension_protected_settings_version
  extensions_time_budget              = var.extensions_time_budget
  extension_operations_enabled        = var.extension_operations_enabled
  custom_data                         = var.custom_data
  custom_data_version                 = var.custom_data_version
  user_data_base64                    = var.user_data_base64
  user_data_base64_version            = var.user_data_base64_version

  # Spot
  priority        = var.priority
  eviction_policy = var.eviction_policy
  max_bid_price   = var.max_bid_price
  priority_mix    = var.priority_mix

  # Identity & RBAC
  managed_identities = {
    system_assigned            = false
    user_assigned_resource_ids = var.user_assigned_identity_resource_ids
  }
  role_assignments = var.role_assignments

  # Diagnostics, lock, tags, telemetry
  boot_diagnostics = var.boot_diagnostics
  lock             = var.lock
  tags             = local.module_tags
  enable_telemetry = var.enable_telemetry

  # Long-tail toggles
  network_api_version = var.network_api_version
  ignore_body_changes = var.ignore_body_changes
  timeouts            = var.timeouts
}
