# platform-pipelines

Centralized, reusable GitHub Actions workflows for Terraform / AVM wrapper module repos and subscription deployment repos across the enterprise.

Consumers reference these via `workflow_call` and get lint, security scanning, plan/apply, and module test/publish without duplicating pipeline logic per repo.

Every repo and subscription we create deploys through `reusable-lz-deploy-plan.yml` / `reusable-lz-deploy-apply.yml` — the destroy gate and the approval ceremony are mandatory, not opt-in. There is no lighter-weight plan/apply pair; a repo that skips these and runs `terraform apply` some other way has no destroy gate and no required-reviewer gate.

## Prerequisites (cross-org access)

This repo is intended to be called from repos in **other organizations within the same GitHub Enterprise account**. That only works if an enterprise owner has enabled it:

`Enterprise settings → Policies → Actions → Reusable workflows` — allow access from other organizations in the enterprise (or explicitly allow-list the consuming orgs).

Without that policy enabled, `workflow_call` across orgs will fail even though both orgs are in the same enterprise.

## Repo layout

```text
.github/workflows/
  reusable-tflint.yml              # terraform fmt + tflint
  reusable-trivy.yml               # IaC security scan (Trivy)
  reusable-lz-deploy-plan.yml      # PR plan: speculative run, never applyable
  reusable-lz-deploy-apply.yml     # main apply: check+gate, destroy gate, approval ceremony, then apply the reviewed run
  reusable-module-test.yml         # local test: validate + terraform test, mocked providers, no credentials
  reusable-module-remote-test.yml  # remote test: deploys to a sandbox subscription, verifies, tears down
  reusable-module-publish.yml      # tag + publish a module, gated on both tests passing
```

### Module pipeline ordering

AVM wrapper module repos should chain these three in sequence, not run them independently:

```text
tflint / trivy  →  module-test (local)  →  module-remote-test (sandbox)  →  module-publish
```

`module-test` runs on every PR and is fast/free. `module-remote-test` costs real sandbox resources and time, so gate it on `module-test` passing first, and only publish once both have succeeded.

## Versioning

Tag releases using semver (`v1.0.0`, `v1.1.0`, ...). Consumers should pin to an exact tag, not `@main`:

```yaml
uses: <org>/platform-pipelines/.github/workflows/reusable-tflint.yml@v1.0.0
```

Move a floating major tag (`v1`) forward deliberately once a change has been validated against a couple of low-risk consumer repos. Don't force-update `v1` without a rollout check — every repo pinned to `@v1` picks up the change immediately.

### Landing zone deploy pipeline

`reusable-lz-deploy-plan.yml` and `reusable-lz-deploy-apply.yml` are the shared pair behind every subscription's deploy pipeline (identity, management, security, firewall management, connectivity, ...). One copy, parameterized by `environment` — the subscription name. Each subscription repo owns:

- its own Terraform root (`providers.tf`, `<environment>.tfvars`, etc.) at `working-directory`,
- a thin caller workflow with the real triggers (`pull_request`, `push: [main]`, `workflow_dispatch`),
- and a GitHub Environment named exactly `<environment>`, with required reviewers configured — that environment is what gates the apply job. No reviewers configured means no gate, silently.

```yaml
# .github/workflows/deploy-plan.yml in e.g. the management-lz repo
name: management-lz deploy plan

on:
  pull_request:
    branches: [main]
  workflow_dispatch:

jobs:
  lint:
    uses: <org>/platform-pipelines/.github/workflows/reusable-tflint.yml@v1.0.0
    with:
      working-directory: .

  security:
    uses: <org>/platform-pipelines/.github/workflows/reusable-trivy.yml@v1.0.0
    with:
      working-directory: .

  plan:
    needs: [lint, security]
    uses: <org>/platform-pipelines/.github/workflows/reusable-lz-deploy-plan.yml@v1.0.0
    with:
      environment: management
    secrets:
      tfc-token: ${{ secrets.TF_API_TOKEN }}
```

```yaml
# .github/workflows/deploy-apply.yml in the same repo
name: management-lz deploy apply

on:
  push:
    branches: [main]
  workflow_dispatch:
    inputs:
      confirm:
        description: 'Type "apply" to confirm'
        type: string
        required: true
      allow_destroy:
        description: "Authorise a plan that destroys or replaces resources"
        type: boolean
        default: false

jobs:
  apply:
    uses: <org>/platform-pipelines/.github/workflows/reusable-lz-deploy-apply.yml@v1.0.0
    with:
      environment: management
      confirm: ${{ inputs.confirm }}
      allow_destroy: ${{ inputs.allow_destroy }}
    secrets:
      tfc-token: ${{ secrets.TF_API_TOKEN }}
```

Swap `environment: management` for `identity` / `security` / `firewall-management` / `connectivity` in each subscription's own pair of caller files — everything else here is copy-paste. There is no other sanctioned way to plan or apply against a subscription; module repos that need a plan/apply step (rather than `reusable-module-test.yml`'s mocked-provider test) go through this same pair too.

## Ownership

Changes here affect every consumer repo across all orgs. Require PR review from CODEOWNERS before merging, and validate changes against a pilot repo before bumping the floating major tag.
