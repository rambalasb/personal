module "role_assignment" {
  source  = "Azure/avm-res-authorization-roleassignment/azurerm"
  version = "0.3.0"

  role_assignments_azure_resource_manager = var.role_assignments_azure_resource_manager
  role_assignments_entra_id               = var.role_assignments_entra_id
}
