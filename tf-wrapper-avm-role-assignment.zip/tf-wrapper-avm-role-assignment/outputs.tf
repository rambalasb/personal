output "role_assignments" {
  description = "Map of ARM role assignments created, keyed by the input map key."
  value       = module.role_assignment.role_assignments
}

output "entra_id_role_assignments" {
  description = "Map of Entra ID directory role assignments created, keyed by the input map key."
  value       = module.role_assignment.entra_id_role_assignments
}

output "all_principals" {
  description = "Aggregate map of principals referenced across the role assignments."
  value       = module.role_assignment.all_principals
}
