# =====================================================================
# ARM (azurerm) role assignments
# =====================================================================

variable "role_assignments_azure_resource_manager" {
  type = map(object({
    role_definition_id                     = optional(string)
    role_definition_name                   = optional(string)
    principal_type                         = optional(string)
    principal_id                           = string
    scope                                  = string
    condition                              = optional(string)
    condition_version                      = optional(string)
    delegated_managed_identity_resource_id = optional(string)
    description                            = optional(string)
    skip_service_principal_aad_check       = optional(bool, false)
  }))
  description = "ARM role assignments to create, keyed by an arbitrary logical name. Supply principal_id, scope, and exactly one of role_definition_id or role_definition_name."
  default     = {}
}

# =====================================================================
# Entra ID (azuread) directory role assignments
# =====================================================================

variable "role_assignments_entra_id" {
  type = map(object({
    app_scope_id        = optional(string)
    directory_scope_id  = optional(string)
    principal_object_id = string
    role_id             = string
  }))
  description = "Entra ID directory role assignments to create, keyed by an arbitrary logical name. Supply principal_object_id and role_id."
  default     = {}
}
