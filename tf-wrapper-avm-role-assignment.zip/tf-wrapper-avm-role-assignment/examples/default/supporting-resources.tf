# random suffix to avoid name collisions on reruns
resource "random_string" "suffix" {
  length  = 6
  lower   = true
  upper   = false
  numeric = true
  special = false
}

# assign to the CI principal, not a hardcoded id
data "azurerm_client_config" "current" {}
