module "resource_group" {
  source = "../../../tf-wrapper-avm-resource-group"

  name     = "rg-avm-ra-default-test-${random_string.suffix.result}"
  location = "canadacentral"

  enable_telemetry = false
}

module "role_assignment" {
  source = "../.."

  role_assignments_azure_resource_manager = {
    reader = {
      principal_id         = data.azurerm_client_config.current.object_id
      principal_type       = "ServicePrincipal"
      scope                = module.resource_group.resource_id
      role_definition_name = "Reader"
    }
  }
}
