check "arm_role_defined_once" {
  assert {
    condition = alltrue([
      for _, ra in var.role_assignments_azure_resource_manager :
      (ra.role_definition_id != null) != (ra.role_definition_name != null)
    ])
    error_message = "Each ARM role assignment must set exactly one of role_definition_id or role_definition_name."
  }
}
