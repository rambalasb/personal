check "sku_supports_enabled_features" {
  assert {
    condition     = var.sku != "Basic" || length(local.enabled_standard_only) == 0
    error_message = "Bastion SKU is 'Basic' but these features need Standard or higher: ${join(", ", local.enabled_standard_only)}. Azure rejects the deployment rather than ignoring them."
  }
}

check "session_recording_requires_premium" {
  assert {
    condition     = var.session_recording_enabled == false || var.sku == "Premium"
    error_message = "session_recording_enabled is true but the SKU is '${var.sku}'. Session recording requires the Premium SKU."
  }
}

check "scale_units_fixed_on_basic" {
  assert {
    condition     = var.sku != "Basic" || var.scale_units == 2
    error_message = "Bastion SKU is 'Basic', which is fixed at 2 scale units. scale_units = ${var.scale_units} will be rejected."
  }
}

check "zonal_redundancy" {
  assert {
    condition     = length(var.zones) >= 2 || var.sku == "Developer"
    error_message = "Bastion Host is placed in ${length(var.zones)} zone(s). Use 2 or more for zonal resilience where the region supports it."
  }
}

check "shareable_link_is_deliberate" {
  assert {
    condition     = var.shareable_link_enabled == false
    error_message = "shareable_link_enabled is true. Shareable links grant access to a VM through a URL that bypasses Entra ID sign-in. Enable only with a documented justification."
  }
}
