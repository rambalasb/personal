# =====================================================================
# Required inputs
# =====================================================================

variable "name" {
  type        = string
  description = "Name of the Bastion Host. 1-80 chars; alphanumerics, underscores, periods, hyphens. Must start with alphanumeric and end with alphanumeric or underscore."

  validation {
    condition     = can(regex("^[a-zA-Z0-9][a-zA-Z0-9._-]{0,78}[a-zA-Z0-9_]$", var.name))
    error_message = "name must be 1-80 characters, alphanumerics/underscores/periods/hyphens, start with alphanumeric, end with alphanumeric or underscore."
  }
}

variable "parent_id" {
  type        = string
  description = "Resource ID of the Resource Group the Bastion Host is deployed into. This module takes the RG's resource ID, not its name — pass module.resource_group[key].resource_id."

  validation {
    condition     = can(regex("^/subscriptions/[^/]+/resourceGroups/[^/]+$", var.parent_id))
    error_message = "parent_id must be a resource group resource ID: /subscriptions/{sub}/resourceGroups/{rg}."
  }
}

variable "location" {
  type        = string
  description = "Azure region where the Bastion Host will be deployed."

  validation {
    condition     = length(var.location) > 0
    error_message = "location must not be empty."
  }
}

# =====================================================================
# SKU and capacity
# =====================================================================

variable "sku" {
  type        = string
  description = "Bastion SKU: 'Basic', 'Standard', 'Premium' or 'Developer'. Basic supports no optional features; Premium is required for session recording; Developer is free, shared, and has no dedicated subnet."
  default     = "Standard"

  validation {
    condition     = contains(["Basic", "Standard", "Premium", "Developer"], var.sku)
    error_message = "sku must be 'Basic', 'Standard', 'Premium' or 'Developer'."
  }
}

variable "scale_units" {
  type        = number
  description = "Number of scale units, 2-50. Each unit supports roughly 20 concurrent sessions. Fixed at 2 on the Basic SKU."
  default     = 2

  validation {
    condition     = var.scale_units >= 2 && var.scale_units <= 50
    error_message = "scale_units must be between 2 and 50."
  }
}

variable "zones" {
  type        = set(string)
  description = "Availability zones for the Bastion Host. Must be empty for the Developer SKU."
  default     = ["1", "2", "3"]

  validation {
    condition     = alltrue([for z in var.zones : contains(["1", "2", "3"], z)])
    error_message = "Each zone must be '1', '2', or '3'."
  }
}

variable "virtual_network_id" {
  type        = string
  description = "Resource ID of the virtual network the Developer SKU attaches to. Required for the Developer SKU and must be null for every other SKU."
  default     = null
}

# =====================================================================
# Networking
# =====================================================================

variable "ip_configuration" {
  type = object({
    name                             = optional(string)
    subnet_id                        = string
    create_public_ip                 = optional(bool, true)
    public_ip_tags                   = optional(map(string), null)
    public_ip_merge_with_module_tags = optional(bool, true)
    public_ip_address_name           = optional(string, null)
    public_ip_address_id             = optional(string, null)
  })
  description = "IP configuration for the Bastion Host. subnet_id must be a subnet literally named 'AzureBastionSubnet', at least /26. Set public_ip_address_id to attach an address this module does not own; leave create_public_ip true to have the module create one."
  default     = null

  validation {
    condition     = var.ip_configuration == null || can(regex("/subnets/AzureBastionSubnet$", try(var.ip_configuration.subnet_id, "")))
    error_message = "ip_configuration.subnet_id must reference a subnet named exactly 'AzureBastionSubnet'. Azure rejects any other name."
  }

  validation {
    condition     = var.ip_configuration == null || try(var.ip_configuration.public_ip_address_id, null) == null || try(var.ip_configuration.create_public_ip, true) == false
    error_message = "Set create_public_ip = false when supplying public_ip_address_id, otherwise the module creates an address that is then ignored."
  }
}

# =====================================================================
# Feature toggles
#    Every toggle below except copy_paste_enabled needs Standard or
#    higher; session recording needs Premium. See checks.tf.
# =====================================================================

variable "copy_paste_enabled" {
  type        = bool
  description = "Allow clipboard copy and paste in the session. Supported on every SKU."
  default     = true
}

variable "file_copy_enabled" {
  type        = bool
  description = "Allow file transfer through the session. Requires Standard or higher."
  default     = false
}

variable "ip_connect_enabled" {
  type        = bool
  description = "Allow connecting to a private IP directly rather than picking a VM. Requires Standard or higher."
  default     = false
}

variable "kerberos_enabled" {
  type        = bool
  description = "Enable Kerberos authentication. Requires Standard or higher."
  default     = false
}

variable "shareable_link_enabled" {
  type        = bool
  description = "Allow generating URLs that grant VM access without an Entra ID sign-in. Requires Standard or higher."
  default     = false
}

variable "tunneling_enabled" {
  type        = bool
  description = "Allow native client tunnelling (az network bastion tunnel / RDP and SSH clients). Requires Standard or higher."
  default     = false
}

variable "session_recording_enabled" {
  type        = bool
  description = "Record sessions to a storage account. Requires the Premium SKU."
  default     = false
}

variable "private_only_enabled" {
  type        = bool
  description = "Deploy without a public IP, reachable only over private connectivity. Requires Premium."
  default     = false
}

# =====================================================================
# Governance
# =====================================================================

variable "role_assignments" {
  type = map(object({
    role_definition_id_or_name             = string
    principal_id                           = string
    description                            = optional(string, null)
    skip_service_principal_aad_check       = optional(bool, false)
    condition                              = optional(string, null)
    condition_version                      = optional(string, null)
    delegated_managed_identity_resource_id = optional(string, null)
    principal_type                         = optional(string, null)
  }))
  description = "RBAC role assignments scoped to the Bastion Host. Common roles: 'Network Contributor', 'Reader'."
  default     = {}
}

variable "lock" {
  type = object({
    kind = string
    name = optional(string, null)
  })
  description = "Optional resource lock. kind must be 'CanNotDelete' or 'ReadOnly'."
  default     = null

  validation {
    condition     = var.lock == null || contains(["CanNotDelete", "ReadOnly"], try(var.lock.kind, ""))
    error_message = "lock.kind must be 'CanNotDelete' or 'ReadOnly' when lock is set."
  }
}

# =====================================================================
# Diagnostics
# =====================================================================

variable "diagnostic_settings" {
  type = map(object({
    name                                     = optional(string, null)
    log_categories                           = optional(set(string), [])
    log_groups                               = optional(set(string), ["allLogs"])
    metric_categories                        = optional(set(string), ["AllMetrics"])
    log_analytics_destination_type           = optional(string, "Dedicated")
    workspace_resource_id                    = optional(string, null)
    storage_account_resource_id              = optional(string, null)
    event_hub_authorization_rule_resource_id = optional(string, null)
    event_hub_name                           = optional(string, null)
    marketplace_partner_resource_id          = optional(string, null)
  }))
  description = "Diagnostic settings for the Bastion Host. BastionAuditLogs is the category that records who connected to what."
  default     = {}
}

# =====================================================================
# Module behavior
# =====================================================================

variable "enable_telemetry" {
  type        = bool
  description = "Whether to enable AVM module telemetry. Set false to opt out."
  default     = true
}

variable "tags" {
  type        = map(string)
  description = "A map of tags to apply to the Bastion Host."
  default     = null
}
