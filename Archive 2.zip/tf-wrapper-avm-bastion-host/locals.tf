locals {
  module_tags = merge(
    var.tags == null ? {} : var.tags,
    {
      managed-by = "terraform"
      module     = "tf-wrapper-avm-bastion-host"
    }
  )

  # Basic supports none of these; Premium is required for session recording.
  standard_only_features = {
    file_copy_enabled         = var.file_copy_enabled
    ip_connect_enabled        = var.ip_connect_enabled
    shareable_link_enabled    = var.shareable_link_enabled
    tunneling_enabled         = var.tunneling_enabled
    kerberos_enabled          = var.kerberos_enabled
    session_recording_enabled = var.session_recording_enabled
  }

  enabled_standard_only = [for k, v in local.standard_only_features : k if v == true]
}
