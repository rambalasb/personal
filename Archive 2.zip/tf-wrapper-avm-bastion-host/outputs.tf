output "resource_id" {
  description = "The Azure resource ID of the Bastion Host."
  value       = module.bastion_host.resource_id
}

output "name" {
  description = "The name of the Bastion Host."
  value       = module.bastion_host.name
}

output "dns_name" {
  description = "The FQDN of the Bastion Host."
  value       = module.bastion_host.dns_name
}

output "resource" {
  description = "The full Bastion Host resource object. Note this is an azapi_resource, not an azurerm_bastion_host."
  value       = module.bastion_host.resource
}
