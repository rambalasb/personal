# random suffix to avoid name collisions on reruns
resource "random_string" "suffix" {
  length  = 6
  lower   = true
  upper   = false
  numeric = true
  special = false
}

# native supporting resources so the example tests standalone
resource "azurerm_resource_group" "this" {
  name     = "rg-avm-bastion-default-test-${random_string.suffix.result}"
  location = "canadacentral"
}

resource "azurerm_virtual_network" "this" {
  name                = "vnet-avm-bastion-test-${random_string.suffix.result}"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location
  address_space       = ["10.60.0.0/16"]
}

# Azure requires this exact name and a minimum of /26 for Standard.
resource "azurerm_subnet" "bastion" {
  name                 = "AzureBastionSubnet"
  resource_group_name  = azurerm_resource_group.this.name
  virtual_network_name = azurerm_virtual_network.this.name
  address_prefixes     = ["10.60.1.0/26"]
}
