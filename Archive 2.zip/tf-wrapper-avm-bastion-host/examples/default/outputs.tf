output "resource_id" {
  value = module.bastion_host.resource_id
}

output "dns_name" {
  value = module.bastion_host.dns_name
}
