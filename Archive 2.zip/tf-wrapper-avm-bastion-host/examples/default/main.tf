module "bastion_host" {
  source = "../.."

  name      = "bas-avm-default-test-${random_string.suffix.result}"
  parent_id = azurerm_resource_group.this.id
  location  = azurerm_resource_group.this.location

  ip_configuration = {
    name      = "ipconfig"
    subnet_id = azurerm_subnet.bastion.id
  }

  enable_telemetry = false
}
