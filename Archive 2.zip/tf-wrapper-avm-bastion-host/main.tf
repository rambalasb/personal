module "bastion_host" {
  source  = "Azure/avm-res-network-bastionhost/azurerm"
  version = "0.9.0"

  # Required. parent_id is the resource group's resource ID, not its name.
  name      = var.name
  parent_id = var.parent_id
  location  = var.location

  # SKU and capacity
  sku                = var.sku
  scale_units        = var.scale_units
  zones              = var.zones
  virtual_network_id = var.virtual_network_id

  # Networking
  ip_configuration = var.ip_configuration

  # Feature toggles. Each requires Standard or Premium; see checks.tf.
  copy_paste_enabled        = var.copy_paste_enabled
  file_copy_enabled         = var.file_copy_enabled
  ip_connect_enabled        = var.ip_connect_enabled
  kerberos_enabled          = var.kerberos_enabled
  shareable_link_enabled    = var.shareable_link_enabled
  tunneling_enabled         = var.tunneling_enabled
  session_recording_enabled = var.session_recording_enabled
  private_only_enabled      = var.private_only_enabled

  # Governance
  role_assignments = var.role_assignments
  lock             = var.lock

  # Diagnostics
  diagnostic_settings = var.diagnostic_settings

  # Module behavior
  enable_telemetry = var.enable_telemetry
  tags             = local.module_tags
}
