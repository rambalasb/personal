output "resource_id" {
  value = module.cognitive_services_account.resource_id
}

output "endpoint" {
  value = module.cognitive_services_account.endpoint
}

output "deployments" {
  value = module.cognitive_services_account.resource_cognitive_deployment
}
