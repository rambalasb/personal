module "cognitive_services_account" {
  source = "../.."

  name      = "cog-avm-default-test-${random_string.suffix.result}"
  parent_id = azurerm_resource_group.this.id
  location  = azurerm_resource_group.this.location
  kind      = "OpenAI"
  sku_name  = "S0"

  # Required for token auth and for any private endpoint.
  custom_subdomain_name = "cog-avm-default-test-${random_string.suffix.result}"

  # Entra ID only, no public data plane.
  local_auth_enabled            = false
  public_network_access_enabled = false

  rai_policies = {
    "strict" = {
      name             = "strict"
      base_policy_name = "Microsoft.DefaultV2"
      mode             = "Blocking"
    }
  }

  cognitive_deployments = {
    "gpt-4o-mini" = {
      name            = "gpt-4o-mini"
      rai_policy_name = "strict"
      model = {
        format = "OpenAI"
        name   = "gpt-4o-mini"
      }
      scale = {
        type     = "GlobalStandard"
        capacity = 10
      }
    }
  }

  enable_telemetry = false
}
