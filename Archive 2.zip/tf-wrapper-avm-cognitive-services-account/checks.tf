check "local_auth_disabled" {
  assert {
    condition     = var.local_auth_enabled == false
    error_message = "local_auth_enabled is not false, so the account's API keys are live. Keys are long-lived shared secrets with no per-caller attribution — prefer Entra ID and set local_auth_enabled = false."
  }
}

check "public_network_access_closed" {
  assert {
    condition     = var.public_network_access_enabled == false
    error_message = "public_network_access_enabled is true, so the account answers from the internet. Set it false and reach the account over a private endpoint."
  }
}

check "network_acls_default_deny" {
  assert {
    condition     = var.network_acls == null || try(var.network_acls.default_action, "") == "Deny"
    error_message = "network_acls.default_action is 'Allow', which permits every source not explicitly blocked. 'Deny' with explicit rules is the safe direction."
  }
}

check "not_free_tier" {
  assert {
    condition     = local.free_tier == false
    error_message = "sku_name is '${var.sku_name}'. Free tiers are limited to one instance per subscription per kind and carry no SLA — they are not suitable outside a sandbox."
  }
}

check "custom_subdomain_set" {
  assert {
    condition     = var.custom_subdomain_name != null
    error_message = "custom_subdomain_name is unset. Token-based authentication and private endpoints both require it, and adding it later forces the account to be recreated."
  }
}

check "deployments_declare_a_content_filter" {
  assert {
    condition = alltrue([
      for d in values(var.cognitive_deployments) : try(d.rai_policy_name, null) != null
    ])
    error_message = "One or more model deployments have no rai_policy_name, so they fall back to Azure's default content filter. Name a policy explicitly so the filtering level is recorded in config."
  }
}

check "deployment_serialization_on_for_multiple_deployments" {
  assert {
    condition     = length(var.cognitive_deployments) < 2 || var.deployment_serialization_enabled
    error_message = "${length(var.cognitive_deployments)} deployments are declared with deployment_serialization_enabled = false. Azure rejects concurrent deployment writes on one account, so the apply will fail intermittently."
  }
}

check "private_endpoints_not_double_owned" {
  assert {
    condition     = length(var.private_endpoints) == 0
    error_message = "private_endpoints is set on the account. The tf-deploy-app-* repos declare endpoints through tf-wrapper-avm-private-endpoint as their own tier; declaring one in both places gives a single Azure resource two Terraform owners. Use one or the other."
  }
}

check "customer_managed_key_present" {
  assert {
    condition     = var.customer_managed_key != null
    error_message = "No customer-managed key is configured, so the account uses a Microsoft-managed key. Acceptable for many workloads — confirm it meets the data classification for what this account processes."
  }
}
