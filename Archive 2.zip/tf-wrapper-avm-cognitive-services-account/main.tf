module "cognitive_services_account" {
  source  = "Azure/avm-res-cognitiveservices-account/azurerm"
  version = "0.11.1"

  # Required. parent_id is the resource group's resource ID, not its name.
  name      = var.name
  parent_id = var.parent_id
  location  = var.location
  kind      = var.kind
  sku_name  = var.sku_name

  # Access
  custom_subdomain_name              = var.custom_subdomain_name
  public_network_access_enabled      = var.public_network_access_enabled
  local_auth_enabled                 = var.local_auth_enabled
  outbound_network_access_restricted = var.outbound_network_access_restricted
  fqdns                              = var.fqdns
  network_acls                       = var.network_acls

  # Identity
  managed_identities = var.managed_identities

  # Model deployments and content safety
  cognitive_deployments            = var.cognitive_deployments
  deployment_serialization_enabled = var.deployment_serialization_enabled
  dynamic_throttling_enabled       = var.dynamic_throttling_enabled
  rai_policies                     = var.rai_policies
  rai_monitor_config               = var.rai_monitor_config

  # Private networking
  private_endpoints                       = var.private_endpoints
  private_endpoints_manage_dns_zone_group = var.private_endpoints_manage_dns_zone_group
  network_injections                      = var.network_injections

  # Encryption and linked storage
  customer_managed_key = var.customer_managed_key
  is_hsm_key           = var.is_hsm_key
  storage              = var.storage

  # AI Foundry projects
  allow_project_management = var.allow_project_management
  associated_projects      = var.associated_projects
  default_project          = var.default_project
  aml_workspace            = var.aml_workspace

  # Kind-specific settings
  custom_question_answering_search_service_id  = var.custom_question_answering_search_service_id
  custom_question_answering_search_service_key = var.custom_question_answering_search_service_key
  qna_runtime_endpoint                         = var.qna_runtime_endpoint
  metrics_advisor_aad_client_id                = var.metrics_advisor_aad_client_id
  metrics_advisor_aad_tenant_id                = var.metrics_advisor_aad_tenant_id
  metrics_advisor_super_user_name              = var.metrics_advisor_super_user_name
  metrics_advisor_website_name                 = var.metrics_advisor_website_name

  # Governance
  role_assignments = var.role_assignments
  lock             = var.lock

  # Diagnostics
  diagnostic_settings = var.diagnostic_settings

  # Module behavior
  enable_telemetry = var.enable_telemetry
  tags             = local.module_tags
  retry            = var.retry
  timeouts         = var.timeouts
}
