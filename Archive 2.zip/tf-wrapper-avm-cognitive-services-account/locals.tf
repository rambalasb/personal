locals {
  module_tags = merge(
    var.tags == null ? {} : var.tags,
    {
      managed-by = "terraform"
      module     = "tf-wrapper-avm-cognitive-services-account"
    }
  )

  # Free tiers are single-instance per subscription and carry no SLA.
  free_tier = can(regex("^F", var.sku_name))
}
