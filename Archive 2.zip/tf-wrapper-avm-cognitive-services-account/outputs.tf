output "resource_id" {
  description = "The Azure resource ID of the Cognitive Services account."
  value       = module.cognitive_services_account.resource_id
}

output "name" {
  description = "The name of the Cognitive Services account."
  value       = module.cognitive_services_account.name
}

output "endpoint" {
  description = "The account's API endpoint."
  value       = module.cognitive_services_account.endpoint
}

output "system_assigned_mi_principal_id" {
  description = "Principal ID of the system-assigned managed identity, or null when one was not requested."
  value       = module.cognitive_services_account.system_assigned_mi_principal_id
}

output "primary_access_key" {
  description = "Primary API key. Empty when local_auth_enabled is false; prefer Entra ID authentication over consuming this."
  value       = module.cognitive_services_account.primary_access_key
  sensitive   = true
}

output "secondary_access_key" {
  description = "Secondary API key. Empty when local_auth_enabled is false."
  value       = module.cognitive_services_account.secondary_access_key
  sensitive   = true
}

output "resource_cognitive_deployment" {
  description = "The deployed models, keyed by the cognitive_deployments map key."
  value       = module.cognitive_services_account.resource_cognitive_deployment
}

output "rai_policy_id" {
  description = "Resource IDs of the Responsible AI policies, keyed by the rai_policies map key."
  value       = module.cognitive_services_account.rai_policy_id
}

output "private_endpoints" {
  description = "Private endpoints the module owns, keyed by the private_endpoints map key. Empty when endpoints are declared through tf-wrapper-avm-private-endpoint instead."
  value       = module.cognitive_services_account.private_endpoints
}

output "resource" {
  description = "The full account resource object. Note this is an azapi_resource, not an azurerm_cognitive_account."
  value       = module.cognitive_services_account.resource
}
