# =====================================================================
# Required inputs
# =====================================================================

variable "name" {
  type        = string
  description = "Name of the Cognitive Services account. 2-64 chars; alphanumerics and hyphens, cannot start or end with a hyphen."

  validation {
    condition     = can(regex("^[a-zA-Z0-9][a-zA-Z0-9-]{0,62}[a-zA-Z0-9]$", var.name))
    error_message = "name must be 2-64 characters of alphanumerics and hyphens, and cannot start or end with a hyphen."
  }
}

variable "parent_id" {
  type        = string
  description = "Resource ID of the Resource Group the account is deployed into. This module takes the RG's resource ID, not its name — pass module.resource_group[key].resource_id."

  validation {
    condition     = can(regex("^/subscriptions/[^/]+/resourceGroups/[^/]+$", var.parent_id))
    error_message = "parent_id must be a resource group resource ID: /subscriptions/{sub}/resourceGroups/{rg}."
  }
}

variable "location" {
  type        = string
  description = "Azure region where the account will be deployed."

  validation {
    condition     = length(var.location) > 0
    error_message = "location must not be empty."
  }
}

variable "kind" {
  type        = string
  description = "Service type, for example 'OpenAI', 'AIServices', 'CognitiveServices', 'ComputerVision', 'FormRecognizer', 'Speech', 'TextAnalytics', 'ContentSafety'. Changing this forces a new resource."

  validation {
    condition     = length(var.kind) > 0
    error_message = "kind must not be empty."
  }
}

variable "sku_name" {
  type        = string
  description = "SKU, for example 'S0' or 'F0'. F-tier is free, limited to one instance per subscription per kind, and carries no SLA."

  validation {
    condition     = can(regex("^(F[0-1]|S[0-6]?|P[0-2]|E0|DC0)$", var.sku_name))
    error_message = "sku_name must be one of F0, F1, S, S0-S6, P0-P2, E0, DC0."
  }
}

# =====================================================================
# Access
# =====================================================================

variable "custom_subdomain_name" {
  type        = string
  description = "Subdomain used for token-based authentication, producing <name>.cognitiveservices.azure.com. Required when network_acls is set and when a private endpoint is attached. Changing this forces a new resource."
  default     = null

  validation {
    condition     = var.custom_subdomain_name == null || can(regex("^[a-z0-9][a-z0-9-]{1,61}[a-z0-9]$", var.custom_subdomain_name))
    error_message = "custom_subdomain_name must be 3-63 characters, lowercase alphanumerics and hyphens, starting and ending alphanumeric."
  }
}

variable "public_network_access_enabled" {
  type        = bool
  description = "Whether the account is reachable from the public internet. Set false when reaching it over a private endpoint."
  default     = true
}

variable "local_auth_enabled" {
  type        = bool
  description = "Whether the account's API keys work. Set false to force Entra ID authentication only."
  default     = null
}

variable "outbound_network_access_restricted" {
  type        = bool
  description = "Restrict the account's own outbound calls to the hosts listed in fqdns."
  default     = null
}

variable "fqdns" {
  type        = list(string)
  description = "Hosts the account may call outbound. Only read when outbound_network_access_restricted is true."
  default     = null
}

variable "network_acls" {
  type = object({
    default_action = string
    ip_rules       = optional(set(string))
    virtual_network_rules = optional(set(object({
      ignore_missing_vnet_service_endpoint = optional(bool)
      subnet_id                            = string
    })))
    bypass = optional(string)
  })
  description = "Network access rules. default_action is 'Allow' or 'Deny'. Setting this requires custom_subdomain_name."
  default     = null

  validation {
    condition     = var.network_acls == null || contains(["Allow", "Deny"], try(var.network_acls.default_action, ""))
    error_message = "network_acls.default_action must be 'Allow' or 'Deny'."
  }

  # Azure rejects the create when the account has no custom subdomain.
  validation {
    condition     = var.network_acls == null || var.custom_subdomain_name != null
    error_message = "custom_subdomain_name is required when network_acls is set."
  }
}

# =====================================================================
# Identity
# =====================================================================

variable "managed_identities" {
  type = object({
    system_assigned            = optional(bool, false)
    user_assigned_resource_ids = optional(set(string), [])
  })
  description = "Managed identities for the account. A customer-managed key requires one."
  default     = {}
}

# =====================================================================
# Governance
# =====================================================================

variable "role_assignments" {
  type = map(object({
    role_definition_id_or_name             = string
    principal_id                           = string
    description                            = optional(string, null)
    skip_service_principal_aad_check       = optional(bool, false)
    condition                              = optional(string, null)
    condition_version                      = optional(string, null)
    delegated_managed_identity_resource_id = optional(string, null)
    principal_type                         = optional(string, null)
  }))
  description = "RBAC role assignments scoped to the account. Common roles: 'Cognitive Services User', 'Cognitive Services OpenAI User', 'Reader'."
  default     = {}
}

variable "lock" {
  type = object({
    kind = string
    name = optional(string, null)
  })
  description = "Optional resource lock. kind must be 'CanNotDelete' or 'ReadOnly'."
  default     = null

  validation {
    condition     = var.lock == null || contains(["CanNotDelete", "ReadOnly"], try(var.lock.kind, ""))
    error_message = "lock.kind must be 'CanNotDelete' or 'ReadOnly' when lock is set."
  }
}

# =====================================================================
# Diagnostics
# =====================================================================

variable "diagnostic_settings" {
  type = map(object({
    name                                     = optional(string, null)
    log_categories                           = optional(set(string), [])
    log_groups                               = optional(set(string), ["allLogs"])
    metric_categories                        = optional(set(string), ["AllMetrics"])
    log_analytics_destination_type           = optional(string, "Dedicated")
    workspace_resource_id                    = optional(string, null)
    storage_account_resource_id              = optional(string, null)
    event_hub_authorization_rule_resource_id = optional(string, null)
    event_hub_name                           = optional(string, null)
    marketplace_partner_resource_id          = optional(string, null)
  }))
  description = "Diagnostic settings for the account. Audit and RequestResponse are the categories that record prompt and response metadata."
  default     = {}
}

# =====================================================================
# Module behavior
# =====================================================================

variable "enable_telemetry" {
  type        = bool
  description = "Whether to enable AVM module telemetry. Set false to opt out."
  default     = true
}

variable "tags" {
  type        = map(string)
  description = "A map of tags to apply to the account."
  default     = null
}

# =====================================================================
# Model deployments and content safety
# =====================================================================

variable "cognitive_deployments" {
  type = map(object({
    name                       = string
    rai_policy_name            = optional(string)
    version_upgrade_option     = optional(string, "OnceNewDefaultVersionAvailable")
    dynamic_throttling_enabled = optional(bool, false)
    model = object({
      format  = string
      name    = string
      version = optional(string)
    })
    scale = object({
      capacity = optional(number, 1)
      family   = optional(string)
      size     = optional(string)
      tier     = optional(string)
      type     = string
    })
    retry = optional(object({
      error_message_regex  = list(string)
      interval_seconds     = optional(number, 30)
      max_interval_seconds = optional(number, 300)
      multiplier           = optional(number, 1.5)
      randomization_factor = optional(number, 0.3)
    }))
    timeouts = optional(object({
      create = optional(string)
      delete = optional(string)
      read   = optional(string)
      update = optional(string)
    }))
  }))
  description = "Model deployments on the account, keyed by deployment identifier. model.format is 'OpenAI' for OpenAI models; scale.type is 'Standard', 'GlobalStandard', 'DataZoneStandard' or 'ProvisionedManaged'. scale.capacity is in thousands of tokens per minute for the Standard types."
  default     = {}

  validation {
    condition = alltrue([
      for d in values(var.cognitive_deployments) :
      contains(["OnceNewDefaultVersionAvailable", "OnceCurrentVersionExpired", "NoAutoUpgrade"], d.version_upgrade_option)
    ])
    error_message = "version_upgrade_option must be 'OnceNewDefaultVersionAvailable', 'OnceCurrentVersionExpired' or 'NoAutoUpgrade'."
  }

  # Deployment names are what callers put in the request path, so a rename is a breaking change for them.
  validation {
    condition = alltrue([
      for d in values(var.cognitive_deployments) : can(regex("^[a-zA-Z0-9][a-zA-Z0-9._-]{0,62}$", d.name))
    ])
    error_message = "Each deployment name must be 1-63 characters of alphanumerics, periods, underscores and hyphens, starting alphanumeric."
  }
}

variable "deployment_serialization_enabled" {
  type        = bool
  description = "Create deployments one at a time. Azure rejects concurrent deployment writes on the same account, so leaving this true is usually required when cognitive_deployments holds more than one entry."
  default     = true
}

variable "dynamic_throttling_enabled" {
  type        = bool
  description = "Account-level dynamic quota. Lets Azure lend spare capacity above the provisioned rate, at the cost of unpredictable throughput."
  default     = false
}

variable "rai_policies" {
  type = map(object({
    name             = string
    base_policy_name = string
    mode             = string
    content_filters = optional(list(object({
      blocking           = bool
      enabled            = bool
      name               = string
      severity_threshold = string
      source             = string
    })))
    custom_block_lists = optional(list(object({
      source          = string
      block_list_name = string
      blocking        = bool
    })))
    retry = optional(object({
      error_message_regex  = optional(list(string))
      interval_seconds     = optional(number)
      max_interval_seconds = optional(number)
      multiplier           = optional(number)
      randomization_factor = optional(number)
    }))
    timeouts = optional(object({
      create = optional(string)
      delete = optional(string)
      read   = optional(string)
      update = optional(string)
    }))
  }))
  description = "Responsible AI content-filter policies, keyed by policy identifier. base_policy_name is usually 'Microsoft.Default' or 'Microsoft.DefaultV2'. mode is 'Default', 'Blocking' or 'Asynchronous_filter'. Referenced from a deployment by rai_policy_name."
  default     = {}

  validation {
    condition = alltrue([
      for p in values(var.rai_policies) : contains(["Default", "Blocking", "Asynchronous_filter"], p.mode)
    ])
    error_message = "Each RAI policy mode must be 'Default', 'Blocking' or 'Asynchronous_filter'."
  }
}

variable "rai_monitor_config" {
  type = object({
    adx_storage_resource_id = string
    identity_client_id      = optional(string, null)
  })
  description = "Azure Data Explorer destination for Responsible AI monitoring data."
  default     = null
}

# =====================================================================
# Private endpoints
#    Prefer the separate private_endpoint tier in the tf-deploy-app-*
#    repos. Declaring an endpoint here and again there gives one Azure
#    resource two Terraform owners, which fights on every apply.
# =====================================================================

variable "private_endpoints" {
  type = map(object({
    name = optional(string, null)
    role_assignments = optional(map(object({
      role_definition_id_or_name             = string
      principal_id                           = string
      description                            = optional(string, null)
      skip_service_principal_aad_check       = optional(bool, false)
      condition                              = optional(string, null)
      condition_version                      = optional(string, null)
      delegated_managed_identity_resource_id = optional(string, null)
      principal_type                         = optional(string, null)
    })), {})
    lock = optional(object({
      kind = string
      name = optional(string, null)
    }), null)
    tags                                    = optional(map(string), null)
    subnet_resource_id                      = string
    private_dns_zone_group_name             = optional(string, "default")
    private_dns_zone_resource_ids           = optional(set(string), [])
    application_security_group_associations = optional(map(string), {})
    private_service_connection_name         = optional(string, null)
    network_interface_name                  = optional(string, null)
    location                                = optional(string, null)
    resource_group_name                     = optional(string, null)
    ip_configurations = optional(map(object({
      name               = string
      private_ip_address = string
    })), {})
  }))
  description = "Private endpoints the module owns, keyed by endpoint identifier. Requires custom_subdomain_name. Leave empty when the endpoint is declared through tf-wrapper-avm-private-endpoint instead."
  default     = {}

  validation {
    condition     = length(var.private_endpoints) == 0 || var.custom_subdomain_name != null
    error_message = "custom_subdomain_name is required when private_endpoints is set — a private endpoint resolves against the custom subdomain."
  }
}

variable "private_endpoints_manage_dns_zone_group" {
  type        = bool
  description = "Let the module manage the private DNS zone group on its endpoints. Set false when Azure Policy creates the zone group, otherwise the two overwrite each other."
  default     = true
}

variable "network_injections" {
  type = object({
    subnet_id                         = string
    scenario                          = string
    microsoft_managed_network_enabled = optional(bool, false)
  })
  description = "Inject the account's compute into a delegated subnet. scenario is 'agent' for Foundry agent workloads. Distinct from a private endpoint: this places the service's own egress in your network."
  default     = null
}

# =====================================================================
# Encryption and linked storage
# =====================================================================

variable "customer_managed_key" {
  type = object({
    key_vault_resource_id = string
    key_name              = string
    key_version           = optional(string, null)
    user_assigned_identity = optional(object({
      resource_id = string
    }), null)
  })
  description = "Customer-managed key for encryption at rest. Requires a managed identity with Key Vault Crypto Service Encryption User on the vault. Leave key_version null to auto-rotate with the key."
  default     = null

  validation {
    condition     = var.customer_managed_key == null || var.managed_identities.system_assigned == true || length(var.managed_identities.user_assigned_resource_ids) > 0
    error_message = "customer_managed_key requires a managed identity — set managed_identities.system_assigned = true or supply user_assigned_resource_ids."
  }
}

variable "is_hsm_key" {
  type        = bool
  description = "Whether the customer-managed key lives in a Managed HSM rather than a standard Key Vault."
  default     = false
}

variable "storage" {
  type = list(object({
    identity_client_id = optional(string)
    storage_account_id = string
  }))
  description = "Storage accounts attached to the account, for kinds that persist artefacts such as FormRecognizer training data."
  default     = null
}

# =====================================================================
# AI Foundry projects
# =====================================================================

variable "allow_project_management" {
  type        = bool
  description = "Whether the account can host AI Foundry projects. Only meaningful for kind = 'AIServices'."
  default     = false
}

variable "associated_projects" {
  type        = list(string)
  description = "Names of AI Foundry projects associated with the account."
  default     = []
}

variable "default_project" {
  type        = string
  description = "Name of the default AI Foundry project."
  default     = null
}

variable "aml_workspace" {
  type = object({
    resource_id        = string
    identity_client_id = optional(string, null)
  })
  description = "Azure Machine Learning workspace linked to the account."
  default     = null
}

# =====================================================================
# Kind-specific settings
#    Each of these is read only by the kind named in its description.
# =====================================================================

variable "custom_question_answering_search_service_id" {
  type        = string
  description = "Cognitive Search service backing custom question answering. Read only when kind is 'TextAnalytics'."
  default     = null
}

variable "custom_question_answering_search_service_key" {
  type        = string
  description = "Admin key for the Cognitive Search service backing custom question answering. Prefer an RBAC grant on the search service over supplying a key here."
  default     = null
  sensitive   = true
}

variable "qna_runtime_endpoint" {
  type        = string
  description = "Runtime endpoint URL. Required when kind is 'QnAMaker'."
  default     = null
}

variable "metrics_advisor_aad_client_id" {
  type        = string
  description = "Entra application client ID. Read only when kind is 'MetricsAdvisor'."
  default     = null
}

variable "metrics_advisor_aad_tenant_id" {
  type        = string
  description = "Entra tenant ID. Read only when kind is 'MetricsAdvisor'."
  default     = null
}

variable "metrics_advisor_super_user_name" {
  type        = string
  description = "Super user name. Read only when kind is 'MetricsAdvisor'."
  default     = null
}

variable "metrics_advisor_website_name" {
  type        = string
  description = "Website name. Read only when kind is 'MetricsAdvisor'."
  default     = null
}

# =====================================================================
# Provider behavior
# =====================================================================

variable "retry" {
  type = object({
    error_message_regex  = optional(list(string))
    interval_seconds     = optional(number)
    max_interval_seconds = optional(number)
    multiplier           = optional(number)
    randomization_factor = optional(number)
  })
  description = "Retry behaviour for the underlying azapi calls. Useful for the throttling Azure returns while a quota change settles."
  default     = null
}

variable "timeouts" {
  type = object({
    create = optional(string)
    delete = optional(string)
    read   = optional(string)
    update = optional(string)
  })
  description = "Per-operation timeouts. Provisioned deployments can exceed the default create timeout."
  default     = null
}
