module "maintenance_configuration" {
  source  = "Azure/avm-res-maintenance-maintenanceconfiguration/azurerm"
  version = "0.1.0"

  # Required
  name                = var.name
  resource_group_name = var.resource_group_name
  location            = var.location
  scope               = var.scope

  # Schedule
  window     = var.window
  visibility = var.visibility

  # Scope-specific payloads
  install_patches      = var.install_patches
  extension_properties = var.extension_properties

  # Governance
  role_assignments = var.role_assignments
  lock             = var.lock

  # Module behavior
  subscription_id  = var.subscription_id
  enable_telemetry = var.enable_telemetry
  tags             = local.module_tags
}
