module "maintenance_configuration" {
  source = "../.."

  # Hyphens are rejected by this resource type.
  name                = "mc_avm_default_test_${random_string.suffix.result}"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location
  scope               = "InGuestPatch"

  window = {
    start_date_time = "2026-10-01 02:00"
    duration        = "03:00"
    recur_every     = "1Week"
    time_zone       = "Pacific Standard Time"
  }

  install_patches = {
    reboot_setting = "IfRequired"
    linux = {
      classifications_to_include = ["Critical", "Security"]
    }
    windows = {
      classifications_to_include = ["Critical", "Security"]
    }
  }

  enable_telemetry = false
}
