output "resource_id" {
  value = module.maintenance_configuration.resource_id
}

output "name" {
  value = module.maintenance_configuration.name
}
