output "resource_id" {
  description = "The Azure resource ID of the Maintenance Configuration."
  value       = module.maintenance_configuration.resource_id
}

output "name" {
  description = "The name of the Maintenance Configuration."
  value       = module.maintenance_configuration.name
}
