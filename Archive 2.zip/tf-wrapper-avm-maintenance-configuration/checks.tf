check "window_present" {
  assert {
    condition     = var.window != null
    error_message = "Maintenance configuration has no window, so it will never run. Scopes other than 'Host' require a schedule to have any effect."
  }
}

check "in_guest_patch_declares_patch_behaviour" {
  assert {
    condition     = !local.in_guest_patch || try(var.install_patches.linux, null) != null || try(var.install_patches.windows, null) != null
    error_message = "scope is 'InGuestPatch' but install_patches declares neither a linux nor a windows block, so no classifications are selected and nothing is patched."
  }
}

check "extension_scope_declares_properties" {
  assert {
    condition     = var.scope != "Extension" || length(var.extension_properties) > 0
    error_message = "scope is 'Extension' but extension_properties is empty. Azure requires the extension payload for this scope."
  }
}

check "reboot_setting_is_explicit_for_guest_patching" {
  assert {
    condition     = !local.in_guest_patch || try(var.install_patches.reboot_setting, null) != null
    error_message = "scope is 'InGuestPatch' but reboot_setting is unset, so Azure decides whether to reboot. Set it explicitly to 'Always', 'IfRequired' or 'Never'."
  }
}

check "visibility_is_custom" {
  assert {
    condition     = var.visibility == "Custom"
    error_message = "visibility is '${var.visibility}'. Azure only accepts 'Custom' for customer-defined maintenance configurations."
  }
}
