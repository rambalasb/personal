# =====================================================================
# Required inputs
# =====================================================================

variable "name" {
  type        = string
  description = "Name of the Maintenance Configuration. 1-64 chars; alphanumerics and underscores. Hyphens are not accepted by this resource type."

  validation {
    condition     = can(regex("^[a-zA-Z0-9_]{1,64}$", var.name))
    error_message = "name must be 1-64 characters of alphanumerics and underscores. Maintenance configurations reject hyphens."
  }
}

variable "resource_group_name" {
  type        = string
  description = "Name of the Resource Group where the Maintenance Configuration will be deployed."

  validation {
    condition     = length(var.resource_group_name) > 0 && length(var.resource_group_name) <= 90
    error_message = "resource_group_name must be 1-90 characters."
  }
}

variable "location" {
  type        = string
  description = "Azure region where the Maintenance Configuration will be deployed."

  validation {
    condition     = length(var.location) > 0
    error_message = "location must not be empty."
  }
}

variable "scope" {
  type        = string
  description = "What the configuration maintains: 'InGuestPatch' for OS patching inside VMs, 'Host' for the underlying host, 'OSImage' for image upgrades, 'Extension', 'Resource', 'SQLDB' or 'SQLManagedInstance'. Changing this forces a new resource."

  validation {
    condition     = contains(["Extension", "Host", "InGuestPatch", "OSImage", "Resource", "SQLDB", "SQLManagedInstance"], var.scope)
    error_message = "scope must be one of: Extension, Host, InGuestPatch, OSImage, Resource, SQLDB, SQLManagedInstance."
  }
}

# =====================================================================
# Schedule
# =====================================================================

variable "window" {
  type = object({
    duration             = optional(string, "01:30")
    expiration_date_time = optional(string)
    recur_every          = string
    start_date_time      = string
    time_zone            = string
  })
  description = "The maintenance window. start_date_time and expiration_date_time are 'YYYY-MM-DD hh:mm'. recur_every takes forms like '1Day', '2Weeks', 'Month Third Sunday'. time_zone is a Windows time zone name, for example 'Pacific Standard Time'."
  default     = null

  validation {
    condition     = var.window == null || can(regex("^[0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}$", try(var.window.start_date_time, "")))
    error_message = "window.start_date_time must be in 'YYYY-MM-DD hh:mm' format."
  }

  validation {
    condition     = var.window == null || try(var.window.expiration_date_time, null) == null || can(regex("^[0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}$", var.window.expiration_date_time))
    error_message = "window.expiration_date_time must be in 'YYYY-MM-DD hh:mm' format when set."
  }

  # Azure enforces both ends of this range.
  validation {
    condition     = var.window == null || can(regex("^([0-9]{2}):([0-9]{2})$", try(var.window.duration, "01:30")))
    error_message = "window.duration must be in 'HH:mm' format. Azure accepts 01:30 through 03:55 for guest patching."
  }
}

variable "visibility" {
  type        = string
  description = "Visibility of the configuration. 'Custom' is the only value Azure accepts for customer-defined configurations."
  default     = "Custom"

  validation {
    condition     = contains(["Custom", "Public"], var.visibility)
    error_message = "visibility must be 'Custom' or 'Public'. Use 'Custom' unless you are reading a built-in configuration."
  }
}

# =====================================================================
# Scope-specific payloads
# =====================================================================

variable "install_patches" {
  type = object({
    linux = optional(object({
      classifications_to_include    = optional(list(string), ["Critical", "Security"])
      package_name_masks_to_exclude = optional(list(string), [])
      package_name_masks_to_include = optional(list(string), [])
    }))
    reboot_setting = optional(string)
    windows = optional(object({
      classifications_to_include   = optional(list(string), ["Critical", "Security"])
      exclude_kbs_requiring_reboot = optional(bool)
      kb_numbers_to_exclude        = optional(list(string), [])
      kb_numbers_to_include        = optional(list(string), [])
    }))
  })
  description = "Guest patching behaviour. Only read when scope is 'InGuestPatch'. reboot_setting is 'Always', 'IfRequired' or 'Never'."
  default     = {}

  validation {
    condition     = try(var.install_patches.reboot_setting, null) == null || contains(["Always", "IfRequired", "Never"], try(var.install_patches.reboot_setting, ""))
    error_message = "install_patches.reboot_setting must be 'Always', 'IfRequired' or 'Never'."
  }
}

variable "extension_properties" {
  type        = map(string)
  description = "Extension properties. Required when scope is 'Extension'. For guest patching on Arc-enabled servers this carries InGuestPatchMode = 'User'."
  default     = {}
}

# =====================================================================
# Governance
# =====================================================================

variable "role_assignments" {
  type = map(object({
    role_definition_id_or_name             = string
    principal_id                           = string
    description                            = optional(string, null)
    skip_service_principal_aad_check       = optional(bool, false)
    condition                              = optional(string, null)
    condition_version                      = optional(string, null)
    delegated_managed_identity_resource_id = optional(string, null)
    principal_type                         = optional(string, null)
  }))
  description = "RBAC role assignments scoped to the Maintenance Configuration. Common roles: 'Contributor', 'Reader'."
  default     = {}
}

variable "lock" {
  type = object({
    kind = string
    name = optional(string, null)
  })
  description = "Optional resource lock. kind must be 'CanNotDelete' or 'ReadOnly'."
  default     = null

  validation {
    condition     = var.lock == null || contains(["CanNotDelete", "ReadOnly"], try(var.lock.kind, ""))
    error_message = "lock.kind must be 'CanNotDelete' or 'ReadOnly' when lock is set."
  }
}

# =====================================================================
# Module behavior
# =====================================================================

variable "subscription_id" {
  type        = string
  description = "Subscription the configuration is created in. Leave null to use the provider's subscription."
  default     = null
}

variable "enable_telemetry" {
  type        = bool
  description = "Whether to enable AVM module telemetry. Set false to opt out."
  default     = true
}

variable "tags" {
  type        = map(string)
  description = "A map of tags to apply to the Maintenance Configuration."
  default     = null
}
