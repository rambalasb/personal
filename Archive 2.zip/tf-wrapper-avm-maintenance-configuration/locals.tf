locals {
  module_tags = merge(
    var.tags == null ? {} : var.tags,
    {
      managed-by = "terraform"
      module     = "tf-wrapper-avm-maintenance-configuration"
    }
  )

  # Guest patching is the only scope that reads install_patches.
  in_guest_patch = var.scope == "InGuestPatch"
}
