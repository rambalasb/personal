output "resource_id" {
  value = module.route_table.resource_id
}

output "name" {
  value = module.route_table.name
}

output "routes" {
  value = module.route_table.routes
}
