module "route_table" {
  source = "../.."

  name                = "rt-avm-default-test-${random_string.suffix.result}"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location

  # Forced tunnelling: default route to an appliance, BGP propagation off.
  bgp_route_propagation_enabled = false

  routes = {
    "default-to-nva" = {
      name                   = "default-to-nva"
      address_prefix         = "0.0.0.0/0"
      next_hop_type          = "VirtualAppliance"
      next_hop_in_ip_address = "10.0.1.4"
    }
    "vnet-local" = {
      name           = "vnet-local"
      address_prefix = "10.0.0.0/16"
      next_hop_type  = "VnetLocal"
    }
  }

  enable_telemetry = false
}
