module "route_table" {
  source  = "Azure/avm-res-network-routetable/azurerm"
  version = "0.5.0"

  # Required
  name                = var.name
  resource_group_name = var.resource_group_name
  location            = var.location

  # Routes and associations
  routes                        = var.routes
  routes_legacy_mode            = var.routes_legacy_mode
  bgp_route_propagation_enabled = var.bgp_route_propagation_enabled
  subnet_resource_ids           = var.subnet_resource_ids

  # Governance
  role_assignments = var.role_assignments
  lock             = var.lock

  # Module behavior
  enable_telemetry = var.enable_telemetry
  tags             = local.module_tags
}
