locals {
  module_tags = merge(
    var.tags == null ? {} : var.tags,
    {
      managed-by = "terraform"
      module     = "tf-wrapper-avm-route-table"
    }
  )

  # A 0.0.0.0/0 route is forced tunnelling; it and BGP propagation interact badly.
  default_routes = [for r in values(var.routes) : r if r.address_prefix == "0.0.0.0/0"]
}
