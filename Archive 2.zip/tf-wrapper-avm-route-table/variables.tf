# =====================================================================
# Required inputs
# =====================================================================

variable "name" {
  type        = string
  description = "Name of the Route Table. 1-80 chars; alphanumerics, underscores, periods, hyphens. Must start with alphanumeric and end with alphanumeric or underscore."

  validation {
    condition     = can(regex("^[a-zA-Z0-9][a-zA-Z0-9._-]{0,78}[a-zA-Z0-9_]$", var.name))
    error_message = "name must be 1-80 characters, alphanumerics/underscores/periods/hyphens, start with alphanumeric, end with alphanumeric or underscore."
  }
}

variable "resource_group_name" {
  type        = string
  description = "Name of the Resource Group where the Route Table will be deployed."

  validation {
    condition     = length(var.resource_group_name) > 0 && length(var.resource_group_name) <= 90
    error_message = "resource_group_name must be 1-90 characters."
  }
}

variable "location" {
  type        = string
  description = "Azure region where the Route Table will be deployed."

  validation {
    condition     = length(var.location) > 0
    error_message = "location must not be empty."
  }
}

# =====================================================================
# Routes and associations
# =====================================================================

variable "routes" {
  type = map(object({
    name                   = string
    address_prefix         = string
    next_hop_type          = string
    next_hop_in_ip_address = optional(string)
  }))
  description = "Routes to create on the table, keyed by route identifier. address_prefix takes CIDR or an Azure service tag. next_hop_type is one of VirtualNetworkGateway, VnetLocal, Internet, VirtualAppliance, None."
  default     = {}

  validation {
    condition = alltrue([
      for r in values(var.routes) :
      contains(["VirtualNetworkGateway", "VnetLocal", "Internet", "VirtualAppliance", "None"], r.next_hop_type)
    ])
    error_message = "Each route's next_hop_type must be one of: VirtualNetworkGateway, VnetLocal, Internet, VirtualAppliance, None."
  }

  # Azure rejects the deployment rather than ignoring the mismatch.
  validation {
    condition = alltrue([
      for r in values(var.routes) :
      r.next_hop_type == "VirtualAppliance" ? try(r.next_hop_in_ip_address, null) != null : try(r.next_hop_in_ip_address, null) == null
    ])
    error_message = "next_hop_in_ip_address is required when next_hop_type is 'VirtualAppliance', and must be omitted for every other next_hop_type."
  }

  validation {
    condition     = length([for r in values(var.routes) : r.name]) == length(distinct([for r in values(var.routes) : r.name]))
    error_message = "Each route name must be unique within the route table."
  }
}

variable "routes_legacy_mode" {
  type        = bool
  description = "Manage routes inline on the route table rather than as separate azurerm_route resources. Only for adopting tables written against the pre-0.3 module layout — it changes state addresses."
  default     = false
}

variable "bgp_route_propagation_enabled" {
  type        = bool
  description = "Whether routes learned by BGP are propagated onto this table. Set false when a default route sends traffic through an appliance."
  default     = true
}

variable "subnet_resource_ids" {
  type        = map(string)
  description = "Subnets to associate the route table with, keyed by identifier. Values are full subnet resource IDs."
  default     = {}

  validation {
    condition = alltrue([
      for id in values(var.subnet_resource_ids) :
      can(regex("^/subscriptions/[^/]+/resourceGroups/[^/]+/providers/Microsoft.Network/virtualNetworks/[^/]+/subnets/[^/]+$", id))
    ])
    error_message = "Each value must be a full subnet resource ID: /subscriptions/{sub}/resourceGroups/{rg}/providers/Microsoft.Network/virtualNetworks/{vnet}/subnets/{subnet}."
  }
}

# =====================================================================
# Governance
# =====================================================================

variable "role_assignments" {
  type = map(object({
    role_definition_id_or_name             = string
    principal_id                           = string
    description                            = optional(string, null)
    skip_service_principal_aad_check       = optional(bool, false)
    condition                              = optional(string, null)
    condition_version                      = optional(string, null)
    delegated_managed_identity_resource_id = optional(string, null)
    principal_type                         = optional(string, null)
  }))
  description = "RBAC role assignments scoped to the Route Table. Common roles: 'Network Contributor', 'Reader'."
  default     = {}
}

variable "lock" {
  type = object({
    kind = string
    name = optional(string, null)
  })
  description = "Optional resource lock. kind must be 'CanNotDelete' or 'ReadOnly'."
  default     = null

  validation {
    condition     = var.lock == null || contains(["CanNotDelete", "ReadOnly"], try(var.lock.kind, ""))
    error_message = "lock.kind must be 'CanNotDelete' or 'ReadOnly' when lock is set."
  }
}

# =====================================================================
# Module behavior
# =====================================================================

variable "enable_telemetry" {
  type        = bool
  description = "Whether to enable AVM module telemetry. Set false to opt out."
  default     = true
}

variable "tags" {
  type        = map(string)
  description = "A map of tags to apply to the Route Table."
  default     = null
}
