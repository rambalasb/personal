check "bgp_propagation_off_when_default_route_present" {
  assert {
    condition     = length(local.default_routes) == 0 || var.bgp_route_propagation_enabled == false
    error_message = "Route table carries a 0.0.0.0/0 route while bgp_route_propagation_enabled is true. A BGP-learned route can win over the static default and silently bypass the appliance. Set bgp_route_propagation_enabled = false for forced tunnelling."
  }
}

check "default_route_targets_an_appliance" {
  assert {
    condition     = alltrue([for r in local.default_routes : r.next_hop_type == "VirtualAppliance"])
    error_message = "Route table sends 0.0.0.0/0 to a next hop other than VirtualAppliance. Confirm this is intended — 'Internet' bypasses inspection and 'None' blackholes all egress."
  }
}

check "table_has_routes_or_associations" {
  assert {
    condition     = length(var.routes) > 0 || length(var.subnet_resource_ids) > 0
    error_message = "Route table has no routes and no subnet associations, so it has no effect. Confirm it is a placeholder."
  }
}

check "routes_legacy_mode_is_off" {
  assert {
    condition     = var.routes_legacy_mode == false
    error_message = "routes_legacy_mode is enabled. It manages routes inline rather than as azurerm_route resources and exists only for adopting pre-0.3 configurations. New tables should leave it false."
  }
}
