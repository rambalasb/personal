output "resource_id" {
  description = "The Azure resource ID of the Route Table."
  value       = module.route_table.resource_id
}

output "name" {
  description = "The name of the Route Table."
  value       = module.route_table.name
}

output "routes" {
  description = "The routes created on the table, keyed by route name."
  value       = module.route_table.routes
}

output "resource" {
  description = "The full azurerm_route_table resource object."
  value       = module.route_table.resource
}
