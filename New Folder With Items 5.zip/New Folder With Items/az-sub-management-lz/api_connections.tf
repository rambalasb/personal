# api_connections.tf
# Native + import: Logic App managed-API connections (Microsoft.Web/connections).
# No AVM/wrapper module. parameter_values are empty in the live state; any
# secret-bearing parameters are reconciled out-of-band, not in the repo.

resource "azurerm_api_connection" "this" {
  for_each = var.enable_api_connections ? var.api_connections : {}

  name                = each.value.name
  resource_group_name = module.resource_group[each.value.resource_group_key].name
  managed_api_id      = "${data.azurerm_subscription.current.id}/providers/Microsoft.Web/locations/${var.location}/managedApis/${each.value.managed_api_name}"
  display_name        = each.value.display_name
  parameter_values    = {}

  lifecycle {
    # parameter_values often carry connection secrets set at connection-auth time.
    ignore_changes = [parameter_values]
  }
}

import {
  for_each = var.enable_api_connections ? var.api_connections : {}

  to = azurerm_api_connection.this[each.key]
  id = "${data.azurerm_subscription.current.id}/resourceGroups/${module.resource_group[each.value.resource_group_key].name}/providers/Microsoft.Web/connections/${each.value.name}"
}
