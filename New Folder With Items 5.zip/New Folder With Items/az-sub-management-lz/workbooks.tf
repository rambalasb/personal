# workbooks.tf
# Native + import: no AVM/wrapper module for Azure Workbooks. The resource name
# is the workbook's GUID. `data_json` (serialized content) must be filled from
# `-generate-config-out` on adoption; until then it will show an in-place diff.

resource "azurerm_application_insights_workbook" "this" {
  for_each = var.enable_workbooks ? var.workbooks : {}

  name                = each.value.name
  resource_group_name = module.resource_group[each.value.resource_group_key].name
  location            = coalesce(each.value.location, var.location)
  display_name        = each.value.display_name
  category            = each.value.category
  data_json           = each.value.data_json
  tags                = merge(local.common_tags, each.value.tags)
}

import {
  for_each = var.enable_workbooks ? var.workbooks : {}

  to = azurerm_application_insights_workbook.this[each.key]
  id = "${data.azurerm_subscription.current.id}/resourceGroups/${module.resource_group[each.value.resource_group_key].name}/providers/Microsoft.Insights/workbooks/${each.value.name}"
}
