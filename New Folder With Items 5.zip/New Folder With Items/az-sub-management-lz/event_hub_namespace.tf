# event_hub_namespace.tf
# Native + import: no AVM/wrapper module for Event Hubs. Adopts the existing
# namespace that backs the ServiceNow action group's event-hub receiver.

resource "azurerm_eventhub_namespace" "this" {
  for_each = var.enable_event_hub_namespace ? var.event_hub_namespace : {}

  name                          = each.value.name
  resource_group_name           = module.resource_group[each.value.resource_group_key].name
  location                      = coalesce(each.value.location, var.location)
  sku                           = each.value.sku
  capacity                      = each.value.capacity
  auto_inflate_enabled          = false
  minimum_tls_version           = "1.2"
  local_authentication_enabled  = true
  public_network_access_enabled = true
  tags                          = merge(local.common_tags, each.value.tags)

  # Reconcile network_ruleset / ip rules against the live namespace on adoption.
}

import {
  for_each = var.enable_event_hub_namespace ? var.event_hub_namespace : {}

  to = azurerm_eventhub_namespace.this[each.key]
  id = "${data.azurerm_subscription.current.id}/resourceGroups/${module.resource_group[each.value.resource_group_key].name}/providers/Microsoft.EventHub/namespaces/${each.value.name}"
}
