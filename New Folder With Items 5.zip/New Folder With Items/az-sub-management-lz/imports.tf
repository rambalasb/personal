# imports.tf
# One-time adoption of existing Azure resources into the wrapper modules. Native
# resources (network watcher, event grid, event hub, monitor workspace, workbooks,
# api connections, logic app) carry their own import blocks in their files.
#
# INTENTIONALLY NOT MANAGED (Azure-created / policy-managed):
#   - "Application Insights Smart Detection" action group (auto-created with App Insights)
#   - LogicAppsManagement solution on la-siem (auto-added)
#   - MA_ws-monitoring-...  data collection endpoint + rule (Azure-managed RG)
#   - dcr-management-linux/windows-l2t3tt55mbzmy (created by the AMA DINE policy)
#
# TODO: the LAW / App Insights / App Service Plan wrappers wrap AVM modules whose
# INTERNAL resource address must be confirmed (run plan and read the import error,
# or inspect the AVM module). Best-guess addresses below.

locals {
  sub = data.azurerm_subscription.current.id
}

# ── Resource groups (azapi, count -> this[0]) ──────────────────────────
import {
  to = module.resource_group["alerts"].module.resource_group.azapi_resource.this[0]
  id = "${local.sub}/resourceGroups/rg-alerts-management-canadacentral-001"
}
import {
  to = module.resource_group["shared"].module.resource_group.azapi_resource.this[0]
  id = "${local.sub}/resourceGroups/rg-shared-management-canadacentral-001"
}
import {
  to = module.resource_group["siem"].module.resource_group.azapi_resource.this[0]
  id = "${local.sub}/resourceGroups/rg-siem-management-canadacentral-001"
}
import {
  to = module.resource_group["servicenow_lga"].module.resource_group.azapi_resource.this[0]
  id = "${local.sub}/resourceGroups/lga-servicenow-integration_group"
}

# ── Storage account (azapi) ────────────────────────────────────────────
import {
  to = module.storage_account["nwmgmt"].module.storage_account.azapi_resource.this
  id = "${local.sub}/resourceGroups/rg-shared-management-canadacentral-001/providers/Microsoft.Storage/storageAccounts/stnwmgmtcanadacentral"
}

# ── User-assigned identities (azurerm) ─────────────────────────────────
import {
  to = module.user_assigned_identity["ama_policy"].module.user_assigned_identity.azurerm_user_assigned_identity.this
  id = "${local.sub}/resourceGroups/rg-shared-management-canadacentral-001/providers/Microsoft.ManagedIdentity/userAssignedIdentities/mid-ama-policy-management-canadacentral-001"
}
import {
  to = module.user_assigned_identity["lap_servicenow"].module.user_assigned_identity.azurerm_user_assigned_identity.this
  id = "${local.sub}/resourceGroups/rg-alerts-management-canadacentral-001/providers/Microsoft.ManagedIdentity/userAssignedIdentities/mid-lap-servicenowintegration-canadacentral-001"
}

# ── Log Analytics workspace (TODO confirm internal AVM address) ────────
import {
  to = module.log_analytics_workspace["siem"].module.log_analytics_workspace.azurerm_log_analytics_workspace.this
  id = "${local.sub}/resourceGroups/rg-siem-management-canadacentral-001/providers/Microsoft.OperationalInsights/workspaces/la-siem-management-canadacentral-001"
}

# ── Application Insights (TODO confirm internal AVM address) ───────────
import {
  to = module.application_insights["servicenow"].module.application_insights.azapi_resource.this
  id = "${local.sub}/resourceGroups/rg-alerts-management-canadacentral-001/providers/Microsoft.Insights/components/ai-servicenowintegration-canadacentral-001"
}

# ── App Service plan (TODO confirm internal AVM address) ───────────────
import {
  to = module.app_service_plan["servicenow"].module.app_service_plan.azapi_resource.this
  id = "${local.sub}/resourceGroups/rg-alerts-management-canadacentral-001/providers/Microsoft.Web/serverFarms/asp-servicenowintegration-canadacentral-001"
}

# ── Action groups (amba-alz wrapper -> monitoring[0]) ──────────────────
import {
  to = module.monitoring[0].azurerm_monitor_action_group.this["fit_db_mail"]
  id = "${local.sub}/resourceGroups/rg-alerts-management-canadacentral-001/providers/Microsoft.Insights/actionGroups/ ag-FIT-DB-mail-alerts-canadacentral-002"
}
import {
  to = module.monitoring[0].azurerm_monitor_action_group.this["servicenow"]
  id = "${local.sub}/resourceGroups/lga-servicenow-integration_group/providers/Microsoft.Insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
}
import {
  to = module.monitoring[0].azurerm_monitor_action_group.this["azfw"]
  id = "${local.sub}/resourceGroups/rg-alerts-management-canadacentral-001/providers/Microsoft.Insights/actionGroups/ag-AzFW-alert-CanadaCentral-001"
}
import {
  to = module.monitoring[0].azurerm_monitor_action_group.this["cops_mail"]
  id = "${local.sub}/resourceGroups/rg-alerts-management-canadacentral-001/providers/Microsoft.Insights/actionGroups/ag-cops-mail-alerts-canadacentral-001"
}
import {
  to = module.monitoring[0].azurerm_monitor_action_group.this["db_mail"]
  id = "${local.sub}/resourceGroups/rg-alerts-management-canadacentral-001/providers/Microsoft.Insights/actionGroups/ag-DB-mail-alerts-canadacentral-001"
}
import {
  to = module.monitoring[0].azurerm_monitor_action_group.this["monitor_mail"]
  id = "${local.sub}/resourceGroups/rg-alerts-management-canadacentral-001/providers/Microsoft.Insights/actionGroups/ag-monitor-mail-alerts-canadacentral-001"
}
import {
  to = module.monitoring[0].azurerm_monitor_action_group.this["pta_mail"]
  id = "${local.sub}/resourceGroups/rg-alerts-management-canadacentral-001/providers/Microsoft.Insights/actionGroups/ag-pta-mail-alerts-canadacentral-001"
}

# ── Alerts (amba-alz wrapper -> monitoring[0]) ─────────────────────────
import {
  to = module.monitoring[0].azurerm_monitor_activity_log_alert.this["service_outage"]
  id = "${local.sub}/resourceGroups/rg-alerts-management-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/Service-Outage-Alert-canadacentral"
}
import {
  to = module.monitoring[0].azurerm_monitor_scheduled_query_rules_alert_v2.this["resource_creation"]
  id = "${local.sub}/resourceGroups/rg-alerts-management-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/Resource-Creation-Alert-canadacentral"
}
import {
  to = module.monitoring[0].azurerm_monitor_scheduled_query_rules_alert_v2.this["storage_container_deletion"]
  id = "${local.sub}/resourceGroups/rg-alerts-management-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/Storage-Account-Container-Deletion-Alert-canadacentral"
}
import {
  to = module.monitoring[0].azurerm_monitor_scheduled_query_rules_alert_v2.this["storage_deletion"]
  id = "${local.sub}/resourceGroups/rg-alerts-management-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/Storage-Account-Deletion-Alert-canadacentral"
}
