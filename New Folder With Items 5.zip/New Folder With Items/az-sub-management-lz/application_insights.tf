# application_insights.tf
# Dependencies: resource_group, log_analytics_workspace (workspace_id).

module "application_insights" {
  for_each = var.enable_application_insights ? var.application_insights : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-application-insights/azurerm"
  version = "0.1.0"

  name                 = each.value.name
  resource_group_name  = module.resource_group[each.value.resource_group_key].name
  location             = coalesce(each.value.location, module.resource_group[each.value.resource_group_key].location)
  workspace_id         = module.log_analytics_workspace[each.value.workspace_key].resource_id
  application_type     = each.value.application_type
  retention_in_days    = each.value.retention_in_days
  daily_data_cap_in_gb = each.value.daily_data_cap_gb
  tags                 = merge(local.common_tags, each.value.tags)
}
