# Alert + action-group definitions passed into the amba-alz wrapper in
# monitoring.tf. Scopes are subscription-scoped to match the live resources.

locals {
  common_tags = merge(var.tags, {
    environment = var.environment
    managed-by  = "terraform"
    solution    = "az-sub-management-lz"
  })

  subscription_scope = data.azurerm_subscription.current.id
  alerts_rg_name     = module.resource_group["alerts"].name

  # Action groups created in this subscription. Two names carry a leading space
  # to match the live resources exactly (do not "fix").
  action_groups = {
    fit_db_mail = {
      name                = " ag-FIT-DB-mail-alerts-canadacentral-002"
      resource_group_name = local.alerts_rg_name
      short_name          = "FitDBA-Mail2"
      email_receivers = {
        "DBA Email 2 - smidba@bchydro.com_-EmailAction-" = {
          email_address           = "smidba@bchydro.com"
          use_common_alert_schema = false
        }
      }
    }

    servicenow = {
      name                = " ag-servicenow-alerts-canadacentral-001"
      resource_group_name = module.resource_group["servicenow_lga"].name
      short_name          = "snow events"
      event_hub_receivers = {
        "snow-alerts" = {
          event_hub_namespace     = "ehns-alerts-canadacentral-001"
          event_hub_name          = "azure-monitor-triggers"
          subscription_id         = data.azurerm_subscription.current.subscription_id
          tenant_id               = data.azurerm_client_config.current.tenant_id
          use_common_alert_schema = true
        }
      }
    }

    azfw = {
      name                = "ag-AzFW-alert-CanadaCentral-001"
      resource_group_name = local.alerts_rg_name
      short_name          = "AzFW alert"
      email_receivers = {
        "TELUS Firewall support_-EmailAction-" = {
          email_address           = "dlBCHydroSecurity-SI@telus.com"
          use_common_alert_schema = false
        }
      }
    }

    cops_mail = {
      name                = "ag-cops-mail-alerts-canadacentral-001"
      resource_group_name = local.alerts_rg_name
      short_name          = "COPS Alert"
      tags = {
        CostCenterId = " YT-01585.S.IMP.CLZ"
        name         = "Call Out Procedures"
      }
      email_receivers = {
        "TELUS support_-EmailAction-" = {
          email_address           = "ticda_tids_managedazure@telusinternational.com"
          use_common_alert_schema = false
        }
        "COPS App support team_-EmailAction-" = {
          email_address           = "COPs.BusinessApplicationSupport@bchydro.com"
          use_common_alert_schema = false
        }
      }
    }

    db_mail = {
      name                = "ag-DB-mail-alerts-canadacentral-001"
      resource_group_name = local.alerts_rg_name
      short_name          = "DB-FIT-COPS"
      email_receivers = {
        "DB alerts-FIT and COPS_-EmailAction-" = {
          email_address           = "dlfujdba@bchydro.com"
          use_common_alert_schema = false
        }
      }
    }

    monitor_mail = {
      name                = "ag-monitor-mail-alerts-canadacentral-001"
      resource_group_name = local.alerts_rg_name
      short_name          = "Monit Alerts"
      email_receivers = {
        "CLZ_-EmailAction-" = {
          email_address           = "Andrei.Mastin@bchydro.com"
          use_common_alert_schema = false
        }
        "bchydro_2_-EmailAction-" = {
          email_address           = "ticda_tids_managedazure@telusinternational.com"
          use_common_alert_schema = false
        }
      }
    }

    pta_mail = {
      name                = "ag-pta-mail-alerts-canadacentral-001"
      resource_group_name = local.alerts_rg_name
      short_name          = "PTA Alert"
      email_receivers = {
        "PTA App support_-EmailAction-" = {
          email_address           = "travis.brown@bchydro.com"
          use_common_alert_schema = false
        }
        "TELUS Cloud support_-EmailAction-" = {
          email_address           = "ticda_tids_managedazure@telusinternational.com"
          use_common_alert_schema = false
        }
      }
    }
  }

  # Activity log alerts -> azurerm_monitor_activity_log_alert
  activity_log_alerts = {
    service_outage = {
      name                = "Service-Outage-Alert-canadacentral"
      resource_group_name = local.alerts_rg_name
      scopes              = [local.subscription_scope]
      location            = "global"
      description         = "Azure Landing Zone Service Health Alert"
      criteria = {
        category = "ServiceHealth"
        service_health = {
          events    = []
          locations = ["Global"]
          services  = []
        }
      }
      action_group_keys = ["monitor_mail"]
    }
  }

  # Log search alerts -> azurerm_monitor_scheduled_query_rules_alert_v2
  log_search_alerts = {
    resource_creation = {
      name                 = "Resource-Creation-Alert-canadacentral"
      resource_group_name  = local.alerts_rg_name
      location             = var.location
      scopes               = [local.subscription_scope]
      severity             = 4
      evaluation_frequency = "PT10M"
      window_duration      = "PT30M"
      description          = "Alert when a new resource is created."
      display_name         = "Resource-Creation-Alert-canadacentral"
      criteria = [{
        query                   = "        AzureActivity\n        | where OperationNameValue has \"Microsoft.Resources/deployments/write\"\n        | where CategoryValue == \"Administrative\"\n        | where ActivityStatusValue == \"Success\"\n        "
        time_aggregation_method = "Count"
        threshold               = 10
        operator                = "GreaterThanOrEqual"
        resource_id_column      = "_ResourceId"
        failing_periods         = { minimum_failing_periods_to_trigger_alert = 1, number_of_evaluation_periods = 1 }
      }]
      action_group_keys = ["servicenow"]
    }

    storage_container_deletion = {
      name                 = "Storage-Account-Container-Deletion-Alert-canadacentral"
      resource_group_name  = local.alerts_rg_name
      location             = var.location
      scopes               = [local.subscription_scope]
      severity             = 0
      evaluation_frequency = "PT5M"
      window_duration      = "PT30M"
      description          = "Alert for the deletion of Storage Account Container."
      display_name         = "Storage-Account-Container-Deletion-Alert-canadacentral"
      criteria = [{
        query                   = "        AzureActivity\n        | where ResourceProviderValue == \"MICROSOFT.STORAGE\" and OperationNameValue == \"MICROSOFT.STORAGE/STORAGEACCOUNTS/BLOBSERVICES/CONTAINERS/DELETE\"\n        "
        time_aggregation_method = "Count"
        threshold               = 1
        operator                = "GreaterThanOrEqual"
        resource_id_column      = "_ResourceId"
        failing_periods         = { minimum_failing_periods_to_trigger_alert = 1, number_of_evaluation_periods = 1 }
      }]
      action_group_keys = ["servicenow"]
    }

    storage_deletion = {
      name                 = "Storage-Account-Deletion-Alert-canadacentral"
      resource_group_name  = local.alerts_rg_name
      location             = var.location
      scopes               = [local.subscription_scope]
      severity             = 0
      evaluation_frequency = "PT5M"
      window_duration      = "PT30M"
      description          = "Alert for the deletion of Storage Account."
      display_name         = "Storage-Account-Deletion-Alert-canadacentral"
      criteria = [{
        query                   = "        AzureActivity\n        | where ResourceProviderValue == \"MICROSOFT.STORAGE\" and OperationNameValue == \"MICROSOFT.STORAGE/STORAGEACCOUNTS/DELETE\"\n        "
        time_aggregation_method = "Count"
        threshold               = 1
        operator                = "GreaterThanOrEqual"
        resource_id_column      = "_ResourceId"
        failing_periods         = { minimum_failing_periods_to_trigger_alert = 1, number_of_evaluation_periods = 1 }
      }]
      action_group_keys = ["servicenow"]
    }
  }
}
