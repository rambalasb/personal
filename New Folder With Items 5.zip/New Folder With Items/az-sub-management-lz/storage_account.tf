# storage_account.tf
# Dependencies: resource_group (resource_group_name picked via resource_group_key).
# Note: the Defender-for-Storage data-scanner private_link_access entry is managed
# by Azure and may reappear as drift if not declared in network_rules.

module "storage_account" {
  for_each = var.enable_storage_account ? var.storage_account : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-storage-account/azurerm"
  version = "0.1.0"

  name                              = each.value.name
  resource_group_name               = module.resource_group[each.value.resource_group_key].name
  location                          = coalesce(each.value.location, module.resource_group[each.value.resource_group_key].location)
  account_kind                      = each.value.account_kind
  account_tier                      = each.value.account_tier
  account_replication_type          = each.value.account_replication_type
  access_tier                       = each.value.access_tier
  min_tls_version                   = each.value.min_tls_version
  https_traffic_only_enabled        = each.value.https_traffic_only_enabled
  shared_access_key_enabled         = each.value.shared_access_key_enabled
  public_network_access_enabled     = each.value.public_network_access_enabled
  cross_tenant_replication_enabled  = each.value.cross_tenant_replication_enabled
  infrastructure_encryption_enabled = each.value.infrastructure_encryption_enabled
  network_rules                     = each.value.network_rules
  tags                              = merge(local.common_tags, each.value.tags)
}
