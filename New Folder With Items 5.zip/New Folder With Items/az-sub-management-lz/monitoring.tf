# monitoring.tf
# Action groups + alerts via the amba-alz wrapper. Definitions built in
# locals.tf. AMBA baseline off (subscription-scoped root).

module "monitoring" {
  count = var.enable_monitoring ? 1 : 0

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-monitoring-amba-alz/azurerm"
  version = "0.1.0"

  enable_amba                = var.enable_amba
  location                   = var.location
  root_management_group_name = var.root_management_group_name

  action_groups       = local.action_groups
  activity_log_alerts = local.activity_log_alerts
  log_search_alerts   = local.log_search_alerts
  tags                = local.common_tags

  depends_on = [module.resource_group, module.event_hub_namespace]
}
