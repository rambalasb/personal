output "resource_group_ids" {
  description = "Resource group IDs, keyed by role."
  value       = { for k, m in module.resource_group : k => m.resource_id }
}

output "storage_account_ids" {
  description = "Storage account resource IDs, keyed by role."
  value       = { for k, m in module.storage_account : k => m.resource_id }
}

output "user_assigned_identity_ids" {
  description = "User-assigned identity resource IDs, keyed by role."
  value       = { for k, m in module.user_assigned_identity : k => m.resource_id }
}

output "log_analytics_workspace_ids" {
  description = "Log Analytics workspace resource IDs, keyed by role."
  value       = { for k, m in module.log_analytics_workspace : k => m.resource_id }
}

output "application_insights_ids" {
  description = "Application Insights resource IDs, keyed by role."
  value       = { for k, m in module.application_insights : k => m.resource_id }
}

output "app_service_plan_ids" {
  description = "App Service plan resource IDs, keyed by role."
  value       = { for k, m in module.app_service_plan : k => m.resource_id }
}
