# event_grid_system_topic.tf
# Native + import: the AVM module (avm-res-eventgrid-systemtopic) has no released
# version yet, so no wrapper exists. Switch to it once it ships. Import adopts the
# existing Azure-managed topic instead of creating one.

resource "azurerm_eventgrid_system_topic" "storage" {
  for_each = var.enable_event_grid_system_topic ? toset(["nwmgmt"]) : toset([])

  name                = "stnwmgmtcanadacentral-870971f8-0467-43bb-b393-b457edcbdb85"
  resource_group_name = module.resource_group["shared"].name
  location            = var.location
  source_resource_id  = module.storage_account["nwmgmt"].resource_id
  topic_type          = "microsoft.storage.storageaccounts"
  tags                = local.common_tags
}

import {
  for_each = var.enable_event_grid_system_topic ? toset(["nwmgmt"]) : toset([])

  to = azurerm_eventgrid_system_topic.storage[each.key]
  id = "${data.azurerm_subscription.current.id}/resourceGroups/rg-shared-management-canadacentral-001/providers/Microsoft.EventGrid/systemTopics/stnwmgmtcanadacentral-870971f8-0467-43bb-b393-b457edcbdb85"
}
