# network_watcher.tf
# Native + import: the AVM module (avm-res-network-networkwatcher, via
# tf-wrapper-avm-network-watcher) manages only flow logs / connection monitors on
# an existing watcher — it can't create the watcher itself. Import adopts it.

resource "azurerm_network_watcher" "management" {
  for_each = var.enable_network_watcher ? toset(["management"]) : toset([])

  name                = "NetworkWatcher_canadacentral_management"
  resource_group_name = module.resource_group["shared"].name
  location            = var.location
  tags                = local.common_tags
}

import {
  for_each = var.enable_network_watcher ? toset(["management"]) : toset([])

  to = azurerm_network_watcher.management[each.key]
  id = "${data.azurerm_subscription.current.id}/resourceGroups/rg-shared-management-canadacentral-001/providers/Microsoft.Network/networkWatchers/NetworkWatcher_canadacentral_management"
}
