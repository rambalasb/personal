# logic_app.tf
# Native + import: Logic App (Standard) for the ServiceNow integration. No AVM/
# wrapper module. This is a scaffold of the required shape — the live resource
# carries a large site_config (CORS, ip_restrictions, vnet integration) and an
# empty storage_account_name. Reconcile the full site_config and storage from
# `-generate-config-out` on adoption; expect in-place diffs until then.

resource "azurerm_logic_app_standard" "this" {
  for_each = var.enable_logic_app ? var.logic_app : {}

  name                       = each.value.name
  resource_group_name        = module.resource_group[each.value.resource_group_key].name
  location                   = coalesce(each.value.location, var.location)
  app_service_plan_id        = module.app_service_plan[each.value.app_service_plan_key].resource_id
  storage_account_name       = each.value.storage_account_name
  storage_account_access_key = "" # TODO: inject via a sensitive workspace variable
  https_only                 = false
  app_settings               = {}

  identity {
    type         = "SystemAssigned, UserAssigned"
    identity_ids = [module.user_assigned_identity[each.value.user_assigned_id_key].resource_id]
  }

  site_config {
    always_on              = true
    ftps_state             = "FtpsOnly"
    min_tls_version        = "1.2"
    vnet_route_all_enabled = true
    # TODO: reconcile cors + ip_restriction blocks and vnet integration.
  }

  tags = merge(local.common_tags, each.value.tags)

  lifecycle {
    ignore_changes = [storage_account_access_key]
  }
}

import {
  for_each = var.enable_logic_app ? var.logic_app : {}

  to = azurerm_logic_app_standard.this[each.key]
  id = "${data.azurerm_subscription.current.id}/resourceGroups/${module.resource_group[each.value.resource_group_key].name}/providers/Microsoft.Web/sites/${each.value.name}"
}
