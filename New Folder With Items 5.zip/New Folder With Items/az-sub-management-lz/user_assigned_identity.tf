# user_assigned_identity.tf
# Dependencies: resource_group (resource_group_name picked via resource_group_key).

module "user_assigned_identity" {
  for_each = var.enable_user_assigned_identity ? var.user_assigned_identity : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-user-assigned-identity/azurerm"
  version = "0.0.3"

  name                = each.value.name
  resource_group_name = module.resource_group[each.value.resource_group_key].name
  location            = coalesce(each.value.location, module.resource_group[each.value.resource_group_key].location)
  tags                = merge(local.common_tags, each.value.tags)
}
