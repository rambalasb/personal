# monitor_workspace.tf
# Native + import: no AVM/wrapper module. Azure Monitor (Prometheus) workspace.
# NOTE: the associated MA_* data collection endpoint/rule are Azure-managed and
# are intentionally NOT declared here (see imports.tf header).

resource "azurerm_monitor_workspace" "this" {
  for_each = var.enable_monitor_workspace ? var.monitor_workspace : {}

  name                          = each.value.name
  resource_group_name           = module.resource_group[each.value.resource_group_key].name
  location                      = coalesce(each.value.location, var.location)
  public_network_access_enabled = true
  tags                          = merge(local.common_tags, each.value.tags)
}

import {
  for_each = var.enable_monitor_workspace ? var.monitor_workspace : {}

  to = azurerm_monitor_workspace.this[each.key]
  id = "${data.azurerm_subscription.current.id}/resourceGroups/${module.resource_group[each.value.resource_group_key].name}/providers/Microsoft.Monitor/accounts/${each.value.name}"
}
