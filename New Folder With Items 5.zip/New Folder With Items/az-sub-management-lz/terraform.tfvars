# ── Shared ─────────────────────────────────────────────────────────────
# subscription_id / tenant_id come from ARM_SUBSCRIPTION_ID / ARM_TENANT_ID.
environment = "prod"
location    = "canadacentral"

tags = {
  owner = "platform-management"
}

enable_amba = false

# ── Feature flags ──────────────────────────────────────────────────────
enable_resource_group          = true
enable_storage_account         = true
enable_user_assigned_identity  = true
enable_log_analytics_workspace = true
enable_application_insights    = true
enable_app_service_plan        = true
enable_monitoring              = true

enable_network_watcher         = true
enable_event_grid_system_topic = true
enable_event_hub_namespace     = true
enable_monitor_workspace       = true
enable_workbooks               = true
enable_api_connections         = true
enable_logic_app               = true

# ── Resource groups ────────────────────────────────────────────────────
resource_group = {
  "alerts"         = { name = "rg-alerts-management-canadacentral-001" }
  "shared"         = { name = "rg-shared-management-canadacentral-001" }
  "siem"           = { name = "rg-siem-management-canadacentral-001" }
  "servicenow_lga" = { name = "lga-servicenow-integration_group" }
}

# ── Storage account ────────────────────────────────────────────────────
storage_account = {
  "nwmgmt" = {
    name                          = "stnwmgmtcanadacentral"
    resource_group_key            = "shared"
    shared_access_key_enabled     = true
    public_network_access_enabled = true
    network_rules = {
      bypass         = ["AzureServices", "Logging", "Metrics"]
      default_action = "Deny"
      ip_rules = [
        "130.107.128.109", "130.107.128.110", "130.107.128.114", "130.107.128.159",
        "130.107.128.171", "130.107.128.173", "130.107.128.187", "130.107.128.189",
        "130.107.128.199", "130.107.128.2", "130.107.128.20", "130.107.128.201",
        "130.107.128.204", "130.107.128.225", "130.107.128.227", "130.107.128.229",
        "130.107.128.251", "130.107.128.253", "130.107.128.84", "130.107.128.94",
        "130.107.180.169", "130.107.180.207", "130.107.181.108", "130.107.181.12",
        "130.107.181.131", "130.107.181.156", "130.107.181.222", "130.107.181.249",
        "130.107.181.29", "130.107.181.97", "130.107.182.143", "130.107.182.152",
        "130.107.182.226", "130.107.182.237", "130.107.183.119", "130.107.183.214",
        "130.107.183.216", "130.107.183.22", "130.107.183.227", "130.107.183.33",
        "130.107.183.56", "130.107.183.57", "130.107.183.60", "130.107.245.112/28",
        "155.190.0.9", "20.48.204.12", "4.206.125.246"
      ]
      virtual_network_subnet_ids = [
        "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cyberark-canadacentral-001/subnets/snet-cyberark-servers-canadacentral-001",
        "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-ertest-canadacentral-001/subnets/snet-ertest-canadacentral-001",
        "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-runners-connectivity-canadacentral-001/subnets/snet-runners-dev-canadacentral-001",
        "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-runners-connectivity-canadacentral-001/subnets/snet-runners-prod-canadacentral-001",
        "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-shared-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-shared-connectivity-canadacentral-001/subnets/snet-outbound-connectivity-canadacentral-001"
      ]
      private_link_access = [{
        endpoint_resource_id = "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/*/providers/Microsoft.Logic/workflows/*"
        endpoint_tenant_id   = "8fbb85e8-0cbc-48c3-a2e9-528cef30ec27"
      }]
    }
  }
}

# ── User-assigned identities ───────────────────────────────────────────
user_assigned_identity = {
  "ama_policy"     = { name = "mid-ama-policy-management-canadacentral-001", resource_group_key = "shared" }
  "lap_servicenow" = { name = "mid-lap-servicenowintegration-canadacentral-001", resource_group_key = "alerts" }
}

# ── Log Analytics workspace ────────────────────────────────────────────
log_analytics_workspace = {
  "siem" = {
    name               = "la-siem-management-canadacentral-001"
    resource_group_key = "siem"
    sku                = "PerGB2018"
    retention_in_days  = 90
    daily_quota_gb     = -1
  }
}

# ── Application Insights ───────────────────────────────────────────────
application_insights = {
  "servicenow" = {
    name               = "ai-servicenowintegration-canadacentral-001"
    resource_group_key = "alerts"
    workspace_key      = "siem"
    application_type   = "web"
    retention_in_days  = 90
    daily_data_cap_gb  = 100
  }
}

# ── App Service plan ───────────────────────────────────────────────────
app_service_plan = {
  "servicenow" = {
    name               = "asp-servicenowintegration-canadacentral-001"
    resource_group_key = "alerts"
    os_type            = "Windows"
    sku_name           = "WS1"
  }
}

# ── Event Hubs namespace ───────────────────────────────────────────────
event_hub_namespace = {
  "alerts" = {
    name               = "ehns-alerts-canadacentral-001"
    resource_group_key = "alerts"
    sku                = "Standard"
    capacity           = 10
  }
}

# ── Azure Monitor workspace ────────────────────────────────────────────
monitor_workspace = {
  "monitoring" = {
    name               = "ws-monitoring-management-canadacentral-001"
    resource_group_key = "siem"
  }
}

# ── Workbooks (data_json filled from -generate-config-out) ─────────────
workbooks = {
  "service_retirement" = {
    name               = "07566e9d-35aa-43e8-a784-e0a5aca0f01d"
    display_name       = "Service Retirement Advisor"
    resource_group_key = "shared"
  }
  "wacoa" = {
    name               = "5cb98961-3ed4-49b5-88ff-64db8c12c020"
    display_name       = "BC Hydro WACOA"
    resource_group_key = "shared"
  }
  "finops_optimization" = {
    name               = "7052262c-0219-50b9-8c30-b36c0f8e8cb3"
    display_name       = "FinOps-Governance - Optimization"
    resource_group_key = "shared"
  }
  "finops_governance" = {
    name               = "b66faf44-802c-57b3-8ae7-f2277cdd4f65"
    display_name       = "FinOps-Governance - Governance"
    resource_group_key = "shared"
  }
}

# ── Logic App API connections ──────────────────────────────────────────
api_connections = {
  "azureeventgrid"     = { name = "azureeventgrid", resource_group_key = "alerts", managed_api_name = "azureeventgrid", display_name = "new_conn_41ee6" }
  "azuremonitorlogs"   = { name = "azuremonitorlogs", resource_group_key = "alerts", managed_api_name = "azuremonitorlogs", display_name = "new_conn_5a313" }
  "azuremonitorlogs-1" = { name = "azuremonitorlogs-1", resource_group_key = "alerts", managed_api_name = "azuremonitorlogs", display_name = "Logic App Managed Identity" }
  "azuresentinel"      = { name = "azuresentinel", resource_group_key = "alerts", managed_api_name = "azuresentinel", display_name = "816a8" }
  "azuresentinel-1"    = { name = "azuresentinel-1", resource_group_key = "alerts", managed_api_name = "azuresentinel", display_name = "Primary Connection" }
  "azuresentinel-2"    = { name = "azuresentinel-2", resource_group_key = "alerts", managed_api_name = "azuresentinel", display_name = "new_conn_9a3fd" }
  "azuresentinel-5"    = { name = "azuresentinel-5", resource_group_key = "alerts", managed_api_name = "azuresentinel", display_name = "Logic App User Assigned ID" }
  "eventhubs"          = { name = "eventhubs", resource_group_key = "alerts", managed_api_name = "eventhubs", display_name = "new_conn_c314e" }
  "eventhubs-3"        = { name = "eventhubs-3", resource_group_key = "alerts", managed_api_name = "eventhubs", display_name = "a5465" }
  "hashgeneratorip"    = { name = "hashgeneratorip", resource_group_key = "alerts", managed_api_name = "hashgeneratorip", display_name = "Hash Generator (Independent Publisher)" }
  "office365"          = { name = "office365", resource_group_key = "alerts", managed_api_name = "office365", display_name = "David.Sobola@bchydro.com" }
  "outlook"            = { name = "outlook", resource_group_key = "alerts", managed_api_name = "outlook", display_name = "Outlook.com" }
  "outlook-1"          = { name = "outlook-1", resource_group_key = "alerts", managed_api_name = "outlook", display_name = "Outlook.com" }
}

# ── Logic App (Standard) ───────────────────────────────────────────────
logic_app = {
  "servicenow" = {
    name                 = "lap-servicenowintegration-canadacentral-001"
    resource_group_key   = "alerts"
    app_service_plan_key = "servicenow"
    storage_account_name = ""
    user_assigned_id_key = "lap_servicenow"
  }
}
