# log_analytics_workspace.tf
# Dependencies: resource_group.

module "log_analytics_workspace" {
  for_each = var.enable_log_analytics_workspace ? var.log_analytics_workspace : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-log-analytics-workspace/azurerm"
  version = "0.1.2"

  name                                      = each.value.name
  resource_group_name                       = module.resource_group[each.value.resource_group_key].name
  location                                  = coalesce(each.value.location, module.resource_group[each.value.resource_group_key].location)
  log_analytics_workspace_sku               = each.value.sku
  log_analytics_workspace_retention_in_days = each.value.retention_in_days
  log_analytics_workspace_daily_quota_gb    = each.value.daily_quota_gb
  tags                                      = merge(local.common_tags, each.value.tags)
}
