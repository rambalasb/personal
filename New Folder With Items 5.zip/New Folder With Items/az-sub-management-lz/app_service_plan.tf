# app_service_plan.tf
# Dependencies: resource_group.

module "app_service_plan" {
  for_each = var.enable_app_service_plan ? var.app_service_plan : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-app-service-plan/azurerm"
  version = "0.1.0"

  name      = each.value.name
  parent_id = module.resource_group[each.value.resource_group_key].resource_id
  location  = coalesce(each.value.location, module.resource_group[each.value.resource_group_key].location)
  os_type   = each.value.os_type
  sku_name  = each.value.sku_name
  tags      = merge(local.common_tags, each.value.tags)
}
