# imports.tf
# Foundation + standard alerts. Networking/compute tiers (hub, shared, dns, dmz,
# ip-groups, ertest, runners, cyberark) add their own imports as they land.
#
# INTENTIONALLY NOT MANAGED (Azure-managed RGs, excluded from resource_group):
#   AzureBackupRG_canadacentral_1, DefaultResourceGroup-CCAN,
#   microsoft-network-canadacentral, microsoft-network-canadaeast

locals {
  sub = data.azurerm_subscription.current.id
}

# ── Resource groups (azapi, count -> this[0]) ──────────────────────────
import {
  to = module.resource_group["alerts"].module.resource_group.azapi_resource.this[0]
  id = "${local.sub}/resourceGroups/rg-alerts-connectivity-canadacentral-001"
}
import {
  to = module.resource_group["cyberark"].module.resource_group.azapi_resource.this[0]
  id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001"
}
import {
  to = module.resource_group["dmz"].module.resource_group.azapi_resource.this[0]
  id = "${local.sub}/resourceGroups/rg-dmz-connectivity-canadacentral-001"
}
import {
  to = module.resource_group["dns"].module.resource_group.azapi_resource.this[0]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001"
}
import {
  to = module.resource_group["ertest_cc"].module.resource_group.azapi_resource.this[0]
  id = "${local.sub}/resourceGroups/rg-ertest-canadacentral-001"
}
import {
  to = module.resource_group["ertest_ce"].module.resource_group.azapi_resource.this[0]
  id = "${local.sub}/resourceGroups/rg-ertest-canadaeast-001"
}
import {
  to = module.resource_group["hub_cc"].module.resource_group.azapi_resource.this[0]
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001"
}
import {
  to = module.resource_group["hub_ce"].module.resource_group.azapi_resource.this[0]
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadaeast-001"
}
import {
  to = module.resource_group["ip_groups"].module.resource_group.azapi_resource.this[0]
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global"
}
import {
  to = module.resource_group["runners"].module.resource_group.azapi_resource.this[0]
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001"
}
import {
  to = module.resource_group["shared_cc"].module.resource_group.azapi_resource.this[0]
  id = "${local.sub}/resourceGroups/rg-shared-connectivity-canadacentral-001"
}
import {
  to = module.resource_group["shared_ce"].module.resource_group.azapi_resource.this[0]
  id = "${local.sub}/resourceGroups/rg-shared-connectivity-canadaeast-001"
}

# ── Standard alerts (amba-alz wrapper -> monitoring[0]) ────────────────
import {
  to = module.monitoring[0].azurerm_monitor_activity_log_alert.this["service_outage"]
  id = "${local.sub}/resourceGroups/rg-alerts-connectivity-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/Service-Outage-Alert-canadacentral"
}
import {
  to = module.monitoring[0].azurerm_monitor_scheduled_query_rules_alert_v2.this["resource_creation"]
  id = "${local.sub}/resourceGroups/rg-alerts-connectivity-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/Resource-Creation-Alert-canadacentral"
}
import {
  to = module.monitoring[0].azurerm_monitor_scheduled_query_rules_alert_v2.this["storage_container_deletion"]
  id = "${local.sub}/resourceGroups/rg-alerts-connectivity-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/Storage-Account-Container-Deletion-Alert-canadacentral"
}
import {
  to = module.monitoring[0].azurerm_monitor_scheduled_query_rules_alert_v2.this["storage_deletion"]
  id = "${local.sub}/resourceGroups/rg-alerts-connectivity-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/Storage-Account-Deletion-Alert-canadacentral"
}
