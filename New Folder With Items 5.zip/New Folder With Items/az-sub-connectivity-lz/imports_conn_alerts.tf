# imports_conn_alerts.tf
# Native resources — direct import addresses (no AVM wrapper).

import {
  to = azurerm_monitor_metric_alert.firewall_connectivity_health
  id = "${local.sub}/resourceGroups/rg-alerts-connectivity-canadacentral-001/providers/Microsoft.Insights/metricAlerts/firewall-connectivity-health"
}
import {
  to = azurerm_monitor_metric_alert.vm_connectivity_cpu_high_warning
  id = "${local.sub}/resourceGroups/rg-alerts-connectivity-canadacentral-001/providers/Microsoft.Insights/metricAlerts/vm-connectivity-cpu-high-warning"
}
import {
  to = azurerm_monitor_metric_alert.vm_connectivity_memory_high_warning
  id = "${local.sub}/resourceGroups/rg-alerts-connectivity-canadacentral-001/providers/Microsoft.Insights/metricAlerts/vm-connectivity-memory-high-warning"
}
import {
  to = azurerm_monitor_activity_log_alert.firewall_connectivity_update
  id = "${local.sub}/resourceGroups/rg-alerts-connectivity-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/firewall-connectivity-update"
}
import {
  to = azurerm_monitor_activity_log_alert.vpn_connectivty_down
  id = "${local.sub}/resourceGroups/rg-alerts-connectivity-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/vpn-connectivty-down"
}
import {
  to = azurerm_monitor_activity_log_alert.vpn_connectivty_down_canadaeast
  id = "${local.sub}/resourceGroups/rg-alerts-connectivity-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/vpn-connectivty-down-canadaeast"
}
