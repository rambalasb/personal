# imports_virtual_network.tf — 8 vnets + subnets + peerings
# confirm AVM internal import addresses on first plan

import {
  to = module.virtual_network["vnet-cyberark-canadacentral-001"].module.virtual_network.azapi_resource.vnet
  id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cyberark-canadacentral-001"
}
import {
  to = module.virtual_network["vnet-cyberark-canadacentral-001"].module.virtual_network.module.subnet["snet-cyberark-servers-canadacentral-001"].azapi_resource.subnet
  id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cyberark-canadacentral-001/subnets/snet-cyberark-servers-canadacentral-001"
}
import {
  to = module.virtual_network["vnet-cyberark-canadacentral-001"].module.virtual_network.azapi_resource.peering["RemoteVnetToHubPeering_a8db0ae7-e4bd-4112-a74f-86be5b004e19"]
  id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cyberark-canadacentral-001/virtualNetworkPeerings/RemoteVnetToHubPeering_a8db0ae7-e4bd-4112-a74f-86be5b004e19"
}
import {
  to = module.virtual_network["vnet-dmz-external-connectivity-canadacentral-001"].module.virtual_network.azapi_resource.vnet
  id = "${local.sub}/resourceGroups/rg-dmz-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dmz-external-connectivity-canadacentral-001"
}
import {
  to = module.virtual_network["vnet-dmz-external-connectivity-canadacentral-001"].module.virtual_network.module.subnet["snet-dmz-gw-prod-canadacentral-001"].azapi_resource.subnet
  id = "${local.sub}/resourceGroups/rg-dmz-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dmz-external-connectivity-canadacentral-001/subnets/snet-dmz-gw-prod-canadacentral-001"
}
import {
  to = module.virtual_network["vnet-dmz-external-connectivity-canadacentral-001"].module.virtual_network.module.subnet["snet-dmz-gw-nonprod-canadacentral-001"].azapi_resource.subnet
  id = "${local.sub}/resourceGroups/rg-dmz-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dmz-external-connectivity-canadacentral-001/subnets/snet-dmz-gw-nonprod-canadacentral-001"
}
import {
  to = module.virtual_network["vnet-dns-connectivity-canadacentral-001"].module.virtual_network.azapi_resource.vnet
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dns-connectivity-canadacentral-001"
}
import {
  to = module.virtual_network["vnet-dns-connectivity-canadacentral-001"].module.virtual_network.module.subnet["snet-dns-inbound-canadacentral-001"].azapi_resource.subnet
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dns-connectivity-canadacentral-001/subnets/snet-dns-inbound-canadacentral-001"
}
import {
  to = module.virtual_network["vnet-dns-connectivity-canadacentral-001"].module.virtual_network.module.subnet["snet-dns-outbound-canadacentral-001"].azapi_resource.subnet
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dns-connectivity-canadacentral-001/subnets/snet-dns-outbound-canadacentral-001"
}
import {
  to = module.virtual_network["vnet-dns-connectivity-canadacentral-001"].module.virtual_network.module.subnet["snet-dns-private-endpoint-canadacentral-001"].azapi_resource.subnet
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dns-connectivity-canadacentral-001/subnets/snet-dns-private-endpoint-canadacentral-001"
}
import {
  to = module.virtual_network["vnet-dns-connectivity-canadacentral-001"].module.virtual_network.azapi_resource.peering["RemoteVnetToHubPeering_a8db0ae7-e4bd-4112-a74f-86be5b004e19"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dns-connectivity-canadacentral-001/virtualNetworkPeerings/RemoteVnetToHubPeering_a8db0ae7-e4bd-4112-a74f-86be5b004e19"
}
import {
  to = module.virtual_network["vnet-dns-connectivity-canadacentral-001"].module.virtual_network.azapi_resource.peering["peer-clz-to-mvp"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dns-connectivity-canadacentral-001/virtualNetworkPeerings/peer-clz-to-mvp"
}
import {
  to = module.virtual_network["vnet-ertest-canadacentral-001"].module.virtual_network.azapi_resource.vnet
  id = "${local.sub}/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-ertest-canadacentral-001"
}
import {
  to = module.virtual_network["vnet-ertest-canadacentral-001"].module.virtual_network.module.subnet["snet-ertest-canadacentral-001"].azapi_resource.subnet
  id = "${local.sub}/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-ertest-canadacentral-001/subnets/snet-ertest-canadacentral-001"
}
import {
  to = module.virtual_network["vnet-ertest-canadacentral-001"].module.virtual_network.azapi_resource.peering["RemoteVnetToHubPeering_a8db0ae7-e4bd-4112-a74f-86be5b004e19"]
  id = "${local.sub}/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-ertest-canadacentral-001/virtualNetworkPeerings/RemoteVnetToHubPeering_a8db0ae7-e4bd-4112-a74f-86be5b004e19"
}
import {
  to = module.virtual_network["vnet-ertest-canadaeast-001"].module.virtual_network.azapi_resource.vnet
  id = "${local.sub}/resourceGroups/rg-ertest-canadaeast-001/providers/Microsoft.Network/virtualNetworks/vnet-ertest-canadaeast-001"
}
import {
  to = module.virtual_network["vnet-ertest-canadaeast-001"].module.virtual_network.module.subnet["snet-ertest-canadaeast-001"].azapi_resource.subnet
  id = "${local.sub}/resourceGroups/rg-ertest-canadaeast-001/providers/Microsoft.Network/virtualNetworks/vnet-ertest-canadaeast-001/subnets/snet-ertest-canadaeast-001"
}
import {
  to = module.virtual_network["vnet-ertest-canadaeast-001"].module.virtual_network.azapi_resource.peering["RemoteVnetToHubPeering_38d55ab0-6c38-42de-bbf1-330ef44c8e89"]
  id = "${local.sub}/resourceGroups/rg-ertest-canadaeast-001/providers/Microsoft.Network/virtualNetworks/vnet-ertest-canadaeast-001/virtualNetworkPeerings/RemoteVnetToHubPeering_38d55ab0-6c38-42de-bbf1-330ef44c8e89"
}
import {
  to = module.virtual_network["vnet-runners-connectivity-canadacentral-001"].module.virtual_network.azapi_resource.vnet
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-runners-connectivity-canadacentral-001"
}
import {
  to = module.virtual_network["vnet-runners-connectivity-canadacentral-001"].module.virtual_network.module.subnet["snet-runners-dev-canadacentral-001"].azapi_resource.subnet
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-runners-connectivity-canadacentral-001/subnets/snet-runners-dev-canadacentral-001"
}
import {
  to = module.virtual_network["vnet-runners-connectivity-canadacentral-001"].module.virtual_network.module.subnet["snet-runners-prod-canadacentral-001"].azapi_resource.subnet
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-runners-connectivity-canadacentral-001/subnets/snet-runners-prod-canadacentral-001"
}
import {
  to = module.virtual_network["vnet-runners-connectivity-canadacentral-001"].module.virtual_network.module.subnet["AzureBastionSubnet"].azapi_resource.subnet
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-runners-connectivity-canadacentral-001/subnets/AzureBastionSubnet"
}
import {
  to = module.virtual_network["vnet-runners-connectivity-canadacentral-001"].module.virtual_network.azapi_resource.peering["RemoteVnetToHubPeering_a8db0ae7-e4bd-4112-a74f-86be5b004e19"]
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-runners-connectivity-canadacentral-001/virtualNetworkPeerings/RemoteVnetToHubPeering_a8db0ae7-e4bd-4112-a74f-86be5b004e19"
}
import {
  to = module.virtual_network["vnet-transit-connectivity-canadacentral-001"].module.virtual_network.azapi_resource.vnet
  id = "${local.sub}/resourceGroups/rg-shared-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-transit-connectivity-canadacentral-001"
}
import {
  to = module.virtual_network["vnet-transit-connectivity-canadacentral-001"].module.virtual_network.module.subnet["AzureFirewallManagementSubnet"].azapi_resource.subnet
  id = "${local.sub}/resourceGroups/rg-shared-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-transit-connectivity-canadacentral-001/subnets/AzureFirewallManagementSubnet"
}
import {
  to = module.virtual_network["vnet-transit-connectivity-canadacentral-001"].module.virtual_network.module.subnet["AzureFirewallSubnet"].azapi_resource.subnet
  id = "${local.sub}/resourceGroups/rg-shared-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-transit-connectivity-canadacentral-001/subnets/AzureFirewallSubnet"
}
import {
  to = module.virtual_network["vnet-transit-connectivity-canadacentral-001"].module.virtual_network.azapi_resource.peering["peering-ns2-edge-to-bch-transit"]
  id = "${local.sub}/resourceGroups/rg-shared-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-transit-connectivity-canadacentral-001/virtualNetworkPeerings/peering-ns2-edge-to-bch-transit"
}
import {
  to = module.virtual_network["vnet-transit-connectivity-canadacentral-001"].module.virtual_network.azapi_resource.peering["RemoteVnetToHubPeering_a8db0ae7-e4bd-4112-a74f-86be5b004e19"]
  id = "${local.sub}/resourceGroups/rg-shared-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-transit-connectivity-canadacentral-001/virtualNetworkPeerings/RemoteVnetToHubPeering_a8db0ae7-e4bd-4112-a74f-86be5b004e19"
}
import {
  to = module.virtual_network["vnet-shared-connectivity-canadacentral-001"].module.virtual_network.azapi_resource.vnet
  id = "${local.sub}/resourceGroups/rg-shared-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-shared-connectivity-canadacentral-001"
}
import {
  to = module.virtual_network["vnet-shared-connectivity-canadacentral-001"].module.virtual_network.module.subnet["snet-outbound-connectivity-canadacentral-001"].azapi_resource.subnet
  id = "${local.sub}/resourceGroups/rg-shared-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-shared-connectivity-canadacentral-001/subnets/snet-outbound-connectivity-canadacentral-001"
}
import {
  to = module.virtual_network["vnet-shared-connectivity-canadacentral-001"].module.virtual_network.azapi_resource.peering["RemoteVnetToHubPeering_a8db0ae7-e4bd-4112-a74f-86be5b004e19"]
  id = "${local.sub}/resourceGroups/rg-shared-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-shared-connectivity-canadacentral-001/virtualNetworkPeerings/RemoteVnetToHubPeering_a8db0ae7-e4bd-4112-a74f-86be5b004e19"
}
