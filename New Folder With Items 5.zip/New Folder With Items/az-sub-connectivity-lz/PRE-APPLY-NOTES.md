# az-sub-connectivity-lz — pre-apply notes

Adoption of the Sub-Connectivity vWAN estate (subscription `f3835bc1-9829-4ac8-9d7a-0999e0b29b90`).
Built tier-by-tier from the exported ARM/JSON. `terraform fmt` clean; no duplicate
variables / locals / imports / module / resource names. **564 import blocks total.**

## Built tiers

| Tier | File | Contents | Imports |
|---|---|---|---|
| Resource groups | resource_group.tf + imports.tf | 12 RGs (2 regions); 4 Azure-managed RGs excluded | 12 |
| Standard alerts | monitoring.tf + locals.tf | Service-Outage + Resource-Creation + 2 storage-deletion → mgmt AGs | 4 |
| IP groups | ip_groups.tf | 89 IP groups | 89 |
| Private DNS | private_dns_zones.tf | 39 zones + 157 vnet links | 196 |
| Virtual networks | virtual_network.tf | 8 VNets, 14 subnets, 9 peerings | 31 |
| vWAN hub | hub_vwan.tf | vWAN, 2 hubs, 4 route tables, 17 route maps, 2 routing intents, 26 hub connections, ER×2 + VPN×2 gateways, 2 vpn sites | 65 |
| Firewall | firewall.tf | 3 firewalls, 2 policies, 17 rule-collection groups (301 IP-group refs resolved) | 22 |
| Network primitives | net_primitives.tf | DDoS, 3 NAT, 3 PIP-prefix, 2 PIP, 11 NSG (+33 rules), 2 route tables, 6 private endpoints, 2 ER circuits, 2 net watchers, 6 flow logs, 2 traffic collectors | 77 |
| DNS resolver | dns_resolver.tf | resolver + inbound/outbound endpoints + forwarding ruleset | 4 |
| Spokes/compute | spokes_compute.tf | 17 VMs, 4 bastion, 1 LB, 17 NICs, 3 ssh keys, 7 maintenance configs, recovery vault | 58 |
| Connectivity alerts | conn_alerts.tf | 3 metric + 3 activity alerts → external mgmt AGs | 6 |

## MUST fill before apply (values not present in the offline export)

1. **Spoke peering targets** — the 26 vWAN hub connections' `remote_virtual_network_id` point at spoke VNets that live in **workload subscriptions**, not this sub. They're currently reconstructed under the hub RG as placeholders (`# TODO spoke RG assumed`). Set each spoke's real subscription + RG. Same for the 3 canadaeast connections and the external vWAN hub (`HV_vhub-connectivity-ca_...`, `RG_..._TODO`).
2. **Secrets** — `azurerm_vpn_gateway_connection.shared_key` (omitted) and `var.spokes_vm_admin_password` (placeholder `REPLACE_ME_PLACEHOLDER`): supply via `TF_VAR_*` / Key Vault, never commit.
3. **Cross-sub SIEM workspace id** — firewall-policy insights and flow-log traffic-analytics reference the Log Analytics workspace in the **security** subscription (`la-siem-security-…`); set its real resource ID.

## Confirm on first speculative plan

- **AVM wrapper internal import addresses** — all `module.<x>[k].module.<inner>.<resource>` targets are best-guess (headers say so); the first `plan` import error prints the exact address to `sed`-fix en masse.
- **VM wrapper versions** — `virtual-machine-linux`/`-windows` pinned `0.1.0` (unverified; others match the registry).
- **defaultRouteTable vs routing_intent** — routes may be double-managed; confirm which owns them.

## Intentionally NOT managed (Azure / backup / test artifacts)

- `Microsoft.Compute/restorePointCollections`, `Microsoft.Compute/snapshots`, `microsoft.devtestlab/schedules`, VM OS disks
- NSG `defaultSecurityRules` (read-only)
- 7 `Microsoft.AlertsManagement/actionRules` (disabled / expired suppression windows)
- `sttestingitout1` / `sttestingitout2` storage (+ event-grid topics/subscriptions) — test artifacts in the alerts RG
- 2 empty firewall rule collections (`rc-allow-sap-aem-inbound`, `rc-allow-net-fit-to-esb-nonprod`) — the provider can't represent 0-rule collections
- Transit firewall's classic inline `networkRuleCollections` — not expressible via the AVM module; migrate to a policy or manage natively

## Same guardrails as the other three LZs
Subscription/tenant from `ARM_SUBSCRIPTION_ID`/`ARM_TENANT_ID`; hardened gate (no create/replace/destroy — imports + in-place updates only); in-place tag adds accepted. Workflow: `TFC_LZ_CONNECTIVITY_WORKSPACE` / `connectivity.tfvars`.
