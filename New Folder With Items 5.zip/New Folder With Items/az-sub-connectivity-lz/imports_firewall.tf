# imports_firewall.tf
# confirm AVM internal import addresses on first plan
# Firewalls + policies import into the wrapper's inner module; rule collection groups
# are native resources in this tier.

import {
  to = module.firewall["azfw-connectivity-canadacentral-001"].module.azure_firewall.azurerm_firewall.this
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/azureFirewalls/azfw-connectivity-canadacentral-001"
}
import {
  to = module.firewall["azfw-connectivity-canadaeast-001"].module.azure_firewall.azurerm_firewall.this
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadaeast-001/providers/Microsoft.Network/azureFirewalls/azfw-connectivity-canadaeast-001"
}
import {
  to = module.firewall["azfw-transit-connectivity-canadacentral-001"].module.azure_firewall.azurerm_firewall.this
  id = "${local.sub}/resourceGroups/rg-shared-connectivity-canadacentral-001/providers/Microsoft.Network/azureFirewalls/azfw-transit-connectivity-canadacentral-001"
}
import {
  to = module.firewall_policy["azfwpol-connectivity-001"].module.firewall_policy.azurerm_firewall_policy.this
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/firewallPolicies/azfwpol-connectivity-001"
}
import {
  to = module.firewall_policy["azfwpol-connectivity-001-BACKUP-20260320-233016-UTC"].module.firewall_policy.azurerm_firewall_policy.this
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/firewallPolicies/azfwpol-connectivity-001-BACKUP-20260320-233016-UTC"
}
import {
  to = azurerm_firewall_policy_rule_collection_group.this["azfwpol-connectivity-001/rcg-1000-spoke-specific-canada-central"]
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/firewallPolicies/azfwpol-connectivity-001/ruleCollectionGroups/rcg-1000-spoke-specific-canada-central"
}
import {
  to = azurerm_firewall_policy_rule_collection_group.this["azfwpol-connectivity-001-BACKUP-20260320-233016-UTC/rcg-1000-spoke-specific-canada-central"]
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/firewallPolicies/azfwpol-connectivity-001-BACKUP-20260320-233016-UTC/ruleCollectionGroups/rcg-1000-spoke-specific-canada-central"
}
import {
  to = azurerm_firewall_policy_rule_collection_group.this["azfwpol-connectivity-001/rcg-20000-spoke-specific-canada-east"]
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/firewallPolicies/azfwpol-connectivity-001/ruleCollectionGroups/rcg-20000-spoke-specific-canada-east"
}
import {
  to = azurerm_firewall_policy_rule_collection_group.this["azfwpol-connectivity-001-BACKUP-20260320-233016-UTC/rcg-20000-spoke-specific-canada-east"]
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/firewallPolicies/azfwpol-connectivity-001-BACKUP-20260320-233016-UTC/ruleCollectionGroups/rcg-20000-spoke-specific-canada-east"
}
import {
  to = azurerm_firewall_policy_rule_collection_group.this["azfwpol-connectivity-001-BACKUP-20260320-233016-UTC/rcg-300-cyberark-SIA-baseline"]
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/firewallPolicies/azfwpol-connectivity-001-BACKUP-20260320-233016-UTC/ruleCollectionGroups/rcg-300-cyberark-SIA-baseline"
}
import {
  to = azurerm_firewall_policy_rule_collection_group.this["azfwpol-connectivity-001/rcg-39800-transit-to-spoke"]
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/firewallPolicies/azfwpol-connectivity-001/ruleCollectionGroups/rcg-39800-transit-to-spoke"
}
import {
  to = azurerm_firewall_policy_rule_collection_group.this["azfwpol-connectivity-001/rcg-40000-onprem-to-spokes"]
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/firewallPolicies/azfwpol-connectivity-001/ruleCollectionGroups/rcg-40000-onprem-to-spokes"
}
import {
  to = azurerm_firewall_policy_rule_collection_group.this["azfwpol-connectivity-001-BACKUP-20260320-233016-UTC/rcg-40000-onprem-to-spokes"]
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/firewallPolicies/azfwpol-connectivity-001-BACKUP-20260320-233016-UTC/ruleCollectionGroups/rcg-40000-onprem-to-spokes"
}
import {
  to = azurerm_firewall_policy_rule_collection_group.this["azfwpol-connectivity-001-BACKUP-20260320-233016-UTC/rcg-41000-spokes-to-onprem"]
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/firewallPolicies/azfwpol-connectivity-001-BACKUP-20260320-233016-UTC/ruleCollectionGroups/rcg-41000-spokes-to-onprem"
}
import {
  to = azurerm_firewall_policy_rule_collection_group.this["azfwpol-connectivity-001/rcg-490-global-security-rexception"]
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/firewallPolicies/azfwpol-connectivity-001/ruleCollectionGroups/rcg-490-global-security-rexception"
}
import {
  to = azurerm_firewall_policy_rule_collection_group.this["azfwpol-connectivity-001-BACKUP-20260320-233016-UTC/rcg-490-global-security-rexception"]
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/firewallPolicies/azfwpol-connectivity-001-BACKUP-20260320-233016-UTC/ruleCollectionGroups/rcg-490-global-security-rexception"
}
import {
  to = azurerm_firewall_policy_rule_collection_group.this["azfwpol-connectivity-001/rcg-500-global-security-baseline"]
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/firewallPolicies/azfwpol-connectivity-001/ruleCollectionGroups/rcg-500-global-security-baseline"
}
import {
  to = azurerm_firewall_policy_rule_collection_group.this["azfwpol-connectivity-001-BACKUP-20260320-233016-UTC/rcg-500-global-security-baseline"]
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/firewallPolicies/azfwpol-connectivity-001-BACKUP-20260320-233016-UTC/ruleCollectionGroups/rcg-500-global-security-baseline"
}
import {
  to = azurerm_firewall_policy_rule_collection_group.this["azfwpol-connectivity-001/rcg-64900-deny-all"]
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/firewallPolicies/azfwpol-connectivity-001/ruleCollectionGroups/rcg-64900-deny-all"
}
import {
  to = azurerm_firewall_policy_rule_collection_group.this["azfwpol-connectivity-001-BACKUP-20260320-233016-UTC/rcg-64900-deny-all"]
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/firewallPolicies/azfwpol-connectivity-001-BACKUP-20260320-233016-UTC/ruleCollectionGroups/rcg-64900-deny-all"
}
import {
  to = azurerm_firewall_policy_rule_collection_group.this["azfwpol-connectivity-001/rcg-800-global-internet-baseline"]
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/firewallPolicies/azfwpol-connectivity-001/ruleCollectionGroups/rcg-800-global-internet-baseline"
}
import {
  to = azurerm_firewall_policy_rule_collection_group.this["azfwpol-connectivity-001-BACKUP-20260320-233016-UTC/rcg-800-global-internet-baseline"]
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/firewallPolicies/azfwpol-connectivity-001-BACKUP-20260320-233016-UTC/ruleCollectionGroups/rcg-800-global-internet-baseline"
}
