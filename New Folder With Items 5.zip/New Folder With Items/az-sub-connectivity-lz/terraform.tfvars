# ── Shared ─────────────────────────────────────────────────────────────
# subscription_id / tenant_id come from ARM_SUBSCRIPTION_ID / ARM_TENANT_ID.
environment = "prod"
location    = "canadacentral"

tags = {
  owner = "connectivity-platform"
}

enable_amba = false

# ── Feature flags ──────────────────────────────────────────────────────
enable_resource_group = true
enable_monitoring     = true

# ── Resource groups (12 managed; 4 Azure-managed RGs excluded) ─────────
resource_group = {
  "alerts"    = { name = "rg-alerts-connectivity-canadacentral-001" }
  "cyberark"  = { name = "rg-cyberark-canadacentral-001" }
  "dmz"       = { name = "rg-dmz-connectivity-canadacentral-001" }
  "dns"       = { name = "rg-dns-connectivity-canadacentral-001" }
  "ertest_cc" = { name = "rg-ertest-canadacentral-001" }
  "ertest_ce" = { name = "rg-ertest-canadaeast-001", location = "canadaeast" }
  "hub_cc"    = { name = "rg-hub-connectivity-canadacentral-001" }
  "hub_ce"    = { name = "rg-hub-connectivity-canadaeast-001", location = "canadaeast" }
  "ip_groups" = { name = "rg-ip-groups-connectivity-global" }
  "runners"   = { name = "rg-runners-connectivity-canadacentral-001" }
  "shared_cc" = { name = "rg-shared-connectivity-canadacentral-001" }
  "shared_ce" = { name = "rg-shared-connectivity-canadaeast-001", location = "canadaeast" }
}

# ── IP groups (89) ──────────────────────────────────────────────────
enable_ip_groups = true

ip_groups = {
  "ipgrp-app-openai-nonprod-canadacentral-001"                         = { location = "canadacentral", ip_addresses = ["10.195.28.9"] }
  "ipgrp-app-openai-prod-canadacentral-001"                            = { location = "canadacentral", ip_addresses = ["10.195.12.9"] }
  "ipgrp-bchsiops-jumphost"                                            = { location = "canadacentral", ip_addresses = ["10.242.30.30", "172.25.81.3"] }
  "ipgrp-cacentral-caeast-ertest-vm"                                   = { location = "canadacentral", ip_addresses = ["10.195.118.7", "10.195.118.8", "10.196.114.7"] }
  "ipgrp-cacentral-clz-dev-subnets"                                    = { location = "canadacentral", ip_addresses = ["10.195.96.0/22", "10.195.80.0/22", "10.195.64.0/22", "172.17.0.0/22", "172.18.0.0/16", "172.16.0.0/16", "172.19.0.0/16", "172.20.0.0/16", "10.0.0.0/16"] }
  "ipgrp-cacentral-clz-dns-resolvers"                                  = { location = "canadacentral", ip_addresses = ["10.195.1.4/32", "10.196.1.4/32", "10.195.4.7/32"] }
  "ipgrp-cacentral-clz-monitor"                                        = { location = "canadacentral", ip_addresses = ["10.195.6.7/32", "10.195.6.14/32", "10.195.6.17/32", "10.195.6.18/32", "10.195.6.8/32", "10.195.6.12/32", "10.195.6.15/32", "10.195.6.9/32", "10.195.6.11/32", "10.195.6.10/32"] }
  "ipgrp-cacentral-clz-prod-subnets"                                   = { location = "canadacentral", ip_addresses = ["10.195.48.0/22", "10.195.116.0/26", "10.195.4.0/22", "10.195.118.0/23", "10.196.114.0/23", "10.195.32.0/22", "10.195.16.0/22", "10.195.114.0/23", "10.195.117.0/24"] }
  "ipgrp-cacentral-clz-subnets"                                        = { location = "canadacentral", ip_addresses = ["10.195.0.0/16"] }
  "ipgrp-cacentral-cops-nonprod-vnet"                                  = { location = "canadacentral", ip_addresses = ["10.195.96.0/22"] }
  "ipgrp-cacentral-cops-prod-vnet"                                     = { location = "canadacentral", ip_addresses = ["10.195.48.0/22"] }
  "ipgrp-cacentral-cyberark-vm-ips"                                    = { location = "canadacentral", ip_addresses = ["10.195.116.4", "10.195.116.5"] }
  "ipgrp-cacentral-cyberark-vnet"                                      = { location = "canadacentral", ip_addresses = ["10.195.116.0/26"] }
  "ipgrp-cacentral-dev-runner-ips"                                     = { location = "canadacentral", ip_addresses = ["10.195.114.7"] }
  "ipgrp-cacentral-dns-connectivity-vnet"                              = { location = "canadacentral", ip_addresses = ["10.195.4.0/22"] }
  "ipgrp-cacentral-ertest-vnet"                                        = { location = "canadacentral", ip_addresses = ["10.195.118.0/23"] }
  "ipgrp-cacentral-fit-nonprod-vnet"                                   = { location = "canadacentral", ip_addresses = ["10.195.80.0/22"] }
  "ipgrp-cacentral-fit-prod-vnet"                                      = { location = "canadacentral", ip_addresses = ["10.195.32.0/22"] }
  "ipgrp-cacentral-hosted-runners"                                     = { location = "canadacentral", ip_addresses = ["10.195.114.7/32", "10.195.115.7/32", "10.195.114.9/32", "10.195.115.9/32"] }
  "ipgrp-cacentral-hosted-runners-vnet"                                = { location = "canadacentral", ip_addresses = ["10.195.114.0/23"] }
  "ipgrp-cacentral-mds-ips"                                            = { location = "canadacentral", ip_addresses = ["10.195.120.4/32", "10.195.120.5/32", "10.195.120.6/32", "10.195.120.7/32", "10.195.120.8/32", "10.195.120.9/32"] }
  "ipgrp-cacentral-nonprod-cops-apps"                                  = { location = "canadacentral", ip_addresses = ["10.195.98.8/32", "10.195.98.7/32", "10.195.96.0/24", "10.195.50.8/32", "10.195.50.6/32", "10.195.48.0/26"] }
  "ipgrp-cacentral-nonprod-cops-db"                                    = { location = "canadacentral", ip_addresses = ["10.195.98.6/32", "10.195.50.7/32"] }
  "ipgrp-cacentral-nonprod-fit-apps"                                   = { location = "canadacentral", ip_addresses = ["10.195.82.6/32", "10.195.82.7/32", "10.195.80.4/32", "10.195.80.0/24", "10.195.81.4/32", "10.195.33.4", "10.195.32.4", "10.195.34.8"] }
  "ipgrp-cacentral-nonprod-pta-apps"                                   = { location = "canadacentral", ip_addresses = ["10.195.64.132/32", "10.195.64.4/32"] }
  "ipgrp-cacentral-nonprod-pta-db"                                     = { location = "canadacentral", ip_addresses = ["10.195.66.6/32"] }
  "ipgrp-cacentral-prod-cops-apps"                                     = { location = "canadacentral", ip_addresses = ["10.195.48.0/26"] }
  "ipgrp-cacentral-prod-cops-db"                                       = { location = "canadacentral", ip_addresses = ["10.195.49.0/26"] }
  "ipgrp-cacentral-prod-fit-apps"                                      = { location = "canadacentral", ip_addresses = ["10.195.32.4/32", "10.195.34.8", "10.195.34.0/24", "10.195.32.0/24"] }
  "ipgrp-cacentral-prod-pta-apps"                                      = { location = "canadacentral", ip_addresses = ["10.195.16.4/32"] }
  "ipgrp-cacentral-prod-pta-db"                                        = { location = "canadacentral", ip_addresses = ["10.195.18.6/32"] }
  "ipgrp-cacentral-prod-runner-ips"                                    = { location = "canadacentral", ip_addresses = ["10.195.115.7"] }
  "ipgrp-cacentral-pta-nonprod-vnet"                                   = { location = "canadacentral", ip_addresses = ["10.195.64.0/22"] }
  "ipgrp-cacentral-pta-prod-vnet"                                      = { location = "canadacentral", ip_addresses = ["10.195.16.0/22"] }
  "ipgrp-cacentral-sandbox-cacentral-1-vnet"                           = { location = "canadacentral", ip_addresses = ["172.17.0.0/16"] }
  "ipgrp-cacentral-sandbox-cacentral-2-vnet"                           = { location = "canadacentral", ip_addresses = ["172.18.0.0/16"] }
  "ipgrp-cacentral-sandbox-cacentral-vnet"                             = { location = "canadacentral", ip_addresses = ["172.16.0.0/16"] }
  "ipgrp-cacentral-shared-connectivity-vnet"                           = { location = "canadacentral", ip_addresses = ["10.195.117.0/24"] }
  "ipgrp-caeast-clz-dns-resolvers"                                     = { location = "canadacentral", ip_addresses = ["10.196.1.4"] }
  "ipgrp-caeast-clz-subnets"                                           = { location = "canadacentral", ip_addresses = ["10.196.0.0/16"] }
  "ipgrp-caeast-ertest-vnet"                                           = { location = "canadacentral", ip_addresses = ["10.196.114.0/23"] }
  "ipgrp-cc-ns2-subnet"                                                = { location = "canadacentral", ip_addresses = ["10.237.0.0/21"] }
  "ipgrp-clz-monitor-ips"                                              = { location = "canadacentral", ip_addresses = ["10.195.6.7/32", "10.195.6.14/32", "10.195.6.17/32", "10.195.6.18/32", "10.195.6.8/32", "10.195.6.12/32", "10.195.6.15/32", "10.195.6.9/32", "10.195.6.11/32", "10.195.6.10/32", "10.195.6.13/32", "10.195.6.6/32", "10.195.6.5/32", "10.195.82.8/32", "10.195.82.9/32", "10.195.66.7/32", "10.195.66.8/32", "10.195.6.20/32", "10.195.6.21/32", "10.195.6.22/32"] }
  "ipgrp-ertest-vm-ips"                                                = { location = "canadacentral", ip_addresses = ["10.195.118.7", "10.195.118.8", "10.196.114.7"] }
  "ipgrp-func-openai-nonprod-canadacentral-001"                        = { location = "canadacentral", ip_addresses = ["10.195.28.10"] }
  "ipgrp-func-openai-prod-canadacentral-001"                           = { location = "canadacentral", ip_addresses = ["10.195.12.10"] }
  "ipgrp-ipgrp-pep-auritas-prod-canadacentral"                         = { location = "canadacentral", ip_addresses = ["10.195.121.10", "10.195.121.12"] }
  "ipgrp-kdcbch-ips"                                                   = { location = "canadacentral", ip_addresses = ["10.242.69.32", "10.242.69.100", "10.242.69.101", "10.242.69.194", "10.242.69.195", "172.25.6.58"] }
  "ipgrp-kvspoprod-canadacentral-001"                                  = { location = "canadacentral", ip_addresses = ["10.195.124.4"] }
  "ipgrp-onprem-controllers"                                           = { location = "canadacentral", ip_addresses = ["10.242.74.147/32", "10.242.74.148/32", "10.242.74.149/32", "172.25.6.17/32", "172.25.6.101/32"] }
  "ipgrp-onprem-infoblox"                                              = { location = "canadacentral", ip_addresses = ["10.242.82.58/32", "10.242.82.56/32", "172.25.4.15/32", "10.242.82.60/32", "142.52.239.60/32"] }
  "ipgrp-onprem-kdcbch-ips"                                            = { location = "canadacentral", ip_addresses = [] }
  "ipgrp-onprem-kdcbch"                                                = { location = "canadacentral", ip_addresses = ["10.242.69.32", "10.242.69.100", "10.242.69.101", "10.242.69.194", "10.242.69.195", "172.25.6.58"] }
  "ipgrp-onprem-subnets"                                               = { location = "canadacentral", ip_addresses = ["10.0.0.0-10.192.255.255", "10.197.0.0-10.255.255.255", "172.16.0.0/12", "192.168.0.0/16", "142.52.0.0/16", "155.190.0.0/16"] }
  "ipgrp-onprem-to-clzdb-subnets"                                      = { location = "canadacentral", ip_addresses = ["142.52.206.1-142.52.237.255", "142.52.198.1-142.52.202.255", "142.52.194.1-142.52.196.255", "142.52.150.1-142.52.191.255", "142.52.0.1-142.52.133.255", "10.171.0.0/19", "10.171.32.0/19", "10.171.48.0/20", "10.172.120.0/21", "10.172.128.0/21", "10.172.160.0/21", "10.172.200.0/21", "10.173.0.0/17", "10.181.10.0/24", "10.49.0.0/16", "10.60.0.0/16", "10.60.0.0/16", "10.74.0.0/16", "10.75.0.0/16", "10.76.0.0/16", "142.52.252.0/24", "172.16.0.0/16", "172.20.0.0/16", "172.21.0.0/21", "172.22.0.0/16", "172.23.0.0/16", "172.24.0.0/16", "172.28.0.0/16", "172.29.0.0/16", "10.244.23.226", "10.244.21.54", "10.244.21.54", "10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "142.52.0.0/16"] }
  "ipgrp-onprem-unix-satellite-servers"                                = { location = "canadacentral", ip_addresses = ["10.242.82.212", "172.25.5.84"] }
  "ipgrp-openai-prod-acropenaiprodcc001"                               = { location = "canadacentral", ip_addresses = ["10.195.12.4", "10.195.12.5"] }
  "ipgrp-pep-auritas-nonprod-canadacentral"                            = { location = "canadacentral", ip_addresses = ["10.195.121.200/32", "10.195.121.199/32"] }
  "ipgrp-pep-auritas-prod-canadacentral"                               = { location = "canadacentral", ip_addresses = ["10.195.121.10", "10.195.121.12"] }
  "ipgrp-pep-df-fabric-nonprod-canadacentral-001"                      = { location = "canadacentral", ip_addresses = ["10.195.127.134"] }
  "ipgrp-pep-kdcazdevjumpp1"                                           = { location = "canadacentral", ip_addresses = ["10.242.112.1"] }
  "ipgrp-pep-kv-spo-nonprod-cc"                                        = { location = "canadacentral", ip_addresses = ["10.195.125.4"] }
  "ipgrp-pep-kvfabricnonprodcc001"                                     = { location = "canadacentral", ip_addresses = ["10.195.127.132"] }
  "ipgrp-pep-kvfabricnonprodcc001-vm-fabric-nonprod-canadacentral-001" = { location = "canadacentral", ip_addresses = [] }
  "ipgrp-pep-kvfabricprodcac001"                                       = { location = "canadacentral", ip_addresses = ["10.195.123.132"] }
  "ipgrp-pep-psql-openai-nonprod-cc-001"                               = { location = "canadacentral", ip_addresses = ["10.195.28.13"] }
  "ipgrp-pep-psql-openai-prod-cc-001"                                  = { location = "canadacentral", ip_addresses = ["10.195.12.11"] }
  "ipgrp-pep-stazpkcapture-prod-canadacentral-001"                     = { location = "canadacentral", ip_addresses = ["10.195.6.24"] }
  "ipgrp-pep-stfabricnonprodcac001"                                    = { location = "canadacentral", ip_addresses = ["10.195.127.135", "10.195.127.133"] }
  "ipgrp-pep-stfabricprodcac001"                                       = { location = "canadacentral", ip_addresses = ["10.195.123.135", "10.195.123.134"] }
  "ipgrp-pep-vm-fabric-nonprod-canadacentral-001"                      = { location = "canadacentral", ip_addresses = ["10.195.127.4"] }
  "ipgrp-snet-auritas-nonprod-app-canadacentral-001"                   = { location = "canadacentral", ip_addresses = ["10.195.121.128/26"] }
  "ipgrp-snet-auritas-nonprod-pep-canadacentral-001"                   = { location = "canadacentral", ip_addresses = ["10.195.121.192/26"] }
  "ipgrp-snet-auritas-prod-app-canadacentral-001"                      = { location = "canadacentral", ip_addresses = ["10.195.121.64/26"] }
  "ipgrp-snet-auritas-prod-pep-canadacentral-001"                      = { location = "canadacentral", ip_addresses = ["10.195.121.0/26"] }
  "ipgrp-vm-openai-prod-canadacentral-001"                             = { location = "canadacentral", ip_addresses = ["10.195.14.4"] }
  "ipgrp-vnet-auritas-nonprod-canadacentral"                           = { location = "canadacentral", ip_addresses = ["10.195.121.128/25"] }
  "ipgrp-vnet-auritas-prod-canadacentral"                              = { location = "canadacentral", ip_addresses = ["10.195.121.0/25"] }
  "ipgrp-vnet-fabric-nonprod-canadacentral"                            = { location = "canadacentral", ip_addresses = ["10.195.127.0/24"] }
  "ipgrp-vnet-fabric-prod-canadacentral"                               = { location = "canadacentral", ip_addresses = ["10.195.123.0/24"] }
  "ipgrp-vnet-mds-prod-canadacentral"                                  = { location = "canadacentral", ip_addresses = ["10.195.120.0/24"] }
  "ipgrp-vnet-openai-nonprod-canadacentral-001"                        = { location = "canadacentral", ip_addresses = ["10.195.28.0/22"] }
  "ipgrp-vnet-solace-nonprod-canadacentral"                            = { location = "canadacentral", ip_addresses = ["10.195.112.0/24"] }
  "ipgrp-vnet-spo-nonprod-canadacentral"                               = { location = "canadacentral", ip_addresses = ["10.195.125.0/24"] }
  "ipgrp-vnet-spo-nonprod-canadaeast"                                  = { location = "canadacentral", ip_addresses = ["10.196.125.0/24"] }
  "ipgrp-vnet-spo-prod-canadacentral-001"                              = { location = "canadacentral", ip_addresses = ["10.195.124.0/24"] }
  "ipgrp-vnet-spo-prod-canadaeast-001"                                 = { location = "canadacentral", ip_addresses = ["10.196.124.0/24"] }
  "ipgrp-vnet-transit-connectivity-canadacentral"                      = { location = "canadacentral", ip_addresses = ["10.195.122.0/26"] }
  "psql-openai-nonprod-cc-001"                                         = { location = "canadacentral", ip_addresses = ["10.195.28.13"] }
}

# ── Private DNS zones (39) + vnet links (157) ───────────────────────
enable_private_dns_zones = true

private_dns_zones = {
  "app-fit-nonprod-canadacentral-001.appserviceenvironment.net" = {
    domain_name = "app-fit-nonprod-canadacentral-001.appserviceenvironment.net"
    virtual_network_links = {
      "link-fit-dns-canadacentral-001"                   = { name = "link-fit-dns-canadacentral-001", virtual_network_id = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-sites-dns-canadacentral-001"                 = { name = "link-sites-dns-canadacentral-001", virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dns-connectivity-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-sites-runners-canadacentral-001"             = { name = "link-sites-runners-canadacentral-001", virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-runners-connectivity-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-sites-shared-connectivity-canadacentral-001" = { name = "link-sites-shared-connectivity-canadacentral-001", virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-shared-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-shared-connectivity-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
    }
  }
  "bchydro.bc.ca" = {
    domain_name = "bchydro.bc.ca"
    virtual_network_links = {
      "link-cops-canadacentral-001"             = { name = "link-cops-canadacentral-001", virtual_network_id = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-nonprod-canadacentral-001", registration_enabled = true, resolution_policy = "Default" }
      "link-dns-connectivity-canadacentral-001" = { name = "link-dns-connectivity-canadacentral-001", virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dns-connectivity-canadacentral-001", registration_enabled = true, resolution_policy = "Default" }
      "link-fabric-nonprod-canadacentral-001"   = { name = "link-fabric-nonprod-canadacentral-001", virtual_network_id = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/rg-fabric-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-fit-nonprod-canadacentral-001"      = { name = "link-fit-nonprod-canadacentral-001", virtual_network_id = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-nonprod-canadacentral-001", registration_enabled = true, resolution_policy = "Default" }
      "link-fit-prod-canadacentral-001"         = { name = "link-fit-prod-canadacentral-001", virtual_network_id = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-prod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-pta-nonprod-canadacentral-001"      = { name = "link-pta-nonprod-canadacentral-001", virtual_network_id = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-nonprod-canadacentral-001", registration_enabled = true, resolution_policy = "Default" }
      "link-runners-canadacentral-001"          = { name = "link-runners-canadacentral-001", virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-runners-connectivity-canadacentral-001", registration_enabled = true, resolution_policy = "Default" }
    }
  }
  "internal.bchydro.bc.ca" = {
    domain_name = "internal.bchydro.bc.ca"
    virtual_network_links = {
      "dns-link-canadacentral"                      = { name = "dns-link-canadacentral", virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dns-connectivity-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "fit-link-canadacentral"                      = { name = "fit-link-canadacentral", virtual_network_id = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-cyberark-servers-cacentral-001"         = { name = "link-cyberark-servers-cacentral-001", virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cyberark-canadacentral-001", registration_enabled = true, resolution_policy = "Default" }
      "link-fit-prod-canadacentral-001"             = { name = "link-fit-prod-canadacentral-001", virtual_network_id = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-prod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-sites-cops-nonprod-canadacentral-001"   = { name = "link-sites-cops-nonprod-canadacentral-001", virtual_network_id = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-sites-cops-prod-canadacentral-001"      = { name = "link-sites-cops-prod-canadacentral-001", virtual_network_id = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-prod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-vnet-auritas-nonprod-canadacentral-001" = { name = "link-vnet-auritas-nonprod-canadacentral-001", virtual_network_id = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-auritas-nonprod-canadacentral-001", registration_enabled = true, resolution_policy = "Default" }
      "link-vnet-auritas-prod-canadacentral-001"    = { name = "link-vnet-auritas-prod-canadacentral-001", virtual_network_id = "/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07/resourceGroups/rg-auritas-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-auritas-prod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "runners-link-canadacentral"                  = { name = "runners-link-canadacentral", virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-runners-connectivity-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "shared-link-canadacentral"                   = { name = "shared-link-canadacentral", virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-shared-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-shared-connectivity-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
    }
  }
  "privatelink.6082b7ce55ac.database.windows.net" = {
    domain_name = "privatelink.6082b7ce55ac.database.windows.net"
    virtual_network_links = {
      "managed-instance-dns-connectivity-link" = { name = "managed-instance-dns-connectivity-link", virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dns-connectivity-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "managed-instance-runners-link"          = { name = "managed-instance-runners-link", virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-runners-connectivity-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "mi-sql-pta-privatelink-canadacentral"   = { name = "mi-sql-pta-privatelink-canadacentral", virtual_network_id = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
    }
  }
  "privatelink.afs.azure.net" = {
    domain_name           = "privatelink.afs.azure.net"
    virtual_network_links = {}
  }
  "privatelink.agentsvc.azure-automation.net" = {
    domain_name = "privatelink.agentsvc.azure-automation.net"
    virtual_network_links = {
      "link-cops-nonprod-canadacentral"   = { name = "link-cops-nonprod-canadacentral", virtual_network_id = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-cops-prod-canadacentral"      = { name = "link-cops-prod-canadacentral", virtual_network_id = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-prod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-fit-nonprod-canadacentral"    = { name = "link-fit-nonprod-canadacentral", virtual_network_id = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-fit-prod-canadacentral"       = { name = "link-fit-prod-canadacentral", virtual_network_id = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-prod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-openai-nonprod-canadacentral" = { name = "link-openai-nonprod-canadacentral", virtual_network_id = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-pta-nonprod-canadacentral"    = { name = "link-pta-nonprod-canadacentral", virtual_network_id = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-pta-prod-canadacentral"       = { name = "link-pta-prod-canadacentral", virtual_network_id = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-prod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "ryv5tt5odaoak"                     = { name = "ryv5tt5odaoak", virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dns-connectivity-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
    }
  }
  "privatelink.aiservices.azure.com" = {
    domain_name           = "privatelink.aiservices.azure.com"
    virtual_network_links = {}
  }
  "privatelink.azurecr.io" = {
    domain_name = "privatelink.azurecr.io"
    virtual_network_links = {
      "link-dns-connectivity-canadacentral-001" = { name = "link-dns-connectivity-canadacentral-001", virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dns-connectivity-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-openai-vnet-canadacentral-link"     = { name = "link-openai-vnet-canadacentral-link", virtual_network_id = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-openai-vnet-prod-canadacentral-001" = { name = "link-openai-vnet-prod-canadacentral-001", virtual_network_id = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-prod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
    }
  }
  "privatelink.azuresynapse.net" = {
    domain_name           = "privatelink.azuresynapse.net"
    virtual_network_links = {}
  }
  "privatelink.azurewebsites.net" = {
    domain_name = "privatelink.azurewebsites.net"
    virtual_network_links = {
      "link-auritas-nonprod-canadacentral-001"           = { name = "link-auritas-nonprod-canadacentral-001", virtual_network_id = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-auritas-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-openai-vnet-canadacentral-001"               = { name = "link-openai-vnet-canadacentral-001", virtual_network_id = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-openai-vnet-prod-canadacentral-001"          = { name = "link-openai-vnet-prod-canadacentral-001", virtual_network_id = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-prod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-sites-cops-nonprod-canadacentral-001"        = { name = "link-sites-cops-nonprod-canadacentral-001", virtual_network_id = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-sites-cops-prod-canadacentral-001"           = { name = "link-sites-cops-prod-canadacentral-001", virtual_network_id = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-prod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-sites-dns-canadacentral-001"                 = { name = "link-sites-dns-canadacentral-001", virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dns-connectivity-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-sites-fit-nonprod-canadacentral-001"         = { name = "link-sites-fit-nonprod-canadacentral-001", virtual_network_id = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-sites-fit-prod-canadacentral-001"            = { name = "link-sites-fit-prod-canadacentral-001", virtual_network_id = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-prod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-sites-runners-canadacentral-001"             = { name = "link-sites-runners-canadacentral-001", virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-runners-connectivity-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-sites-shared-connectivity-canadacentral-001" = { name = "link-sites-shared-connectivity-canadacentral-001", virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-shared-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-shared-connectivity-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
    }
  }
  "privatelink.blob.core.windows.net" = {
    domain_name = "privatelink.blob.core.windows.net"
    virtual_network_links = {
      "link-auritas-prod-canadacentral-001"         = { name = "link-auritas-prod-canadacentral-001", virtual_network_id = "/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07/resourceGroups/rg-auritas-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-auritas-prod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-blob-cops-nonprod-canadacentral-001"    = { name = "link-blob-cops-nonprod-canadacentral-001", virtual_network_id = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-blob-cops-prod-canadacentral-001"       = { name = "link-blob-cops-prod-canadacentral-001", virtual_network_id = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-prod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-blob-dns-canadacentral-001"             = { name = "link-blob-dns-canadacentral-001", virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dns-connectivity-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-blob-fit-nonprod-canadacentral-001"     = { name = "link-blob-fit-nonprod-canadacentral-001", virtual_network_id = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-blob-fit-prod-canadacentral-001"        = { name = "link-blob-fit-prod-canadacentral-001", virtual_network_id = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-prod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-blob-pta-nonprod-canadacentral-001"     = { name = "link-blob-pta-nonprod-canadacentral-001", virtual_network_id = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-blob-pta-prod-canadacentral-001"        = { name = "link-blob-pta-prod-canadacentral-001", virtual_network_id = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-prod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-blob-runners-canadacentral-001"         = { name = "link-blob-runners-canadacentral-001", virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-runners-connectivity-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-mft-dev-canadacentral-001"              = { name = "link-mft-dev-canadacentral-001", virtual_network_id = "/subscriptions/1b4f6411-516b-4bec-9a22-6d64c2ff3339/resourceGroups/rg-mft-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-mft-dev-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-openai-vnet-canadacentral-001"          = { name = "link-openai-vnet-canadacentral-001", virtual_network_id = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-openai-vnet-prod-canadacentral-001"     = { name = "link-openai-vnet-prod-canadacentral-001", virtual_network_id = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-prod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-vnet-auritas-nonprod-canadacentral-001" = { name = "link-vnet-auritas-nonprod-canadacentral-001", virtual_network_id = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-auritas-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-vnet-fabric-nonprod-canadacentral-001"  = { name = "link-vnet-fabric-nonprod-canadacentral-001", virtual_network_id = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/rg-fabric-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-vnet-fabric-prod-canadacentral-001"     = { name = "link-vnet-fabric-prod-canadacentral-001", virtual_network_id = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-prod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-vnet-mds-prod-canadacentral-001"        = { name = "link-vnet-mds-prod-canadacentral-001", virtual_network_id = "/subscriptions/dea89b5c-c8a0-4f3e-810e-c36a51501f29/resourceGroups/rg-network-mds-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-mds-prod-canadacentral", registration_enabled = false, resolution_policy = "Default" }
    }
  }
  "privatelink.canadacentral.azmk8s.io" = {
    domain_name           = "privatelink.canadacentral.azmk8s.io"
    virtual_network_links = {}
  }
  "privatelink.canadaeast.azmk8s.io" = {
    domain_name           = "privatelink.canadaeast.azmk8s.io"
    virtual_network_links = {}
  }
  "privatelink.cnc.backup.windowsazure.com" = {
    domain_name = "privatelink.cnc.backup.windowsazure.com"
    virtual_network_links = {
      "5kuztzayyvoh2"                           = { name = "5kuztzayyvoh2", virtual_network_id = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "g3sclxwzc33p2"                           = { name = "g3sclxwzc33p2", virtual_network_id = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-dns-connectivity-canadacentral-001" = { name = "link-dns-connectivity-canadacentral-001", virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dns-connectivity-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
    }
  }
  "privatelink.cognitiveservices.azure.com" = {
    domain_name = "privatelink.cognitiveservices.azure.com"
    virtual_network_links = {
      "link-openai-vnet-canadacentral-001"      = { name = "link-openai-vnet-canadacentral-001", virtual_network_id = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-openai-vnet-prod-canadacentral-001" = { name = "link-openai-vnet-prod-canadacentral-001", virtual_network_id = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-prod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
    }
  }
  "privatelink.d1b5826aa498.database.windows.net" = {
    domain_name = "privatelink.d1b5826aa498.database.windows.net"
    virtual_network_links = {
      "managed-instance-dns-connectivity-link" = { name = "managed-instance-dns-connectivity-link", virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dns-connectivity-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "managed-instance-runners-link"          = { name = "managed-instance-runners-link", virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-runners-connectivity-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "mi-sql-pta-privatelink-canadacentral"   = { name = "mi-sql-pta-privatelink-canadacentral", virtual_network_id = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-prod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "pta-vnet-link-shared-connectivity"      = { name = "pta-vnet-link-shared-connectivity", virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-shared-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-shared-connectivity-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
    }
  }
  "privatelink.database.windows.net" = {
    domain_name = "privatelink.database.windows.net"
    virtual_network_links = {
      "link-mft-dev-canadacentral-001"          = { name = "link-mft-dev-canadacentral-001", virtual_network_id = "/subscriptions/1b4f6411-516b-4bec-9a22-6d64c2ff3339/resourceGroups/rg-mft-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-mft-dev-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-sql-cops-nonprod-canadacentral-001" = { name = "link-sql-cops-nonprod-canadacentral-001", virtual_network_id = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-sql-cops-prod-canadacentral-001"    = { name = "link-sql-cops-prod-canadacentral-001", virtual_network_id = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-prod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-sql-dns-canadacentral-001"          = { name = "link-sql-dns-canadacentral-001", virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dns-connectivity-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-sql-pta-nonprod-canadacentral-001"  = { name = "link-sql-pta-nonprod-canadacentral-001", virtual_network_id = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-sql-runners-canadacentral-001"      = { name = "link-sql-runners-canadacentral-001", virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-runners-connectivity-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
    }
  }
  "privatelink.datafactory.azure.net" = {
    domain_name = "privatelink.datafactory.azure.net"
    virtual_network_links = {
      "link-vnet-dns-connectivity-canadacentral-001" = { name = "link-vnet-dns-connectivity-canadacentral-001", virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dns-connectivity-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-vnet-fabric-nonprod-canadacentral-001"   = { name = "link-vnet-fabric-nonprod-canadacentral-001", virtual_network_id = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/rg-fabric-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-vnet-fabric-prod-canadacentral-001"      = { name = "link-vnet-fabric-prod-canadacentral-001", virtual_network_id = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-prod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
    }
  }
  "privatelink.dev.azuresynapse.net" = {
    domain_name           = "privatelink.dev.azuresynapse.net"
    virtual_network_links = {}
  }
  "privatelink.dfs.core.windows.net" = {
    domain_name = "privatelink.dfs.core.windows.net"
    virtual_network_links = {
      "link-dfs-dns-canadacentral-001"             = { name = "link-dfs-dns-canadacentral-001", virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dns-connectivity-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-vnet-fabric-nonprod-canadacentral-001" = { name = "link-vnet-fabric-nonprod-canadacentral-001", virtual_network_id = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/rg-fabric-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-vnet-fabric-prod-canadacentral-001"    = { name = "link-vnet-fabric-prod-canadacentral-001", virtual_network_id = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-prod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
    }
  }
  "privatelink.documents.azure.com" = {
    domain_name = "privatelink.documents.azure.com"
    virtual_network_links = {
      "link-dns-connectivity-canadacentral-001" = { name = "link-dns-connectivity-canadacentral-001", virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dns-connectivity-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-openai-vnet-canadacentral-001"      = { name = "link-openai-vnet-canadacentral-001", virtual_network_id = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-openai-vnet-prod-canadacentral-001" = { name = "link-openai-vnet-prod-canadacentral-001", virtual_network_id = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-prod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
    }
  }
  "privatelink.dp.kubernetesconfiguration.azure.com" = {
    domain_name = "privatelink.dp.kubernetesconfiguration.azure.com"
    virtual_network_links = {
      "link-dns-connectivity-canadacentral-001" = { name = "link-dns-connectivity-canadacentral-001", virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dns-connectivity-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-vnet-mds-prod-canadacentral"        = { name = "link-vnet-mds-prod-canadacentral", virtual_network_id = "/subscriptions/dea89b5c-c8a0-4f3e-810e-c36a51501f29/resourceGroups/rg-network-mds-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-mds-prod-canadacentral", registration_enabled = false, resolution_policy = "Default" }
    }
  }
  "privatelink.file.core.windows.net" = {
    domain_name = "privatelink.file.core.windows.net"
    virtual_network_links = {
      "link-file-cops-prod-canadacentral-001"         = { name = "link-file-cops-prod-canadacentral-001", virtual_network_id = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-prod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-files-cops-nonprod-canadacentral-001"     = { name = "link-files-cops-nonprod-canadacentral-001", virtual_network_id = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-files-dns-connectivity-canadacentral-001" = { name = "link-files-dns-connectivity-canadacentral-001", virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dns-connectivity-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-files-fit-nonprod-canadacentral-001"      = { name = "link-files-fit-nonprod-canadacentral-001", virtual_network_id = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-files-pta-nonprod-canadacentral-001"      = { name = "link-files-pta-nonprod-canadacentral-001", virtual_network_id = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-mft-dev-canadacentral-001"                = { name = "link-mft-dev-canadacentral-001", virtual_network_id = "/subscriptions/1b4f6411-516b-4bec-9a22-6d64c2ff3339/resourceGroups/rg-mft-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-mft-dev-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
    }
  }
  "privatelink.guestconfiguration.azure.com" = {
    domain_name = "privatelink.guestconfiguration.azure.com"
    virtual_network_links = {
      "link-dns-connectivity-canadacentral-001" = { name = "link-dns-connectivity-canadacentral-001", virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dns-connectivity-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-vnet-mds-prod-canadacentral"        = { name = "link-vnet-mds-prod-canadacentral", virtual_network_id = "/subscriptions/dea89b5c-c8a0-4f3e-810e-c36a51501f29/resourceGroups/rg-network-mds-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-mds-prod-canadacentral", registration_enabled = false, resolution_policy = "Default" }
    }
  }
  "privatelink.his.arc.azure.com" = {
    domain_name = "privatelink.his.arc.azure.com"
    virtual_network_links = {
      "link-dns-connectivity-canadacentral-001" = { name = "link-dns-connectivity-canadacentral-001", virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dns-connectivity-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-vnet-mds-prod-canadacentral"        = { name = "link-vnet-mds-prod-canadacentral", virtual_network_id = "/subscriptions/dea89b5c-c8a0-4f3e-810e-c36a51501f29/resourceGroups/rg-network-mds-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-mds-prod-canadacentral", registration_enabled = false, resolution_policy = "Default" }
    }
  }
  "privatelink.monitor.azure.com" = {
    domain_name = "privatelink.monitor.azure.com"
    virtual_network_links = {
      "link-cops-nonprod-canadacentral"   = { name = "link-cops-nonprod-canadacentral", virtual_network_id = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-cops-prod-canadacentral"      = { name = "link-cops-prod-canadacentral", virtual_network_id = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-prod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-fit-nonprod-canadacentral"    = { name = "link-fit-nonprod-canadacentral", virtual_network_id = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-fit-prod-canadacentral"       = { name = "link-fit-prod-canadacentral", virtual_network_id = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-prod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-openai-nonprod-canadacentral" = { name = "link-openai-nonprod-canadacentral", virtual_network_id = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-pta-nonprod-canadacentral"    = { name = "link-pta-nonprod-canadacentral", virtual_network_id = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-pta-prod-canadacentral"       = { name = "link-pta-prod-canadacentral", virtual_network_id = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-prod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "ryv5tt5odaoak"                     = { name = "ryv5tt5odaoak", virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dns-connectivity-canadacentral-001", registration_enabled = false, resolution_policy = "NxDomainRedirect" }
    }
  }
  "privatelink.ods.opinsights.azure.com" = {
    domain_name = "privatelink.ods.opinsights.azure.com"
    virtual_network_links = {
      "link-cops-nonprod-canadacentral"   = { name = "link-cops-nonprod-canadacentral", virtual_network_id = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-cops-prod-canadacentral"      = { name = "link-cops-prod-canadacentral", virtual_network_id = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-prod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-fit-nonprod-canadacentral"    = { name = "link-fit-nonprod-canadacentral", virtual_network_id = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-fit-prod-canadacentral"       = { name = "link-fit-prod-canadacentral", virtual_network_id = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-prod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-openai-nonprod-canadacentral" = { name = "link-openai-nonprod-canadacentral", virtual_network_id = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-pta-nonprod-canadacentral"    = { name = "link-pta-nonprod-canadacentral", virtual_network_id = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-pta-prod-canadacentral"       = { name = "link-pta-prod-canadacentral", virtual_network_id = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-prod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "ryv5tt5odaoak"                     = { name = "ryv5tt5odaoak", virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dns-connectivity-canadacentral-001", registration_enabled = false, resolution_policy = "NxDomainRedirect" }
    }
  }
  "privatelink.oms.opinsights.azure.com" = {
    domain_name = "privatelink.oms.opinsights.azure.com"
    virtual_network_links = {
      "link-cops-nonprod-canadacentral"   = { name = "link-cops-nonprod-canadacentral", virtual_network_id = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-cops-prod-canadacentral"      = { name = "link-cops-prod-canadacentral", virtual_network_id = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-prod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-fit-nonprod-canadacentral"    = { name = "link-fit-nonprod-canadacentral", virtual_network_id = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-fit-prod-canadacentral"       = { name = "link-fit-prod-canadacentral", virtual_network_id = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-prod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-openai-nonprod-canadacentral" = { name = "link-openai-nonprod-canadacentral", virtual_network_id = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-pta-nonprod-canadacentral"    = { name = "link-pta-nonprod-canadacentral", virtual_network_id = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-pta-prod-canadacentral"       = { name = "link-pta-prod-canadacentral", virtual_network_id = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-prod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "ryv5tt5odaoak"                     = { name = "ryv5tt5odaoak", virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dns-connectivity-canadacentral-001", registration_enabled = false, resolution_policy = "NxDomainRedirect" }
    }
  }
  "privatelink.openai.azure.com" = {
    domain_name = "privatelink.openai.azure.com"
    virtual_network_links = {
      "link-openai-vnet-canadacentral-001"      = { name = "link-openai-vnet-canadacentral-001", virtual_network_id = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-openai-vnet-prod-canadacentral-001" = { name = "link-openai-vnet-prod-canadacentral-001", virtual_network_id = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-prod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
    }
  }
  "privatelink.oracledb.azure.com" = {
    domain_name           = "privatelink.oracledb.azure.com"
    virtual_network_links = {}
  }
  "privatelink.postgres.database.azure.com" = {
    domain_name = "privatelink.postgres.database.azure.com"
    virtual_network_links = {
      "link-dns-connectivity-canadacentral-001" = { name = "link-dns-connectivity-canadacentral-001", virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dns-connectivity-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-openai-vnet-canadacentral-001"      = { name = "link-openai-vnet-canadacentral-001", virtual_network_id = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-openai-vnet-prod-canadacentral-001" = { name = "link-openai-vnet-prod-canadacentral-001", virtual_network_id = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-prod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
    }
  }
  "privatelink.queue.core.windows.net" = {
    domain_name = "privatelink.queue.core.windows.net"
    virtual_network_links = {
      "5kuztzayyvoh2"                                 = { name = "5kuztzayyvoh2", virtual_network_id = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "g3sclxwzc33p2"                                 = { name = "g3sclxwzc33p2", virtual_network_id = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-openai-vnet-canadacentral-001"            = { name = "link-openai-vnet-canadacentral-001", virtual_network_id = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-openai-vnet-prod-canadacentral-001"       = { name = "link-openai-vnet-prod-canadacentral-001", virtual_network_id = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-prod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-queue-dns-connectivity-canadacentral-001" = { name = "link-queue-dns-connectivity-canadacentral-001", virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dns-connectivity-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
    }
  }
  "privatelink.redis.azure.net" = {
    domain_name = "privatelink.redis.azure.net"
    virtual_network_links = {
      "dmzd6g33v2eog"                           = { name = "dmzd6g33v2eog", virtual_network_id = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-dns-connectivity-canadacentral-001" = { name = "link-dns-connectivity-canadacentral-001", virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dns-connectivity-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
    }
  }
  "privatelink.redis.cache.windows.net" = {
    domain_name = "privatelink.redis.cache.windows.net"
    virtual_network_links = {
      "dmzd6g33v2eog"                                 = { name = "dmzd6g33v2eog", virtual_network_id = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-cache-cops-prod-canadacentral-001"        = { name = "link-cache-cops-prod-canadacentral-001", virtual_network_id = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-prod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-cache-dns-connectivity-canadacentral-001" = { name = "link-cache-dns-connectivity-canadacentral-001", virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dns-connectivity-canadacentral-001", registration_enabled = false, resolution_policy = "NxDomainRedirect" }
    }
  }
  "privatelink.servicebus.windows.net" = {
    domain_name = "privatelink.servicebus.windows.net"
    virtual_network_links = {
      "link-dns-connectivity-canadacentral-001"    = { name = "link-dns-connectivity-canadacentral-001", virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dns-connectivity-canadacentral-001", registration_enabled = false, resolution_policy = "NxDomainRedirect" }
      "link-shared-connectivity-canadacentral-001" = { name = "link-shared-connectivity-canadacentral-001", virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-shared-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-shared-connectivity-canadacentral-001", registration_enabled = false, resolution_policy = "NxDomainRedirect" }
    }
  }
  "privatelink.sql.azuresynapse.net" = {
    domain_name           = "privatelink.sql.azuresynapse.net"
    virtual_network_links = {}
  }
  "privatelink.table.core.windows.net" = {
    domain_name = "privatelink.table.core.windows.net"
    virtual_network_links = {
      "link-dns-connectivity-canadacentral-001" = { name = "link-dns-connectivity-canadacentral-001", virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dns-connectivity-canadacentral-001", registration_enabled = false, resolution_policy = "NxDomainRedirect" }
    }
  }
  "privatelink.vaultcore.azure.net" = {
    domain_name = "privatelink.vaultcore.azure.net"
    virtual_network_links = {
      "link-mft-dev-canadacentral-001"             = { name = "link-mft-dev-canadacentral-001", virtual_network_id = "/subscriptions/1b4f6411-516b-4bec-9a22-6d64c2ff3339/resourceGroups/rg-mft-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-mft-dev-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-openai-vnet-canadacentral-001"         = { name = "link-openai-vnet-canadacentral-001", virtual_network_id = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-openai-vnet-prod-canadacentral-001"    = { name = "link-openai-vnet-prod-canadacentral-001", virtual_network_id = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-prod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-spo-nonprod-vnet-canadacentral-001"    = { name = "link-spo-nonprod-vnet-canadacentral-001", virtual_network_id = "/subscriptions/b8ee8f40-3a3f-4583-b3a2-d34541c46fec/resourceGroups/rg-spo-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-spo-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-spo-nonprod-vnet-canadaeast-001"       = { name = "link-spo-nonprod-vnet-canadaeast-001", virtual_network_id = "/subscriptions/b8ee8f40-3a3f-4583-b3a2-d34541c46fec/resourceGroups/rg-spo-nonprod-network-canadaeast-001/providers/Microsoft.Network/virtualNetworks/vnet-spo-nonprod-canadaeast-001", registration_enabled = false, resolution_policy = "Default" }
      "link-spo-prod-vnet-canadacentral-001"       = { name = "link-spo-prod-vnet-canadacentral-001", virtual_network_id = "/subscriptions/0832c60a-a0fb-4cf4-9add-b555c50e4815/resourceGroups/rg-spo-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-spo-prod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-spo-prod-vnet-canadaeast-001"          = { name = "link-spo-prod-vnet-canadaeast-001", virtual_network_id = "/subscriptions/0832c60a-a0fb-4cf4-9add-b555c50e4815/resourceGroups/rg-spo-prod-network-canadaeast-001/providers/Microsoft.Network/virtualNetworks/vnet-spo-prod-canadaeast-001", registration_enabled = false, resolution_policy = "Default" }
      "link-vault-cops-nonprod-canadacentral-001"  = { name = "link-vault-cops-nonprod-canadacentral-001", virtual_network_id = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-vault-cops-prod-canadacentral-001"     = { name = "link-vault-cops-prod-canadacentral-001", virtual_network_id = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-prod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-vault-dns-canadacentral-001"           = { name = "link-vault-dns-canadacentral-001", virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dns-connectivity-canadacentral-001", registration_enabled = false, resolution_policy = "NxDomainRedirect" }
      "link-vault-fit-nonprod-canadacentral-001"   = { name = "link-vault-fit-nonprod-canadacentral-001", virtual_network_id = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-vault-fit-prod-canadacentral-001"      = { name = "link-vault-fit-prod-canadacentral-001", virtual_network_id = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-prod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-vault-pta-nonprod-canadacentral-001"   = { name = "link-vault-pta-nonprod-canadacentral-001", virtual_network_id = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-vault-pta-prod-canadacentral-001"      = { name = "link-vault-pta-prod-canadacentral-001", virtual_network_id = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-prod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-vault-runners-canadacentral-001"       = { name = "link-vault-runners-canadacentral-001", virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-runners-connectivity-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-vnet-fabric-nonprod-canadacentral-001" = { name = "link-vnet-fabric-nonprod-canadacentral-001", virtual_network_id = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/rg-fabric-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-nonprod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
      "link-vnet-fabric-prod-canadacentral-001"    = { name = "link-vnet-fabric-prod-canadacentral-001", virtual_network_id = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-prod-canadacentral-001", registration_enabled = false, resolution_policy = "Default" }
    }
  }
  "privatelink.web.core.windows.net" = {
    domain_name = "privatelink.web.core.windows.net"
    virtual_network_links = {
      "link-dns-connectivity-canadacentral-001" = { name = "link-dns-connectivity-canadacentral-001", virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dns-connectivity-canadacentral-001", registration_enabled = false, resolution_policy = "NxDomainRedirect" }
    }
  }
}
