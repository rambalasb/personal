# private_dns_zones.tf
# 39 private DNS zones + 157 vnet links in rg-dns-connectivity-canadacentral-001.
# Sourced from per-resource JSON (real names).

variable "enable_private_dns_zones" {
  type    = bool
  default = false
}

variable "private_dns_zones" {
  type = map(object({
    domain_name = string
    virtual_network_links = optional(map(object({
      name                 = string
      virtual_network_id   = string
      registration_enabled = optional(bool, false)
      resolution_policy    = optional(string, "Default")
    })), {})
  }))
  default = {}
}

module "private_dns_zone" {
  for_each = var.enable_private_dns_zones ? var.private_dns_zones : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-private-dns-zone/azurerm"
  version = "1.0.0"

  domain_name           = each.value.domain_name
  parent_id             = module.resource_group["dns"].resource_id
  virtual_network_links = each.value.virtual_network_links
  tags                  = local.common_tags
}
