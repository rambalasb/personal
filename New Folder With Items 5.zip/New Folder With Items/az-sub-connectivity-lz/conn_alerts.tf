# conn_alerts.tf
# Connectivity-specific alerts in rg-alerts-connectivity-canadacentral-001.
# Native azurerm resources — the amba-alz wrapper (monitoring.tf) covers the 4
# standard alerts only. Action groups are external in the management sub.
#
# NOT MANAGED (test artifacts / one-off suppressions in the same RG, left for
# review — deliberately not reproduced here):
#   - Microsoft.AlertsManagement/actionRules: "Alert suppression on VPN
#     connectivity" and "suppress backup alerts". Both disabled, with past-dated
#     one-shot suppression windows (2026-05-12 and 2026-04-22). The live export
#     shows two; the remaining alert processing rules referenced elsewhere are
#     likewise disabled/expired suppressions.
#   - Storage accounts sttestingitout1 / sttestingitout2 (Standard_RAGRS, public
#     access disabled) plus their EventGrid system topics and the
#     StorageAntimalwareSubscription event subscriptions (Defender malware
#     scanning webhooks), and the blob/file/queue/table service configs. These
#     look like ad-hoc test artifacts, not connectivity infrastructure.

locals {
  # Scopes live in the hub tier RGs.
  conn_alerts_azfw_cc_id = "${local.subscription_scope}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/azureFirewalls/azfw-connectivity-canadacentral-001"
  conn_alerts_vpn_cc_id  = "${local.subscription_scope}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/vpnGateways/vpn-connectivity-canadacentral-001"
  conn_alerts_vpn_ce_id  = "${local.subscription_scope}/resourceGroups/rg-hub-connectivity-canadaeast-001/providers/Microsoft.Network/vpnGateways/vpn-connectivity-canadaeast-001"

  # AzFW action group — mgmt sub (mail + servicenow ags are declared in locals.tf).
  mgmt_azfw_ag_id = "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/rg-alerts-management-canadacentral-001/providers/Microsoft.Insights/actionGroups/ag-AzFW-alert-CanadaCentral-001"
}

# ── Metric alerts ──────────────────────────────────────────────────────

resource "azurerm_monitor_metric_alert" "firewall_connectivity_health" {
  name                     = "firewall-connectivity-health"
  resource_group_name      = local.alerts_rg_name
  scopes                   = [local.conn_alerts_azfw_cc_id]
  target_resource_type     = "Microsoft.Network/azureFirewalls"
  target_resource_location = "canadacentral"
  severity                 = 0
  frequency                = "PT1M"
  window_size              = "PT5M"
  auto_mitigate            = true

  criteria {
    metric_namespace       = "Microsoft.Network/azureFirewalls"
    metric_name            = "FirewallHealth"
    aggregation            = "Average"
    operator               = "LessThan"
    threshold              = 99
    skip_metric_validation = false
  }

  action {
    action_group_id = local.mgmt_servicenow_ag_id
  }

  tags = local.common_tags
}

resource "azurerm_monitor_metric_alert" "vm_connectivity_cpu_high_warning" {
  name                     = "vm-connectivity-cpu-high-warning"
  resource_group_name      = local.alerts_rg_name
  scopes                   = [local.subscription_scope]
  target_resource_type     = "microsoft.compute/virtualmachines"
  target_resource_location = "canadacentral"
  severity                 = 2
  frequency                = "PT5M"
  window_size              = "PT30M"
  auto_mitigate            = true
  description              = "Action will be triggered when percentage CPU for VM is greater than 90%"

  criteria {
    metric_namespace = "microsoft.compute/virtualmachines"
    metric_name      = "Percentage CPU"
    aggregation      = "Average"
    operator         = "GreaterThan"
    threshold        = 90
  }

  action {
    action_group_id = local.mgmt_servicenow_ag_id
  }

  tags = local.common_tags
}

resource "azurerm_monitor_metric_alert" "vm_connectivity_memory_high_warning" {
  name                     = "vm-connectivity-memory-high-warning"
  resource_group_name      = local.alerts_rg_name
  scopes                   = [local.subscription_scope]
  target_resource_type     = "microsoft.compute/virtualmachines"
  target_resource_location = "canadacentral"
  severity                 = 2
  frequency                = "PT1M"
  window_size              = "PT5M"
  auto_mitigate            = true
  # Description verbatim from source (copy-paste mismatch — mentions CPU).
  description = "Action will be triggered when percentage CPU for VM is greater than 90%"

  criteria {
    metric_namespace       = "microsoft.compute/virtualmachines"
    metric_name            = "Available Memory Percentage"
    aggregation            = "Average"
    operator               = "LessThanOrEqual"
    threshold              = 10
    skip_metric_validation = false
  }

  action {
    action_group_id = local.mgmt_servicenow_ag_id
  }

  tags = local.common_tags
}

# ── Activity log alerts ────────────────────────────────────────────────

resource "azurerm_monitor_activity_log_alert" "firewall_connectivity_update" {
  name                = "firewall-connectivity-update"
  resource_group_name = local.alerts_rg_name
  location            = "global"
  scopes              = [local.conn_alerts_azfw_cc_id]

  criteria {
    category       = "Administrative"
    operation_name = "Microsoft.Network/azurefirewalls/write"
  }

  action {
    action_group_id = local.mgmt_azfw_ag_id
  }

  tags = local.common_tags
}

resource "azurerm_monitor_activity_log_alert" "vpn_connectivty_down" {
  name                = "vpn-connectivty-down"
  resource_group_name = local.alerts_rg_name
  location            = "global"
  scopes              = [local.subscription_scope]

  criteria {
    category        = "ResourceHealth"
    resource_groups = ["rg-hub-connectivity-canadacentral-001"]
    resource_ids    = [local.conn_alerts_vpn_cc_id]
    resource_types  = ["Microsoft.Network/vpnGateways"]

    resource_health {
      current = ["Degraded", "Unavailable"]
    }
  }

  action {
    action_group_id = local.mgmt_servicenow_ag_id
  }

  tags = local.common_tags
}

resource "azurerm_monitor_activity_log_alert" "vpn_connectivty_down_canadaeast" {
  name                = "vpn-connectivty-down-canadaeast"
  resource_group_name = local.alerts_rg_name
  location            = "global"
  scopes              = [local.subscription_scope]

  criteria {
    category        = "ResourceHealth"
    resource_groups = ["rg-hub-connectivity-canadaeast-001"]
    resource_ids    = [local.conn_alerts_vpn_ce_id]
    resource_types  = ["Microsoft.Network/vpnGateways"]

    resource_health {
      current = ["Degraded", "Unavailable"]
    }
  }

  action {
    action_group_id = local.mgmt_servicenow_ag_id
  }

  tags = local.common_tags
}
