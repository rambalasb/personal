# net_primitives.tf
# Network primitives across the hub / shared / cyberark / runners / dns / dmz
# RGs: DDoS plan, NAT gateways, public IP prefixes and addresses, NSGs + rules,
# route tables, private endpoints, ExpressRoute circuits, network watchers +
# flow logs, and Azure Traffic Collectors.

locals {
  # SIEM Log Analytics workspace for flow-log traffic analytics (security sub).
  # TODO confirm security subscription id + workspace RG
  net_flowlog_workspace_id          = "9c9a382f-30e1-4ace-ab51-a73661e7bb9e"
  net_flowlog_workspace_resource_id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-siem-security-canadacentral-001/providers/Microsoft.OperationalInsights/workspaces/la-siem-security-canadacentral-001"

  net_pe_subnet_id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dns-connectivity-canadacentral-001/subnets/snet-dns-private-endpoint-canadacentral-001"

  net_ddos_data = {
    "ddos-protection-plan" = {
      rg       = "hub_cc"
      location = "canadacentral"
    }
  }

  net_nat_gateways = {
    "ngw-cyberark-connectivity-canadacentral-001" = {
      rg               = "cyberark"
      location         = "canadacentral"
      public_ip_prefix = "pip-ngw-cyberark-connectivity-canadacentral-001"
    }
    "ngw-runners-connectivity-canadacentral-001" = {
      rg               = "runners"
      location         = "canadacentral"
      public_ip_prefix = "pip-ngw-runners-connectivity-canadacentral-001"
    }
    "ngw-shared-connectivity-canadacentral-001" = {
      rg               = "shared_cc"
      location         = "canadacentral"
      public_ip_prefix = "pip-ngw-shared-connectivity-canadacentral-001"
    }
  }

  net_public_ip_prefixes = {
    "pip-ngw-cyberark-connectivity-canadacentral-001" = {
      rg            = "cyberark"
      location      = "canadacentral"
      prefix_length = 31
    }
    "pip-ngw-runners-connectivity-canadacentral-001" = {
      rg            = "runners"
      location      = "canadacentral"
      prefix_length = 31
    }
    "pip-ngw-shared-connectivity-canadacentral-001" = {
      rg            = "shared_cc"
      location      = "canadacentral"
      prefix_length = 28
    }
  }

  net_public_ips = {
    "pip-ars-transit-connectivity-canadacentral-001" = {
      rg    = "shared_cc"
      zones = ["1", "2", "3"]
    }
    "pip-azfw-transit-connectivity-canadacentral-001" = {
      rg    = "shared_cc"
      zones = null
    }
  }

  net_nsgs = {
    "nsg-cyberark-servers-canadacentral-001" = {
      rg       = "cyberark"
      location = "canadacentral"
      security_rules = {
        MicrosoftDefenderForCloud-JITRule_324660756_5D9A522ECE3E484A9208AA226FBF47FD = {
          name                       = "MicrosoftDefenderForCloud-JITRule_324660756_5D9A522ECE3E484A9208AA226FBF47FD"
          description                = "MDC JIT Network Access rule for policy 'default' of VM 'vm-cyberark-server-canadacentral-001'."
          priority                   = 4096
          direction                  = "Inbound"
          access                     = "Deny"
          protocol                   = "*"
          source_address_prefix      = "*"
          source_port_range          = "*"
          destination_address_prefix = "10.195.116.4"
          destination_port_range     = "3389"
        }
        AllowOnPrem = {
          name      = "AllowOnPrem"
          priority  = 1000
          direction = "Inbound"
          access    = "Allow"
          protocol  = "*"
          source_address_prefixes = [
            "10.0.0.0/8",
            "172.16.0.0/12",
            "192.168.0.0/16",
            "142.52.0.0/16"
          ]
          source_port_range          = "*"
          destination_address_prefix = "*"
          destination_port_range     = "*"
        }
        AllowBastionAccess = {
          name                  = "AllowBastionAccess"
          priority              = 200
          direction             = "Inbound"
          access                = "Allow"
          protocol              = "*"
          source_address_prefix = "168.63.129.16"
          source_port_range     = "*"
          destination_address_prefixes = [
            "10.195.116.4",
            "10.195.116.5"
          ]
          destination_port_range = "3389"
        }
        Cyberark-SSH = {
          name        = "Cyberark-SSH"
          description = "SSH Port 22 allowed from Cyberark VMs"
          priority    = 300
          direction   = "Inbound"
          access      = "Allow"
          protocol    = "Tcp"
          source_address_prefixes = [
            "10.195.116.4",
            "10.195.116.5"
          ]
          source_port_range = "*"
          destination_address_prefixes = [
            "10.195.116.6",
            "10.195.116.8"
          ]
          destination_port_range = "22"
        }
      }
    }
    "nsg-dmz-gw-nonprod-canadacentral-001" = {
      rg             = "dmz"
      location       = "canadacentral"
      security_rules = {}
    }
    "nsg-dmz-gw-prod-canadacentral-001" = {
      rg             = "dmz"
      location       = "canadacentral"
      security_rules = {}
    }
    "nsg-ertest-canadacentral-001" = {
      rg       = "ertest_cc"
      location = "canadacentral"
      security_rules = {
        AllowOnPrem = {
          name      = "AllowOnPrem"
          priority  = 200
          direction = "Inbound"
          access    = "Allow"
          protocol  = "*"
          source_address_prefixes = [
            "10.0.0.0/8",
            "172.16.0.0/12",
            "192.168.0.0/16",
            "142.52.0.0/16"
          ]
          source_port_range          = "*"
          destination_address_prefix = "*"
          destination_port_range     = "*"
        }
        allowBastionHost = {
          name                       = "allowBastionHost"
          priority                   = 180
          direction                  = "Inbound"
          access                     = "Allow"
          protocol                   = "Tcp"
          source_address_prefix      = "168.63.129.16"
          source_port_range          = "*"
          destination_address_prefix = "*"
          destination_port_range     = "3389"
        }
      }
    }
    "nsg-ertest-canadaeast-001" = {
      rg       = "ertest_ce"
      location = "canadaeast"
      security_rules = {
        AllowOnPrem = {
          name      = "AllowOnPrem"
          priority  = 200
          direction = "Inbound"
          access    = "Allow"
          protocol  = "*"
          source_address_prefixes = [
            "10.0.0.0/8",
            "172.16.0.0/12",
            "192.168.0.0/16",
            "142.52.0.0/16"
          ]
          source_port_range          = "*"
          destination_address_prefix = "*"
          destination_port_range     = "*"
        }
        allowBastionHost = {
          name                       = "allowBastionHost"
          priority                   = 190
          direction                  = "Inbound"
          access                     = "Allow"
          protocol                   = "Tcp"
          source_address_prefix      = "168.63.129.16"
          source_port_range          = "*"
          destination_address_prefix = "*"
          destination_port_range     = "3389"
        }
      }
    }
    "nsg-bh-canadacentral-001" = {
      rg       = "runners"
      location = "canadacentral"
      security_rules = {
        allowHttps = {
          name                       = "allowHttps"
          priority                   = 100
          direction                  = "Inbound"
          access                     = "Allow"
          protocol                   = "Tcp"
          source_address_prefix      = "*"
          source_port_range          = "*"
          destination_address_prefix = "*"
          destination_port_range     = "443"
        }
        allowBastionComm = {
          name                       = "allowBastionComm"
          priority                   = 110
          direction                  = "Inbound"
          access                     = "Allow"
          protocol                   = "*"
          source_address_prefix      = "VirtualNetwork"
          source_port_range          = "*"
          destination_address_prefix = "VirtualNetwork"
          destination_port_ranges = [
            "8080",
            "5701"
          ]
        }
        allowBastionCommOutbound = {
          name                       = "allowBastionCommOutbound"
          priority                   = 120
          direction                  = "Outbound"
          access                     = "Allow"
          protocol                   = "*"
          source_address_prefix      = "VirtualNetwork"
          source_port_range          = "*"
          destination_address_prefix = "VirtualNetwork"
          destination_port_ranges = [
            "8080",
            "5701"
          ]
        }
        allowHttpOutbound = {
          name                       = "allowHttpOutbound"
          priority                   = 130
          direction                  = "Outbound"
          access                     = "Allow"
          protocol                   = "*"
          source_address_prefix      = "*"
          source_port_range          = "*"
          destination_address_prefix = "*"
          destination_port_range     = "80"
        }
        allowAzureCLoudOut = {
          name                       = "allowAzureCLoudOut"
          priority                   = 140
          direction                  = "Outbound"
          access                     = "Allow"
          protocol                   = "Tcp"
          source_address_prefix      = "*"
          source_port_range          = "*"
          destination_address_prefix = "AzureCloud"
          destination_port_range     = "443"
        }
        allowSSHRDPOutbound = {
          name                       = "allowSSHRDPOutbound"
          priority                   = 150
          direction                  = "Outbound"
          access                     = "Allow"
          protocol                   = "*"
          source_address_prefix      = "*"
          source_port_range          = "*"
          destination_address_prefix = "VirtualNetwork"
          destination_port_ranges = [
            "22",
            "3389"
          ]
        }
        allowAllPriority = {
          name                       = "allowAllPriority"
          priority                   = 105
          direction                  = "Outbound"
          access                     = "Allow"
          protocol                   = "*"
          source_address_prefix      = "*"
          source_port_range          = "*"
          destination_address_prefix = "*"
          destination_port_range     = "*"
        }
        allowAllIn = {
          name      = "allowAllIn"
          priority  = 102
          direction = "Inbound"
          access    = "Allow"
          protocol  = "*"
          source_address_prefixes = [
            "10.0.0.0/8",
            "172.16.0.0/12",
            "192.168.0.0/16",
            "142.52.0.0/16"
          ]
          source_port_range          = "*"
          destination_address_prefix = "*"
          destination_port_range     = "*"
        }
      }
    }
    "nsg-runners-dev-canadacentral-001" = {
      rg       = "runners"
      location = "canadacentral"
      security_rules = {
        AllowOnPrem = {
          name      = "AllowOnPrem"
          priority  = 200
          direction = "Inbound"
          access    = "Allow"
          protocol  = "*"
          source_address_prefixes = [
            "10.0.0.0/8",
            "172.16.0.0/12",
            "192.168.0.0/16",
            "142.52.0.0/16"
          ]
          source_port_range          = "*"
          destination_address_prefix = "*"
          destination_port_range     = "*"
        }
        DenyAllInbound = {
          name                       = "DenyAllInbound"
          priority                   = 1000
          direction                  = "Inbound"
          access                     = "Deny"
          protocol                   = "*"
          source_address_prefix      = "*"
          source_port_range          = "*"
          destination_address_prefix = "*"
          destination_port_range     = "*"
        }
        AllowBastionHost = {
          name      = "AllowBastionHost"
          priority  = 100
          direction = "Inbound"
          access    = "Allow"
          protocol  = "Tcp"
          source_address_prefixes = [
            "10.0.0.0/8",
            "172.16.0.0/12",
            "192.168.0.0/16",
            "142.52.0.0/16",
            "155.190.0.0/16",
            "168.63.129.16"
          ]
          source_port_range          = "*"
          destination_address_prefix = "*"
          destination_port_range     = "3389"
        }
        allowBastionSSH = {
          name                       = "allowBastionSSH"
          priority                   = 999
          direction                  = "Inbound"
          access                     = "Allow"
          protocol                   = "Tcp"
          source_address_prefix      = "168.63.129.16"
          source_port_range          = "*"
          destination_address_prefix = "*"
          destination_port_range     = "22"
        }
      }
    }
    "nsg-runners-prod-canadacentral-001" = {
      rg       = "runners"
      location = "canadacentral"
      security_rules = {
        AllowOnPrem = {
          name      = "AllowOnPrem"
          priority  = 200
          direction = "Inbound"
          access    = "Allow"
          protocol  = "*"
          source_address_prefixes = [
            "10.0.0.0/8",
            "172.16.0.0/12",
            "192.168.0.0/16",
            "142.52.0.0/16"
          ]
          source_port_range          = "*"
          destination_address_prefix = "*"
          destination_port_range     = "*"
        }
        DenyAllInbound = {
          name                       = "DenyAllInbound"
          priority                   = 1000
          direction                  = "Inbound"
          access                     = "Deny"
          protocol                   = "*"
          source_address_prefix      = "*"
          source_port_range          = "*"
          destination_address_prefix = "*"
          destination_port_range     = "*"
        }
        AllowBastionHost = {
          name      = "AllowBastionHost"
          priority  = 900
          direction = "Inbound"
          access    = "Allow"
          protocol  = "Tcp"
          source_address_prefixes = [
            "168.63.129.16",
            "10.0.0.0/8",
            "172.16.0.0/12",
            "192.168.0.0/16",
            "142.52.0.0/16",
            "155.190.0.0/16"
          ]
          source_port_range          = "*"
          destination_address_prefix = "*"
          destination_port_range     = "3389"
        }
        AllowBastionSSH = {
          name                       = "AllowBastionSSH"
          priority                   = 999
          direction                  = "Inbound"
          access                     = "Allow"
          protocol                   = "Tcp"
          source_address_prefix      = "168.63.129.16"
          source_port_range          = "*"
          destination_address_prefix = "*"
          destination_port_range     = "22"
        }
      }
    }
    "nsg-dns-private-endpoint-canadacentral-001" = {
      rg       = "dns"
      location = "canadacentral"
      security_rules = {
        AllowOnPrem = {
          name      = "AllowOnPrem"
          priority  = 200
          direction = "Inbound"
          access    = "Allow"
          protocol  = "*"
          source_address_prefixes = [
            "10.0.0.0/8",
            "172.16.0.0/12",
            "192.168.0.0/16",
            "142.52.0.0/16",
            "130.107.245.112/28"
          ]
          source_port_range          = "*"
          destination_address_prefix = "*"
          destination_port_range     = "*"
        }
        DenyAllInbound = {
          name                       = "DenyAllInbound"
          priority                   = 1000
          direction                  = "Inbound"
          access                     = "Deny"
          protocol                   = "*"
          source_address_prefix      = "*"
          source_port_range          = "*"
          destination_address_prefix = "*"
          destination_port_range     = "*"
        }
      }
    }
    "nsg-dns-inbound-canadacentral-001" = {
      rg       = "dns"
      location = "canadacentral"
      security_rules = {
        AllowOnPrem = {
          name      = "AllowOnPrem"
          priority  = 200
          direction = "Inbound"
          access    = "Allow"
          protocol  = "*"
          source_address_prefixes = [
            "10.0.0.0/8",
            "172.16.0.0/12",
            "192.168.0.0/16",
            "142.52.0.0/16"
          ]
          source_port_range          = "*"
          destination_address_prefix = "*"
          destination_port_range     = "*"
        }
        DenyAllInbound = {
          name                       = "DenyAllInbound"
          priority                   = 1000
          direction                  = "Inbound"
          access                     = "Deny"
          protocol                   = "*"
          source_address_prefix      = "*"
          source_port_range          = "*"
          destination_address_prefix = "*"
          destination_port_range     = "*"
        }
      }
    }
    "nsg-dns-outbound-canadacentral-001" = {
      rg       = "dns"
      location = "canadacentral"
      security_rules = {
        AllowOnPrem = {
          name      = "AllowOnPrem"
          priority  = 200
          direction = "Inbound"
          access    = "Allow"
          protocol  = "*"
          source_address_prefixes = [
            "10.0.0.0/8",
            "172.16.0.0/12",
            "192.168.0.0/16",
            "142.52.0.0/16"
          ]
          source_port_range          = "*"
          destination_address_prefix = "*"
          destination_port_range     = "*"
        }
        DenyAllInbound = {
          name                       = "DenyAllInbound"
          priority                   = 1000
          direction                  = "Inbound"
          access                     = "Deny"
          protocol                   = "*"
          source_address_prefix      = "*"
          source_port_range          = "*"
          destination_address_prefix = "*"
          destination_port_range     = "*"
        }
        AllStorageOutbound = {
          name                       = "AllStorageOutbound"
          priority                   = 1010
          direction                  = "Outbound"
          access                     = "Allow"
          protocol                   = "*"
          source_address_prefix      = "LogicApps"
          source_port_range          = "*"
          destination_address_prefix = "Storage"
          destination_port_ranges = [
            "445",
            "443"
          ]
        }
        AllowRunners = {
          name      = "AllowRunners"
          priority  = 300
          direction = "Inbound"
          access    = "Allow"
          protocol  = "*"
          source_address_prefixes = [
            "10.195.115.7",
            "10.195.114.7"
          ]
          source_port_range          = "*"
          destination_address_prefix = "*"
          destination_port_range     = "443"
        }
        AllowTest = {
          name      = "AllowTest"
          priority  = 305
          direction = "Inbound"
          access    = "Allow"
          protocol  = "*"
          source_address_prefixes = [
            "155.190.0.8/32",
            "155.190.0.9/32",
            "155.190.0.10/32",
            "155.190.0.11/32"
          ]
          source_port_range          = "*"
          destination_address_prefix = "*"
          destination_port_range     = "443"
        }
      }
    }
  }

  net_route_tables = {
    "rt-cyberark-canadacentral-001" = {
      rg     = "cyberark"
      routes = []
    }
    "rt-transit-fw-canadacentral-001" = {
      rg = "shared_cc"
      routes = [
        {
          name           = "r-allow-bch-to-ns2"
          address_prefix = "10.237.0.0/21"
          next_hop_type  = "VnetLocal"
        }
      ]
    }
  }

  net_private_endpoints = {
    "pep-la-connectivity-canadacentral-001" = {
      rg = "dns"
      subresource_names = [
        "azuremonitor"
      ]
      private_connection_resource_id  = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/microsoft.insights/privateLinkScopes/ampls-connectivity-canadacentral-001"
      private_service_connection_name = "pep-la-connectivity-canadacentral-001"
      network_interface_name          = "pep-la-connectivity-canadacentral-001-nic"
    }
    "pep-ehns-alerts-canadacentral-001" = {
      rg = "dns"
      subresource_names = [
        "namespace"
      ]
      private_connection_resource_id  = "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/rg-alerts-management-canadacentral-001/providers/Microsoft.EventHub/namespaces/ehns-alerts-canadacentral-001"
      private_service_connection_name = "pep-ehns-alerts-canadacentral-001"
      network_interface_name          = "pep-ehns-alerts-canadacentral-001-nic"
    }
    "pep-azfw-connectivity-canadacentral-001" = {
      rg = "dns"
      subresource_names = [
        "vault"
      ]
      private_connection_resource_id  = "/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0/resourceGroups/rg-mid-identity-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvfwtlscanadacentral"
      private_service_connection_name = "pep-azfw-connectivity-canadacentral-001"
      network_interface_name          = "pep-azfw-connectivity-canadacentral-001-nic"
    }
    "pep-stazpkcapture-prod-canadacentral-001" = {
      rg = "hub_cc"
      subresource_names = [
        "blob"
      ]
      private_connection_resource_id  = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Storage/storageAccounts/stazfwpkcapture"
      private_service_connection_name = "pep-stazpkcapture-prod-canadacentral-001_365a13ae-d3d5-49f5-b3fb-c50c73d2d05f"
      network_interface_name          = null
    }
    "pep-rsv-connectivity-canadacentral-001" = {
      rg = "runners"
      subresource_names = [
        "AzureBackup"
      ]
      private_connection_resource_id  = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.RecoveryServices/vaults/rsv-connectivity-canadacentral-001"
      private_service_connection_name = "pep-rsv-connectivity-canadacentral-001_f369867d-b16c-44b9-92d6-e23b1aff8036"
      network_interface_name          = null
    }
    "pep-lap-servicenowintegration-canadacentral-001" = {
      rg = "shared_cc"
      subresource_names = [
        "sites"
      ]
      private_connection_resource_id  = "${local.sub}/resourceGroups/rg-shared-connectivity-canadacentral-001/providers/Microsoft.Web/sites/lap-servicenowintegration-canadacentral-001"
      private_service_connection_name = "pep-lap-servicenowintegration-canadacentral-001"
      network_interface_name          = "pep-lap-servicenowintegration-canadacentral-001-nic"
    }
  }

  net_er_circuits = {
    "erc-quebec-connectivity-caeast-001" = {
      location         = "canadaeast"
      peering_location = "Quebec City"
      vlan_id          = 2001
      primary_prefix   = "10.54.17.100/30"
      secondary_prefix = "10.54.18.212/30"
    }
    "erc-toronto-connectivity-cacentral-001" = {
      location         = "canadacentral"
      peering_location = "Toronto"
      vlan_id          = 2000
      primary_prefix   = "10.243.21.224/30"
      secondary_prefix = "10.243.225.104/30"
    }
  }

  net_network_watchers = {
    "NetworkWatcher_canadacentral_connectivity" = {
      rg       = "shared_cc"
      location = "canadacentral"
    }
    "NetworkWatcher_canadaeast_connectivity" = {
      rg       = "shared_ce"
      location = "canadaeast"
    }
  }

  net_flow_logs = {
    "vnet-cyberark-canadacentral-001-rg-cyberark-canadacentra-flowlog" = {
      watcher            = "NetworkWatcher_canadacentral_connectivity"
      rg                 = "shared_cc"
      location           = "canadacentral"
      target_resource_id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cyberark-canadacentral-001"
      storage_account_id = "${local.sub}/resourceGroups/rg-shared-connectivity-canadacentral-001/providers/Microsoft.Storage/storageAccounts/stnwconncanadacentral"
      ta_interval        = 60
    }
    "vnet-dns-connectivity-canadacentral-001-rg-dns-connectiv-flowlog" = {
      watcher            = "NetworkWatcher_canadacentral_connectivity"
      rg                 = "shared_cc"
      location           = "canadacentral"
      target_resource_id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dns-connectivity-canadacentral-001"
      storage_account_id = "${local.sub}/resourceGroups/rg-shared-connectivity-canadacentral-001/providers/Microsoft.Storage/storageAccounts/stnwconncanadacentral"
      ta_interval        = 60
    }
    "vnet-ertest-canadacentral-001-rg-ertest-canadacentral-00-flowlog" = {
      watcher            = "NetworkWatcher_canadacentral_connectivity"
      rg                 = "shared_cc"
      location           = "canadacentral"
      target_resource_id = "${local.sub}/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-ertest-canadacentral-001"
      storage_account_id = "${local.sub}/resourceGroups/rg-shared-connectivity-canadacentral-001/providers/Microsoft.Storage/storageAccounts/stnwconncanadacentral"
      ta_interval        = 10
    }
    "vnet-runners-connectivity-canadacentral-001-rg-runners-c-flowlog" = {
      watcher            = "NetworkWatcher_canadacentral_connectivity"
      rg                 = "shared_cc"
      location           = "canadacentral"
      target_resource_id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-runners-connectivity-canadacentral-001"
      storage_account_id = "${local.sub}/resourceGroups/rg-shared-connectivity-canadacentral-001/providers/Microsoft.Storage/storageAccounts/stnwconncanadacentral"
      ta_interval        = 60
    }
    "vnet-shared-connectivity-canadacentral-001-rg-shared-con-flowlog" = {
      watcher            = "NetworkWatcher_canadacentral_connectivity"
      rg                 = "shared_cc"
      location           = "canadacentral"
      target_resource_id = "${local.sub}/resourceGroups/rg-shared-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-shared-connectivity-canadacentral-001"
      storage_account_id = "${local.sub}/resourceGroups/rg-shared-connectivity-canadacentral-001/providers/Microsoft.Storage/storageAccounts/stnwconncanadacentral"
      ta_interval        = 60
    }
    "vnet-ertest-canadaeast-001-rg-ertest-canadaeast-001-flowlog" = {
      watcher            = "NetworkWatcher_canadaeast_connectivity"
      rg                 = "shared_ce"
      location           = "canadaeast"
      target_resource_id = "${local.sub}/resourceGroups/rg-ertest-canadaeast-001/providers/Microsoft.Network/virtualNetworks/vnet-ertest-canadaeast-001"
      storage_account_id = "${local.sub}/resourceGroups/rg-shared-connectivity-canadaeast-001/providers/Microsoft.Storage/storageAccounts/stnwconncanadaeast"
      ta_interval        = 10
    }
  }

  net_traffic_collectors = {
    "tc-erc-toronto-connectivity-canadacentral-001" = {
      rg       = "hub_cc"
      location = "canadacentral"
    }
    "tc-erc-quebec-connectivity-canadaeast-001" = {
      rg       = "hub_ce"
      location = "canadaeast"
    }
  }

  net_collector_policies = {
    "tc-erc-toronto-connectivity-canadacentral-001" = {
      location            = "canadacentral"
      ingestion_source_id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/expressRouteCircuits/erc-toronto-connectivity-cacentral-001"
    }
    "tc-erc-quebec-connectivity-canadaeast-001" = {
      location            = "canadaeast"
      ingestion_source_id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/expressRouteCircuits/erc-quebec-connectivity-caeast-001"
    }
  }
}

# DDoS protection plan
module "ddos_protection_plan" {
  for_each = local.net_ddos_data

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-ddos-protection-plan/azurerm"
  version = "0.1.0" # TODO confirm version

  name                = each.key
  resource_group_name = module.resource_group[each.value.rg].name
  location            = each.value.location
  tags                = local.common_tags
}

# NAT gateways (prefix-only per wrapper policy)
module "nat_gateway" {
  for_each = local.net_nat_gateways

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-nat-gateway/azurerm"
  version = "0.1.0" # TODO confirm version

  name      = each.key
  parent_id = module.resource_group[each.value.rg].resource_id
  location  = each.value.location

  sku_name                = "Standard"
  idle_timeout_in_minutes = 10
  zones                   = ["1"]

  public_ip_prefix_resource_ids = [
    "${module.resource_group[each.value.rg].resource_id}/providers/Microsoft.Network/publicIPPrefixes/${each.value.public_ip_prefix}"
  ]

  tags = local.common_tags
}

# Public IP prefixes
module "public_ip_prefix" {
  for_each = local.net_public_ip_prefixes

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-public-ip-prefix/azurerm"
  version = "0.1.0" # TODO confirm version

  name                = each.key
  resource_group_name = module.resource_group[each.value.rg].name
  location            = each.value.location
  prefix_length       = each.value.prefix_length
  sku_name            = "Standard"
  sku_tier            = "Regional"
  ip_version          = "IPv4"
  zones               = ["1"]
  tags                = local.common_tags
}

# Public IP addresses (no wrapper - native)
resource "azurerm_public_ip" "this" {
  for_each = local.net_public_ips

  name                = each.key
  resource_group_name = module.resource_group[each.value.rg].name
  location            = "canadacentral"
  allocation_method   = "Static"
  sku                 = "Standard"
  sku_tier            = "Regional"
  ip_version          = "IPv4"
  zones               = each.value.zones
  tags                = local.common_tags
}

# Network security groups + rules
module "network_security_group" {
  for_each = local.net_nsgs

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-network-security-group/azurerm"
  version = "0.1.0" # TODO confirm version

  name                = each.key
  resource_group_name = module.resource_group[each.value.rg].name
  location            = each.value.location
  security_rules      = each.value.security_rules
  tags                = local.common_tags
}

# Route tables (no wrapper - native, inline routes)
resource "azurerm_route_table" "this" {
  for_each = local.net_route_tables

  name                          = each.key
  resource_group_name           = module.resource_group[each.value.rg].name
  location                      = "canadacentral"
  bgp_route_propagation_enabled = true

  dynamic "route" {
    for_each = each.value.routes
    content {
      name           = route.value.name
      address_prefix = route.value.address_prefix
      next_hop_type  = route.value.next_hop_type
    }
  }

  tags = local.common_tags
}

# Private endpoints. DNS zone groups managed elsewhere, not set here.
module "private_endpoint" {
  for_each = local.net_private_endpoints

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-private-endpoint/azurerm"
  version = "0.1.0" # TODO confirm version

  name                            = each.key
  location                        = "canadacentral"
  resource_group_name             = module.resource_group[each.value.rg].name
  subnet_resource_id              = local.net_pe_subnet_id
  private_connection_resource_id  = each.value.private_connection_resource_id
  subresource_names               = each.value.subresource_names
  private_service_connection_name = each.value.private_service_connection_name
  network_interface_name          = each.value.network_interface_name
  tags                            = local.common_tags
}

# ExpressRoute circuits + private peering. Both circuits live in the CC hub RG.
module "express_route_circuit" {
  for_each = local.net_er_circuits

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-express-route-circuit/azurerm"
  version = "0.1.0" # TODO confirm version

  name                = each.key
  resource_group_name = module.resource_group["hub_cc"].name
  location            = each.value.location

  sku = {
    tier   = "Standard"
    family = "MeteredData"
  }

  service_provider_name = "Telus"
  peering_location      = each.value.peering_location
  bandwidth_in_mbps     = 2000

  peerings = {
    AzurePrivatePeering = {
      peering_type                  = "AzurePrivatePeering"
      vlan_id                       = each.value.vlan_id
      peer_asn                      = 852
      primary_peer_address_prefix   = each.value.primary_prefix
      secondary_peer_address_prefix = each.value.secondary_prefix
    }
  }

  tags = local.common_tags
}

# Network watchers (custom watchers, native). Wrapper can't create the watcher.
resource "azurerm_network_watcher" "this" {
  for_each = local.net_network_watchers

  name                = each.key
  resource_group_name = module.resource_group[each.value.rg].name
  location            = each.value.location
  tags                = local.common_tags
}

# Flow logs (native). Traffic analytics -> SIEM workspace in the security sub.
resource "azurerm_network_watcher_flow_log" "this" {
  for_each = local.net_flow_logs

  name                 = each.key
  network_watcher_name = azurerm_network_watcher.this[each.value.watcher].name
  resource_group_name  = module.resource_group[each.value.rg].name
  location             = each.value.location
  target_resource_id   = each.value.target_resource_id
  storage_account_id   = each.value.storage_account_id
  enabled              = true
  version              = 2

  retention_policy {
    enabled = true
    days    = 90
  }

  traffic_analytics {
    enabled               = true
    interval_in_minutes   = each.value.ta_interval
    workspace_id          = local.net_flowlog_workspace_id
    workspace_region      = "canadacentral"
    workspace_resource_id = local.net_flowlog_workspace_resource_id
  }

  tags = local.common_tags
}

# Azure Traffic Collectors + collector policies (no provider resource - azapi)
resource "azapi_resource" "traffic_collector" {
  for_each = local.net_traffic_collectors

  type      = "Microsoft.NetworkFunction/azureTrafficCollectors@2022-11-01"
  name      = each.key
  parent_id = module.resource_group[each.value.rg].resource_id
  location  = each.value.location
  body = {
    properties = {}
  }
  tags = local.common_tags
}

resource "azapi_resource" "collector_policy" {
  for_each = local.net_collector_policies

  type      = "Microsoft.NetworkFunction/azureTrafficCollectors/collectorPolicies@2022-11-01"
  name      = "cp-1"
  parent_id = azapi_resource.traffic_collector[each.key].id
  location  = each.value.location
  body = {
    properties = {
      emissionPolicies = [
        {
          emissionDestinations = [
            {
              destinationType = "AzureMonitor"
            }
          ]
          emissionType = "IPFIX"
        }
      ]
      ingestionPolicy = {
        ingestionSources = [
          {
            resourceId = each.value.ingestion_source_id
            sourceType = "Resource"
          }
        ]
        ingestionType = "IPFIX"
      }
    }
  }
  tags = local.common_tags
}
