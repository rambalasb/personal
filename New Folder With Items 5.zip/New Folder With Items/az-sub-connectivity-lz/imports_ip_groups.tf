# imports_ip_groups.tf — 89 IP groups (internal AVM address: confirm on first plan)

import {
  to = module.ip_group["ipgrp-app-openai-nonprod-canadacentral-001"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-app-openai-nonprod-canadacentral-001"
}
import {
  to = module.ip_group["ipgrp-app-openai-prod-canadacentral-001"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-app-openai-prod-canadacentral-001"
}
import {
  to = module.ip_group["ipgrp-bchsiops-jumphost"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-bchsiops-jumphost"
}
import {
  to = module.ip_group["ipgrp-cacentral-caeast-ertest-vm"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-cacentral-caeast-ertest-vm"
}
import {
  to = module.ip_group["ipgrp-cacentral-clz-dev-subnets"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-cacentral-clz-dev-subnets"
}
import {
  to = module.ip_group["ipgrp-cacentral-clz-dns-resolvers"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-cacentral-clz-dns-resolvers"
}
import {
  to = module.ip_group["ipgrp-cacentral-clz-monitor"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-cacentral-clz-monitor"
}
import {
  to = module.ip_group["ipgrp-cacentral-clz-prod-subnets"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-cacentral-clz-prod-subnets"
}
import {
  to = module.ip_group["ipgrp-cacentral-clz-subnets"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-cacentral-clz-subnets"
}
import {
  to = module.ip_group["ipgrp-cacentral-cops-nonprod-vnet"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-cacentral-cops-nonprod-vnet"
}
import {
  to = module.ip_group["ipgrp-cacentral-cops-prod-vnet"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-cacentral-cops-prod-vnet"
}
import {
  to = module.ip_group["ipgrp-cacentral-cyberark-vm-ips"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-cacentral-cyberark-vm-ips"
}
import {
  to = module.ip_group["ipgrp-cacentral-cyberark-vnet"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-cacentral-cyberark-vnet"
}
import {
  to = module.ip_group["ipgrp-cacentral-dev-runner-ips"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-cacentral-dev-runner-ips"
}
import {
  to = module.ip_group["ipgrp-cacentral-dns-connectivity-vnet"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-cacentral-dns-connectivity-vnet"
}
import {
  to = module.ip_group["ipgrp-cacentral-ertest-vnet"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-cacentral-ertest-vnet"
}
import {
  to = module.ip_group["ipgrp-cacentral-fit-nonprod-vnet"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-cacentral-fit-nonprod-vnet"
}
import {
  to = module.ip_group["ipgrp-cacentral-fit-prod-vnet"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-cacentral-fit-prod-vnet"
}
import {
  to = module.ip_group["ipgrp-cacentral-hosted-runners"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-cacentral-hosted-runners"
}
import {
  to = module.ip_group["ipgrp-cacentral-hosted-runners-vnet"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-cacentral-hosted-runners-vnet"
}
import {
  to = module.ip_group["ipgrp-cacentral-mds-ips"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-cacentral-mds-ips"
}
import {
  to = module.ip_group["ipgrp-cacentral-nonprod-cops-apps"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-cacentral-nonprod-cops-apps"
}
import {
  to = module.ip_group["ipgrp-cacentral-nonprod-cops-db"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-cacentral-nonprod-cops-db"
}
import {
  to = module.ip_group["ipgrp-cacentral-nonprod-fit-apps"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-cacentral-nonprod-fit-apps"
}
import {
  to = module.ip_group["ipgrp-cacentral-nonprod-pta-apps"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-cacentral-nonprod-pta-apps"
}
import {
  to = module.ip_group["ipgrp-cacentral-nonprod-pta-db"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-cacentral-nonprod-pta-db"
}
import {
  to = module.ip_group["ipgrp-cacentral-prod-cops-apps"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-cacentral-prod-cops-apps"
}
import {
  to = module.ip_group["ipgrp-cacentral-prod-cops-db"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-cacentral-prod-cops-db"
}
import {
  to = module.ip_group["ipgrp-cacentral-prod-fit-apps"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-cacentral-prod-fit-apps"
}
import {
  to = module.ip_group["ipgrp-cacentral-prod-pta-apps"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-cacentral-prod-pta-apps"
}
import {
  to = module.ip_group["ipgrp-cacentral-prod-pta-db"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-cacentral-prod-pta-db"
}
import {
  to = module.ip_group["ipgrp-cacentral-prod-runner-ips"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-cacentral-prod-runner-ips"
}
import {
  to = module.ip_group["ipgrp-cacentral-pta-nonprod-vnet"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-cacentral-pta-nonprod-vnet"
}
import {
  to = module.ip_group["ipgrp-cacentral-pta-prod-vnet"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-cacentral-pta-prod-vnet"
}
import {
  to = module.ip_group["ipgrp-cacentral-sandbox-cacentral-1-vnet"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-cacentral-sandbox-cacentral-1-vnet"
}
import {
  to = module.ip_group["ipgrp-cacentral-sandbox-cacentral-2-vnet"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-cacentral-sandbox-cacentral-2-vnet"
}
import {
  to = module.ip_group["ipgrp-cacentral-sandbox-cacentral-vnet"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-cacentral-sandbox-cacentral-vnet"
}
import {
  to = module.ip_group["ipgrp-cacentral-shared-connectivity-vnet"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-cacentral-shared-connectivity-vnet"
}
import {
  to = module.ip_group["ipgrp-caeast-clz-dns-resolvers"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-caeast-clz-dns-resolvers"
}
import {
  to = module.ip_group["ipgrp-caeast-clz-subnets"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-caeast-clz-subnets"
}
import {
  to = module.ip_group["ipgrp-caeast-ertest-vnet"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-caeast-ertest-vnet"
}
import {
  to = module.ip_group["ipgrp-cc-ns2-subnet"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-cc-ns2-subnet"
}
import {
  to = module.ip_group["ipgrp-clz-monitor-ips"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-clz-monitor-ips"
}
import {
  to = module.ip_group["ipgrp-ertest-vm-ips"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-ertest-vm-ips"
}
import {
  to = module.ip_group["ipgrp-func-openai-nonprod-canadacentral-001"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-func-openai-nonprod-canadacentral-001"
}
import {
  to = module.ip_group["ipgrp-func-openai-prod-canadacentral-001"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-func-openai-prod-canadacentral-001"
}
import {
  to = module.ip_group["ipgrp-ipgrp-pep-auritas-prod-canadacentral"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-ipgrp-pep-auritas-prod-canadacentral"
}
import {
  to = module.ip_group["ipgrp-kdcbch-ips"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-kdcbch-ips"
}
import {
  to = module.ip_group["ipgrp-kvspoprod-canadacentral-001"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-kvspoprod-canadacentral-001"
}
import {
  to = module.ip_group["ipgrp-onprem-controllers"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-onprem-controllers"
}
import {
  to = module.ip_group["ipgrp-onprem-infoblox"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-onprem-infoblox"
}
import {
  to = module.ip_group["ipgrp-onprem-kdcbch-ips"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-onprem-kdcbch-ips"
}
import {
  to = module.ip_group["ipgrp-onprem-kdcbch"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-onprem-kdcbch"
}
import {
  to = module.ip_group["ipgrp-onprem-subnets"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-onprem-subnets"
}
import {
  to = module.ip_group["ipgrp-onprem-to-clzdb-subnets"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-onprem-to-clzdb-subnets"
}
import {
  to = module.ip_group["ipgrp-onprem-unix-satellite-servers"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-onprem-unix-satellite-servers"
}
import {
  to = module.ip_group["ipgrp-openai-prod-acropenaiprodcc001"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-openai-prod-acropenaiprodcc001"
}
import {
  to = module.ip_group["ipgrp-pep-auritas-nonprod-canadacentral"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-pep-auritas-nonprod-canadacentral"
}
import {
  to = module.ip_group["ipgrp-pep-auritas-prod-canadacentral"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-pep-auritas-prod-canadacentral"
}
import {
  to = module.ip_group["ipgrp-pep-df-fabric-nonprod-canadacentral-001"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-pep-df-fabric-nonprod-canadacentral-001"
}
import {
  to = module.ip_group["ipgrp-pep-kdcazdevjumpp1"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-pep-kdcazdevjumpp1"
}
import {
  to = module.ip_group["ipgrp-pep-kv-spo-nonprod-cc"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-pep-kv-spo-nonprod-cc"
}
import {
  to = module.ip_group["ipgrp-pep-kvfabricnonprodcc001"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-pep-kvfabricnonprodcc001"
}
import {
  to = module.ip_group["ipgrp-pep-kvfabricnonprodcc001-vm-fabric-nonprod-canadacentral-001"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-pep-kvfabricnonprodcc001-vm-fabric-nonprod-canadacentral-001"
}
import {
  to = module.ip_group["ipgrp-pep-kvfabricprodcac001"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-pep-kvfabricprodcac001"
}
import {
  to = module.ip_group["ipgrp-pep-psql-openai-nonprod-cc-001"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-pep-psql-openai-nonprod-cc-001"
}
import {
  to = module.ip_group["ipgrp-pep-psql-openai-prod-cc-001"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-pep-psql-openai-prod-cc-001"
}
import {
  to = module.ip_group["ipgrp-pep-stazpkcapture-prod-canadacentral-001"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-pep-stazpkcapture-prod-canadacentral-001"
}
import {
  to = module.ip_group["ipgrp-pep-stfabricnonprodcac001"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-pep-stfabricnonprodcac001"
}
import {
  to = module.ip_group["ipgrp-pep-stfabricprodcac001"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-pep-stfabricprodcac001"
}
import {
  to = module.ip_group["ipgrp-pep-vm-fabric-nonprod-canadacentral-001"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-pep-vm-fabric-nonprod-canadacentral-001"
}
import {
  to = module.ip_group["ipgrp-snet-auritas-nonprod-app-canadacentral-001"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-snet-auritas-nonprod-app-canadacentral-001"
}
import {
  to = module.ip_group["ipgrp-snet-auritas-nonprod-pep-canadacentral-001"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-snet-auritas-nonprod-pep-canadacentral-001"
}
import {
  to = module.ip_group["ipgrp-snet-auritas-prod-app-canadacentral-001"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-snet-auritas-prod-app-canadacentral-001"
}
import {
  to = module.ip_group["ipgrp-snet-auritas-prod-pep-canadacentral-001"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-snet-auritas-prod-pep-canadacentral-001"
}
import {
  to = module.ip_group["ipgrp-vm-openai-prod-canadacentral-001"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-vm-openai-prod-canadacentral-001"
}
import {
  to = module.ip_group["ipgrp-vnet-auritas-nonprod-canadacentral"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-vnet-auritas-nonprod-canadacentral"
}
import {
  to = module.ip_group["ipgrp-vnet-auritas-prod-canadacentral"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-vnet-auritas-prod-canadacentral"
}
import {
  to = module.ip_group["ipgrp-vnet-fabric-nonprod-canadacentral"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-vnet-fabric-nonprod-canadacentral"
}
import {
  to = module.ip_group["ipgrp-vnet-fabric-prod-canadacentral"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-vnet-fabric-prod-canadacentral"
}
import {
  to = module.ip_group["ipgrp-vnet-mds-prod-canadacentral"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-vnet-mds-prod-canadacentral"
}
import {
  to = module.ip_group["ipgrp-vnet-openai-nonprod-canadacentral-001"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-vnet-openai-nonprod-canadacentral-001"
}
import {
  to = module.ip_group["ipgrp-vnet-solace-nonprod-canadacentral"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-vnet-solace-nonprod-canadacentral"
}
import {
  to = module.ip_group["ipgrp-vnet-spo-nonprod-canadacentral"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-vnet-spo-nonprod-canadacentral"
}
import {
  to = module.ip_group["ipgrp-vnet-spo-nonprod-canadaeast"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-vnet-spo-nonprod-canadaeast"
}
import {
  to = module.ip_group["ipgrp-vnet-spo-prod-canadacentral-001"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-vnet-spo-prod-canadacentral-001"
}
import {
  to = module.ip_group["ipgrp-vnet-spo-prod-canadaeast-001"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-vnet-spo-prod-canadaeast-001"
}
import {
  to = module.ip_group["ipgrp-vnet-transit-connectivity-canadacentral"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/ipgrp-vnet-transit-connectivity-canadacentral"
}
import {
  to = module.ip_group["psql-openai-nonprod-cc-001"].module.ip_group.azurerm_ip_group.this
  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/psql-openai-nonprod-cc-001"
}
