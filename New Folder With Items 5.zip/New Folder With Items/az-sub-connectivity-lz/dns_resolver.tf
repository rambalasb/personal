# dns_resolver.tf
# Private DNS Resolver in rg-dns-connectivity-canadacentral-001 (canadacentral):
# 1 resolver (pdr) + 1 inbound + 1 outbound endpoint, plus the frs forwarding
# ruleset (modeled under the outbound endpoint per the wrapper's schema).
# Sourced from per-resource JSON (real names).

locals {
  dns_resolver_data = {
    "pdr-connectivity-canadacentral-001" = {
      location                    = "canadacentral"
      virtual_network_resource_id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dns-connectivity-canadacentral-001"

      inbound_endpoints = {
        "pdr-inbound-connectivity-canadacentral-001" = {
          name                         = "pdr-inbound-connectivity-canadacentral-001"
          subnet_name                  = "snet-dns-inbound-canadacentral-001"
          private_ip_allocation_method = "Static"
          private_ip_address           = "10.195.4.7"
        }
      }

      outbound_endpoints = {
        "pdr-outbound-connectivity-canadacentral-001" = {
          name        = "pdr-outbound-connectivity-canadacentral-001"
          subnet_name = "snet-dns-outbound-canadacentral-001"
          forwarding_ruleset = {
            "frs-dns-connectivity-canadacentral-001" = {
              name = "frs-dns-connectivity-canadacentral-001"
              # No dnsForwardingRulesets/virtualNetworkLinks exist in source.
              link_with_outbound_endpoint_virtual_network = false
            }
          }
        }
      }
    }
  }
}

module "dns_resolver" {
  for_each = local.dns_resolver_data

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-dns-resolver/azurerm"
  version = "0.1.0" # TODO confirm version

  name                        = each.key
  resource_group_name         = module.resource_group["dns"].name
  location                    = each.value.location
  virtual_network_resource_id = each.value.virtual_network_resource_id
  inbound_endpoints           = each.value.inbound_endpoints
  outbound_endpoints          = each.value.outbound_endpoints
  tags                        = local.common_tags
}
