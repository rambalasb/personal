# imports_private_dns.tf — 39 zones + 157 links (confirm AVM internal addresses on first plan)

import {
  to = module.private_dns_zone["app-fit-nonprod-canadacentral-001.appserviceenvironment.net"].module.private_dns_zone.azurerm_private_dns_zone.this
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/app-fit-nonprod-canadacentral-001.appserviceenvironment.net"
}
import {
  to = module.private_dns_zone["app-fit-nonprod-canadacentral-001.appserviceenvironment.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-fit-dns-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/app-fit-nonprod-canadacentral-001.appserviceenvironment.net/virtualNetworkLinks/link-fit-dns-canadacentral-001"
}
import {
  to = module.private_dns_zone["app-fit-nonprod-canadacentral-001.appserviceenvironment.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-sites-dns-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/app-fit-nonprod-canadacentral-001.appserviceenvironment.net/virtualNetworkLinks/link-sites-dns-canadacentral-001"
}
import {
  to = module.private_dns_zone["app-fit-nonprod-canadacentral-001.appserviceenvironment.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-sites-runners-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/app-fit-nonprod-canadacentral-001.appserviceenvironment.net/virtualNetworkLinks/link-sites-runners-canadacentral-001"
}
import {
  to = module.private_dns_zone["app-fit-nonprod-canadacentral-001.appserviceenvironment.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-sites-shared-connectivity-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/app-fit-nonprod-canadacentral-001.appserviceenvironment.net/virtualNetworkLinks/link-sites-shared-connectivity-canadacentral-001"
}
import {
  to = module.private_dns_zone["bchydro.bc.ca"].module.private_dns_zone.azurerm_private_dns_zone.this
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/bchydro.bc.ca"
}
import {
  to = module.private_dns_zone["bchydro.bc.ca"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-cops-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/bchydro.bc.ca/virtualNetworkLinks/link-cops-canadacentral-001"
}
import {
  to = module.private_dns_zone["bchydro.bc.ca"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-dns-connectivity-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/bchydro.bc.ca/virtualNetworkLinks/link-dns-connectivity-canadacentral-001"
}
import {
  to = module.private_dns_zone["bchydro.bc.ca"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-fabric-nonprod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/bchydro.bc.ca/virtualNetworkLinks/link-fabric-nonprod-canadacentral-001"
}
import {
  to = module.private_dns_zone["bchydro.bc.ca"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-fit-nonprod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/bchydro.bc.ca/virtualNetworkLinks/link-fit-nonprod-canadacentral-001"
}
import {
  to = module.private_dns_zone["bchydro.bc.ca"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-fit-prod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/bchydro.bc.ca/virtualNetworkLinks/link-fit-prod-canadacentral-001"
}
import {
  to = module.private_dns_zone["bchydro.bc.ca"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-pta-nonprod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/bchydro.bc.ca/virtualNetworkLinks/link-pta-nonprod-canadacentral-001"
}
import {
  to = module.private_dns_zone["bchydro.bc.ca"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-runners-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/bchydro.bc.ca/virtualNetworkLinks/link-runners-canadacentral-001"
}
import {
  to = module.private_dns_zone["internal.bchydro.bc.ca"].module.private_dns_zone.azurerm_private_dns_zone.this
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/internal.bchydro.bc.ca"
}
import {
  to = module.private_dns_zone["internal.bchydro.bc.ca"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["dns-link-canadacentral"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/internal.bchydro.bc.ca/virtualNetworkLinks/dns-link-canadacentral"
}
import {
  to = module.private_dns_zone["internal.bchydro.bc.ca"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["fit-link-canadacentral"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/internal.bchydro.bc.ca/virtualNetworkLinks/fit-link-canadacentral"
}
import {
  to = module.private_dns_zone["internal.bchydro.bc.ca"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-cyberark-servers-cacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/internal.bchydro.bc.ca/virtualNetworkLinks/link-cyberark-servers-cacentral-001"
}
import {
  to = module.private_dns_zone["internal.bchydro.bc.ca"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-fit-prod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/internal.bchydro.bc.ca/virtualNetworkLinks/link-fit-prod-canadacentral-001"
}
import {
  to = module.private_dns_zone["internal.bchydro.bc.ca"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-sites-cops-nonprod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/internal.bchydro.bc.ca/virtualNetworkLinks/link-sites-cops-nonprod-canadacentral-001"
}
import {
  to = module.private_dns_zone["internal.bchydro.bc.ca"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-sites-cops-prod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/internal.bchydro.bc.ca/virtualNetworkLinks/link-sites-cops-prod-canadacentral-001"
}
import {
  to = module.private_dns_zone["internal.bchydro.bc.ca"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-vnet-auritas-nonprod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/internal.bchydro.bc.ca/virtualNetworkLinks/link-vnet-auritas-nonprod-canadacentral-001"
}
import {
  to = module.private_dns_zone["internal.bchydro.bc.ca"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-vnet-auritas-prod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/internal.bchydro.bc.ca/virtualNetworkLinks/link-vnet-auritas-prod-canadacentral-001"
}
import {
  to = module.private_dns_zone["internal.bchydro.bc.ca"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["runners-link-canadacentral"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/internal.bchydro.bc.ca/virtualNetworkLinks/runners-link-canadacentral"
}
import {
  to = module.private_dns_zone["internal.bchydro.bc.ca"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["shared-link-canadacentral"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/internal.bchydro.bc.ca/virtualNetworkLinks/shared-link-canadacentral"
}
import {
  to = module.private_dns_zone["privatelink.6082b7ce55ac.database.windows.net"].module.private_dns_zone.azurerm_private_dns_zone.this
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.6082b7ce55ac.database.windows.net"
}
import {
  to = module.private_dns_zone["privatelink.6082b7ce55ac.database.windows.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["managed-instance-dns-connectivity-link"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.6082b7ce55ac.database.windows.net/virtualNetworkLinks/managed-instance-dns-connectivity-link"
}
import {
  to = module.private_dns_zone["privatelink.6082b7ce55ac.database.windows.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["managed-instance-runners-link"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.6082b7ce55ac.database.windows.net/virtualNetworkLinks/managed-instance-runners-link"
}
import {
  to = module.private_dns_zone["privatelink.6082b7ce55ac.database.windows.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["mi-sql-pta-privatelink-canadacentral"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.6082b7ce55ac.database.windows.net/virtualNetworkLinks/mi-sql-pta-privatelink-canadacentral"
}
import {
  to = module.private_dns_zone["privatelink.afs.azure.net"].module.private_dns_zone.azurerm_private_dns_zone.this
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.afs.azure.net"
}
import {
  to = module.private_dns_zone["privatelink.agentsvc.azure-automation.net"].module.private_dns_zone.azurerm_private_dns_zone.this
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.agentsvc.azure-automation.net"
}
import {
  to = module.private_dns_zone["privatelink.agentsvc.azure-automation.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-cops-nonprod-canadacentral"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.agentsvc.azure-automation.net/virtualNetworkLinks/link-cops-nonprod-canadacentral"
}
import {
  to = module.private_dns_zone["privatelink.agentsvc.azure-automation.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-cops-prod-canadacentral"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.agentsvc.azure-automation.net/virtualNetworkLinks/link-cops-prod-canadacentral"
}
import {
  to = module.private_dns_zone["privatelink.agentsvc.azure-automation.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-fit-nonprod-canadacentral"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.agentsvc.azure-automation.net/virtualNetworkLinks/link-fit-nonprod-canadacentral"
}
import {
  to = module.private_dns_zone["privatelink.agentsvc.azure-automation.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-fit-prod-canadacentral"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.agentsvc.azure-automation.net/virtualNetworkLinks/link-fit-prod-canadacentral"
}
import {
  to = module.private_dns_zone["privatelink.agentsvc.azure-automation.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-openai-nonprod-canadacentral"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.agentsvc.azure-automation.net/virtualNetworkLinks/link-openai-nonprod-canadacentral"
}
import {
  to = module.private_dns_zone["privatelink.agentsvc.azure-automation.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-pta-nonprod-canadacentral"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.agentsvc.azure-automation.net/virtualNetworkLinks/link-pta-nonprod-canadacentral"
}
import {
  to = module.private_dns_zone["privatelink.agentsvc.azure-automation.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-pta-prod-canadacentral"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.agentsvc.azure-automation.net/virtualNetworkLinks/link-pta-prod-canadacentral"
}
import {
  to = module.private_dns_zone["privatelink.agentsvc.azure-automation.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["ryv5tt5odaoak"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.agentsvc.azure-automation.net/virtualNetworkLinks/ryv5tt5odaoak"
}
import {
  to = module.private_dns_zone["privatelink.aiservices.azure.com"].module.private_dns_zone.azurerm_private_dns_zone.this
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.aiservices.azure.com"
}
import {
  to = module.private_dns_zone["privatelink.azurecr.io"].module.private_dns_zone.azurerm_private_dns_zone.this
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.azurecr.io"
}
import {
  to = module.private_dns_zone["privatelink.azurecr.io"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-dns-connectivity-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.azurecr.io/virtualNetworkLinks/link-dns-connectivity-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.azurecr.io"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-openai-vnet-canadacentral-link"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.azurecr.io/virtualNetworkLinks/link-openai-vnet-canadacentral-link"
}
import {
  to = module.private_dns_zone["privatelink.azurecr.io"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-openai-vnet-prod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.azurecr.io/virtualNetworkLinks/link-openai-vnet-prod-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.azuresynapse.net"].module.private_dns_zone.azurerm_private_dns_zone.this
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.azuresynapse.net"
}
import {
  to = module.private_dns_zone["privatelink.azurewebsites.net"].module.private_dns_zone.azurerm_private_dns_zone.this
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.azurewebsites.net"
}
import {
  to = module.private_dns_zone["privatelink.azurewebsites.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-auritas-nonprod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.azurewebsites.net/virtualNetworkLinks/link-auritas-nonprod-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.azurewebsites.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-openai-vnet-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.azurewebsites.net/virtualNetworkLinks/link-openai-vnet-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.azurewebsites.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-openai-vnet-prod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.azurewebsites.net/virtualNetworkLinks/link-openai-vnet-prod-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.azurewebsites.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-sites-cops-nonprod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.azurewebsites.net/virtualNetworkLinks/link-sites-cops-nonprod-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.azurewebsites.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-sites-cops-prod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.azurewebsites.net/virtualNetworkLinks/link-sites-cops-prod-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.azurewebsites.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-sites-dns-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.azurewebsites.net/virtualNetworkLinks/link-sites-dns-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.azurewebsites.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-sites-fit-nonprod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.azurewebsites.net/virtualNetworkLinks/link-sites-fit-nonprod-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.azurewebsites.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-sites-fit-prod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.azurewebsites.net/virtualNetworkLinks/link-sites-fit-prod-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.azurewebsites.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-sites-runners-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.azurewebsites.net/virtualNetworkLinks/link-sites-runners-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.azurewebsites.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-sites-shared-connectivity-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.azurewebsites.net/virtualNetworkLinks/link-sites-shared-connectivity-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.blob.core.windows.net"].module.private_dns_zone.azurerm_private_dns_zone.this
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net"
}
import {
  to = module.private_dns_zone["privatelink.blob.core.windows.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-auritas-prod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net/virtualNetworkLinks/link-auritas-prod-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.blob.core.windows.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-blob-cops-nonprod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net/virtualNetworkLinks/link-blob-cops-nonprod-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.blob.core.windows.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-blob-cops-prod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net/virtualNetworkLinks/link-blob-cops-prod-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.blob.core.windows.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-blob-dns-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net/virtualNetworkLinks/link-blob-dns-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.blob.core.windows.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-blob-fit-nonprod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net/virtualNetworkLinks/link-blob-fit-nonprod-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.blob.core.windows.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-blob-fit-prod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net/virtualNetworkLinks/link-blob-fit-prod-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.blob.core.windows.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-blob-pta-nonprod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net/virtualNetworkLinks/link-blob-pta-nonprod-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.blob.core.windows.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-blob-pta-prod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net/virtualNetworkLinks/link-blob-pta-prod-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.blob.core.windows.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-blob-runners-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net/virtualNetworkLinks/link-blob-runners-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.blob.core.windows.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-mft-dev-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net/virtualNetworkLinks/link-mft-dev-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.blob.core.windows.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-openai-vnet-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net/virtualNetworkLinks/link-openai-vnet-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.blob.core.windows.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-openai-vnet-prod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net/virtualNetworkLinks/link-openai-vnet-prod-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.blob.core.windows.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-vnet-auritas-nonprod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net/virtualNetworkLinks/link-vnet-auritas-nonprod-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.blob.core.windows.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-vnet-fabric-nonprod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net/virtualNetworkLinks/link-vnet-fabric-nonprod-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.blob.core.windows.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-vnet-fabric-prod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net/virtualNetworkLinks/link-vnet-fabric-prod-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.blob.core.windows.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-vnet-mds-prod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net/virtualNetworkLinks/link-vnet-mds-prod-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.canadacentral.azmk8s.io"].module.private_dns_zone.azurerm_private_dns_zone.this
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.canadacentral.azmk8s.io"
}
import {
  to = module.private_dns_zone["privatelink.canadaeast.azmk8s.io"].module.private_dns_zone.azurerm_private_dns_zone.this
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.canadaeast.azmk8s.io"
}
import {
  to = module.private_dns_zone["privatelink.cnc.backup.windowsazure.com"].module.private_dns_zone.azurerm_private_dns_zone.this
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.cnc.backup.windowsazure.com"
}
import {
  to = module.private_dns_zone["privatelink.cnc.backup.windowsazure.com"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["5kuztzayyvoh2"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.cnc.backup.windowsazure.com/virtualNetworkLinks/5kuztzayyvoh2"
}
import {
  to = module.private_dns_zone["privatelink.cnc.backup.windowsazure.com"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["g3sclxwzc33p2"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.cnc.backup.windowsazure.com/virtualNetworkLinks/g3sclxwzc33p2"
}
import {
  to = module.private_dns_zone["privatelink.cnc.backup.windowsazure.com"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-dns-connectivity-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.cnc.backup.windowsazure.com/virtualNetworkLinks/link-dns-connectivity-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.cognitiveservices.azure.com"].module.private_dns_zone.azurerm_private_dns_zone.this
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.cognitiveservices.azure.com"
}
import {
  to = module.private_dns_zone["privatelink.cognitiveservices.azure.com"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-openai-vnet-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.cognitiveservices.azure.com/virtualNetworkLinks/link-openai-vnet-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.cognitiveservices.azure.com"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-openai-vnet-prod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.cognitiveservices.azure.com/virtualNetworkLinks/link-openai-vnet-prod-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.d1b5826aa498.database.windows.net"].module.private_dns_zone.azurerm_private_dns_zone.this
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.d1b5826aa498.database.windows.net"
}
import {
  to = module.private_dns_zone["privatelink.d1b5826aa498.database.windows.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["managed-instance-dns-connectivity-link"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.d1b5826aa498.database.windows.net/virtualNetworkLinks/managed-instance-dns-connectivity-link"
}
import {
  to = module.private_dns_zone["privatelink.d1b5826aa498.database.windows.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["managed-instance-runners-link"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.d1b5826aa498.database.windows.net/virtualNetworkLinks/managed-instance-runners-link"
}
import {
  to = module.private_dns_zone["privatelink.d1b5826aa498.database.windows.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["mi-sql-pta-privatelink-canadacentral"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.d1b5826aa498.database.windows.net/virtualNetworkLinks/mi-sql-pta-privatelink-canadacentral"
}
import {
  to = module.private_dns_zone["privatelink.d1b5826aa498.database.windows.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["pta-vnet-link-shared-connectivity"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.d1b5826aa498.database.windows.net/virtualNetworkLinks/pta-vnet-link-shared-connectivity"
}
import {
  to = module.private_dns_zone["privatelink.database.windows.net"].module.private_dns_zone.azurerm_private_dns_zone.this
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.database.windows.net"
}
import {
  to = module.private_dns_zone["privatelink.database.windows.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-mft-dev-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.database.windows.net/virtualNetworkLinks/link-mft-dev-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.database.windows.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-sql-cops-nonprod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.database.windows.net/virtualNetworkLinks/link-sql-cops-nonprod-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.database.windows.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-sql-cops-prod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.database.windows.net/virtualNetworkLinks/link-sql-cops-prod-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.database.windows.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-sql-dns-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.database.windows.net/virtualNetworkLinks/link-sql-dns-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.database.windows.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-sql-pta-nonprod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.database.windows.net/virtualNetworkLinks/link-sql-pta-nonprod-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.database.windows.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-sql-runners-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.database.windows.net/virtualNetworkLinks/link-sql-runners-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.datafactory.azure.net"].module.private_dns_zone.azurerm_private_dns_zone.this
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.datafactory.azure.net"
}
import {
  to = module.private_dns_zone["privatelink.datafactory.azure.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-vnet-dns-connectivity-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.datafactory.azure.net/virtualNetworkLinks/link-vnet-dns-connectivity-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.datafactory.azure.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-vnet-fabric-nonprod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.datafactory.azure.net/virtualNetworkLinks/link-vnet-fabric-nonprod-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.datafactory.azure.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-vnet-fabric-prod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.datafactory.azure.net/virtualNetworkLinks/link-vnet-fabric-prod-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.dev.azuresynapse.net"].module.private_dns_zone.azurerm_private_dns_zone.this
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.dev.azuresynapse.net"
}
import {
  to = module.private_dns_zone["privatelink.dfs.core.windows.net"].module.private_dns_zone.azurerm_private_dns_zone.this
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.dfs.core.windows.net"
}
import {
  to = module.private_dns_zone["privatelink.dfs.core.windows.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-dfs-dns-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.dfs.core.windows.net/virtualNetworkLinks/link-dfs-dns-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.dfs.core.windows.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-vnet-fabric-nonprod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.dfs.core.windows.net/virtualNetworkLinks/link-vnet-fabric-nonprod-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.dfs.core.windows.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-vnet-fabric-prod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.dfs.core.windows.net/virtualNetworkLinks/link-vnet-fabric-prod-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.documents.azure.com"].module.private_dns_zone.azurerm_private_dns_zone.this
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.documents.azure.com"
}
import {
  to = module.private_dns_zone["privatelink.documents.azure.com"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-dns-connectivity-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.documents.azure.com/virtualNetworkLinks/link-dns-connectivity-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.documents.azure.com"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-openai-vnet-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.documents.azure.com/virtualNetworkLinks/link-openai-vnet-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.documents.azure.com"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-openai-vnet-prod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.documents.azure.com/virtualNetworkLinks/link-openai-vnet-prod-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.dp.kubernetesconfiguration.azure.com"].module.private_dns_zone.azurerm_private_dns_zone.this
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.dp.kubernetesconfiguration.azure.com"
}
import {
  to = module.private_dns_zone["privatelink.dp.kubernetesconfiguration.azure.com"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-dns-connectivity-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.dp.kubernetesconfiguration.azure.com/virtualNetworkLinks/link-dns-connectivity-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.dp.kubernetesconfiguration.azure.com"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-vnet-mds-prod-canadacentral"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.dp.kubernetesconfiguration.azure.com/virtualNetworkLinks/link-vnet-mds-prod-canadacentral"
}
import {
  to = module.private_dns_zone["privatelink.file.core.windows.net"].module.private_dns_zone.azurerm_private_dns_zone.this
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.file.core.windows.net"
}
import {
  to = module.private_dns_zone["privatelink.file.core.windows.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-file-cops-prod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.file.core.windows.net/virtualNetworkLinks/link-file-cops-prod-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.file.core.windows.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-files-cops-nonprod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.file.core.windows.net/virtualNetworkLinks/link-files-cops-nonprod-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.file.core.windows.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-files-dns-connectivity-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.file.core.windows.net/virtualNetworkLinks/link-files-dns-connectivity-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.file.core.windows.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-files-fit-nonprod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.file.core.windows.net/virtualNetworkLinks/link-files-fit-nonprod-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.file.core.windows.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-files-pta-nonprod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.file.core.windows.net/virtualNetworkLinks/link-files-pta-nonprod-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.file.core.windows.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-mft-dev-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.file.core.windows.net/virtualNetworkLinks/link-mft-dev-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.guestconfiguration.azure.com"].module.private_dns_zone.azurerm_private_dns_zone.this
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.guestconfiguration.azure.com"
}
import {
  to = module.private_dns_zone["privatelink.guestconfiguration.azure.com"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-dns-connectivity-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.guestconfiguration.azure.com/virtualNetworkLinks/link-dns-connectivity-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.guestconfiguration.azure.com"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-vnet-mds-prod-canadacentral"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.guestconfiguration.azure.com/virtualNetworkLinks/link-vnet-mds-prod-canadacentral"
}
import {
  to = module.private_dns_zone["privatelink.his.arc.azure.com"].module.private_dns_zone.azurerm_private_dns_zone.this
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.his.arc.azure.com"
}
import {
  to = module.private_dns_zone["privatelink.his.arc.azure.com"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-dns-connectivity-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.his.arc.azure.com/virtualNetworkLinks/link-dns-connectivity-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.his.arc.azure.com"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-vnet-mds-prod-canadacentral"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.his.arc.azure.com/virtualNetworkLinks/link-vnet-mds-prod-canadacentral"
}
import {
  to = module.private_dns_zone["privatelink.monitor.azure.com"].module.private_dns_zone.azurerm_private_dns_zone.this
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.monitor.azure.com"
}
import {
  to = module.private_dns_zone["privatelink.monitor.azure.com"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-cops-nonprod-canadacentral"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.monitor.azure.com/virtualNetworkLinks/link-cops-nonprod-canadacentral"
}
import {
  to = module.private_dns_zone["privatelink.monitor.azure.com"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-cops-prod-canadacentral"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.monitor.azure.com/virtualNetworkLinks/link-cops-prod-canadacentral"
}
import {
  to = module.private_dns_zone["privatelink.monitor.azure.com"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-fit-nonprod-canadacentral"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.monitor.azure.com/virtualNetworkLinks/link-fit-nonprod-canadacentral"
}
import {
  to = module.private_dns_zone["privatelink.monitor.azure.com"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-fit-prod-canadacentral"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.monitor.azure.com/virtualNetworkLinks/link-fit-prod-canadacentral"
}
import {
  to = module.private_dns_zone["privatelink.monitor.azure.com"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-openai-nonprod-canadacentral"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.monitor.azure.com/virtualNetworkLinks/link-openai-nonprod-canadacentral"
}
import {
  to = module.private_dns_zone["privatelink.monitor.azure.com"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-pta-nonprod-canadacentral"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.monitor.azure.com/virtualNetworkLinks/link-pta-nonprod-canadacentral"
}
import {
  to = module.private_dns_zone["privatelink.monitor.azure.com"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-pta-prod-canadacentral"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.monitor.azure.com/virtualNetworkLinks/link-pta-prod-canadacentral"
}
import {
  to = module.private_dns_zone["privatelink.monitor.azure.com"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["ryv5tt5odaoak"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.monitor.azure.com/virtualNetworkLinks/ryv5tt5odaoak"
}
import {
  to = module.private_dns_zone["privatelink.ods.opinsights.azure.com"].module.private_dns_zone.azurerm_private_dns_zone.this
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.ods.opinsights.azure.com"
}
import {
  to = module.private_dns_zone["privatelink.ods.opinsights.azure.com"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-cops-nonprod-canadacentral"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.ods.opinsights.azure.com/virtualNetworkLinks/link-cops-nonprod-canadacentral"
}
import {
  to = module.private_dns_zone["privatelink.ods.opinsights.azure.com"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-cops-prod-canadacentral"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.ods.opinsights.azure.com/virtualNetworkLinks/link-cops-prod-canadacentral"
}
import {
  to = module.private_dns_zone["privatelink.ods.opinsights.azure.com"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-fit-nonprod-canadacentral"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.ods.opinsights.azure.com/virtualNetworkLinks/link-fit-nonprod-canadacentral"
}
import {
  to = module.private_dns_zone["privatelink.ods.opinsights.azure.com"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-fit-prod-canadacentral"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.ods.opinsights.azure.com/virtualNetworkLinks/link-fit-prod-canadacentral"
}
import {
  to = module.private_dns_zone["privatelink.ods.opinsights.azure.com"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-openai-nonprod-canadacentral"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.ods.opinsights.azure.com/virtualNetworkLinks/link-openai-nonprod-canadacentral"
}
import {
  to = module.private_dns_zone["privatelink.ods.opinsights.azure.com"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-pta-nonprod-canadacentral"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.ods.opinsights.azure.com/virtualNetworkLinks/link-pta-nonprod-canadacentral"
}
import {
  to = module.private_dns_zone["privatelink.ods.opinsights.azure.com"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-pta-prod-canadacentral"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.ods.opinsights.azure.com/virtualNetworkLinks/link-pta-prod-canadacentral"
}
import {
  to = module.private_dns_zone["privatelink.ods.opinsights.azure.com"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["ryv5tt5odaoak"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.ods.opinsights.azure.com/virtualNetworkLinks/ryv5tt5odaoak"
}
import {
  to = module.private_dns_zone["privatelink.oms.opinsights.azure.com"].module.private_dns_zone.azurerm_private_dns_zone.this
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.oms.opinsights.azure.com"
}
import {
  to = module.private_dns_zone["privatelink.oms.opinsights.azure.com"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-cops-nonprod-canadacentral"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.oms.opinsights.azure.com/virtualNetworkLinks/link-cops-nonprod-canadacentral"
}
import {
  to = module.private_dns_zone["privatelink.oms.opinsights.azure.com"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-cops-prod-canadacentral"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.oms.opinsights.azure.com/virtualNetworkLinks/link-cops-prod-canadacentral"
}
import {
  to = module.private_dns_zone["privatelink.oms.opinsights.azure.com"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-fit-nonprod-canadacentral"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.oms.opinsights.azure.com/virtualNetworkLinks/link-fit-nonprod-canadacentral"
}
import {
  to = module.private_dns_zone["privatelink.oms.opinsights.azure.com"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-fit-prod-canadacentral"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.oms.opinsights.azure.com/virtualNetworkLinks/link-fit-prod-canadacentral"
}
import {
  to = module.private_dns_zone["privatelink.oms.opinsights.azure.com"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-openai-nonprod-canadacentral"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.oms.opinsights.azure.com/virtualNetworkLinks/link-openai-nonprod-canadacentral"
}
import {
  to = module.private_dns_zone["privatelink.oms.opinsights.azure.com"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-pta-nonprod-canadacentral"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.oms.opinsights.azure.com/virtualNetworkLinks/link-pta-nonprod-canadacentral"
}
import {
  to = module.private_dns_zone["privatelink.oms.opinsights.azure.com"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-pta-prod-canadacentral"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.oms.opinsights.azure.com/virtualNetworkLinks/link-pta-prod-canadacentral"
}
import {
  to = module.private_dns_zone["privatelink.oms.opinsights.azure.com"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["ryv5tt5odaoak"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.oms.opinsights.azure.com/virtualNetworkLinks/ryv5tt5odaoak"
}
import {
  to = module.private_dns_zone["privatelink.openai.azure.com"].module.private_dns_zone.azurerm_private_dns_zone.this
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.openai.azure.com"
}
import {
  to = module.private_dns_zone["privatelink.openai.azure.com"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-openai-vnet-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.openai.azure.com/virtualNetworkLinks/link-openai-vnet-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.openai.azure.com"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-openai-vnet-prod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.openai.azure.com/virtualNetworkLinks/link-openai-vnet-prod-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.oracledb.azure.com"].module.private_dns_zone.azurerm_private_dns_zone.this
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.oracledb.azure.com"
}
import {
  to = module.private_dns_zone["privatelink.postgres.database.azure.com"].module.private_dns_zone.azurerm_private_dns_zone.this
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.postgres.database.azure.com"
}
import {
  to = module.private_dns_zone["privatelink.postgres.database.azure.com"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-dns-connectivity-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.postgres.database.azure.com/virtualNetworkLinks/link-dns-connectivity-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.postgres.database.azure.com"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-openai-vnet-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.postgres.database.azure.com/virtualNetworkLinks/link-openai-vnet-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.postgres.database.azure.com"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-openai-vnet-prod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.postgres.database.azure.com/virtualNetworkLinks/link-openai-vnet-prod-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.queue.core.windows.net"].module.private_dns_zone.azurerm_private_dns_zone.this
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.queue.core.windows.net"
}
import {
  to = module.private_dns_zone["privatelink.queue.core.windows.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["5kuztzayyvoh2"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.queue.core.windows.net/virtualNetworkLinks/5kuztzayyvoh2"
}
import {
  to = module.private_dns_zone["privatelink.queue.core.windows.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["g3sclxwzc33p2"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.queue.core.windows.net/virtualNetworkLinks/g3sclxwzc33p2"
}
import {
  to = module.private_dns_zone["privatelink.queue.core.windows.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-openai-vnet-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.queue.core.windows.net/virtualNetworkLinks/link-openai-vnet-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.queue.core.windows.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-openai-vnet-prod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.queue.core.windows.net/virtualNetworkLinks/link-openai-vnet-prod-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.queue.core.windows.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-queue-dns-connectivity-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.queue.core.windows.net/virtualNetworkLinks/link-queue-dns-connectivity-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.redis.azure.net"].module.private_dns_zone.azurerm_private_dns_zone.this
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.redis.azure.net"
}
import {
  to = module.private_dns_zone["privatelink.redis.azure.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["dmzd6g33v2eog"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.redis.azure.net/virtualNetworkLinks/dmzd6g33v2eog"
}
import {
  to = module.private_dns_zone["privatelink.redis.azure.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-dns-connectivity-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.redis.azure.net/virtualNetworkLinks/link-dns-connectivity-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.redis.cache.windows.net"].module.private_dns_zone.azurerm_private_dns_zone.this
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.redis.cache.windows.net"
}
import {
  to = module.private_dns_zone["privatelink.redis.cache.windows.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["dmzd6g33v2eog"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.redis.cache.windows.net/virtualNetworkLinks/dmzd6g33v2eog"
}
import {
  to = module.private_dns_zone["privatelink.redis.cache.windows.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-cache-cops-prod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.redis.cache.windows.net/virtualNetworkLinks/link-cache-cops-prod-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.redis.cache.windows.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-cache-dns-connectivity-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.redis.cache.windows.net/virtualNetworkLinks/link-cache-dns-connectivity-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.servicebus.windows.net"].module.private_dns_zone.azurerm_private_dns_zone.this
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.servicebus.windows.net"
}
import {
  to = module.private_dns_zone["privatelink.servicebus.windows.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-dns-connectivity-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.servicebus.windows.net/virtualNetworkLinks/link-dns-connectivity-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.servicebus.windows.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-shared-connectivity-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.servicebus.windows.net/virtualNetworkLinks/link-shared-connectivity-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.sql.azuresynapse.net"].module.private_dns_zone.azurerm_private_dns_zone.this
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.sql.azuresynapse.net"
}
import {
  to = module.private_dns_zone["privatelink.table.core.windows.net"].module.private_dns_zone.azurerm_private_dns_zone.this
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.table.core.windows.net"
}
import {
  to = module.private_dns_zone["privatelink.table.core.windows.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-dns-connectivity-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.table.core.windows.net/virtualNetworkLinks/link-dns-connectivity-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.vaultcore.azure.net"].module.private_dns_zone.azurerm_private_dns_zone.this
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.vaultcore.azure.net"
}
import {
  to = module.private_dns_zone["privatelink.vaultcore.azure.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-mft-dev-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.vaultcore.azure.net/virtualNetworkLinks/link-mft-dev-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.vaultcore.azure.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-openai-vnet-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.vaultcore.azure.net/virtualNetworkLinks/link-openai-vnet-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.vaultcore.azure.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-openai-vnet-prod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.vaultcore.azure.net/virtualNetworkLinks/link-openai-vnet-prod-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.vaultcore.azure.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-spo-nonprod-vnet-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.vaultcore.azure.net/virtualNetworkLinks/link-spo-nonprod-vnet-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.vaultcore.azure.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-spo-nonprod-vnet-canadaeast-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.vaultcore.azure.net/virtualNetworkLinks/link-spo-nonprod-vnet-canadaeast-001"
}
import {
  to = module.private_dns_zone["privatelink.vaultcore.azure.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-spo-prod-vnet-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.vaultcore.azure.net/virtualNetworkLinks/link-spo-prod-vnet-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.vaultcore.azure.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-spo-prod-vnet-canadaeast-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.vaultcore.azure.net/virtualNetworkLinks/link-spo-prod-vnet-canadaeast-001"
}
import {
  to = module.private_dns_zone["privatelink.vaultcore.azure.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-vault-cops-nonprod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.vaultcore.azure.net/virtualNetworkLinks/link-vault-cops-nonprod-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.vaultcore.azure.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-vault-cops-prod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.vaultcore.azure.net/virtualNetworkLinks/link-vault-cops-prod-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.vaultcore.azure.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-vault-dns-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.vaultcore.azure.net/virtualNetworkLinks/link-vault-dns-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.vaultcore.azure.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-vault-fit-nonprod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.vaultcore.azure.net/virtualNetworkLinks/link-vault-fit-nonprod-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.vaultcore.azure.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-vault-fit-prod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.vaultcore.azure.net/virtualNetworkLinks/link-vault-fit-prod-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.vaultcore.azure.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-vault-pta-nonprod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.vaultcore.azure.net/virtualNetworkLinks/link-vault-pta-nonprod-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.vaultcore.azure.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-vault-pta-prod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.vaultcore.azure.net/virtualNetworkLinks/link-vault-pta-prod-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.vaultcore.azure.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-vault-runners-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.vaultcore.azure.net/virtualNetworkLinks/link-vault-runners-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.vaultcore.azure.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-vnet-fabric-nonprod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.vaultcore.azure.net/virtualNetworkLinks/link-vnet-fabric-nonprod-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.vaultcore.azure.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-vnet-fabric-prod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.vaultcore.azure.net/virtualNetworkLinks/link-vnet-fabric-prod-canadacentral-001"
}
import {
  to = module.private_dns_zone["privatelink.web.core.windows.net"].module.private_dns_zone.azurerm_private_dns_zone.this
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.web.core.windows.net"
}
import {
  to = module.private_dns_zone["privatelink.web.core.windows.net"].module.private_dns_zone.azurerm_private_dns_zone_virtual_network_link.this["link-dns-connectivity-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.web.core.windows.net/virtualNetworkLinks/link-dns-connectivity-canadacentral-001"
}
