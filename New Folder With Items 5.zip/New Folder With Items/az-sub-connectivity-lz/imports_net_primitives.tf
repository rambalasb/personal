# imports_net_primitives.tf
# confirm AVM internal import addresses on first plan

# DDoS protection plan
import {
  to = module.ddos_protection_plan["ddos-protection-plan"].module.ddos_protection_plan.azurerm_network_ddos_protection_plan.this
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/ddosProtectionPlans/ddos-protection-plan"
}

# NAT gateways
import {
  to = module.nat_gateway["ngw-cyberark-connectivity-canadacentral-001"].module.nat_gateway.azurerm_nat_gateway.this
  id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Network/natGateways/ngw-cyberark-connectivity-canadacentral-001"
}
import {
  to = module.nat_gateway["ngw-runners-connectivity-canadacentral-001"].module.nat_gateway.azurerm_nat_gateway.this
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/natGateways/ngw-runners-connectivity-canadacentral-001"
}
import {
  to = module.nat_gateway["ngw-shared-connectivity-canadacentral-001"].module.nat_gateway.azurerm_nat_gateway.this
  id = "${local.sub}/resourceGroups/rg-shared-connectivity-canadacentral-001/providers/Microsoft.Network/natGateways/ngw-shared-connectivity-canadacentral-001"
}

# Public IP prefixes
import {
  to = module.public_ip_prefix["pip-ngw-cyberark-connectivity-canadacentral-001"].module.public_ip_prefix.azurerm_public_ip_prefix.this
  id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Network/publicIPPrefixes/pip-ngw-cyberark-connectivity-canadacentral-001"
}
import {
  to = module.public_ip_prefix["pip-ngw-runners-connectivity-canadacentral-001"].module.public_ip_prefix.azurerm_public_ip_prefix.this
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/publicIPPrefixes/pip-ngw-runners-connectivity-canadacentral-001"
}
import {
  to = module.public_ip_prefix["pip-ngw-shared-connectivity-canadacentral-001"].module.public_ip_prefix.azurerm_public_ip_prefix.this
  id = "${local.sub}/resourceGroups/rg-shared-connectivity-canadacentral-001/providers/Microsoft.Network/publicIPPrefixes/pip-ngw-shared-connectivity-canadacentral-001"
}

# Public IP addresses (native)
import {
  to = azurerm_public_ip.this["pip-ars-transit-connectivity-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-shared-connectivity-canadacentral-001/providers/Microsoft.Network/publicIPAddresses/pip-ars-transit-connectivity-canadacentral-001"
}
import {
  to = azurerm_public_ip.this["pip-azfw-transit-connectivity-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-shared-connectivity-canadacentral-001/providers/Microsoft.Network/publicIPAddresses/pip-azfw-transit-connectivity-canadacentral-001"
}

# Network security groups + rules
import {
  to = module.network_security_group["nsg-cyberark-servers-canadacentral-001"].module.network_security_group.azurerm_network_security_group.this
  id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-cyberark-servers-canadacentral-001"
}
import {
  to = module.network_security_group["nsg-cyberark-servers-canadacentral-001"].module.network_security_group.azurerm_network_security_rule.this["MicrosoftDefenderForCloud-JITRule_324660756_5D9A522ECE3E484A9208AA226FBF47FD"]
  id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-cyberark-servers-canadacentral-001/securityRules/MicrosoftDefenderForCloud-JITRule_324660756_5D9A522ECE3E484A9208AA226FBF47FD"
}
import {
  to = module.network_security_group["nsg-cyberark-servers-canadacentral-001"].module.network_security_group.azurerm_network_security_rule.this["AllowOnPrem"]
  id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-cyberark-servers-canadacentral-001/securityRules/AllowOnPrem"
}
import {
  to = module.network_security_group["nsg-cyberark-servers-canadacentral-001"].module.network_security_group.azurerm_network_security_rule.this["AllowBastionAccess"]
  id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-cyberark-servers-canadacentral-001/securityRules/AllowBastionAccess"
}
import {
  to = module.network_security_group["nsg-cyberark-servers-canadacentral-001"].module.network_security_group.azurerm_network_security_rule.this["Cyberark-SSH"]
  id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-cyberark-servers-canadacentral-001/securityRules/Cyberark-SSH"
}
import {
  to = module.network_security_group["nsg-dmz-gw-nonprod-canadacentral-001"].module.network_security_group.azurerm_network_security_group.this
  id = "${local.sub}/resourceGroups/rg-dmz-connectivity-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-dmz-gw-nonprod-canadacentral-001"
}
import {
  to = module.network_security_group["nsg-dmz-gw-prod-canadacentral-001"].module.network_security_group.azurerm_network_security_group.this
  id = "${local.sub}/resourceGroups/rg-dmz-connectivity-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-dmz-gw-prod-canadacentral-001"
}
import {
  to = module.network_security_group["nsg-ertest-canadacentral-001"].module.network_security_group.azurerm_network_security_group.this
  id = "${local.sub}/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-ertest-canadacentral-001"
}
import {
  to = module.network_security_group["nsg-ertest-canadacentral-001"].module.network_security_group.azurerm_network_security_rule.this["AllowOnPrem"]
  id = "${local.sub}/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-ertest-canadacentral-001/securityRules/AllowOnPrem"
}
import {
  to = module.network_security_group["nsg-ertest-canadacentral-001"].module.network_security_group.azurerm_network_security_rule.this["allowBastionHost"]
  id = "${local.sub}/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-ertest-canadacentral-001/securityRules/allowBastionHost"
}
import {
  to = module.network_security_group["nsg-ertest-canadaeast-001"].module.network_security_group.azurerm_network_security_group.this
  id = "${local.sub}/resourceGroups/rg-ertest-canadaeast-001/providers/Microsoft.Network/networkSecurityGroups/nsg-ertest-canadaeast-001"
}
import {
  to = module.network_security_group["nsg-ertest-canadaeast-001"].module.network_security_group.azurerm_network_security_rule.this["AllowOnPrem"]
  id = "${local.sub}/resourceGroups/rg-ertest-canadaeast-001/providers/Microsoft.Network/networkSecurityGroups/nsg-ertest-canadaeast-001/securityRules/AllowOnPrem"
}
import {
  to = module.network_security_group["nsg-ertest-canadaeast-001"].module.network_security_group.azurerm_network_security_rule.this["allowBastionHost"]
  id = "${local.sub}/resourceGroups/rg-ertest-canadaeast-001/providers/Microsoft.Network/networkSecurityGroups/nsg-ertest-canadaeast-001/securityRules/allowBastionHost"
}
import {
  to = module.network_security_group["nsg-bh-canadacentral-001"].module.network_security_group.azurerm_network_security_group.this
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-bh-canadacentral-001"
}
import {
  to = module.network_security_group["nsg-bh-canadacentral-001"].module.network_security_group.azurerm_network_security_rule.this["allowHttps"]
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-bh-canadacentral-001/securityRules/allowHttps"
}
import {
  to = module.network_security_group["nsg-bh-canadacentral-001"].module.network_security_group.azurerm_network_security_rule.this["allowBastionComm"]
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-bh-canadacentral-001/securityRules/allowBastionComm"
}
import {
  to = module.network_security_group["nsg-bh-canadacentral-001"].module.network_security_group.azurerm_network_security_rule.this["allowBastionCommOutbound"]
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-bh-canadacentral-001/securityRules/allowBastionCommOutbound"
}
import {
  to = module.network_security_group["nsg-bh-canadacentral-001"].module.network_security_group.azurerm_network_security_rule.this["allowHttpOutbound"]
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-bh-canadacentral-001/securityRules/allowHttpOutbound"
}
import {
  to = module.network_security_group["nsg-bh-canadacentral-001"].module.network_security_group.azurerm_network_security_rule.this["allowAzureCLoudOut"]
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-bh-canadacentral-001/securityRules/allowAzureCLoudOut"
}
import {
  to = module.network_security_group["nsg-bh-canadacentral-001"].module.network_security_group.azurerm_network_security_rule.this["allowSSHRDPOutbound"]
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-bh-canadacentral-001/securityRules/allowSSHRDPOutbound"
}
import {
  to = module.network_security_group["nsg-bh-canadacentral-001"].module.network_security_group.azurerm_network_security_rule.this["allowAllPriority"]
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-bh-canadacentral-001/securityRules/allowAllPriority"
}
import {
  to = module.network_security_group["nsg-bh-canadacentral-001"].module.network_security_group.azurerm_network_security_rule.this["allowAllIn"]
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-bh-canadacentral-001/securityRules/allowAllIn"
}
import {
  to = module.network_security_group["nsg-runners-dev-canadacentral-001"].module.network_security_group.azurerm_network_security_group.this
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-runners-dev-canadacentral-001"
}
import {
  to = module.network_security_group["nsg-runners-dev-canadacentral-001"].module.network_security_group.azurerm_network_security_rule.this["AllowOnPrem"]
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-runners-dev-canadacentral-001/securityRules/AllowOnPrem"
}
import {
  to = module.network_security_group["nsg-runners-dev-canadacentral-001"].module.network_security_group.azurerm_network_security_rule.this["DenyAllInbound"]
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-runners-dev-canadacentral-001/securityRules/DenyAllInbound"
}
import {
  to = module.network_security_group["nsg-runners-dev-canadacentral-001"].module.network_security_group.azurerm_network_security_rule.this["AllowBastionHost"]
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-runners-dev-canadacentral-001/securityRules/AllowBastionHost"
}
import {
  to = module.network_security_group["nsg-runners-dev-canadacentral-001"].module.network_security_group.azurerm_network_security_rule.this["allowBastionSSH"]
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-runners-dev-canadacentral-001/securityRules/allowBastionSSH"
}
import {
  to = module.network_security_group["nsg-runners-prod-canadacentral-001"].module.network_security_group.azurerm_network_security_group.this
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-runners-prod-canadacentral-001"
}
import {
  to = module.network_security_group["nsg-runners-prod-canadacentral-001"].module.network_security_group.azurerm_network_security_rule.this["AllowOnPrem"]
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-runners-prod-canadacentral-001/securityRules/AllowOnPrem"
}
import {
  to = module.network_security_group["nsg-runners-prod-canadacentral-001"].module.network_security_group.azurerm_network_security_rule.this["DenyAllInbound"]
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-runners-prod-canadacentral-001/securityRules/DenyAllInbound"
}
import {
  to = module.network_security_group["nsg-runners-prod-canadacentral-001"].module.network_security_group.azurerm_network_security_rule.this["AllowBastionHost"]
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-runners-prod-canadacentral-001/securityRules/AllowBastionHost"
}
import {
  to = module.network_security_group["nsg-runners-prod-canadacentral-001"].module.network_security_group.azurerm_network_security_rule.this["AllowBastionSSH"]
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-runners-prod-canadacentral-001/securityRules/AllowBastionSSH"
}
import {
  to = module.network_security_group["nsg-dns-private-endpoint-canadacentral-001"].module.network_security_group.azurerm_network_security_group.this
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-dns-private-endpoint-canadacentral-001"
}
import {
  to = module.network_security_group["nsg-dns-private-endpoint-canadacentral-001"].module.network_security_group.azurerm_network_security_rule.this["AllowOnPrem"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-dns-private-endpoint-canadacentral-001/securityRules/AllowOnPrem"
}
import {
  to = module.network_security_group["nsg-dns-private-endpoint-canadacentral-001"].module.network_security_group.azurerm_network_security_rule.this["DenyAllInbound"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-dns-private-endpoint-canadacentral-001/securityRules/DenyAllInbound"
}
import {
  to = module.network_security_group["nsg-dns-inbound-canadacentral-001"].module.network_security_group.azurerm_network_security_group.this
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-dns-inbound-canadacentral-001"
}
import {
  to = module.network_security_group["nsg-dns-inbound-canadacentral-001"].module.network_security_group.azurerm_network_security_rule.this["AllowOnPrem"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-dns-inbound-canadacentral-001/securityRules/AllowOnPrem"
}
import {
  to = module.network_security_group["nsg-dns-inbound-canadacentral-001"].module.network_security_group.azurerm_network_security_rule.this["DenyAllInbound"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-dns-inbound-canadacentral-001/securityRules/DenyAllInbound"
}
import {
  to = module.network_security_group["nsg-dns-outbound-canadacentral-001"].module.network_security_group.azurerm_network_security_group.this
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-dns-outbound-canadacentral-001"
}
import {
  to = module.network_security_group["nsg-dns-outbound-canadacentral-001"].module.network_security_group.azurerm_network_security_rule.this["AllowOnPrem"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-dns-outbound-canadacentral-001/securityRules/AllowOnPrem"
}
import {
  to = module.network_security_group["nsg-dns-outbound-canadacentral-001"].module.network_security_group.azurerm_network_security_rule.this["DenyAllInbound"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-dns-outbound-canadacentral-001/securityRules/DenyAllInbound"
}
import {
  to = module.network_security_group["nsg-dns-outbound-canadacentral-001"].module.network_security_group.azurerm_network_security_rule.this["AllStorageOutbound"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-dns-outbound-canadacentral-001/securityRules/AllStorageOutbound"
}
import {
  to = module.network_security_group["nsg-dns-outbound-canadacentral-001"].module.network_security_group.azurerm_network_security_rule.this["AllowRunners"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-dns-outbound-canadacentral-001/securityRules/AllowRunners"
}
import {
  to = module.network_security_group["nsg-dns-outbound-canadacentral-001"].module.network_security_group.azurerm_network_security_rule.this["AllowTest"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-dns-outbound-canadacentral-001/securityRules/AllowTest"
}

# Route tables (native)
import {
  to = azurerm_route_table.this["rt-cyberark-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Network/routeTables/rt-cyberark-canadacentral-001"
}
import {
  to = azurerm_route_table.this["rt-transit-fw-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-shared-connectivity-canadacentral-001/providers/Microsoft.Network/routeTables/rt-transit-fw-canadacentral-001"
}

# Private endpoints
import {
  to = module.private_endpoint["pep-la-connectivity-canadacentral-001"].module.private_endpoint.azurerm_private_endpoint.this
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-la-connectivity-canadacentral-001"
}
import {
  to = module.private_endpoint["pep-ehns-alerts-canadacentral-001"].module.private_endpoint.azurerm_private_endpoint.this
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-ehns-alerts-canadacentral-001"
}
import {
  to = module.private_endpoint["pep-azfw-connectivity-canadacentral-001"].module.private_endpoint.azurerm_private_endpoint.this
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-azfw-connectivity-canadacentral-001"
}
import {
  to = module.private_endpoint["pep-stazpkcapture-prod-canadacentral-001"].module.private_endpoint.azurerm_private_endpoint.this
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-stazpkcapture-prod-canadacentral-001"
}
import {
  to = module.private_endpoint["pep-rsv-connectivity-canadacentral-001"].module.private_endpoint.azurerm_private_endpoint.this
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-rsv-connectivity-canadacentral-001"
}
import {
  to = module.private_endpoint["pep-lap-servicenowintegration-canadacentral-001"].module.private_endpoint.azurerm_private_endpoint.this
  id = "${local.sub}/resourceGroups/rg-shared-connectivity-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-lap-servicenowintegration-canadacentral-001"
}

# ExpressRoute circuits + peerings
import {
  to = module.express_route_circuit["erc-quebec-connectivity-caeast-001"].module.express_route_circuit.azurerm_express_route_circuit.this
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/expressRouteCircuits/erc-quebec-connectivity-caeast-001"
}
import {
  to = module.express_route_circuit["erc-quebec-connectivity-caeast-001"].module.express_route_circuit.azurerm_express_route_circuit_peering.this["AzurePrivatePeering"]
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/expressRouteCircuits/erc-quebec-connectivity-caeast-001/peerings/AzurePrivatePeering"
}
import {
  to = module.express_route_circuit["erc-toronto-connectivity-cacentral-001"].module.express_route_circuit.azurerm_express_route_circuit.this
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/expressRouteCircuits/erc-toronto-connectivity-cacentral-001"
}
import {
  to = module.express_route_circuit["erc-toronto-connectivity-cacentral-001"].module.express_route_circuit.azurerm_express_route_circuit_peering.this["AzurePrivatePeering"]
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/expressRouteCircuits/erc-toronto-connectivity-cacentral-001/peerings/AzurePrivatePeering"
}

# Network watchers (native)
import {
  to = azurerm_network_watcher.this["NetworkWatcher_canadacentral_connectivity"]
  id = "${local.sub}/resourceGroups/rg-shared-connectivity-canadacentral-001/providers/Microsoft.Network/networkWatchers/NetworkWatcher_canadacentral_connectivity"
}
import {
  to = azurerm_network_watcher.this["NetworkWatcher_canadaeast_connectivity"]
  id = "${local.sub}/resourceGroups/rg-shared-connectivity-canadaeast-001/providers/Microsoft.Network/networkWatchers/NetworkWatcher_canadaeast_connectivity"
}

# Flow logs (native)
import {
  to = azurerm_network_watcher_flow_log.this["vnet-cyberark-canadacentral-001-rg-cyberark-canadacentra-flowlog"]
  id = "${local.sub}/resourceGroups/rg-shared-connectivity-canadacentral-001/providers/Microsoft.Network/networkWatchers/NetworkWatcher_canadacentral_connectivity/flowLogs/vnet-cyberark-canadacentral-001-rg-cyberark-canadacentra-flowlog"
}
import {
  to = azurerm_network_watcher_flow_log.this["vnet-dns-connectivity-canadacentral-001-rg-dns-connectiv-flowlog"]
  id = "${local.sub}/resourceGroups/rg-shared-connectivity-canadacentral-001/providers/Microsoft.Network/networkWatchers/NetworkWatcher_canadacentral_connectivity/flowLogs/vnet-dns-connectivity-canadacentral-001-rg-dns-connectiv-flowlog"
}
import {
  to = azurerm_network_watcher_flow_log.this["vnet-ertest-canadacentral-001-rg-ertest-canadacentral-00-flowlog"]
  id = "${local.sub}/resourceGroups/rg-shared-connectivity-canadacentral-001/providers/Microsoft.Network/networkWatchers/NetworkWatcher_canadacentral_connectivity/flowLogs/vnet-ertest-canadacentral-001-rg-ertest-canadacentral-00-flowlog"
}
import {
  to = azurerm_network_watcher_flow_log.this["vnet-runners-connectivity-canadacentral-001-rg-runners-c-flowlog"]
  id = "${local.sub}/resourceGroups/rg-shared-connectivity-canadacentral-001/providers/Microsoft.Network/networkWatchers/NetworkWatcher_canadacentral_connectivity/flowLogs/vnet-runners-connectivity-canadacentral-001-rg-runners-c-flowlog"
}
import {
  to = azurerm_network_watcher_flow_log.this["vnet-shared-connectivity-canadacentral-001-rg-shared-con-flowlog"]
  id = "${local.sub}/resourceGroups/rg-shared-connectivity-canadacentral-001/providers/Microsoft.Network/networkWatchers/NetworkWatcher_canadacentral_connectivity/flowLogs/vnet-shared-connectivity-canadacentral-001-rg-shared-con-flowlog"
}
import {
  to = azurerm_network_watcher_flow_log.this["vnet-ertest-canadaeast-001-rg-ertest-canadaeast-001-flowlog"]
  id = "${local.sub}/resourceGroups/rg-shared-connectivity-canadaeast-001/providers/Microsoft.Network/networkWatchers/NetworkWatcher_canadaeast_connectivity/flowLogs/vnet-ertest-canadaeast-001-rg-ertest-canadaeast-001-flowlog"
}

# Azure Traffic Collectors + collector policies (azapi)
import {
  to = azapi_resource.traffic_collector["tc-erc-toronto-connectivity-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.NetworkFunction/azureTrafficCollectors/tc-erc-toronto-connectivity-canadacentral-001"
}
import {
  to = azapi_resource.collector_policy["tc-erc-toronto-connectivity-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.NetworkFunction/azureTrafficCollectors/tc-erc-toronto-connectivity-canadacentral-001/collectorPolicies/cp-1"
}
import {
  to = azapi_resource.traffic_collector["tc-erc-quebec-connectivity-canadaeast-001"]
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadaeast-001/providers/Microsoft.NetworkFunction/azureTrafficCollectors/tc-erc-quebec-connectivity-canadaeast-001"
}
import {
  to = azapi_resource.collector_policy["tc-erc-quebec-connectivity-canadaeast-001"]
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadaeast-001/providers/Microsoft.NetworkFunction/azureTrafficCollectors/tc-erc-quebec-connectivity-canadaeast-001/collectorPolicies/cp-1"
}
