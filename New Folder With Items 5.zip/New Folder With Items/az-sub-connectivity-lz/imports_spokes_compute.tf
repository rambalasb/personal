# imports_spokes_compute.tf — Compute/spokes tier.
# confirm AVM internal import addresses on first plan (VM + NIC addresses inside
# the tf-wrapper-avm-virtual-machine-* modules and the recovery-services-vault module).

# ── Windows VMs (12) ───────────────────────────────────────────────────
import {
  to = module.windows_vm["vm-cyberark-server-canadacentral-001"].module.windows_vm.azurerm_windows_virtual_machine.this
  id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-cyberark-server-canadacentral-001"
}
import {
  to = module.windows_vm["vm-cyberark-server-canadacentral-002"].module.windows_vm.azurerm_windows_virtual_machine.this
  id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-cyberark-server-canadacentral-002"
}
import {
  to = module.windows_vm["vm-cistest-canadacentral001"].module.windows_vm.azurerm_windows_virtual_machine.this
  id = "${local.sub}/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-cistest-canadacentral001"
}
import {
  to = module.windows_vm["vm-ertest-canadacentral-001"].module.windows_vm.azurerm_windows_virtual_machine.this
  id = "${local.sub}/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-ertest-canadacentral-001"
}
import {
  to = module.windows_vm["vm-ertest-canadacentral-002"].module.windows_vm.azurerm_windows_virtual_machine.this
  id = "${local.sub}/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-ertest-canadacentral-002"
}
import {
  to = module.windows_vm["vm-ertest-canadacentral-003"].module.windows_vm.azurerm_windows_virtual_machine.this
  id = "${local.sub}/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-ertest-canadacentral-003"
}
import {
  to = module.windows_vm["vm-ertest-canadacentral-004"].module.windows_vm.azurerm_windows_virtual_machine.this
  id = "${local.sub}/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-ertest-canadacentral-004"
}
import {
  to = module.windows_vm["vm-ertest-canadacentral-005"].module.windows_vm.azurerm_windows_virtual_machine.this
  id = "${local.sub}/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-ertest-canadacentral-005"
}
import {
  to = module.windows_vm["vm-pptest-canadacentral-001"].module.windows_vm.azurerm_windows_virtual_machine.this
  id = "${local.sub}/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-pptest-canadacentral-001"
}
import {
  to = module.windows_vm["vm-ertest-canadaeast-001"].module.windows_vm.azurerm_windows_virtual_machine.this
  id = "${local.sub}/resourceGroups/rg-ertest-canadaeast-001/providers/Microsoft.Compute/virtualMachines/vm-ertest-canadaeast-001"
}
import {
  to = module.windows_vm["vm-runners-dev-canadacentral-001"].module.windows_vm.azurerm_windows_virtual_machine.this
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-runners-dev-canadacentral-001"
}
import {
  to = module.windows_vm["vm-runners-prod-canadacentral-001"].module.windows_vm.azurerm_windows_virtual_machine.this
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-runners-prod-canadacentral-001"
}

# ── Linux VMs (5) ──────────────────────────────────────────────────────
import {
  to = module.linux_vm["vm-cyberark-test-vm01-canadacentral-001"].module.linux_vm.azurerm_linux_virtual_machine.this
  id = "${local.sub}/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-cyberark-test-vm01-canadacentral-001"
}
import {
  to = module.linux_vm["vm-cyberark-test-vm-canadacentral-001"].module.linux_vm.azurerm_linux_virtual_machine.this
  id = "${local.sub}/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-cyberark-test-vm-canadacentral-001"
}
import {
  to = module.linux_vm["vm-testvm-lin-canadacentral001"].module.linux_vm.azurerm_linux_virtual_machine.this
  id = "${local.sub}/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-testvm-lin-canadacentral001"
}
import {
  to = module.linux_vm["vm-runners-lin-dev-canadacentral-001"].module.linux_vm.azurerm_linux_virtual_machine.this
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-runners-lin-dev-canadacentral-001"
}
import {
  to = module.linux_vm["vm-runners-lin-prod-canadacentral-001"].module.linux_vm.azurerm_linux_virtual_machine.this
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-runners-lin-prod-canadacentral-001"
}

# ── Network interfaces (17, module-internal — confirm address on first plan) ──
import {
  to = module.windows_vm["vm-cyberark-server-canadacentral-001"].module.windows_vm.azurerm_network_interface.this["nic-cyberark-server-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Network/networkInterfaces/nic-cyberark-server-canadacentral-001"
}
import {
  to = module.windows_vm["vm-cyberark-server-canadacentral-002"].module.windows_vm.azurerm_network_interface.this["nic-cyberark-server-canadacentral-002"]
  id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Network/networkInterfaces/nic-cyberark-server-canadacentral-002"
}
import {
  to = module.windows_vm["vm-cistest-canadacentral001"].module.windows_vm.azurerm_network_interface.this["vm-cistest-canadacentral001330-z1"]
  id = "${local.sub}/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.Network/networkInterfaces/vm-cistest-canadacentral001330-z1"
}
import {
  to = module.windows_vm["vm-ertest-canadacentral-001"].module.windows_vm.azurerm_network_interface.this["nic-vm-ertest-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.Network/networkInterfaces/nic-vm-ertest-canadacentral-001"
}
import {
  to = module.windows_vm["vm-ertest-canadacentral-002"].module.windows_vm.azurerm_network_interface.this["nic-vm-ertest-canadacentral-002"]
  id = "${local.sub}/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.Network/networkInterfaces/nic-vm-ertest-canadacentral-002"
}
import {
  to = module.windows_vm["vm-ertest-canadacentral-003"].module.windows_vm.azurerm_network_interface.this["vm-ertest-canadacentral-00324-z1"]
  id = "${local.sub}/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.Network/networkInterfaces/vm-ertest-canadacentral-00324-z1"
}
import {
  to = module.windows_vm["vm-ertest-canadacentral-004"].module.windows_vm.azurerm_network_interface.this["vm-ertest-canadacentral-004501-z1"]
  id = "${local.sub}/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.Network/networkInterfaces/vm-ertest-canadacentral-004501-z1"
}
import {
  to = module.windows_vm["vm-ertest-canadacentral-005"].module.windows_vm.azurerm_network_interface.this["vm-ertest-canadacentral-005323-z1"]
  id = "${local.sub}/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.Network/networkInterfaces/vm-ertest-canadacentral-005323-z1"
}
import {
  to = module.windows_vm["vm-pptest-canadacentral-001"].module.windows_vm.azurerm_network_interface.this["vm-pptest-canadacentral-001631-z1"]
  id = "${local.sub}/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.Network/networkInterfaces/vm-pptest-canadacentral-001631-z1"
}
import {
  to = module.windows_vm["vm-ertest-canadaeast-001"].module.windows_vm.azurerm_network_interface.this["nic-vm-ertest-canadaeast-001"]
  id = "${local.sub}/resourceGroups/rg-ertest-canadaeast-001/providers/Microsoft.Network/networkInterfaces/nic-vm-ertest-canadaeast-001"
}
import {
  to = module.windows_vm["vm-runners-dev-canadacentral-001"].module.windows_vm.azurerm_network_interface.this["nic-vm-runners-dev-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/networkInterfaces/nic-vm-runners-dev-canadacentral-001"
}
import {
  to = module.windows_vm["vm-runners-prod-canadacentral-001"].module.windows_vm.azurerm_network_interface.this["nic-vm-runners-prod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/networkInterfaces/nic-vm-runners-prod-canadacentral-001"
}
import {
  to = module.linux_vm["vm-cyberark-test-vm01-canadacentral-001"].module.linux_vm.azurerm_network_interface.this["vm-cyberark-test-vm01-canadacentral-001868-z1"]
  id = "${local.sub}/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.Network/networkInterfaces/vm-cyberark-test-vm01-canadacentral-001868-z1"
}
import {
  to = module.linux_vm["vm-cyberark-test-vm-canadacentral-001"].module.linux_vm.azurerm_network_interface.this["vm-cyberark-test-vm-canadacentral-001608-z1"]
  id = "${local.sub}/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.Network/networkInterfaces/vm-cyberark-test-vm-canadacentral-001608-z1"
}
import {
  to = module.linux_vm["vm-testvm-lin-canadacentral001"].module.linux_vm.azurerm_network_interface.this["vm-testvm-lin-canadacentral001376-z1"]
  id = "${local.sub}/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.Network/networkInterfaces/vm-testvm-lin-canadacentral001376-z1"
}
import {
  to = module.linux_vm["vm-runners-lin-dev-canadacentral-001"].module.linux_vm.azurerm_network_interface.this["nic-vm-runners-lin-dev-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/networkInterfaces/nic-vm-runners-lin-dev-canadacentral-001"
}
import {
  to = module.linux_vm["vm-runners-lin-prod-canadacentral-001"].module.linux_vm.azurerm_network_interface.this["nic-vm-runners-lin-prod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/networkInterfaces/nic-vm-runners-lin-prod-canadacentral-001"
}

# ── SSH public keys (3) ────────────────────────────────────────────────
import {
  to = azurerm_ssh_public_key.this["vm-cyberark-test-vm01-canadacentral-001-key"]
  id = "${local.sub}/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.Compute/sshPublicKeys/vm-cyberark-test-vm01-canadacentral-001-key"
}
import {
  to = azurerm_ssh_public_key.this["vm-cyberark-test-vm-canadacentral-001-key"]
  id = "${local.sub}/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.Compute/sshPublicKeys/vm-cyberark-test-vm-canadacentral-001-key"
}
import {
  to = azurerm_ssh_public_key.this["sshkey-hosted-runners-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Compute/sshPublicKeys/sshkey-hosted-runners-canadacentral-001"
}

# ── Bastion hosts (4) ──────────────────────────────────────────────────
import {
  to = azurerm_bastion_host.this["bh-cyberark-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Network/bastionHosts/bh-cyberark-canadacentral-001"
}
import {
  to = azurerm_bastion_host.this["bh-ertest-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.Network/bastionHosts/bh-ertest-canadacentral-001"
}
import {
  to = azurerm_bastion_host.this["bh-ertest-canadaeast-001"]
  id = "${local.sub}/resourceGroups/rg-ertest-canadaeast-001/providers/Microsoft.Network/bastionHosts/bh-ertest-canadaeast-001"
}
import {
  to = azurerm_bastion_host.this["bh-connectivity-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/bastionHosts/bh-connectivity-canadacentral-001"
}

# ── Internal load balancer + backend pool + probes + rules ─────────────
import {
  to = azurerm_lb.cyberark
  id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Network/loadBalancers/lb-internal-cyberark-canadacentral-001"
}
import {
  to = azurerm_lb_backend_address_pool.cyberark
  id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Network/loadBalancers/lb-internal-cyberark-canadacentral-001/backendAddressPools/bkp-lb-internal-cyberark-canadacentral-001"
}
import {
  to = azurerm_lb_probe.cyberark["psm-health-probe"]
  id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Network/loadBalancers/lb-internal-cyberark-canadacentral-001/probes/psm-health-probe"
}
import {
  to = azurerm_lb_probe.cyberark["rds-health-probe"]
  id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Network/loadBalancers/lb-internal-cyberark-canadacentral-001/probes/rds-health-probe"
}
import {
  to = azurerm_lb_rule.cyberark["rds-inbound-lb-rule"]
  id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Network/loadBalancers/lb-internal-cyberark-canadacentral-001/loadBalancingRules/rds-inbound-lb-rule"
}
import {
  to = azurerm_lb_rule.cyberark["psm-inbound-lb-rule"]
  id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Network/loadBalancers/lb-internal-cyberark-canadacentral-001/loadBalancingRules/psm-inbound-lb-rule"
}

# ── Maintenance configurations (7) ─────────────────────────────────────
import {
  to = azurerm_maintenance_configuration.this["mc-cyberark-server-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Maintenance/maintenanceConfigurations/mc-cyberark-server-canadacentral-001"
}
import {
  to = azurerm_maintenance_configuration.this["mc-cyberark-server-canadacentral-002"]
  id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Maintenance/maintenanceConfigurations/mc-cyberark-server-canadacentral-002"
}
import {
  to = azurerm_maintenance_configuration.this["mc-cyberark-server-canadacentral-01"]
  id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Maintenance/maintenanceConfigurations/mc-cyberark-server-canadacentral-01"
}
import {
  to = azurerm_maintenance_configuration.this["vm-ertest-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.Maintenance/maintenanceConfigurations/vm-ertest-canadacentral-001"
}
import {
  to = azurerm_maintenance_configuration.this["vm-ertest-canadaeast-001"]
  id = "${local.sub}/resourceGroups/rg-ertest-canadaeast-001/providers/Microsoft.Maintenance/maintenanceConfigurations/vm-ertest-canadaeast-001"
}
import {
  to = azurerm_maintenance_configuration.this["mc-runners-dev-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Maintenance/maintenanceConfigurations/mc-runners-dev-canadacentral-001"
}
import {
  to = azurerm_maintenance_configuration.this["mc-runners-prod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Maintenance/maintenanceConfigurations/mc-runners-prod-canadacentral-001"
}

# ── Recovery Services vault (azapi, via wrapper) ───────────────────────
import {
  to = module.recovery_services_vault["connectivity"].module.recovery_services_vault.azapi_resource.this
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.RecoveryServices/vaults/rsv-connectivity-canadacentral-001"
}

# ── Backup policies (3, Azure-created defaults) ────────────────────────
import {
  to = azurerm_backup_policy_vm.default
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.RecoveryServices/vaults/rsv-connectivity-canadacentral-001/backupPolicies/DefaultPolicy"
}
import {
  to = azurerm_backup_policy_vm.enhanced
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.RecoveryServices/vaults/rsv-connectivity-canadacentral-001/backupPolicies/EnhancedPolicy"
}
import {
  to = azurerm_backup_policy_vm_workload.hourly_log
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.RecoveryServices/vaults/rsv-connectivity-canadacentral-001/backupPolicies/HourlyLogBackup"
}
