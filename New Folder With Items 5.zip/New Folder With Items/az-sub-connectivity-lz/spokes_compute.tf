# spokes_compute.tf
# Compute/spokes tier: rg-cyberark, rg-ertest (cc + ce), rg-runners.
#   17 VMs (12 Windows via tf-wrapper-avm-virtual-machine-windows,
#           5 Linux via tf-wrapper-avm-virtual-machine-linux)
#   17 NICs modeled inside each VM module's network_interfaces input
#   4 bastion hosts, 1 internal load balancer (+ backend pool, probes, rules)
#   3 SSH public keys, 7 maintenance configurations
#   1 recovery services vault (wrapper) + 3 default backup policies (native)
#
# EXCLUDED (Azure / backup-managed — not adopted here):
#   Microsoft.Compute/restorePointCollections
#   Microsoft.Compute/snapshots
#     - vm-cyberark-test-vm01-canadacentral-001-OS--snapshot-24thJune2026
#     - vm-cyberark-test-vm-canadacentral-001-OsDisk-1-snapshot-24thJune-2026
#   microsoft.devtestlab/schedules
#     - shutdown-computevm-vm-pptest-canadacentral-001
#
# TODO confirm AVM wrapper published versions (guessed below).
# TODO the Compute/disks (osdisk-*, disk-1-*, disk-2-*) referenced by the VMs
#      belong to a disks tier; existing-disk attachments below use best-guess ids.

variable "spokes_vm_admin_password" {
  type        = string
  description = "Placeholder admin password for the Windows spoke VMs. TODO source from Key Vault; do not commit a real secret."
  sensitive   = true
  default     = "REPLACE_ME_PLACEHOLDER" # TODO replace via TF_VAR_spokes_vm_admin_password / Key Vault
}

# TODO: admin_password rotation cannot be ignored from here (no lifecycle block on
# a module). The underlying azurerm_windows_virtual_machine.admin_password should
# carry ignore_changes inside the AVM module; confirm on first plan.

locals {
  # Subnet resource ids (vnets/subnets are co-located in each spoke RG,
  # built by the networking tiers — referenced by id here).
  spokes_snet_cyberark     = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cyberark-canadacentral-001/subnets/snet-cyberark-servers-canadacentral-001"
  spokes_snet_ertest_cc    = "${local.sub}/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-ertest-canadacentral-001/subnets/snet-ertest-canadacentral-001"
  spokes_snet_ertest_ce    = "${local.sub}/resourceGroups/rg-ertest-canadaeast-001/providers/Microsoft.Network/virtualNetworks/vnet-ertest-canadaeast-001/subnets/snet-ertest-canadaeast-001"
  spokes_snet_runners_dev  = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-runners-connectivity-canadacentral-001/subnets/snet-runners-dev-canadacentral-001"
  spokes_snet_runners_prod = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-runners-connectivity-canadacentral-001/subnets/snet-runners-prod-canadacentral-001"

  spokes_lb_bkp_cyberark = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Network/loadBalancers/lb-internal-cyberark-canadacentral-001/backendAddressPools/bkp-lb-internal-cyberark-canadacentral-001"

  # SSH public keys (also fed to the Linux VMs that use them).
  spokes_ssh_public_keys = {
    "vm-cyberark-test-vm01-canadacentral-001-key" = {
      rg_key     = "ertest_cc"
      location   = "canadacentral"
      public_key = "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQDna/wYBQ7tnEdNRM9NU070c3pTfO4d3aTJpzyZVw+m2puA7cM99ECJ0UjncIoJVxiSo/1uYrVVAsukmTbemJ08qtZXmSX6q5mcX0oQrdoRYUBdUegCBf9XpzP3Y1SQI5LLavYXUcOtp0+HuLDA1FbLSo8ckb/sFU9mFBd4qWc6Uhd7qlbR6xOEh0IdGWK8W/gpvnyYORMQd7CWQvLMQUW53QemmEkpPhd/cHlXOlOUiDTub/ukkajtN/+VqNAOUkxdRb1DioT3+2Xq1Gad6EZq0iQlFsX9w9fJl257xDYaGcT6HgkoczJkpWRLI+rRY20LJsxBOn0S3kRNcEM58PBydQ4ZSLukc6oj0t8FPLTwaT1DqXiONz7UQ+NJA/PA/+QlFvgH6LiQFYqnu1mvvgTVboLYh4sJjCgmHN4rz5aCIheYxw4MGg+K84GuvRgENBiAAzADn2uuI6gqe2IFFtdn9jiXf9GsGwxeADKI5tjzUv+kYBB7hmoRS/AjG1eMpGk= generated-by-azure"
    }
    "vm-cyberark-test-vm-canadacentral-001-key" = {
      rg_key     = "ertest_cc"
      location   = "canadacentral"
      public_key = "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQDRIXAYWVjU3fNtFyibDjrMrKSC20lzIBjACbXsB4aYwgYideXLuPtRV0Tn0we1wgCMcld47FTWyZ5yBsvp7UUwG3VHz7xevHSugpwwijfmta2zUYF4afhPkqhBEZmJNG7E7HtwWaasbqIjTqF1+rkCd34xw1SunP8Nl+c2eM6uLngHu9NZVfW9QsAXHUBzz1zTYznjURL0RfH2ZjiB8kTGlYvkKcSP1Ih64XjYZs036RaewXhV6PYYEYMDqObQQvoNNeRQXtn2GZS7PBL/cZ57QdKvK1+UOUNwyQLWZLTEJdoDWv9IK5TZYgEa4JgDf7WtvcTlrbI9GKIL34RL/aAgwH5txWp80ENAl6OxwAfw11u2oDHp+UElchFWSopMCir1FNklEL4ucTNZEKOV92qj+dEgT+n4DDETRuwrnYRhvsALKs/La8BmQ/t/Vr1FC/3YoU4njywg32ppSN10UAWO1uRxn6RUJgtzyrEa/4WISrPZ2eNvKXg/C2Y1tUolzVU= generated-by-azure"
    }
    "sshkey-hosted-runners-canadacentral-001" = {
      rg_key     = "runners"
      location   = "canadacentral"
      public_key = "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQDm75LKdXh4xRUoKIIt8s8bqsLHCvutOZDyXLZbYNFlg69tVxc7w0iNGBSaKaFKGrqejcihOljctwJrIgIZzQBAyVMS+UB1PH0U2NAwyhguymmt7iX7jljKvARJtXCuNq4IvDiHLh4P8qNQTDFuwU1BaRStJYq+X2b9g0CsC+i9jL6AIrqJUOXo34x6T59vTV7lV4WWYth96PPrwM0jkJ0Wum9sqtnemm+zOIVtTwZeWntkXu/8UsLGpLHGFjBuRGtrVRkmAiAeDZgW/aJj6s2iUvxB+4VejkKorurn1fFxU+aGi72geHFQPqmOGcPnB0P4zM93dHzvLU5i0FtPXZoQUnz5yOxq7jiC5eUYNSbq2W+d1JPM3AdFrmw8SAgcDhXeLbCbp+44D5d5gX8V0avnlD4vlTfo7BbLxaSEZKkZ+4vT3DnvH8+yQVz8nrTccEfTDP2OjwMXSt8vlYT7CANOhv41cXtQN8jQqtnefQfKpZKuhJ13UOH9DQnUU2O/E3k= generated-by-azure"
    }
  }

  # ---- Windows VMs (12) ----
  spokes_windows_vms = {
    "vm-cyberark-server-canadacentral-001" = {
      rg_key                   = "cyberark"
      location                 = "canadacentral"
      zone                     = "1"
      sku_size                 = "Standard_F32s_v2"
      os_disk_type             = "Premium_ZRS"
      os_disk_size             = 127
      image                    = { publisher = "MicrosoftWindowsServer", offer = "WindowsServer", sku = "2022-datacenter-g2", version = "latest" }
      computer_name            = "cyberarkvm001"
      admin_username           = "azcyberarkmid"
      license_type             = "Windows_Server"
      enable_automatic_updates = false
      patch_assessment_mode    = "AutomaticByPlatform"
      bypass_user_schedule     = true
      nic_name                 = "nic-cyberark-server-canadacentral-001"
      nic_accel                = true
      ic_name                  = "internal"
      subnet_id                = local.spokes_snet_cyberark
      private_ip_allocation    = "Dynamic"
      private_ip_address       = null
      lb_backend_pool_id       = local.spokes_lb_bkp_cyberark
      data_disks = {
        "disk-1-vm-cyberark-server-canadacentral-001" = { lun = 0, id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Compute/disks/disk-1-vm-cyberark-server-canadacentral-001" }
        "disk-2-vm-cyberark-server-canadacentral-001" = { lun = 1, id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Compute/disks/disk-2-vm-cyberark-server-canadacentral-001" }
      }
    }
    "vm-cyberark-server-canadacentral-002" = {
      rg_key                   = "cyberark"
      location                 = "canadacentral"
      zone                     = "1"
      sku_size                 = "Standard_F32s_v2"
      os_disk_type             = "Premium_ZRS"
      os_disk_size             = 127
      image                    = { publisher = "MicrosoftWindowsServer", offer = "WindowsServer", sku = "2022-datacenter-g2", version = "latest" }
      computer_name            = "cyberarkvm002"
      admin_username           = "azcyberarkmid"
      license_type             = "Windows_Server"
      enable_automatic_updates = false
      patch_assessment_mode    = "AutomaticByPlatform"
      bypass_user_schedule     = true
      nic_name                 = "nic-cyberark-server-canadacentral-002"
      nic_accel                = true
      ic_name                  = "internal"
      subnet_id                = local.spokes_snet_cyberark
      private_ip_allocation    = "Dynamic"
      private_ip_address       = null
      lb_backend_pool_id       = local.spokes_lb_bkp_cyberark
      data_disks = {
        "disk-1-vm-cyberark-server-canadacentral-002" = { lun = 0, id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Compute/disks/disk-1-vm-cyberark-server-canadacentral-002" }
        "disk-2-vm-cyberark-server-canadacentral-002" = { lun = 1, id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Compute/disks/disk-2-vm-cyberark-server-canadacentral-002" }
      }
    }
    "vm-cistest-canadacentral001" = {
      rg_key                   = "ertest_cc"
      location                 = "canadacentral"
      zone                     = "1"
      sku_size                 = "Standard_B4ms"
      os_disk_type             = "Premium_LRS"
      os_disk_size             = null
      image                    = { publisher = "MicrosoftWindowsServer", offer = "WindowsServer", sku = "2025-datacenter-g2", version = "latest" }
      computer_name            = "vm-cistest-cana"
      admin_username           = "bchadmin"
      license_type             = "Windows_Server"
      enable_automatic_updates = true
      patch_assessment_mode    = "ImageDefault"
      bypass_user_schedule     = false
      nic_name                 = "vm-cistest-canadacentral001330-z1"
      nic_accel                = false
      ic_name                  = "ipconfig1"
      subnet_id                = local.spokes_snet_ertest_cc
      private_ip_allocation    = "Dynamic"
      private_ip_address       = null
      lb_backend_pool_id       = null
      data_disks               = {}
    }
    "vm-ertest-canadacentral-001" = {
      rg_key                   = "ertest_cc"
      location                 = "canadacentral"
      zone                     = "1"
      sku_size                 = "Standard_B4ms"
      os_disk_type             = "Premium_LRS"
      os_disk_size             = null
      image                    = { publisher = "MicrosoftWindowsServer", offer = "WindowsServer", sku = "2022-datacenter-g2", version = "latest" }
      computer_name            = "ertest001"
      admin_username           = "ervmuser"
      license_type             = "Windows_Server"
      enable_automatic_updates = true
      patch_assessment_mode    = "ImageDefault"
      bypass_user_schedule     = false
      nic_name                 = "nic-vm-ertest-canadacentral-001"
      nic_accel                = false
      ic_name                  = "internal"
      subnet_id                = local.spokes_snet_ertest_cc
      private_ip_allocation    = "Static"
      private_ip_address       = "10.195.118.7"
      lb_backend_pool_id       = null
      data_disks               = {}
    }
    "vm-ertest-canadacentral-002" = {
      rg_key                   = "ertest_cc"
      location                 = "canadacentral"
      zone                     = "1"
      sku_size                 = "Standard_B4ms"
      os_disk_type             = "Premium_LRS"
      os_disk_size             = null
      image                    = { publisher = "MicrosoftWindowsServer", offer = "WindowsServer", sku = "2022-datacenter-g2", version = "latest" }
      computer_name            = "ertest002"
      admin_username           = "ervmuser"
      license_type             = "Windows_Server"
      enable_automatic_updates = true
      patch_assessment_mode    = "ImageDefault"
      bypass_user_schedule     = false
      nic_name                 = "nic-vm-ertest-canadacentral-002"
      nic_accel                = false
      ic_name                  = "internal"
      subnet_id                = local.spokes_snet_ertest_cc
      private_ip_allocation    = "Static"
      private_ip_address       = "10.195.118.8"
      lb_backend_pool_id       = null
      data_disks               = {}
    }
    "vm-ertest-canadacentral-003" = {
      rg_key                   = "ertest_cc"
      location                 = "canadacentral"
      zone                     = "1"
      sku_size                 = "Standard_B4ms"
      os_disk_type             = "Premium_LRS"
      os_disk_size             = null
      image                    = { publisher = "microsoftwindowsserver", offer = "windowsserver2022", sku = "2022-datacenter-g2", version = "latest" }
      computer_name            = "vm-ertest-canad"
      admin_username           = "bchydroertestuser"
      license_type             = "Windows_Server"
      enable_automatic_updates = true
      patch_assessment_mode    = "ImageDefault"
      bypass_user_schedule     = false
      nic_name                 = "vm-ertest-canadacentral-00324-z1"
      nic_accel                = false
      ic_name                  = "ipconfig1"
      subnet_id                = local.spokes_snet_ertest_cc
      private_ip_allocation    = "Dynamic"
      private_ip_address       = null
      lb_backend_pool_id       = null
      data_disks               = {}
    }
    "vm-ertest-canadacentral-004" = {
      rg_key                   = "ertest_cc"
      location                 = "canadacentral"
      zone                     = "1"
      sku_size                 = "Standard_B4ms"
      os_disk_type             = "Premium_LRS"
      os_disk_size             = null
      image                    = { publisher = "microsoftwindowsserver", offer = "windowsserver2022", sku = "2022-datacenter-g2", version = "latest" }
      computer_name            = "vm-ertest-canad"
      admin_username           = "bchydroertestuser2"
      license_type             = "Windows_Server"
      enable_automatic_updates = true
      patch_assessment_mode    = "ImageDefault"
      bypass_user_schedule     = false
      nic_name                 = "vm-ertest-canadacentral-004501-z1"
      nic_accel                = false
      ic_name                  = "ipconfig1"
      subnet_id                = local.spokes_snet_ertest_cc
      private_ip_allocation    = "Dynamic"
      private_ip_address       = null
      lb_backend_pool_id       = null
      data_disks               = {}
    }
    "vm-ertest-canadacentral-005" = {
      rg_key                   = "ertest_cc"
      location                 = "canadacentral"
      zone                     = "1"
      sku_size                 = "Standard_B4ms"
      os_disk_type             = "Premium_LRS"
      os_disk_size             = null
      image                    = { publisher = "microsoftwindowsserver", offer = "windowsserver2022", sku = "2022-datacenter-g2", version = "latest" }
      computer_name            = "vm-ertest-canad"
      admin_username           = "bchydroertestuser3"
      license_type             = "Windows_Server"
      enable_automatic_updates = true
      patch_assessment_mode    = "ImageDefault"
      bypass_user_schedule     = false
      nic_name                 = "vm-ertest-canadacentral-005323-z1"
      nic_accel                = false
      ic_name                  = "ipconfig1"
      subnet_id                = local.spokes_snet_ertest_cc
      private_ip_allocation    = "Dynamic"
      private_ip_address       = null
      lb_backend_pool_id       = null
      data_disks               = {}
    }
    "vm-pptest-canadacentral-001" = {
      rg_key                   = "ertest_cc"
      location                 = "canadacentral"
      zone                     = "1"
      sku_size                 = "Standard_B4ms"
      os_disk_type             = "Premium_LRS" # TODO storageAccountType absent in source; confirm
      os_disk_size             = null
      image                    = { publisher = "MicrosoftWindowsServer", offer = "WindowsServer", sku = "2025-datacenter-g2", version = "latest" }
      computer_name            = "vm-pptest-canad"
      admin_username           = "bchadmin"
      license_type             = "Windows_Server"
      enable_automatic_updates = true
      patch_assessment_mode    = "ImageDefault"
      bypass_user_schedule     = false
      nic_name                 = "vm-pptest-canadacentral-001631-z1"
      nic_accel                = false
      ic_name                  = "ipconfig1"
      subnet_id                = local.spokes_snet_ertest_cc
      private_ip_allocation    = "Dynamic"
      private_ip_address       = null
      lb_backend_pool_id       = null
      data_disks               = {}
    }
    "vm-ertest-canadaeast-001" = {
      rg_key                   = "ertest_ce"
      location                 = "canadaeast"
      zone                     = null
      sku_size                 = "Standard_D4ds_v6"
      os_disk_type             = "Premium_LRS"
      os_disk_size             = null
      image                    = { publisher = "MicrosoftWindowsServer", offer = "WindowsServer", sku = "2022-datacenter-g2", version = "latest" }
      computer_name            = "ertest003"
      admin_username           = "ervmuser"
      license_type             = "Windows_Server"
      enable_automatic_updates = true
      patch_assessment_mode    = "ImageDefault"
      bypass_user_schedule     = false
      nic_name                 = "nic-vm-ertest-canadaeast-001"
      nic_accel                = false
      ic_name                  = "internal"
      subnet_id                = local.spokes_snet_ertest_ce
      private_ip_allocation    = "Static"
      private_ip_address       = "10.196.114.7"
      lb_backend_pool_id       = null
      data_disks               = {}
    }
    "vm-runners-dev-canadacentral-001" = {
      rg_key                   = "runners"
      location                 = "canadacentral"
      zone                     = "1"
      sku_size                 = "Standard_B4ms"
      os_disk_type             = "Premium_ZRS"
      os_disk_size             = null
      image                    = { publisher = "MicrosoftWindowsServer", offer = "WindowsServer", sku = "2022-datacenter-g2", version = "latest" }
      computer_name            = "azdevrunner"
      admin_username           = "azurerunner"
      license_type             = "Windows_Server"
      enable_automatic_updates = true
      patch_assessment_mode    = "ImageDefault"
      bypass_user_schedule     = false
      nic_name                 = "nic-vm-runners-dev-canadacentral-001"
      nic_accel                = false
      ic_name                  = "internal"
      subnet_id                = local.spokes_snet_runners_dev
      private_ip_allocation    = "Static"
      private_ip_address       = "10.195.114.7"
      lb_backend_pool_id       = null
      data_disks               = {}
    }
    "vm-runners-prod-canadacentral-001" = {
      rg_key                   = "runners"
      location                 = "canadacentral"
      zone                     = "1"
      sku_size                 = "Standard_B4ms"
      os_disk_type             = "Premium_ZRS"
      os_disk_size             = null
      image                    = { publisher = "MicrosoftWindowsServer", offer = "WindowsServer", sku = "2022-datacenter-g2", version = "latest" }
      computer_name            = "azprodrunner"
      admin_username           = "azurerunner"
      license_type             = "Windows_Server"
      enable_automatic_updates = true
      patch_assessment_mode    = "ImageDefault"
      bypass_user_schedule     = false
      nic_name                 = "nic-vm-runners-prod-canadacentral-001"
      nic_accel                = false
      ic_name                  = "internal"
      subnet_id                = local.spokes_snet_runners_prod
      private_ip_allocation    = "Static"
      private_ip_address       = "10.195.115.7"
      lb_backend_pool_id       = null
      data_disks               = {}
    }
  }

  # ---- Linux VMs (5) ----
  spokes_linux_vms = {
    "vm-cyberark-test-vm01-canadacentral-001" = {
      rg_key                = "ertest_cc"
      location              = "canadacentral"
      zone                  = "1"
      sku_size              = "Standard_B4as_v2"
      os_disk_type          = "StandardSSD_LRS"
      os_disk_size          = null
      image                 = { publisher = "RedHat", offer = "RHEL", sku = "8_10", version = "latest" }
      admin_username        = "azureuser"
      ssh_keys              = [local.spokes_ssh_public_keys["vm-cyberark-test-vm01-canadacentral-001-key"].public_key]
      nic_name              = "vm-cyberark-test-vm01-canadacentral-001868-z1"
      nic_accel             = true
      ic_name               = "ipconfig1"
      subnet_id             = local.spokes_snet_cyberark # cross-RG: cyberark vnet
      private_ip_allocation = "Dynamic"
      private_ip_address    = null
    }
    "vm-cyberark-test-vm-canadacentral-001" = {
      rg_key                = "ertest_cc"
      location              = "canadacentral"
      zone                  = "1"
      sku_size              = "Standard_B4as_v2"
      os_disk_type          = "StandardSSD_LRS"
      os_disk_size          = null
      image                 = { publisher = "RedHat", offer = "RHEL", sku = "8_10", version = "latest" }
      admin_username        = "azureuser"
      ssh_keys              = [local.spokes_ssh_public_keys["vm-cyberark-test-vm-canadacentral-001-key"].public_key]
      nic_name              = "vm-cyberark-test-vm-canadacentral-001608-z1"
      nic_accel             = true
      ic_name               = "ipconfig1"
      subnet_id             = local.spokes_snet_cyberark # cross-RG: cyberark vnet
      private_ip_allocation = "Dynamic"
      private_ip_address    = null
    }
    "vm-testvm-lin-canadacentral001" = {
      rg_key                = "ertest_cc"
      location              = "canadacentral"
      zone                  = "1"
      sku_size              = "Standard_D4s_v3"
      os_disk_type          = "Premium_LRS"
      os_disk_size          = null
      image                 = { publisher = "RedHat", offer = "RHEL", sku = "94_gen2", version = "latest" }
      admin_username        = "bchadmin"
      ssh_keys              = [] # TODO no sshPublicKeys resource found for this VM; key auto-generated
      nic_name              = "vm-testvm-lin-canadacentral001376-z1"
      nic_accel             = true
      ic_name               = "ipconfig1"
      subnet_id             = local.spokes_snet_ertest_cc
      private_ip_allocation = "Dynamic"
      private_ip_address    = null
    }
    "vm-runners-lin-dev-canadacentral-001" = {
      rg_key                = "runners"
      location              = "canadacentral"
      zone                  = "1"
      sku_size              = "Standard_B4ms"
      os_disk_type          = "Premium_ZRS"
      os_disk_size          = null
      image                 = { publisher = "RedHat", offer = "RHEL", sku = "8_10", version = "latest" }
      admin_username        = "azurerunner"
      ssh_keys              = [local.spokes_ssh_public_keys["sshkey-hosted-runners-canadacentral-001"].public_key]
      nic_name              = "nic-vm-runners-lin-dev-canadacentral-001"
      nic_accel             = false
      ic_name               = "internal"
      subnet_id             = local.spokes_snet_runners_dev
      private_ip_allocation = "Static"
      private_ip_address    = "10.195.114.9"
    }
    "vm-runners-lin-prod-canadacentral-001" = {
      rg_key                = "runners"
      location              = "canadacentral"
      zone                  = "1"
      sku_size              = "Standard_B4ms"
      os_disk_type          = "Premium_ZRS"
      os_disk_size          = null
      image                 = { publisher = "RedHat", offer = "RHEL", sku = "8_10", version = "latest" }
      admin_username        = "azurerunner"
      ssh_keys              = [local.spokes_ssh_public_keys["sshkey-hosted-runners-canadacentral-001"].public_key]
      nic_name              = "nic-vm-runners-lin-prod-canadacentral-001"
      nic_accel             = false
      ic_name               = "internal"
      subnet_id             = local.spokes_snet_runners_prod
      private_ip_allocation = "Static"
      private_ip_address    = "10.195.115.9"
    }
  }

  # ---- Bastion hosts (4, Developer SKU — vnet-based, no subnet/public IP) ----
  spokes_bastion_hosts = {
    "bh-cyberark-canadacentral-001" = {
      rg_key             = "cyberark"
      location           = "canadacentral"
      virtual_network_id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cyberark-canadacentral-001"
    }
    "bh-ertest-canadacentral-001" = {
      rg_key             = "ertest_cc"
      location           = "canadacentral"
      virtual_network_id = "${local.sub}/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-ertest-canadacentral-001"
    }
    "bh-ertest-canadaeast-001" = {
      rg_key             = "ertest_ce"
      location           = "canadaeast"
      virtual_network_id = "${local.sub}/resourceGroups/rg-ertest-canadaeast-001/providers/Microsoft.Network/virtualNetworks/vnet-ertest-canadaeast-001"
    }
    "bh-connectivity-canadacentral-001" = {
      rg_key             = "runners"
      location           = "canadacentral"
      virtual_network_id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-runners-connectivity-canadacentral-001"
    }
  }

  # ---- Maintenance configurations (7) ----
  spokes_maintenance_configurations = {
    "mc-cyberark-server-canadacentral-001" = {
      rg_key                  = "cyberark"
      location                = "canadaeast" # per source
      start_date_time         = "2026-03-14 20:00"
      duration                = "03:55"
      recur_every             = "1Month Second Saturday"
      windows_classifications = ["Critical", "Security"]
    }
    "mc-cyberark-server-canadacentral-002" = {
      rg_key                  = "cyberark"
      location                = "canadacentral"
      start_date_time         = "2026-03-21 22:00"
      duration                = "03:00"
      recur_every             = "1Month Third Saturday"
      windows_classifications = ["Critical", "Security"]
    }
    "mc-cyberark-server-canadacentral-01" = {
      rg_key                  = "cyberark"
      location                = "canadacentral"
      start_date_time         = "2026-03-14 20:00"
      duration                = "03:55"
      recur_every             = "1Month Second Saturday"
      windows_classifications = ["Critical", "Security"]
    }
    "vm-ertest-canadacentral-001" = {
      rg_key                  = "ertest_cc"
      location                = "canadacentral"
      start_date_time         = "2026-03-14 05:00"
      duration                = "03:00"
      recur_every             = "1Month Second Saturday"
      windows_classifications = ["Critical", "Security"]
    }
    "vm-ertest-canadaeast-001" = {
      rg_key                  = "ertest_ce"
      location                = "canadaeast"
      start_date_time         = "2026-03-14 05:00"
      duration                = "03:00"
      recur_every             = "1Month Second Saturday"
      windows_classifications = ["Critical", "Security", "UpdateRollup"]
    }
    "mc-runners-dev-canadacentral-001" = {
      rg_key                  = "runners"
      location                = "canadacentral"
      start_date_time         = "2026-03-14 20:00"
      duration                = "03:55"
      recur_every             = "1Month Second Saturday"
      windows_classifications = ["Critical", "Security"]
    }
    "mc-runners-prod-canadacentral-001" = {
      rg_key                  = "runners"
      location                = "canadacentral"
      start_date_time         = "2026-03-21 20:00"
      duration                = "03:55"
      recur_every             = "1Month Third Saturday"
      windows_classifications = ["Critical", "Security"]
    }
  }

  # ---- Load balancer probes / rules (internal cyberark LB) ----
  spokes_lb_probes = {
    "psm-health-probe" = { protocol = "Https", port = 443, request_path = "/psm/api/health", interval = 30, num_probes = 1 }
    "rds-health-probe" = { protocol = "Tcp", port = 3389, request_path = null, interval = 30, num_probes = 1 }
  }
  spokes_lb_rules = {
    "rds-inbound-lb-rule" = { frontend_port = 3389, backend_port = 3389, probe = "rds-health-probe" }
    "psm-inbound-lb-rule" = { frontend_port = 443, backend_port = 443, probe = "psm-health-probe" }
  }
}

# =====================================================================
# Virtual machines
# =====================================================================

module "windows_vm" {
  for_each = local.spokes_windows_vms

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-virtual-machine-windows/azurerm"
  version = "0.1.0" # TODO confirm version

  name                = each.key
  resource_group_name = module.resource_group[each.value.rg_key].name
  location            = each.value.location
  zone                = each.value.zone
  computer_name       = each.value.computer_name
  sku_size            = each.value.sku_size

  source_image_reference = each.value.image

  os_disk = {
    caching              = "ReadWrite"
    storage_account_type = each.value.os_disk_type
    disk_size_gb         = each.value.os_disk_size
  }

  account_credentials = {
    admin_credentials = {
      username                           = each.value.admin_username
      password                           = var.spokes_vm_admin_password # TODO source from Key Vault
      generate_admin_password_or_ssh_key = false
    }
  }

  network_interfaces = {
    (each.value.nic_name) = {
      name                           = each.value.nic_name
      accelerated_networking_enabled = each.value.nic_accel
      ip_configurations = {
        (each.value.ic_name) = {
          name                          = each.value.ic_name
          private_ip_subnet_resource_id = each.value.subnet_id
          private_ip_address_allocation = each.value.private_ip_allocation
          private_ip_address            = each.value.private_ip_address
          is_primary_ipconfiguration    = true
          create_public_ip_address      = false
          load_balancer_backend_pools = each.value.lb_backend_pool_id == null ? {} : {
            "lb" = { load_balancer_backend_pool_resource_id = each.value.lb_backend_pool_id }
          }
        }
      }
    }
  }

  data_disk_existing_disks = {
    for k, d in each.value.data_disks : k => {
      caching                  = "None"
      managed_disk_resource_id = d.id
      lun                      = d.lun
    }
  }

  managed_identities = { system_assigned = true }

  license_type                                           = each.value.license_type
  enable_automatic_updates                               = each.value.enable_automatic_updates
  patch_assessment_mode                                  = each.value.patch_assessment_mode
  bypass_platform_safety_checks_on_user_schedule_enabled = each.value.bypass_user_schedule

  tags = local.common_tags
}

module "linux_vm" {
  for_each = local.spokes_linux_vms

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-virtual-machine-linux/azurerm"
  version = "0.1.0" # TODO confirm version

  name                = each.key
  resource_group_name = module.resource_group[each.value.rg_key].name
  location            = each.value.location
  zone                = each.value.zone
  sku_size            = each.value.sku_size

  source_image_reference = each.value.image

  os_disk = {
    caching              = "ReadWrite"
    storage_account_type = each.value.os_disk_type
    disk_size_gb         = each.value.os_disk_size
  }

  account_credentials = {
    admin_credentials = {
      username                           = each.value.admin_username
      ssh_keys                           = each.value.ssh_keys
      generate_admin_password_or_ssh_key = length(each.value.ssh_keys) == 0
    }
  }

  network_interfaces = {
    (each.value.nic_name) = {
      name                           = each.value.nic_name
      accelerated_networking_enabled = each.value.nic_accel
      ip_configurations = {
        (each.value.ic_name) = {
          name                          = each.value.ic_name
          private_ip_subnet_resource_id = each.value.subnet_id
          private_ip_address_allocation = each.value.private_ip_allocation
          private_ip_address            = each.value.private_ip_address
          is_primary_ipconfiguration    = true
          create_public_ip_address      = false
        }
      }
    }
  }

  managed_identities = { system_assigned = true }

  tags = local.common_tags
}

# =====================================================================
# SSH public keys (native)
# =====================================================================

resource "azurerm_ssh_public_key" "this" {
  for_each = local.spokes_ssh_public_keys

  name                = each.key
  resource_group_name = module.resource_group[each.value.rg_key].name
  location            = each.value.location
  public_key          = each.value.public_key
  tags                = local.common_tags
}

# =====================================================================
# Bastion hosts (native, Developer SKU)
# =====================================================================

resource "azurerm_bastion_host" "this" {
  for_each = local.spokes_bastion_hosts

  name                = each.key
  resource_group_name = module.resource_group[each.value.rg_key].name
  location            = each.value.location
  sku                 = "Developer"
  virtual_network_id  = each.value.virtual_network_id
  tags                = local.common_tags
}

# =====================================================================
# Internal load balancer (cyberark) + backend pool + probes + rules
# =====================================================================

resource "azurerm_lb" "cyberark" {
  name                = "lb-internal-cyberark-canadacentral-001"
  resource_group_name = module.resource_group["cyberark"].name
  location            = "canadacentral"
  sku                 = "Standard"
  sku_tier            = "Regional"

  frontend_ip_configuration {
    name                          = "fic-lb-internal-cyberark-canadacentral-001"
    subnet_id                     = local.spokes_snet_cyberark
    private_ip_address            = "10.195.116.7"
    private_ip_address_allocation = "Static"
    private_ip_address_version    = "IPv4"
    zones                         = ["1", "2", "3"]
  }

  tags = local.common_tags
}

resource "azurerm_lb_backend_address_pool" "cyberark" {
  name            = "bkp-lb-internal-cyberark-canadacentral-001"
  loadbalancer_id = azurerm_lb.cyberark.id
}

resource "azurerm_lb_probe" "cyberark" {
  for_each = local.spokes_lb_probes

  name                = each.key
  loadbalancer_id     = azurerm_lb.cyberark.id
  protocol            = each.value.protocol
  port                = each.value.port
  request_path        = each.value.request_path
  interval_in_seconds = each.value.interval
  number_of_probes    = each.value.num_probes
}

resource "azurerm_lb_rule" "cyberark" {
  for_each = local.spokes_lb_rules

  name                           = each.key
  loadbalancer_id                = azurerm_lb.cyberark.id
  frontend_ip_configuration_name = "fic-lb-internal-cyberark-canadacentral-001"
  protocol                       = "Tcp"
  frontend_port                  = each.value.frontend_port
  backend_port                   = each.value.backend_port
  idle_timeout_in_minutes        = 4
  floating_ip_enabled            = false
  load_distribution              = "Default"
  backend_address_pool_ids       = [azurerm_lb_backend_address_pool.cyberark.id]
  probe_id                       = azurerm_lb_probe.cyberark[each.value.probe].id
}

# =====================================================================
# Maintenance configurations (native)
# =====================================================================

resource "azurerm_maintenance_configuration" "this" {
  for_each = local.spokes_maintenance_configurations

  name                     = each.key
  resource_group_name      = module.resource_group[each.value.rg_key].name
  location                 = each.value.location
  scope                    = "InGuestPatch"
  in_guest_user_patch_mode = "User"
  visibility               = "Custom"

  window {
    start_date_time = each.value.start_date_time
    duration        = each.value.duration
    time_zone       = "Pacific Standard Time"
    recur_every     = each.value.recur_every
  }

  install_patches {
    reboot = "IfRequired"
    linux {
      classifications_to_include = ["Critical", "Security"]
    }
    windows {
      classifications_to_include = each.value.windows_classifications
    }
  }

  tags = local.common_tags
}

# =====================================================================
# Recovery Services vault (wrapper) + default backup policies (native)
# =====================================================================

module "recovery_services_vault" {
  for_each = {
    "connectivity" = {
      name   = "rsv-connectivity-canadacentral-001"
      rg_key = "runners"
      sku    = "RS0"
    }
  }

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-recovery-services-vault/azurerm"
  version = "0.1.0"

  name                          = each.value.name
  resource_group_name           = module.resource_group[each.value.rg_key].name
  location                      = "canadacentral"
  sku                           = each.value.sku
  storage_mode_type             = "GeoRedundant"
  cross_region_restore_enabled  = false
  soft_delete_enabled           = true
  immutability                  = "Unlocked"
  public_network_access_enabled = false

  tags = local.common_tags
}

# Azure-created default policies present in every vault, adopted as native resources.
resource "azurerm_backup_policy_vm" "default" {
  name                = "DefaultPolicy"
  resource_group_name = module.resource_group["runners"].name
  recovery_vault_name = "rsv-connectivity-canadacentral-001"
  policy_type         = "V1"
  timezone            = "UTC"

  instant_restore_retention_days = 2

  backup {
    frequency = "Daily"
    time      = "10:30"
  }

  retention_daily {
    count = 30
  }

  depends_on = [module.recovery_services_vault]
}

resource "azurerm_backup_policy_vm" "enhanced" {
  name                = "EnhancedPolicy"
  resource_group_name = module.resource_group["runners"].name
  recovery_vault_name = "rsv-connectivity-canadacentral-001"
  policy_type         = "V2"
  timezone            = "UTC"

  instant_restore_retention_days = 2

  backup {
    frequency     = "Hourly"
    hour_interval = 4
    hour_duration = 12
    time          = "08:00"
  }

  retention_daily {
    count = 30
  }

  depends_on = [module.recovery_services_vault]
}

# SQL workload log-backup policy (AzureWorkload / SQLDataBase).
resource "azurerm_backup_policy_vm_workload" "hourly_log" {
  name                = "HourlyLogBackup"
  resource_group_name = module.resource_group["runners"].name
  recovery_vault_name = "rsv-connectivity-canadacentral-001"
  workload_type       = "SQLDataBase"

  settings {
    time_zone           = "UTC"
    compression_enabled = false
  }

  protection_policy {
    policy_type = "Full"
    backup {
      frequency = "Daily"
      time      = "10:30"
    }
    retention_daily {
      count = 30
    }
  }

  protection_policy {
    policy_type = "Log"
    backup {
      frequency_in_minutes = 60
    }
    simple_retention {
      count = 30
    }
  }

  depends_on = [module.recovery_services_vault]
}
