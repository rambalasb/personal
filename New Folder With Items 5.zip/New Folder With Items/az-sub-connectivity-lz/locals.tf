# Alert definitions passed into the amba-alz wrapper in monitoring.tf. All
# action groups live in the MANAGEMENT subscription and are referenced by ID
# (cross-sub). No action groups are created in this subscription.
#
# Only the STANDARD alerts are built here — their names are known and match the
# other landing zones. The connectivity-specific alerts (firewall health/update,
# VPN resource-health x2, VM CPU/memory) are pending: `az group export`
# parameterized their names, so exact resource names must be confirmed via
# `az resource show` before they can be imported. See NOTES in monitoring.tf.

locals {
  common_tags = merge(var.tags, {
    environment = var.environment
    managed-by  = "terraform"
    solution    = "az-sub-connectivity-lz"
  })

  subscription_scope = data.azurerm_subscription.current.id
  alerts_rg_name     = module.resource_group["alerts"].name

  # Management-subscription action groups (cross-sub, by ID). The ServiceNow
  # name has an intentional leading space (matches live).
  mgmt_servicenow_ag_id = "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/lga-servicenow-integration_group/providers/Microsoft.Insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
  mgmt_mail_ag_id       = "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/rg-alerts-management-canadacentral-001/providers/Microsoft.Insights/actionGroups/ag-monitor-mail-alerts-canadacentral-001"

  activity_log_alerts = {
    service_outage = {
      name                = "Service-Outage-Alert-canadacentral"
      resource_group_name = local.alerts_rg_name
      scopes              = [local.subscription_scope]
      location            = "global"
      description         = "Azure Landing Zone Service Health Alert"
      criteria = {
        category = "ServiceHealth"
        service_health = {
          events    = []
          locations = ["Global"]
          services  = []
        }
      }
      action_group_ids = [local.mgmt_mail_ag_id]
    }
  }

  log_search_alerts = {
    resource_creation = {
      name                 = "Resource-Creation-Alert-canadacentral"
      resource_group_name  = local.alerts_rg_name
      location             = var.location
      scopes               = [local.subscription_scope]
      severity             = 4
      evaluation_frequency = "PT10M"
      window_duration      = "PT30M"
      description          = "Alert when a new resource is created."
      display_name         = "Resource-Creation-Alert-canadacentral"
      criteria = [{
        query                   = "        AzureActivity\n        | where OperationNameValue has \"Microsoft.Resources/deployments/write\"\n        | where CategoryValue == \"Administrative\"\n        | where ActivityStatusValue == \"Success\"\n        "
        time_aggregation_method = "Count"
        threshold               = 10
        operator                = "GreaterThanOrEqual"
        resource_id_column      = "_ResourceId"
        failing_periods         = { minimum_failing_periods_to_trigger_alert = 1, number_of_evaluation_periods = 1 }
      }]
      action_group_ids = [local.mgmt_servicenow_ag_id]
    }

    storage_container_deletion = {
      name                 = "Storage-Account-Container-Deletion-Alert-canadacentral"
      resource_group_name  = local.alerts_rg_name
      location             = var.location
      scopes               = [local.subscription_scope]
      severity             = 0
      evaluation_frequency = "PT5M"
      window_duration      = "PT30M"
      description          = "Alert for the deletion of Storage Account Container."
      display_name         = "Storage-Account-Container-Deletion-Alert-canadacentral"
      criteria = [{
        query                   = "        AzureActivity\n        | where ResourceProviderValue == \"MICROSOFT.STORAGE\" and OperationNameValue == \"MICROSOFT.STORAGE/STORAGEACCOUNTS/BLOBSERVICES/CONTAINERS/DELETE\"\n        "
        time_aggregation_method = "Count"
        threshold               = 1
        operator                = "GreaterThanOrEqual"
        resource_id_column      = "_ResourceId"
        failing_periods         = { minimum_failing_periods_to_trigger_alert = 1, number_of_evaluation_periods = 1 }
      }]
      action_group_ids = [local.mgmt_servicenow_ag_id]
    }

    storage_deletion = {
      name                 = "Storage-Account-Deletion-Alert-canadacentral"
      resource_group_name  = local.alerts_rg_name
      location             = var.location
      scopes               = [local.subscription_scope]
      severity             = 0
      evaluation_frequency = "PT5M"
      window_duration      = "PT30M"
      description          = "Alert for the deletion of Storage Account."
      display_name         = "Storage-Account-Deletion-Alert-canadacentral"
      criteria = [{
        query                   = "        AzureActivity\n        | where ResourceProviderValue == \"MICROSOFT.STORAGE\" and OperationNameValue == \"MICROSOFT.STORAGE/STORAGEACCOUNTS/DELETE\"\n        "
        time_aggregation_method = "Count"
        threshold               = 1
        operator                = "GreaterThanOrEqual"
        resource_id_column      = "_ResourceId"
        failing_periods         = { minimum_failing_periods_to_trigger_alert = 1, number_of_evaluation_periods = 1 }
      }]
      action_group_ids = [local.mgmt_servicenow_ag_id]
    }
  }
}
