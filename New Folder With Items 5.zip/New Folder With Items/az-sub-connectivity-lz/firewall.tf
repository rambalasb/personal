# firewall.tf
# 3 Azure Firewalls (2 secured-hub in the hub RGs, 1 VNet-based transit in shared_cc),
# 2 firewall policies + 17 rule collection groups (all in rg-hub-connectivity-canadacentral-001).
# Policies via tf-wrapper-avm-azure-firewall-policy; the wrapper does not expose rule
# collection groups, so those use the native azurerm_firewall_policy_rule_collection_group.
# Rule ipGroups references resolve to module.ip_group[...].resource_id.
#
# TODO the transit firewall (azfw-transit-connectivity-canadacentral-001) carries classic
# inline networkRuleCollections (rc-allow-ns2-to-bch) that the AVM firewall module cannot
# express; migrate those to a firewall policy or reconcile on first plan.
#
# TODO the following empty rule collections are omitted (the provider cannot represent a
# 0-rule collection):
#   azfwpol-connectivity-001/rcg-1000-spoke-specific-canada-central :: rc-allow-sap-aem-inbound (action Allow, priority 2520)
#   azfwpol-connectivity-001-BACKUP-20260320-233016-UTC/rcg-41000-spokes-to-onprem :: rc-allow-net-fit-to-esb-nonprod (action Allow, priority 41100)

variable "enable_firewall" {
  type    = bool
  default = false
}

locals {
  # UserAssigned identity for the connectivity firewall policy (identity subscription).
  firewall_uami_id = "/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0/resourceGroups/rg-mid-identity-canadacentral-001/providers/Microsoft.ManagedIdentity/userAssignedIdentities/mid-azfirewall-canadacentral-001"

  # TODO confirm cross-subscription Log Analytics workspace id (SIEM lives in the security LZ).
  firewall_insights_workspace_id = "${local.sub}/resourceGroups/rg-siem-security-canadacentral-001/providers/Microsoft.OperationalInsights/workspaces/la-siem-security-canadacentral-001"

  firewalls = {
    "azfw-connectivity-canadacentral-001" = {
      rg_key                      = "hub_cc"
      location                    = "canadacentral"
      sku_name                    = "AZFW_Hub"
      sku_tier                    = "Premium"
      firewall_policy_id          = module.firewall_policy["azfwpol-connectivity-001"].resource_id
      zones                       = null
      virtual_hub                 = { public_ip_count = 1, virtual_hub_id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001" }
      ip_configurations           = {}
      management_ip_configuration = null
    }
    "azfw-connectivity-canadaeast-001" = {
      rg_key                      = "hub_ce"
      location                    = "canadaeast"
      sku_name                    = "AZFW_Hub"
      sku_tier                    = "Premium"
      firewall_policy_id          = module.firewall_policy["azfwpol-connectivity-001"].resource_id
      zones                       = null
      virtual_hub                 = { public_ip_count = 1, virtual_hub_id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadaeast-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadaeast-001" }
      ip_configurations           = {}
      management_ip_configuration = null
    }
    "azfw-transit-connectivity-canadacentral-001" = {
      rg_key             = "shared_cc"
      location           = "canadacentral"
      sku_name           = "AZFW_VNet"
      sku_tier           = "Standard"
      firewall_policy_id = null
      zones              = null
      virtual_hub        = null
      ip_configurations = {
        primary = {
          name                 = "azfw-transit-connectivity-canadacentral-001_IPConf"
          subnet_id            = "${local.sub}/resourceGroups/rg-shared-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-transit-connectivity-canadacentral-001/subnets/AzureFirewallSubnet"
          public_ip_address_id = null
        }
      }
      management_ip_configuration = {
        name                 = "pip-azfw-transit-connectivity-canadacentral-001"
        public_ip_address_id = "${local.sub}/resourceGroups/rg-shared-connectivity-canadacentral-001/providers/Microsoft.Network/publicIPAddresses/pip-azfw-transit-connectivity-canadacentral-001"
        subnet_id            = "${local.sub}/resourceGroups/rg-shared-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-transit-connectivity-canadacentral-001/subnets/AzureFirewallManagementSubnet"
      }
    }
  }

  firewall_policies = {
    "azfwpol-connectivity-001" = {
      location                 = "canadacentral"
      sku                      = "Premium"
      threat_intelligence_mode = "Deny"
      dns                      = { proxy_enabled = true, servers = ["10.195.4.7"] }
      intrusion_detection      = { mode = "Deny" }
      identity                 = { type = "UserAssigned", identity_ids = [local.firewall_uami_id] }
      insights = {
        enabled                            = true
        default_log_analytics_workspace_id = local.firewall_insights_workspace_id
        retention_in_days                  = 30
        log_analytics_workspace = [
          { firewall_location = "canadacentral", id = local.firewall_insights_workspace_id },
          { firewall_location = "canadaeast", id = local.firewall_insights_workspace_id },
        ]
      }
      tls_certificate = {
        name                = "azkv-fw-tls-cert"
        key_vault_secret_id = "https://kvfwtlscanadacentral.vault.azure.net/secrets/azkv-fw-tls-cert/0393397970c443b4be90c8928137ef62"
      }
    }
    "azfwpol-connectivity-001-BACKUP-20260320-233016-UTC" = {
      location                 = "canadacentral"
      sku                      = "Premium"
      threat_intelligence_mode = "Deny"
      dns                      = { proxy_enabled = true, servers = ["10.195.4.7"] }
      intrusion_detection      = { mode = "Deny" }
      identity                 = null
      insights                 = null
      tls_certificate          = null
    }
  }

  firewall_rule_collection_groups = {
    "azfwpol-connectivity-001/rcg-1000-spoke-specific-canada-central" = {
      name       = "rcg-1000-spoke-specific-canada-central"
      policy_key = "azfwpol-connectivity-001"
      priority   = 1000
      network_rule_collections = [
        {
          name     = "rc-allow-vnet-shared-connectivity-canadacentral-001-inbound"
          priority = 1410
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-sentinel-to-logic-app"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-monitor"].resource_id]
              destination_addresses = ["10.195.6.16"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-hosted-runners-to-loganalytics"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = ["10.195.6.8"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-hosted-runners-to-keyvault-tmp"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = ["10.195.66.4"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-hosted-runners-to-logic-app-tmp"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = ["10.195.6.16"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-cops-nonprod-canadacentral-001-inbound"
          priority = 1610
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-hosted-runners-to-cops-nonprod-dbs-tmp"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-nonprod-cops-db"].resource_id]
              destination_ports     = ["443", "1433", "11000-11999"]
            },
            {
              name                  = "r-allow-hosted-runners-to-cops-nonprod-apps-tmp"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-nonprod-cops-apps"].resource_id]
              destination_ports     = ["80", "443", "8172"]
            },
            {
              name                  = "r-allow-cops-nonprod-to-apple-push"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-nonprod-cops-apps"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["api.push.apple.com", "api.sandbox.push.apple.com"]
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-fit-nonprod-canadacentral-001-inbound"
          priority = 1810
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-hosted-runners-to-fit-nonprod-apps-tmp"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-nonprod-fit-apps"].resource_id]
              destination_ports     = ["80", "443", "8172"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-pta-nonprod-canadacentral-001-inbound"
          priority = 2010
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-hosted-runners-to-pta-nonprod-dbs-tmp"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-nonprod-pta-db"].resource_id]
              destination_ports     = ["443", "1433", "11000-11999"]
            },
            {
              name                  = "r-allow-hosted-runners-to-pta-nonprod-apps-tmp"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-nonprod-pta-apps"].resource_id]
              destination_ports     = ["80", "443", "8172"]
            },
            {
              name                  = "r-allow-hosted-runners-to-pta-nonprod-storage-tmp"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = ["10.195.66.9"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-pta-prod-canadacentral-inbound"
          priority = 2210
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-hosted-runners-to-pta-prod-storage-tmp"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-prod-pta-db"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-hosted-runners-to-pta-prod-dbs-tmp"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-prod-pta-db"].resource_id]
              destination_ports     = ["443", "1433", "11000-11999"]
            },
            {
              name                  = "r-allow-hosted-runners-to-pta-prod-apps-tmp"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-prod-pta-apps"].resource_id]
              destination_ports     = ["80", "443", "8172"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-fit-nonprod-canadacentral-001-outbound"
          priority = 1910
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-fit-nonprod-to-esb-1"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.80.0-10.195.83.254"]
              source_ip_groups      = []
              destination_addresses = ["10.242.47.1"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["22734", "22738", "443"]
            },
            {
              name                  = "r-allow-fit-nonprod-to-esb-2"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.80.0-10.195.83.254"]
              source_ip_groups      = []
              destination_addresses = ["10.242.47.2"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["23734", "23738", "443"]
            },
            {
              name                  = "r-allow-fit-nonprod-db-to-tkdcdbmontr"
              protocols             = ["TCP", "UDP"]
              source_addresses      = ["10.195.81.4"]
              source_ip_groups      = []
              destination_addresses = ["10.242.83.125"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["4903", "22", "3872"]
            },
            {
              name                  = "r-allow-fit-nonprod-db-to-bch-smtp"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.81.4"]
              source_ip_groups      = []
              destination_addresses = ["10.242.35.1"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["25"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-ertest-canadacentral-001-inbound"
          priority = 1390
          action   = "Deny"
          rules = [
            {
              name                  = "r-deny-ertest-canadacentral-001-inbound"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-ertest-vnet"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-cyberark-canadacentral-001-inbound"
          priority = 2690
          action   = "Deny"
          rules = [
            {
              name                  = "r-deny-vnet-cyberark-canadacentral-001-inbound"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cyberark-vnet"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-dns-connectivity-canadacentral-001-inbound"
          priority = 2890
          action   = "Deny"
          rules = [
            {
              name                  = "r-deny-dns-connectivity-canadacentral-001-inbound"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-dns-connectivity-vnet"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-shared-connectivity-canadacentral-001-inbound"
          priority = 1590
          action   = "Deny"
          rules = [
            {
              name                  = "r-deny-vnet-shared-connectivity-canadacentral-001-inbound"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-shared-connectivity-vnet"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-cops-nonprod-canadacentral-inbound"
          priority = 1790
          action   = "Deny"
          rules = [
            {
              name                  = "r-deny-vnet-cops-nonprod-canadacentral-inbound"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cops-nonprod-vnet"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-fit-nonprod-canadacentral-001-inbound"
          priority = 1990
          action   = "Deny"
          rules = [
            {
              name                  = "r-deny-vnet-fit-nonprod-canadacentral-001-inbound"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-fit-nonprod-vnet"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-runners-connectivity-canadacentral-001-inbound"
          priority = 3090
          action   = "Deny"
          rules = [
            {
              name                  = "r-deny-vnet-runners-connectivity-canadacentral-001-inbound"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners-vnet"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-cops-prod-canadacentral-inbound"
          priority = 3290
          action   = "Deny"
          rules = [
            {
              name                  = "r-deny-vnet-cops-prod-canadacentral-inbound"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cops-prod-vnet"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-fit-prod-canadacentral-001-inbound"
          priority = 3490
          action   = "Deny"
          rules = [
            {
              name                  = "r-deny-vnet-fit-prod-canadacentral-001-inbound"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-fit-prod-vnet"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-pta-prod-canadacentral-001-inbound"
          priority = 2390
          action   = "Deny"
          rules = [
            {
              name                  = "r-deny-vnet-pta-prod-canadacentral-001-inbound"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-pta-prod-vnet"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-pta-nonprod-canadacentral-001-inbound"
          priority = 2190
          action   = "Deny"
          rules = [
            {
              name                  = "r-deny-vnet-pta-nonprod-canadacentral-001-inbound"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-pta-nonprod-vnet"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-fit-prod-canadacentral-001-outbound"
          priority = 3310
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-fit-prod-db-to-kdcdbmontr"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.33.4"]
              source_ip_groups      = []
              destination_addresses = ["10.242.83.115"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["4903"]
            },
            {
              name                  = "r-allow-fit-prod-db-to-bch-smtp"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.33.4"]
              source_ip_groups      = []
              destination_addresses = ["10.242.35.1"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["25"]
            },
            {
              name                  = "r-allow-fit-prod-to-prod-esb"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-prod-fit-apps"].resource_id]
              destination_addresses = ["10.242.12.161"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["21734", "21738", "443"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-cops-prod-canadacentral-001-outbound"
          priority = 3110
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-cops-prod-to-apple-push"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-prod-cops-apps"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["api.push.apple.com", "api.sandbox.push.apple.com"]
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-fit-prod-canadacentral-001-inbound"
          priority = 1710
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-hosted-runners-to-fit-prod-apps"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-prod-fit-apps"].resource_id]
              destination_ports     = ["80", "443", "8172"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-runners-connectivity-canadacentral-001-outbound"
          priority = 2910
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-runners-to-ms-build"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["akamaized.net", "akamaitechnologies.com", "aka.ms", "download.visualstudio.microsoft.com", "download.microsoft.com", "download.visualstudio.com", "marketplace.visualstudio.com", "gallerycdn.vsassets.io", "visualstudio.microsoft.com", "learn.microsoft.com", "msdn.microsoft.com", "www.microsoft.com", "windows.net", "microsoftonline.com", "live.com", "github-releases.githubusercontent.com", "objects.githubusercontent.com", "github.com", "az837173.vo.msecnd.net"]
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-cops-prod-canadacentral-inbound"
          priority = 3120
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-hosted-runners-to-cops-prod-dbs"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-prod-cops-db"].resource_id]
              destination_ports     = ["443", "1433", "11000-11999"]
            },
            {
              name                  = "r-allow-hosted-runners-to-cops-prod-apps"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-prod-cops-apps"].resource_id]
              destination_ports     = ["80", "443", "8172"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-mds-prod-canadacentral-in"
          priority = 3690
          action   = "Deny"
          rules = [
            {
              name                  = "r-deny-vnet-mds-prod-canadacentral-in"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-mds-prod-canadacentral"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-solace-nonprod-canadacentral-in"
          priority = 3890
          action   = "Deny"
          rules = [
            {
              name                  = "r-deny-vnet-solace-nonprod-canadacentral-in"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-solace-nonprod-canadacentral"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-openai-nonprod-canadacentral-001-in"
          priority = 4290
          action   = "Deny"
          rules = [
            {
              name                  = "r-deny-vnet-openai-nonprod-canadacentral-001-in"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-openai-nonprod-canadacentral-001"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-auritas-nonprod-canadacentral-in"
          priority = 4490
          action   = "Deny"
          rules = [
            {
              name                  = "r-deny-vnet-auritas-nonprod-canadacentral-in"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-auritas-nonprod-canadacentral"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-mds-canadacentral-outbound"
          priority = 3610
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-mds-https"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-mds-ips"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-allow-runners-cacentral"
          priority = 2912
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-prod-runners-to-prod-vnets"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-prod-runner-ips"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-clz-prod-subnets"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-dev-runners-to-dev-vnets"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-dev-runner-ips"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-clz-dev-subnets"].resource_id]
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-allow-sap-aem-outbound"
          priority = 3810
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-dev-30500"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.112.0/24"]
              source_ip_groups      = []
              destination_addresses = ["10.242.74.123", "10.242.83.70"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["30500"]
            },
            {
              name                  = "r-allow-qa-30500"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.112.0/24"]
              source_ip_groups      = []
              destination_addresses = ["10.242.83.220", "10.242.83.138"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["30500"]
            },
            {
              name                  = "r-allow-dev-8443"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.112.0/24"]
              source_ip_groups      = []
              destination_addresses = ["10.242.83.52", "10.242.83.10"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["8443"]
            },
            {
              name                  = "r-allow-qa-8443"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.112.0/24"]
              source_ip_groups      = []
              destination_addresses = ["10.242.83.97", "10.242.83.11"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["8443"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-ertest-canadacentral-001-in"
          priority = 1211
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-iperf02"
              protocols             = ["ICMP"]
              source_addresses      = ["10.195.118.7", "10.195.118.8"]
              source_ip_groups      = []
              destination_addresses = ["10.196.114.7", "10.242.69.32", "10.242.69.100", "10.242.69.101", "10.242.69.194", "10.242.69.195", "172.25.6.58"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
            {
              name                  = "r-allow-iperf01"
              protocols             = ["UDP", "TCP"]
              source_addresses      = ["10.195.118.7", "10.195.118.8"]
              source_ip_groups      = []
              destination_addresses = ["10.196.114.7", "10.242.69.32", "10.242.69.100", "10.242.69.101", "10.242.69.194", "10.242.69.195", "172.25.6.58"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["5201"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-cyberark-canadacentral-001-in"
          priority = 2531
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-runners-to-openai-nonprod"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cyberark-vnet"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-vnet-openai-nonprod-canadacentral-001"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-oracle-cyberark"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cyberark-vm-ips"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["dogwood.oracle.cyberark.cloud"]
              destination_ip_groups = []
              destination_ports     = ["1521"]
            },
            {
              name                  = "r-allow-sql-cyberark"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cyberark-vm-ips"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["dogwood.mssql.cyberark.cloud"]
              destination_ip_groups = []
              destination_ports     = ["1433"]
            },
            {
              name                  = "r-allow-cyberark-to-windows-vms"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cyberark-vm-ips"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_ports     = ["445", "3389"]
            },
            {
              name                  = "r-allow-cyberark-to-linux-vms"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cyberark-vm-ips"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_ports     = ["22"]
            },
            {
              name                  = "r-allow-cyberark-1858-ip"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cyberark-vm-ips"].resource_id]
              destination_addresses = ["15.223.165.102"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["1858"]
            },
            {
              name                  = " r-allow-cyberark-1858 "
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cyberark-vm-ips"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["vault-dogwood.privilegecloud.cyberark.cloud"]
              destination_ip_groups = []
              destination_ports     = ["1858"]
            },
            {
              name                  = "r-allow-cyberark-to-cyberarksite"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cyberark-vm-ips"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["www.cyberark.cloud", "abp4127.id.cyberark.cloud", "cyberark.cloud", "cyberark.com", "www.cyberark.com", "community.cyberark.com", "s3.amazonaws.com", "amazonaws.com", "component-registry-store-490081306957.s3.amazonaws.com", "caintegrations.s3.amazonaws.com", "dogwood.cyberark.cloud", "connector-dogwood.privilegecloud.cyberark.cloud", "console.privilegecloud.cyberark.cloud", "dogwood.dpa.cyberark.cloud", "ca-central-1.bc.be-privilege-access.cyberark.cloud", "a3vvqcp8z371p3-ats.iot.ca-central-1.amazonaws.com", "a2m4b3cupk8nzj-ats.iot.ca-central-1.amazonaws.com", "casoftware.s3.amazonaws.com", "dogwood.privilegecloud.cyberark.cloud", "webaccess-dogwood.privilegecloud.cyberark.cloud", "dogwood.webaccess.cyberark.cloud", "dogwood.connectormanagement.cyberark.cloud", "connector-management-scripts-490081306957-ca-central-1.s3.amazonaws.com", "connector-management-assets-490081306957-ca-central-1.s3.amazonaws.com", "pod1402-b1.relay.idaptive.app", "pod1402-b2.relay.idaptive.app", "pod1402-a1.relay.idaptive.app", "pod1402-a2.relay.idaptive.app", "pod0.idaptive.app", "edge.idaptive.app", "cms-assets-bucket-445444212982.s3.amazonaws.com", "cms-assets-bucket-445444212982-ca-central-1.s3.ca-central-1.amazonaws.com", "dogwood.rdp.cyberark.cloud", "dogwood.k8s.cyberark.cloud", "crt.r2m02.amazontrust.com", "ocsp.r2m02.amazontrust.com", "privacy-policy.truste.com", "ocsp.verisign.com", "ocsp.globalsign.com", "crl.globalsign.com", "secure.globalsign.com", "dogwood.ssh.cyberark.cloud", "dogwood.rdp.cyberark.cloud", "dogwood.mariadb.cyberark.cloud", "dogwood.mysql.cyberark.cloud", "dogwood.oracle.cyberark.cloud", "dogwood.postgres.cyberark.cloud", "dogwood.mssql.cyberark.cloud", "dogwood.db2.cyberark.cloud", "dogwood.mongodb.cyberark.cloud", "vault-dogwood.privilegecloud.cyberark.cloud", "ipinfo.io"]
              destination_ip_groups = []
              destination_ports     = ["443", "80", "22", "8443", "3306", "2484", "5432", "1433", "50002", "27017", "1858"]
            },
            {
              name                  = "r-allow-cyberark-to-openai-prod"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cyberark-vm-ips"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-vm-openai-prod-canadacentral-001"].resource_id]
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-auritas-nonprod-canadacentral-in"
          priority = 4310
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-snet-auritas-nonprod-app-cc-in"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-snet-auritas-nonprod-app-canadacentral-001"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["hub.docker.com", "registry-1.docker.io", "production.cloudflare.docker.com", "docker.io", "index.docker.io"]
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-snet-auritas-nonprod-pep-cc-in"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-snet-auritas-nonprod-pep-canadacentral-001"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["hub.docker.com", "registry-1.docker.io", "production.cloudflare.docker.com", "docker.io", "index.docker.io"]
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-runners-connectivity-canadacentral-001-in"
          priority = 2911
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-runners-to-openai-nonprod"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners-vnet"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-vnet-openai-nonprod-canadacentral-001"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-runners-to-openai-prod"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-openai-prod-acropenaiprodcc001"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-runners-to-pep-psql-openai-prod"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-psql-openai-prod-cc-001"].resource_id]
              destination_ports     = ["5432"]
            },
            {
              name                  = "r-allow-runners-to-pep-psql-openai-nonprod"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-psql-openai-nonprod-cc-001"].resource_id]
              destination_ports     = ["5432"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-auritas-prod-canadacentral-in"
          priority = 4690
          action   = "Deny"
          rules = [
            {
              name                  = "r-deny-vnet-auritas-prod-canadacentral-in"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-auritas-prod-canadacentral"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-auritas-prod-canadacentral-in"
          priority = 4510
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-snet-auritas-prod-app-cc-in"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-snet-auritas-prod-app-canadacentral-001"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["hub.docker.com", "registry-1.docker.io", "production.cloudflare.docker.com", "docker.io", "index.docker.io"]
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-snet-auritas-prod-pep-cc-in"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-snet-auritas-prod-pep-canadacentral-001"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["hub.docker.com", "registry-1.docker.io", "production.cloudflare.docker.com", "docker.io", "index.docker.io"]
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-fabric-prod-canadacentral-in"
          priority = 4890
          action   = "Deny"
          rules = [
            {
              name                  = "r-deny-vnet-fabric-prod-canadacentral-in"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-fabric-prod-canadacentral"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-spo-nonprod-canadacentral-in"
          priority = 5090
          action   = "Deny"
          rules = [
            {
              name                  = "r-deny-vnet-spo-nonprod-canadacentral-in"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-spo-nonprod-canadacentral"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-spo-prod-canadacentral-in"
          priority = 5290
          action   = "Deny"
          rules = [
            {
              name                  = "r-deny-vnet-spo-prod-canadacentral-in"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-spo-prod-canadacentral-001"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-fabric-nonprod-canadacentral-in"
          priority = 5490
          action   = "Deny"
          rules = [
            {
              name                  = "r-deny-vnet-fabric-nonprod-canadacentral-in"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-fabric-nonprod-canadacentral"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-solace-nonprod-canadacentral-in"
          priority = 3809
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-solace-eam-to-esb-dev"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.112.8"]
              source_ip_groups      = []
              destination_addresses = ["10.242.94.44"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-solace-aem-datalake"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-solace-nonprod-canadacentral"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-stfabricnonprodcac001"].resource_id]
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-fabric-nonprod-canadacentral-in"
          priority = 5310
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-fabric-nonprod-to-sap-dataphere"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-pep-df-fabric-nonprod-canadacentral-001"].resource_id, module.ip_group["ipgrp-pep-vm-fabric-nonprod-canadacentral-001"].resource_id]
              destination_addresses = ["15.156.54.127", "16.52.121.191", "16.52.13.141", "3.98.251.234"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-fabric-nonprod-to-sap-dataphere-fqdn"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-pep-df-fabric-nonprod-canadacentral-001"].resource_id, module.ip_group["ipgrp-pep-vm-fabric-nonprod-canadacentral-001"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["dcaa148a-35ec-449b-9faa-496ecda12902.hana.prod-ca10.hanacloud.ondemand.com", "e70c6873-472e-48ed-9476-05b63d89ec98.hana.prod-ca10.hanacloud.ondemand.com"]
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-fabric-non-prod-to-esb-dropbox"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-pep-vm-fabric-nonprod-canadacentral-001"].resource_id, module.ip_group["ipgrp-pep-df-fabric-nonprod-canadacentral-001"].resource_id]
              destination_addresses = ["10.242.124.9"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["22"]
            },
          ]
        },
      ]
      application_rule_collections = [

      ]
    },
    "azfwpol-connectivity-001-BACKUP-20260320-233016-UTC/rcg-1000-spoke-specific-canada-central" = {
      name       = "rcg-1000-spoke-specific-canada-central"
      policy_key = "azfwpol-connectivity-001-BACKUP-20260320-233016-UTC"
      priority   = 1000
      network_rule_collections = [
        {
          name     = "rc-allow-vnet-ertest-canadacentral-001-inbound"
          priority = 1210
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-iperf01"
              protocols             = ["TCP", "UDP"]
              source_addresses      = ["10.195.118.7", "10.195.118.8"]
              source_ip_groups      = []
              destination_addresses = ["10.196.114.7", "10.242.69.32", "10.242.69.100", "10.242.69.101", "10.242.69.194", "10.242.69.195", "172.25.6.58"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["5201"]
            },
            {
              name                  = "r-allow-iperf02"
              protocols             = ["ICMP"]
              source_addresses      = ["10.195.118.7", "10.195.118.8"]
              source_ip_groups      = []
              destination_addresses = ["10.196.114.7", "10.242.69.32", "10.242.69.100", "10.242.69.101", "10.242.69.194", "10.242.69.195", "172.25.6.58"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
            {
              name                  = "r-allow-cyberark-to-ertest"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cyberark-vm-ips"].resource_id]
              destination_addresses = ["10.195.118.7", "10.195.118.8", "10.196.114.7"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["135", "445", "3389"]
            },
            {
              name                  = "r-allow-cyberark-to-ertest-linux-vms"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cyberark-vm-ips"].resource_id]
              destination_addresses = ["10.195.116.6", "10.195.116.8"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["22"]
            },
          ]
        },
        {
          name     = "rc-allow-monitoring"
          priority = 1010
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-logging"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-clz-monitor-ips"].resource_id]
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-shared-connectivity-canadacentral-001-inbound"
          priority = 1410
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-sentinel-to-logic-app"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-monitor"].resource_id]
              destination_addresses = ["10.195.6.16"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-hosted-runners-to-loganalytics"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = ["10.195.6.8"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-hosted-runners-to-keyvault-tmp"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = ["10.195.66.4"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-hosted-runners-to-logic-app-tmp"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = ["10.195.6.16"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-cops-nonprod-canadacentral-001-inbound"
          priority = 1610
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-hosted-runners-to-cops-nonprod-dbs-tmp"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-nonprod-cops-db"].resource_id]
              destination_ports     = ["443", "1433", "11000-11999"]
            },
            {
              name                  = "r-allow-hosted-runners-to-cops-nonprod-apps-tmp"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-nonprod-cops-apps"].resource_id]
              destination_ports     = ["80", "443", "8172"]
            },
            {
              name                  = "r-allow-cops-nonprod-to-apple-push"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-nonprod-cops-apps"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["api.push.apple.com", "api.sandbox.push.apple.com"]
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-fit-nonprod-canadacentral-001-inbound"
          priority = 1810
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-hosted-runners-to-fit-nonprod-apps-tmp"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-nonprod-fit-apps"].resource_id]
              destination_ports     = ["80", "443", "8172"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-pta-nonprod-canadacentral-001-inbound"
          priority = 2010
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-hosted-runners-to-pta-nonprod-dbs-tmp"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-nonprod-pta-db"].resource_id]
              destination_ports     = ["443", "1433", "11000-11999"]
            },
            {
              name                  = "r-allow-hosted-runners-to-pta-nonprod-apps-tmp"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-nonprod-pta-apps"].resource_id]
              destination_ports     = ["80", "443", "8172"]
            },
            {
              name                  = "r-allow-hosted-runners-to-pta-nonprod-storage-tmp"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = ["10.195.66.9"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-pta-prod-canadacentral-inbound"
          priority = 2210
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-hosted-runners-to-pta-prod-storage-tmp"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-prod-pta-db"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-hosted-runners-to-pta-prod-dbs-tmp"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-prod-pta-db"].resource_id]
              destination_ports     = ["443", "1433", "11000-11999"]
            },
            {
              name                  = "r-allow-hosted-runners-to-pta-prod-apps-tmp"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-prod-pta-apps"].resource_id]
              destination_ports     = ["80", "443", "8172"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-fit-nonprod-canadacentral-001-outbound"
          priority = 1910
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-fit-nonprod-to-esb-1"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.80.0-10.195.83.254"]
              source_ip_groups      = []
              destination_addresses = ["10.242.47.1"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["22734", "22738", "443"]
            },
            {
              name                  = "r-allow-fit-nonprod-to-esb-2"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.80.0-10.195.83.254"]
              source_ip_groups      = []
              destination_addresses = ["10.242.47.2"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["23734", "23738", "443"]
            },
            {
              name                  = "r-allow-fit-nonprod-db-to-tkdcdbmontr"
              protocols             = ["TCP", "UDP"]
              source_addresses      = ["10.195.81.4"]
              source_ip_groups      = []
              destination_addresses = ["10.242.83.125"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["4903", "22", "3872"]
            },
            {
              name                  = "r-allow-fit-nonprod-db-to-bch-smtp"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.81.4"]
              source_ip_groups      = []
              destination_addresses = ["10.242.35.1"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["25"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-cyberark-canadacentral-001-outbound"
          priority = 2510
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-cyberark-to-cyberarksite"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cyberark-vm-ips"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["www.cyberark.cloud", "abp4127.id.cyberark.cloud", "cyberark.cloud", "cyberark.com", "www.cyberark.com", "community.cyberark.com", "s3.amazonaws.com", "amazonaws.com", "component-registry-store-490081306957.s3.amazonaws.com", "caintegrations.s3.amazonaws.com", "dogwood.cyberark.cloud", "connector-dogwood.privilegecloud.cyberark.cloud", "console.privilegecloud.cyberark.cloud", "dogwood.dpa.cyberark.cloud", "ca-central-1.bc.be-privilege-access.cyberark.cloud", "a3vvqcp8z371p3-ats.iot.ca-central-1.amazonaws.com", "a2m4b3cupk8nzj-ats.iot.ca-central-1.amazonaws.com", "casoftware.s3.amazonaws.com", "dogwood.privilegecloud.cyberark.cloud", "webaccess-dogwood.privilegecloud.cyberark.cloud", "dogwood.webaccess.cyberark.cloud", "dogwood.connectormanagement.cyberark.cloud", "connector-management-scripts-490081306957-ca-central-1.s3.amazonaws.com", "connector-management-assets-490081306957-ca-central-1.s3.amazonaws.com", "pod1402-b1.relay.idaptive.app", "pod1402-b2.relay.idaptive.app", "pod1402-a1.relay.idaptive.app", "pod1402-a2.relay.idaptive.app", "pod0.idaptive.app", "edge.idaptive.app", "cms-assets-bucket-445444212982.s3.amazonaws.com", "cms-assets-bucket-445444212982-ca-central-1.s3.ca-central-1.amazonaws.com", "dogwood.rdp.cyberark.cloud", "dogwood.k8s.cyberark.cloud", "crt.r2m02.amazontrust.com", "ocsp.r2m02.amazontrust.com", "privacy-policy.truste.com", "ocsp.verisign.com", "ocsp.globalsign.com", "crl.globalsign.com", "secure.globalsign.com", "dogwood.ssh.cyberark.cloud", "dogwood.rdp.cyberark.cloud", "dogwood.mariadb.cyberark.cloud", "dogwood.mysql.cyberark.cloud", "dogwood.oracle.cyberark.cloud", "dogwood.postgres.cyberark.cloud", "dogwood.mssql.cyberark.cloud", "dogwood.db2.cyberark.cloud", "dogwood.mongodb.cyberark.cloud", "vault-dogwood.privilegecloud.cyberark.cloud", "ipinfo.io"]
              destination_ip_groups = []
              destination_ports     = ["443", "80", "22", "8443", "3306", "2484", "5432", "1433", "50002", "27017", "1858"]
            },
            {
              name                  = "r-allow-cyberark-1858"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cyberark-vm-ips"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["vault-dogwood.privilegecloud.cyberark.cloud"]
              destination_ip_groups = []
              destination_ports     = ["1858"]
            },
            {
              name                  = "r-allow-cyberark-1858-ip"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cyberark-vm-ips"].resource_id]
              destination_addresses = ["15.223.165.102"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["1858"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-ertest-canadacentral-001-inbound"
          priority = 1390
          action   = "Deny"
          rules = [
            {
              name                  = "r-deny-ertest-canadacentral-001-inbound"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-ertest-vnet"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-cyberark-canadacentral-001-inbound"
          priority = 2690
          action   = "Deny"
          rules = [
            {
              name                  = "r-deny-vnet-cyberark-canadacentral-001-inbound"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cyberark-vnet"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-dns-connectivity-canadacentral-001-inbound"
          priority = 2890
          action   = "Deny"
          rules = [
            {
              name                  = "r-deny-dns-connectivity-canadacentral-001-inbound"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-dns-connectivity-vnet"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-shared-connectivity-canadacentral-001-inbound"
          priority = 1590
          action   = "Deny"
          rules = [
            {
              name                  = "r-deny-vnet-shared-connectivity-canadacentral-001-inbound"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-shared-connectivity-vnet"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-cops-nonprod-canadacentral-inbound"
          priority = 1790
          action   = "Deny"
          rules = [
            {
              name                  = "r-deny-vnet-cops-nonprod-canadacentral-inbound"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cops-nonprod-vnet"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-fit-nonprod-canadacentral-001-inbound"
          priority = 1990
          action   = "Deny"
          rules = [
            {
              name                  = "r-deny-vnet-fit-nonprod-canadacentral-001-inbound"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-fit-nonprod-vnet"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-runners-connectivity-canadacentral-001-inbound"
          priority = 3090
          action   = "Deny"
          rules = [
            {
              name                  = "r-deny-vnet-runners-connectivity-canadacentral-001-inbound"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners-vnet"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-cops-prod-canadacentral-inbound"
          priority = 3290
          action   = "Deny"
          rules = [
            {
              name                  = "r-deny-vnet-cops-prod-canadacentral-inbound"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cops-prod-vnet"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-fit-prod-canadacentral-001-inbound"
          priority = 3490
          action   = "Deny"
          rules = [
            {
              name                  = "r-deny-vnet-fit-prod-canadacentral-001-inbound"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-fit-prod-vnet"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-pta-prod-canadacentral-001-inbound"
          priority = 2390
          action   = "Deny"
          rules = [
            {
              name                  = "r-deny-vnet-pta-prod-canadacentral-001-inbound"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-pta-prod-vnet"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-pta-nonprod-canadacentral-001-inbound"
          priority = 2190
          action   = "Deny"
          rules = [
            {
              name                  = "r-deny-vnet-pta-nonprod-canadacentral-001-inbound"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-pta-nonprod-vnet"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-fit-prod-canadacentral-001-outbound"
          priority = 3310
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-fit-prod-db-to-kdcdbmontr"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.33.4"]
              source_ip_groups      = []
              destination_addresses = ["10.242.83.115"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["4903"]
            },
            {
              name                  = "r-allow-fit-prod-db-to-bch-smtp"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.33.4"]
              source_ip_groups      = []
              destination_addresses = ["10.242.35.1"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["25"]
            },
            {
              name                  = "r-allow-fit-prod-to-prod-esb"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-prod-fit-apps"].resource_id]
              destination_addresses = ["10.242.12.161"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["21734", "21738", "443"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-cops-prod-canadacentral-001-outbound"
          priority = 3110
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-cops-prod-to-apple-push"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-prod-cops-apps"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["api.push.apple.com", "api.sandbox.push.apple.com"]
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-fit-prod-canadacentral-001-inbound"
          priority = 1710
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-hosted-runners-to-fit-prod-apps"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-prod-fit-apps"].resource_id]
              destination_ports     = ["80", "443", "8172"]
            },
          ]
        },
        {
          name     = "rc-allow-runners-cacentral"
          priority = 1020
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-prod-runners-to-prod-vnets"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-prod-runner-ips"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-clz-prod-subnets"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-dev-runners-to-dev-vnets"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-dev-runner-ips"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-clz-dev-subnets"].resource_id]
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-runners-connectivity-canadacentral-001-outbound"
          priority = 2910
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-runners-to-ms-build"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["akamaized.net", "akamaitechnologies.com", "aka.ms", "download.visualstudio.microsoft.com", "download.microsoft.com", "download.visualstudio.com", "marketplace.visualstudio.com", "gallerycdn.vsassets.io", "visualstudio.microsoft.com", "learn.microsoft.com", "msdn.microsoft.com", "www.microsoft.com", "windows.net", "microsoftonline.com", "live.com", "github-releases.githubusercontent.com", "objects.githubusercontent.com", "github.com", "az837173.vo.msecnd.net"]
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-cops-prod-canadacentral-inbound"
          priority = 3120
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-hosted-runners-to-cops-prod-dbs"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-prod-cops-db"].resource_id]
              destination_ports     = ["443", "1433", "11000-11999"]
            },
            {
              name                  = "r-allow-hosted-runners-to-cops-prod-apps"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-prod-cops-apps"].resource_id]
              destination_ports     = ["80", "443", "8172"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-mds-canadacentral-outbound"
          priority = 1110
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-mds-https"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-mds-ips"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-allow-sap-aem-outbound"
          priority = 2530
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-dev-30500"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.112.0/24"]
              source_ip_groups      = []
              destination_addresses = ["10.242.74.123", "10.242.83.70"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["30500"]
            },
            {
              name                  = "r-allow-qa-30500"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.112.0/24"]
              source_ip_groups      = []
              destination_addresses = ["10.242.83.220", "10.242.83.138"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["30500"]
            },
            {
              name                  = "r-allow-dev-8443"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.112.0/24"]
              source_ip_groups      = []
              destination_addresses = ["10.242.83.52", "10.242.83.10"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["8443"]
            },
            {
              name                  = "r-allow-qa-8443"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.112.0/24"]
              source_ip_groups      = []
              destination_addresses = ["10.242.83.97", "10.242.83.11"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["8443"]
            },
          ]
        },
        {
          name     = "rc-allow-sap-aem-inbound"
          priority = 2520
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-onprem-9443"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.33.41", "10.242.33.42", "10.242.33.40", "10.242.33.44", "10.242.33.45", "10.242.33.46", "10.242.33.43", "10.242.33.47"]
              source_ip_groups      = []
              destination_addresses = ["10.195.112.0/24"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["9443"]
            },
          ]
        },
      ]
      application_rule_collections = [

      ]
    },
    "azfwpol-connectivity-001/rcg-20000-spoke-specific-canada-east" = {
      name       = "rcg-20000-spoke-specific-canada-east"
      policy_key = "azfwpol-connectivity-001"
      priority   = 20000
      network_rule_collections = [
        {
          name     = "rc-deny-vnet-ertest-canadaeast-001-inbound"
          priority = 20390
          action   = "Deny"
          rules = [
            {
              name                  = "r-deny-ertest-canadaeast-001-inbound"
              protocols             = ["Any"]
              source_addresses      = ["10.196.114.0/23"]
              source_ip_groups      = []
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-ertest-canadaeast-001-in"
          priority = 20210
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-iperf01"
              protocols             = ["TCP", "UDP"]
              source_addresses      = ["10.196.114.7"]
              source_ip_groups      = []
              destination_addresses = ["10.195.118.7", "10.195.118.8", "10.242.69.32", "10.242.69.100", "10.242.69.101", "10.242.69.194", "10.242.69.195", "172.25.6.58"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["5201"]
            },
            {
              name                  = "r-allow-iperf02"
              protocols             = ["ICMP"]
              source_addresses      = ["10.196.114.7"]
              source_ip_groups      = []
              destination_addresses = ["10.195.118.7", "10.195.118.8", "10.242.69.32", "10.242.69.100", "10.242.69.101", "10.242.69.194", "10.242.69.195", "172.25.6.58"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-spo-nonprod-canadaeast-in"
          priority = 20590
          action   = "Deny"
          rules = [
            {
              name                  = "r-deny-vnet-spo-nonprod-canadaeast-in"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-spo-nonprod-canadaeast"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-spo-nonprod-canadaeast-in"
          priority = 20490
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-vnet-spo-nonprod-ce-to-kv-cc"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-spo-nonprod-canadaeast"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-kv-spo-nonprod-cc"].resource_id]
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-spo-prod-canadaeast-001-in"
          priority = 20790
          action   = "Deny"
          rules = [
            {
              name                  = "r-deny-vnet-spo-prod-canadaeast-001-in"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-spo-prod-canadaeast-001"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-spo-prod-canadaeast-001-in"
          priority = 20610
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-spo-prod-canadaeast-to-keyvault"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-spo-prod-canadaeast-001"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-kvspoprod-canadacentral-001"].resource_id]
              destination_ports     = ["443"]
            },
          ]
        },
      ]
      application_rule_collections = [

      ]
    },
    "azfwpol-connectivity-001-BACKUP-20260320-233016-UTC/rcg-20000-spoke-specific-canada-east" = {
      name       = "rcg-20000-spoke-specific-canada-east"
      policy_key = "azfwpol-connectivity-001-BACKUP-20260320-233016-UTC"
      priority   = 20000
      network_rule_collections = [
        {
          name     = "rc-allow-vnet-ertest-canadaeast-001-inbound"
          priority = 20000
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-iperf01"
              protocols             = ["TCP", "UDP"]
              source_addresses      = ["10.196.114.7"]
              source_ip_groups      = []
              destination_addresses = ["10.195.118.7", "10.195.118.8", "10.242.69.32", "10.242.69.100", "10.242.69.101", "10.242.69.194", "10.242.69.195", "172.25.6.58"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["5201"]
            },
            {
              name                  = "r-allow-iperf02"
              protocols             = ["ICMP"]
              source_addresses      = ["10.196.114.7"]
              source_ip_groups      = []
              destination_addresses = ["10.195.118.7", "10.195.118.8", "10.242.69.32", "10.242.69.100", "10.242.69.101", "10.242.69.194", "10.242.69.195", "172.25.6.58"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-ertest-canadaeast-001-inbound"
          priority = 20500
          action   = "Deny"
          rules = [
            {
              name                  = "r-deny-ertest-canadaeast-001-inbound"
              protocols             = ["Any"]
              source_addresses      = ["10.196.114.0/23"]
              source_ip_groups      = []
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-ertest-canadaeast-001-outbound"
          priority = 20200
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-ertest-caeast-to-certificates"
              protocols             = ["TCP"]
              source_addresses      = ["10.196.114.7"]
              source_ip_groups      = []
              destination_addresses = []
              destination_fqdns     = ["support.sectigo.com"]
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
          ]
        },
      ]
      application_rule_collections = [

      ]
    },
    "azfwpol-connectivity-001-BACKUP-20260320-233016-UTC/rcg-300-cyberark-SIA-baseline" = {
      name       = "rcg-300-cyberark-SIA-baseline"
      policy_key = "azfwpol-connectivity-001-BACKUP-20260320-233016-UTC"
      priority   = 300
      network_rule_collections = [
        {
          name     = "rc-allow-cyberark-SIA"
          priority = 320
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-cyberark-to-windows-vms"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cyberark-vm-ips"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_ports     = ["135", "445", "3389"]
            },
            {
              name                  = "r-allow-cyberark-to-linux-vms"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cyberark-vm-ips"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_ports     = ["22"]
            },
            {
              name                  = "r-allow-cyberark-certs"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-caeast-clz-subnets"].resource_id, module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["support.sectigo.com"]
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-cyberark-ssh-to-dogwood"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-caeast-clz-subnets"].resource_id, module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["dogwood.ssh.cyberark.cloud"]
              destination_ip_groups = []
              destination_ports     = ["22"]
            },
          ]
        },
      ]
      application_rule_collections = [

      ]
    },
    "azfwpol-connectivity-001/rcg-39800-transit-to-spoke" = {
      name       = "rcg-39800-transit-to-spoke"
      policy_key = "azfwpol-connectivity-001"
      priority   = 39800
      network_rule_collections = [
        {
          name     = "rc-deny-vnet-transit-connectivity-canadacentral-inbound"
          priority = 39880
          action   = "Deny"
          rules = [
            {
              name                  = "r-deny-vnet-transit-connectivity-canadacentral-inbound"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-transit-connectivity-canadacentral"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-transit-connectivity-canadacentral-in"
          priority = 39810
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-snet-auritas-nonprod-canadacentral"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-transit-connectivity-canadacentral"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-auritas-nonprod-canadacentral"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-ns2-to-auritas-nonprod"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cc-ns2-subnet"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-auritas-nonprod-canadacentral"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-snet-auritas-prod-canadacentral"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-transit-connectivity-canadacentral"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-auritas-prod-canadacentral"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-ns2-to-auritas-prod"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cc-ns2-subnet"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-auritas-prod-canadacentral"].resource_id]
              destination_ports     = ["443"]
            },
          ]
        },
      ]
      application_rule_collections = [

      ]
    },
    "azfwpol-connectivity-001/rcg-40000-onprem-to-spokes" = {
      name       = "rcg-40000-onprem-to-spokes"
      policy_key = "azfwpol-connectivity-001"
      priority   = 40000
      network_rule_collections = [
        {
          name     = "rc-allow-net-onprem-to-east"
          priority = 40200
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-icmp"
              protocols             = ["ICMP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_ports     = ["*"]
            },
            {
              name                  = "r-allow-iperf01"
              protocols             = ["TCP", "UDP"]
              source_addresses      = ["10.242.69.32", "10.242.69.100", "10.242.69.101", "10.242.69.194", "10.242.69.195", "172.25.6.58"]
              source_ip_groups      = []
              destination_addresses = ["10.196.114.7"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["5201"]
            },
          ]
        },
        {
          name     = "rc-allow-net-onprem-to-central"
          priority = 40100
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-icmp"
              protocols             = ["ICMP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id]
              destination_ports     = ["*"]
            },
            {
              name                  = "r-allow-pta-nonprod-apps"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-nonprod-pta-apps"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-pta-nonprod-db"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-to-clzdb-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-nonprod-pta-db"].resource_id]
              destination_ports     = ["1433", "11000-11999"]
            },
            {
              name                  = "r-allow-cops-nonprod-db"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-to-clzdb-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-nonprod-cops-db"].resource_id]
              destination_ports     = ["1433", "11000-11999"]
            },
            {
              name                  = "r-allow-cops-nonprod-apps"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-nonprod-cops-apps"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-fit-apps"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-nonprod-fit-apps"].resource_id, module.ip_group["ipgrp-cacentral-prod-fit-apps"].resource_id]
              destination_ports     = ["443", "1521"]
            },
            {
              name                  = "r-allow-esb-fit-nonprod-1"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.47.1"]
              source_ip_groups      = []
              destination_addresses = ["10.195.80.4"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["22734", "23738", "443"]
            },
            {
              name                  = "r-allow-esb-to-fit-nonprod-2"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.47.2", "10.242.94.14"]
              source_ip_groups      = []
              destination_addresses = ["10.195.80.4"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["23734", "23738", "443"]
            },
            {
              name                  = "r-allow-pta-prod-apps"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-prod-pta-apps"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-pta-prod-db"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-to-clzdb-subnets"].resource_id, module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-prod-pta-db"].resource_id]
              destination_ports     = ["443", "1433", "11000-11999"]
            },
            {
              name                  = "r-allow-iperf01"
              protocols             = ["TCP", "UDP"]
              source_addresses      = ["10.242.69.32", "10.242.69.100", "10.242.69.101", "10.242.69.194", "10.242.69.195", "172.25.6.58"]
              source_ip_groups      = []
              destination_addresses = ["10.195.118.7", "10.195.118.8"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["5201"]
            },
            {
              name                  = "r-allow-esb-to-fit-nonprod-3"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.94.14"]
              source_ip_groups      = []
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-nonprod-fit-apps"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-UAG-to-fit-nonprod"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.234.34", "10.242.234.33"]
              source_ip_groups      = []
              destination_addresses = ["10.195.80.4"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-UAG-to-fit-prod"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.234.34", "10.242.234.33"]
              source_ip_groups      = []
              destination_addresses = ["10.195.32.4"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-kdcdbmontr-to-fit-prod-db"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.83.115"]
              source_ip_groups      = []
              destination_addresses = ["10.195.33.4"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["1521", "22", "3872"]
            },
            {
              name                  = "r-allow-tkdcdbmontr-to-fit-nonprod-db"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.83.125"]
              source_ip_groups      = []
              destination_addresses = ["10.195.81.4"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["1521", "22", "3872"]
            },
            {
              name                  = "r-allow-esb-to-fit-prod"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.94.14"]
              source_ip_groups      = []
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-prod-fit-apps"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-mds-https"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-mds-ips"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-bch-onprem-subnets-to-cyberark"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-cyberark-vnet"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-bch-to-openai-nonprod"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-app-openai-nonprod-canadacentral-001"].resource_id, module.ip_group["ipgrp-func-openai-nonprod-canadacentral-001"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-bch-to-auritas-nonprod-web-fun"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-auritas-nonprod-canadacentral"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-mds-logging-https"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-clz-monitor-ips"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-bch-to-openai-prod"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-app-openai-prod-canadacentral-001"].resource_id, module.ip_group["ipgrp-func-openai-prod-canadacentral-001"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-onprem-sap-aem-9443"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.33.41", "10.242.33.42", "10.242.33.40", "10.242.33.44", "10.242.33.45", "10.242.33.46", "10.242.33.43", "10.242.33.47", "10.242.33.50"]
              source_ip_groups      = []
              destination_addresses = ["10.195.112.0/24"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["9443"]
            },
            {
              name                  = "r-allow-bch-to-auritas-prod-web-fun"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-auritas-prod-canadacentral"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-esb-dev-to-solace-eam"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.94.44"]
              source_ip_groups      = []
              destination_addresses = ["10.195.112.8"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["55443", "443", "5671", "8883", "8443", "9443", "943"]
            },
            {
              name                  = "r-allow-bch-to-pep-stfabricprodcac001"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-stfabricprodcac001"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-bch-to-pep-kvfabricprodcac001"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-kvfabricprodcac001"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-siops-to-stazfwpkcapture"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-bchsiops-jumphost"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-stazpkcapture-prod-canadacentral-001"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-bch-to-spo-nonprod-https"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-kv-spo-nonprod-cc"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-bch-to-keyvault"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-kvspoprod-canadacentral-001"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-bch-to-stfabricnonprodca-nonprod-https"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-stfabricnonprodcac001"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-bch-to-kvfabricnonprodcc001-nonprod-https"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-kvfabricnonprodcc001"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-bch-to-vm-fabric-nonprod-canadacentral-001-rdp"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-pep-kdcazdevjumpp1"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-vm-fabric-nonprod-canadacentral-001"].resource_id]
              destination_ports     = ["3389"]
            },
            {
              name                  = "r-allow-bch-vpn-to-mi-sql-pta-nonprod-cc"
              protocols             = ["TCP"]
              source_addresses      = ["10.244.128.0/18", "10.242.0.0/17", "10.244.0.0/19"]
              source_ip_groups      = []
              destination_addresses = ["10.195.66.10"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["1433"]
            },
          ]
        },
      ]
      application_rule_collections = [

      ]
    },
    "azfwpol-connectivity-001-BACKUP-20260320-233016-UTC/rcg-40000-onprem-to-spokes" = {
      name       = "rcg-40000-onprem-to-spokes"
      policy_key = "azfwpol-connectivity-001-BACKUP-20260320-233016-UTC"
      priority   = 40000
      network_rule_collections = [
        {
          name     = "rc-allow-net-onprem-to-central"
          priority = 40100
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-icmp"
              protocols             = ["ICMP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id]
              destination_ports     = ["*"]
            },
            {
              name                  = "r-allow-pta-nonprod-apps"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-nonprod-pta-apps"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-pta-nonprod-db"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-to-clzdb-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-nonprod-pta-db"].resource_id]
              destination_ports     = ["1433", "11000-11999"]
            },
            {
              name                  = "r-allow-cops-nonprod-db"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-to-clzdb-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-nonprod-cops-db"].resource_id]
              destination_ports     = ["1433", "11000-11999"]
            },
            {
              name                  = "r-allow-cops-nonprod-apps"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-nonprod-cops-apps"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-fit-apps"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-nonprod-fit-apps"].resource_id, module.ip_group["ipgrp-cacentral-prod-fit-apps"].resource_id]
              destination_ports     = ["443", "1521"]
            },
            {
              name                  = "r-allow-esb-fit-nonprod-1"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.47.1"]
              source_ip_groups      = []
              destination_addresses = ["10.195.80.4"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["22734", "23738", "443"]
            },
            {
              name                  = "r-allow-esb-to-fit-nonprod-2"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.47.2", "10.242.94.14"]
              source_ip_groups      = []
              destination_addresses = ["10.195.80.4"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["23734", "23738", "443"]
            },
            {
              name                  = "r-allow-pta-prod-apps"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-prod-pta-apps"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-pta-prod-db"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-to-clzdb-subnets"].resource_id, module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-prod-pta-db"].resource_id]
              destination_ports     = ["443", "1433", "11000-11999"]
            },
            {
              name                  = "r-allow-iperf01"
              protocols             = ["TCP", "UDP"]
              source_addresses      = ["10.242.69.32", "10.242.69.100", "10.242.69.101", "10.242.69.194", "10.242.69.195", "172.25.6.58"]
              source_ip_groups      = []
              destination_addresses = ["10.195.118.7", "10.195.118.8"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["5201"]
            },
            {
              name                  = "r-allow-esb-to-fit-nonprod-3"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.94.14"]
              source_ip_groups      = []
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-nonprod-fit-apps"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-UAG-to-fit-nonprod"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.234.34", "10.242.234.33"]
              source_ip_groups      = []
              destination_addresses = ["10.195.80.4"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-UAG-to-fit-prod"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.234.34", "10.242.234.33"]
              source_ip_groups      = []
              destination_addresses = ["10.195.32.4"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-kdcdbmontr-to-fit-prod-db"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.83.115"]
              source_ip_groups      = []
              destination_addresses = ["10.195.33.4"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["1521", "22", "3872"]
            },
            {
              name                  = "r-allow-tkdcdbmontr-to-fit-nonprod-db"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.83.125"]
              source_ip_groups      = []
              destination_addresses = ["10.195.81.4"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["1521", "22", "3872"]
            },
            {
              name                  = "r-allow-esb-to-fit-prod"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.94.14"]
              source_ip_groups      = []
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-prod-fit-apps"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-mds-https"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-mds-ips"].resource_id]
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-allow-net-onprem-to-east"
          priority = 40200
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-icmp"
              protocols             = ["ICMP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_ports     = ["*"]
            },
            {
              name                  = "r-allow-iperf01"
              protocols             = ["TCP", "UDP"]
              source_addresses      = ["10.242.69.32", "10.242.69.100", "10.242.69.101", "10.242.69.194", "10.242.69.195", "172.25.6.58"]
              source_ip_groups      = []
              destination_addresses = ["10.196.114.7"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["5201"]
            },
          ]
        },
      ]
      application_rule_collections = [
        {
          name     = "rc-allow-app-onprem"
          priority = 40300
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-database"
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id, module.ip_group["ipgrp-onprem-to-clzdb-subnets"].resource_id]
              destination_fqdns     = ["*.database.windows.net"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = false
              protocols             = [{ type = "Mssql", port = 1433 }]
            },
            {
              name                  = "r-allow-apps"
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_fqdns     = ["*core.windows.net", "*.azurewebsites.net"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = false
              protocols             = [{ type = "Https", port = 443 }]
            },
          ]
        },
      ]
    },
    "azfwpol-connectivity-001-BACKUP-20260320-233016-UTC/rcg-41000-spokes-to-onprem" = {
      name       = "rcg-41000-spokes-to-onprem"
      policy_key = "azfwpol-connectivity-001-BACKUP-20260320-233016-UTC"
      priority   = 41000
      network_rule_collections = [

      ]
      application_rule_collections = [

      ]
    },
    "azfwpol-connectivity-001/rcg-490-global-security-rexception" = {
      name       = "rcg-490-global-security-rexception"
      policy_key = "azfwpol-connectivity-001"
      priority   = 490
      network_rule_collections = [
        {
          name     = "rc-allow-rexception-services"
          priority = 495
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-cyberark-to-windows-vms-tcp135"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cyberark-vm-ips"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_ports     = ["135"]
            },
          ]
        },
      ]
      application_rule_collections = [

      ]
    },
    "azfwpol-connectivity-001-BACKUP-20260320-233016-UTC/rcg-490-global-security-rexception" = {
      name       = "rcg-490-global-security-rexception"
      policy_key = "azfwpol-connectivity-001-BACKUP-20260320-233016-UTC"
      priority   = 490
      network_rule_collections = [

      ]
      application_rule_collections = [

      ]
    },
    "azfwpol-connectivity-001/rcg-500-global-security-baseline" = {
      name       = "rcg-500-global-security-baseline"
      policy_key = "azfwpol-connectivity-001"
      priority   = 500
      network_rule_collections = [
        {
          name     = "rc-deny-risky-protocols"
          priority = 600
          action   = "Deny"
          rules = [
            {
              name                  = "r-deny-telnet"
              protocols             = ["TCP"]
              source_addresses      = ["*"]
              source_ip_groups      = []
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["23"]
            },
            {
              name                  = "r-deny-ftp"
              protocols             = ["TCP"]
              source_addresses      = ["*"]
              source_ip_groups      = []
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["20", "21"]
            },
            {
              name                  = "r-deny-tftp"
              protocols             = ["UDP"]
              source_addresses      = ["*"]
              source_ip_groups      = []
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["69"]
            },
            {
              name                  = "r-deny-netbios"
              protocols             = ["TCP"]
              source_addresses      = ["*"]
              source_ip_groups      = []
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["137", "138"]
            },
            {
              name                  = "r-deny-rpc"
              protocols             = ["TCP"]
              source_addresses      = ["*"]
              source_ip_groups      = []
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["135"]
            },
          ]
        },
      ]
      application_rule_collections = [

      ]
    },
    "azfwpol-connectivity-001-BACKUP-20260320-233016-UTC/rcg-500-global-security-baseline" = {
      name       = "rcg-500-global-security-baseline"
      policy_key = "azfwpol-connectivity-001-BACKUP-20260320-233016-UTC"
      priority   = 500
      network_rule_collections = [
        {
          name     = "rc-deny-risky-protocols"
          priority = 600
          action   = "Deny"
          rules = [
            {
              name                  = "r-deny-telnet"
              protocols             = ["TCP"]
              source_addresses      = ["*"]
              source_ip_groups      = []
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["23"]
            },
            {
              name                  = "r-deny-ftp"
              protocols             = ["TCP"]
              source_addresses      = ["*"]
              source_ip_groups      = []
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["20", "21"]
            },
            {
              name                  = "r-deny-tftp"
              protocols             = ["UDP"]
              source_addresses      = ["*"]
              source_ip_groups      = []
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["69"]
            },
            {
              name                  = "r-deny-netbios"
              protocols             = ["TCP"]
              source_addresses      = ["*"]
              source_ip_groups      = []
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["137", "138"]
            },
            {
              name                  = "r-deny-rpc"
              protocols             = ["TCP"]
              source_addresses      = ["*"]
              source_ip_groups      = []
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["135"]
            },
          ]
        },
      ]
      application_rule_collections = [

      ]
    },
    "azfwpol-connectivity-001/rcg-64900-deny-all" = {
      name       = "rcg-64900-deny-all"
      policy_key = "azfwpol-connectivity-001"
      priority   = 64900
      network_rule_collections = [
        {
          name     = "rc-deny-network"
          priority = 64910
          action   = "Deny"
          rules = [
            {
              name                  = "rc-deny-network"
              protocols             = ["Any"]
              source_addresses      = ["*"]
              source_ip_groups      = []
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
      ]
      application_rule_collections = [
        {
          name     = "rc-deny-applications"
          priority = 64920
          action   = "Deny"
          rules = [
            {
              name                  = "rc-deny-applications"
              source_addresses      = ["*"]
              source_ip_groups      = []
              destination_fqdns     = ["*"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = true
              protocols             = [{ type = "Https", port = 443 }, { type = "Mssql", port = 1433 }]
            },
          ]
        },
      ]
    },
    "azfwpol-connectivity-001-BACKUP-20260320-233016-UTC/rcg-64900-deny-all" = {
      name       = "rcg-64900-deny-all"
      policy_key = "azfwpol-connectivity-001-BACKUP-20260320-233016-UTC"
      priority   = 64900
      network_rule_collections = [
        {
          name     = "rc-deny-network"
          priority = 64910
          action   = "Deny"
          rules = [
            {
              name                  = "rc-deny-network"
              protocols             = ["Any"]
              source_addresses      = ["*"]
              source_ip_groups      = []
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
      ]
      application_rule_collections = [
        {
          name     = "rc-deny-applications"
          priority = 64920
          action   = "Deny"
          rules = [
            {
              name                  = "rc-deny-applications"
              source_addresses      = ["*"]
              source_ip_groups      = []
              destination_fqdns     = ["*"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = true
              protocols             = [{ type = "Https", port = 443 }, { type = "Mssql", port = 1433 }]
            },
          ]
        },
      ]
    },
    "azfwpol-connectivity-001/rcg-800-global-internet-baseline" = {
      name       = "rcg-800-global-internet-baseline"
      policy_key = "azfwpol-connectivity-001"
      priority   = 800
      network_rule_collections = [
        {
          name     = "rc-allow-tagbased-services"
          priority = 820
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-azure-services"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = ["AzurePortal", "AzureCloud", "LogicApps", "AzureFrontDoor.Frontend", "AzureFrontDoor.FirstParty", "AzureFrontDoor.Backend", "AzureFrontDoor.Infra", "AzureFrontDoor.MicrosoftSecurity", "AzureActiveDirectory", "AzureResourceManager", "AppService", "Storage", "AzureKeyVault", "AppConfiguration"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443", "445"]
            },
            {
              name                  = "r-allow-azure-monitor"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = ["AzureMonitor", "AzureSentinel", "KustoAnalytics", "ActionGroup", "LogicAppsManagement", "AppServiceManagement"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-sql-services"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = ["Sql", "SqlManagement"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-allow-fqdnbased-services"
          priority = 830
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-microsoft-nuget"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["dotnet.microsoft.com", "download.microsoft.com", "api.nuget.org", "www.nuget.org", "nuget.org", "azuresearch-usnc.nuget.org", "azuresearch-ussc.nuget.org", "licenses.nuget.org", "nuget.cdn.azure.cn", "azuresearch-ea.nuget.org", "azuresearch-sea.nuget.org", "crl3.digicert.com", "crl4.digicert.com", "ocsp.digicert.com", "cacerts.digicert.com", "registry.npmjs.org", "nodejs.org", "dist.nuget.org", "skimdb.npmjs.com", "api.npms.io", "eslint.org", "gradle.org"]
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-smsgateway"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["secure.smsgateway.ca"]
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-servicenow"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["bchydrodev.service-now.com", "bchydroqa.service-now.com", "bchydrouat.service-now.com", "bchydro.service-now.com"]
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-windows-update"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["windowsupdate.microsoft.com", "windowsupdate.microsoft.com", "update.microsoft.com", "windowsupdate.com", "download.windowsupdate.com", "download.microsoft.com", "wustat.windows.com", "ntservicepack.microsoft.com"]
              destination_ip_groups = []
              destination_ports     = ["80", "443"]
            },
            {
              name                  = "r-allow-ntp"
              protocols             = ["UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["time.windows.com"]
              destination_ip_groups = []
              destination_ports     = ["123"]
            },
            {
              name                  = "r-allow-windows-kms"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["kms.core.windows.net"]
              destination_ip_groups = []
              destination_ports     = ["1688"]
            },
            {
              name                  = "r-allow-cyberark-certs"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-caeast-clz-subnets"].resource_id, module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["support.sectigo.com"]
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-cyberark-ssh-to-dogwood"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-caeast-clz-subnets"].resource_id, module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["dogwood.ssh.cyberark.cloud"]
              destination_ip_groups = []
              destination_ports     = ["22"]
            },
          ]
        },
        {
          name     = "rc-allow-ipbased-services"
          priority = 810
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-ntp"
              protocols             = ["UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = ["168.61.215.74"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["123"]
            },
            {
              name                  = "r-allow-dns-inbound"
              protocols             = ["UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-infoblox"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-clz-dns-resolvers"].resource_id]
              destination_ports     = ["53"]
            },
            {
              name                  = "r-allow-dns-outbound"
              protocols             = ["UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-onprem-controllers"].resource_id]
              destination_ports     = ["53"]
            },
            {
              name                  = "r-allow-dns-azure"
              protocols             = ["UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-clz-dns-resolvers"].resource_id]
              destination_ports     = ["53"]
            },
            {
              name                  = "r-allow-github-actions"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = ["4.175.114.51/32", "20.102.35.120/32", "4.175.114.43/32", "20.72.125.48/32", "20.19.5.100/32", "20.7.92.46/32", "20.232.252.48/32", "52.186.44.51/32", "20.22.98.201/32", "20.246.184.240/32", "20.96.133.71/32", "20.253.2.203/32", "20.102.39.220/32", "20.81.127.181/32", "52.148.30.208/32", "20.14.42.190/32", "20.85.159.192/32", "52.224.205.173/32", "20.118.176.156/32", "20.236.207.188/32", "20.242.161.191/32", "20.166.216.139/32", "20.253.126.26/32", "52.152.245.137/32", "40.118.236.116/32", "20.185.75.138/32", "20.96.226.211/32", "52.167.78.33/32", "20.105.13.142/32", "20.253.95.3/32", "20.221.96.90/32", "51.138.235.85/32", "52.186.47.208/32", "20.7.220.66/32", "20.75.4.210/32", "20.120.75.171/32", "20.98.183.48/32", "20.84.200.15/32", "20.14.235.135/32", "20.10.226.54/32", "20.22.166.15/32", "20.65.21.88/32", "20.102.36.236/32", "20.124.56.57/32", "20.94.100.174/32", "20.102.166.33/32", "20.31.193.160/32", "20.232.77.7/32", "20.102.38.122/32", "20.102.39.57/32", "20.85.108.33/32", "40.88.240.168/32", "20.69.187.19/32", "20.246.192.124/32", "20.4.161.108/32", "20.22.22.84/32", "20.1.250.47/32", "20.237.33.78/32", "20.242.179.206/32", "40.88.239.133/32", "20.121.247.125/32", "20.106.107.180/32", "20.22.118.40/32", "20.15.240.48/32", "20.84.218.150/32"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-github"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = ["140.82.112.0/20", "143.55.64.0/20", "185.199.108.0/22", "192.30.252.0/22", "20.175.192.146/32", "20.175.192.147/32", "20.175.192.149/32", "20.175.192.150/32", "20.199.39.227/32", "20.199.39.228/32", "20.199.39.231/32", "20.199.39.232/32", "20.200.245.241/32", "20.200.245.245/32", "20.200.245.246/32", "20.200.245.247/32", "20.200.245.248/32", "20.201.28.144/32", "20.201.28.148/32", "20.201.28.149/32", "20.201.28.151/32", "20.201.28.152/32", "20.205.243.160/32", "20.205.243.164/32", "20.205.243.165/32", "20.205.243.166/32", "20.205.243.168/32", "20.207.73.82/32", "20.207.73.83/32", "20.207.73.85/32", "20.207.73.86/32", "20.207.73.88/32", "20.217.135.1/32", "20.233.83.145/32", "20.233.83.146/32", "20.233.83.147/32", "20.233.83.149/32", "20.233.83.150/32", "20.248.137.48/32", "20.248.137.49/32", "20.248.137.50/32", "20.248.137.52/32", "20.248.137.55/32", "20.26.156.215/32", "20.26.156.216/32", "20.26.156.211/32", "20.27.177.113/32", "20.27.177.114/32", "20.27.177.116/32", "20.27.177.117/32", "20.27.177.118/32", "20.29.134.17/32", "20.29.134.18/32", "20.29.134.19/32", "20.29.134.23/32", "20.29.134.24/32", "20.87.245.0/32", "20.87.245.1/32", "20.87.245.4/32", "20.87.245.6/32", "20.87.245.7/32", "4.208.26.196/32", "4.208.26.197/32", "4.208.26.198/32", "4.208.26.199/32", "4.208.26.200/32", "4.225.11.196/32", "4.237.22.32/32"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-logging"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-clz-monitor-ips"].resource_id]
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-allow-ipbased-azbchclz-to-onprem"
          priority = 835
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-azbchclz-to-unix-satellite"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-onprem-unix-satellite-servers"].resource_id]
              destination_ports     = ["443"]
            },
          ]
        },
      ]
      application_rule_collections = [
        {
          name     = "rc-allow-microsoft-services"
          priority = 840
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-windows-update"
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_fqdns     = ["windowsupdate.microsoft.com", "*.windowsupdate.microsoft.com", "update.microsoft.com", "*.update.microsoft.com", "windowsupdate.com", "*.windowsupdate.com", "download.windowsupdate.com", "*.download.windowsupdate.com", "download.microsoft.com", "wustat.windows.com", "*.wustat.windows.com", "ntservicepack.microsoft.com", "*.delivery.mp.microsoft.com", "*.microsoft.com", "*.windows.com"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = false
              protocols             = [{ type = "Https", port = 443 }, { type = "Http", port = 80 }]
            },
            {
              name                  = "r-allow-azure-services"
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_fqdns     = ["*.azure.com", "*.microsoft.com", "*.azure.net", "*.azurewebsites.net", "*.blob.core.windows.net", "*.queue.core.windows.net", "*.table.core.windows.net"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = true
              protocols             = [{ type = "Https", port = 443 }]
            },
            {
              name                  = "r-allow-azure-monitor"
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_fqdns     = ["*.ods.opinsights.azure.com", "*.oms.opinsights.azure.com", "*.monitoring.azure.com", "api.loganalytics.io", "*.loganalytics.io", "js.monitor.azure.com", "*.monitor.azure.com"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = true
              protocols             = [{ type = "Https", port = 443 }]
            },
            {
              name                  = "r-allow-office365"
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_fqdns     = ["*.office.com", "*.office365.com", "*.outlook.com", "*.sharepoint.com", "*.onedrive.com", "*.teams.microsoft.com"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = true
              protocols             = [{ type = "Https", port = 443 }]
            },
            {
              name                  = "r-allow-app-insights"
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_fqdns     = ["*.applicationinsights.azure.com"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = true
              protocols             = [{ type = "Https", port = 443 }]
            },
            {
              name                  = "r-allow-cops-nonprod-apple-api"
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-nonprod-cops-apps"].resource_id]
              destination_fqdns     = ["api.push.apple.com", "api.sandbox.push.apple.com"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = false
              protocols             = [{ type = "Https", port = 443 }]
            },
            {
              name                  = "r-allow-ms-build-tools"
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_fqdns     = ["*akamaitechnologies.com", "akamaized.net", "go.microsoft.com", "aka.ms", "download.visualstudio.microsoft.com", "download.microsoft.com", "download.visualstudio.com", "marketplace.visualstudio.com", "*.gallerycdn.vsassets.io", "visualstudio.microsoft.com", "learn.microsoft.com", "msdn.microsoft.com", "www.microsoft.com", "*.windows.net", "*.microsoftonline.com", "*.live.com", "github-releases.githubusercontent.com", "objects.githubusercontent.com", "github.com", "az837173.vo.msecnd.net"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = false
              protocols             = [{ type = "Https", port = 443 }]
            },
          ]
        },
        {
          name     = "rc-allow-fqdnbased-app-services"
          priority = 850
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-cyberark-https"
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cyberark-vm-ips"].resource_id]
              destination_fqdns     = ["*.cyberark.cloud", "*.cyberark.com", "*.privilegecloud.cyberark.cloud", "*.dpa.cyberark.cloud", "*.bc.be-privilege-access.cyberark.cloud", "*.s3.amazonaws.com", "*.s3.ca-central-1.amazonaws.com", "*.ca-central-1.amazonaws.com", "*.iot.ca-central-1.amazonaws.com", "component-registry-store-490081306957.s3.amazonaws.com", "caintegrations.s3.amazonaws.com", "connector-management-scripts-490081306957-ca-central-1.s3.amazonaws.com", "connector-management-assets-490081306957-ca-central-1.s3.amazonaws.com", "cms-assets-bucket-445444212982.s3.amazonaws.com", "cms-assets-bucket-445444212982-ca-central-1.s3.ca-central-1.amazonaws.com", "casoftware.s3.amazonaws.com", "community.cyberark.com", "ca-central-1.bc.be-privilege-access.cyberark.cloud", "dogwood.cyberark.cloud", "dogwood.privilegecloud.cyberark.cloud", "webaccess-dogwood.privilegecloud.cyberark.cloud", "dogwood.webaccess.cyberark.cloud", "dogwood.connectormanagement.cyberark.cloud", "connector-dogwood.privilegecloud.cyberark.cloud", "console.privilegecloud.cyberark.cloud", "dogwood.dpa.cyberark.cloud", "a3vvqcp8z371p3-ats.iot.ca-central-1.amazonaws.com", "a2m4b3cupk8nzj-ats.iot.ca-central-1.amazonaws.com", "pod1402-b1.relay.idaptive.app", "pod1402-b2.relay.idaptive.app", "pod1402-a1.relay.idaptive.app", "pod1402-a2.relay.idaptive.app", "pod0.idaptive.app", "edge.idaptive.app", "ip-ranges.amazonaws.com", "*.relay.idaptive.app", "*.idaptive.app", "*.webaccess.cyberark.cloud", "*.connectormanagement.cyberark.cloud"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = false
              protocols             = [{ type = "Https", port = 443 }]
            },
            {
              name                  = "r-allpw-hosted-runners-to-fit-apps"
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_fqdns     = ["*.appserviceenvironment.net"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = true
              protocols             = [{ type = "Http", port = 80 }, { type = "Https", port = 443 }]
            },
            {
              name                  = "r-allow-cyberark-http"
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cyberark-vm-ips"].resource_id]
              destination_fqdns     = ["crt.r2m02.amazontrust.com", "ocsp.r2m02.amazontrust.com", "privacy-policy.truste.com", "ocsp.verisign.com", "ocsp.globalsign.com", "crl.globalsign.com", "secure.globalsign.com", "ipinfo.io"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = false
              protocols             = [{ type = "Http", port = 80 }]
            },
          ]
        },
      ]
    },
    "azfwpol-connectivity-001-BACKUP-20260320-233016-UTC/rcg-800-global-internet-baseline" = {
      name       = "rcg-800-global-internet-baseline"
      policy_key = "azfwpol-connectivity-001-BACKUP-20260320-233016-UTC"
      priority   = 800
      network_rule_collections = [
        {
          name     = "rc-allow-tagbased-services"
          priority = 820
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-azure-services"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = ["AzurePortal", "AzureCloud", "LogicApps", "AzureFrontDoor.Frontend", "AzureFrontDoor.FirstParty", "AzureFrontDoor.Backend", "AzureFrontDoor.Infra", "AzureFrontDoor.MicrosoftSecurity", "AzureActiveDirectory", "AzureResourceManager", "AppService", "Storage", "AzureKeyVault", "AppConfiguration"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443", "445"]
            },
            {
              name                  = "r-allow-azure-monitor"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = ["AzureMonitor", "AzureSentinel", "KustoAnalytics", "ActionGroup", "LogicAppsManagement", "AppServiceManagement"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-sql-services"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = ["Sql", "SqlManagement"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-allow-ipbased-services"
          priority = 810
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-ntp"
              protocols             = ["UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = ["168.61.215.74"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["123"]
            },
            {
              name                  = "r-allow-dns-inbound"
              protocols             = ["UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-infoblox"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-clz-dns-resolvers"].resource_id]
              destination_ports     = ["53"]
            },
            {
              name                  = "r-allow-dns-outbound"
              protocols             = ["UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-onprem-controllers"].resource_id]
              destination_ports     = ["53"]
            },
            {
              name                  = "r-allow-dns-azure"
              protocols             = ["UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-clz-dns-resolvers"].resource_id]
              destination_ports     = ["53"]
            },
            {
              name                  = "r-allow-github-actions"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = ["4.175.114.51/32", "20.102.35.120/32", "4.175.114.43/32", "20.72.125.48/32", "20.19.5.100/32", "20.7.92.46/32", "20.232.252.48/32", "52.186.44.51/32", "20.22.98.201/32", "20.246.184.240/32", "20.96.133.71/32", "20.253.2.203/32", "20.102.39.220/32", "20.81.127.181/32", "52.148.30.208/32", "20.14.42.190/32", "20.85.159.192/32", "52.224.205.173/32", "20.118.176.156/32", "20.236.207.188/32", "20.242.161.191/32", "20.166.216.139/32", "20.253.126.26/32", "52.152.245.137/32", "40.118.236.116/32", "20.185.75.138/32", "20.96.226.211/32", "52.167.78.33/32", "20.105.13.142/32", "20.253.95.3/32", "20.221.96.90/32", "51.138.235.85/32", "52.186.47.208/32", "20.7.220.66/32", "20.75.4.210/32", "20.120.75.171/32", "20.98.183.48/32", "20.84.200.15/32", "20.14.235.135/32", "20.10.226.54/32", "20.22.166.15/32", "20.65.21.88/32", "20.102.36.236/32", "20.124.56.57/32", "20.94.100.174/32", "20.102.166.33/32", "20.31.193.160/32", "20.232.77.7/32", "20.102.38.122/32", "20.102.39.57/32", "20.85.108.33/32", "40.88.240.168/32", "20.69.187.19/32", "20.246.192.124/32", "20.4.161.108/32", "20.22.22.84/32", "20.1.250.47/32", "20.237.33.78/32", "20.242.179.206/32", "40.88.239.133/32", "20.121.247.125/32", "20.106.107.180/32", "20.22.118.40/32", "20.15.240.48/32", "20.84.218.150/32"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-github"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = ["140.82.112.0/20", "143.55.64.0/20", "185.199.108.0/22", "192.30.252.0/22", "20.175.192.146/32", "20.175.192.147/32", "20.175.192.149/32", "20.175.192.150/32", "20.199.39.227/32", "20.199.39.228/32", "20.199.39.231/32", "20.199.39.232/32", "20.200.245.241/32", "20.200.245.245/32", "20.200.245.246/32", "20.200.245.247/32", "20.200.245.248/32", "20.201.28.144/32", "20.201.28.148/32", "20.201.28.149/32", "20.201.28.151/32", "20.201.28.152/32", "20.205.243.160/32", "20.205.243.164/32", "20.205.243.165/32", "20.205.243.166/32", "20.205.243.168/32", "20.207.73.82/32", "20.207.73.83/32", "20.207.73.85/32", "20.207.73.86/32", "20.207.73.88/32", "20.217.135.1/32", "20.233.83.145/32", "20.233.83.146/32", "20.233.83.147/32", "20.233.83.149/32", "20.233.83.150/32", "20.248.137.48/32", "20.248.137.49/32", "20.248.137.50/32", "20.248.137.52/32", "20.248.137.55/32", "20.26.156.215/32", "20.26.156.216/32", "20.26.156.211/32", "20.27.177.113/32", "20.27.177.114/32", "20.27.177.116/32", "20.27.177.117/32", "20.27.177.118/32", "20.29.134.17/32", "20.29.134.18/32", "20.29.134.19/32", "20.29.134.23/32", "20.29.134.24/32", "20.87.245.0/32", "20.87.245.1/32", "20.87.245.4/32", "20.87.245.6/32", "20.87.245.7/32", "4.208.26.196/32", "4.208.26.197/32", "4.208.26.198/32", "4.208.26.199/32", "4.208.26.200/32", "4.225.11.196/32", "4.237.22.32/32"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-allow-fqdnbased-services"
          priority = 830
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-microsoft-nuget"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["dotnet.microsoft.com", "download.microsoft.com", "api.nuget.org", "www.nuget.org", "nuget.org", "azuresearch-usnc.nuget.org", "azuresearch-ussc.nuget.org", "licenses.nuget.org", "nuget.cdn.azure.cn", "azuresearch-ea.nuget.org", "azuresearch-sea.nuget.org", "crl3.digicert.com", "crl4.digicert.com", "ocsp.digicert.com", "cacerts.digicert.com", "registry.npmjs.org", "nodejs.org", "dist.nuget.org", "skimdb.npmjs.com", "api.npms.io", "eslint.org", "gradle.org"]
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-smsgateway"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["secure.smsgateway.ca"]
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-servicenow"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["bchydrodev.service-now.com", "bchydroqa.service-now.com", "bchydrouat.service-now.com", "bchydro.service-now.com"]
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-windows-update"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["windowsupdate.microsoft.com", "windowsupdate.microsoft.com", "update.microsoft.com", "windowsupdate.com", "download.windowsupdate.com", "download.microsoft.com", "wustat.windows.com", "ntservicepack.microsoft.com"]
              destination_ip_groups = []
              destination_ports     = ["80", "443"]
            },
            {
              name                  = "r-allow-ntp"
              protocols             = ["UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["time.windows.com"]
              destination_ip_groups = []
              destination_ports     = ["123"]
            },
          ]
        },
      ]
      application_rule_collections = [
        {
          name     = "rc-allow-microsoft-services"
          priority = 840
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-windows-update"
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_fqdns     = ["windowsupdate.microsoft.com", "*.windowsupdate.microsoft.com", "update.microsoft.com", "*.update.microsoft.com", "windowsupdate.com", "*.windowsupdate.com", "download.windowsupdate.com", "*.download.windowsupdate.com", "download.microsoft.com", "wustat.windows.com", "*.wustat.windows.com", "ntservicepack.microsoft.com", "*.delivery.mp.microsoft.com", "*.microsoft.com", "*.windows.com"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = false
              protocols             = [{ type = "Https", port = 443 }, { type = "Http", port = 80 }]
            },
            {
              name                  = "r-allow-azure-services"
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_fqdns     = ["*.azure.com", "*.microsoft.com", "*.azure.net", "*.azurewebsites.net", "*.blob.core.windows.net", "*.queue.core.windows.net", "*.table.core.windows.net"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = true
              protocols             = [{ type = "Https", port = 443 }]
            },
            {
              name                  = "r-allow-azure-monitor"
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_fqdns     = ["*.ods.opinsights.azure.com", "*.oms.opinsights.azure.com", "*.monitoring.azure.com", "api.loganalytics.io", "*.loganalytics.io", "js.monitor.azure.com", "*.monitor.azure.com"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = true
              protocols             = [{ type = "Https", port = 443 }]
            },
            {
              name                  = "r-allow-office365"
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_fqdns     = ["*.office.com", "*.office365.com", "*.outlook.com", "*.sharepoint.com", "*.onedrive.com", "*.teams.microsoft.com"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = true
              protocols             = [{ type = "Https", port = 443 }]
            },
            {
              name                  = "r-allow-app-insights"
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_fqdns     = ["*.applicationinsights.azure.com"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = true
              protocols             = [{ type = "Https", port = 443 }]
            },
            {
              name                  = "r-allow-cops-nonprod-apple-api"
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-nonprod-cops-apps"].resource_id]
              destination_fqdns     = ["api.push.apple.com", "api.sandbox.push.apple.com"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = false
              protocols             = [{ type = "Https", port = 443 }]
            },
            {
              name                  = "r-allow-ms-build-tools"
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_fqdns     = ["*akamaitechnologies.com", "akamaized.net", "go.microsoft.com", "aka.ms", "download.visualstudio.microsoft.com", "download.microsoft.com", "download.visualstudio.com", "marketplace.visualstudio.com", "*.gallerycdn.vsassets.io", "visualstudio.microsoft.com", "learn.microsoft.com", "msdn.microsoft.com", "www.microsoft.com", "*.windows.net", "*.microsoftonline.com", "*.live.com", "github-releases.githubusercontent.com", "objects.githubusercontent.com", "github.com", "az837173.vo.msecnd.net"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = false
              protocols             = [{ type = "Https", port = 443 }]
            },
          ]
        },
        {
          name     = "rc-allow-fqdnbased-app-services"
          priority = 850
          action   = "Allow"
          rules = [
            {
              name                  = "r-allow-cyberark-https"
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cyberark-vm-ips"].resource_id]
              destination_fqdns     = ["*.cyberark.cloud", "*.cyberark.com", "*.privilegecloud.cyberark.cloud", "*.dpa.cyberark.cloud", "*.bc.be-privilege-access.cyberark.cloud", "*.s3.amazonaws.com", "*.s3.ca-central-1.amazonaws.com", "*.ca-central-1.amazonaws.com", "*.iot.ca-central-1.amazonaws.com", "component-registry-store-490081306957.s3.amazonaws.com", "caintegrations.s3.amazonaws.com", "connector-management-scripts-490081306957-ca-central-1.s3.amazonaws.com", "connector-management-assets-490081306957-ca-central-1.s3.amazonaws.com", "cms-assets-bucket-445444212982.s3.amazonaws.com", "cms-assets-bucket-445444212982-ca-central-1.s3.ca-central-1.amazonaws.com", "casoftware.s3.amazonaws.com", "community.cyberark.com", "ca-central-1.bc.be-privilege-access.cyberark.cloud", "dogwood.cyberark.cloud", "dogwood.privilegecloud.cyberark.cloud", "webaccess-dogwood.privilegecloud.cyberark.cloud", "dogwood.webaccess.cyberark.cloud", "dogwood.connectormanagement.cyberark.cloud", "connector-dogwood.privilegecloud.cyberark.cloud", "console.privilegecloud.cyberark.cloud", "dogwood.dpa.cyberark.cloud", "a3vvqcp8z371p3-ats.iot.ca-central-1.amazonaws.com", "a2m4b3cupk8nzj-ats.iot.ca-central-1.amazonaws.com", "pod1402-b1.relay.idaptive.app", "pod1402-b2.relay.idaptive.app", "pod1402-a1.relay.idaptive.app", "pod1402-a2.relay.idaptive.app", "pod0.idaptive.app", "edge.idaptive.app", "ip-ranges.amazonaws.com", "*.relay.idaptive.app", "*.idaptive.app", "*.webaccess.cyberark.cloud", "*.connectormanagement.cyberark.cloud"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = false
              protocols             = [{ type = "Https", port = 443 }]
            },
            {
              name                  = "r-allpw-hosted-runners-to-fit-apps"
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_fqdns     = ["*.appserviceenvironment.net"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = true
              protocols             = [{ type = "Http", port = 80 }, { type = "Https", port = 443 }]
            },
            {
              name                  = "r-allow-cyberark-http"
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cyberark-vm-ips"].resource_id]
              destination_fqdns     = ["crt.r2m02.amazontrust.com", "ocsp.r2m02.amazontrust.com", "privacy-policy.truste.com", "ocsp.verisign.com", "ocsp.globalsign.com", "crl.globalsign.com", "secure.globalsign.com", "ipinfo.io"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = false
              protocols             = [{ type = "Http", port = 80 }]
            },
          ]
        },
      ]
    }
  }
}

module "firewall" {
  for_each = var.enable_firewall ? local.firewalls : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-azure-firewall/azurerm"
  version = "0.1.0" # TODO confirm version

  name                = each.key
  resource_group_name = module.resource_group[each.value.rg_key].name
  location            = each.value.location
  firewall_sku_name   = each.value.sku_name
  firewall_sku_tier   = each.value.sku_tier

  firewall_policy_id                   = each.value.firewall_policy_id
  firewall_zones                       = each.value.zones
  firewall_virtual_hub                 = each.value.virtual_hub
  ip_configurations                    = each.value.ip_configurations
  firewall_management_ip_configuration = each.value.management_ip_configuration

  tags = local.common_tags
}

module "firewall_policy" {
  for_each = var.enable_firewall ? local.firewall_policies : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-azure-firewall-policy/azurerm"
  version = "0.1.0" # TODO confirm version

  name                = each.key
  resource_group_name = module.resource_group["hub_cc"].name
  location            = each.value.location

  firewall_policy_sku                      = each.value.sku
  firewall_policy_threat_intelligence_mode = each.value.threat_intelligence_mode
  firewall_policy_dns                      = each.value.dns
  firewall_policy_intrusion_detection      = each.value.intrusion_detection
  firewall_policy_identity                 = each.value.identity
  firewall_policy_insights                 = each.value.insights
  firewall_policy_tls_certificate          = each.value.tls_certificate

  tags = local.common_tags
}

resource "azurerm_firewall_policy_rule_collection_group" "this" {
  for_each = var.enable_firewall ? local.firewall_rule_collection_groups : {}

  name               = each.value.name
  firewall_policy_id = module.firewall_policy[each.value.policy_key].resource_id
  priority           = each.value.priority

  dynamic "network_rule_collection" {
    for_each = each.value.network_rule_collections
    content {
      name     = network_rule_collection.value.name
      priority = network_rule_collection.value.priority
      action   = network_rule_collection.value.action

      dynamic "rule" {
        for_each = network_rule_collection.value.rules
        content {
          name                  = rule.value.name
          protocols             = rule.value.protocols
          source_addresses      = rule.value.source_addresses
          source_ip_groups      = rule.value.source_ip_groups
          destination_addresses = rule.value.destination_addresses
          destination_fqdns     = rule.value.destination_fqdns
          destination_ip_groups = rule.value.destination_ip_groups
          destination_ports     = rule.value.destination_ports
        }
      }
    }
  }

  dynamic "application_rule_collection" {
    for_each = each.value.application_rule_collections
    content {
      name     = application_rule_collection.value.name
      priority = application_rule_collection.value.priority
      action   = application_rule_collection.value.action

      dynamic "rule" {
        for_each = application_rule_collection.value.rules
        content {
          name                  = rule.value.name
          source_addresses      = rule.value.source_addresses
          source_ip_groups      = rule.value.source_ip_groups
          destination_fqdns     = rule.value.destination_fqdns
          destination_urls      = rule.value.destination_urls
          destination_fqdn_tags = rule.value.destination_fqdn_tags
          web_categories        = rule.value.web_categories
          terminate_tls         = rule.value.terminate_tls

          dynamic "protocols" {
            for_each = rule.value.protocols
            content {
              type = protocols.value.type
              port = protocols.value.port
            }
          }
        }
      }
    }
  }
}
