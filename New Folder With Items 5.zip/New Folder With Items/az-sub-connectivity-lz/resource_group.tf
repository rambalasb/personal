# resource_group.tf
# Dependencies: none — resource groups deploy first.

module "resource_group" {
  for_each = var.enable_resource_group ? var.resource_group : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-resource-group/azurerm"
  version = "2.0.0"

  name     = each.value.name
  location = coalesce(each.value.location, var.location)
  tags     = merge(local.common_tags, each.value.tags)
}
