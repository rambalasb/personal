output "resource_group_ids" {
  description = "Resource group IDs, keyed by role."
  value       = { for k, m in module.resource_group : k => m.resource_id }
}
