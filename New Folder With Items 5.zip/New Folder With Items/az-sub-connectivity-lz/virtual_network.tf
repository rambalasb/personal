# virtual_network.tf
# 8 virtual networks across cyberark, dmz, dns, ertest (cc/ce), runners, and shared (transit + shared).
# Subnet NSG/NAT references co-locate in the vnet's own RG unless the source id said otherwise.
# service_endpoints map to the wrapper's service_endpoints_with_location input.

locals {
  # vhub-connectivity-canadacentral hub vnet (vWAN) — resolved from rg-dns peering source id.
  vhub_cc_id = "/subscriptions/a7649084-9747-497e-b98e-66a9f81a36b5/resourceGroups/RG_vhub-connectivity-canadacentral-001_d3fafbbc-b650-4a3f-87fc-e6d91f22b076/providers/Microsoft.Network/virtualNetworks/HV_vhub-connectivity-ca_22adadaa-e038-4ede-bc41-6fbfc755c2ca"

  virtual_network_data = {
    "vnet-cyberark-canadacentral-001" = {
      resource_group_key = "cyberark"
      location           = "canadacentral"
      address_space      = ["10.195.116.0/26"]
      subnets = {
        "snet-cyberark-servers-canadacentral-001" = {
          name           = "snet-cyberark-servers-canadacentral-001"
          address_prefix = "10.195.116.0/27"
          network_security_group = {
            id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-cyberark-servers-canadacentral-001"
          }
          nat_gateway = {
            id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Network/natGateways/ngw-cyberark-connectivity-canadacentral-001"
          }
          private_endpoint_network_policies = "Disabled"
          service_endpoints_with_location = [
            { service = "Microsoft.Storage", locations = ["canadacentral", "canadaeast"] }
          ]
        }
      }
      peerings = {
        "RemoteVnetToHubPeering_a8db0ae7-e4bd-4112-a74f-86be5b004e19" = {
          name                               = "RemoteVnetToHubPeering_a8db0ae7-e4bd-4112-a74f-86be5b004e19"
          remote_virtual_network_resource_id = local.vhub_cc_id
          allow_forwarded_traffic            = false
          allow_gateway_transit              = false
          allow_virtual_network_access       = true
          use_remote_gateways                = true
        }
      }
    }

    "vnet-dmz-external-connectivity-canadacentral-001" = {
      resource_group_key = "dmz"
      location           = "canadacentral"
      address_space      = ["10.195.8.0/23"]
      subnets = {
        "snet-dmz-gw-prod-canadacentral-001" = {
          name                              = "snet-dmz-gw-prod-canadacentral-001"
          address_prefixes                  = ["10.195.8.0/24"]
          private_endpoint_network_policies = "Disabled"
        }
        "snet-dmz-gw-nonprod-canadacentral-001" = {
          name                              = "snet-dmz-gw-nonprod-canadacentral-001"
          address_prefixes                  = ["10.195.9.0/24"]
          private_endpoint_network_policies = "Disabled"
        }
      }
      peerings = {}
    }

    "vnet-dns-connectivity-canadacentral-001" = {
      resource_group_key = "dns"
      location           = "canadacentral"
      address_space      = ["10.195.4.0/22"]
      subnets = {
        "snet-dns-inbound-canadacentral-001" = {
          name           = "snet-dns-inbound-canadacentral-001"
          address_prefix = "10.195.4.0/25"
          network_security_group = {
            id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-dns-inbound-canadacentral-001"
          }
          private_endpoint_network_policies = "Disabled"
          delegations = [
            { name = "inboundDelegation", service_delegation = { name = "Microsoft.Network/dnsResolvers" } }
          ]
        }
        "snet-dns-outbound-canadacentral-001" = {
          name           = "snet-dns-outbound-canadacentral-001"
          address_prefix = "10.195.5.0/25"
          network_security_group = {
            id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-dns-outbound-canadacentral-001"
          }
          private_endpoint_network_policies = "Disabled"
          delegations = [
            { name = "outboundDelegation", service_delegation = { name = "Microsoft.Network/dnsResolvers" } }
          ]
        }
        "snet-dns-private-endpoint-canadacentral-001" = {
          name           = "snet-dns-private-endpoint-canadacentral-001"
          address_prefix = "10.195.6.0/23"
          network_security_group = {
            id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-dns-private-endpoint-canadacentral-001"
          }
          private_endpoint_network_policies = "NetworkSecurityGroupEnabled"
        }
      }
      peerings = {
        "RemoteVnetToHubPeering_a8db0ae7-e4bd-4112-a74f-86be5b004e19" = {
          name                               = "RemoteVnetToHubPeering_a8db0ae7-e4bd-4112-a74f-86be5b004e19"
          remote_virtual_network_resource_id = local.vhub_cc_id
          allow_forwarded_traffic            = false
          allow_gateway_transit              = false
          allow_virtual_network_access       = true
          use_remote_gateways                = true
        }
        "peer-clz-to-mvp" = {
          name                               = "peer-clz-to-mvp"
          remote_virtual_network_resource_id = "/subscriptions/68a7a148-af69-4081-9864-7dc37b9a6c85/resourceGroups/RG-SharedServices-Network-Prod/providers/Microsoft.Network/virtualNetworks/vnet-shared-canadacentral-001"
          allow_forwarded_traffic            = true
          allow_gateway_transit              = false
          allow_virtual_network_access       = true
          use_remote_gateways                = false
        }
      }
    }

    "vnet-ertest-canadacentral-001" = {
      resource_group_key = "ertest_cc"
      location           = "canadacentral"
      address_space      = ["10.195.118.0/23"]
      subnets = {
        "snet-ertest-canadacentral-001" = {
          name           = "snet-ertest-canadacentral-001"
          address_prefix = "10.195.118.0/27"
          network_security_group = {
            id = "${local.sub}/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-ertest-canadacentral-001"
          }
          private_endpoint_network_policies = "Disabled"
          service_endpoints_with_location = [
            { service = "Microsoft.Storage", locations = ["canadacentral", "canadaeast"] }
          ]
        }
      }
      peerings = {
        "RemoteVnetToHubPeering_a8db0ae7-e4bd-4112-a74f-86be5b004e19" = {
          name                               = "RemoteVnetToHubPeering_a8db0ae7-e4bd-4112-a74f-86be5b004e19"
          remote_virtual_network_resource_id = local.vhub_cc_id
          allow_forwarded_traffic            = false
          allow_gateway_transit              = false
          allow_virtual_network_access       = true
          use_remote_gateways                = true
        }
      }
    }

    "vnet-ertest-canadaeast-001" = {
      resource_group_key = "ertest_ce"
      location           = "canadaeast"
      address_space      = ["10.196.114.0/23"]
      subnets = {
        "snet-ertest-canadaeast-001" = {
          name           = "snet-ertest-canadaeast-001"
          address_prefix = "10.196.114.0/27"
          network_security_group = {
            id = "${local.sub}/resourceGroups/rg-ertest-canadaeast-001/providers/Microsoft.Network/networkSecurityGroups/nsg-ertest-canadaeast-001"
          }
          private_endpoint_network_policies = "Disabled"
        }
      }
      peerings = {
        "RemoteVnetToHubPeering_38d55ab0-6c38-42de-bbf1-330ef44c8e89" = {
          name = "RemoteVnetToHubPeering_38d55ab0-6c38-42de-bbf1-330ef44c8e89"
          # TODO confirm canadaeast vhub RG guid — external vWAN hub, RG name not in export
          remote_virtual_network_resource_id = "/subscriptions/a7649084-9747-497e-b98e-66a9f81a36b5/resourceGroups/RG_vhub-connectivity-canadaeast-001_TODO/providers/Microsoft.Network/virtualNetworks/HV_vhub-connectivity-ca_717641f4-fd7d-4fd9-aa0c-b5fc67d419a6"
          allow_forwarded_traffic            = false
          allow_gateway_transit              = false
          allow_virtual_network_access       = true
          use_remote_gateways                = true
        }
      }
    }

    "vnet-runners-connectivity-canadacentral-001" = {
      resource_group_key = "runners"
      location           = "canadacentral"
      address_space      = ["10.195.114.0/23"]
      subnets = {
        "snet-runners-dev-canadacentral-001" = {
          name           = "snet-runners-dev-canadacentral-001"
          address_prefix = "10.195.114.0/27"
          network_security_group = {
            id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-runners-dev-canadacentral-001"
          }
          nat_gateway = {
            id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/natGateways/ngw-runners-connectivity-canadacentral-001"
          }
          private_endpoint_network_policies = "Disabled"
          delegations = [
            { name = "GitHub.Network/networkSettings", service_delegation = { name = "GitHub.Network/networkSettings" } }
          ]
          service_endpoints_with_location = [
            { service = "Microsoft.Storage", locations = ["canadacentral", "canadaeast"] },
            { service = "Microsoft.KeyVault", locations = ["*"] }
          ]
        }
        "snet-runners-prod-canadacentral-001" = {
          name           = "snet-runners-prod-canadacentral-001"
          address_prefix = "10.195.115.0/27"
          network_security_group = {
            id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-runners-prod-canadacentral-001"
          }
          nat_gateway = {
            id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/natGateways/ngw-runners-connectivity-canadacentral-001"
          }
          private_endpoint_network_policies = "Disabled"
          delegations = [
            { name = "GitHub.Network/networkSettings", service_delegation = { name = "GitHub.Network/networkSettings" } }
          ]
          service_endpoints_with_location = [
            { service = "Microsoft.Storage", locations = ["canadacentral", "canadaeast"] }
          ]
        }
        "AzureBastionSubnet" = {
          name           = "AzureBastionSubnet"
          address_prefix = "10.195.114.128/26"
          network_security_group = {
            id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-bh-canadacentral-001"
          }
          private_endpoint_network_policies = "Disabled"
          delegations = [
            { name = "delegation", service_delegation = { name = "Microsoft.Web/serverfarms" } }
          ]
          service_endpoints_with_location = [
            { service = "Microsoft.Storage", locations = ["canadacentral", "canadaeast"] }
          ]
        }
      }
      peerings = {
        "RemoteVnetToHubPeering_a8db0ae7-e4bd-4112-a74f-86be5b004e19" = {
          name                               = "RemoteVnetToHubPeering_a8db0ae7-e4bd-4112-a74f-86be5b004e19"
          remote_virtual_network_resource_id = local.vhub_cc_id
          allow_forwarded_traffic            = false
          allow_gateway_transit              = false
          allow_virtual_network_access       = true
          use_remote_gateways                = true
        }
      }
    }

    "vnet-transit-connectivity-canadacentral-001" = {
      resource_group_key = "shared_cc"
      location           = "canadacentral"
      address_space      = ["10.195.122.0/26", "10.195.122.64/26", "10.195.122.128/26"]
      subnets = {
        "AzureFirewallManagementSubnet" = {
          name                              = "AzureFirewallManagementSubnet"
          address_prefixes                  = ["10.195.122.64/26"]
          private_endpoint_network_policies = "Disabled"
        }
        "AzureFirewallSubnet" = {
          name                              = "AzureFirewallSubnet"
          address_prefixes                  = ["10.195.122.0/26"]
          private_endpoint_network_policies = "Disabled"
        }
      }
      peerings = {
        "peering-ns2-edge-to-bch-transit" = {
          name = "peering-ns2-edge-to-bch-transit"
          # TODO confirm remote id — external PCE edge vnet cre-s4-pce-customer0057-edge, sub/RG not in export (co-location assumed)
          remote_virtual_network_resource_id = "${local.sub}/resourceGroups/rg-shared-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/cre-s4-pce-customer0057-edge"
          allow_forwarded_traffic            = true
          allow_gateway_transit              = false
          allow_virtual_network_access       = true
          use_remote_gateways                = false
        }
        "RemoteVnetToHubPeering_a8db0ae7-e4bd-4112-a74f-86be5b004e19" = {
          name                               = "RemoteVnetToHubPeering_a8db0ae7-e4bd-4112-a74f-86be5b004e19"
          remote_virtual_network_resource_id = local.vhub_cc_id
          allow_forwarded_traffic            = false
          allow_gateway_transit              = false
          allow_virtual_network_access       = true
          use_remote_gateways                = true
        }
      }
    }

    "vnet-shared-connectivity-canadacentral-001" = {
      resource_group_key = "shared_cc"
      location           = "canadacentral"
      address_space      = ["10.195.117.0/24"]
      subnets = {
        "snet-outbound-connectivity-canadacentral-001" = {
          name             = "snet-outbound-connectivity-canadacentral-001"
          address_prefixes = ["10.195.117.0/25"]
          network_security_group = {
            id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/networkSecurityGroups/nsg-dns-outbound-canadacentral-001"
          }
          nat_gateway = {
            id = "${local.sub}/resourceGroups/rg-shared-connectivity-canadacentral-001/providers/Microsoft.Network/natGateways/ngw-shared-connectivity-canadacentral-001"
          }
          private_endpoint_network_policies = "Disabled"
          delegations = [
            { name = "delegation", service_delegation = { name = "Microsoft.Web/serverfarms" } }
          ]
          service_endpoints_with_location = [
            { service = "Microsoft.Storage", locations = ["canadacentral", "canadaeast"] }
          ]
        }
      }
      peerings = {
        "RemoteVnetToHubPeering_a8db0ae7-e4bd-4112-a74f-86be5b004e19" = {
          name                               = "RemoteVnetToHubPeering_a8db0ae7-e4bd-4112-a74f-86be5b004e19"
          remote_virtual_network_resource_id = local.vhub_cc_id
          allow_forwarded_traffic            = false
          allow_gateway_transit              = false
          allow_virtual_network_access       = true
          use_remote_gateways                = true
        }
      }
    }
  }
}

module "virtual_network" {
  for_each = local.virtual_network_data

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-virtual-network/azurerm"
  version = "0.1.0" # TODO confirm published wrapper version

  name          = each.key
  parent_id     = module.resource_group[each.value.resource_group_key].resource_id
  location      = each.value.location
  address_space = each.value.address_space
  subnets       = each.value.subnets
  peerings      = each.value.peerings
  tags          = local.common_tags
}
