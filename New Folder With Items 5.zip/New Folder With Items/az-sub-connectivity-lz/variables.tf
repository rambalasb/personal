# =====================================================================
# Shared inputs. subscription_id / tenant_id come from the provider
# environment (ARM_SUBSCRIPTION_ID / ARM_TENANT_ID).
#
# NOTE: connectivity is a large, multi-region (canadacentral + canadaeast)
# hub-and-spoke sub. This scaffolds the resource groups + the alerts tier
# (rg-alerts-connectivity). Networking/compute tiers (hub, shared, dns, dmz,
# ip-groups, ertest, runners, cyberark) are added as their exports come in.
# =====================================================================

variable "environment" {
  type    = string
  default = "prod"
}

variable "location" {
  type    = string
  default = "canadacentral"
}

variable "tags" {
  type    = map(string)
  default = {}
}

variable "enable_amba" {
  type    = bool
  default = false
}

variable "root_management_group_name" {
  type    = string
  default = null
}

# --- Feature flags ------------------------------------------------------
variable "enable_resource_group" {
  type    = bool
  default = false
}

variable "enable_monitoring" {
  type        = bool
  description = "Deploy alerts via the amba-alz wrapper (action groups are external, in the management sub)."
  default     = false
}

# --- Resource groups ----------------------------------------------------
variable "resource_group" {
  type = map(object({
    name     = string
    location = optional(string)
    tags     = optional(map(string), {})
  }))
  default = {}
}
