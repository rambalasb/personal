# imports_dns_resolver.tf — 1 resolver + inbound/outbound endpoints + forwarding ruleset
# confirm AVM internal import addresses on first plan

import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver.this
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsResolvers/pdr-connectivity-canadacentral-001"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_inbound_endpoint.this["pdr-inbound-connectivity-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsResolvers/pdr-connectivity-canadacentral-001/inboundEndpoints/pdr-inbound-connectivity-canadacentral-001"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_outbound_endpoint.this["pdr-outbound-connectivity-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsResolvers/pdr-connectivity-canadacentral-001/outboundEndpoints/pdr-outbound-connectivity-canadacentral-001"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_dns_forwarding_ruleset.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001"
}
