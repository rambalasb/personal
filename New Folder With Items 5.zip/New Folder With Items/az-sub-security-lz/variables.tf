# =====================================================================
# 1. Shared inputs. subscription_id / tenant_id come from the provider
#    environment (ARM_SUBSCRIPTION_ID / ARM_TENANT_ID).
# =====================================================================

variable "environment" {
  type        = string
  description = "Deployment environment label (e.g., prod, nonprod)."
}

variable "location" {
  type        = string
  description = "Default Azure region for resources that do not override it."
  default     = "canadacentral"
}

variable "tags" {
  type        = map(string)
  description = "Baseline tags merged onto every resource."
  default     = {}
}

variable "enable_amba" {
  type        = bool
  description = "Deploy the AMBA-ALZ baseline via the wrapper. Requires management-group permissions."
  default     = false
}

variable "root_management_group_name" {
  type        = string
  description = "ALZ intermediate root management group ID. Required only when enable_amba = true."
  default     = null
}

# =====================================================================
# 2. Feature flags.
# =====================================================================

variable "enable_resource_group" {
  type    = bool
  default = false
}

variable "enable_storage_account" {
  type    = bool
  default = false
}

variable "enable_log_analytics_workspace" {
  type    = bool
  default = false
}

variable "enable_monitoring" {
  type        = bool
  description = "Deploy the action group + alerts via the amba-alz wrapper."
  default     = false
}

variable "enable_network_watcher" {
  type    = bool
  default = false
}

variable "enable_event_grid_system_topic" {
  type    = bool
  default = false
}

variable "enable_workbooks" {
  type    = bool
  default = false
}

# =====================================================================
# 3. Resource maps.
# =====================================================================

variable "resource_group" {
  type = map(object({
    name     = string
    location = optional(string)
    tags     = optional(map(string), {})
  }))
  default = {}
}

variable "storage_account" {
  type = map(object({
    name                          = string
    resource_group_key            = string
    location                      = optional(string)
    account_kind                  = optional(string, "StorageV2")
    account_tier                  = optional(string, "Standard")
    account_replication_type      = optional(string, "LRS")
    access_tier                   = optional(string, "Hot")
    shared_access_key_enabled     = optional(bool, false)
    public_network_access_enabled = optional(bool, false)
    network_rules = optional(object({
      bypass                     = optional(set(string), ["AzureServices"])
      default_action             = optional(string, "Deny")
      ip_rules                   = optional(set(string), [])
      virtual_network_subnet_ids = optional(set(string), [])
      private_link_access = optional(list(object({
        endpoint_resource_id = string
        endpoint_tenant_id   = optional(string)
      })))
    }), {})
    tags = optional(map(string), {})
  }))
  default = {}
}

variable "log_analytics_workspace" {
  type = map(object({
    name               = string
    resource_group_key = string
    location           = optional(string)
    sku                = optional(string, "PerGB2018")
    retention_in_days  = optional(number, 30)
    daily_quota_gb     = optional(number, -1)
    tags               = optional(map(string), {})
  }))
  default = {}
}

variable "workbooks" {
  # Azure Workbooks — no AVM module; native azurerm_application_insights_workbook.
  # `data_json` (serialized content) is filled from -generate-config-out on adoption.
  type = map(object({
    name               = string # workbook resource name == its GUID
    display_name       = string
    resource_group_key = string
    location           = optional(string)
    category           = optional(string, "workbook")
    data_json          = optional(string, "{}")
    tags               = optional(map(string), {})
  }))
  default = {}
}
