# ── Shared ─────────────────────────────────────────────────────────────
# subscription_id / tenant_id come from ARM_SUBSCRIPTION_ID / ARM_TENANT_ID.
environment = "prod"
location    = "canadacentral"

tags = {
  owner = "security-platform"
}

enable_amba = false

# ── Feature flags ──────────────────────────────────────────────────────
enable_resource_group          = true
enable_storage_account         = true
enable_log_analytics_workspace = true
enable_monitoring              = true
enable_network_watcher         = true
enable_event_grid_system_topic = true
enable_workbooks               = true

# ── Resource groups ────────────────────────────────────────────────────
resource_group = {
  "alerts"       = { name = "rg-alerts-security-canadacentral-001" }
  "siem"         = { name = "rg-siem-security-canadacentral-001" }
  "shared"       = { name = "rg-shared-security-canadacentral-001" }
  "mdc_workbook" = { name = "rg-mdc-workbook-security-canadacentral-001" }
}

# ── Storage account ────────────────────────────────────────────────────
storage_account = {
  "nwsec" = {
    name                          = "stnwseccanadacentral"
    resource_group_key            = "shared"
    shared_access_key_enabled     = false
    public_network_access_enabled = true
    network_rules = {
      bypass         = ["AzureServices"]
      default_action = "Allow"
      private_link_access = [{
        endpoint_resource_id = "/subscriptions/7d54d6f7-83d9-48cf-ac35-1068bcfd0561/providers/Microsoft.Security/datascanners/StorageDataScanner"
        endpoint_tenant_id   = "8fbb85e8-0cbc-48c3-a2e9-528cef30ec27"
      }]
    }
  }
}

# ── Log Analytics workspace ────────────────────────────────────────────
log_analytics_workspace = {
  "siem" = {
    name               = "la-siem-security-canadacentral-001"
    resource_group_key = "siem"
    sku                = "PerGB2018"
    retention_in_days  = 90
    daily_quota_gb     = -1
  }
}

# ── Workbooks (data_json filled from -generate-config-out) ─────────────
workbooks = {
  "active_recommendations" = {
    name               = "0ea4e1c4-9d65-4038-818e-b8e345a1e021"
    display_name       = "Active Recommendations"
    resource_group_key = "mdc_workbook"
  }
  "analytics_health_audit" = {
    name               = "1606f749-f0b6-41e2-b8ba-daa714b6f6d2"
    display_name       = "Analytics Health & Audit - la-siem-security-canadacentral-001"
    resource_group_key = "siem"
  }
  "defender_plan_coverage" = {
    name               = "34d0e931-7394-46a5-951d-c4a4935e046b"
    display_name       = "Defender for Cloud Plan Coverage"
    resource_group_key = "siem"
  }
  "azure_firewall_logs" = {
    name               = "4801c93e-ec61-43ba-a9f9-ee9adac5c618"
    display_name       = "Azure Firewall Structured Logs - la-siem-security-canadacentral-001"
    resource_group_key = "siem"
  }
  "executive_dashboard" = {
    name               = "56d91105-ce64-4bb0-a8b7-3f48315e29b8"
    display_name       = "Executive Dashboard"
    resource_group_key = "siem"
  }
  "azure_activity" = {
    name               = "610ec12e-c6c7-4773-bc8b-c10909e60590"
    display_name       = "Azure Activity - la-siem-security-canadacentral-001"
    resource_group_key = "siem"
  }
  "sample_workbook" = {
    name               = "8bba610c-ab4f-4eac-9791-13e1456a2016"
    display_name       = "Sample Workbook"
    resource_group_key = "siem"
  }
  "data_collection_health" = {
    name               = "a1045f8c-7a8b-41f2-a5bb-fb7c3f3aa4e9"
    display_name       = "Data collection health monitoring - la-siem-security-canadacentral-001"
    resource_group_key = "siem"
  }
  "workspace_usage" = {
    name               = "c3b70cc3-1cac-4144-a253-95b59933799c"
    display_name       = "Workspace Usage Report - la-siem-security-canadacentral-001"
    resource_group_key = "siem"
  }
  "entra_signin_logs" = {
    name               = "c8fc48c2-6ff8-4736-8f31-74c55f7a21e0"
    display_name       = "Microsoft Entra ID Sign-in logs - la-siem-security-canadacentral-001"
    resource_group_key = "siem"
  }
  "defender_plans_coverage" = {
    name               = "cd8fde80-c274-479c-8cd2-71e0cdcc2074"
    display_name       = "Defender for Cloud Plans Coverage"
    resource_group_key = "mdc_workbook"
  }
  "keyvault_security" = {
    name               = "f5f514ac-3765-4d82-9100-29094bf5992e"
    display_name       = "Azure Key Vault Security - la-siem-security-canadacentral-001"
    resource_group_key = "siem"
  }
}
