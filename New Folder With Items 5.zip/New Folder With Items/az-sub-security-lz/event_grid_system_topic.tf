# event_grid_system_topic.tf
# Native + import: the AVM module (avm-res-eventgrid-systemtopic) has no released
# version yet. Import adopts the existing Azure-managed topic on the storage
# account instead of creating one.

resource "azurerm_eventgrid_system_topic" "storage" {
  for_each = var.enable_event_grid_system_topic ? toset(["nwsec"]) : toset([])

  name                = "stnwseccanadacentral-477e2d12-ef85-4555-ba6a-9f15e9b0a042"
  resource_group_name = module.resource_group["shared"].name
  location            = var.location
  source_resource_id  = module.storage_account["nwsec"].resource_id
  topic_type          = "microsoft.storage.storageaccounts"
  tags                = local.common_tags
}

import {
  for_each = var.enable_event_grid_system_topic ? toset(["nwsec"]) : toset([])

  to = azurerm_eventgrid_system_topic.storage[each.key]
  id = "${data.azurerm_subscription.current.id}/resourceGroups/rg-shared-security-canadacentral-001/providers/Microsoft.EventGrid/systemTopics/stnwseccanadacentral-477e2d12-ef85-4555-ba6a-9f15e9b0a042"
}
