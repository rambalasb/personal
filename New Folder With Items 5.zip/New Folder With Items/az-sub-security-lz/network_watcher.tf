# network_watcher.tf
# Native + import: the AVM module manages only flow logs / connection monitors on
# an existing watcher — it can't create the watcher itself. Import adopts it.

resource "azurerm_network_watcher" "security" {
  for_each = var.enable_network_watcher ? toset(["security"]) : toset([])

  name                = "NetworkWatcher_canadacentral_security"
  resource_group_name = module.resource_group["shared"].name
  location            = var.location
  tags                = local.common_tags
}

import {
  for_each = var.enable_network_watcher ? toset(["security"]) : toset([])

  to = azurerm_network_watcher.security[each.key]
  id = "${data.azurerm_subscription.current.id}/resourceGroups/rg-shared-security-canadacentral-001/providers/Microsoft.Network/networkWatchers/NetworkWatcher_canadacentral_security"
}
