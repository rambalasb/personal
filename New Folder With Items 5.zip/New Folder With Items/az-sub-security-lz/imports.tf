# imports.tf
# One-time adoption of existing Azure resources into the wrapper modules. Native
# resources (network watcher, event grid, workbooks) carry their own import
# blocks in their files.
#
# INTENTIONALLY NOT MANAGED (Azure / Sentinel / policy-created):
#   - Solutions on la-siem: BehaviorAnalyticsInsights, SecurityCenterFree,
#     SecurityInsights (gallery solutions enabled on the workspace)
#   - dcr-security-linux/windows-q5fz5il6qfnzw (AMA DINE-policy DCRs)
#   - dcr-security-windows-sentinel, dcr-windows-security-sentinel (createdBy=Sentinel)
#   - NWTA-9c9a382f-* data collection endpoints + rules (Traffic Analytics, auto-created)
#
# TODO: the LAW wrapper wraps an AVM module whose INTERNAL resource address must
# be confirmed (run plan and read the import error, or inspect the AVM module).

locals {
  sub = data.azurerm_subscription.current.id
}

# ── Resource groups (azapi, count -> this[0]) ──────────────────────────
import {
  to = module.resource_group["alerts"].module.resource_group.azapi_resource.this[0]
  id = "${local.sub}/resourceGroups/rg-alerts-security-canadacentral-001"
}
import {
  to = module.resource_group["siem"].module.resource_group.azapi_resource.this[0]
  id = "${local.sub}/resourceGroups/rg-siem-security-canadacentral-001"
}
import {
  to = module.resource_group["shared"].module.resource_group.azapi_resource.this[0]
  id = "${local.sub}/resourceGroups/rg-shared-security-canadacentral-001"
}
import {
  to = module.resource_group["mdc_workbook"].module.resource_group.azapi_resource.this[0]
  id = "${local.sub}/resourceGroups/rg-mdc-workbook-security-canadacentral-001"
}

# ── Storage account (azapi) ────────────────────────────────────────────
import {
  to = module.storage_account["nwsec"].module.storage_account.azapi_resource.this
  id = "${local.sub}/resourceGroups/rg-shared-security-canadacentral-001/providers/Microsoft.Storage/storageAccounts/stnwseccanadacentral"
}

# ── Log Analytics workspace (TODO confirm internal AVM address) ────────
import {
  to = module.log_analytics_workspace["siem"].module.log_analytics_workspace.azurerm_log_analytics_workspace.this
  id = "${local.sub}/resourceGroups/rg-siem-security-canadacentral-001/providers/Microsoft.OperationalInsights/workspaces/la-siem-security-canadacentral-001"
}

# ── Action group (amba-alz wrapper -> monitoring[0]) ───────────────────
import {
  to = module.monitoring[0].azurerm_monitor_action_group.this["sentinel_health"]
  id = "${local.sub}/resourceGroups/rg-alerts-security-canadacentral-001/providers/Microsoft.Insights/actionGroups/ag-sentinel-health-monitoring"
}

# ── Activity log alerts ────────────────────────────────────────────────
import {
  to = module.monitoring[0].azurerm_monitor_activity_log_alert.this["sentinel_law_deletion"]
  id = "${local.sub}/resourceGroups/rg-siem-security-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/Sentinel - LAW Deletion Operation"
}
import {
  to = module.monitoring[0].azurerm_monitor_activity_log_alert.this["sentinel_data_purge"]
  id = "${local.sub}/resourceGroups/rg-siem-security-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/Sentinel- Data Purge"
}
import {
  to = module.monitoring[0].azurerm_monitor_activity_log_alert.this["service_outage"]
  id = "${local.sub}/resourceGroups/rg-alerts-security-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/Service-Outage-Alert-canadacentral"
}

# ── Log search alerts ──────────────────────────────────────────────────
import {
  to = module.monitoring[0].azurerm_monitor_scheduled_query_rules_alert_v2.this["high_impact_destructive"]
  id = "${local.sub}/resourceGroups/rg-alerts-security-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/Azure - High Impact Destructive Operation Detected"
}
import {
  to = module.monitoring[0].azurerm_monitor_scheduled_query_rules_alert_v2.this["operational_issues"]
  id = "${local.sub}/resourceGroups/rg-siem-security-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/Operational issues - la-siem-security-canadacentral-001"
}
import {
  to = module.monitoring[0].azurerm_monitor_scheduled_query_rules_alert_v2.this["resource_creation"]
  id = "${local.sub}/resourceGroups/rg-alerts-security-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/Resource-Creation-Alert-canadacentral"
}
import {
  to = module.monitoring[0].azurerm_monitor_scheduled_query_rules_alert_v2.this["sentinel_analytic_created"]
  id = "${local.sub}/resourceGroups/rg-alerts-security-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/Sentinel - Analytic Rule Created or Modified"
}
import {
  to = module.monitoring[0].azurerm_monitor_scheduled_query_rules_alert_v2.this["sentinel_analytic_deleted"]
  id = "${local.sub}/resourceGroups/rg-alerts-security-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/Sentinel - Analytic Rule Deleted or Disabled"
}
import {
  to = module.monitoring[0].azurerm_monitor_scheduled_query_rules_alert_v2.this["sentinel_automation_failure"]
  id = "${local.sub}/resourceGroups/rg-alerts-security-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/Sentinel - Automation Rule Trigger Failure"
}
import {
  to = module.monitoring[0].azurerm_monitor_scheduled_query_rules_alert_v2.this["sentinel_critical_table_silence"]
  id = "${local.sub}/resourceGroups/rg-alerts-security-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/Sentinel - Critical Table Ingestion Silence"
}
import {
  to = module.monitoring[0].azurerm_monitor_scheduled_query_rules_alert_v2.this["storage_container_deletion"]
  id = "${local.sub}/resourceGroups/rg-alerts-security-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/Storage-Account-Container-Deletion-Alert-canadacentral"
}
import {
  to = module.monitoring[0].azurerm_monitor_scheduled_query_rules_alert_v2.this["storage_deletion"]
  id = "${local.sub}/resourceGroups/rg-alerts-security-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/Storage-Account-Deletion-Alert-canadacentral"
}
