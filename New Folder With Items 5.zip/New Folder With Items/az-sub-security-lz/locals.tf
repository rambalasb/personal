# Alert + action-group definitions passed into the amba-alz wrapper in
# monitoring.tf. Sentinel-monitoring alerts route to the local
# ag-sentinel-health-monitoring; the standard resource/storage alerts route to
# the ServiceNow action group in the MANAGEMENT subscription (cross-sub, by ID).

locals {
  common_tags = merge(var.tags, {
    environment = var.environment
    managed-by  = "terraform"
    solution    = "az-sub-security-lz"
  })

  subscription_scope = data.azurerm_subscription.current.id
  alerts_rg_name     = module.resource_group["alerts"].name
  siem_rg_name       = module.resource_group["siem"].name
  siem_workspace_id  = module.log_analytics_workspace["siem"].resource_id

  # Action groups in the management subscription, referenced cross-sub by ID.
  # The ServiceNow name has an intentional leading space (matches live).
  external_servicenow_ag_id = "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/lga-servicenow-integration_group/providers/Microsoft.Insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
  external_mail_ag_id       = "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/rg-alerts-management-canadacentral-001/providers/Microsoft.Insights/actionGroups/ag-monitor-mail-alerts-canadacentral-001"

  action_groups = {
    sentinel_health = {
      name                = "ag-sentinel-health-monitoring"
      resource_group_name = local.alerts_rg_name
      short_name          = "SIEM-Health"
      event_hub_receivers = {
        "ServiceNow" = {
          event_hub_namespace     = "ehns-alerts-canadacentral-001"
          event_hub_name          = "sentinel-alert-triggers"
          subscription_id         = "ccac6a90-8b47-44a9-88b2-520506c45219"
          tenant_id               = data.azurerm_client_config.current.tenant_id
          use_common_alert_schema = true
        }
      }
    }
  }

  # Activity log alerts -> azurerm_monitor_activity_log_alert
  activity_log_alerts = {
    sentinel_law_deletion = {
      name                = "Sentinel - LAW Deletion Operation"
      resource_group_name = local.siem_rg_name
      scopes              = [local.siem_workspace_id]
      location            = "global"
      description         = ""
      criteria = {
        category       = "Administrative"
        operation_name = "Microsoft.OperationalInsights/workspaces/delete"
      }
      action_group_keys = ["sentinel_health"]
    }

    sentinel_data_purge = {
      name                = "Sentinel- Data Purge"
      resource_group_name = local.siem_rg_name
      scopes              = [local.siem_workspace_id]
      location            = "global"
      description         = "Purging data from a Log Analytics Workspace (LAW) detected: it is a destructive, non-reversible operation."
      criteria = {
        category       = "Administrative"
        operation_name = "Microsoft.OperationalInsights/workspaces/purge/action"
      }
      action_group_keys = ["sentinel_health"]
    }

    service_outage = {
      name                = "Service-Outage-Alert-canadacentral"
      resource_group_name = local.alerts_rg_name
      scopes              = [local.subscription_scope]
      location            = "global"
      description         = "Azure Landing Zone Service Health Alert"
      criteria = {
        category = "ServiceHealth"
        service_health = {
          events    = []
          locations = ["Global"]
          services  = []
        }
      }
      action_group_ids = [local.external_mail_ag_id]
    }
  }

  # Log search alerts -> azurerm_monitor_scheduled_query_rules_alert_v2
  log_search_alerts = {
    high_impact_destructive = {
      name                              = "Azure - High Impact Destructive Operation Detected"
      resource_group_name               = local.alerts_rg_name
      location                          = var.location
      scopes                            = [local.subscription_scope]
      severity                          = 0
      evaluation_frequency              = "PT1H"
      window_duration                   = "PT1H"
      mute_actions_after_alert_duration = "PT3H"
      query_time_range_override         = "PT3H"
      description                       = "A critical destructive Azure control plane operation has been detected.\nOperations monitored: Resource lock deletion, Resource group deletion, Subscription removal from Management Group. "
      display_name                      = "Azure - High Impact Destructive Operation Detected"
      criteria = [{
        query                   = "let HighImpactOps = dynamic([\n    \"MICROSOFT.AUTHORIZATION/LOCKS/DELETE\",\n    \"MICROSOFT.RESOURCES/SUBSCRIPTIONS/RESOURCEGROUPS/DELETE\",\n    \"MICROSOFT.MANAGEMENT/MANAGEMENTGROUPS/SUBSCRIPTIONS/DELETE\"\n    ]);\nlet SubscriptionMap = datatable(SubId: string, SubName: string) [\n    \"7d54d6f7-83d9-48cf-ac35-1068bcfd0561\", \"Sub-Security\"\n];\nAzureActivity\n| where TimeGenerated > ago(3h)\n| where toupper(OperationNameValue) has_any (HighImpactOps)\n| where ActivityStatusValue =~ \"Success\"\n| lookup kind=leftouter SubscriptionMap on $left.SubscriptionId == $right.SubId\n| extend SubscriptionName = iif(isnotempty(SubName), SubName, SubscriptionId)\n| extend RiskLevel = case(\n                         toupper(OperationNameValue) == \"MICROSOFT.AUTHORIZATION/LOCKS/DELETE\",\n                         \"CRITICAL - Resource Lock Removed\",\n                         toupper(OperationNameValue) == \"MICROSOFT.RESOURCES/SUBSCRIPTIONS/RESOURCEGROUPS/DELETE\",\n                         \"CRITICAL - Resource Group Deleted\",\n                         toupper(OperationNameValue) == \"MICROSOFT.MANAGEMENT/MANAGEMENTGROUPS/SUBSCRIPTIONS/DELETE\",\n                         \"CRITICAL - Subscription Removed from Management Group\",\n                         \"HIGH\"\n                     )\n| project\n    OperationTime    = TimeGenerated,\n    RiskLevel,\n    Caller,\n    SubscriptionName,\n    SubscriptionId,\n    ResourceGroup,\n    Operation        = OperationNameValue,\n    AffectedResource = ResourceId,\n    SourceIP         = CallerIpAddress,\n    CorrelationId\n| order by OperationTime desc\n"
        time_aggregation_method = "Count"
        threshold               = 0
        operator                = "GreaterThan"
        resource_id_column      = ""
        dimensions = [
          { name = "RiskLevel", operator = "Include", values = ["*"] },
          { name = "Caller", operator = "Include", values = ["*"] },
          { name = "SubscriptionName", operator = "Include", values = ["*"] },
          { name = "Operation", operator = "Include", values = ["*"] },
        ]
        failing_periods = { minimum_failing_periods_to_trigger_alert = 1, number_of_evaluation_periods = 1 }
      }]
      action_group_keys = ["sentinel_health"]
    }

    operational_issues = {
      name                 = "Operational issues - la-siem-security-canadacentral-001"
      resource_group_name  = local.siem_rg_name
      location             = var.location
      scopes               = [local.siem_workspace_id]
      severity             = 3
      evaluation_frequency = "PT5M"
      window_duration      = "PT5M"
      description          = "There are operational issues in the workspace"
      display_name         = ""
      tags                 = { alertRuleCreatedWithAlertsRecommendations = "true" }
      criteria = [{
        query                   = "_LogOperation | where Level == \"Warning\""
        time_aggregation_method = "Count"
        threshold               = 0
        operator                = "GreaterThan"
        resource_id_column      = "_ResourceId"
        failing_periods         = { minimum_failing_periods_to_trigger_alert = 1, number_of_evaluation_periods = 1 }
      }]
      action_group_keys = ["sentinel_health"]
    }

    resource_creation = {
      name                 = "Resource-Creation-Alert-canadacentral"
      resource_group_name  = local.alerts_rg_name
      location             = var.location
      scopes               = [local.subscription_scope]
      severity             = 4
      evaluation_frequency = "PT10M"
      window_duration      = "PT30M"
      description          = "Alert when a new resource is created."
      display_name         = "Resource-Creation-Alert-canadacentral"
      criteria = [{
        query                   = "        AzureActivity\n        | where OperationNameValue has \"Microsoft.Resources/deployments/write\"\n        | where CategoryValue == \"Administrative\"\n        | where ActivityStatusValue == \"Success\"\n        "
        time_aggregation_method = "Count"
        threshold               = 10
        operator                = "GreaterThanOrEqual"
        resource_id_column      = "_ResourceId"
        failing_periods         = { minimum_failing_periods_to_trigger_alert = 1, number_of_evaluation_periods = 1 }
      }]
      action_group_ids = [local.external_servicenow_ag_id]
    }

    sentinel_analytic_created = {
      name                              = "Sentinel - Analytic Rule Created or Modified"
      resource_group_name               = local.alerts_rg_name
      location                          = var.location
      scopes                            = [local.siem_workspace_id]
      severity                          = 2
      evaluation_frequency              = "PT2H"
      window_duration                   = "PT2H"
      mute_actions_after_alert_duration = "PT3H"
      query_time_range_override         = "PT3H"
      target_resource_types             = ["Microsoft.OperationalInsights/workspaces"]
      description                       = "Fires when a Sentinel Analytic Rule is created or modified."
      display_name                      = "Sentinel - Analytic Rule Created or Modified"
      criteria = [{
        query                   = "SentinelAudit\n| where TimeGenerated > ago(3h)\n| where SentinelResourceType == \"Analytic Rule\"\n| where OperationName == \"Microsoft.SecurityInsights/alertRules/Write\"\n| extend ExtProps = todynamic(ExtendedProperties)\n| extend enabled  = parse_json(tostring(parse_json(tostring(ExtProps.UpdatedResourceState)).properties)).enabled\n// Exclude disablements — already captured by Deletion or disablement rule\n| where enabled != false\n| project\n    TimeGenerated,\n    Description,\n    enabled,\n    RuleName        = SentinelResourceName,\n    RuleId          = SentinelResourceId,\n    PerformedBy     = tostring(ExtProps.CallerName),\n    CallerIPAddress = tostring(ExtProps.CallerIpAddress),\n    CorrelationId,\n    Status,\n    WorkspaceId\n| order by TimeGenerated desc\n"
        time_aggregation_method = "Count"
        threshold               = 0
        operator                = "GreaterThan"
        resource_id_column      = ""
        dimensions = [
          { name = "Description", operator = "Include", values = ["*"] },
          { name = "RuleName", operator = "Include", values = ["*"] },
          { name = "PerformedBy", operator = "Include", values = ["*"] },
        ]
        failing_periods = { minimum_failing_periods_to_trigger_alert = 1, number_of_evaluation_periods = 1 }
      }]
      action_group_keys = ["sentinel_health"]
    }

    sentinel_analytic_deleted = {
      name                              = "Sentinel - Analytic Rule Deleted or Disabled"
      resource_group_name               = local.alerts_rg_name
      location                          = var.location
      scopes                            = [local.siem_workspace_id]
      severity                          = 1
      evaluation_frequency              = "PT2H"
      window_duration                   = "PT2H"
      mute_actions_after_alert_duration = "PT2H"
      query_time_range_override         = "P2D"
      target_resource_types             = ["Microsoft.OperationalInsights/workspaces"]
      description                       = "Fires when a Sentinel Analytic Rule is deleted or disabled. "
      display_name                      = "Sentinel - Analytic Rule Deleted or Disabled"
      criteria = [{
        query                   = "SentinelAudit\n| where TimeGenerated > ago(3h)\n| where SentinelResourceType == \"Analytic Rule\"\n| where OperationName in (\n    \"Microsoft.SecurityInsights/alertRules/Delete\",\n    \"Microsoft.SecurityInsights/alertRules/Write\"\n)\n| extend ExtProps = todynamic(ExtendedProperties)\n| extend enabled  = parse_json(tostring(parse_json(tostring(ExtProps.UpdatedResourceState)).properties)).enabled\n| where OperationName == \"Microsoft.SecurityInsights/alertRules/Delete\"\n    or (OperationName == \"Microsoft.SecurityInsights/alertRules/Write\" and enabled == false)\n| extend ActionTaken = case(\n    OperationName == \"Microsoft.SecurityInsights/alertRules/Delete\", \"DELETED\",\n    enabled == false,                                                 \"DISABLED\",\n    \"UNKNOWN\"\n)\n| project\n    TimeGenerated,\n    ActionTaken,\n    Description,\n    enabled,\n    RuleName        = SentinelResourceName,\n    RuleId          = SentinelResourceId,\n    PerformedBy     = tostring(ExtProps.CallerName),\n    CallerIPAddress = tostring(ExtProps.CallerIpAddress),\n    CorrelationId,\n    Status,\n    WorkspaceId\n| order by TimeGenerated desc\n"
        time_aggregation_method = "Count"
        threshold               = 0
        operator                = "GreaterThan"
        resource_id_column      = ""
        dimensions = [
          { name = "ActionTaken", operator = "Include", values = ["*"] },
          { name = "RuleName", operator = "Include", values = ["*"] },
          { name = "PerformedBy", operator = "Include", values = ["*"] },
        ]
        failing_periods = { minimum_failing_periods_to_trigger_alert = 1, number_of_evaluation_periods = 1 }
      }]
      action_group_keys = ["sentinel_health"]
    }

    sentinel_automation_failure = {
      name                              = "Sentinel - Automation Rule Trigger Failure"
      resource_group_name               = local.alerts_rg_name
      location                          = var.location
      scopes                            = [local.siem_workspace_id]
      severity                          = 1
      evaluation_frequency              = "PT1H"
      window_duration                   = "PT1H"
      mute_actions_after_alert_duration = "PT3H"
      query_time_range_override         = "PT3H"
      target_resource_types             = ["Microsoft.OperationalInsights/workspaces"]
      description                       = "Alert when Automation Rule Trigger Fails"
      display_name                      = "Sentinel - Automation Rule Trigger Failure"
      criteria = [{
        query                   = "_SentinelHealth()\n| where TimeGenerated > ago(2h)\n| where SentinelResourceType in (\"Automation rule\", \"Playbook\")\n| where Status !in (\"Success\", \"Informational\")\n| project\n    TimeGenerated,\n    ResourceType=SentinelResourceType,\n    RuleName = SentinelResourceName,\n    RuleId = SentinelResourceId,\n    SentinelIncidentID = ExtendedProperties.IncidentNumber,\n    Status,\n    Description,\n    FailureReason   = Reason,\n    WorkspaceId\n| order by TimeGenerated desc\n\n"
        time_aggregation_method = "Count"
        threshold               = 0
        operator                = "GreaterThan"
        resource_id_column      = ""
        dimensions = [
          { name = "RuleName", operator = "Include", values = ["*"] },
          { name = "Status", operator = "Include", values = ["*"] },
          { name = "FailureReason", operator = "Include", values = ["*"] },
        ]
        failing_periods = { minimum_failing_periods_to_trigger_alert = 1, number_of_evaluation_periods = 1 }
      }]
      action_group_keys = ["sentinel_health"]
    }

    sentinel_critical_table_silence = {
      name                      = "Sentinel - Critical Table Ingestion Silence"
      resource_group_name       = local.alerts_rg_name
      location                  = var.location
      scopes                    = [local.siem_workspace_id]
      severity                  = 1
      evaluation_frequency      = "PT1H"
      window_duration           = "PT1H"
      auto_mitigation_enabled   = true
      query_time_range_override = "P1D"
      target_resource_types     = ["Microsoft.OperationalInsights/workspaces"]
      description               = "A critical security table has not received logs in the past 30 minutes."
      display_name              = "Sentinel - Critical Table Ingestion Silence"
      criteria = [{
        query                   = "let LookbackWindow = 8h;\nlet CurrentHourUTC  = hourofday(now());\nlet IsBusinessHours = CurrentHourUTC >= 15 or CurrentHourUTC < 2;\nunion isfuzzy=true withsource=tablename\n    CommonSecurityLog,\n    Heartbeat,\n    SecurityEvent,\n    SigninLogs,\n    AuditLogs,\n    Syslog,\n    AzureActivity,\n    SecurityAlert,\n    SecurityIncident,\n    IdentityLogonEvents,\n    IdentityDirectoryEvents\n| where TimeGenerated > ago(LookbackWindow)\n| summarize LastSeen = max(TimeGenerated) by tablename\n| extend TimeDifference = datetime_diff(\"minute\", now(), LastSeen)\n// Per-table threshold based on expected ingestion frequency\n| extend ThresholdMinutes = case(\n                                tablename == \"Heartbeat\",60,\n                                tablename == \"CommonSecurityLog\",60,\n                                tablename == \"SecurityEvent\",60,\n                                tablename == \"Syslog\",60,\n                                tablename == \"SigninLogs\",120,\n                                tablename == \"AuditLogs\",120,\n                                tablename == \"IdentityLogonEvents\", 120,\n                                tablename == \"IdentityDirectoryEvents\",120,\n                                tablename == \"AzureActivity\",120,\n                                tablename == \"SecurityAlert\" and IsBusinessHours,240,\n                                tablename == \"SecurityAlert\" and IsBusinessHours == false,720,\n                                tablename == \"SecurityIncident\" and IsBusinessHours,240,\n                                tablename == \"SecurityIncident\" and IsBusinessHours == false, 720,\n                                IsBusinessHours, 180, 480\n                            )\n| where TimeDifference > ThresholdMinutes\n| project\n    TableName        = tablename,\n    LastSeenUTC      = LastSeen,\n    SilenceMinutes   = TimeDifference,\n    ThresholdMinutes,\n    BusinessHours      = iif(IsBusinessHours, \"Yes (7AM-7PM PST/PDT)\", \"No (Off Hours)\"),\n    SilenceVsThreshold = strcat(\n                         tostring(TimeDifference),\" min silent / \",tostring(ThresholdMinutes),\" min threshold\")\n| order by SilenceMinutes desc\n"
        time_aggregation_method = "Count"
        threshold               = 0
        operator                = "GreaterThan"
        resource_id_column      = ""
        dimensions = [
          { name = "TableName", operator = "Include", values = ["*"] },
        ]
        failing_periods = { minimum_failing_periods_to_trigger_alert = 1, number_of_evaluation_periods = 1 }
      }]
      action_group_keys = ["sentinel_health"]
    }

    storage_container_deletion = {
      name                 = "Storage-Account-Container-Deletion-Alert-canadacentral"
      resource_group_name  = local.alerts_rg_name
      location             = var.location
      scopes               = [local.subscription_scope]
      severity             = 0
      evaluation_frequency = "PT5M"
      window_duration      = "PT30M"
      description          = "Alert for the deletion of Storage Account Container."
      display_name         = "Storage-Account-Container-Deletion-Alert-canadacentral"
      criteria = [{
        query                   = "        AzureActivity\n        | where ResourceProviderValue == \"MICROSOFT.STORAGE\" and OperationNameValue == \"MICROSOFT.STORAGE/STORAGEACCOUNTS/BLOBSERVICES/CONTAINERS/DELETE\"\n        "
        time_aggregation_method = "Count"
        threshold               = 1
        operator                = "GreaterThanOrEqual"
        resource_id_column      = "_ResourceId"
        failing_periods         = { minimum_failing_periods_to_trigger_alert = 1, number_of_evaluation_periods = 1 }
      }]
      action_group_ids = [local.external_servicenow_ag_id]
    }

    storage_deletion = {
      name                 = "Storage-Account-Deletion-Alert-canadacentral"
      resource_group_name  = local.alerts_rg_name
      location             = var.location
      scopes               = [local.subscription_scope]
      severity             = 0
      evaluation_frequency = "PT5M"
      window_duration      = "PT30M"
      description          = "Alert for the deletion of Storage Account."
      display_name         = "Storage-Account-Deletion-Alert-canadacentral"
      criteria = [{
        query                   = "        AzureActivity\n        | where ResourceProviderValue == \"MICROSOFT.STORAGE\" and OperationNameValue == \"MICROSOFT.STORAGE/STORAGEACCOUNTS/DELETE\"\n        "
        time_aggregation_method = "Count"
        threshold               = 1
        operator                = "GreaterThanOrEqual"
        resource_id_column      = "_ResourceId"
        failing_periods         = { minimum_failing_periods_to_trigger_alert = 1, number_of_evaluation_periods = 1 }
      }]
      action_group_ids = [local.external_servicenow_ag_id]
    }
  }
}
