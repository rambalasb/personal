output "resource_group_ids" {
  description = "Resource group IDs, keyed by role."
  value       = { for k, m in module.resource_group : k => m.resource_id }
}

output "storage_account_ids" {
  description = "Storage account resource IDs, keyed by role."
  value       = { for k, m in module.storage_account : k => m.resource_id }
}

output "log_analytics_workspace_ids" {
  description = "Log Analytics workspace resource IDs, keyed by role."
  value       = { for k, m in module.log_analytics_workspace : k => m.resource_id }
}
