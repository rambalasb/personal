# tf-shared-workflows

Centralized, reusable GitHub Actions workflows for Terraform / AVM wrapper module repos and subscription deployment repos across the enterprise.

Consumers reference these via `workflow_call` and get lint, security scanning, plan/apply, and module test/publish without duplicating pipeline logic per repo.

Every repo and subscription we create deploys through `deploy.yml` — one entry point for both platform subscriptions (identity, management, ...; one environment) and app subscriptions (a workload with dev/test/prod; several environments), see "Deploy pipeline" below. Lint (tflint) and security (trivy) are mandatory inside it, not opt-in jobs a caller can drop; so are the destroy gate and the approval ceremony on every apply. There is no lighter-weight plan/apply pair; a repo that skips this and runs `terraform apply` some other way has no destroy gate, no required-reviewer gate, and no enforced lint/security.

## Prerequisites (cross-org access)

This repo is intended to be called from repos in **other organizations within the same GitHub Enterprise account**. That only works if an enterprise owner has enabled it:

`Enterprise settings → Policies → Actions → Reusable workflows` — allow access from other organizations in the enterprise (or explicitly allow-list the consuming orgs).

Without that policy enabled, `workflow_call` across orgs will fail even though both orgs are in the same enterprise.

## Repo layout

```text
.github/workflows/
  tflint.yml                # terraform fmt + tflint, SARIF -> GitHub Advanced Security
  trivy.yml                 # IaC security scan (Trivy), SARIF -> GitHub Advanced Security
  deploy.yml                # the sanctioned entry point: lint + security + deploy-env.yml matrixed across 1..N environments
  deploy-env.yml            # deploy-plan.yml + deploy-apply.yml chained for one environment -- internal building block, not called directly
  deploy-plan.yml           # PR plan: speculative run, never applyable -- internal building block, not called directly
  deploy-apply.yml          # main apply: check+gate, destroy gate, approval ceremony -- internal building block, not called directly
  bootstrap-workspace.yml   # create/reassert a TFC workspace + Azure variables -- internal building block, not called directly
  module-test.yml           # local test: validate + terraform test, mocked providers, no credentials
  module-remote-test.yml    # remote test: deploys to a sandbox subscription, verifies, tears down
  module-publish.yml        # tag + publish a module, gated on both tests passing
  require-semver-label.yml  # blocks merge to main without exactly one semver:* label
  auto-semver-label.yml     # proposes that label from the PR title (Conventional Commits)
  release.yml               # cuts the tag + moves the floating major tag on merge
```

### Module pipeline ordering

`lint` (tflint) and `security` (trivy) run in parallel with `module-test`, not before it — gating `module-test` behind them would serialize a real Azure apply/destroy cycle behind two static checks. Inside `module-test` itself, `test` → `publish` → `remote-test` is strictly sequential:

```text
lint, security, module-test(test)  →  publish  →  remote-test (sandbox)
```

`publish`/`remote-test` only run on merge to main, and `remote-test` consumes the exact version `publish` just cut.

Every `tf-wrapper-avm-*` repo uses the same `ci.yml`, nothing repo-specific in it — copy [`templates/module-ci.yml`](templates/module-ci.yml) verbatim into a new wrapper repo's `.github/workflows/ci.yml`.

### Callers need `security-events: write`

`tflint.yml` and `trivy.yml` upload SARIF to GitHub Advanced Security, which needs `actions: read` and `security-events: write` granted by the **calling** workflow's top-level `permissions:` — a called reusable workflow can't have more than the caller grants. Missing this fails the upload step, not the scan itself, so it can look like the scan passed with a silent secondary failure. See the `permissions:` block in the example below.

## Versioning

Tag releases using semver (`v1.0.0`, `v1.1.0`, ...). Consumers should pin to an exact tag, not `@main`:

```yaml
uses: <org>/tf-shared-workflows/.github/workflows/tflint.yml@v1.0.0
```

### Cutting a release

Every PR into `main` must carry exactly one label: `semver:patch`, `semver:minor`, or `semver:major` — `require-semver-label.yml` blocks merge otherwise (add its `Require semver label` check as a required status check in branch protection). On merge, `release.yml` reads that label off the merged PR, finds the latest existing `vX.Y.Z` tag, bumps it accordingly, pushes the new exact tag, and moves the floating major tag (`v1`, `v2`, ...) to match — fully automatic, patch/minor/major alike. The label plus PR review is the deliberate act; there is no separate manual rollout step, so every repo pinned to the floating major picks up a merged change on its next run.

`auto-semver-label.yml` applies that label automatically for most PRs, by parsing the title as [Conventional Commits](https://www.conventionalcommits.org/), on open and on every title edit: `feat: ...` → minor; `fix:`, `docs:`, `chore:`, `refactor:`, `test:`, `ci:`, `build:`, `style:`, `perf:` → patch (every recognized type still cuts a tag, patch is just the safe default absent a stronger signal); `!` right after the type or scope on any type, or a `BREAKING CHANGE:` footer → major regardless of type. It only ever proposes a label — `require-semver-label.yml` is still what blocks merge. A title with no recognizable Conventional Commits type at all gets no label: add one by hand.

### Deploy pipeline

One reusable workflow, `deploy.yml`, behind every subscription's deploy pipeline — platform subscriptions (identity, management, security, firewall management, connectivity, ...) and app subscriptions (a workload deployed to dev/test/prod, ...) alike. The only thing that differs between them is the `environments` input: a platform subscription passes a one-element array (its own subscription name), an app subscription passes one element per environment it owns. There is no separate single-environment template — a platform subscription is just the N=1 case of the same pipeline. Each repo owns:

- its own Terraform root (`providers.tf`, one `<environment>.tfvars` per entry in `environments`) at `working-directory`,
- a single thin caller workflow with the real triggers (`pull_request`, `push: [main]`, `workflow_dispatch`, a weekly `schedule`),
- and, per entry in `environments`, a GitHub Environment named exactly that entry, with required reviewers configured — that's what gates that environment's apply job. No reviewers configured means no gate, silently.

**Call chain.** A caller's `deploy.yml` only ever references the top of this tree; everything below is internal plumbing it never sees:

```text
<your-repo>/.github/workflows/deploy.yml          (thin caller, copied from templates/deploy.yml)
  │
  │  uses:
  ▼
tf-shared-workflows/.github/workflows/deploy.yml  (the one sanctioned entry point)
  │
  ├── tflint.yml   ─┐  mandatory, run once per pipeline run —
  ├── trivy.yml    ─┘  not per environment, and not skippable from the caller
  │
  └── deploy-env.yml            (matrixed once per entry in `environments`,
      │                          max-parallel: 1, in array order — see timeline below)
      │
      ├── ensure-workspace       one TFC API call: does this environment's workspace exist?
      │      │
      │      │ missing (or reassert_workspace: true), AND azure_client_id supplied
      │      ▼
      │   bootstrap-workspace.yml   creates or reasserts the workspace + Azure variables
      │      │
      │      ▼
      │   await-credentials      environment: <name> ← pauses for a human to approve,
      │                          confirming the Entra federated credentials
      │                          bootstrap's summary asked for are now registered
      │
      ├── deploy-plan.yml       speculative plan, no -out, never applyable
      │                         (the PR-time / throwaway check)
      │
      └── deploy-apply.yml      needs: plan succeeding
          ├── check job          real plan -out=tfplan.binary, destroy gate, audit trail
          └── apply job          environment: <name>  ← required-reviewer gate lives here
```

`deploy-env.yml` exists only to make the branch under it — plan then apply, for one environment — into a single callable unit. Without it, `deploy.yml` would have to matrix `deploy-plan.yml` and `deploy-apply.yml` as two separate flat jobs, and a matrixed job's `needs.<job>.result` reflects the combined outcome of every leg in it — so `prod`'s plan would have to succeed before `dev`'s apply could even start. Chaining them per environment first avoids that.

**Onboarding a new environment.** On every routine run, `ensure-workspace` is one cheap TFC API call that finds the workspace already exists, and `bootstrap`/`await-credentials` are skipped entirely — no cost, no pause. The self-bootstrapping path only activates on a `workflow_dispatch` run that supplies `azure_client_id`/`azure_tenant_id`/`azure_subscription_id` (see `templates/deploy.yml`'s onboarding inputs): `ensure-workspace` finds the workspace missing, `bootstrap` (calling `bootstrap-workspace.yml`) creates it and sets its Azure variables, then `await-credentials` — gated on the same GitHub Environment as `apply`, below — pauses the run. A human registers the two Entra federated credentials the bootstrap job's summary asked for (still the one step nothing here can do, since that's Entra-side with no TFC API equivalent), then approves the pending `await-credentials` job. Approval resumes the *same* run straight into `plan`/`apply` — no second pipeline to notice and re-trigger by hand. `deploy.yml`'s `guard-onboarding-scope` job refuses this path outright if `environments` lists more than one entry, since the same Azure identity would otherwise get wired to every environment that happened to be missing its workspace, not just the one being onboarded — onboard one environment per dispatch. Setting `reassert_workspace: true` runs the same `bootstrap`/`await-credentials` path against a workspace that already exists, instead of only a missing one — for reasserting Terraform version, auto-apply, or rotated Azure credentials.

**Which TFC workspace does this target?** Every environment gets its own workspace, named `<workspace_prefix>-<environment>` (`workspace_prefix` defaults to `az-platform`). How that name actually gets used depends on how the repo's `providers.tf` declares its `cloud` block — this repo doesn't control that, `providers.tf` does:

- **Platform subscription** (`identity`, `management`, ...): `providers.tf` hardcodes one fixed workspace name —

  ```hcl
  cloud {
    organization = "BC_Hydro"
    workspaces { name = "az-platform-identity" }
  }
  ```

  Terraform only ever talks to that one workspace; nothing in CI selects it, so `TF_WORKSPACE` (set by `deploy-plan.yml`/`deploy-apply.yml` from `workspace_prefix`) is redundant but harmless — it has to match by construction, and Terraform errors if it doesn't. `workspace_prefix` stays at its `az-platform` default for these.
- **App subscription** (a multi-environment workload): one `providers.tf`, several workspaces, so the cloud block can't hardcode a single name — it matches by **tag** instead:

  ```hcl
  cloud {
    organization = "BC_Hydro"
    workspaces { project = "az-cep"; tags = ["az-cep"] }
  }
  ```

  Here `TF_WORKSPACE` (again `<workspace_prefix>-<environment>`) is what actually picks which of the tagged workspaces this run targets — `dev` and `prod` share the same `providers.tf` but resolve to `az-cep-dev` and `az-cep-prod`. `workspace_prefix` **must** be set to the repo's own short name (`az-cep`) in its caller — see `templates/deploy.yml`'s `workspace_prefix:` field. Get it wrong and a run targets the wrong workspace, or none. This is also why `bootstrap-workspace.yml` tags a newly created workspace with `workspace_prefix` (via its `workspace_tag` input) — a tags-based cloud block can't find an untagged workspace no matter how correctly named it is.

**Promotion timeline**, for `environments: ["dev","prod"]` on a merge to main:

```text
 max-parallel: 1, fail-fast: true (default) — one environment at a time, in array order

 ┌─ deploy-env.yml(dev) ────────────┐         ┌─ deploy-env.yml(prod) ───────────┐
 │ plan(dev) ──▶ apply(dev)         │ ──────▶ │ plan(prod) ──▶ apply(prod)       │
 │  (unattended)   (needs reviewer  │succeeds │  (unattended)   (needs reviewer  │
 │                  if `dev` env    │         │                  if `prod` env   │
 │                  has one)        │         │                  has one)        │
 └───────────────────────────────────┘         └───────────────────────────────────┘
         │
         │ dev's plan or apply fails
         ▼
 prod's deploy-env.yml is cancelled while queued — never starts.
 A broken dev never reaches, let alone touches, prod.
```

For a platform subscription (`environments` has one entry), this collapses to a single box — nothing to sequence, same pipeline either way.

**What runs, by trigger** — the same three states apply per environment, decided by `github.event_name` inside `deploy-env.yml`, not by any input the caller sets:

| Trigger | `plan` | `apply` |
| --- | --- | --- |
| `pull_request` | ✅ speculative, never applied | — |
| `push` to main / `workflow_dispatch` | ✅ | ✅, if `plan` succeeded, gated on required reviewers |
| `schedule` (weekly) | — | — (only the standalone `trivy` job runs) |

There's no "apply only" state: `deploy-apply.yml`'s own `check` job always re-plans immediately before applying — that fresh, saved run is what the approver reviews and what actually gets applied, never a plan computed earlier in the run or supplied externally.

`lint` (tflint) and `security` (trivy) live inside `deploy.yml` itself, mandatory for every entry regardless of count — not separate jobs in the caller's own copy, so a repo can't strip them out by editing its own workflow file. Plan and apply are where the `environments` count actually matters: `deploy.yml` matrixes `deploy-env.yml` (plan then apply, chained, for one environment) across every entry, **sequentially, in the order the array lists them** — `max-parallel: 1` plus the default `fail-fast: true` mean environment N+1 never starts until environment N's plan+apply has fully succeeded, and a failure cancels whatever hasn't started yet. A platform subscription's one-element array is unaffected by this (nothing to sequence); an app subscription's `["dev","prod"]` gets a real dev-then-prod promotion gate — a broken `dev` stops `prod` from running at all.

It matrixes the chained `deploy-env.yml`, not `deploy-plan.yml`/`deploy-apply.yml` directly as two separate top-level jobs, because that would produce a *different and worse* coupling: a matrixed job's `needs.<job>.result` reflects the combined outcome of every leg, so a flat `plan` matrix job wouldn't finish (and let `apply` start at all) until **every** environment had planned — meaning `prod`'s plan would have to succeed before `dev`'s apply could even begin. Chaining plan+apply per environment inside one reusable workflow first, then matrixing that as a single unit, is what makes this an actual ordered promotion instead of "everything plans, then everything applies."

On a PR, `lint`/`security`/`deploy` all start together (no dependency between them — `plan`, inside `deploy`, is speculative and never applyable, so there's nothing costly to protect by waiting). On merge to main, the same three run again on the merge commit, and for each environment, only if that environment's `plan` succeeds does its `apply` start — `apply` is the one job worth gating per environment, since it's a real, approval-gated change. `apply` runs its own internal re-plan regardless (the saved HCP run the approver actually reviews); the `plan` job here is a cheap, disposable filter so a reviewer is never asked to approve something that doesn't even plan cleanly.

```yaml
# .github/workflows/deploy.yml -- a platform subscription repo (one environment)
name: management-lz deploy

on:
  pull_request:
    branches: [main]
  push:
    branches: [main]
  workflow_dispatch:
    inputs:
      confirm:
        description: 'Type "apply" to confirm'
        type: string
        required: true
      allow_destroy:
        description: "Authorise a plan that destroys or replaces resources"
        type: boolean
        default: false
  schedule:
    - cron: "30 2 * * 1"

permissions:
  actions: read # lint/security jobs upload SARIF to GHAS
  security-events: write # lint/security jobs upload SARIF to GHAS

jobs:
  deploy:
    uses: <org>/tf-shared-workflows/.github/workflows/deploy.yml@v1
    with:
      environments: '["management"]'
      confirm: ${{ inputs.confirm }}
      allow_destroy: ${{ inputs.allow_destroy }}
    secrets:
      tfc-token: ${{ secrets.TF_API_TOKEN }}
```

```yaml
# .github/workflows/deploy.yml -- an app subscription repo (several environments)
jobs:
  deploy:
    uses: <org>/tf-shared-workflows/.github/workflows/deploy.yml@v1
    with:
      environments: '["dev","prod"]'
      confirm: ${{ inputs.confirm }}
      allow_destroy: ${{ inputs.allow_destroy }}
    secrets:
      tfc-token: ${{ secrets.TF_API_TOKEN }}
```

A ready-to-copy version lives in [`templates/deploy.yml`](templates/deploy.yml) — copy it into a new repo's `.github/workflows/deploy.yml`, set `environments:` (and the workflow `name:`), done. The pipeline logic itself is never duplicated: every repo's caller references the same `deploy.yml` via `uses:`, so a fix or a change to the shared workflow reaches every platform and app subscription without touching these files. There is no other sanctioned way to plan or apply against a subscription; module repos that need a plan/apply step (rather than `module-test.yml`'s mocked-provider test) go through this same template too.

**Migrating an existing platform subscription repo:** its current caller (`plan`/`apply` as separate `uses:` jobs against `deploy-plan.yml`/`deploy-apply.yml`, plus its own `lint`/`security` jobs) still works unchanged — those files aren't going away, `deploy-env.yml` calls the exact same two internally. Moving a repo onto `deploy.yml` is a caller-file swap only, no Terraform or state change, but validate it against one pilot repo before rolling it to the rest, the same way you'd validate any other change here (see "Ownership" below).

### Bootstrapping a subscription workspace

The `az-platform-*` workspaces pin a fixed `name` in their `cloud` block (not `tags`), which deliberately disables Terraform's own create-on-init behavior — nothing here ever creates a missing workspace just because a plan or apply happened to run. `bootstrap-workspace.yml` scripts that setup instead of doing it by hand in the TFC UI: creates the workspace if missing (or reasserts execution-mode/auto-apply/Terraform-version if it already exists), and sets the four Azure dynamic-credential variables. It doesn't replace Gate4's manual sign-off (E5/E6 in `gate4-subscription-onboarding`); it's what the person doing that sign-off runs instead of clicking through the TFC UI by hand. It also can't create the Entra app's federated credentials — that's an Entra-side action with no TFC API equivalent — so its job summary prints the exact two subjects (`run_phase:plan` / `run_phase:apply`) to register by hand afterward.

**`deploy.yml` itself is the only way to run this — there is no separate template.** Onboard a new environment, or reassert an existing one's config (Terraform version, Azure variables, after rotating the Entra app), the same way: `workflow_dispatch` with `azure_client_id`/`azure_tenant_id`/`azure_subscription_id` filled in, `environments` naming that one environment, and `reassert_workspace: true` if the workspace already exists — see "Onboarding a new environment" above. A separate, always-available bootstrap pipeline sitting next to `deploy.yml` invited exactly the mistake it looked like it invited — a developer re-running it against an environment that's already live, out of habit, months after onboarding. There used to be a standalone `templates/bootstrap-workspace.yml`; it's gone, folded into `deploy.yml`'s `ensure-workspace`/`reassert_workspace` path, which costs nothing extra since `bootstrap-workspace.yml` already required the same three Azure inputs on every call regardless.

## Ownership

Changes here affect every consumer repo across all orgs. Validate changes against a pilot repo before bumping the floating major tag.
