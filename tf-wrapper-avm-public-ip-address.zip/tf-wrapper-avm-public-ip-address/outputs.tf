output "resource_id" {
  description = "The Azure resource ID of the Public IP."
  value       = module.public_ip.resource_id
}

output "name" {
  description = "The name of the Public IP."
  value       = module.public_ip.name
}

output "public_ip_address" {
  description = "The IP address Azure allocated."
  value       = module.public_ip.public_ip_address
}
