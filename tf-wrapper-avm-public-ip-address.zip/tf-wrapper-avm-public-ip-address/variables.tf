# =====================================================================
# Required inputs
# =====================================================================

variable "name" {
  type        = string
  description = "Name of the Public IP. 1-80 chars; alphanumerics, underscores, periods, hyphens. Must start with alphanumeric and end with alphanumeric or underscore."

  validation {
    condition     = can(regex("^[a-zA-Z0-9]([a-zA-Z0-9._-]{0,78}[a-zA-Z0-9_])?$", var.name))
    error_message = "name must be 1-80 characters, alphanumerics/underscores/periods/hyphens, start with alphanumeric, end with alphanumeric or underscore."
  }
}

variable "resource_group_name" {
  type        = string
  description = "Name of the Resource Group where the Public IP will be deployed."

  validation {
    condition     = length(var.resource_group_name) > 0 && length(var.resource_group_name) <= 90
    error_message = "resource_group_name must be 1-90 characters."
  }
}

variable "location" {
  type        = string
  description = "Azure region where the Public IP will be deployed."

  validation {
    condition     = length(var.location) > 0
    error_message = "location must not be empty."
  }
}

# =====================================================================
# Defaulted toggles
# =====================================================================

variable "allocation_method" {
  type        = string
  description = "'Static' or 'Dynamic'. Standard SKU only supports 'Static'."
  default     = "Static"

  validation {
    condition     = contains(["Static", "Dynamic"], var.allocation_method)
    error_message = "allocation_method must be 'Static' or 'Dynamic'."
  }
}

variable "sku" {
  type        = string
  description = "Public IP SKU. 'Standard' or 'Basic'. Basic was retired by Azure on September 30, 2025."
  default     = "Standard"

  validation {
    condition     = contains(["Standard", "Basic"], var.sku)
    error_message = "sku must be 'Standard' or 'Basic'."
  }
}

variable "sku_tier" {
  type        = string
  description = "'Regional' or 'Global'. Changing this forces a new resource."
  default     = "Regional"

  validation {
    condition     = contains(["Regional", "Global"], var.sku_tier)
    error_message = "sku_tier must be 'Regional' or 'Global'."
  }
}

variable "ip_version" {
  type        = string
  description = "'IPv4' or 'IPv6'. Changing this forces a new resource."
  default     = "IPv4"

  validation {
    condition     = contains(["IPv4", "IPv6"], var.ip_version)
    error_message = "ip_version must be 'IPv4' or 'IPv6'."
  }
}

variable "zones" {
  type        = set(string)
  description = "Availability zones. Defaults to all three. Set to [] for a non-zonal address. Changing this forces a new resource."
  default     = ["1", "2", "3"]
  nullable    = false

  validation {
    condition     = alltrue([for z in var.zones : contains(["1", "2", "3"], z)])
    error_message = "Each zone must be '1', '2', or '3'."
  }
}

# =====================================================================
# Addressing and DNS
# =====================================================================

variable "public_ip_prefix_id" {
  type        = string
  description = "Resource ID of a Public IP Prefix to allocate the address from."
  default     = null
}

variable "domain_name_label" {
  type        = string
  description = "DNS label; produces <label>.<region>.cloudapp.azure.com."
  default     = null
}

variable "reverse_fqdn" {
  type        = string
  description = "Reverse DNS FQDN. Cannot be combined with domain_name_label."
  default     = null
}

variable "idle_timeout_in_minutes" {
  type        = number
  description = "TCP idle timeout, 4-30 minutes."
  default     = 4

  validation {
    condition     = var.idle_timeout_in_minutes >= 4 && var.idle_timeout_in_minutes <= 30
    error_message = "idle_timeout_in_minutes must be between 4 and 30."
  }
}

variable "ip_tags" {
  type        = map(string)
  description = "IP tags, for example { RoutingPreference = \"Internet\" }. Changing this forces a new resource."
  default     = {}
}

variable "edge_zone" {
  type        = string
  description = "Edge zone to place the address in."
  default     = null
}

# =====================================================================
# DDoS
# =====================================================================

variable "ddos_protection_mode" {
  type        = string
  description = "'VirtualNetworkInherited', 'Enabled' or 'Disabled'."
  default     = "VirtualNetworkInherited"

  validation {
    condition     = contains(["VirtualNetworkInherited", "Enabled", "Disabled"], var.ddos_protection_mode)
    error_message = "ddos_protection_mode must be 'VirtualNetworkInherited', 'Enabled' or 'Disabled'."
  }
}

variable "ddos_protection_plan_id" {
  type        = string
  description = "DDoS protection plan ID. Only used when ddos_protection_mode is 'Enabled'."
  default     = null
}

# =====================================================================
# Governance
# =====================================================================

variable "role_assignments" {
  type = map(object({
    role_definition_id_or_name             = string
    principal_id                           = string
    description                            = optional(string, null)
    skip_service_principal_aad_check       = optional(bool, false)
    condition                              = optional(string, null)
    condition_version                      = optional(string, null)
    delegated_managed_identity_resource_id = optional(string, null)
    principal_type                         = optional(string, null)
  }))
  description = "RBAC role assignments scoped to the Public IP."
  default     = {}
  nullable    = false
}

variable "lock" {
  type = object({
    kind = string
    name = optional(string, null)
  })
  description = "Optional resource lock. kind must be 'CanNotDelete' or 'ReadOnly'."
  default     = null

  validation {
    condition     = var.lock == null || contains(["CanNotDelete", "ReadOnly"], try(var.lock.kind, ""))
    error_message = "lock.kind must be 'CanNotDelete' or 'ReadOnly' when lock is set."
  }
}

variable "diagnostic_settings" {
  type = map(object({
    name                                     = optional(string, null)
    log_categories                           = optional(set(string), [])
    log_groups                               = optional(set(string), ["allLogs"])
    metric_categories                        = optional(set(string), ["AllMetrics"])
    log_analytics_destination_type           = optional(string, "Dedicated")
    workspace_resource_id                    = optional(string, null)
    storage_account_resource_id              = optional(string, null)
    event_hub_authorization_rule_resource_id = optional(string, null)
    event_hub_name                           = optional(string, null)
    marketplace_partner_resource_id          = optional(string, null)
  }))
  description = "Diagnostic settings for the Public IP. Each entry needs at least one destination."
  default     = {}
  nullable    = false
}

# =====================================================================
# Module behavior
# =====================================================================

variable "enable_telemetry" {
  type        = bool
  description = "Whether to enable AVM module telemetry. Set false to opt out."
  default     = true
}

variable "tags" {
  type        = map(string)
  description = "A map of tags to apply to the Public IP."
  default     = null
}
