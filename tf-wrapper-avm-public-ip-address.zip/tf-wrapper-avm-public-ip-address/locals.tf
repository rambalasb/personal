locals {
  module_tags = merge(
    var.tags == null ? {} : var.tags,
    {
      managed-by = "terraform"
      module     = "tf-wrapper-avm-public-ip-address"
    }
  )

  # The AVM module types zones as numbers; this wrapper takes strings to match
  # tf-wrapper-avm-public-ip-prefix.
  zones = [for z in var.zones : tonumber(z)]
}
