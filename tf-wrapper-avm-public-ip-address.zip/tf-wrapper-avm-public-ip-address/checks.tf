check "sku_is_standard" {
  assert {
    condition     = var.sku == "Standard"
    error_message = "Public IP SKU is '${var.sku}'. Basic SKU public IPs were retired by Azure on September 30, 2025; use 'Standard'."
  }
}

check "standard_sku_is_static" {
  assert {
    condition     = var.sku != "Standard" || var.allocation_method == "Static"
    error_message = "Standard SKU public IPs only support Static allocation; Azure rejects '${var.allocation_method}'."
  }
}

check "zonal_redundancy" {
  assert {
    condition     = length(var.zones) >= 2 || length(var.zones) == 0
    error_message = "Public IP is pinned to ${length(var.zones)} zone. Use 2 or more zones for zone redundancy, or zones = [] for a non-zonal address."
  }
}

check "ddos_plan_matches_mode" {
  assert {
    condition     = var.ddos_protection_mode == "Enabled" || var.ddos_protection_plan_id == null
    error_message = "ddos_protection_plan_id is set but ddos_protection_mode is '${var.ddos_protection_mode}', so the plan is ignored. Set the mode to 'Enabled'."
  }
}
