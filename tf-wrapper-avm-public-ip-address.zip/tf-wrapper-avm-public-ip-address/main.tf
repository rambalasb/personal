module "public_ip" {
  source  = "Azure/avm-res-network-publicipaddress/azurerm"
  version = "0.2.1"

  # Required
  name                = var.name
  resource_group_name = var.resource_group_name
  location            = var.location

  # Defaulted toggles
  allocation_method = var.allocation_method
  sku               = var.sku
  sku_tier          = var.sku_tier
  ip_version        = var.ip_version
  zones             = local.zones

  # Addressing and DNS
  public_ip_prefix_id     = var.public_ip_prefix_id
  domain_name_label       = var.domain_name_label
  reverse_fqdn            = var.reverse_fqdn
  idle_timeout_in_minutes = var.idle_timeout_in_minutes
  ip_tags                 = var.ip_tags
  edge_zone               = var.edge_zone

  # DDoS
  ddos_protection_mode    = var.ddos_protection_mode
  ddos_protection_plan_id = var.ddos_protection_plan_id

  # Governance
  role_assignments    = var.role_assignments
  lock                = var.lock
  diagnostic_settings = var.diagnostic_settings

  # Module behavior
  enable_telemetry = var.enable_telemetry
  tags             = local.module_tags
}
