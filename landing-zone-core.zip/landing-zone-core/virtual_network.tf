# virtual_network.tf
# Dependencies: resource_group (parent_id = RG resource_id, picked via resource_group_key).
# Companion: role_assignment (scope = each VNet's resource_id).

module "virtual_network" {
  for_each = var.enable_virtual_network ? var.virtual_network : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-virtual-network/azurerm"
  version = "0.1.0"

  name          = each.value.name
  parent_id     = module.resource_group[each.value.resource_group_key].resource_id
  location      = coalesce(each.value.location, module.resource_group[each.value.resource_group_key].location)
  address_space = each.value.address_space
  dns_servers   = each.value.dns_servers
  subnets       = each.value.subnets
  tags          = merge(local.common_tags, each.value.tags)
}

module "virtual_network_role_assignment" {
  for_each = (var.enable_virtual_network && var.enable_virtual_network_role_assignment) ? var.virtual_network_role_assignment : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-role-assignment/azurerm"
  version = "0.3.4"

  role_assignments_azure_resource_manager = {
    for ra_key, ra in each.value : ra_key => merge(ra, {
      scope = module.virtual_network[each.key].resource_id
    })
  }

  depends_on = [module.virtual_network]
}
