# key_vault.tf
# Dependencies: resource_group (resource_group_name = RG name, picked via resource_group_key)
#               + log_analytics_workspace (optional — diagnostics wired when log_analytics_key is set).
# Companion: role_assignment (scope = each key vault's resource_id).

module "key_vault" {
  for_each = var.enable_key_vault ? var.key_vault : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-key-vault/azurerm"
  version = "0.2.0"

  name                          = each.value.name
  resource_group_name           = module.resource_group[each.value.resource_group_key].name
  location                      = coalesce(each.value.location, module.resource_group[each.value.resource_group_key].location)
  tenant_id                     = var.tenant_id
  sku_name                      = each.value.sku_name
  purge_protection_enabled      = each.value.purge_protection_enabled
  public_network_access_enabled = each.value.public_network_access_enabled
  tags                          = merge(local.common_tags, each.value.tags)

  # Diagnostics — wired only when the instance binds a workspace via log_analytics_key.
  diagnostic_settings = each.value.log_analytics_key == null ? {} : {
    to-law = {
      workspace_resource_id = module.log_analytics_workspace[each.value.log_analytics_key].resource_id
    }
  }
}

module "key_vault_role_assignment" {
  for_each = (var.enable_key_vault && var.enable_key_vault_role_assignment) ? var.key_vault_role_assignment : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-role-assignment/azurerm"
  version = "0.3.4"

  role_assignments_azure_resource_manager = {
    for ra_key, ra in each.value : ra_key => merge(ra, {
      scope = module.key_vault[each.key].resource_id
    })
  }

  depends_on = [module.key_vault]
}
