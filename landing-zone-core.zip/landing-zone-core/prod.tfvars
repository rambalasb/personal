# ── Shared ─────────────────────────────────────────────────────────────
environment = "prod"

# Required by every key_vault instance — replace with your Entra tenant ID.
tenant_id = "00000000-0000-0000-0000-000000000000"

tags = {
  owner       = "platform-team"
  cost-center = "cc-1234"
}

# ── Feature flags ──────────────────────────────────────────────────────
# Full landing zone: three RGs, two VNets, two NSGs, central workspace,
# platform key vault (with diagnostics), one storage account. Role
# assignments enabled on key_vault and storage_account.
enable_resource_group                          = true
enable_resource_group_role_assignment          = false
enable_virtual_network                         = true
enable_virtual_network_role_assignment         = false
enable_network_security_group                  = true
enable_network_security_group_role_assignment  = false
enable_log_analytics_workspace                 = true
enable_log_analytics_workspace_role_assignment = false
enable_key_vault                               = true
enable_key_vault_role_assignment               = true
enable_storage_account                         = true
enable_storage_account_role_assignment         = true

# ── Module config (maps keyed by instance role) ────────────────────────
resource_group = {
  "network" = { name = "rg-network-prod", location = "canadacentral" }
  "app"     = { name = "rg-app-prod", location = "canadacentral" }
  "shared"  = { name = "rg-shared-prod", location = "canadacentral" }
}

virtual_network = {
  "hub" = {
    name               = "vnet-hub-prod"
    resource_group_key = "network"
    address_space      = ["10.0.0.0/16"]
    subnets = {
      "gateway" = { address_prefix = "10.0.0.0/24" }
      "shared"  = { address_prefix = "10.0.1.0/24" }
    }
  }
  "spoke" = {
    name               = "vnet-spoke-prod"
    resource_group_key = "network"
    address_space      = ["10.1.0.0/16"]
    subnets = {
      "app" = { address_prefix = "10.1.0.0/24" }
    }
  }
}

network_security_group = {
  "app" = {
    name               = "nsg-app-prod"
    resource_group_key = "network"
    security_rules = {
      "allow-https-in" = {
        name                       = "allow-https-in"
        access                     = "Allow"
        direction                  = "Inbound"
        priority                   = 100
        protocol                   = "Tcp"
        source_port_range          = "*"
        destination_port_range     = "443"
        source_address_prefix      = "*"
        destination_address_prefix = "*"
      }
    }
  }
  "data" = {
    name               = "nsg-data-prod"
    resource_group_key = "network"
  }
}

log_analytics_workspace = {
  "central" = {
    name               = "law-central-prod"
    resource_group_key = "shared"
    retention_in_days  = 90
  }
}

key_vault = {
  "platform" = {
    name               = "kv-lzcore-plat-prod"
    resource_group_key = "shared"
    log_analytics_key  = "central"
    sku_name           = "premium"
  }
}

# Companion keyed by parent key_vault instance. Grant on "platform" only.
key_vault_role_assignment = {
  "platform" = {
    "secrets-reader" = {
      role_definition_name = "Key Vault Secrets User"
      principal_id         = "00000000-0000-0000-0000-000000000000" # replace with Entra group/SP object ID
      principal_type       = "Group"
    }
  }
}

storage_account = {
  "primary" = {
    name                     = "stlzcoreappprod"
    resource_group_key       = "app"
    account_replication_type = "GRS"
  }
}

# Companion keyed by parent storage_account instance. Grant on "primary" only.
storage_account_role_assignment = {
  "primary" = {
    "blob-reader" = {
      role_definition_name = "Storage Blob Data Reader"
      principal_id         = "00000000-0000-0000-0000-000000000000" # replace with Entra group/SP object ID
      principal_type       = "Group"
    }
  }
}
