terraform {
  required_version = ">= 1.9, < 2.0"

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 3.116, < 5.0"
    }
    # Required by tf-wrapper-avm-role-assignment for Entra ID assignments.
    azuread = {
      source  = "hashicorp/azuread"
      version = ">= 2.50, < 4.0"
    }
  }

  # Uncomment and populate for remote state:
  # backend "azurerm" {
  #   resource_group_name  = ""
  #   storage_account_name = ""
  #   container_name       = ""
  #   key                  = "landing-zone-core.tfstate"
  # }
}

provider "azurerm" {
  features {}
}

provider "azuread" {}
