# Deployment order — Terraform infers this automatically from the per-instance
# module.<producer>[each.value.<producer>_key] references in each consumer file.
#   1. resource_group           (no dependencies)
#   2. virtual_network          (depends on: resource_group)
#   3. network_security_group   (depends on: resource_group)
#   4. log_analytics_workspace  (depends on: resource_group)
#   5. storage_account          (depends on: resource_group)
#   6. key_vault                (depends on: resource_group + log_analytics_workspace for diagnostics)
#   *  *_role_assignment companions deploy after their parent (explicit depends_on).

locals {
  common_tags = merge(var.tags, {
    environment = var.environment
    managed-by  = "terraform"
    solution    = "landing-zone-core"
  })
}
