# resource_group.tf
# Dependencies: none — resource groups deploy first.
# Companion: role_assignment (scope = each RG's resource_id).

module "resource_group" {
  for_each = var.enable_resource_group ? var.resource_group : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-resource-group/azurerm"
  version = "1.0.1"

  name       = each.value.name
  location   = each.value.location
  managed_by = each.value.managed_by
  lock       = each.value.lock
  tags       = merge(local.common_tags, each.value.tags)
}

module "resource_group_role_assignment" {
  for_each = (var.enable_resource_group && var.enable_resource_group_role_assignment) ? var.resource_group_role_assignment : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-role-assignment/azurerm"
  version = "0.3.4"

  # each.key is the parent resource_group instance key. Scope is injected
  # from the parent's resource_id, so it is not supplied in tfvars.
  role_assignments_azure_resource_manager = {
    for ra_key, ra in each.value : ra_key => merge(ra, {
      scope = module.resource_group[each.key].resource_id
    })
  }

  depends_on = [module.resource_group]
}
