# log_analytics_workspace.tf
# Dependencies: resource_group (resource_group_name = RG name, picked via resource_group_key).
# Companion: role_assignment (scope = each workspace's resource_id).

module "log_analytics_workspace" {
  for_each = var.enable_log_analytics_workspace ? var.log_analytics_workspace : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-log-analytics-workspace/azurerm"
  version = "0.1.0"

  name                                      = each.value.name
  resource_group_name                       = module.resource_group[each.value.resource_group_key].name
  location                                  = coalesce(each.value.location, module.resource_group[each.value.resource_group_key].location)
  log_analytics_workspace_sku               = each.value.sku
  log_analytics_workspace_retention_in_days = each.value.retention_in_days
  tags                                      = merge(local.common_tags, each.value.tags)
}

module "log_analytics_workspace_role_assignment" {
  for_each = (var.enable_log_analytics_workspace && var.enable_log_analytics_workspace_role_assignment) ? var.log_analytics_workspace_role_assignment : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-role-assignment/azurerm"
  version = "0.3.4"

  role_assignments_azure_resource_manager = {
    for ra_key, ra in each.value : ra_key => merge(ra, {
      scope = module.log_analytics_workspace[each.key].resource_id
    })
  }

  depends_on = [module.log_analytics_workspace]
}
