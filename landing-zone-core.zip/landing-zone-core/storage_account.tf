# storage_account.tf
# Dependencies: resource_group (resource_group_name = RG name, picked via resource_group_key).
# Companion: role_assignment (scope = each storage account's resource_id).

module "storage_account" {
  for_each = var.enable_storage_account ? var.storage_account : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-storage-account/azurerm"
  version = "0.1.0"

  name                     = each.value.name
  resource_group_name      = module.resource_group[each.value.resource_group_key].name
  location                 = coalesce(each.value.location, module.resource_group[each.value.resource_group_key].location)
  account_kind             = each.value.account_kind
  account_tier             = each.value.account_tier
  account_replication_type = each.value.account_replication_type
  tags                     = merge(local.common_tags, each.value.tags)
}

module "storage_account_role_assignment" {
  for_each = (var.enable_storage_account && var.enable_storage_account_role_assignment) ? var.storage_account_role_assignment : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-role-assignment/azurerm"
  version = "0.3.4"

  role_assignments_azure_resource_manager = {
    for ra_key, ra in each.value : ra_key => merge(ra, {
      scope = module.storage_account[each.key].resource_id
    })
  }

  depends_on = [module.storage_account]
}
