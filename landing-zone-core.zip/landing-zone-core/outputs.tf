# Outputs are maps keyed by the instance identifier so callers can look up
# any specific instance. Empty maps when the wrapper's enable_* flag is false.

output "resource_group_ids" {
  description = "Resource IDs of every deployed resource group, keyed by instance identifier (e.g. network, app, shared)."
  value       = { for k, m in module.resource_group : k => m.resource_id }
}

output "resource_group_names" {
  description = "Names of every deployed resource group, keyed by instance identifier."
  value       = { for k, m in module.resource_group : k => m.name }
}

output "virtual_network_ids" {
  description = "Resource IDs of every deployed virtual network, keyed by instance identifier (e.g. hub, spoke)."
  value       = { for k, m in module.virtual_network : k => m.resource_id }
}

output "virtual_network_subnets" {
  description = "Subnet maps of every deployed virtual network, keyed by instance identifier."
  value       = { for k, m in module.virtual_network : k => m.subnets }
}

output "network_security_group_ids" {
  description = "Resource IDs of every deployed network security group, keyed by instance identifier (e.g. app, data)."
  value       = { for k, m in module.network_security_group : k => m.resource_id }
}

output "log_analytics_workspace_ids" {
  description = "Resource IDs of every deployed Log Analytics workspace, keyed by instance identifier (e.g. central)."
  value       = { for k, m in module.log_analytics_workspace : k => m.resource_id }
}

output "key_vault_ids" {
  description = "Resource IDs of every deployed key vault, keyed by instance identifier (e.g. platform)."
  value       = { for k, m in module.key_vault : k => m.resource_id }
}

output "key_vault_uris" {
  description = "Vault URIs of every deployed key vault, keyed by instance identifier."
  value       = { for k, m in module.key_vault : k => m.uri }
}

output "storage_account_ids" {
  description = "Resource IDs of every deployed storage account, keyed by instance identifier (e.g. primary)."
  value       = { for k, m in module.storage_account : k => m.resource_id }
}

output "storage_account_names" {
  description = "Names of every deployed storage account, keyed by instance identifier."
  value       = { for k, m in module.storage_account : k => m.name }
}
