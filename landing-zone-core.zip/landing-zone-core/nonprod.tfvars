# ── Shared ─────────────────────────────────────────────────────────────
environment = "nonprod"

tags = {
  owner       = "platform-team"
  cost-center = "cc-1234"
}

# ── Feature flags ──────────────────────────────────────────────────────
# Slimmer nonprod footprint: network + app tiers only. No shared tier,
# no Log Analytics, no Key Vault, no role assignments.
enable_resource_group                          = true
enable_resource_group_role_assignment          = false
enable_virtual_network                         = true
enable_virtual_network_role_assignment         = false
enable_network_security_group                  = true
enable_network_security_group_role_assignment  = false
enable_log_analytics_workspace                 = false
enable_log_analytics_workspace_role_assignment = false
enable_key_vault                               = false
enable_key_vault_role_assignment               = false
enable_storage_account                         = true
enable_storage_account_role_assignment         = false

# ── Module config (maps keyed by instance role) ────────────────────────
resource_group = {
  "network" = { name = "rg-network-np", location = "canadacentral" }
  "app"     = { name = "rg-app-np", location = "canadacentral" }
}

virtual_network = {
  "hub" = {
    name               = "vnet-hub-np"
    resource_group_key = "network"
    address_space      = ["10.10.0.0/16"]
    subnets = {
      "default" = { address_prefix = "10.10.1.0/24" }
    }
  }
}

network_security_group = {
  "app" = {
    name               = "nsg-app-np"
    resource_group_key = "network"
  }
}

storage_account = {
  "primary" = {
    name               = "stlzcoreappnp"
    resource_group_key = "app"
  }
}
