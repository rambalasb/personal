# network_security_group.tf
# Dependencies: resource_group (resource_group_name = RG name, picked via resource_group_key).
# Companion: role_assignment (scope = each NSG's resource_id).

module "network_security_group" {
  for_each = var.enable_network_security_group ? var.network_security_group : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-network-security-group/azurerm"
  version = "0.1.0"

  name                = each.value.name
  resource_group_name = module.resource_group[each.value.resource_group_key].name
  location            = coalesce(each.value.location, module.resource_group[each.value.resource_group_key].location)
  security_rules      = each.value.security_rules
  tags                = merge(local.common_tags, each.value.tags)
}

module "network_security_group_role_assignment" {
  for_each = (var.enable_network_security_group && var.enable_network_security_group_role_assignment) ? var.network_security_group_role_assignment : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-role-assignment/azurerm"
  version = "0.3.4"

  role_assignments_azure_resource_manager = {
    for ra_key, ra in each.value : ra_key => merge(ra, {
      scope = module.network_security_group[each.key].resource_id
    })
  }

  depends_on = [module.network_security_group]
}
