# =====================================================================
# 1. Shared infrastructure variables
#    Only values that genuinely apply to every instance of every
#    resource. Per-instance name/location/SKU live in the config maps.
# =====================================================================

variable "environment" {
  type        = string
  description = "Deployment environment label (e.g., nonprod, prod)."
}

variable "tags" {
  type        = map(string)
  description = "Baseline tags applied to all resources. Merged with per-instance tags."
  default     = {}
}

variable "tenant_id" {
  type        = string
  description = "Entra ID tenant ID used by every key_vault instance."
  default     = null
}

# =====================================================================
# 2. Feature flags — one per primary wrapper, one per companion.
#    Each flag gates the whole wrapper (all its instances on/off in
#    this env). Per-instance opt-out = omit the key from the config map.
#    Default false everywhere: environments explicitly opt in.
# =====================================================================

variable "enable_resource_group" {
  type    = bool
  default = false
}

variable "enable_resource_group_role_assignment" {
  type        = bool
  description = "Deploy role assignments scoped to resource groups. Requires enable_resource_group = true."
  default     = false
}

variable "enable_virtual_network" {
  type    = bool
  default = false
}

variable "enable_virtual_network_role_assignment" {
  type        = bool
  description = "Deploy role assignments scoped to virtual networks. Requires enable_virtual_network = true."
  default     = false
}

variable "enable_network_security_group" {
  type    = bool
  default = false
}

variable "enable_network_security_group_role_assignment" {
  type        = bool
  description = "Deploy role assignments scoped to network security groups. Requires enable_network_security_group = true."
  default     = false
}

variable "enable_log_analytics_workspace" {
  type    = bool
  default = false
}

variable "enable_log_analytics_workspace_role_assignment" {
  type        = bool
  description = "Deploy role assignments scoped to Log Analytics workspaces. Requires enable_log_analytics_workspace = true."
  default     = false
}

variable "enable_key_vault" {
  type    = bool
  default = false
}

variable "enable_key_vault_role_assignment" {
  type        = bool
  description = "Deploy role assignments scoped to key vaults. Requires enable_key_vault = true."
  default     = false
}

variable "enable_storage_account" {
  type    = bool
  default = false
}

variable "enable_storage_account_role_assignment" {
  type        = bool
  description = "Deploy role assignments scoped to storage accounts. Requires enable_storage_account = true."
  default     = false
}

# =====================================================================
# 3. Per-wrapper config maps — one map(object) per primary wrapper,
#    keyed by the instance identifier. <producer>_key fields are the
#    cross-resource binding glue added on top of each wrapper's own
#    variables.
# =====================================================================

variable "resource_group" {
  type = map(object({
    name       = string
    location   = string
    managed_by = optional(string)
    lock = optional(object({
      kind = string
      name = optional(string)
    }))
    tags = optional(map(string), {})
  }))
  description = "Resource groups to deploy, keyed by role (e.g. network, app, shared). Required when enable_resource_group = true."
  default     = {}
}

variable "virtual_network" {
  type = map(object({
    name               = string
    resource_group_key = string           # references a key in var.resource_group
    location           = optional(string) # falls back to the RG's location
    address_space      = set(string)
    dns_servers        = optional(set(string))
    subnets = optional(map(object({
      address_prefix = optional(string)
    })), {})
    tags = optional(map(string), {})
  }))
  description = "Virtual networks to deploy, keyed by instance role (e.g. hub, spoke). Required when enable_virtual_network = true."
  default     = {}
}

variable "network_security_group" {
  type = map(object({
    name               = string
    resource_group_key = string           # references a key in var.resource_group
    location           = optional(string) # falls back to the RG's location
    security_rules = optional(map(object({
      name                       = string
      access                     = string
      direction                  = string
      priority                   = number
      protocol                   = string
      source_port_range          = optional(string)
      destination_port_range     = optional(string)
      source_address_prefix      = optional(string)
      destination_address_prefix = optional(string)
    })), {})
    tags = optional(map(string), {})
  }))
  description = "Network security groups to deploy, keyed by instance role (e.g. app, data). Required when enable_network_security_group = true."
  default     = {}
}

variable "log_analytics_workspace" {
  type = map(object({
    name               = string
    resource_group_key = string           # references a key in var.resource_group
    location           = optional(string) # falls back to the RG's location
    sku                = optional(string, "PerGB2018")
    retention_in_days  = optional(number, 30)
    tags               = optional(map(string), {})
  }))
  description = "Log Analytics workspaces to deploy, keyed by instance role (e.g. central). Required when enable_log_analytics_workspace = true."
  default     = {}
}

variable "key_vault" {
  type = map(object({
    name                          = string
    resource_group_key            = string           # references a key in var.resource_group
    log_analytics_key             = optional(string) # references a key in var.log_analytics_workspace; enables diagnostics when set
    location                      = optional(string) # falls back to the RG's location
    sku_name                      = optional(string, "standard")
    purge_protection_enabled      = optional(bool, true)
    public_network_access_enabled = optional(bool, true)
    tags                          = optional(map(string), {})
  }))
  description = "Key vaults to deploy, keyed by instance role (e.g. platform). Required when enable_key_vault = true."
  default     = {}
}

variable "storage_account" {
  type = map(object({
    name                     = string
    resource_group_key       = string           # references a key in var.resource_group
    location                 = optional(string) # falls back to the RG's location
    account_kind             = optional(string, "StorageV2")
    account_tier             = optional(string, "Standard")
    account_replication_type = optional(string, "LRS")
    tags                     = optional(map(string), {})
  }))
  description = "Storage accounts to deploy, keyed by instance role (e.g. primary). Required when enable_storage_account = true."
  default     = {}
}

# ---------------------------------------------------------------------
# Companion config maps — keyed by the PARENT instance key. The inner
# map is the role_assignments_azure_resource_manager map for that parent
# (scope is injected automatically from the parent's resource_id, so it
# is NOT supplied here). Populate only the parent keys you want to grant
# on; omit a parent key to skip it.
# ---------------------------------------------------------------------

variable "resource_group_role_assignment" {
  type = map(map(object({
    role_definition_id                     = optional(string)
    role_definition_name                   = optional(string)
    principal_type                         = optional(string)
    principal_id                           = string
    condition                              = optional(string)
    condition_version                      = optional(string)
    delegated_managed_identity_resource_id = optional(string)
    description                            = optional(string)
    skip_service_principal_aad_check       = optional(bool, false)
  })))
  description = "RBAC assignments scoped to resource groups, keyed by the parent resource_group instance key. Required when enable_resource_group_role_assignment = true."
  default     = {}
}

variable "virtual_network_role_assignment" {
  type = map(map(object({
    role_definition_id                     = optional(string)
    role_definition_name                   = optional(string)
    principal_type                         = optional(string)
    principal_id                           = string
    condition                              = optional(string)
    condition_version                      = optional(string)
    delegated_managed_identity_resource_id = optional(string)
    description                            = optional(string)
    skip_service_principal_aad_check       = optional(bool, false)
  })))
  description = "RBAC assignments scoped to virtual networks, keyed by the parent virtual_network instance key. Required when enable_virtual_network_role_assignment = true."
  default     = {}
}

variable "network_security_group_role_assignment" {
  type = map(map(object({
    role_definition_id                     = optional(string)
    role_definition_name                   = optional(string)
    principal_type                         = optional(string)
    principal_id                           = string
    condition                              = optional(string)
    condition_version                      = optional(string)
    delegated_managed_identity_resource_id = optional(string)
    description                            = optional(string)
    skip_service_principal_aad_check       = optional(bool, false)
  })))
  description = "RBAC assignments scoped to network security groups, keyed by the parent network_security_group instance key. Required when enable_network_security_group_role_assignment = true."
  default     = {}
}

variable "log_analytics_workspace_role_assignment" {
  type = map(map(object({
    role_definition_id                     = optional(string)
    role_definition_name                   = optional(string)
    principal_type                         = optional(string)
    principal_id                           = string
    condition                              = optional(string)
    condition_version                      = optional(string)
    delegated_managed_identity_resource_id = optional(string)
    description                            = optional(string)
    skip_service_principal_aad_check       = optional(bool, false)
  })))
  description = "RBAC assignments scoped to Log Analytics workspaces, keyed by the parent log_analytics_workspace instance key. Required when enable_log_analytics_workspace_role_assignment = true."
  default     = {}
}

variable "key_vault_role_assignment" {
  type = map(map(object({
    role_definition_id                     = optional(string)
    role_definition_name                   = optional(string)
    principal_type                         = optional(string)
    principal_id                           = string
    condition                              = optional(string)
    condition_version                      = optional(string)
    delegated_managed_identity_resource_id = optional(string)
    description                            = optional(string)
    skip_service_principal_aad_check       = optional(bool, false)
  })))
  description = "RBAC assignments scoped to key vaults, keyed by the parent key_vault instance key. Required when enable_key_vault_role_assignment = true."
  default     = {}
}

variable "storage_account_role_assignment" {
  type = map(map(object({
    role_definition_id                     = optional(string)
    role_definition_name                   = optional(string)
    principal_type                         = optional(string)
    principal_id                           = string
    condition                              = optional(string)
    condition_version                      = optional(string)
    delegated_managed_identity_resource_id = optional(string)
    description                            = optional(string)
    skip_service_principal_aad_check       = optional(bool, false)
  })))
  description = "RBAC assignments scoped to storage accounts, keyed by the parent storage_account instance key. Required when enable_storage_account_role_assignment = true."
  default     = {}
}
