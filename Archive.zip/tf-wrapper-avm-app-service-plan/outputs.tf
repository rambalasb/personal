output "resource_id" {
  description = "The Azure resource ID of the App Service Plan (canonical 'Microsoft.Web/serverFarms' casing)."
  value       = module.app_service_plan.resource_id
}

output "name" {
  description = "The name of the App Service Plan."
  value       = module.app_service_plan.name
}
