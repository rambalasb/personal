module "app_service_plan" {
  source  = "Azure/avm-res-web-serverfarm/azurerm"
  version = "2.0.4"

  # Required
  name      = var.name
  parent_id = local.parent_id
  location  = var.location
  os_type   = var.os_type

  # Scale & SKU
  sku_name                        = var.sku_name
  worker_count                    = var.worker_count
  maximum_elastic_worker_count    = var.maximum_elastic_worker_count
  per_site_scaling_enabled        = var.per_site_scaling_enabled
  premium_plan_auto_scale_enabled = var.premium_plan_auto_scale_enabled
  zone_balancing_enabled          = var.zone_balancing_enabled

  # Networking
  virtual_network_subnet_id  = var.virtual_network_subnet_id
  app_service_environment_id = var.app_service_environment_id

  # Identity & governance
  managed_identities = var.managed_identities
  role_assignments   = var.role_assignments
  lock               = var.lock

  # Diagnostics
  diagnostic_settings = var.diagnostic_settings

  # WindowsManagedInstance-only inputs (passed as null/empty for other OS types)
  install_scripts       = var.install_scripts
  plan_default_identity = var.plan_default_identity
  rdp_enabled           = var.rdp_enabled
  registry_adapters     = var.registry_adapters
  storage_mounts        = var.storage_mounts

  # Module behavior
  enable_telemetry          = var.enable_telemetry
  tags                      = local.module_tags
  retry                     = var.retry
  timeouts                  = var.timeouts
  server_farm_resource_type = var.server_farm_resource_type
}
