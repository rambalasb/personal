locals {
  module_tags = merge(
    var.tags == null ? {} : var.tags,
    {
      managed-by = "terraform"
      module     = "tf-wrapper-avm-app-service-plan"
    }
  )

  # AVM uses parent_id (RG resource ID). Derive for caller convenience.
  parent_id = "/subscriptions/${var.subscription_id}/resourceGroups/${var.resource_group_name}"

  is_managed_instance = var.os_type == "WindowsManagedInstance"
  zone_redundant_sku  = can(regex("^(P[0-9]+(m)?v[2-4]|I[1-6]v2|EP[1-3]|WS[1-3])$", var.sku_name))
}
