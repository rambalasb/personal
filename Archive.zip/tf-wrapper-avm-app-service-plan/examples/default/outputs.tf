output "resource_id" {
  value = module.app_service_plan.resource_id
}

output "name" {
  value = module.app_service_plan.name
}
