module "app_service_plan" {
  source = "../.."

  name                = "asp-avm-default-test-${random_string.suffix.result}"
  subscription_id     = data.azurerm_client_config.current.subscription_id
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location
  os_type             = "Linux"

  enable_telemetry = false
}
