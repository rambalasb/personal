check "zone_balancing_enabled" {
  assert {
    condition     = var.zone_balancing_enabled
    error_message = "App Service Plan zone_balancing_enabled is false. Enable for zonal HA across availability zones (requires a zone-redundant SKU + worker_count >= 2)."
  }
}

check "worker_count_meets_production_minimum" {
  assert {
    condition     = var.worker_count >= 2
    error_message = "App Service Plan worker_count is ${var.worker_count}. Production workloads should have at least 2 workers for HA."
  }
}

check "premium_sku_for_zone_balancing" {
  assert {
    condition     = !var.zone_balancing_enabled || local.zone_redundant_sku
    error_message = "zone_balancing_enabled = true but SKU '${var.sku_name}' is not zone-redundant. Switch to a Premium v2/v3/v4, Isolated v2, Elastic Premium, or WorkflowStandard SKU."
  }
}

check "managed_instance_only_inputs_match_os_type" {
  assert {
    condition = (
      local.is_managed_instance ||
      (var.install_scripts == null && var.plan_default_identity == null && var.rdp_enabled == null && var.registry_adapters == null && var.storage_mounts == null)
    )
    error_message = "WindowsManagedInstance-only inputs (install_scripts, plan_default_identity, rdp_enabled, registry_adapters, storage_mounts) are set but os_type is '${var.os_type}'. They'll be ignored or rejected by Azure."
  }
}

check "rdp_requires_bastion_warning" {
  assert {
    condition     = !try(var.rdp_enabled, false)
    error_message = "rdp_enabled = true on a Managed Instance plan requires a Bastion host in the same VNet for connectivity. Confirm the Bastion is provisioned in your VNet integration target."
  }
}
