# =====================================================================
# Required inputs
# =====================================================================

variable "name" {
  type        = string
  description = "Name of the App Service Plan. 1-60 chars; letters, numbers, hyphens, underscores."

  validation {
    condition     = can(regex("^[a-zA-Z0-9-_]{1,60}$", var.name))
    error_message = "name must be 1-60 characters, letters/numbers/hyphens/underscores."
  }
}

variable "subscription_id" {
  type        = string
  description = "Subscription ID containing the Resource Group. Used to derive the AVM parent_id."

  validation {
    condition     = can(regex("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$", var.subscription_id))
    error_message = "subscription_id must be a valid GUID."
  }
}

variable "resource_group_name" {
  type        = string
  description = "Name of the Resource Group where the App Service Plan will be deployed."

  validation {
    condition     = length(var.resource_group_name) > 0 && length(var.resource_group_name) <= 90
    error_message = "resource_group_name must be 1-90 characters."
  }
}

variable "location" {
  type        = string
  description = "Azure region where the App Service Plan will be deployed."

  validation {
    condition     = length(var.location) > 0
    error_message = "location must not be empty."
  }
}

variable "os_type" {
  type        = string
  description = "OS type for the plan. 'Windows', 'Linux', 'WindowsContainer', or 'WindowsManagedInstance'."

  validation {
    condition     = contains(["Windows", "Linux", "WindowsContainer", "WindowsManagedInstance"], var.os_type)
    error_message = "os_type must be 'Windows', 'Linux', 'WindowsContainer', or 'WindowsManagedInstance'."
  }
}

# =====================================================================
# Scale & SKU
# =====================================================================

variable "sku_name" {
  type        = string
  description = "Plan SKU. Defaults to 'P1v2' (minimum for zone redundancy). See AVM module for the full allowed list."
  default     = "P1v2"

  validation {
    condition     = can(regex("^(B1|B2|B3|D1|F1|I1|I2|I3|I1v2|I2v2|I3v2|I4v2|I5v2|I6v2|P1v2|P2v2|P3v2|P0v3|P1v3|P2v3|P3v3|P1mv3|P2mv3|P3mv3|P4mv3|P5mv3|P0v4|P1v4|P2v4|P3v4|P1mv4|P2mv4|P3mv4|P4mv4|P5mv4|S1|S2|S3|SHARED|EP1|EP2|EP3|FC1|WS1|WS2|WS3|Y1)$", var.sku_name))
    error_message = "sku_name must be a valid App Service Plan SKU (see AVM module docs)."
  }
}

variable "worker_count" {
  type        = number
  description = "Number of workers to allocate. Defaults to 3 (recommended minimum for production)."
  default     = 3

  validation {
    condition     = var.worker_count >= 1
    error_message = "worker_count must be at least 1."
  }
}

variable "maximum_elastic_worker_count" {
  type        = number
  description = "Maximum total workers for ElasticScaleEnabled plans (Premium/EP/WS)."
  default     = 3
}

variable "per_site_scaling_enabled" {
  type        = bool
  description = "Whether per-site scaling is enabled on this plan."
  default     = false
}

variable "premium_plan_auto_scale_enabled" {
  type        = bool
  description = "Whether elastic auto-scale is enabled. Only valid for Premium or Elastic Premium SKUs."
  default     = false
}

variable "zone_balancing_enabled" {
  type        = bool
  description = "Whether zone balancing is enabled. Requires a zone-redundant SKU (Premium v2/v3, Isolated v2, Elastic Premium, WS)."
  default     = true
}

# =====================================================================
# Networking
# =====================================================================

variable "virtual_network_subnet_id" {
  type        = string
  description = "Subnet resource ID to integrate the plan with (regional VNet integration). The subnet must be delegated to Microsoft.Web/serverFarms."
  default     = null
}

variable "app_service_environment_id" {
  type        = string
  description = "App Service Environment (ASE) resource ID for ASE-hosted plans."
  default     = null
}

# =====================================================================
# Identity & governance
# =====================================================================

variable "managed_identities" {
  type = object({
    system_assigned            = optional(bool, false)
    user_assigned_resource_ids = optional(set(string), [])
  })
  description = "Managed identity configuration."
  default     = {}
}

variable "role_assignments" {
  type = map(object({
    role_definition_id_or_name             = string
    principal_id                           = string
    description                            = optional(string, null)
    skip_service_principal_aad_check       = optional(bool, false)
    condition                              = optional(string, null)
    condition_version                      = optional(string, null)
    delegated_managed_identity_resource_id = optional(string, null)
    principal_type                         = optional(string, null)
  }))
  description = "RBAC role assignments scoped to the App Service Plan."
  default     = {}
}

variable "lock" {
  type = object({
    kind = string
    name = optional(string, null)
  })
  description = "Optional resource lock. kind must be 'CanNotDelete' or 'ReadOnly'."
  default     = null

  validation {
    condition     = var.lock == null || contains(["CanNotDelete", "ReadOnly"], try(var.lock.kind, ""))
    error_message = "lock.kind must be 'CanNotDelete' or 'ReadOnly' when set."
  }
}

# =====================================================================
# Diagnostics
# =====================================================================

variable "diagnostic_settings" {
  type = map(object({
    name = optional(string, null)
    logs = optional(set(object({
      category       = optional(string, null)
      category_group = optional(string, null)
      enabled        = optional(bool, true)
      retention_policy = optional(object({
        days    = optional(number, 0)
        enabled = optional(bool, false)
      }), {})
    })), [])
    metrics = optional(set(object({
      category = optional(string, null)
      enabled  = optional(bool, true)
      retention_policy = optional(object({
        days    = optional(number, 0)
        enabled = optional(bool, false)
      }), {})
    })), [])
    log_analytics_destination_type           = optional(string, "Dedicated")
    workspace_resource_id                    = optional(string, null)
    storage_account_resource_id              = optional(string, null)
    event_hub_authorization_rule_resource_id = optional(string, null)
    event_hub_name                           = optional(string, null)
    marketplace_partner_resource_id          = optional(string, null)
  }))
  description = "Diagnostic settings for the plan."
  default     = {}
}

# =====================================================================
# WindowsManagedInstance-only inputs (no-op for other os_type values)
# =====================================================================

variable "install_scripts" {
  type = list(object({
    name = string
    source = object({
      type       = optional(string, "RemoteAzureBlob")
      source_uri = string
    })
  }))
  description = "Install scripts. Only applicable when os_type = 'WindowsManagedInstance'."
  default     = null
}

variable "plan_default_identity" {
  type = object({
    identity_type                      = optional(string, "UserAssigned")
    user_assigned_identity_resource_id = string
  })
  description = "Default identity for Managed Instance plans. Only applicable when os_type = 'WindowsManagedInstance'."
  default     = null
}

variable "rdp_enabled" {
  type        = bool
  description = "Whether RDP is enabled on Managed Instance plans (requires Bastion in the VNet). Only applicable when os_type = 'WindowsManagedInstance'."
  default     = null
}

variable "registry_adapters" {
  type = list(object({
    registry_key = string
    type         = string
    key_vault_secret_reference = object({
      secret_uri = string
    })
  }))
  description = "Registry adapters for Managed Instance plans. type: 'DWORD' or 'String'. Only applicable when os_type = 'WindowsManagedInstance'."
  default     = null

  validation {
    condition = var.registry_adapters == null || alltrue([
      for a in coalesce(var.registry_adapters, []) : contains(["DWORD", "String"], a.type)
    ])
    error_message = "Each registry_adapters.type must be 'DWORD' or 'String'."
  }
}

variable "storage_mounts" {
  type = list(object({
    name             = string
    type             = optional(string, "LocalStorage")
    source           = optional(string, "")
    destination_path = string
    credentials_key_vault_reference = optional(object({
      secret_uri = optional(string)
    }), {})
  }))
  description = "Storage mounts for Managed Instance plans. Only applicable when os_type = 'WindowsManagedInstance'."
  default     = null
}

# =====================================================================
# Module behavior
# =====================================================================

variable "enable_telemetry" {
  type        = bool
  description = "Whether to enable AVM module telemetry. Set false to opt out."
  default     = true
}

variable "tags" {
  type        = map(string)
  description = "A map of tags to apply to the plan."
  default     = null
}

variable "retry" {
  type = object({
    error_message_regex  = optional(list(string), ["ScopeLocked"])
    interval_seconds     = optional(number, null)
    max_interval_seconds = optional(number, null)
  })
  description = "Retry configuration for azapi operations."
  default     = null
}

variable "timeouts" {
  type = object({
    create = optional(string, null)
    delete = optional(string, null)
    read   = optional(string, null)
    update = optional(string, null)
  })
  description = "Operation timeouts. Each value must be a Go duration (e.g. '30m', '1h')."
  default     = null
}

variable "server_farm_resource_type" {
  type        = string
  description = "Resource type/API version for the server farm. Defaults to 'Microsoft.Web/serverfarms@2025-03-01'. Change only when targeting a specific API version."
  default     = "Microsoft.Web/serverfarms@2025-03-01"
}

# =====================================================================
# Cross-input validation (Terraform >= 1.9)
# =====================================================================

variable "_validate_managed_instance_only_inputs" {
  type        = bool
  description = "Internal sentinel — do not set."
  default     = true

  validation {
    condition = (
      var.os_type == "WindowsManagedInstance" ||
      (var.install_scripts == null && var.plan_default_identity == null && var.rdp_enabled == null && var.registry_adapters == null && var.storage_mounts == null)
    )
    error_message = "install_scripts, plan_default_identity, rdp_enabled, registry_adapters, and storage_mounts are only valid when os_type = 'WindowsManagedInstance'. Unset them or change os_type."
  }
}

variable "_validate_zone_balancing_requires_compatible_sku" {
  type        = bool
  description = "Internal sentinel — do not set."
  default     = true

  validation {
    condition = (
      !var.zone_balancing_enabled ||
      can(regex("^(P[0-9]+(m)?v[2-4]|I[1-6]v2|EP[1-3]|WS[1-3])$", var.sku_name))
    )
    error_message = "zone_balancing_enabled = true requires a zone-redundant SKU (Premium v2/v3/v4, Isolated v2, Elastic Premium EP1-EP3, or WorkflowStandard WS1-WS3). SKU '${var.sku_name}' is not zone-redundant — set zone_balancing_enabled = false or pick a compatible SKU."
  }
}

variable "_validate_zone_balancing_requires_multiple_workers" {
  type        = bool
  description = "Internal sentinel — do not set."
  default     = true

  validation {
    condition     = !var.zone_balancing_enabled || var.worker_count >= 2
    error_message = "zone_balancing_enabled = true requires worker_count >= 2. With 1 worker there's nothing to balance across zones."
  }
}

variable "_validate_premium_auto_scale_requires_premium_sku" {
  type        = bool
  description = "Internal sentinel — do not set."
  default     = true

  validation {
    condition = (
      !var.premium_plan_auto_scale_enabled ||
      can(regex("^(P[0-9]+(m)?v[2-4]|EP[1-3])$", var.sku_name))
    )
    error_message = "premium_plan_auto_scale_enabled = true requires a Premium (Pv2/v3/v4) or Elastic Premium (EP1-EP3) SKU. SKU '${var.sku_name}' is not eligible."
  }
}
