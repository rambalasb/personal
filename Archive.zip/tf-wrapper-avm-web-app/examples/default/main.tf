module "web_app" {
  source = "../.."

  name                     = "app-avm-${random_string.suffix.result}"
  subscription_id          = data.azurerm_client_config.current.subscription_id
  resource_group_name      = azurerm_resource_group.this.name
  location                 = azurerm_resource_group.this.location
  os_type                  = "Linux"
  service_plan_resource_id = azurerm_service_plan.this.id

  enable_telemetry = false
}
