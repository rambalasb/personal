output "resource_id" {
  value     = module.web_app.resource_id
  sensitive = true
}

output "name" {
  value = module.web_app.name
}

output "resource_uri" {
  value = module.web_app.resource_uri
}
