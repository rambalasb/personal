# =====================================================================
# Required inputs
# =====================================================================

variable "name" {
  type        = string
  description = "Name of the Web App. 2-60 characters; globally unique."

  validation {
    condition     = length(var.name) >= 2 && length(var.name) <= 60
    error_message = "name must be 2-60 characters."
  }
}

variable "subscription_id" {
  type        = string
  description = "Subscription ID containing the Resource Group. Used to derive the AVM parent_id."

  validation {
    condition     = can(regex("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$", var.subscription_id))
    error_message = "subscription_id must be a valid GUID."
  }
}

variable "resource_group_name" {
  type        = string
  description = "Name of the Resource Group where the Web App will be deployed."

  validation {
    condition     = length(var.resource_group_name) > 0 && length(var.resource_group_name) <= 90
    error_message = "resource_group_name must be 1-90 characters."
  }
}

variable "location" {
  type        = string
  description = "Azure region where the Web App will be deployed."

  validation {
    condition     = length(var.location) > 0
    error_message = "location must not be empty."
  }
}

variable "service_plan_resource_id" {
  type        = string
  description = "Resource ID of the App Service Plan that hosts the Web App."

  validation {
    condition     = can(regex("^/subscriptions/[a-f0-9-]+/resourceGroups/[a-zA-Z0-9._-]+/providers/Microsoft.Web/[sS]erver[fF]arms/[a-zA-Z0-9._-]+$", var.service_plan_resource_id))
    error_message = "service_plan_resource_id must be a valid Microsoft.Web/serverFarms resource ID."
  }
}

# =====================================================================
# OS — kind is hardcoded to 'webapp' by this wrapper
# =====================================================================

variable "os_type" {
  type        = string
  description = "OS type. 'Linux' or 'Windows'."
  default     = "Linux"

  validation {
    condition     = contains(["Linux", "Windows"], var.os_type)
    error_message = "os_type must be 'Linux' or 'Windows'."
  }
}

variable "enabled" {
  type        = bool
  description = "Whether the Web App is enabled."
  default     = true
}

# =====================================================================
# Large polymorphic objects — type = any
# Schemas live in the upstream AVM module's variables.tf.
# AVM validates these at apply.
# =====================================================================

variable "site_config" {
  type        = any
  description = "Site config (app stack, always_on, IP restrictions, CORS, auto-heal, scaling, etc.). See AVM upstream variables.tf for the full ~370-line type."
  default     = {}
}

variable "auth_settings" {
  type        = any
  description = "Legacy EasyAuth v1 settings. Prefer auth_settings_v2."
  default     = null
}

variable "auth_settings_v2" {
  type        = any
  description = "EasyAuth v2 settings (AAD, Apple, Facebook, GitHub, Google, Twitter, custom OIDC)."
  default     = null
}

variable "deployment_slots" {
  type        = any
  description = "Map of deployment slots."
  default     = {}
}

# =====================================================================
# App settings & connection strings
# =====================================================================

variable "app_settings" {
  type        = map(string)
  description = "App Settings (key-value pairs surfaced as env vars at runtime)."
  default     = {}
}

variable "slot_sensitive_app_settings" {
  type        = map(map(string))
  description = "Per-slot sensitive app settings, keyed by slot key."
  default     = {}
  sensitive   = true
}

variable "connection_strings" {
  type = map(object({
    name  = optional(string)
    type  = optional(string)
    value = optional(string)
  }))
  description = "Map of connection strings."
  default     = {}
  sensitive   = true
}

variable "sticky_settings" {
  type = map(object({
    app_setting_names       = optional(list(string))
    connection_string_names = optional(list(string))
  }))
  description = "App settings and connection strings that should stick to a slot during swap."
  default     = {}
}

# =====================================================================
# Network & access
# =====================================================================

variable "public_network_access_enabled" {
  type        = bool
  description = "Whether the Web App is reachable over the public internet."
  default     = false
}

variable "https_only" {
  type        = bool
  description = "Whether the Web App enforces HTTPS-only traffic."
  default     = true
}

variable "host_names_disabled" {
  type        = bool
  description = "Whether public hostnames are disabled."
  default     = null
}

variable "ip_mode" {
  type        = string
  description = "IP mode. 'IPv4', 'IPv4AndIPv6', or 'IPv6'."
  default     = null

  validation {
    condition     = var.ip_mode == null || contains(["IPv4", "IPv4AndIPv6", "IPv6"], coalesce(var.ip_mode, "IPv4"))
    error_message = "ip_mode must be 'IPv4', 'IPv4AndIPv6', 'IPv6', or null."
  }
}

variable "virtual_network_subnet_id" {
  type        = string
  description = "Subnet resource ID for regional VNet integration."
  default     = null
}

variable "vnet_route_all_traffic" {
  type        = bool
  description = "Whether all outbound traffic is routed through the integrated VNet."
  default     = false
}

variable "vnet_application_traffic_enabled" {
  type        = bool
  description = "Whether application traffic uses the integrated VNet."
  default     = false
}

variable "vnet_image_pull_enabled" {
  type        = bool
  description = "Whether container image pulls are routed via the VNet (containerized Web Apps)."
  default     = null
}

variable "virtual_network_backup_restore_enabled" {
  type        = bool
  description = "Whether VNet backup/restore is enabled."
  default     = null
}

variable "private_endpoints" {
  type = map(object({
    name = optional(string, null)
    role_assignments = optional(map(object({
      role_definition_id_or_name             = string
      principal_id                           = string
      description                            = optional(string, null)
      skip_service_principal_aad_check       = optional(bool, false)
      condition                              = optional(string, null)
      condition_version                      = optional(string, null)
      delegated_managed_identity_resource_id = optional(string, null)
      principal_type                         = optional(string, null)
    })), {})
    lock = optional(object({
      kind = string
      name = optional(string, null)
    }), null)
    tags                                    = optional(map(string), null)
    subnet_resource_id                      = string
    private_dns_zone_group_name             = optional(string, "default")
    private_dns_zone_resource_ids           = optional(set(string), [])
    application_security_group_associations = optional(map(string), {})
    private_service_connection_name         = optional(string, null)
    network_interface_name                  = optional(string, null)
    location                                = optional(string, null)
    resource_group_name                     = optional(string, null)
    ip_configurations = optional(map(object({
      name               = string
      private_ip_address = string
      member_name        = optional(string, null)
    })), {})
  }))
  description = "Map of private endpoints to attach."
  default     = {}
}

variable "private_endpoints_inherit_lock" {
  type        = bool
  description = "Whether private endpoints inherit the parent's lock."
  default     = true
}

variable "private_endpoints_manage_dns_zone_group" {
  type        = bool
  description = "Whether the module manages private DNS zone groups."
  default     = true
}

variable "dns_configuration" {
  type = object({
    dns_alt_server            = optional(string)
    dns_max_cache_timeout     = optional(number)
    dns_retry_attempt_count   = optional(number)
    dns_retry_attempt_timeout = optional(number)
    dns_servers               = optional(list(string))
  })
  description = "Custom DNS configuration for the Web App."
  default     = null
}

# =====================================================================
# Identity, certs, custom domains
# =====================================================================

variable "managed_identities" {
  type = object({
    system_assigned            = optional(bool, false)
    user_assigned_resource_ids = optional(set(string), [])
  })
  description = "Managed identity configuration."
  default     = {}
}

variable "key_vault_reference_identity" {
  type        = string
  description = "User-assigned identity for Key Vault references in app settings. Use 'SystemAssigned' for the system identity."
  default     = null
}

variable "certificates" {
  type = map(object({
    name                  = optional(string)
    key_vault_id          = optional(string)
    key_vault_secret_name = optional(string)
    pfx_blob              = optional(string)
    password              = optional(string)
    host_names            = optional(list(string))
    tags                  = optional(map(string))
  }))
  description = "Map of certificates created via Microsoft.Web/certificates."
  default     = {}
}

variable "custom_domains" {
  type = map(object({
    hostname        = string
    ssl_state       = optional(string)
    thumbprint      = optional(string)
    certificate_key = optional(string)
  }))
  description = "Map of custom domain bindings. DNS records must be provisioned externally."
  default     = {}
}

variable "auto_generated_domain_name_label_scope" {
  type        = string
  description = "Scope of the auto-generated hostname label. 'TenantReuse', 'SubscriptionReuse', 'ResourceGroupReuse', or 'NoReuse'."
  default     = null
}

variable "client_certificate_enabled" {
  type        = bool
  description = "Whether client certificate authentication is enabled."
  default     = false
}

variable "client_certificate_mode" {
  type        = string
  description = "Client certificate mode. 'Required', 'Optional', or 'OptionalInteractiveUser'."
  default     = "Required"

  validation {
    condition     = contains(["Required", "Optional", "OptionalInteractiveUser"], var.client_certificate_mode)
    error_message = "client_certificate_mode must be 'Required', 'Optional', or 'OptionalInteractiveUser'."
  }
}

variable "client_certificate_exclusion_paths" {
  type        = string
  description = "Comma-separated URL paths excluded from client certificate validation."
  default     = null
}

variable "client_affinity_enabled" {
  type        = bool
  description = "Whether ARR affinity cookies are enabled (Web App session stickiness)."
  default     = false
}

variable "client_affinity_partitioning_enabled" {
  type        = bool
  description = "Whether the affinity cookie uses the CHIPS partitioned attribute."
  default     = null
}

variable "client_affinity_proxy_enabled" {
  type        = bool
  description = "Whether X-Forwarded-Host overrides host for affinity routing."
  default     = null
}

# =====================================================================
# Backup, logs, diagnostics
# =====================================================================

variable "backup" {
  type = map(object({
    enabled             = optional(bool, true)
    name                = optional(string)
    storage_account_url = optional(string)
    schedule = optional(map(object({
      frequency_interval       = optional(number)
      frequency_unit           = optional(string)
      keep_at_least_one_backup = optional(bool)
      retention_period_days    = optional(number)
      start_time               = optional(string)
    })))
  }))
  description = "Map of backup configurations."
  default     = {}
}

variable "logs" {
  type = map(object({
    application_logs = optional(map(object({
      azure_blob_storage = optional(object({
        level             = optional(string, "Off")
        retention_in_days = optional(number, 0)
        sas_url           = string
      }))
      file_system = optional(object({
        level = optional(string, "Off")
      }), {})
    })), {})
    detailed_error_messages = optional(bool, false)
    failed_requests_tracing = optional(bool, false)
    http_logs = optional(map(object({
      azure_blob_storage = optional(object({
        retention_in_days = optional(number, 0)
        sas_url           = string
      }))
      file_system = optional(object({
        retention_in_days = optional(number, 0)
        retention_in_mb   = number
      }))
    })), {})
  }))
  description = "Map of logs configuration."
  default     = {}
}

variable "diagnostic_settings" {
  type = map(object({
    name = optional(string, null)
    logs = optional(set(object({
      category       = optional(string, null)
      category_group = optional(string, null)
      enabled        = optional(bool, true)
      retention_policy = optional(object({
        days    = optional(number, 0)
        enabled = optional(bool, false)
      }), {})
    })), [])
    metrics = optional(set(object({
      category = optional(string, null)
      enabled  = optional(bool, true)
      retention_policy = optional(object({
        days    = optional(number, 0)
        enabled = optional(bool, false)
      }), {})
    })), [])
    log_analytics_destination_type           = optional(string, "Dedicated")
    workspace_resource_id                    = optional(string, null)
    storage_account_resource_id              = optional(string, null)
    event_hub_authorization_rule_resource_id = optional(string, null)
    event_hub_name                           = optional(string, null)
    marketplace_partner_resource_id          = optional(string, null)
  }))
  description = "Diagnostic settings for the Web App."
  default     = {}
}

# =====================================================================
# Application Insights
# =====================================================================

variable "application_insights_connection_string" {
  type        = string
  description = "Application Insights connection string (recommended over instrumentation key)."
  default     = null
  sensitive   = true
}

variable "application_insights_key" {
  type        = string
  description = "Application Insights instrumentation key (legacy — prefer connection string)."
  default     = null
  sensitive   = true
}

# =====================================================================
# Mounted Azure File shares (optional for Web Apps that need shared storage)
# =====================================================================

variable "storage_shares_to_mount" {
  type = map(object({
    access_key   = string
    account_name = string
    mount_path   = string
    name         = string
    share_name   = string
    type         = optional(string, "AzureFiles")
  }))
  description = "Map of Azure File shares to mount inside the Web App."
  default     = {}
  sensitive   = true
}

variable "slots_storage_shares_to_mount_sensitive_values" {
  type        = map(map(string))
  description = "Per-slot sensitive overrides for storage_shares_to_mount."
  default     = {}
  sensitive   = true
}

# =====================================================================
# RBAC, lock, tags
# =====================================================================

variable "role_assignments" {
  type = map(object({
    role_definition_id_or_name             = string
    principal_id                           = string
    description                            = optional(string, null)
    skip_service_principal_aad_check       = optional(bool, false)
    condition                              = optional(string, null)
    condition_version                      = optional(string, null)
    delegated_managed_identity_resource_id = optional(string, null)
    principal_type                         = optional(string, null)
  }))
  description = "RBAC role assignments scoped to the Web App."
  default     = {}
}

variable "lock" {
  type = object({
    kind = string
    name = optional(string, null)
  })
  description = "Optional resource lock. kind must be 'CanNotDelete' or 'ReadOnly'."
  default     = null

  validation {
    condition     = var.lock == null || contains(["CanNotDelete", "ReadOnly"], try(var.lock.kind, ""))
    error_message = "lock.kind must be 'CanNotDelete' or 'ReadOnly' when set."
  }
}

variable "deployment_slots_inherit_lock" {
  type        = bool
  description = "Whether deployment slots inherit the parent's lock."
  default     = true
}

variable "all_child_resources_inherit_tags" {
  type        = bool
  description = "Whether child resources inherit tags from the parent."
  default     = true
}

variable "tags" {
  type        = map(string)
  description = "A map of tags to apply to the Web App."
  default     = null
}

# =====================================================================
# Misc behavior
# =====================================================================

variable "redundancy_mode" {
  type        = string
  description = "Site redundancy mode. 'ActiveActive', 'Failover', 'GeoRedundant', 'Manual', or 'None'."
  default     = null

  validation {
    condition     = var.redundancy_mode == null || contains(["ActiveActive", "Failover", "GeoRedundant", "Manual", "None"], coalesce(var.redundancy_mode, "None"))
    error_message = "redundancy_mode must be 'ActiveActive', 'Failover', 'GeoRedundant', 'Manual', 'None', or null."
  }
}

variable "hyper_v" {
  type        = bool
  description = "Whether Hyper-V sandbox is enabled (Windows hosting)."
  default     = null
}

variable "scm_publish_basic_authentication_enabled" {
  type        = bool
  description = "Whether SCM basic auth publish is enabled. Set false for managed-identity-only deploys."
  default     = true
}

variable "scm_site_also_stopped" {
  type        = bool
  description = "Whether the SCM site is also stopped when the app is stopped."
  default     = null
}

variable "ftp_publish_basic_authentication_enabled" {
  type        = bool
  description = "Whether FTP basic auth publish is enabled."
  default     = false
}

variable "ssh_enabled" {
  type        = bool
  description = "Whether SSH is enabled (Linux App Service Managed Instance)."
  default     = null
}

variable "end_to_end_encryption_enabled" {
  type        = bool
  description = "Whether end-to-end encryption is enabled between front ends and workers."
  default     = null
}

variable "dapr_config" {
  type = object({
    app_id                = optional(string)
    app_port              = optional(number)
    enable_api_logging    = optional(bool)
    enabled               = optional(bool)
    http_max_request_size = optional(number)
    http_read_buffer_size = optional(number)
    log_level             = optional(string)
  })
  description = "Dapr configuration (Container Apps environment hosted Web Apps)."
  default     = null

  validation {
    condition     = var.dapr_config == null || try(var.dapr_config.log_level, null) == null || contains(["debug", "error", "info", "warn"], coalesce(try(var.dapr_config.log_level, null), "info"))
    error_message = "dapr_config.log_level must be 'debug', 'error', 'info', or 'warn'."
  }
}

variable "resource_config" {
  type = object({
    cpu    = optional(number)
    memory = optional(string)
  })
  description = "Resource requirements for Container Apps environment hosted apps."
  default     = null
}

variable "managed_environment_id" {
  type        = string
  description = "Azure Container Apps managed environment ID for hosting."
  default     = null
}

variable "hosting_environment_id" {
  type        = string
  description = "App Service Environment (ASE) ID for ASE-hosted Web Apps."
  default     = null
}

variable "workload_profile_name" {
  type        = string
  description = "Workload profile name (Container Apps environment hosted apps)."
  default     = null
}

variable "app_service_active_slot" {
  type = object({
    slot_key                 = optional(string)
    overwrite_network_config = optional(bool, true)
  })
  description = "Sets the active slot. slot_key must match a key in var.deployment_slots."
  default     = null
}

variable "zip_deploy_file" {
  type        = string
  description = "Path to a ZIP deploy artifact to push after creation."
  default     = null
}

variable "zip_deploy_wait_duration" {
  type        = string
  description = "Duration to wait after ZIP deploy completes."
  default     = null
}

# =====================================================================
# Module behavior
# =====================================================================

variable "enable_telemetry" {
  type        = bool
  description = "Whether to enable AVM module telemetry."
  default     = true
}

variable "retry" {
  type = object({
    error_message_regex = list(string)
    interval_seconds    = optional(number, 10)
    max_retries         = optional(number, 3)
  })
  description = "Retry configuration for azapi resources."
  default = {
    error_message_regex = ["Cannot modify this site because another operation is in progress"]
  }
}

variable "timeouts" {
  type = object({
    create = optional(string, null)
    delete = optional(string, null)
    read   = optional(string, null)
    update = optional(string, null)
  })
  description = "Operation timeouts."
  default     = null
}
