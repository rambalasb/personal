check "https_only_enforced" {
  assert {
    condition     = var.https_only
    error_message = "Web App https_only is false. Enable HTTPS-only traffic for compliance."
  }
}

check "public_network_access_disabled_by_default" {
  assert {
    condition     = !var.public_network_access_enabled || local.has_private_endpoints
    error_message = "public_network_access_enabled = true without any private endpoints. Either disable public access or add private endpoints."
  }
}

check "ftp_basic_auth_disabled" {
  assert {
    condition     = !var.ftp_publish_basic_authentication_enabled
    error_message = "FTP basic authentication is enabled. FTP is unencrypted — prefer disabled."
  }
}

check "scm_basic_auth_review" {
  assert {
    condition     = !var.scm_publish_basic_authentication_enabled
    error_message = "SCM basic authentication is enabled. For least-privilege deploys, switch to managed-identity-based deployment and set scm_publish_basic_authentication_enabled = false."
  }
}

check "application_insights_configured" {
  assert {
    condition     = var.application_insights_connection_string != null || var.application_insights_key != null
    error_message = "Web App has no Application Insights connection_string or instrumentation key."
  }
}
