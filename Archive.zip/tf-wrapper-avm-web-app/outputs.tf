output "resource_id" {
  description = "The Azure resource ID of the Web App."
  value       = module.web_app.resource_id
  sensitive   = true
}

output "name" {
  description = "The name of the Web App."
  value       = module.web_app.name
}

output "os_type" {
  description = "The OS type."
  value       = module.web_app.os_type
}

output "location" {
  description = "The Azure region of the Web App."
  value       = module.web_app.location
}

output "resource_uri" {
  description = "Default hostname (e.g. myapp.azurewebsites.net)."
  value       = module.web_app.resource_uri
}

output "resource" {
  description = "The full azapi Web App resource object. Sensitive."
  value       = module.web_app.resource
  sensitive   = true
}

output "active_slot" {
  description = "Resource ID of the currently active slot."
  value       = module.web_app.active_slot
}

output "deployment_slots" {
  description = "Map of deployment slots created by the module."
  value       = module.web_app.deployment_slots
}

output "deployment_slot_locks" {
  description = "Map of locks applied to deployment slots."
  value       = module.web_app.deployment_slot_locks
}

output "custom_domain_verification_id" {
  description = "Custom domain verification ID — use to create an asuid TXT record before binding a custom domain."
  value       = module.web_app.custom_domain_verification_id
}

output "private_endpoints" {
  description = "Map of private endpoints."
  value       = module.web_app.private_endpoints
}

output "identity_principal_id" {
  description = "System-assigned managed identity principal ID."
  value       = module.web_app.identity_principal_id
  sensitive   = true
}

output "system_assigned_mi_principal_id_slots" {
  description = "Map of system-assigned managed identity principal IDs per slot."
  value       = module.web_app.system_assigned_mi_principal_id_slots
  sensitive   = true
}

output "resource_lock" {
  description = "Resource lock."
  value       = module.web_app.resource_lock
}
