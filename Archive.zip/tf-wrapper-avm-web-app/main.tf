module "web_app" {
  source  = "Azure/avm-res-web-site/azurerm"
  version = "0.22.0"

  # Kind pinned by this wrapper — never expose as a variable.
  kind = "webapp"

  # Required
  name                     = var.name
  parent_id                = local.parent_id
  location                 = var.location
  service_plan_resource_id = var.service_plan_resource_id

  # OS
  os_type = var.os_type
  enabled = var.enabled

  # Polymorphic objects (any-typed)
  site_config      = var.site_config
  auth_settings    = var.auth_settings
  auth_settings_v2 = var.auth_settings_v2
  deployment_slots = var.deployment_slots

  # App settings & connection strings
  app_settings                = var.app_settings
  slot_sensitive_app_settings = var.slot_sensitive_app_settings
  connection_strings          = var.connection_strings
  sticky_settings             = var.sticky_settings

  # Network & access
  public_network_access_enabled           = var.public_network_access_enabled
  https_only                              = var.https_only
  host_names_disabled                     = var.host_names_disabled
  ip_mode                                 = var.ip_mode
  virtual_network_subnet_id               = var.virtual_network_subnet_id
  vnet_route_all_traffic                  = var.vnet_route_all_traffic
  vnet_application_traffic_enabled        = var.vnet_application_traffic_enabled
  vnet_image_pull_enabled                 = var.vnet_image_pull_enabled
  virtual_network_backup_restore_enabled  = var.virtual_network_backup_restore_enabled
  private_endpoints                       = var.private_endpoints
  private_endpoints_inherit_lock          = var.private_endpoints_inherit_lock
  private_endpoints_manage_dns_zone_group = var.private_endpoints_manage_dns_zone_group
  dns_configuration                       = var.dns_configuration

  # Identity, certs, custom domains
  managed_identities                     = var.managed_identities
  key_vault_reference_identity           = var.key_vault_reference_identity
  certificates                           = var.certificates
  custom_domains                         = var.custom_domains
  auto_generated_domain_name_label_scope = var.auto_generated_domain_name_label_scope
  client_certificate_enabled             = var.client_certificate_enabled
  client_certificate_mode                = var.client_certificate_mode
  client_certificate_exclusion_paths     = var.client_certificate_exclusion_paths
  client_affinity_enabled                = var.client_affinity_enabled
  client_affinity_partitioning_enabled   = var.client_affinity_partitioning_enabled
  client_affinity_proxy_enabled          = var.client_affinity_proxy_enabled

  # Backup, logs, diagnostics
  backup              = var.backup
  logs                = var.logs
  diagnostic_settings = var.diagnostic_settings

  # Application Insights
  application_insights_connection_string = var.application_insights_connection_string
  application_insights_key               = var.application_insights_key

  # Storage shares (optional)
  storage_shares_to_mount                        = var.storage_shares_to_mount
  slots_storage_shares_to_mount_sensitive_values = var.slots_storage_shares_to_mount_sensitive_values

  # RBAC, lock, tags
  role_assignments                 = var.role_assignments
  lock                             = var.lock
  deployment_slots_inherit_lock    = var.deployment_slots_inherit_lock
  all_child_resources_inherit_tags = var.all_child_resources_inherit_tags
  tags                             = local.module_tags

  # Misc behavior
  redundancy_mode                          = var.redundancy_mode
  hyper_v                                  = var.hyper_v
  scm_publish_basic_authentication_enabled = var.scm_publish_basic_authentication_enabled
  scm_site_also_stopped                    = var.scm_site_also_stopped
  ftp_publish_basic_authentication_enabled = var.ftp_publish_basic_authentication_enabled
  ssh_enabled                              = var.ssh_enabled
  end_to_end_encryption_enabled            = var.end_to_end_encryption_enabled
  dapr_config                              = var.dapr_config
  resource_config                          = var.resource_config
  managed_environment_id                   = var.managed_environment_id
  hosting_environment_id                   = var.hosting_environment_id
  workload_profile_name                    = var.workload_profile_name
  app_service_active_slot                  = var.app_service_active_slot
  zip_deploy_file                          = var.zip_deploy_file
  zip_deploy_wait_duration                 = var.zip_deploy_wait_duration

  # Module behavior
  enable_telemetry = var.enable_telemetry
  retry            = var.retry
  timeouts         = var.timeouts
}
