output "resource_id" {
  description = "The Azure resource ID of the Function App."
  value       = module.function_app.resource_id
  sensitive   = true
}

output "name" {
  description = "The name of the Function App."
  value       = module.function_app.name
}

output "os_type" {
  description = "The OS type."
  value       = module.function_app.os_type
}

output "location" {
  description = "The Azure region of the Function App."
  value       = module.function_app.location
}

output "resource_uri" {
  description = "Default hostname (e.g. myfunc.azurewebsites.net)."
  value       = module.function_app.resource_uri
}

output "resource" {
  description = "The full azapi Function App resource object. Sensitive."
  value       = module.function_app.resource
  sensitive   = true
}

output "active_slot" {
  description = "Resource ID of the currently active slot."
  value       = module.function_app.active_slot
}

output "deployment_slots" {
  description = "Map of deployment slots."
  value       = module.function_app.deployment_slots
}

output "deployment_slot_locks" {
  description = "Map of locks applied to deployment slots."
  value       = module.function_app.deployment_slot_locks
}

output "custom_domain_verification_id" {
  description = "Custom domain verification ID."
  value       = module.function_app.custom_domain_verification_id
}

output "private_endpoints" {
  description = "Map of private endpoints."
  value       = module.function_app.private_endpoints
}

output "identity_principal_id" {
  description = "System-assigned managed identity principal ID."
  value       = module.function_app.identity_principal_id
  sensitive   = true
}

output "system_assigned_mi_principal_id_slots" {
  description = "Map of system-assigned managed identity principal IDs per slot."
  value       = module.function_app.system_assigned_mi_principal_id_slots
  sensitive   = true
}

output "resource_lock" {
  description = "Resource lock."
  value       = module.function_app.resource_lock
}
