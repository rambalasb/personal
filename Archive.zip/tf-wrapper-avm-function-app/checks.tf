check "https_only_enforced" {
  assert {
    condition     = var.https_only
    error_message = "Function App https_only is false. Enable HTTPS-only traffic for compliance."
  }
}

check "public_network_access_disabled_by_default" {
  assert {
    condition     = !var.public_network_access_enabled || local.has_private_endpoints
    error_message = "public_network_access_enabled = true without any private endpoints. Either disable public access or add private endpoints."
  }
}

check "ftp_basic_auth_disabled" {
  assert {
    condition     = !var.ftp_publish_basic_authentication_enabled
    error_message = "FTP basic authentication is enabled. FTP is unencrypted — prefer disabled."
  }
}

check "scm_basic_auth_review" {
  assert {
    condition     = !var.scm_publish_basic_authentication_enabled
    error_message = "SCM basic authentication is enabled. For least-privilege deploys, switch to managed-identity-based deployment."
  }
}

check "functions_extension_version_pinned" {
  assert {
    condition     = local.is_flex_consumption || (var.functions_extension_version != null && var.functions_extension_version != "")
    error_message = "Function App is non-Flex-Consumption but functions_extension_version is unset/empty. Pin to '~4' (or another supported major) to avoid runtime drift."
  }
}

check "storage_uses_managed_identity_recommended" {
  assert {
    condition     = var.storage_uses_managed_identity || var.storage_authentication_type == "SystemAssignedIdentity" || var.storage_authentication_type == "UserAssignedIdentity"
    error_message = "Function App backing storage is using connection-string auth. Prefer managed identity (storage_uses_managed_identity = true and/or storage_authentication_type = 'SystemAssignedIdentity'/'UserAssignedIdentity') to eliminate static keys."
  }
}

check "application_insights_configured" {
  assert {
    condition     = var.application_insights_connection_string != null || var.application_insights_key != null
    error_message = "Function App has no Application Insights connection_string or instrumentation key. Function execution telemetry won't flow without one."
  }
}
