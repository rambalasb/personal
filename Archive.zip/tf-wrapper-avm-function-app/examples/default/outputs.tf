output "resource_id" {
  value     = module.function_app.resource_id
  sensitive = true
}

output "name" {
  value = module.function_app.name
}

output "resource_uri" {
  value = module.function_app.resource_uri
}
