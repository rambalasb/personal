# random suffix to avoid name collisions on reruns
resource "random_string" "suffix" {
  length  = 6
  lower   = true
  upper   = false
  numeric = true
  special = false
}

# subscription_id is required by the wrapper; source it from the auth context
data "azurerm_client_config" "current" {}

# native supporting RG so the example tests standalone, without a sibling module
resource "azurerm_resource_group" "this" {
  name     = "rg-avm-func-default-test-${random_string.suffix.result}"
  location = "canadacentral"
}

# consumption plan provides service_plan_resource_id
resource "azurerm_service_plan" "this" {
  name                = "asp-avm-func-default-test-${random_string.suffix.result}"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location
  os_type             = "Linux"
  sku_name            = "Y1"
}
