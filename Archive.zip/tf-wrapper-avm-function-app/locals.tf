locals {
  module_tags = merge(
    var.tags == null ? {} : var.tags,
    {
      managed-by = "terraform"
      module     = "tf-wrapper-avm-function-app"
      kind       = "functionapp"
    }
  )

  parent_id = "/subscriptions/${var.subscription_id}/resourceGroups/${var.resource_group_name}"

  has_private_endpoints = length(var.private_endpoints) > 0
  is_flex_consumption   = var.function_app_uses_fc1 == true
}
