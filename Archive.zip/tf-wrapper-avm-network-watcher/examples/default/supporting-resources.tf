# random suffix to avoid name collisions on reruns
resource "random_string" "suffix" {
  length  = 6
  lower   = true
  upper   = false
  numeric = true
  special = false
}

# native supporting RG so the example tests standalone, without a sibling module
resource "azurerm_resource_group" "this" {
  name     = "rg-avm-nw-default-test-${random_string.suffix.result}"
  location = "canadacentral"
}

# wrapper reads an existing watcher; Azure auto-creates one per region in NetworkWatcherRG
data "azurerm_network_watcher" "this" {
  name                = "NetworkWatcher_${azurerm_resource_group.this.location}"
  resource_group_name = "NetworkWatcherRG"
}

# the wrapper is a no-op without a child resource, so provide a flow log target + sink
resource "azurerm_network_security_group" "this" {
  name                = "nsg-avm-nw-default-test-${random_string.suffix.result}"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location
}

resource "azurerm_storage_account" "this" {
  name                     = "stnwdefault${random_string.suffix.result}"
  resource_group_name      = azurerm_resource_group.this.name
  location                 = azurerm_resource_group.this.location
  account_tier             = "Standard"
  account_replication_type = "LRS"
}
