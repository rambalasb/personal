module "network_watcher" {
  source = "../.."

  network_watcher_id   = data.azurerm_network_watcher.this.id
  network_watcher_name = data.azurerm_network_watcher.this.name
  resource_group_name  = data.azurerm_network_watcher.this.resource_group_name
  location             = azurerm_resource_group.this.location

  # wrapper manages child resources only; one flow log keeps it from being a no-op
  flow_logs = {
    default = {
      enabled            = true
      name               = "fl-avm-nw-default-test-${random_string.suffix.result}"
      target_resource_id = azurerm_network_security_group.this.id
      storage_account_id = azurerm_storage_account.this.id
      retention_policy = {
        # 90 days to clear the compliance retention check
        days    = 90
        enabled = true
      }
    }
  }

  enable_telemetry = false
}
