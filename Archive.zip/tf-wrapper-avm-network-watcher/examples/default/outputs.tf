output "resource_id" {
  value = module.network_watcher.resource_id
}

output "resource_flow_log" {
  value = module.network_watcher.resource_flow_log
}
