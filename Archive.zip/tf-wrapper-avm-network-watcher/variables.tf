# =====================================================================
# Required inputs — reference an EXISTING Network Watcher
#
# This wrapper does NOT create the Network Watcher resource itself.
# Azure auto-creates one per region (NetworkWatcherRG/NetworkWatcher_<region>);
# supply its name + resource ID here. The wrapper manages Flow Logs and
# Connection Monitors as child resources of that watcher.
# =====================================================================

variable "network_watcher_id" {
  type        = string
  description = "Resource ID of an existing Network Watcher. Typically /subscriptions/<sub>/resourceGroups/NetworkWatcherRG/providers/Microsoft.Network/networkWatchers/NetworkWatcher_<region>."

  validation {
    condition     = can(regex("^/subscriptions/[^/]+/resourceGroups/[^/]+/providers/Microsoft\\.Network/networkWatchers/[^/]+$", var.network_watcher_id))
    error_message = "network_watcher_id must be a valid Microsoft.Network/networkWatchers resource ID."
  }
}

variable "network_watcher_name" {
  type        = string
  description = "Name of the existing Network Watcher (must match the name in network_watcher_id)."

  validation {
    condition     = length(var.network_watcher_name) > 0
    error_message = "network_watcher_name must not be empty."
  }
}

variable "resource_group_name" {
  type        = string
  description = "Name of the Resource Group hosting the Network Watcher (typically 'NetworkWatcherRG')."

  validation {
    condition     = length(var.resource_group_name) > 0 && length(var.resource_group_name) <= 90
    error_message = "resource_group_name must be 1-90 characters."
  }
}

variable "location" {
  type        = string
  description = "Azure region of the Network Watcher (used to scope Flow Logs and Connection Monitors)."

  validation {
    condition     = length(var.location) > 0
    error_message = "location must not be empty."
  }
}

# =====================================================================
# Flow Logs — capture NSG / VNet traffic to a Storage Account
# =====================================================================

variable "flow_logs" {
  type = map(object({
    enabled            = bool
    name               = string
    target_resource_id = string
    retention_policy = object({
      days    = number
      enabled = bool
    })
    storage_account_id = string
    traffic_analytics = optional(object({
      enabled               = bool
      interval_in_minutes   = optional(number)
      workspace_id          = string
      workspace_region      = string
      workspace_resource_id = string
      }), {
      enabled               = false
      interval_in_minutes   = 0
      workspace_id          = null
      workspace_region      = null
      workspace_resource_id = null
    })
    version = optional(number, null)
  }))
  description = <<DESC
Map of Network Watcher Flow Logs. Each entry captures traffic from an NSG or VNet to a Storage Account.

- enabled: whether the flow log is active
- name: flow log resource name
- target_resource_id: NSG or VNet resource ID to capture from
- storage_account_id: where flow logs are written
- version: 1 or 2 (default Azure picks 2)
- retention_policy.days: retention period (recommend >= 90 for compliance)
- retention_policy.enabled: whether the retention policy is enforced
- traffic_analytics (optional): enables Log Analytics-based traffic analytics
  - enabled: turn analytics on/off
  - workspace_id (GUID), workspace_region, workspace_resource_id: target LAW
  - interval_in_minutes: 10 or 60 (default 60)
DESC
  default     = null

  validation {
    condition = var.flow_logs == null || alltrue([
      for k, fl in coalesce(var.flow_logs, {}) :
      fl.version == null || contains([1, 2], fl.version)
    ])
    error_message = "Each flow_logs.version must be 1 or 2 (or null)."
  }

  validation {
    condition = var.flow_logs == null || alltrue([
      for k, fl in coalesce(var.flow_logs, {}) :
      fl.retention_policy.days >= 0 && fl.retention_policy.days <= 365
    ])
    error_message = "Each flow_logs.retention_policy.days must be between 0 and 365."
  }

  validation {
    condition = var.flow_logs == null || alltrue([
      for k, fl in coalesce(var.flow_logs, {}) :
      can(regex("^/subscriptions/[^/]+/resourceGroups/[^/]+/providers/Microsoft\\.Network/(networkSecurityGroups|virtualNetworks)/[^/]+$", fl.target_resource_id))
    ])
    error_message = "Each flow_logs.target_resource_id must be a Microsoft.Network/networkSecurityGroups or Microsoft.Network/virtualNetworks resource ID."
  }
}

# =====================================================================
# Connection Monitors — synthetic probes between endpoints
# =====================================================================

variable "condition_monitor" {
  type = map(object({
    name = string
    endpoint = set(object({
      address               = optional(string)
      coverage_level        = optional(string)
      excluded_ip_addresses = optional(set(string))
      included_ip_addresses = optional(set(string))
      name                  = string
      target_resource_id    = optional(string)
      target_resource_type  = optional(string)
      filter = optional(object({
        type = optional(string)
        item = optional(set(object({
          address = optional(string)
          type    = optional(string)
        })))
      }))
    }))
    test_configuration = set(object({
      name                      = string
      preferred_ip_version      = optional(string)
      protocol                  = string
      test_frequency_in_seconds = optional(number)
      http_configuration = optional(object({
        method                   = optional(string)
        path                     = optional(string)
        port                     = optional(number)
        prefer_https             = optional(bool)
        protocol                 = string
        valid_status_code_ranges = optional(set(string))
        request_header = optional(set(object({
          name  = string
          value = string
        })))
      }))
      icmp_configuration = optional(object({
        trace_route_enabled = optional(bool)
      }))
      success_threshold = optional(object({
        checks_failed_percent = optional(number)
        round_trip_time_ms    = optional(number)
      }))
      tcp_configuration = optional(object({
        destination_port_behavior = optional(string)
        port                      = number
        trace_route_enabled       = optional(bool)
      }))
    }))
    test_group = set(object({
      destination_endpoints    = set(string)
      enabled                  = optional(bool)
      name                     = string
      source_endpoints         = set(string)
      test_configuration_names = set(string)
    }))
    notes                         = optional(string, null)
    output_workspace_resource_ids = optional(list(string), null)
  }))
  description = <<DESC
Map of Network Connection Monitors. Each entry runs synthetic probes from source endpoints to destination endpoints on a schedule.

- name: connection monitor resource name
- endpoint: set of named endpoints (sources and destinations); each can be an Azure VM, subnet, VNet, Arc machine, or external address
- test_configuration: set of named test configs (HTTP, TCP, or ICMP probes)
- test_group: set of named test groups that bind sources, destinations, and test configurations together
- notes: free-text description
- output_workspace_resource_ids: list of Log Analytics workspaces to receive probe results
DESC
  default     = null

  validation {
    condition = var.condition_monitor == null || alltrue([
      for k, cm in coalesce(var.condition_monitor, {}) :
      length(cm.endpoint) >= 2
    ])
    error_message = "Each condition_monitor must define at least 2 endpoints (one source and one destination)."
  }

  validation {
    condition = var.condition_monitor == null || alltrue(flatten([
      for k, cm in coalesce(var.condition_monitor, {}) : [
        for tc in cm.test_configuration : contains(["Tcp", "Http", "Icmp"], tc.protocol)
      ]
    ]))
    error_message = "Each test_configuration.protocol must be 'Tcp', 'Http', or 'Icmp'."
  }
}

# =====================================================================
# Governance
# =====================================================================

variable "role_assignments" {
  type = map(object({
    role_definition_id_or_name             = string
    principal_id                           = string
    description                            = optional(string, null)
    skip_service_principal_aad_check       = optional(bool, false)
    condition                              = optional(string, null)
    condition_version                      = optional(string, null)
    delegated_managed_identity_resource_id = optional(string, null)
    principal_type                         = optional(string, null)
  }))
  description = "RBAC role assignments scoped to the Network Watcher. Common roles: 'Network Contributor', 'Reader'."
  default     = {}
}

variable "lock" {
  type = object({
    kind = string
    name = optional(string, null)
  })
  description = "Optional resource lock. kind must be 'CanNotDelete' or 'ReadOnly'."
  default     = null

  validation {
    condition     = var.lock == null || contains(["CanNotDelete", "ReadOnly"], try(var.lock.kind, ""))
    error_message = "lock.kind must be 'CanNotDelete' or 'ReadOnly' when set."
  }
}

# =====================================================================
# Module behavior
# =====================================================================

variable "enable_telemetry" {
  type        = bool
  description = "Whether to enable AVM module telemetry. Set false to opt out."
  default     = true
}

variable "tags" {
  type        = map(string)
  description = "A map of tags to apply to managed child resources (flow logs and connection monitors)."
  default     = null
}

# =====================================================================
# Cross-input validation
# =====================================================================

variable "_validate_at_least_one_child_resource" {
  type        = bool
  description = "Internal sentinel — do not set."
  default     = true

  validation {
    condition     = (var.flow_logs != null && length(coalesce(var.flow_logs, {})) > 0) || (var.condition_monitor != null && length(coalesce(var.condition_monitor, {})) > 0)
    error_message = "At least one of var.flow_logs or var.condition_monitor must contain entries. This module is a no-op without them — it does not create the Network Watcher itself."
  }
}
