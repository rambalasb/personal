module "network_watcher" {
  source  = "Azure/avm-res-network-networkwatcher/azurerm"
  version = "0.3.2"

  # Reference to existing Network Watcher (this module reads, doesn't create)
  network_watcher_id   = var.network_watcher_id
  network_watcher_name = var.network_watcher_name
  resource_group_name  = var.resource_group_name
  location             = var.location

  # Child resources
  flow_logs         = var.flow_logs
  condition_monitor = var.condition_monitor

  # Governance
  role_assignments = var.role_assignments
  lock             = var.lock

  # Module behavior
  enable_telemetry = var.enable_telemetry
  tags             = local.module_tags
}
