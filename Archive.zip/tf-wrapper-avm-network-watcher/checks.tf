check "manages_at_least_one_child_resource" {
  assert {
    condition     = local.flow_log_count + local.connection_monitor_count > 0
    error_message = "Network Watcher wrapper has neither flow_logs nor condition_monitor configured. This module manages child resources of an existing watcher — without at least one entry it's a no-op."
  }
}

check "flow_logs_retention_meets_compliance_minimum" {
  assert {
    condition     = length(local.flow_logs_with_weak_retention) == 0
    error_message = "Flow log(s) ${join(", ", local.flow_logs_with_weak_retention)} have retention disabled or set below 90 days. Most compliance frameworks (PCI, HIPAA, SOC 2) require >= 90 days of network log retention."
  }
}

check "flow_logs_have_traffic_analytics_enabled" {
  assert {
    condition     = length(local.flow_logs_without_traffic_analytics) == 0
    error_message = "Flow log(s) ${join(", ", local.flow_logs_without_traffic_analytics)} don't have traffic_analytics enabled. Enable it to get usable insights from the raw flow records via Log Analytics."
  }
}
