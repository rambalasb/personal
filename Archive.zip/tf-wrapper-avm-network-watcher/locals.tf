locals {
  module_tags = merge(
    var.tags == null ? {} : var.tags,
    {
      managed-by = "terraform"
      module     = "tf-wrapper-avm-network-watcher"
    }
  )

  # Counts used by checks.tf
  flow_log_count          = var.flow_logs == null ? 0 : length(var.flow_logs)
  connection_monitor_count = var.condition_monitor == null ? 0 : length(var.condition_monitor)

  # Flow logs without retention enabled, or with retention < 90 days.
  flow_logs_with_weak_retention = var.flow_logs == null ? [] : [
    for k, fl in var.flow_logs : k
    if !fl.retention_policy.enabled || fl.retention_policy.days < 90
  ]

  # Flow logs without traffic analytics enabled.
  flow_logs_without_traffic_analytics = var.flow_logs == null ? [] : [
    for k, fl in var.flow_logs : k
    if !try(fl.traffic_analytics.enabled, false)
  ]
}
