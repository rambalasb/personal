output "resource_id" {
  description = "The Azure resource ID of the existing Network Watcher (echoes var.network_watcher_id). This module does not create the watcher itself."
  value       = module.network_watcher.resource_id
}

output "resource" {
  description = "Data-source read of the existing Network Watcher resource."
  value       = module.network_watcher.resource
}

output "resource_flow_log" {
  description = "The full set of Flow Log resources managed by this module (azapi_resource.flow_logs)."
  value       = module.network_watcher.resource_flow_log
}

output "resource_connection_monitor" {
  description = "The full set of Connection Monitor resources managed by this module (azurerm_network_connection_monitor)."
  value       = module.network_watcher.resource_connection_monitor
}
