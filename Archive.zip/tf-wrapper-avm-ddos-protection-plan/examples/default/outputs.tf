output "resource_id" {
  value = module.ddos_protection_plan.resource_id
}

output "name" {
  value = module.ddos_protection_plan.name
}

output "resource" {
  value = module.ddos_protection_plan.resource
}
