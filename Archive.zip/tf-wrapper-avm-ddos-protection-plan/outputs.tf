output "resource_id" {
  description = "The Azure resource ID of the DDoS Protection Plan. Attach VNets and Public IPs to this ID via their respective ddos_protection_plan / ddos_protection_plan_id blocks."
  value       = module.ddos_protection_plan.resource_id
}

output "name" {
  description = "The name of the DDoS Protection Plan."
  value       = module.ddos_protection_plan.name
}

output "resource" {
  description = "The full azurerm_network_ddos_protection_plan resource object."
  value       = module.ddos_protection_plan.resource
}
