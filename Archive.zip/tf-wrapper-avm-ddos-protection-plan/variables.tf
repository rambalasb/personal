# =====================================================================
# Required inputs
# =====================================================================

variable "name" {
  type        = string
  description = "Name of the DDoS Protection Plan. 1-80 chars; alphanumerics, periods, underscores, hyphens, parentheses; must start with alphanumeric or underscore and end with alphanumeric, underscore, or parenthesis."

  validation {
    condition     = can(regex("^[a-zA-Z0-9_][a-zA-Z0-9._()-]{0,78}[a-zA-Z0-9_()]$", var.name)) || can(regex("^[a-zA-Z0-9_]$", var.name))
    error_message = "name must be 1-80 characters, alphanumerics/periods/underscores/hyphens/parentheses, starting with alphanumeric or underscore."
  }
}

variable "resource_group_name" {
  type        = string
  description = "Name of the Resource Group where the DDoS Protection Plan will be deployed."

  validation {
    condition     = length(var.resource_group_name) > 0 && length(var.resource_group_name) <= 90
    error_message = "resource_group_name must be 1-90 characters."
  }
}

variable "location" {
  type        = string
  description = "Azure region where the DDoS Protection Plan will be deployed."

  validation {
    condition     = length(var.location) > 0
    error_message = "location must not be empty."
  }
}

# =====================================================================
# Governance
# =====================================================================

variable "role_assignments" {
  type = map(object({
    role_definition_id_or_name             = string
    principal_id                           = string
    description                            = optional(string, null)
    skip_service_principal_aad_check       = optional(bool, false)
    condition                              = optional(string, null)
    condition_version                      = optional(string, null)
    delegated_managed_identity_resource_id = optional(string, null)
    principal_type                         = optional(string, null)
  }))
  description = "RBAC role assignments scoped to the DDoS Protection Plan. Common roles: 'Network Contributor', 'Reader'."
  default     = {}
}

variable "lock" {
  type = object({
    kind = string
    name = optional(string, null)
  })
  description = "Optional resource lock. kind must be 'CanNotDelete' or 'ReadOnly'. STRONGLY recommended for DDoS plans given their cost (~$2,944/mo)."
  default     = null

  validation {
    condition     = var.lock == null || contains(["CanNotDelete", "ReadOnly"], try(var.lock.kind, ""))
    error_message = "lock.kind must be 'CanNotDelete' or 'ReadOnly' when set."
  }
}

# =====================================================================
# Module behavior
# =====================================================================

variable "enable_telemetry" {
  type        = bool
  description = "Whether to enable AVM module telemetry. Set false to opt out."
  default     = true
}

variable "tags" {
  type        = map(string)
  description = "A map of tags to apply to the DDoS Protection Plan. Recommend cost-allocation tags given the plan's monthly price."
  default     = null
}
