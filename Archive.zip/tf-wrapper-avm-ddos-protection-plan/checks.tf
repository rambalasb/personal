check "lock_recommended_for_expensive_resource" {
  assert {
    condition     = var.lock != null && try(var.lock.kind, "") == "CanNotDelete"
    error_message = "DDoS Protection Plans cost approximately $2,944/month. Set lock = { kind = \"CanNotDelete\" } to protect against accidental deletion."
  }
}

check "cost_allocation_tags_present" {
  assert {
    condition     = length(local.module_tags) > 2
    error_message = "DDoS Protection Plan has no caller-supplied tags. Given the monthly cost, add cost-allocation tags (e.g. cost-center, owner, environment) via var.tags."
  }
}
