output "resource_id" {
  value = module.network_security_group.resource_id
}

output "name" {
  value = module.network_security_group.name
}

output "security_rules" {
  value = module.network_security_group.security_rules
}
