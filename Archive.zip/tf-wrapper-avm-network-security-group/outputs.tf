output "resource_id" {
  description = "The Azure resource ID of the Network Security Group."
  value       = module.network_security_group.resource_id
}

output "name" {
  description = "The name of the Network Security Group."
  value       = module.network_security_group.name
}

output "security_rules" {
  description = "Map of security rules created on the NSG, keyed by the input map key. Empty-set attributes are normalized for idempotent plans."
  value       = module.network_security_group.security_rules
}
