locals {
  module_tags = merge(
    var.tags == null ? {} : var.tags,
    {
      managed-by = "terraform"
      module     = "tf-wrapper-avm-network-security-group"
    }
  )

  # Sets used by post-deploy checks.
  inbound_allow_rules = {
    for k, r in var.security_rules :
    k => r if r.access == "Allow" && r.direction == "Inbound"
  }

  inbound_allow_from_internet = {
    for k, r in local.inbound_allow_rules :
    k => r if(
      r.source_address_prefix == "Internet" ||
      r.source_address_prefix == "*" ||
      r.source_address_prefix == "0.0.0.0/0"
    )
  }

  inbound_allow_to_any_port = {
    for k, r in local.inbound_allow_rules :
    k => r if(r.destination_port_range == "*")
  }
}
