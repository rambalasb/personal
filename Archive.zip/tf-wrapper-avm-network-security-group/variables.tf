# =====================================================================
# Required inputs
# =====================================================================

variable "name" {
  type        = string
  description = "Name of the Network Security Group. 1-80 chars; alphanumerics, underscores, periods, hyphens. Must start with alphanumeric and end with alphanumeric or underscore."

  validation {
    condition     = can(regex("^[[:alnum:]]([[:alnum:]_.-]{0,78}?[[:alnum:]_])?$", var.name))
    error_message = "name must be 1-80 characters, alphanumerics/underscores/periods/hyphens, starting with alphanumeric and ending with alphanumeric or underscore."
  }
}

variable "resource_group_name" {
  type        = string
  description = "Name of the Resource Group where the NSG will be deployed."

  validation {
    condition     = length(var.resource_group_name) > 0 && length(var.resource_group_name) <= 90
    error_message = "resource_group_name must be 1-90 characters."
  }
}

variable "location" {
  type        = string
  description = "Azure region where the NSG will be deployed."

  validation {
    condition     = length(var.location) > 0
    error_message = "location must not be empty."
  }
}

# =====================================================================
# Security rules
# =====================================================================

variable "security_rules" {
  type = map(object({
    access                                     = string
    description                                = optional(string)
    destination_address_prefix                 = optional(string)
    destination_address_prefixes               = optional(set(string))
    destination_application_security_group_ids = optional(set(string))
    destination_port_range                     = optional(string)
    destination_port_ranges                    = optional(set(string))
    direction                                  = string
    name                                       = string
    priority                                   = number
    protocol                                   = string
    source_address_prefix                      = optional(string)
    source_address_prefixes                    = optional(set(string))
    source_application_security_group_ids      = optional(set(string))
    source_port_range                          = optional(string)
    source_port_ranges                         = optional(set(string))
    timeouts = optional(object({
      create = optional(string)
      delete = optional(string)
      read   = optional(string)
      update = optional(string)
    }))
  }))
  description = <<DESC
Map of security rules. Each rule requires: name, access ('Allow'/'Deny'), direction ('Inbound'/'Outbound'), priority (100-4096, unique per NSG), protocol ('Tcp'/'Udp'/'Icmp'/'Esp'/'Ah'/'*'). Exactly one of source_address_prefix/source_address_prefixes/source_application_security_group_ids must be set; same for destinations and port ranges.
DESC
  default     = {}

  validation {
    condition     = alltrue([for _, r in var.security_rules : contains(["Allow", "Deny"], r.access)])
    error_message = "Each security rule's access must be 'Allow' or 'Deny'."
  }

  validation {
    condition     = alltrue([for _, r in var.security_rules : contains(["Inbound", "Outbound"], r.direction)])
    error_message = "Each security rule's direction must be 'Inbound' or 'Outbound'."
  }

  validation {
    condition     = alltrue([for _, r in var.security_rules : contains(["Tcp", "Udp", "Icmp", "Esp", "Ah", "*"], r.protocol)])
    error_message = "Each security rule's protocol must be one of: 'Tcp', 'Udp', 'Icmp', 'Esp', 'Ah', '*'."
  }

  validation {
    condition     = alltrue([for _, r in var.security_rules : r.priority >= 100 && r.priority <= 4096])
    error_message = "Each security rule's priority must be between 100 and 4096."
  }

  validation {
    condition     = length([for _, r in var.security_rules : r.priority]) == length(distinct([for _, r in var.security_rules : r.priority]))
    error_message = "Security rule priorities must be unique within the NSG."
  }

  validation {
    condition = alltrue([
      for _, r in var.security_rules :
      (r.source_address_prefix != null ? 1 : 0) +
      (r.source_address_prefixes != null && length(coalesce(r.source_address_prefixes, [])) > 0 ? 1 : 0) +
      (r.source_application_security_group_ids != null && length(coalesce(r.source_application_security_group_ids, [])) > 0 ? 1 : 0) == 1
    ])
    error_message = "Each security rule must set exactly one of: source_address_prefix, source_address_prefixes, source_application_security_group_ids."
  }

  validation {
    condition = alltrue([
      for _, r in var.security_rules :
      (r.destination_address_prefix != null ? 1 : 0) +
      (r.destination_address_prefixes != null && length(coalesce(r.destination_address_prefixes, [])) > 0 ? 1 : 0) +
      (r.destination_application_security_group_ids != null && length(coalesce(r.destination_application_security_group_ids, [])) > 0 ? 1 : 0) == 1
    ])
    error_message = "Each security rule must set exactly one of: destination_address_prefix, destination_address_prefixes, destination_application_security_group_ids."
  }

  validation {
    condition = alltrue([
      for _, r in var.security_rules :
      (r.source_port_range != null ? 1 : 0) +
      (r.source_port_ranges != null && length(coalesce(r.source_port_ranges, [])) > 0 ? 1 : 0) == 1
    ])
    error_message = "Each security rule must set exactly one of: source_port_range or source_port_ranges."
  }

  validation {
    condition = alltrue([
      for _, r in var.security_rules :
      (r.destination_port_range != null ? 1 : 0) +
      (r.destination_port_ranges != null && length(coalesce(r.destination_port_ranges, [])) > 0 ? 1 : 0) == 1
    ])
    error_message = "Each security rule must set exactly one of: destination_port_range or destination_port_ranges."
  }
}

# =====================================================================
# Governance
# =====================================================================

variable "role_assignments" {
  type = map(object({
    role_definition_id_or_name             = string
    principal_id                           = string
    description                            = optional(string, null)
    skip_service_principal_aad_check       = optional(bool, false)
    condition                              = optional(string, null)
    condition_version                      = optional(string, null)
    delegated_managed_identity_resource_id = optional(string, null)
    principal_type                         = optional(string, null)
  }))
  description = "RBAC role assignments scoped to the NSG. Common roles: 'Network Contributor', 'Reader'."
  default     = {}
}

variable "lock" {
  type = object({
    kind = string
    name = optional(string, null)
  })
  description = "Optional resource lock. kind must be 'CanNotDelete' or 'ReadOnly'."
  default     = null

  validation {
    condition     = var.lock == null || contains(["CanNotDelete", "ReadOnly"], try(var.lock.kind, ""))
    error_message = "lock.kind must be 'CanNotDelete' or 'ReadOnly' when lock is set."
  }
}

# =====================================================================
# Diagnostics
# =====================================================================

variable "diagnostic_settings" {
  type = map(object({
    name                                     = optional(string, null)
    log_categories                           = optional(set(string), [])
    log_groups                               = optional(set(string), ["allLogs"])
    metric_categories                        = optional(set(string), ["AllMetrics"])
    log_analytics_destination_type           = optional(string, "Dedicated")
    workspace_resource_id                    = optional(string, null)
    storage_account_resource_id              = optional(string, null)
    event_hub_authorization_rule_resource_id = optional(string, null)
    event_hub_name                           = optional(string, null)
    marketplace_partner_resource_id          = optional(string, null)
  }))
  description = "Diagnostic settings for the NSG. At least one destination per entry."
  default     = {}
}

# =====================================================================
# Module behavior
# =====================================================================

variable "enable_telemetry" {
  type        = bool
  description = "Whether to enable AVM module telemetry. Set false to opt out."
  default     = true
}

variable "tags" {
  type        = map(string)
  description = "A map of tags to apply to the NSG."
  default     = null
}

variable "timeouts" {
  type = object({
    create = optional(string)
    delete = optional(string)
    read   = optional(string)
    update = optional(string)
  })
  description = "Operation timeouts for the NSG resource."
  default     = null
}
