module "network_security_group" {
  source  = "Azure/avm-res-network-networksecuritygroup/azurerm"
  version = "0.5.1"

  # Required
  name                = var.name
  resource_group_name = var.resource_group_name
  location            = var.location

  # Security rules
  security_rules = var.security_rules

  # Governance
  role_assignments = var.role_assignments
  lock             = var.lock

  # Diagnostics
  diagnostic_settings = var.diagnostic_settings

  # Module behavior
  enable_telemetry = var.enable_telemetry
  tags             = local.module_tags
  timeouts         = var.timeouts
}
