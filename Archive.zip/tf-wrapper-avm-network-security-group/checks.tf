check "no_inbound_allow_from_internet" {
  assert {
    condition     = length(local.inbound_allow_from_internet) == 0
    error_message = "NSG has inbound Allow rule(s) from 'Internet' / '*' / '0.0.0.0/0': ${join(", ", keys(local.inbound_allow_from_internet))}. Scope these to specific source prefixes or service tags."
  }
}

check "no_inbound_allow_to_any_port" {
  assert {
    condition     = length(local.inbound_allow_to_any_port) == 0
    error_message = "NSG has inbound Allow rule(s) targeting all ports ('*'): ${join(", ", keys(local.inbound_allow_to_any_port))}. Restrict to specific destination ports or ranges."
  }
}

check "no_management_ports_open_to_internet" {
  assert {
    condition = length([
      for k, r in local.inbound_allow_rules : k
      if(
        (r.source_address_prefix == "Internet" || r.source_address_prefix == "*" || r.source_address_prefix == "0.0.0.0/0") &&
        (
          r.destination_port_range == "22" ||
          r.destination_port_range == "3389" ||
          r.destination_port_range == "5985" ||
          r.destination_port_range == "5986" ||
          contains(coalesce(r.destination_port_ranges, []), "22") ||
          contains(coalesce(r.destination_port_ranges, []), "3389") ||
          contains(coalesce(r.destination_port_ranges, []), "5985") ||
          contains(coalesce(r.destination_port_ranges, []), "5986")
        )
      )
    ]) == 0
    error_message = "NSG has inbound rule(s) opening management ports (SSH 22 / RDP 3389 / WinRM 5985-5986) to the internet. Use Bastion, JIT, or a restricted source prefix instead."
  }
}

check "diagnostic_settings_configured" {
  assert {
    condition     = length(var.diagnostic_settings) > 0
    error_message = "NSG has no diagnostic settings configured. Enable NSG flow logs (via diagnostic_settings) to support traffic analytics and security investigations."
  }
}
