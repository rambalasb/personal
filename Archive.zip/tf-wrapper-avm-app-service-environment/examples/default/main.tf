module "app_service_environment" {
  source = "../.."

  name                = "ase-avm-${random_string.suffix.result}"
  subscription_id     = data.azurerm_client_config.current.subscription_id
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location
  subnet_id           = azurerm_subnet.ase.id

  enable_telemetry = false
}
