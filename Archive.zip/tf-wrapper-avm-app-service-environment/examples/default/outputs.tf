output "resource_id" {
  value = module.app_service_environment.resource_id
}

output "name" {
  value = module.app_service_environment.name
}

output "dns_suffix" {
  value = module.app_service_environment.dns_suffix
}
