# random suffix to avoid name collisions on reruns
resource "random_string" "suffix" {
  length  = 6
  lower   = true
  upper   = false
  numeric = true
  special = false
}

# subscription_id for the AVM parent_id comes from the authenticated context
data "azurerm_client_config" "current" {}

# native supporting RG so the example tests standalone, without a sibling module
resource "azurerm_resource_group" "this" {
  name     = "rg-avm-ase-default-test-${random_string.suffix.result}"
  location = "canadacentral"
}

resource "azurerm_virtual_network" "this" {
  name                = "vnet-avm-ase-default-test-${random_string.suffix.result}"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location
  address_space       = ["10.0.0.0/16"]
}

# ASE requires a dedicated subnet delegated to Microsoft.Web/hostingEnvironments
resource "azurerm_subnet" "ase" {
  name                 = "snet-ase"
  resource_group_name  = azurerm_resource_group.this.name
  virtual_network_name = azurerm_virtual_network.this.name
  address_prefixes     = ["10.0.1.0/24"]

  delegation {
    name = "ase-delegation"

    service_delegation {
      name = "Microsoft.Web/hostingEnvironments"
    }
  }
}
