output "resource_id" {
  description = "The Azure resource ID of the App Service Environment."
  value       = module.app_service_environment.resource_id
}

output "name" {
  description = "The name of the App Service Environment."
  value       = module.app_service_environment.name
}

output "dns_suffix" {
  description = "The DNS suffix of the ASE (e.g. 'myase.appserviceenvironment.net' for an internal ASE). Use this to target sites deployed inside the ASE."
  value       = module.app_service_environment.dns_suffix
}

output "external_inbound_ip_addresses" {
  description = "External (public) inbound IP addresses of the ASE. Empty for fully-internal ASEs."
  value       = module.app_service_environment.external_inbound_ip_addresses
}

output "internal_inbound_ip_addresses" {
  description = "Internal (ILB) inbound IP addresses of the ASE. The ILB IPs sites in the ASE will be reachable on."
  value       = module.app_service_environment.internal_inbound_ip_addresses
}

output "linux_outbound_ip_addresses" {
  description = "Outbound IP addresses for Linux workers in the ASE. Use these for downstream firewall allowlisting."
  value       = module.app_service_environment.linux_outbound_ip_addresses
}

output "windows_outbound_ip_addresses" {
  description = "Outbound IP addresses for Windows workers in the ASE."
  value       = module.app_service_environment.windows_outbound_ip_addresses
}

output "system_assigned_managed_identity_principal_id" {
  description = "Principal ID of the ASE's system-assigned managed identity, if enabled."
  value       = module.app_service_environment.system_assigned_managed_identity_principal_id
}
