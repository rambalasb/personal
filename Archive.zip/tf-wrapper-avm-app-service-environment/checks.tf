check "internal_load_balancing_for_private_workloads" {
  assert {
    condition     = local.is_internal_ase
    error_message = "App Service Environment internal_load_balancing_mode is 'None' — sites in this ASE will be exposed to the public internet. For private workloads, use 'Web, Publishing'."
  }
}

check "internal_encryption_enabled" {
  assert {
    condition     = var.internal_encryption_enabled
    error_message = "internal_encryption_enabled is false. Traffic between ASE front-ends and workers should be encrypted."
  }
}

check "tls_1_disabled" {
  assert {
    condition     = !var.tls_1_enabled
    error_message = "TLS 1.0 is enabled on the ASE. TLS 1.0 and 1.1 are deprecated — keep tls_1_enabled = false."
  }
}

check "ftp_disabled" {
  assert {
    condition     = !var.ftp_enabled
    error_message = "FTP is enabled on the ASE. FTP is unencrypted and a frequent attack vector — keep ftp_enabled = false."
  }
}

check "zone_redundancy_enabled_for_production" {
  assert {
    condition     = var.zone_redundancy_enabled
    error_message = "zone_redundancy_enabled is false. Production ASEs should be zone-redundant for HA (requires a supported region)."
  }
}

check "remote_debug_disabled" {
  assert {
    condition     = var.remote_debug_enabled != true
    error_message = "remote_debug_enabled is true. Disable in production — leaves a debugger port open."
  }
}

check "lock_recommended_for_expensive_resource" {
  assert {
    condition     = var.lock != null
    error_message = "App Service Environments cost approximately $1000+/month and take 4-6 hours to recreate. Set var.lock = { kind = \"CanNotDelete\" } to protect against accidental deletion."
  }
}
