locals {
  module_tags = merge(
    var.tags == null ? {} : var.tags,
    {
      managed-by = "terraform"
      module     = "tf-wrapper-avm-app-service-environment"
    }
  )

  # AVM uses parent_id (RG resource ID). Derive for caller convenience.
  parent_id = "/subscriptions/${var.subscription_id}/resourceGroups/${var.resource_group_name}"

  is_internal_ase = var.internal_load_balancing_mode != "None"
}
