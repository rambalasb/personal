module "app_service_environment" {
  source  = "Azure/avm-res-web-hostingenvironment/azurerm"
  version = "2.0.1"

  # Required
  name      = var.name
  parent_id = local.parent_id
  location  = var.location
  subnet_id = var.subnet_id

  # Core security/network toggles
  internal_load_balancing_mode           = var.internal_load_balancing_mode
  zone_redundancy_enabled                = var.zone_redundancy_enabled
  internal_encryption_enabled            = var.internal_encryption_enabled
  ftp_enabled                            = var.ftp_enabled
  fips_mode_enabled                      = var.fips_mode_enabled
  tls_1_enabled                          = var.tls_1_enabled
  allow_new_private_endpoint_connections = var.allow_new_private_endpoint_connections
  remote_debug_enabled                   = var.remote_debug_enabled
  upgrade_preference                     = var.upgrade_preference

  # Advanced configuration
  dedicated_host_count             = var.dedicated_host_count
  cluster_settings                 = var.cluster_settings
  front_end_tls_cipher_suite_order = var.front_end_tls_cipher_suite_order
  inbound_ip_address_override      = var.inbound_ip_address_override
  custom_dns_suffix_configuration  = var.custom_dns_suffix_configuration

  # Identity & RBAC
  managed_identities = var.managed_identities
  role_assignments   = var.role_assignments
  lock               = var.lock

  # Diagnostics
  diagnostic_settings = var.diagnostic_settings

  # Module behavior
  enable_telemetry = var.enable_telemetry
  tags             = local.module_tags
  retry            = var.retry
  timeouts         = var.timeouts
}
