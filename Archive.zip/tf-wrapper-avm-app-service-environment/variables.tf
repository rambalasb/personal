# =====================================================================
# Required inputs
# =====================================================================

variable "name" {
  type        = string
  description = "Name of the App Service Environment (ASE). 1-60 chars, alphanumerics and hyphens only."

  validation {
    condition     = can(regex("^[a-zA-Z0-9-]{1,60}$", var.name))
    error_message = "name must be 1-60 characters, alphanumerics and hyphens only."
  }
}

variable "subscription_id" {
  type        = string
  description = "Subscription ID containing the Resource Group. Used to derive the AVM parent_id."

  validation {
    condition     = can(regex("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$", var.subscription_id))
    error_message = "subscription_id must be a valid GUID."
  }
}

variable "resource_group_name" {
  type        = string
  description = "Name of the Resource Group where the ASE will be deployed."

  validation {
    condition     = length(var.resource_group_name) > 0 && length(var.resource_group_name) <= 90
    error_message = "resource_group_name must be 1-90 characters."
  }
}

variable "location" {
  type        = string
  description = "Azure region where the ASE will be deployed. Note: zone-redundant ASEs are only supported in some regions."

  validation {
    condition     = length(var.location) > 0
    error_message = "location must not be empty."
  }
}

variable "subnet_id" {
  type        = string
  description = "Resource ID of the subnet hosting the ASE. The subnet MUST be delegated to 'Microsoft.Web/hostingEnvironments' before creation."

  validation {
    condition     = can(regex("^/subscriptions/[^/]+/resourceGroups/[^/]+/providers/Microsoft\\.Network/virtualNetworks/[^/]+/subnets/[^/]+$", var.subnet_id))
    error_message = "subnet_id must be a valid Microsoft.Network/virtualNetworks/subnets resource ID."
  }
}

# =====================================================================
# Core security/network toggles (secure defaults)
# =====================================================================

variable "internal_load_balancing_mode" {
  type        = string
  description = "Which endpoints are served from the internal load balancer (ILB). 'None' (external ASE), 'Web', 'Publishing', or 'Web, Publishing' (full internal ASE)."
  default     = "Web, Publishing"

  validation {
    condition     = contains(["None", "Web", "Publishing", "Web, Publishing"], var.internal_load_balancing_mode)
    error_message = "internal_load_balancing_mode must be 'None', 'Web', 'Publishing', or 'Web, Publishing'."
  }
}

variable "zone_redundancy_enabled" {
  type        = bool
  description = "Whether the ASE is zone-redundant. Requires a supported region."
  default     = true
}

variable "internal_encryption_enabled" {
  type        = bool
  description = "Whether internal encryption between ASE workers is enabled. Strongly recommended."
  default     = true
}

variable "ftp_enabled" {
  type        = bool
  description = "Whether FTP is enabled on the ASE. FTP is unencrypted; keep disabled."
  default     = false
}

variable "fips_mode_enabled" {
  type        = bool
  description = "Whether FIPS-compliant ciphers/protocols are enforced (Linux). Required for some federal/regulated workloads."
  default     = false
}

variable "tls_1_enabled" {
  type        = bool
  description = "Whether TLS 1.0 is enabled. Keep false — TLS 1.0/1.1 are deprecated."
  default     = false
}

variable "allow_new_private_endpoint_connections" {
  type        = bool
  description = "Whether new private endpoint connections to the ASE are accepted."
  default     = true
}

variable "remote_debug_enabled" {
  type        = bool
  description = "Whether remote debugging is enabled on the ASE. Disable in production."
  default     = null
}

variable "upgrade_preference" {
  type        = string
  description = "ASE upgrade preference. 'None', 'Early', 'Late', or 'Manual'."
  default     = "None"

  validation {
    condition     = contains(["None", "Early", "Late", "Manual"], var.upgrade_preference)
    error_message = "upgrade_preference must be 'None', 'Early', 'Late', or 'Manual'."
  }
}

# =====================================================================
# Advanced configuration
# =====================================================================

variable "dedicated_host_count" {
  type        = number
  description = "Dedicated host count. Possible value is null (no dedicated hosts) or 2."
  default     = null

  validation {
    condition     = var.dedicated_host_count == null || var.dedicated_host_count == 2
    error_message = "dedicated_host_count must be null or 2."
  }
}

variable "cluster_settings" {
  type = list(object({
    name  = string
    value = string
  }))
  description = "Low-level ASE cluster settings (name/value pairs). See https://learn.microsoft.com/en-us/azure/app-service/environment/app-service-app-service-environment-custom-settings"
  default     = []
}

variable "front_end_tls_cipher_suite_order" {
  type        = string
  description = "TLS cipher suite order for ASE front ends. See AVM module docs for valid inputs."
  default     = null
}

variable "inbound_ip_address_override" {
  type        = string
  description = "Customer-provided inbound IP address. Can only be set at ASE creation time."
  default     = null
}

variable "custom_dns_suffix_configuration" {
  type = object({
    certificate_url              = string
    dns_suffix                   = string
    key_vault_reference_identity = optional(string, null)
  })
  description = "Custom domain suffix for sites deployed in this ASE. certificate_url is a Key Vault secret URL; key_vault_reference_identity is the user-assigned identity used to read it (defaults to ASE system identity if null)."
  default     = null
}

# =====================================================================
# Identity & RBAC
# =====================================================================

variable "managed_identities" {
  type = object({
    system_assigned            = optional(bool, false)
    user_assigned_resource_ids = optional(set(string), [])
  })
  description = "Managed identity configuration. Required when using custom_dns_suffix_configuration with Key Vault."
  default     = {}
}

variable "role_assignments" {
  type = map(object({
    role_definition_id_or_name             = string
    principal_id                           = string
    description                            = optional(string, null)
    skip_service_principal_aad_check       = optional(bool, false)
    condition                              = optional(string, null)
    condition_version                      = optional(string, null)
    delegated_managed_identity_resource_id = optional(string, null)
    principal_type                         = optional(string, null)
  }))
  description = "RBAC role assignments scoped to the ASE."
  default     = {}
}

variable "lock" {
  type = object({
    kind = string
    name = optional(string, null)
  })
  description = "Optional resource lock. STRONGLY recommended given ASE's ~$1000/mo base cost and 6h create/destroy times."
  default     = null

  validation {
    condition     = var.lock == null || contains(["CanNotDelete", "ReadOnly"], try(var.lock.kind, ""))
    error_message = "lock.kind must be 'CanNotDelete' or 'ReadOnly' when set."
  }
}

# =====================================================================
# Diagnostics
# =====================================================================

variable "diagnostic_settings" {
  type = map(object({
    name = optional(string, null)
    logs = optional(set(object({
      category       = optional(string, null)
      category_group = optional(string, null)
      enabled        = optional(bool, true)
      retention_policy = optional(object({
        days    = optional(number, 0)
        enabled = optional(bool, false)
      }), {})
    })), [])
    metrics = optional(set(object({
      category = optional(string, null)
      enabled  = optional(bool, true)
      retention_policy = optional(object({
        days    = optional(number, 0)
        enabled = optional(bool, false)
      }), {})
    })), [])
    log_analytics_destination_type           = optional(string, "Dedicated")
    workspace_resource_id                    = optional(string, null)
    storage_account_resource_id              = optional(string, null)
    event_hub_authorization_rule_resource_id = optional(string, null)
    event_hub_name                           = optional(string, null)
    marketplace_partner_resource_id          = optional(string, null)
  }))
  description = "Diagnostic settings for the ASE."
  default     = {}
}

# =====================================================================
# Module behavior
# =====================================================================

variable "enable_telemetry" {
  type        = bool
  description = "Whether to enable AVM module telemetry. Set false to opt out."
  default     = true
}

variable "tags" {
  type        = map(string)
  description = "A map of tags. Recommend cost-allocation tags given the ASE's monthly cost."
  default     = null
}

variable "retry" {
  type = object({
    error_message_regex  = optional(list(string), ["ScopeLocked"])
    interval_seconds     = optional(number, null)
    max_interval_seconds = optional(number, null)
  })
  description = "Retry configuration for azapi operations."
  default     = {}
}

variable "timeouts" {
  type = object({
    create = optional(string, "6h")
    delete = optional(string, "6h")
    read   = optional(string, "5m")
    update = optional(string, "6h")
  })
  description = "Operation timeouts. Default 6h for create/update/delete — ASE deployments often take 4-6 hours."
  default     = {}
}

# =====================================================================
# Cross-input validation
# =====================================================================

variable "_validate_custom_dns_suffix_needs_identity" {
  type        = bool
  description = "Internal sentinel — do not set."
  default     = true

  validation {
    condition = (
      var.custom_dns_suffix_configuration == null ||
      var.managed_identities.system_assigned == true ||
      length(coalesce(var.managed_identities.user_assigned_resource_ids, [])) > 0
    )
    error_message = "custom_dns_suffix_configuration requires the ASE to have a managed identity (system or user-assigned) so it can read the certificate from Key Vault. Enable managed_identities.system_assigned = true or supply user_assigned_resource_ids."
  }
}
