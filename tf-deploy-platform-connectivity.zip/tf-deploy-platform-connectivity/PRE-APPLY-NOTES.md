# tf-deploy-platform-connectivity — pre-apply notes

Adoption of the Sub-Connectivity vWAN estate (subscription `f3835bc1-9829-4ac8-9d7a-0999e0b29b90`).
Built tier-by-tier from the exported ARM/JSON. `terraform fmt` clean; no duplicate
variables / locals / imports / module / resource names. **726 import blocks total**,
reconciled against the 2026-10-05 inventory.

The firewall tier and the IP groups it references moved to
`tf-deploy-platform-firewall-management` (111 imports at the time), leaving 453
here; the 2026-09-28 and 2026-10-05 reconciliations took it to 726. See
`HANDOVER.md` §5 for the boundary and what still crosses it.

## Built tiers

| Tier | File | Contents | Imports |
|---|---|---|---|
| Resource groups | `resource_group.tf` | 12 RGs across 2 regions | 12 |
| Standard alerts | `monitoring.tf`, `locals.tf` | Service-Outage (activity log), Resource-Creation and 2 storage-deletion (log search) | 4 |
| Private DNS | `private_dns_zones.tf`, `connectivity.tfvars` | 43 zones + 315 vnet links | 358 |
| Virtual networks | `virtual_network.tf` | 8 VNets, 14 subnets, 9 peerings | 31 |
| vWAN hub | `hub_vwan.tf` | vWAN, 2 hubs, 2 `noneRouteTable`s + 2 `private_traffic` routes, 17 route maps, 2 routing intents, 50 hub connections, 1 BGP connection, 2 ER gateways + 4 connections, 2 VPN gateways + 2 connections, 2 VPN sites | 89 |
| Network primitives | `net_primitives.tf` | DDoS, 3 NAT, 3 PIP prefixes, 2 PIPs, 11 NSGs (+33 rules), 2 route tables (+1 route), 8 private endpoints, 2 ER circuits (+2 peerings), 2 network watchers, 6 flow logs, 2 traffic collectors (+2 policies) | 80 |
| DNS resolver | `dns_resolver.tf` | resolver, inbound + outbound endpoints, forwarding ruleset + 62 rules | 66 |
| Spokes/compute | `spokes_compute.tf` | 6 VMs (4 Windows, 2 Linux) + 6 NICs, 4 Developer bastions, 3 SSH keys, 1 LB (+pool, 2 probes, 2 rules), 7 maintenance configs, recovery vault + 3 backup policies | 36 |
| Connectivity alerts | `conn_alerts.tf` | 19 metric, 16 log-search and 6 activity-log alerts, 2 action groups, 7 alert processing rules (declared here, created through `module.monitoring`) | 50 |

## MUST fill before apply

1. **Secrets** — `azurerm_vpn_gateway_connection.shared_key` (omitted) and `var.spokes_vm_admin_password` (placeholder `REPLACE_ME_PLACEHOLDER`): supply via `TF_VAR_*` / Key Vault, never commit.

Resolved from the inventory exports and no longer open: the spoke VNet IDs on
all 50 hub connections and both external peerings (2026-10-05 export), and the
flow-log SIEM workspace's subscription (`7d54d6f7-…`). See `REMEDIATION.md`.

## Confirm on first speculative plan

- **AVM wrapper internal import addresses** — most `module.<x>[k].module.<inner>.<resource>` targets are inferred (headers say so); the route-table, SSH-key and bastion ones were read from the AVM source. The first `plan` import error prints the exact address to `sed`-fix en masse.
- **Module versions are settled** — all reconciled against the registry on 2026-09-09. `virtual-machine-linux` was pinned `0.1.0`, which has never been published (latest `0.0.1`), and `monitoring.tf` named the non-`ptn-` amba module, whose latest is `0.0.1`. Neither could resolve; both fixed. See `MODULE_GAPS.md`.
- **Wrapper versions not yet confirmed against the registry** — `tf-wrapper-avm-route-table` (pinned 0.3.0; goanywheremft pins 0.0.1) and `tf-wrapper-avm-virtual-network` (0.1.0, `# TODO` in `virtual_network.tf`).

## Intentionally NOT managed (Azure / backup / test artifacts)

- `Microsoft.Compute/restorePointCollections`, `Microsoft.Compute/snapshots`, `microsoft.devtestlab/schedules`, VM OS disks
- NSG `defaultSecurityRules` (read-only)
- `sttestingitout1` / `sttestingitout2` storage (+ event-grid topics/subscriptions) — test artifacts in the alerts RG

## Firewall items that moved with the tier

Recorded here only so this list stays a complete account of the original
adoption. All four are now in `tf-deploy-platform-firewall-management`:

- 2 empty firewall rule collections (`rc-allow-sap-aem-inbound`, `rc-allow-net-fit-to-esb-nonprod`) — the provider can't represent 0-rule collections
- Transit firewall's classic inline `networkRuleCollections` — not expressible via the AVM module
- `enable_firewall` was never set in the tfvars, so the 22 firewall imports targeted instances that did not exist. Fixed in the new repo; see `REMEDIATION.md`
- The firewall-policy insights workspace id was built under the wrong subscription. Fixed in the new repo; see `REMEDIATION.md`

## Same guardrails as the other three LZs
Subscription/tenant from `ARM_SUBSCRIPTION_ID`/`ARM_TENANT_ID`; hardened gate (no create/replace/destroy — imports + in-place updates only); in-place tag adds accepted. Workflow: `import-verify.yml` / `import-apply.yml`, tfvars `connectivity.tfvars`, HCP workspace `az-platform-connectivity`.
