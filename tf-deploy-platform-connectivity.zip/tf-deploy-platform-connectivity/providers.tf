terraform {
  required_version = ">= 1.9, < 2.0"

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 3.116, < 5.0"
    }
    # Required by the amba-alz wrapper (AMBA is AzAPI-based).
    azapi = {
      source  = "Azure/azapi"
      version = "~> 2.4"
    }
    modtm = {
      source  = "Azure/modtm"
      version = "~> 0.3"
    }
    random = {
      source  = "hashicorp/random"
      version = "~> 3.6"
    }
  }

  cloud {
    organization = "BC_Hydro"

    workspaces {
      name = "az-platform-connectivity"
    }
  }
}

provider "azurerm" {
  features {}
}

provider "azapi" {}
