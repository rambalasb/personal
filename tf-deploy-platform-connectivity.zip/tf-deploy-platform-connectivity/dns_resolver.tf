# dns_resolver.tf
# Private DNS Resolver in rg-dns-connectivity-canadacentral-001 (canadacentral):
# 1 resolver (pdr) + 1 inbound + 1 outbound endpoint, plus the frs forwarding
# ruleset and its 62 forwarding rules (modeled under the outbound endpoint per
# the wrapper's schema). 60 of the 62 rules are Disabled in Azure and are
# carried as enabled = false; only bchydro-rule-0 and one other are live.
# Sourced from per-resource JSON (real names).

locals {
  dns_resolver_data = {
    "pdr-connectivity-canadacentral-001" = {
      location                    = "canadacentral"
      virtual_network_resource_id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dns-connectivity-canadacentral-001"

      inbound_endpoints = {
        "pdr-inbound-connectivity-canadacentral-001" = {
          name                         = "pdr-inbound-connectivity-canadacentral-001"
          subnet_name                  = "snet-dns-inbound-canadacentral-001"
          private_ip_allocation_method = "Static"
          private_ip_address           = "10.195.4.7"
        }
      }

      outbound_endpoints = {
        "pdr-outbound-connectivity-canadacentral-001" = {
          name        = "pdr-outbound-connectivity-canadacentral-001"
          subnet_name = "snet-dns-outbound-canadacentral-001"
          forwarding_ruleset = {
            "frs-dns-connectivity-canadacentral-001" = {
              name = "frs-dns-connectivity-canadacentral-001"
              # No dnsForwardingRulesets/virtualNetworkLinks exist in source.
              link_with_outbound_endpoint_virtual_network = false
              rules = {
                "bchydro-rule-0" = { name = "bchydro-rule-0", domain_name = "bchydro.bc.ca.", enabled = true, destination_ip_addresses = { "10.242.74.147" = "53", "10.242.74.148" = "53", "10.242.74.149" = "53", "172.25.6.17" = "53", "172.25.6.101" = "53" } }
                "bchydro-rule-1" = { name = "bchydro-rule-1", domain_name = "bchydro.com.", enabled = true, destination_ip_addresses = { "10.242.74.147" = "53", "10.242.74.148" = "53", "10.242.74.149" = "53", "172.25.6.17" = "53", "172.25.6.101" = "53" } }
                "mvp-rule-0"     = { name = "mvp-rule-0", domain_name = "007d8da8-62af-4915-9b8a-a634a314c67b.agentsvc.azure-automation.net.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-1"     = { name = "mvp-rule-1", domain_name = "cog-openai-nonprod-canadcentral001.aiservices.azure.com.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-10"    = { name = "mvp-rule-10", domain_name = "app-openai-nonprodcanadacentral-001-bre8eugtbgb6e6hz.canadacentral-01.azurewebsites.net.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-11"    = { name = "mvp-rule-11", domain_name = "app-openai-prodcanadacentral-001-gxh4d3ashcdveree.canadacentral-01.azurewebsites.net.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-12"    = { name = "mvp-rule-12", domain_name = "func-asm-poc-canadacentral-001.azurewebsites.net.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-13"    = { name = "mvp-rule-13", domain_name = "func-asm-poc-canadacentral-001.scm.azurewebsites.net.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-14"    = { name = "mvp-rule-14", domain_name = "func-openai-nonprod-cc-001.azurewebsites.net.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-15"    = { name = "mvp-rule-15", domain_name = "func-openai-nonprod-cc-001.scm.azurewebsites.net.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-16"    = { name = "mvp-rule-16", domain_name = "func-openai-prod-cc-001-bweabeb9eyauf3bf.canadacentral-01.azurewebsites.net.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-17"    = { name = "mvp-rule-17", domain_name = "func-openai-prod-cc-001-bweabeb9eyauf3bf.scm.canadacentral-01.azurewebsites.net.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-18"    = { name = "mvp-rule-18", domain_name = "gsa-f7cd7c3f-909b000003.blob.core.windows.net.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-19"    = { name = "mvp-rule-19", domain_name = "gsa-f7cd7c3f-909b000004.blob.core.windows.net.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-2"     = { name = "mvp-rule-2", domain_name = "acraampocnonprodcanadacentral001.azurecr.io.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-20"    = { name = "mvp-rule-20", domain_name = "scadvisorcontentpl.blob.core.windows.net.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-21"    = { name = "mvp-rule-21", domain_name = "stasmpocconfig001.blob.core.windows.net.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-22"    = { name = "mvp-rule-22", domain_name = "stasmpocfunc001.blob.core.windows.net.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-23"    = { name = "mvp-rule-23", domain_name = "stasmpocstore001.blob.core.windows.net.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-24"    = { name = "mvp-rule-24", domain_name = "stopenainonprodcc001.blob.core.windows.net.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-25"    = { name = "mvp-rule-25", domain_name = "vm000000.blob.core.windows.net.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-26"    = { name = "mvp-rule-26", domain_name = "vm000001.blob.core.windows.net.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-27"    = { name = "mvp-rule-27", domain_name = "vpngw000000.blob.core.windows.net.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-28"    = { name = "mvp-rule-28", domain_name = "vpngw000001.blob.core.windows.net.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-29"    = { name = "mvp-rule-29", domain_name = "doc-openai-nonprod-canadacentral-001.cognitiveservices.azure.com.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-3"     = { name = "mvp-rule-3", domain_name = "acraampocnonprodcanadacentral001.canadacentral.data.azurecr.io.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-30"    = { name = "mvp-rule-30", domain_name = "doc-openai-prod-canadacentral-001.cognitiveservices.azure.com.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-31"    = { name = "mvp-rule-31", domain_name = "cosmos-openai-nonprod-canadacentral-001.documents.azure.com.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-32"    = { name = "mvp-rule-32", domain_name = "cosmos-openai-nonprod-canadacentral-001-canadacentral.documents.azure.com.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-33"    = { name = "mvp-rule-33", domain_name = "cosmos-openai-prod-canadacentral-001.documents.azure.com.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-34"    = { name = "mvp-rule-34", domain_name = "cosmos-openai-prod-canadacentral-001-canadacentral.documents.azure.com.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-35"    = { name = "mvp-rule-35", domain_name = "canadacentral.dp.kubernetesconfiguration.azure.com.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-36"    = { name = "mvp-rule-36", domain_name = "stasmpocfunc001.file.core.windows.net.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-37"    = { name = "mvp-rule-37", domain_name = "agentserviceapi.guestconfiguration.azure.com.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-38"    = { name = "mvp-rule-38", domain_name = "canadacentral-gas.guestconfiguration.azure.com.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-39"    = { name = "mvp-rule-39", domain_name = "canada-ats.his.arc.azure.com.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-4"     = { name = "mvp-rule-4", domain_name = "acropenainonprodcanadcentral001.azurecr.io.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-40"    = { name = "mvp-rule-40", domain_name = "cc.his.arc.azure.com.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-41"    = { name = "mvp-rule-41", domain_name = "gbl.his.arc.azure.com.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-42"    = { name = "mvp-rule-42", domain_name = "api.monitor.azure.com.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-43"    = { name = "mvp-rule-43", domain_name = "diagservices-query.monitor.azure.com.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-44"    = { name = "mvp-rule-44", domain_name = "global.handler.control.monitor.azure.com.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-45"    = { name = "mvp-rule-45", domain_name = "global.in.ai.monitor.azure.com.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-46"    = { name = "mvp-rule-46", domain_name = "live.monitor.azure.com.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-47"    = { name = "mvp-rule-47", domain_name = "profiler.monitor.azure.com.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-48"    = { name = "mvp-rule-48", domain_name = "snapshot.monitor.azure.com.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-49"    = { name = "mvp-rule-49", domain_name = "007d8da8-62af-4915-9b8a-a634a314c67b.ods.opinsights.azure.com.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-5"     = { name = "mvp-rule-5", domain_name = "acropenainonprodcanadcentral001.canadacentral.data.azurecr.io.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-50"    = { name = "mvp-rule-50", domain_name = "007d8da8-62af-4915-9b8a-a634a314c67b.oms.opinsights.azure.com.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-51"    = { name = "mvp-rule-51", domain_name = "cog-openai-nonprod-canadaeast-001.openai.azure.com.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-52"    = { name = "mvp-rule-52", domain_name = "cog-openai-prod-canadaeast.openai.azure.com.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-53"    = { name = "mvp-rule-53", domain_name = "psql-openai-nonprod-canadacentral-001.postgres.database.azure.com.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-54"    = { name = "mvp-rule-54", domain_name = "psql-openai-prod-canadacentral-001.postgres.database.azure.com.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-55"    = { name = "mvp-rule-55", domain_name = "stasmpocfunc001.queue.core.windows.net.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-56"    = { name = "mvp-rule-56", domain_name = "stopenainonprodcc001.queue.core.windows.net.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-57"    = { name = "mvp-rule-57", domain_name = "eventhubns-prod-canadacentral-001.servicebus.windows.net.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-58"    = { name = "mvp-rule-58", domain_name = "stasmpocfunc001.table.core.windows.net.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-59"    = { name = "mvp-rule-59", domain_name = "kv-openai-nonprod-cc-001.vaultcore.azure.net.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-6"     = { name = "mvp-rule-6", domain_name = "acropenaiprodcanadacentral001.azurecr.io.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-7"     = { name = "mvp-rule-7", domain_name = "acropenaiprodcanadacentral001.canadacentral.data.azurecr.io.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-8"     = { name = "mvp-rule-8", domain_name = "app-asm-poc-canadcentral-001-c2ewf5bzcab8hth2.canadacentral-01.azurewebsites.net.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
                "mvp-rule-9"     = { name = "mvp-rule-9", domain_name = "app-asm-poc-canadcentral-001-c2ewf5bzcab8hth2.scm.canadacentral-01.azurewebsites.net.", enabled = false, destination_ip_addresses = { "10.193.0.36" = "53" } }
              }
            }
          }
        }
      }
    }
  }
}

module "dns_resolver" {
  for_each = local.dns_resolver_data

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-dns-resolver/azurerm"
  version = "0.1.0"

  name                        = each.key
  resource_group_name         = module.resource_group["dns"].name
  location                    = each.value.location
  virtual_network_resource_id = each.value.virtual_network_resource_id
  inbound_endpoints           = each.value.inbound_endpoints
  outbound_endpoints          = each.value.outbound_endpoints

  enable_telemetry = false
  tags             = local.common_tags
}
