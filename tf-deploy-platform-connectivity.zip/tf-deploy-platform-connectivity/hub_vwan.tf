# hub_vwan.tf
# Virtual WAN hub tier for rg-hub-connectivity-canadacentral-001 and -canadaeast-001.
# No single-resource AVM wrapper exists for vWAN/vhub/gateways, and the ALZ
# pattern module (avm-ptn-alz-connectivity-virtual-wan) also builds firewall / DNS /
# bastion which are separate tiers here, so native azurerm_ resources are used.
#
# The firewall ids below are constructed, not module references: the firewalls
# are managed by tf-deploy-platform-firewall-management. A state reference
# would couple the two workspaces; a constructed id does not.
# defaultRouteTable belongs to routing intent: Azure writes its _policy__* routes
# from the intent's policies, so declaring the table would fight the intent. Only
# the private_traffic route (routing intent's additional private prefixes) is
# managed here, as a single route.

resource "azurerm_virtual_wan" "this" {
  name                           = "vwan-connectivity-canadacentral-001"
  resource_group_name            = module.resource_group["hub_cc"].name
  location                       = "canadacentral"
  type                           = "Standard"
  allow_branch_to_branch_traffic = true
  disable_vpn_encryption         = false
  tags                           = local.common_tags
}


locals {
  virtual_hubs = {
    cc = {
      name           = "vhub-connectivity-canadacentral-001"
      rg_key         = "hub_cc"
      location       = "canadacentral"
      address_prefix = "10.195.0.0/22"
    }
    ce = {
      name           = "vhub-connectivity-canadaeast-001"
      rg_key         = "hub_ce"
      location       = "canadaeast"
      address_prefix = "10.196.0.0/22"
    }
  }
}

resource "azurerm_virtual_hub" "this" {
  for_each = local.virtual_hubs

  name                                   = each.value.name
  resource_group_name                    = module.resource_group[each.value.rg_key].name
  location                               = each.value.location
  virtual_wan_id                         = azurerm_virtual_wan.this.id
  address_prefix                         = each.value.address_prefix
  sku                                    = "Standard"
  hub_routing_preference                 = "ASPath"
  virtual_router_auto_scale_min_capacity = 2
  tags                                   = local.common_tags
}


# Route next hops. The two firewalls are owned by
# tf-deploy-platform-firewall-management; these ids are constructed from the RG
# ids this repo does own, so nothing here reads that workspace's state. Renaming
# a firewall there silently breaks these routes -- the names are the contract
# between the two repos.
locals {
  hub_firewall_ids = {
    cc = "${module.resource_group["hub_cc"].resource_id}/providers/Microsoft.Network/azureFirewalls/azfw-connectivity-canadacentral-001"
    ce = "${module.resource_group["hub_ce"].resource_id}/providers/Microsoft.Network/azureFirewalls/azfw-connectivity-canadaeast-001"
  }
}

resource "azurerm_virtual_hub_route_table" "this" {
  for_each = local.hub_route_tables

  name           = each.value.name
  virtual_hub_id = azurerm_virtual_hub.this[each.value.hub].id
  labels         = each.value.labels

  dynamic "route" {
    for_each = each.value.routes
    content {
      name              = route.value.name
      destinations_type = route.value.destinations_type
      destinations      = route.value.destinations
      next_hop_type     = route.value.next_hop_type
      next_hop          = local.hub_firewall_ids[each.value.hub]
    }
  }
}

locals {
  hub_route_tables = {
    "cc-none" = {
      name   = "noneRouteTable"
      hub    = "cc"
      labels = ["none"]
      routes = []
    }
    "ce-none" = {
      name   = "noneRouteTable"
      hub    = "ce"
      labels = ["none"]
      routes = []
    }
  }
}


resource "azurerm_route_map" "this" {
  for_each = local.route_maps

  name           = each.value.name
  virtual_hub_id = azurerm_virtual_hub.this[each.value.hub].id

  dynamic "rule" {
    for_each = each.value.rules
    content {
      name                 = rule.value.name
      next_step_if_matched = rule.value.next_step_if_matched

      dynamic "action" {
        for_each = rule.value.actions
        content {
          type = action.value.type
          dynamic "parameter" {
            for_each = action.value.parameters
            content {
              as_path      = parameter.value.as_path
              community    = parameter.value.community
              route_prefix = parameter.value.route_prefix
            }
          }
        }
      }

      dynamic "match_criterion" {
        for_each = rule.value.match_criteria
        content {
          match_condition = match_criterion.value.match_condition
          as_path         = match_criterion.value.as_path
          community       = match_criterion.value.community
          route_prefix    = match_criterion.value.route_prefix
        }
      }
    }
  }
}

locals {
  route_maps = {
    "cc-Advertise-ER-Peerings" = {
      name = "Advertise-ER-Peerings"
      hub  = "cc"
      rules = [
        {
          name                 = "10-54-17-100"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = ["10.54.17.100/30"]
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.54.17.100/30"]
            },
          ]
        },
        {
          name                 = "10-54-18-212"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = ["10.54.18.212/30"]
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.54.18.212/30"]
            },
          ]
        },
        {
          name                 = "10-243-225-104"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = ["10.243.225.104/30"]
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.243.225.104/30"]
            },
          ]
        },
        {
          name                 = "10-243-21-224"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = ["10.243.21.224/30"]
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.243.21.224/30"]
            },
          ]
        },
      ]
    }
    "cc-cloud-network-summarization" = {
      name = "cloud-network-summarization"
      hub  = "cc"
      rules = [
        {
          name                 = "summarization-rule"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = ["10.195.0.0/16"]
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.195.0.0/16"]
            },
          ]
        },
        {
          name                 = "summarization-rule-east"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = ["10.196.0.0/16"]
                },
              ]
            },
            {
              type = "Add"
              parameters = [
                {
                  as_path      = ["64500", "64500", "64500"]
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.196.0.0/16"]
            },
          ]
        },
      ]
    }
    "cc-Quebec-ER-RouteMap" = {
      name = "Quebec-ER-RouteMap"
      hub  = "cc"
      rules = [
        {
          name                 = "PrefixEqual-10.195.118.8-NoASPrepend"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = ["10.195.118.8/32"]
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Equals"
              as_path         = []
              community       = []
              route_prefix    = ["10.195.118.8/32"]
            },
          ]
        },
        {
          name                 = "PrefixContains-10.195.118.0-ASPrepend"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = ["10.195.118.0/23"]
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.195.118.0/23"]
            },
          ]
        },
        {
          name                 = "PrefixContains-10.196.0.0-NoASPrepend"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = ["10.196.0.0/16"]
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.196.0.0/16"]
            },
          ]
        },
        {
          name                 = "Drop-PrefixContains-10.195.0.0"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.195.0.0/16"]
            },
          ]
        },
        {
          name                 = "Drop-Network-10.0.0.0-8"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.0.0.0/8"]
            },
          ]
        },
        {
          name                 = "Drop-Network-10.242.0.0-16"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.242.0.0/16"]
            },
          ]
        },
        {
          name                 = "Drop-Network-10.242.32.5-32"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Equals"
              as_path         = []
              community       = []
              route_prefix    = ["10.242.32.5/32"]
            },
          ]
        },
        {
          name                 = "Drop-Network-10.243.0.0-16"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.243.0.0/16"]
            },
          ]
        },
        {
          name                 = "Drop-Network-142.52.0.0-16"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["142.52.0.0/16"]
            },
          ]
        },
        {
          name                 = "Drop-Network-172.16.0.0-12"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["172.16.0.0/12"]
            },
          ]
        },
        {
          name                 = "Drop-Network-192.168.0.0-16"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["192.168.0.0/16"]
            },
          ]
        },
      ]
    }
    "cc-rm-rfc-inbound" = {
      name = "rm-rfc-inbound"
      hub  = "cc"
      rules = [
        {
          name                 = "rfc10"
          next_step_if_matched = "Continue"
          actions = [
            {
              type = "Add"
              parameters = [
                {
                  as_path      = ["64300", "64300", "64300", "64300", "64300", "64300", "64300", "64300"]
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.0.0.0/8"]
            },
          ]
        },
      ]
    }
    "cc-Toronto-ER-RouteMap" = {
      name = "Toronto-ER-RouteMap"
      hub  = "cc"
      rules = [
        {
          name                 = "PrefixEqual-10.195.118.8-ASPrepend"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = ["10.195.118.8/32"]
                },
              ]
            },
            {
              type = "Add"
              parameters = [
                {
                  as_path      = ["852", "852", "852"]
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Equals"
              as_path         = []
              community       = []
              route_prefix    = ["10.195.118.8/32"]
            },
          ]
        },
        {
          name                 = "PrefixContains-10.195.118.0-Replace"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = ["10.195.118.0/23"]
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.195.118.0/23"]
            },
          ]
        },
        {
          name                 = "PrefixContains-10.196.0.0-ASPrepend"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = ["10.196.0.0/16"]
                },
              ]
            },
            {
              type = "Add"
              parameters = [
                {
                  as_path      = ["852", "852", "852"]
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.196.0.0/16"]
            },
          ]
        },
        {
          name                 = "Drop-PrefixContains-10.195.0.0"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.195.0.0/16"]
            },
          ]
        },
        {
          name                 = "Drop-Network-10.0.0.0-8"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.0.0.0/8"]
            },
          ]
        },
        {
          name                 = "Drop-Network-10.242.0.0-16"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.242.0.0/16"]
            },
          ]
        },
        {
          name                 = "Drop-Network-10.242.32.5-32"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Equals"
              as_path         = []
              community       = []
              route_prefix    = ["10.242.32.5/32"]
            },
          ]
        },
        {
          name                 = "Drop-Network-10.243.0.0-16"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.243.0.0/16"]
            },
          ]
        },
        {
          name                 = "Drop-Network-142.52.0.0-16"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["142.52.0.0/16"]
            },
          ]
        },
        {
          name                 = "Drop-Network-172.16.0.0-12"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["172.16.0.0/12"]
            },
          ]
        },
        {
          name                 = "Drop-Network-192.168.0.0-16"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["192.168.0.0/16"]
            },
          ]
        },
      ]
    }
    "cc-rm-quebec-outbound" = {
      name = "rm-quebec-outbound"
      hub  = "cc"
      rules = [
        {
          name                 = "SummarizeCanadaCentralVHub"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = ["10.195.0.0/22"]
                },
              ]
            },
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = ["852", "852"]
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.195.0.0/22"]
            },
          ]
        },
        {
          name                 = "SummarizeCanadaCentral"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = ["10.195.0.0/16"]
                },
              ]
            },
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = ["852", "852"]
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.195.0.0/16"]
            },
          ]
        },
        {
          name                 = "SummarizeCanadaEast"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = ["10.196.0.0/16"]
                },
              ]
            },
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = ["852", "852"]
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.196.0.0/16"]
            },
          ]
        },
        {
          name                 = "DropOnprem-10242"
          next_step_if_matched = "Continue"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.242.0.0/16"]
            },
          ]
        },
        {
          name                 = "DropOnprem-102423"
          next_step_if_matched = "Continue"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Equals"
              as_path         = []
              community       = []
              route_prefix    = ["10.242.32.5/32"]
            },
          ]
        },
        {
          name                 = "DropOnprem-10243"
          next_step_if_matched = "Continue"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.243.0.0/16"]
            },
          ]
        },
        {
          name                 = "DropOnprem-142"
          next_step_if_matched = "Continue"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["142.52.0.0/16"]
            },
          ]
        },
        {
          name                 = "DropRFC1918-10"
          next_step_if_matched = "Continue"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.0.0.0/8"]
            },
          ]
        },
        {
          name                 = "DropRFC1918-172"
          next_step_if_matched = "Continue"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["172.16.0.0/12"]
            },
          ]
        },
        {
          name                 = "DropRFC1918-192"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["192.168.0.0/16"]
            },
          ]
        },
        {
          name                 = "DropNS2Network"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.237.0.0/21"]
            },
          ]
        },
      ]
    }
    "cc-rm-toronto-outbound" = {
      name = "rm-toronto-outbound"
      hub  = "cc"
      rules = [
        {
          name                 = "SummarizeCanadaCentralVHub"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = ["10.195.0.0/22"]
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.195.0.0/22"]
            },
          ]
        },
        {
          name                 = "SummarizeCanadaCentral"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = ["10.195.0.0/16"]
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.195.0.0/16"]
            },
          ]
        },
        {
          name                 = "SummarizeCanadaEast"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = ["10.196.0.0/16"]
                },
              ]
            },
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = ["852", "852"]
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.196.0.0/16"]
            },
          ]
        },
        {
          name                 = "DropOnprem-10242"
          next_step_if_matched = "Continue"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.242.0.0/16"]
            },
          ]
        },
        {
          name                 = "DropOnprem-102423"
          next_step_if_matched = "Continue"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Equals"
              as_path         = []
              community       = []
              route_prefix    = ["10.242.32.5/32"]
            },
          ]
        },
        {
          name                 = "DropOnprem-10243"
          next_step_if_matched = "Continue"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.243.0.0/16"]
            },
          ]
        },
        {
          name                 = "DropOnprem-142"
          next_step_if_matched = "Continue"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["142.52.0.0/16"]
            },
          ]
        },
        {
          name                 = "DropRFC1918-10"
          next_step_if_matched = "Continue"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.0.0.0/8"]
            },
          ]
        },
        {
          name                 = "DropRFC1918-172"
          next_step_if_matched = "Continue"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["172.16.0.0/12"]
            },
          ]
        },
        {
          name                 = "DropRFC1918-192"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["192.168.0.0/16"]
            },
          ]
        },
        {
          name                 = "DropNS2Network"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.237.0.0/21"]
            },
          ]
        },
      ]
    }
    "cc-rm-vpn-inbound" = {
      name = "rm-vpn-inbound"
      hub  = "cc"
      rules = [
        {
          name                 = "PrependRFC1918-1"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = ["64500", "64500", "64500", "64500", "64500", "64500", "64500", "64500", "64500"]
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.0.0.0/8"]
            },
          ]
        },
        {
          name                 = "PrependRFC1918-2"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = ["64500", "64500", "64500", "64500", "64500", "64500", "64500", "64500", "64500"]
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["172.16.0.0/12"]
            },
          ]
        },
        {
          name                 = "PrependRFC1918-3"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = ["64500", "64500", "64500", "64500", "64500", "64500", "64500", "64500", "64500"]
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["192.168.0.0/16"]
            },
          ]
        },
        {
          name                 = "PrependRFC1918-4"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = ["64500", "64500", "64500", "64500", "64500", "64500", "64500", "64500", "64500"]
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["142.52.0.0/16"]
            },
          ]
        },
      ]
    }
    "cc-rm-vpn-outbound" = {
      name = "rm-vpn-outbound"
      hub  = "cc"
      rules = [
        {
          name                 = "SummarizeCanadaCentral"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = ["10.195.0.0/16"]
                },
              ]
            },
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = ["64500", "64500", "64500"]
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.195.0.0/16"]
            },
          ]
        },
        {
          name                 = "DropCanadaEast"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.196.0.0/16"]
            },
          ]
        },
        {
          name                 = "DropTestIP1"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Equals"
              as_path         = []
              community       = []
              route_prefix    = ["172.25.6.58/32"]
            },
          ]
        },
        {
          name                 = "DropTestIP2"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Equals"
              as_path         = []
              community       = []
              route_prefix    = ["10.242.69.101/32"]
            },
          ]
        },
        {
          name                 = "DropTestIP3"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Equals"
              as_path         = []
              community       = []
              route_prefix    = ["10.242.69.194/32"]
            },
          ]
        },
        {
          name                 = "DropTestIP4"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Equals"
              as_path         = []
              community       = []
              route_prefix    = ["10.242.32.5/32"]
            },
          ]
        },
        {
          name                 = "DropTestIP5"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Equals"
              as_path         = []
              community       = []
              route_prefix    = ["10.242.69.195/32"]
            },
          ]
        },
        {
          name                 = "DropTestIP6"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Equals"
              as_path         = []
              community       = []
              route_prefix    = ["10.242.69.32/32"]
            },
          ]
        },
        {
          name                 = "DropTestIP7"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Equals"
              as_path         = []
              community       = []
              route_prefix    = ["10.242.69.100/32"]
            },
          ]
        },
        {
          name                 = "DropNS2Network"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.237.0.0/21"]
            },
          ]
        },
        {
          name                 = "DropOnprem-10242"
          next_step_if_matched = "Continue"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.242.0.0/16"]
            },
          ]
        },
        {
          name                 = "DropOnprem-102423"
          next_step_if_matched = "Continue"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Equals"
              as_path         = []
              community       = []
              route_prefix    = ["10.242.32.5/32"]
            },
          ]
        },
        {
          name                 = "DropOnprem-10243"
          next_step_if_matched = "Continue"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.243.0.0/16"]
            },
          ]
        },
        {
          name                 = "DropOnprem-142"
          next_step_if_matched = "Continue"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["142.52.0.0/16"]
            },
          ]
        },
        {
          name                 = "DropRFC1918-10"
          next_step_if_matched = "Continue"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.0.0.0/8"]
            },
          ]
        },
        {
          name                 = "DropRFC1918-172"
          next_step_if_matched = "Continue"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["172.16.0.0/12"]
            },
          ]
        },
        {
          name                 = "DropRFC1918-192"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["192.168.0.0/16"]
            },
          ]
        },
        {
          name                 = "Drop1024321"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.243.21.224/30"]
            },
          ]
        },
        {
          name                 = "Drop10243225"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.243.225.104/30"]
            },
          ]
        },
        {
          name                 = "Drop105417"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.54.17.100/30"]
            },
          ]
        },
        {
          name                 = "Drop105418"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.54.18.212/30"]
            },
          ]
        },
        {
          name                 = "Drop10242228"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.242.253.228/30"]
            },
          ]
        },
        {
          name                 = "Drop10242196"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.242.253.196/30"]
            },
          ]
        },
        {
          name                 = "Drop1024324"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.243.230.24/29"]
            },
          ]
        },
        {
          name                 = "Drop10159140"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.159.36.140/30"]
            },
          ]
        },
        {
          name                 = "Drop1015916"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.159.36.16/30"]
            },
          ]
        },
        {
          name                 = "DropDefault"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["0.0.0.0/0"]
            },
          ]
        },
      ]
    }
    "ce-Advertise-ER-Peerings" = {
      name = "Advertise-ER-Peerings"
      hub  = "ce"
      rules = [
        {
          name                 = "10-243-21-224"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = ["10.243.21.224/30"]
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.243.21.224/30"]
            },
          ]
        },
        {
          name                 = "10-243-225-104"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = ["10.243.225.104/30"]
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.243.225.104/30"]
            },
          ]
        },
        {
          name                 = "10-54-17-100"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = ["10.54.17.100/30"]
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.54.17.100/30"]
            },
          ]
        },
        {
          name                 = "10-54-18-212"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = ["10.54.18.212/30"]
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.54.18.212/30"]
            },
          ]
        },
      ]
    }
    "ce-cloud-network-summarization" = {
      name = "cloud-network-summarization"
      hub  = "ce"
      rules = [
        {
          name                 = "summarization-rule-central"
          next_step_if_matched = "Continue"
          actions = [
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = ["10.195.0.0/16"]
                },
              ]
            },
            {
              type = "Add"
              parameters = [
                {
                  as_path      = ["64500", "64500", "64500"]
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.195.0.0/16"]
            },
          ]
        },
        {
          name                 = "summarization-rule-east"
          next_step_if_matched = "Continue"
          actions = [
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = ["10.196.0.0/16"]
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.196.0.0/16"]
            },
          ]
        },
      ]
    }
    "ce-Quebec-ER-RouteMap" = {
      name = "Quebec-ER-RouteMap"
      hub  = "ce"
      rules = [
        {
          name                 = "Replace-10.196.114.0-23"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = ["10.196.114.0/23"]
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.196.114.0/23"]
            },
          ]
        },
        {
          name                 = "PrefixContains-10.195.118.0-ASPrepend"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = ["10.195.118.0/23"]
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.195.118.0/23"]
            },
          ]
        },
        {
          name                 = "Drop-Network-10.0.0..0-8"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.0.0.0/8"]
            },
          ]
        },
        {
          name                 = "Drop-Network-10.242.0.0-16"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.242.0.0/16"]
            },
          ]
        },
        {
          name                 = "Drop-Network-10.242.32.5-32"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Equals"
              as_path         = []
              community       = []
              route_prefix    = ["10.242.32.5/32"]
            },
          ]
        },
        {
          name                 = "Drop-Network-10.243.0.0-16"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.243.0.0/16"]
            },
          ]
        },
        {
          name                 = "Drop-Network-142.52.0.0-16"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["142.52.0.0/16"]
            },
          ]
        },
        {
          name                 = "Drop-Network-172.16.0.0-12"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["172.16.0.0/12"]
            },
          ]
        },
        {
          name                 = "Drop-Network-192.168.0.0-16"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["192.168.0.0/16"]
            },
          ]
        },
        {
          name                 = "Drop-PrefixContains-10.195.0.0"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.195.0.0/16"]
            },
          ]
        },
        {
          name                 = "PrefixEqual-10.195.118.8-NoASPrepend"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = ["10.195.118.8/32"]
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Equals"
              as_path         = []
              community       = []
              route_prefix    = ["10.195.118.8/32"]
            },
          ]
        },
        {
          name                 = "PrefixContains-10.196.0.0-NoASPrepend"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.196.0.0/16"]
            },
          ]
        },
      ]
    }
    "ce-Toronto-ER-RouteMap" = {
      name = "Toronto-ER-RouteMap"
      hub  = "ce"
      rules = [
        {
          name                 = "PrefixEqual-10.195.118.8-ASPrepend"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = ["10.195.118.8/32"]
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Equals"
              as_path         = []
              community       = []
              route_prefix    = ["10.195.118.8/32"]
            },
          ]
        },
        {
          name                 = "PrefixContains-10.195.118.0-Replace"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = ["10.195.118.0/23"]
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.195.118.0/23"]
            },
          ]
        },
        {
          name                 = "PrefixContains-10.196.0.0-ASPrepend"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = ["10.196.0.0/16"]
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.196.0.0/16"]
            },
          ]
        },
        {
          name                 = "Drop-PrefixContains-10.195.0.0"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.195.0.0/16"]
            },
          ]
        },
        {
          name                 = "Drop-Network-10.0..0.0-8"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.0.0.0/8"]
            },
          ]
        },
        {
          name                 = "Drop-Network-10.242.0.0-16"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.242.0.0/16"]
            },
          ]
        },
        {
          name                 = "Drop-Network-10.242.32.5-32"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Equals"
              as_path         = []
              community       = []
              route_prefix    = ["10.242.32.5/32"]
            },
          ]
        },
        {
          name                 = "Drop-Network-10.243.0.0-16"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.243.0.0/16"]
            },
          ]
        },
        {
          name                 = "Drop-Network-142.52.0.0-16"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["142.52.0.0/16"]
            },
          ]
        },
        {
          name                 = "Drop-Network-172.16.0.0-12"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["172.16.0.0/12"]
            },
          ]
        },
        {
          name                 = "Drop-Network-192.168.0.0-16"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["192.168.0.0/16"]
            },
          ]
        },
      ]
    }
    "ce-rm-quebec-outbound" = {
      name = "rm-quebec-outbound"
      hub  = "ce"
      rules = [
        {
          name                 = "SummarizeCanadaEastVHub"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = ["10.196.0.0/22"]
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.196.0.0/22"]
            },
          ]
        },
        {
          name                 = "SummarizeCanadaCentral"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = ["10.195.0.0/16"]
                },
              ]
            },
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = ["852", "852"]
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.195.0.0/16"]
            },
          ]
        },
        {
          name                 = "SummarizeCanadaEast"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = ["10.196.0.0/16"]
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.196.0.0/16"]
            },
          ]
        },
        {
          name                 = "DropOnprem-10242"
          next_step_if_matched = "Continue"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.242.0.0/16"]
            },
          ]
        },
        {
          name                 = "DropOnprem-102423"
          next_step_if_matched = "Continue"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Equals"
              as_path         = []
              community       = []
              route_prefix    = ["10.242.32.5/32"]
            },
          ]
        },
        {
          name                 = "DropOnprem-10243"
          next_step_if_matched = "Continue"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.243.0.0/16"]
            },
          ]
        },
        {
          name                 = "DropOnprem-142"
          next_step_if_matched = "Continue"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["142.52.0.0/16"]
            },
          ]
        },
        {
          name                 = "DropRFC1918-10"
          next_step_if_matched = "Continue"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.0.0.0/8"]
            },
          ]
        },
        {
          name                 = "DropRFC1918-172"
          next_step_if_matched = "Continue"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["172.16.0.0/12"]
            },
          ]
        },
        {
          name                 = "DropRFC1918-192"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["192.168.0.0/16"]
            },
          ]
        },
        {
          name                 = "DropNS2Network"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.237.0.0/21"]
            },
          ]
        },
      ]
    }
    "ce-rm-toronto-outbound" = {
      name = "rm-toronto-outbound"
      hub  = "ce"
      rules = [
        {
          name                 = "SummarizeCanadaEastVHub"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = ["10.196.0.0/22"]
                },
              ]
            },
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = ["852", "852"]
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.196.0.0/22"]
            },
          ]
        },
        {
          name                 = "SummarizeCanadaCentral"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = ["10.195.0.0/16"]
                },
              ]
            },
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = ["852", "852"]
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.195.0.0/16"]
            },
          ]
        },
        {
          name                 = "SummarizeCanadaEast"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = ["10.196.0.0/16"]
                },
              ]
            },
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = ["852", "852"]
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.196.0.0/16"]
            },
          ]
        },
        {
          name                 = "DropOnprem-10242"
          next_step_if_matched = "Continue"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.242.0.0/16"]
            },
          ]
        },
        {
          name                 = "DropOnprem-102423"
          next_step_if_matched = "Continue"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Equals"
              as_path         = []
              community       = []
              route_prefix    = ["10.242.32.5/32"]
            },
          ]
        },
        {
          name                 = "DropOnprem-10243"
          next_step_if_matched = "Continue"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.243.0.0/16"]
            },
          ]
        },
        {
          name                 = "DropOnprem-142"
          next_step_if_matched = "Continue"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["142.52.0.0/16"]
            },
          ]
        },
        {
          name                 = "DropRFC1918-10"
          next_step_if_matched = "Continue"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.0.0.0/8"]
            },
          ]
        },
        {
          name                 = "DropRFC1918-172"
          next_step_if_matched = "Continue"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["172.16.0.0/12"]
            },
          ]
        },
        {
          name                 = "DropRFC1918-192"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["192.168.0.0/16"]
            },
          ]
        },
        {
          name                 = "DropNS2Network"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.237.0.0/21"]
            },
          ]
        },
      ]
    }
    "ce-rm-vpn-inbound" = {
      name = "rm-vpn-inbound"
      hub  = "ce"
      rules = [
        {
          name                 = "PrependRFC1918-1"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = ["64500", "64500", "64500", "64500", "64500", "64500", "64500", "64500", "64500"]
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.0.0.0/8"]
            },
          ]
        },
        {
          name                 = "PrependRFC1918-2"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = ["64500", "64500", "64500", "64500", "64500", "64500", "64500", "64500", "64500"]
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["172.16.0.0/12"]
            },
          ]
        },
        {
          name                 = "PrependRFC1918-3"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = ["64500", "64500", "64500", "64500", "64500", "64500", "64500", "64500", "64500"]
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["192.168.0.0/16"]
            },
          ]
        },
        {
          name                 = "PrependRFC1918-4"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = ["64500", "64500", "64500", "64500", "64500", "64500", "64500", "64500", "64500"]
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["142.52.0.0/16"]
            },
          ]
        },
      ]
    }
    "ce-rm-vpn-outbound" = {
      name = "rm-vpn-outbound"
      hub  = "ce"
      rules = [
        {
          name                 = "SummarizeCanadaEast"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = ["10.196.0.0/16"]
                },
              ]
            },
            {
              type = "Replace"
              parameters = [
                {
                  as_path      = ["64500", "64500", "64500"]
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.196.0.0/16"]
            },
          ]
        },
        {
          name                 = "DropCanadaCentral"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.195.0.0/16"]
            },
          ]
        },
        {
          name                 = "DropTestIP1"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Equals"
              as_path         = []
              community       = []
              route_prefix    = ["172.25.6.58/32"]
            },
          ]
        },
        {
          name                 = "DropTestIP2"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Equals"
              as_path         = []
              community       = []
              route_prefix    = ["10.242.69.101/32"]
            },
          ]
        },
        {
          name                 = "DropTestIP3"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Equals"
              as_path         = []
              community       = []
              route_prefix    = ["10.242.69.194/32"]
            },
          ]
        },
        {
          name                 = "DropTestIP4"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Equals"
              as_path         = []
              community       = []
              route_prefix    = ["10.242.32.5/32"]
            },
          ]
        },
        {
          name                 = "DropTestIP5"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Equals"
              as_path         = []
              community       = []
              route_prefix    = ["10.242.69.195/32"]
            },
          ]
        },
        {
          name                 = "DropTestIP6"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Equals"
              as_path         = []
              community       = []
              route_prefix    = ["10.242.69.32/32"]
            },
          ]
        },
        {
          name                 = "DropTestIP7"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Equals"
              as_path         = []
              community       = []
              route_prefix    = ["10.242.69.100/32"]
            },
          ]
        },
        {
          name                 = "DropNS2Network"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.237.0.0/21"]
            },
          ]
        },
        {
          name                 = "DropOnprem-10242"
          next_step_if_matched = "Continue"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.242.0.0/16"]
            },
          ]
        },
        {
          name                 = "DropOnprem-102423"
          next_step_if_matched = "Continue"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Equals"
              as_path         = []
              community       = []
              route_prefix    = ["10.242.32.5/32"]
            },
          ]
        },
        {
          name                 = "DropOnprem-10243"
          next_step_if_matched = "Continue"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.243.0.0/16"]
            },
          ]
        },
        {
          name                 = "DropOnprem-142"
          next_step_if_matched = "Continue"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["142.52.0.0/16"]
            },
          ]
        },
        {
          name                 = "DropRFC1918-10"
          next_step_if_matched = "Continue"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.0.0.0/8"]
            },
          ]
        },
        {
          name                 = "DropRFC1918-172"
          next_step_if_matched = "Continue"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["172.16.0.0/12"]
            },
          ]
        },
        {
          name                 = "DropRFC1918-192"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["192.168.0.0/16"]
            },
          ]
        },
        {
          name                 = "Drop1024321"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.243.21.224/30"]
            },
          ]
        },
        {
          name                 = "Drop10243225"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.243.225.104/30"]
            },
          ]
        },
        {
          name                 = "Drop105417"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.54.17.100/30"]
            },
          ]
        },
        {
          name                 = "Drop105418"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.54.18.212/30"]
            },
          ]
        },
        {
          name                 = "Drop10242228"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.242.253.228/30"]
            },
          ]
        },
        {
          name                 = "Drop10242196"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.242.253.196/30"]
            },
          ]
        },
        {
          name                 = "Drop1024324"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.243.230.24/29"]
            },
          ]
        },
        {
          name                 = "Drop10159140"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.159.36.140/30"]
            },
          ]
        },
        {
          name                 = "Drop1015916"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["10.159.36.16/30"]
            },
          ]
        },
        {
          name                 = "DropDefault"
          next_step_if_matched = "Terminate"
          actions = [
            {
              type = "Drop"
              parameters = [
                {
                  as_path      = []
                  community    = []
                  route_prefix = []
                },
              ]
            },
          ]
          match_criteria = [
            {
              match_condition = "Contains"
              as_path         = []
              community       = []
              route_prefix    = ["0.0.0.0/0"]
            },
          ]
        },
      ]
    }
  }
}


resource "azurerm_virtual_hub_routing_intent" "this" {
  for_each = local.routing_intents

  name           = each.value.name
  virtual_hub_id = azurerm_virtual_hub.this[each.value.hub].id

  dynamic "routing_policy" {
    for_each = each.value.routing_policies
    content {
      name         = routing_policy.value.name
      destinations = routing_policy.value.destinations
      next_hop     = local.hub_firewall_ids[each.value.hub]
    }
  }
}

locals {
  routing_intents = {
    cc = {
      name = "defaultRouteTable"
      hub  = "cc"
      routing_policies = [
        {
          name         = "_PublicTraffic"
          destinations = ["Internet"]
        },
        {
          name         = "_PrivateTraffic"
          destinations = ["PrivateTraffic"]
        },
      ]
    }
    ce = {
      name = "defaultRouteTable"
      hub  = "ce"
      routing_policies = [
        {
          name         = "_PublicTraffic"
          destinations = ["Internet"]
        },
        {
          name         = "_PrivateTraffic"
          destinations = ["PrivateTraffic"]
        },
      ]
    }
  }
}


resource "azurerm_virtual_hub_route_table_route" "private_traffic" {
  for_each = local.virtual_hubs

  route_table_id    = azurerm_virtual_hub.this[each.key].default_route_table_id
  name              = "private_traffic"
  destinations_type = "CIDR"
  destinations      = ["142.52.0.0/16"]
  next_hop_type     = "ResourceId"
  next_hop          = local.hub_firewall_ids[each.key]

  depends_on = [azurerm_virtual_hub_routing_intent.this]
}

resource "azurerm_virtual_hub_connection" "this" {
  for_each = local.hub_virtual_network_connections

  name                      = each.value.name
  virtual_hub_id            = azurerm_virtual_hub.this[each.value.hub].id
  remote_virtual_network_id = each.value.remote_virtual_network_id
  internet_security_enabled = each.value.internet_security_enabled

  routing {
    associated_route_table_id = azurerm_virtual_hub.this[each.value.hub].default_route_table_id
    propagated_route_table {
      labels          = ["none"]
      route_table_ids = [azurerm_virtual_hub_route_table.this["${each.value.hub}-none"].id]
    }
  }
}

locals {
  hub_virtual_network_connections = {
    "peering-hub-to-auritas-nonprod-canadacentral-001" = {
      name                      = "peering-hub-to-auritas-nonprod-canadacentral-001"
      hub                       = "cc"
      remote_virtual_network_id = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-auritas-nonprod-canadacentral-001"
      internet_security_enabled = true
    }
    "peering-hub-to-auritas-prod-canadacentral-001" = {
      name                      = "peering-hub-to-auritas-prod-canadacentral-001"
      hub                       = "cc"
      remote_virtual_network_id = "/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07/resourceGroups/rg-auritas-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-auritas-prod-canadacentral-001"
      internet_security_enabled = true
    }
    "peering-hub-to-cops-nonprod-canadacentral-001" = {
      name                      = "peering-hub-to-cops-nonprod-canadacentral-001"
      hub                       = "cc"
      remote_virtual_network_id = "/subscriptions/675a173c-0b66-4506-9aec-c0b2681e0fb9/resourceGroups/rg-cops-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-nonprod-canadacentral-001"
      internet_security_enabled = true
    }
    "peering-hub-to-cops-prod-canadacentral-001" = {
      name                      = "peering-hub-to-cops-prod-canadacentral-001"
      hub                       = "cc"
      remote_virtual_network_id = "/subscriptions/9a891d10-c1e9-4527-a22c-204426e3725b/resourceGroups/rg-cops-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cops-prod-canadacentral-001"
      internet_security_enabled = true
    }
    "peering-hub-to-cyberark-canadacentral-001" = {
      name                      = "peering-hub-to-cyberark-canadacentral-001"
      hub                       = "cc"
      remote_virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cyberark-canadacentral-001"
      internet_security_enabled = true
    }
    "peering-hub-to-dns-canadacentral-001" = {
      name                      = "peering-hub-to-dns-canadacentral-001"
      hub                       = "cc"
      remote_virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dns-connectivity-canadacentral-001"
      internet_security_enabled = true
    }
    "peering-hub-to-ertest-connectivity-canadacentral-001" = {
      name                      = "peering-hub-to-ertest-connectivity-canadacentral-001"
      hub                       = "cc"
      remote_virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-ertest-canadacentral-001"
      internet_security_enabled = true
    }
    "peering-hub-to-fabric-nonprod-canadacentral-001" = {
      name                      = "peering-hub-to-fabric-nonprod-canadacentral-001"
      hub                       = "cc"
      remote_virtual_network_id = "/subscriptions/cd096fc9-e946-4547-8b46-eb23b6024332/resourceGroups/rg-fabric-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-nonprod-canadacentral-001"
      internet_security_enabled = true
    }
    "peering-hub-to-fabric-prod-canadacentral-001" = {
      name                      = "peering-hub-to-fabric-prod-canadacentral-001"
      hub                       = "cc"
      remote_virtual_network_id = "/subscriptions/e299ec5b-9b38-4d00-9c9a-9257a48b6ecc/resourceGroups/rg-fabric-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fabric-prod-canadacentral-001"
      internet_security_enabled = true
    }
    "peering-hub-to-fitnonprod-canadacentral-001" = {
      name                      = "peering-hub-to-fitnonprod-canadacentral-001"
      hub                       = "cc"
      remote_virtual_network_id = "/subscriptions/fa089a5b-f881-41a6-a30f-58bfdfd52abd/resourceGroups/rg-fit-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-nonprod-canadacentral-001"
      internet_security_enabled = true
    }
    "peering-hub-to-fitprod-canadacentral-001" = {
      name                      = "peering-hub-to-fitprod-canadacentral-001"
      hub                       = "cc"
      remote_virtual_network_id = "/subscriptions/0aa40f3e-3340-444e-bfac-d01a42a54ad1/resourceGroups/rg-fit-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-fit-prod-canadacentral-001"
      internet_security_enabled = true
    }
    "peering-hub-to-mds-prod-canadacentral" = {
      name                      = "peering-hub-to-mds-prod-canadacentral"
      hub                       = "cc"
      remote_virtual_network_id = "/subscriptions/dea89b5c-c8a0-4f3e-810e-c36a51501f29/resourceGroups/rg-network-mds-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-mds-prod-canadacentral"
      internet_security_enabled = true
    }
    "peering-hub-to-mft-dev-canadacentral-001" = {
      name                      = "peering-hub-to-mft-dev-canadacentral-001"
      hub                       = "cc"
      remote_virtual_network_id = "/subscriptions/1b4f6411-516b-4bec-9a22-6d64c2ff3339/resourceGroups/rg-mft-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-mft-dev-canadacentral-001"
      internet_security_enabled = true
    }
    "peering-hub-to-openai-nonprod-canadacentral-001" = {
      name                      = "peering-hub-to-openai-nonprod-canadacentral-001"
      hub                       = "cc"
      remote_virtual_network_id = "/subscriptions/79fa77c1-d916-47f8-b388-33c03f29c5ea/resourceGroups/rg-openai-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-nonprod-canadacentral-001"
      internet_security_enabled = true
    }
    "peering-hub-to-openai-prod-canadacentral-001" = {
      name                      = "peering-hub-to-openai-prod-canadacentral-001"
      hub                       = "cc"
      remote_virtual_network_id = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-prod-canadacentral-001"
      internet_security_enabled = true
    }
    "peering-hub-to-pta-nonprod-canadacentral-001" = {
      name                      = "peering-hub-to-pta-nonprod-canadacentral-001"
      hub                       = "cc"
      remote_virtual_network_id = "/subscriptions/770996e1-e364-4315-9ab9-0c703d5d0996/resourceGroups/rg-pta-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-nonprod-canadacentral-001"
      internet_security_enabled = true
    }
    "peering-hub-to-pta-prod-canadacentral-001" = {
      name                      = "peering-hub-to-pta-prod-canadacentral-001"
      hub                       = "cc"
      remote_virtual_network_id = "/subscriptions/9f1ecbca-59d7-4ff3-a1b3-0192cb2196a4/resourceGroups/rg-pta-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pta-prod-canadacentral-001"
      internet_security_enabled = true
    }
    "peering-hub-to-runners-connectivity-canadacentral-001" = {
      name                      = "peering-hub-to-runners-connectivity-canadacentral-001"
      hub                       = "cc"
      remote_virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-runners-connectivity-canadacentral-001"
      internet_security_enabled = true
    }
    "peering-hub-to-shared-canadacentral-001" = {
      name                      = "peering-hub-to-shared-canadacentral-001"
      hub                       = "cc"
      remote_virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-shared-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-shared-connectivity-canadacentral-001"
      internet_security_enabled = true
    }
    "peering-hub-to-spo-prod-canadacentral-001" = {
      name                      = "peering-hub-to-spo-prod-canadacentral-001"
      hub                       = "cc"
      remote_virtual_network_id = "/subscriptions/0832c60a-a0fb-4cf4-9add-b555c50e4815/resourceGroups/rg-spo-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-spo-prod-canadacentral-001"
      internet_security_enabled = true
    }
    "peering-hub-to-transit-connectivity-canadacentral-001" = {
      name                      = "peering-hub-to-transit-connectivity-canadacentral-001"
      hub                       = "cc"
      remote_virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-shared-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-transit-connectivity-canadacentral-001"
      internet_security_enabled = true
    }
    "peering-solace-vnet-connection" = {
      name                      = "peering-solace-vnet-connection"
      hub                       = "cc"
      remote_virtual_network_id = "/subscriptions/767bd71b-570e-439a-b102-13997f209d22/resourceGroups/iwdntm8qjsi-aks-cacn-np-infra-rg/providers/Microsoft.Network/virtualNetworks/iwdntm8qjsi-aks-cacn-np-vnet"
      internet_security_enabled = true
    }
    "Peering-spo-vnet-nonprod-Connection" = {
      name                      = "Peering-spo-vnet-nonprod-Connection"
      hub                       = "cc"
      remote_virtual_network_id = "/subscriptions/b8ee8f40-3a3f-4583-b3a2-d34541c46fec/resourceGroups/rg-spo-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-spo-nonprod-canadacentral-001"
      internet_security_enabled = true
    }
    "peering-hub-to-ertest-connectivity-canadaeast-001" = {
      name                      = "peering-hub-to-ertest-connectivity-canadaeast-001"
      hub                       = "ce"
      remote_virtual_network_id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-ertest-canadaeast-001/providers/Microsoft.Network/virtualNetworks/vnet-ertest-canadaeast-001"
      internet_security_enabled = true
    }
    "peering-hub-to-spo-prod-canadaeast-001" = {
      name                      = "peering-hub-to-spo-prod-canadaeast-001"
      hub                       = "ce"
      remote_virtual_network_id = "/subscriptions/0832c60a-a0fb-4cf4-9add-b555c50e4815/resourceGroups/rg-spo-prod-network-canadaeast-001/providers/Microsoft.Network/virtualNetworks/vnet-spo-prod-canadaeast-001"
      internet_security_enabled = true
    }
    "peering-spo-nonprod-canadaeast-vnet-connection" = {
      name                      = "peering-spo-nonprod-canadaeast-vnet-connection"
      hub                       = "ce"
      remote_virtual_network_id = "/subscriptions/b8ee8f40-3a3f-4583-b3a2-d34541c46fec/resourceGroups/rg-spo-nonprod-network-canadaeast-001/providers/Microsoft.Network/virtualNetworks/vnet-spo-nonprod-canadaeast-001"
      internet_security_enabled = true
    }
    # Added from the 2026-09-28 inventory; remote VNet IDs are from the export.
    "peering-hub-to-pea-dev-canadacentral-001" = {
      name                      = "peering-hub-to-pea-dev-canadacentral-001"
      hub                       = "cc"
      remote_virtual_network_id = "/subscriptions/0c73b3b8-beee-473e-9844-9f26f1158d3a/resourceGroups/rg-pea-app-dev-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-pea-dev-canadacentral-001"
      internet_security_enabled = true
    }
    "peering-hub-to-dthree-dev-canadacentral-001" = {
      name                      = "peering-hub-to-dthree-dev-canadacentral-001"
      hub                       = "cc"
      remote_virtual_network_id = "/subscriptions/a31e3d9d-bc24-4bdb-a7a8-b00b560eb58b/resourceGroups/rg-dthree-app-dev-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dthree-dev-canadacentral-001"
      internet_security_enabled = true
    }
    "peering-hub-to-ecsi-nonprod-canadacentral-001" = {
      name                      = "peering-hub-to-ecsi-nonprod-canadacentral-001"
      hub                       = "cc"
      remote_virtual_network_id = "/subscriptions/f7ae617d-7194-4ae1-8f2a-2b5a6ade49ce/resourceGroups/rg-ecsi-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-ecsi-nonprod-canadacentral-001"
      internet_security_enabled = true
    }
    "peering-hub-to-boundary-test-canadacentral-001" = {
      name                      = "peering-hub-to-boundary-test-canadacentral-001"
      hub                       = "cc"
      remote_virtual_network_id = "/subscriptions/8213d17f-d226-4870-8054-ca292da2ba10/resourceGroups/rg-boundary-test-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-boundary-test-canadacentral-001"
      internet_security_enabled = true
    }
    "peering-hub-to-finops-canadacentral-001" = {
      name                      = "peering-hub-to-finops-canadacentral-001"
      hub                       = "cc"
      remote_virtual_network_id = "/subscriptions/bb7c23ad-af29-4ee0-8ed9-afae5ecbf203/resourceGroups/rg-finops-canadacentral-001/providers/Microsoft.Network/virtualNetworks/bchydrofinops-vnet-canadacentral"
      internet_security_enabled = true
    }
    "peering-hub-to-wrap-test-canadacentral-001" = {
      name                      = "peering-hub-to-wrap-test-canadacentral-001"
      hub                       = "cc"
      remote_virtual_network_id = "/subscriptions/6e6b8249-1945-49ee-8770-08597cb1850e/resourceGroups/rg-wrap-test-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-wrap-test-canadacentral-001"
      internet_security_enabled = true
    }
    "peering-hub-to-safehub-dev-canadacentral-001" = {
      name                      = "peering-hub-to-safehub-dev-canadacentral-001"
      hub                       = "cc"
      remote_virtual_network_id = "/subscriptions/5321d957-2756-4eb1-b1c4-ea780b37c73f/resourceGroups/rg-safehub-dev-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-safehub-dev-canadacentral-001"
      internet_security_enabled = true
    }
    "peering-hub-to-cns-nonprod-canadacentral-001" = {
      name                      = "peering-hub-to-cns-nonprod-canadacentral-001"
      hub                       = "cc"
      remote_virtual_network_id = "/subscriptions/b495240d-9ed9-4852-8868-586831fff63c/resourceGroups/rg-cns-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cns-nonprod-canadacentral-001"
      internet_security_enabled = true
    }
    "peering-hub-to-lims-dev-canadacentral-001" = {
      name                      = "peering-hub-to-lims-dev-canadacentral-001"
      hub                       = "cc"
      remote_virtual_network_id = "/subscriptions/3473c6d2-bcc4-4443-8561-b05d7341c8b8/resourceGroups/rg-lims-app-dev-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-lims-dev-canadacentral-001"
      internet_security_enabled = true
    }
    "peering-hub-to-cswt-test-canadacentral-001" = {
      name                      = "peering-hub-to-cswt-test-canadacentral-001"
      hub                       = "cc"
      remote_virtual_network_id = "/subscriptions/f7b409b2-a4d3-4680-abbc-e1b0de7e6024/resourceGroups/rg-cswt-test-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cswt-test-canadacentral-001"
      internet_security_enabled = true
    }
    "peering-hub-to-gom-test-canadacentral-001" = {
      name                      = "peering-hub-to-gom-test-canadacentral-001"
      hub                       = "cc"
      remote_virtual_network_id = "/subscriptions/befbb614-4ece-4f45-bf8f-c69a4189704c/resourceGroups/rg-gom-test-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-gom-test-canadacentral-001"
      internet_security_enabled = true
    }
    "peering-hub-to-cep-qas-canadacentral-001" = {
      name                      = "peering-hub-to-cep-qas-canadacentral-001"
      hub                       = "cc"
      remote_virtual_network_id = "/subscriptions/a99c1adb-6d41-47d1-9e26-ebc725da7c71/resourceGroups/rg-cep-qas-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cep-qas-canadacentral-001"
      internet_security_enabled = true
    }
    "peering-hub-to-cep-dev-canadacentral-001" = {
      name                      = "peering-hub-to-cep-dev-canadacentral-001"
      hub                       = "cc"
      remote_virtual_network_id = "/subscriptions/a99c1adb-6d41-47d1-9e26-ebc725da7c71/resourceGroups/rg-cep-dev-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cep-dev-canadacentral-001"
      internet_security_enabled = true
    }
    "peering-hub-to-citt-canadacentral-001" = {
      name                      = "peering-hub-to-citt-canadacentral-001"
      hub                       = "cc"
      remote_virtual_network_id = "/subscriptions/f497fe28-050a-43e0-bff9-f82587d5ecf2/resourceGroups/rg-citt-app-dev-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-citt-dev-canadacentral-001"
      internet_security_enabled = true
    }
    "peering-hub-to-cep-stg-canadacentral-001" = {
      name                      = "peering-hub-to-cep-stg-canadacentral-001"
      hub                       = "cc"
      remote_virtual_network_id = "/subscriptions/d6a3ba21-cf3e-4d3b-a583-084873291e86/resourceGroups/rg-cep-stg-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cep-stg-canadacentral-001"
      internet_security_enabled = true
    }
    "Peering-vhub-connectivity-shipping-nonprod" = {
      name                      = "Peering-vhub-connectivity-shipping-nonprod"
      hub                       = "cc"
      remote_virtual_network_id = "/subscriptions/ecdddbde-9bf1-4f34-9eda-97e77b030625/resourceGroups/rg-shipd-app-nonprod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-shipd-nonprod-canadacentral-001"
      internet_security_enabled = true
    }
    "peering-hub-to-sub-dmz-internal-nonprod-canadacentral-001" = {
      name                      = "peering-hub-to-sub-dmz-internal-nonprod-canadacentral-001"
      hub                       = "cc"
      remote_virtual_network_id = "/subscriptions/0fdc6acd-d006-4051-af9c-df8adb16bd0a/resourceGroups/rg-sharedsvc-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-sharedsvc-nonprod-gw-canadacentral-001"
      internet_security_enabled = true
    }
    "peering-hub-to-cep-prod-canadacentral-001" = {
      name                      = "peering-hub-to-cep-prod-canadacentral-001"
      hub                       = "cc"
      remote_virtual_network_id = "/subscriptions/d6a3ba21-cf3e-4d3b-a583-084873291e86/resourceGroups/rg-cep-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-cep-prod-canadacentral-001"
      internet_security_enabled = true
    }
    "peering-hub-to-dthree-prod-canadacentral-001" = {
      name                      = "peering-hub-to-dthree-prod-canadacentral-001"
      hub                       = "cc"
      remote_virtual_network_id = "/subscriptions/bd6fac84-0dce-4be4-a0ae-a28b04981270/resourceGroups/rg-dthree-app-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dthree-prod-canadacentral-001"
      internet_security_enabled = true
    }
    "peering-hub-to-solace-vnet-002" = {
      name                      = "peering-hub-to-solace-vnet-002"
      hub                       = "cc"
      remote_virtual_network_id = "/subscriptions/767bd71b-570e-439a-b102-13997f209d22/resourceGroups/qxbbl6j6y3w-aks-cacn-prd-infra-rg/providers/Microsoft.Network/virtualNetworks/qxbbl6j6y3w-aks-cacn-prd-vnet"
      internet_security_enabled = true
    }
    # Added from the 2026-10-05 inventory.
    "peering-hub-to-ampl-test-canadacentral-001" = {
      name                      = "peering-hub-to-ampl-test-canadacentral-001"
      hub                       = "cc"
      remote_virtual_network_id = "/subscriptions/256779b8-5e03-4fb7-9826-312035296977/resourceGroups/rg-ampl-app-test-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-ampl-test-canadacentral-001"
      internet_security_enabled = true
    }
    "peering-hub-to-mft-qas-canadacentral-001" = {
      name                      = "peering-hub-to-mft-qas-canadacentral-001"
      hub                       = "cc"
      remote_virtual_network_id = "/subscriptions/1b4f6411-516b-4bec-9a22-6d64c2ff3339/resourceGroups/rg-mft-qas-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-mft-qas-canadacentral-001"
      internet_security_enabled = true
    }
    "peering-hub-to-mft-prod-canadacentral-001" = {
      name                      = "peering-hub-to-mft-prod-canadacentral-001"
      hub                       = "cc"
      remote_virtual_network_id = "/subscriptions/99f6f29d-d824-4061-891f-0e2a28ffb483/resourceGroups/rg-mft-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-mft-prod-canadacentral-001"
      internet_security_enabled = true
    }
    "peering-hub-to-sharedservices-prod-canadacentral-001" = {
      name                      = "peering-hub-to-sharedservices-prod-canadacentral-001"
      hub                       = "cc"
      remote_virtual_network_id = "/subscriptions/1e46e0fc-73a7-4ca8-9877-f4d803736458/resourceGroups/rg-sharedservices-prod-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-sharedservices-prod-canadacentral-001"
      internet_security_enabled = true
    }
  }
}


resource "azurerm_virtual_hub_bgp_connection" "this" {
  for_each = local.hub_bgp_connections

  name                          = each.value.name
  virtual_hub_id                = azurerm_virtual_hub.this[each.value.hub].id
  peer_asn                      = each.value.peer_asn
  peer_ip                       = each.value.peer_ip
  virtual_network_connection_id = azurerm_virtual_hub_connection.this[each.value.connection_key].id
}

locals {
  hub_bgp_connections = {
    "bgp-peer-transit-connectivity-canadacentral-001" = {
      name           = "bgp-peer-transit-connectivity-canadacentral-001"
      hub            = "cc"
      peer_asn       = 65510
      peer_ip        = "10.195.122.4"
      connection_key = "peering-hub-to-transit-connectivity-canadacentral-001"
    }
  }
}


resource "azurerm_express_route_gateway" "this" {
  for_each = local.express_route_gateways

  name                          = each.value.name
  resource_group_name           = module.resource_group[each.value.rg_key].name
  location                      = each.value.location
  virtual_hub_id                = azurerm_virtual_hub.this[each.value.hub].id
  scale_units                   = each.value.scale_units
  allow_non_virtual_wan_traffic = false
  tags                          = local.common_tags
}

locals {
  express_route_gateways = {
    cc = {
      name        = "ergw-connectivity-canadacentral-001"
      rg_key      = "hub_cc"
      location    = "canadacentral"
      hub         = "cc"
      scale_units = 2
    }
    ce = {
      name        = "ergw-connectivity-canadaeast-001"
      rg_key      = "hub_ce"
      location    = "canadaeast"
      hub         = "ce"
      scale_units = 2
    }
  }
}


# ExpressRoute circuit peering ids belong to the circuit tier (both circuits live in
# rg-hub-connectivity-canadacentral-001).
locals {
  er_circuit_peering_ids = {
    toronto = "${module.resource_group["hub_cc"].resource_id}/providers/Microsoft.Network/expressRouteCircuits/erc-toronto-connectivity-cacentral-001/peerings/AzurePrivatePeering"
    quebec  = "${module.resource_group["hub_cc"].resource_id}/providers/Microsoft.Network/expressRouteCircuits/erc-quebec-connectivity-caeast-001/peerings/AzurePrivatePeering"
  }
}

resource "azurerm_express_route_connection" "this" {
  for_each = local.express_route_connections

  name                                 = each.value.name
  express_route_gateway_id             = azurerm_express_route_gateway.this[each.value.hub].id
  express_route_circuit_peering_id     = local.er_circuit_peering_ids[each.value.circuit]
  routing_weight                       = each.value.routing_weight
  enable_internet_security             = false
  express_route_gateway_bypass_enabled = false

  routing {
    associated_route_table_id = azurerm_virtual_hub.this[each.value.hub].default_route_table_id
    outbound_route_map_id     = azurerm_route_map.this[each.value.outbound_route_map_key].id
    propagated_route_table {
      labels          = ["none"]
      route_table_ids = [azurerm_virtual_hub_route_table.this["${each.value.hub}-none"].id]
    }
  }
}

locals {
  express_route_connections = {
    "ExRConnection-canadacentral-1765413785995" = {
      name                   = "ExRConnection-canadacentral-1765413785995"
      hub                    = "cc"
      circuit                = "toronto"
      routing_weight         = 300
      outbound_route_map_key = "cc-rm-toronto-outbound"
    }
    "ExRConnection-canadacentral-1765415088995" = {
      name                   = "ExRConnection-canadacentral-1765415088995"
      hub                    = "cc"
      circuit                = "quebec"
      routing_weight         = 200
      outbound_route_map_key = "cc-rm-quebec-outbound"
    }
    "ExRConnection-canadaeast-1765215308956" = {
      name                   = "ExRConnection-canadaeast-1765215308956"
      hub                    = "ce"
      circuit                = "toronto"
      routing_weight         = 200
      outbound_route_map_key = "ce-rm-toronto-outbound"
    }
    "ExRConnection-canadaeast-1765412290836" = {
      name                   = "ExRConnection-canadaeast-1765412290836"
      hub                    = "ce"
      circuit                = "quebec"
      routing_weight         = 300
      outbound_route_map_key = "ce-rm-quebec-outbound"
    }
  }
}


resource "azurerm_vpn_site" "this" {
  for_each = local.vpn_sites

  name                = each.value.name
  resource_group_name = module.resource_group[each.value.rg_key].name
  location            = each.value.location
  virtual_wan_id      = azurerm_virtual_wan.this.id
  address_cidrs       = each.value.address_cidrs
  device_vendor       = each.value.device_vendor

  dynamic "link" {
    for_each = each.value.links
    content {
      name          = link.value.name
      ip_address    = link.value.ip_address
      provider_name = link.value.provider_name
      speed_in_mbps = link.value.speed_in_mbps
      bgp {
        asn             = link.value.bgp_asn
        peering_address = link.value.bgp_peering_address
      }
    }
  }

  o365_policy {
    traffic_category {
      allow_endpoint_enabled    = false
      default_endpoint_enabled  = false
      optimize_endpoint_enabled = false
    }
  }
}

locals {
  vpn_sites = {
    cc = {
      name          = "vsite-onprem-connectivity-canadacentral-001"
      rg_key        = "hub_cc"
      location      = "canadacentral"
      address_cidrs = ["10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "142.52.0.0/16"]
      device_vendor = "Cisco Firepower FTD"
      links = [
        {
          name                = "vsite-onprem-connectivity-canadacentral-001-onprem"
          ip_address          = "142.52.193.25"
          provider_name       = "Telus"
          speed_in_mbps       = 2000
          bgp_asn             = 65521
          bgp_peering_address = "10.242.32.10"
        },
      ]
    }
    ce = {
      name          = "vsite-onprem-connectivity-canadaeast-001"
      rg_key        = "hub_ce"
      location      = "canadaeast"
      address_cidrs = ["10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "142.52.0.0/16"]
      device_vendor = "Cisco Firepower FTD"
      links = [
        {
          name                = "vsite-onprem-connectivity-canadaeast-001-onprem"
          ip_address          = "142.52.193.25"
          provider_name       = "Telus"
          speed_in_mbps       = 2000
          bgp_asn             = 65521
          bgp_peering_address = "10.242.32.10"
        },
      ]
    }
  }
}


resource "azurerm_vpn_gateway" "this" {
  for_each = local.vpn_gateways

  name                                  = each.value.name
  resource_group_name                   = module.resource_group[each.value.rg_key].name
  location                              = each.value.location
  virtual_hub_id                        = azurerm_virtual_hub.this[each.value.hub].id
  scale_unit                            = each.value.scale_unit
  bgp_route_translation_for_nat_enabled = false
  tags                                  = local.common_tags

  bgp_settings {
    asn         = each.value.bgp_asn
    peer_weight = each.value.peer_weight
  }
}

locals {
  vpn_gateways = {
    cc = {
      name        = "vpn-connectivity-canadacentral-001"
      rg_key      = "hub_cc"
      location    = "canadacentral"
      hub         = "cc"
      scale_unit  = 1
      bgp_asn     = 65515
      peer_weight = 10
    }
    ce = {
      name        = "vpn-connectivity-canadaeast-001"
      rg_key      = "hub_ce"
      location    = "canadaeast"
      hub         = "ce"
      scale_unit  = 1
      bgp_asn     = 65515
      peer_weight = 10
    }
  }
}


# shared_key omitted (secret); set out-of-band before apply.
resource "azurerm_vpn_gateway_connection" "this" {
  for_each = local.vpn_gateway_connections

  name                      = each.value.name
  vpn_gateway_id            = azurerm_vpn_gateway.this[each.value.hub].id
  remote_vpn_site_id        = azurerm_vpn_site.this[each.value.hub].id
  internet_security_enabled = each.value.internet_security_enabled

  dynamic "vpn_link" {
    for_each = each.value.vpn_links
    content {
      name                                  = vpn_link.value.name
      vpn_site_link_id                      = "${azurerm_vpn_site.this[each.value.hub].id}/vpnSiteLinks/${vpn_link.value.site_link_name}"
      bandwidth_mbps                        = vpn_link.value.bandwidth_mbps
      bgp_enabled                           = vpn_link.value.bgp_enabled
      protocol                              = vpn_link.value.protocol
      ratelimit_enabled                     = vpn_link.value.ratelimit_enabled
      route_weight                          = vpn_link.value.route_weight
      connection_mode                       = vpn_link.value.connection_mode
      dpd_timeout_seconds                   = vpn_link.value.dpd_timeout_seconds
      local_azure_ip_address_enabled        = vpn_link.value.local_azure_ip_address_enabled
      policy_based_traffic_selector_enabled = vpn_link.value.policy_based_traffic_selector_enabled
      # TODO shared_key = <secret>

      ipsec_policy {
        dh_group                 = vpn_link.value.ipsec.dh_group
        ike_encryption_algorithm = vpn_link.value.ipsec.ike_encryption_algorithm
        ike_integrity_algorithm  = vpn_link.value.ipsec.ike_integrity_algorithm
        encryption_algorithm     = vpn_link.value.ipsec.encryption_algorithm
        integrity_algorithm      = vpn_link.value.ipsec.integrity_algorithm
        pfs_group                = vpn_link.value.ipsec.pfs_group
        sa_data_size_kb          = vpn_link.value.ipsec.sa_data_size_kb
        sa_lifetime_sec          = vpn_link.value.ipsec.sa_lifetime_sec
      }
    }
  }

  routing {
    associated_route_table = azurerm_virtual_hub.this[each.value.hub].default_route_table_id
    inbound_route_map_id   = azurerm_route_map.this["${each.value.hub}-rm-vpn-inbound"].id
    outbound_route_map_id  = azurerm_route_map.this["${each.value.hub}-rm-vpn-outbound"].id
    propagated_route_table {
      labels          = ["none"]
      route_table_ids = [azurerm_virtual_hub_route_table.this["${each.value.hub}-none"].id]
    }
  }

  traffic_selector_policy {
    local_address_ranges  = ["0.0.0.0/0"]
    remote_address_ranges = ["0.0.0.0/0"]
  }
}

locals {
  vpn_gateway_connections = {
    cc = {
      name                      = "vconn-onprem-connectivity-canadacentral-001"
      hub                       = "cc"
      internet_security_enabled = true
      vpn_links = [
        {
          name                                  = "vsite-onprem-connectivity-canadacentral-001-onprem"
          site_link_name                        = "vsite-onprem-connectivity-canadacentral-001-onprem"
          bandwidth_mbps                        = 2000
          bgp_enabled                           = true
          protocol                              = "IKEv2"
          ratelimit_enabled                     = true
          route_weight                          = 0
          connection_mode                       = "Default"
          dpd_timeout_seconds                   = 45
          local_azure_ip_address_enabled        = false
          policy_based_traffic_selector_enabled = false
          ipsec = {
            dh_group                 = "ECP384"
            ike_encryption_algorithm = "GCMAES256"
            ike_integrity_algorithm  = "SHA384"
            encryption_algorithm     = "GCMAES256"
            integrity_algorithm      = "GCMAES256"
            pfs_group                = "ECP384"
            sa_data_size_kb          = "102400000"
            sa_lifetime_sec          = "14400"
          }
        },
      ]
    }
    ce = {
      name                      = "vconn-onprem-connectivity-canadaeast-001"
      hub                       = "ce"
      internet_security_enabled = true
      vpn_links = [
        {
          name                                  = "vsite-onprem-connectivity-canadaeast-001-onprem"
          site_link_name                        = "vsite-onprem-connectivity-canadaeast-001-onprem"
          bandwidth_mbps                        = 2000
          bgp_enabled                           = true
          protocol                              = "IKEv2"
          ratelimit_enabled                     = true
          route_weight                          = 0
          connection_mode                       = "Default"
          dpd_timeout_seconds                   = 45
          local_azure_ip_address_enabled        = false
          policy_based_traffic_selector_enabled = false
          ipsec = {
            dh_group                 = "ECP384"
            ike_encryption_algorithm = "GCMAES256"
            ike_integrity_algorithm  = "SHA384"
            encryption_algorithm     = "GCMAES256"
            integrity_algorithm      = "GCMAES256"
            pfs_group                = "ECP384"
            sa_data_size_kb          = "102400000"
            sa_lifetime_sec          = "14400"
          }
        },
      ]
    }
  }
}

