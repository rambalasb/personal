#!/usr/bin/env bash
# Full inventory of the connectivity subscription, for reconciling both
# tf-deploy-platform-connectivity and tf-deploy-platform-firewall-management.
# Produced full-inventory-20261005/.
#
# Run in Azure Cloud Shell (bash): it needs az, jq, GNU xargs and sha1sum.
# On macOS use gxargs/gsha1sum from `brew install findutils coreutils`.
#
#   bash export_full_inventory.sh 2> errors.txt
#
# Cloud Shell drops idle sessions after 20 minutes. The two per-resource steps
# run in parallel and cache each result under cache/, so re-running after a
# disconnect resumes instead of starting over. Delete cache/ before an export
# on a later date, or it returns stale results.
#
# Done when the summary shows equal resource / diag / props counts and
# "export failures: 0". Anything else: re-run, then read errors.txt.

SUB=${SUB:-f3835bc1-9829-4ac8-9d7a-0999e0b29b90}
OUT=${OUT:-$HOME/clouddrive/full-inventory}
PAR=${PAR:-8}
mkdir -p "$OUT" && cd "$OUT" || exit 1
rm -rf props children
mkdir -p props children cache/diag cache/props cache/err
az account set --subscription "$SUB" || exit 1
az config set extension.use_dynamic_install=yes_without_prompt -o none

echo "[1] top-level resources"
az resource list --subscription "$SUB" -o json > azure-inventory.json
jq -r 'sort_by(.id)[] | [.id, .type, .location] | @tsv' azure-inventory.json > azure-inventory.tsv

echo "[2] resource groups + subscription"
az graph query -q "ResourceContainers | where subscriptionId =~ '$SUB' | project id, type, location" \
  --subscriptions "$SUB" --first 1000 -o json > resource-containers.json
jq -r '.data[] | [.id, .type, .location] | @tsv' resource-containers.json >> azure-inventory.tsv

echo "[3] firewall rule collection groups (ids; full rules in step 15)"
az network firewall policy list --query "[].[resourceGroup,name]" -o tsv | while read -r g n; do
  az network firewall policy rule-collection-group list -g "$g" --policy-name "$n" --query "[].id" -o tsv
done | sed 's/$/\tMicrosoft.Network\/firewallPolicies\/ruleCollectionGroups\t-/' >> azure-inventory.tsv

echo "[4] private DNS vnet links"
az network private-dns zone list --query "[].[resourceGroup,name]" -o tsv | while read -r g n; do
  az network private-dns link vnet list -g "$g" -z "$n" --query "[].id" -o tsv
done | sed 's/$/\tMicrosoft.Network\/privateDnsZones\/virtualNetworkLinks\t-/' >> azure-inventory.tsv

echo "[5] vWAN hub connections + route tables"
az network vhub list --query "[].[resourceGroup,name]" -o tsv | while read -r g n; do
  az network vhub connection list -g "$g" --vhub-name "$n" --query "[].id" -o tsv \
    | sed 's/$/\tMicrosoft.Network\/virtualHubs\/hubVirtualNetworkConnections\t-/'
  az network vhub route-table list -g "$g" --vhub-name "$n" --query "[].id" -o tsv \
    | sed 's/$/\tMicrosoft.Network\/virtualHubs\/hubRouteTables\t-/'
done >> azure-inventory.tsv
sort -u -o azure-inventory.tsv azure-inventory.tsv

echo "[6] IP groups"
az network ip-group list -o json > ip-groups.json

echo "[7] classic inline firewall rules"
az network firewall list --query "[].[resourceGroup,name]" -o tsv | while read -r g n; do
  az network firewall show -g "$g" -n "$n" -o json \
    | jq --arg fw "$n" --arg rg "$g" '{firewall:$fw, resourceGroup:$rg, networkRuleCollections:.networkRuleCollections}'
done | jq -s '.' > classic-firewall-rules.json

echo "[8] role assignments"
az role assignment list --all \
  --query "[].{role:roleDefinitionName,principal:principalId,principalType:principalType,scope:scope}" \
  -o json > role-assignments.json

key() { printf %s "$1" | sha1sum | cut -c1-40; }
diag_one() {
  id=$1; h=$(key "$id"); f=cache/diag/$h; e=cache/err/diag-$h
  [ -s "$f" ] && return 0
  if out=$(az monitor diagnostic-settings list --resource "$id" -o json 2>"$e"); then
    printf '== %s\n%s\n' "$id" "$out" > "$f.tmp" && mv "$f.tmp" "$f"
  elif grep -q ResourceTypeNotSupported "$e"; then
    printf '== %s\nUNSUPPORTED\n' "$id" > "$f"
  else
    echo "EXPORT-FAILED diag $id: $(tr '\n' ' ' < "$e")" >&2
  fi
  rm -f "$e"
}
props_one() {
  id=$1; h=$(key "$id"); f=cache/props/$h; e=cache/err/props-$h
  [ -s "$f" ] && return 0
  if ! az resource show --ids "$id" -o json > "$f.tmp" 2>"$e"; then
    # az picks the newest api-version the provider advertises; some regions do not serve it yet
    ver=$(grep -o "supported api-versions are '[^']*'" "$e" | head -1 | grep -oE '[0-9]{4}-[0-9]{2}-[0-9]{2}(-preview)?' | grep -v preview | tail -1)
    [ -n "$ver" ] && az resource show --ids "$id" --api-version "$ver" -o json > "$f.tmp" 2>"$e"
  fi
  if [ -s "$f.tmp" ] && jq -e . "$f.tmp" >/dev/null 2>&1; then
    mv "$f.tmp" "$f"
  else
    rm -f "$f.tmp"; echo "EXPORT-FAILED props $id: $(tr '\n' ' ' < "$e")" >&2
  fi
  rm -f "$e"
}
export -f key diag_one props_one

echo "[9] diagnostic settings per resource ($PAR in parallel, resumable)"
jq -r '.[].id' azure-inventory.json | xargs -d '\n' -P "$PAR" -I{} bash -c 'diag_one "$1"' _ {}
: > diagnostic-settings.txt
jq -r '.[].id' azure-inventory.json | while read -r id; do
  f=cache/diag/$(key "$id"); [ -s "$f" ] || continue
  body=$(tail -n +2 "$f")
  [ "$body" = "[]" ] || [ "$body" = "UNSUPPORTED" ] || cat "$f" >> diagnostic-settings.txt
done
az monitor diagnostic-settings subscription list -o json > subscription-diagnostic-settings.json

echo "[10] locks"
az lock list -o json > locks.json

echo "[11] policy assignments + exemptions"
az policy assignment list --disable-scope-strict-match -o json > policy-assignments.json
az policy exemption list --disable-scope-strict-match -o json > policy-exemptions.json

echo "[12] federated credentials"
: > federated-credentials.txt
az identity list --query "[].[resourceGroup,name]" -o tsv | while read -r g n; do
  echo "== $n" >> federated-credentials.txt
  az identity federated-credential list --identity-name "$n" -g "$g" -o json >> federated-credentials.txt
done

echo "[13] full properties per resource ($PAR in parallel, resumable)"
jq -r '.[].id' azure-inventory.json | xargs -d '\n' -P "$PAR" -I{} bash -c 'props_one "$1"' _ {}
# Group case-insensitively: Azure returns some types in two casings, and two
# spellings writing the same file would overwrite each other.
jq -r '[.[].type | ascii_downcase] | unique[]' azure-inventory.json | while read -r t; do
  jq -r --arg t "$t" '.[] | select((.type|ascii_downcase)==$t) | .id' azure-inventory.json | while read -r id; do
    f=cache/props/$(key "$id"); [ -s "$f" ] && cat "$f"
  done | jq -s '.' > "props/$(echo "$t" | tr '/' '_').json"
done

echo "[14] child resources, full objects"
az network vnet list -o json          > .vnets.json
az network nsg list -o json           > .nsgs.json
az group list --query "[].name" -o tsv | while read -r g; do
  az network route-table list -g "$g" -o json || echo "EXPORT-FAILED route-tables $g" >&2
done | jq -s 'add // []' > .rts.json
az network express-route list -o json > .ercs.json
az network lb list -o json            > .lbs.json
jq '[.[] | .subnets[]?]'                .vnets.json > children/vnet-subnets.json
jq '[.[] | .virtualNetworkPeerings[]?]' .vnets.json > children/vnet-peerings.json
jq '[.[] | .securityRules[]?]'          .nsgs.json  > children/nsg-rules.json
jq '[.[] | .routes[]?]'                 .rts.json   > children/route-table-routes.json
jq '[.[] | .peerings[]?]'               .ercs.json  > children/erc-peerings.json
jq '[.[] | .backendAddressPools[]?]'    .lbs.json   > children/lb-pools.json
jq '[.[] | .probes[]?]'                 .lbs.json   > children/lb-probes.json
jq '[.[] | .loadBalancingRules[]?]'     .lbs.json   > children/lb-rules.json
rm -f .vnets.json .nsgs.json .rts.json .ercs.json .lbs.json

# per <output file> <az args with $g/$n>  -- reads "rg name" pairs on stdin
per() {
  out=$1; shift
  while read -r g n; do
    [ -n "$n" ] || continue
    eval "az $* -o json" || echo "EXPORT-FAILED $out $g/$n" >&2
  done | jq -s 'add // []' > "children/$out"
}
az network private-dns zone list --query "[].[resourceGroup,name]" -o tsv \
  | per pdns-vnet-links.json 'network private-dns link vnet list -g "$g" -z "$n"'
az network vhub list --query "[].[resourceGroup,name]" -o tsv > .hubs.tsv
per vhub-connections.json    'network vhub connection list -g "$g" --vhub-name "$n"'    < .hubs.tsv
per vhub-route-tables.json   'network vhub route-table list -g "$g" --vhub-name "$n"'   < .hubs.tsv
per vhub-route-maps.json     'network vhub route-map list -g "$g" --vhub-name "$n"'     < .hubs.tsv
per vhub-routing-intent.json 'network vhub routing-intent list -g "$g" --vhub "$n"'     < .hubs.tsv
per vhub-bgp.json            'network vhub bgpconnection list -g "$g" --vhub-name "$n"' < .hubs.tsv
rm -f .hubs.tsv
# Returns [] in current CLI versions; the four connections are inside
# props/microsoft.network_expressroutegateways.json (expressRouteConnections).
az network express-route gateway list --query "[].[resourceGroup,name]" -o tsv \
  | per ergw-connections.json 'network express-route gateway connection list -g "$g" --gateway-name "$n"'
az network vpn-gateway list --query "[].[resourceGroup,name]" -o tsv \
  | per vpn-connections.json 'network vpn-gateway connection list -g "$g" --gateway-name "$n"'
az backup vault list --query "[].[resourceGroup,name]" -o tsv \
  | per rsv-backup-policies.json 'backup policy list -g "$g" --vault-name "$n"'
az dns-resolver list --query "[].[resourceGroup,name]" -o tsv > .resolvers.tsv
per dnsr-inbound.json  'dns-resolver inbound-endpoint list -g "$g" --dns-resolver-name "$n"'  < .resolvers.tsv
per dnsr-outbound.json 'dns-resolver outbound-endpoint list -g "$g" --dns-resolver-name "$n"' < .resolvers.tsv
rm -f .resolvers.tsv
az dns-resolver forwarding-ruleset list --query "[].[resourceGroup,name]" -o tsv \
  | per frs-rules.json 'dns-resolver forwarding-rule list -g "$g" --ruleset-name "$n"'

echo "[15] firewall rule collection groups, full rules"
az network firewall policy list --query "[].[resourceGroup,name]" -o tsv | while read -r g n; do
  az network firewall policy rule-collection-group list -g "$g" --policy-name "$n" -o json \
    || echo "EXPORT-FAILED rule-collection-groups $g/$n" >&2
done | jq -s 'add // []' > rule-collection-groups.json

echo "[16] bundle"
ZIP="full-inventory-$(date +%Y%m%d-%H%M%S).zip"
zip -qr "$ZIP" azure-inventory.json azure-inventory.tsv resource-containers.json \
  ip-groups.json classic-firewall-rules.json role-assignments.json rule-collection-groups.json \
  diagnostic-settings.txt subscription-diagnostic-settings.json locks.json \
  policy-assignments.json policy-exemptions.json federated-credentials.txt \
  props children errors.txt
echo
echo "resources: $(jq length azure-inventory.json) | diag cached: $(ls cache/diag | grep -vc tmp) | props cached: $(ls cache/props | grep -vc tmp)"
echo "export failures: $(grep -c EXPORT-FAILED errors.txt 2>/dev/null || echo '?')"
echo "zip -> $OUT/$ZIP"
echo "Cloud Shell: download \"$OUT/$ZIP\""
