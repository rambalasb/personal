# conn_alerts.tf
# The connectivity alerts tier, through tf-wrapper-avm-monitor-alerts. The four
# standard ALZ alerts stay in monitoring.tf on the amba-alz pattern module;
# every other alert in the subscription is here.
#
# Action groups the alerts target live in the MANAGEMENT subscription and are
# referenced by ID. The two declared here are Azure Backup's own, in
# AzureBackupRG_canadacentral_1.
#
# Metric alert names come from the portal inventory, not the CLI dump: the
# generic Microsoft.Resources API lowercases microsoft.insights ids and derives
# name from them, so 16 of 19 read back in the wrong case. name is ForceNew on
# azurerm_monitor_metric_alert, so the wrong case is a rebuild, not an update.

variable "enable_conn_alerts" {
  type    = bool
  default = false
}

locals {
  # Scopes live in the hub tier RGs. The azfw scope is a constructed id: the
  # firewall is owned by tf-deploy-platform-firewall-management, and an alert
  # that watches a resource does not need to manage it.
  conn_alerts_azfw_cc_id = "${local.subscription_scope}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/azureFirewalls/azfw-connectivity-canadacentral-001"
  conn_alerts_vpn_cc_id  = "${local.subscription_scope}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/vpnGateways/vpn-connectivity-canadacentral-001"
  conn_alerts_vpn_ce_id  = "${local.subscription_scope}/resourceGroups/rg-hub-connectivity-canadaeast-001/providers/Microsoft.Network/vpnGateways/vpn-connectivity-canadaeast-001"

  # AzFW action group — mgmt sub (mail + servicenow ags are declared in locals.tf).
  mgmt_azfw_ag_id = "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/rg-alerts-management-canadacentral-001/providers/Microsoft.Insights/actionGroups/ag-AzFW-alert-CanadaCentral-001"
}

locals {
  # ---- Metric alerts (19) ----
  monitor_metric_alerts = {
    backup_alerts = {
      name                     = "Backup Alerts"
      resource_group_name      = "rg-runners-connectivity-canadacentral-001"
      scopes                   = ["/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.RecoveryServices/vaults/rsv-connectivity-canadacentral-001"]
      description              = ""
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT15M"
      window_size              = "PT6H"
      severity                 = 3
      target_resource_type     = "Microsoft.RecoveryServices/vaults"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.RecoveryServices/vaults"
          metric_name            = "BackupHealthEvent"
          aggregation            = "Count"
          operator               = "GreaterThan"
          threshold              = 0.0
          skip_metric_validation = false
        },
      ]
      action_group_ids = [local.mgmt_mail_ag_id]
      tags             = { "CostCenterId" = "80025906", "Environment" = "Prod" }
    }
    erc_arp_availibility_alert_canadacentral = {
      name                     = "ERC-ARP-Availibility-Alert-canadacentral"
      resource_group_name      = "rg-hub-connectivity-canadacentral-001"
      scopes                   = ["/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/expressRouteCircuits/erc-toronto-connectivity-cacentral-001"]
      description              = "This  alert is triggered when there is ARP packet drop"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 1
      target_resource_type     = "Microsoft.Network/expressRouteCircuits"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Network/expressRouteCircuits"
          metric_name            = "ArpAvailability"
          aggregation            = "Average"
          operator               = "LessThan"
          threshold              = 100.0
          skip_metric_validation = false
        },
      ]
      action_group_ids = [local.mgmt_mail_ag_id]
      tags             = { "CostCenterId" = "80025906", "Environment" = "Prod" }
    }
    erc_arp_availibility_alert_canadaeast = {
      name                     = "ERC-ARP-Availibility-Alert-canadaeast"
      resource_group_name      = "rg-hub-connectivity-canadacentral-001"
      scopes                   = ["/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/expressRouteCircuits/erc-quebec-connectivity-caeast-001"]
      description              = "This alert is triggered when there is ARP packet drop"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 1
      target_resource_type     = "Microsoft.Network/expressRouteCircuits"
      target_resource_location = "canadaeast"
      criteria = [
        {
          metric_namespace       = "Microsoft.Network/expressRouteCircuits"
          metric_name            = "ArpAvailability"
          aggregation            = "Average"
          operator               = "LessThan"
          threshold              = 100.0
          skip_metric_validation = false
        },
      ]
      action_group_ids = [local.mgmt_mail_ag_id]
      tags             = { "CostCenterId" = "80025906", "Environment" = "Prod" }
    }
    erc_bgp_availibility_alert_canadacentral = {
      name                     = "ERC-BGP-Availibility-Alert-canadacentral"
      resource_group_name      = "rg-hub-connectivity-canadacentral-001"
      scopes                   = ["/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/expressRouteCircuits/erc-toronto-connectivity-cacentral-001"]
      description              = "This alert get triggered when there is drop in BGP session between onprem and Azure"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 0
      target_resource_type     = "Microsoft.Network/expressRouteCircuits"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Network/expressRouteCircuits"
          metric_name            = "BgpAvailability"
          aggregation            = "Average"
          operator               = "LessThan"
          threshold              = 100.0
          skip_metric_validation = false
        },
      ]
      action_group_ids = [local.mgmt_servicenow_ag_id]
      tags             = { "CostCenterId" = "80025906", "Environment" = "Prod" }
    }
    erc_bgp_availibility_alert_canadaeast = {
      name                     = "ERC-BGP-Availibility-Alert-canadaeast"
      resource_group_name      = "rg-hub-connectivity-canadaeast-001"
      scopes                   = ["/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/expressRouteCircuits/erc-quebec-connectivity-caeast-001"]
      description              = "This alert get triggered when there is drop in BGP session between onprem and Azure-canadaeast"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 0
      target_resource_type     = "Microsoft.Network/expressRouteCircuits"
      target_resource_location = "canadaeast"
      criteria = [
        {
          metric_namespace       = "Microsoft.Network/expressRouteCircuits"
          metric_name            = "BgpAvailability"
          aggregation            = "Average"
          operator               = "LessThan"
          threshold              = 100.0
          skip_metric_validation = false
        },
      ]
      action_group_ids = [local.mgmt_servicenow_ag_id]
      tags             = { "CostCenterId" = "80025906", "Environment" = "Prod" }
    }
    erc_bitsinpersecond_alert_canadaeast = {
      name                     = "ERC-Bitsinpersecond-Alert-canadaeast"
      resource_group_name      = "rg-hub-connectivity-canadacentral-001"
      scopes                   = ["/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/expressRouteCircuits/erc-quebec-connectivity-caeast-001"]
      description              = "Alert get triggered when it Detect capacity saturation on the ExpressRoute circuit."
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 2
      target_resource_type     = "Microsoft.Network/expressRouteCircuits"
      target_resource_location = "canadaeast"
      dynamic_criteria = {
        metric_namespace  = "Microsoft.Network/expressRouteCircuits"
        metric_name       = "BitsInPerSecond"
        aggregation       = "Total"
        operator          = "GreaterOrLessThan"
        alert_sensitivity = "Low"
      }
      action_group_ids = [local.mgmt_mail_ag_id]
      tags             = { "CostCenterId" = "80025906", "Environment" = "Prod" }
    }
    erc_bitsinpersecond_alert_canadcentral = {
      name                     = "ERC-Bitsinpersecond-Alert-canadcentral"
      resource_group_name      = "rg-hub-connectivity-canadacentral-001"
      scopes                   = ["/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/expressRouteCircuits/erc-toronto-connectivity-cacentral-001"]
      description              = "Alert get triggered when it Detect capacity saturation on the ExpressRoute circuit."
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 2
      target_resource_type     = "Microsoft.Network/expressRouteCircuits"
      target_resource_location = "canadacentral"
      dynamic_criteria = {
        metric_namespace  = "Microsoft.Network/expressRouteCircuits"
        metric_name       = "BitsInPerSecond"
        aggregation       = "Total"
        operator          = "GreaterOrLessThan"
        alert_sensitivity = "Low"
      }
      action_group_ids = [local.mgmt_mail_ag_id]
      tags             = { "CostCenterId" = "80025906", "Environment" = "Prod" }
    }
    erc_bitsoutpersecond_alert_canadacentral = {
      name                     = "ERC-Bitsoutpersecond-Alert-canadacentral"
      resource_group_name      = "rg-hub-connectivity-canadacentral-001"
      scopes                   = ["/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/expressRouteCircuits/erc-toronto-connectivity-cacentral-001"]
      description              = "Alert get triggered when it Detect capacity saturation on the ExpressRoute circuit."
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 2
      target_resource_type     = "Microsoft.Network/expressRouteCircuits"
      target_resource_location = "canadacentral"
      dynamic_criteria = {
        metric_namespace  = "Microsoft.Network/expressRouteCircuits"
        metric_name       = "BitsOutPerSecond"
        aggregation       = "Total"
        operator          = "GreaterOrLessThan"
        alert_sensitivity = "Low"
      }
      action_group_ids = [local.mgmt_mail_ag_id]
      tags             = { "CostCenterId" = "80025906", "Environment" = "Prod" }
    }
    erc_bitsoutpersecond_alert_canadaeast = {
      name                     = "ERC-Bitsoutpersecond-Alert-canadaeast"
      resource_group_name      = "rg-hub-connectivity-canadacentral-001"
      scopes                   = ["/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/expressRouteCircuits/erc-quebec-connectivity-caeast-001"]
      description              = "Alert get triggered when it Detect capacity saturation on the ExpressRoute circuit."
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 2
      target_resource_type     = "Microsoft.Network/expressRouteCircuits"
      target_resource_location = "canadaeast"
      dynamic_criteria = {
        metric_namespace  = "Microsoft.Network/expressRouteCircuits"
        metric_name       = "BitsOutPerSecond"
        aggregation       = "Total"
        operator          = "GreaterOrLessThan"
        alert_sensitivity = "Low"
      }
      action_group_ids = [local.mgmt_mail_ag_id]
      tags             = { "CostCenterId" = "80025906", "Environment" = "Prod" }
    }
    firewall_snat_port_exhaution_alert_canadacentral = {
      name                     = "Firewall-SNAT-Port-Exhaution-Alert-canadacentral"
      resource_group_name      = "rg-hub-connectivity-canadacentral-001"
      scopes                   = ["/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/azureFirewalls/azfw-connectivity-canadacentral-001"]
      description              = "Alert get triggered when Azure Firewall SNAT port utilization has exceeded the safe threshold"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT15M"
      severity                 = 0
      target_resource_type     = "Microsoft.Network/azureFirewalls"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "microsoft.network/azurefirewalls"
          metric_name            = "SNATPortUtilization"
          aggregation            = "Average"
          operator               = "GreaterThan"
          threshold              = 80.0
          skip_metric_validation = false
        },
      ]
      action_group_ids = [local.mgmt_servicenow_ag_id]
      tags             = { "CostCenterId" = "80025906", "Environment" = "Prod" }
    }
    loadbalancer_health_probe_alert_canadcentral = {
      name                     = "LoadBalancer-Health-Probe-Alert-canadcentral"
      resource_group_name      = "rg-cyberark-canadacentral-001"
      scopes                   = ["/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Network/loadBalancers/lb-internal-cyberark-canadacentral-001"]
      description              = "Thsi alert is for Load Balancer health probe detects an unhealthy backend instance"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT5M"
      severity                 = 0
      target_resource_type     = "Microsoft.Network/loadBalancers"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "microsoft.network/loadbalancers"
          metric_name            = "DipAvailability"
          aggregation            = "Average"
          operator               = "LessThan"
          threshold              = 1.0
          skip_metric_validation = false
        },
      ]
      action_group_ids = [local.mgmt_servicenow_ag_id]
      tags             = { "CostCenterId" = "80025906", "Environment" = "Prod" }
    }
    nat_gw_cyberark_datapathavailibilty_alert_canadacentral = {
      name                     = "NAT-GW-Cyberark-Datapathavailibilty-alert-canadacentral"
      resource_group_name      = "rg-cyberark-canadacentral-001"
      scopes                   = ["/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Network/natGateways/ngw-cyberark-connectivity-canadacentral-001"]
      description              = "Alert for Health of NAT Gateway control and data plane."
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 1
      target_resource_type     = "Microsoft.Network/natGateways"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Network/natGateways"
          metric_name            = "DatapathAvailability"
          aggregation            = "Average"
          operator               = "LessThan"
          threshold              = 90.0
          skip_metric_validation = false
        },
      ]
      action_group_ids = [local.mgmt_servicenow_ag_id]
      tags             = { "CostCenterId" = "80025906", "Environment" = "Prod" }
    }
    nat_gw_runners_datapathavailibilty_alert_canadacentral = {
      name                     = "NAT-GW-runners-Datapathavailibilty-alert-canadacentral"
      resource_group_name      = "rg-runners-connectivity-canadacentral-001"
      scopes                   = ["/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/natGateways/ngw-runners-connectivity-canadacentral-001"]
      description              = "Alert for Health of NAT Gateway control and data plane."
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 1
      target_resource_type     = "Microsoft.Network/natGateways"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Network/natGateways"
          metric_name            = "DatapathAvailability"
          aggregation            = "Average"
          operator               = "LessThan"
          threshold              = 90.0
          skip_metric_validation = false
        },
      ]
      action_group_ids = [local.mgmt_servicenow_ag_id]
      tags             = { "CostCenterId" = "80025906", "Environment" = "Prod" }
    }
    nat_gw_shared_datapathavailibilty_alert_canadacentral = {
      name                     = "NAT-GW-shared-Datapathavailibilty-alert-canadacentral"
      resource_group_name      = "rg-shared-connectivity-canadacentral-001"
      scopes                   = ["/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-shared-connectivity-canadacentral-001/providers/Microsoft.Network/natGateways/ngw-shared-connectivity-canadacentral-001"]
      description              = "Alert for Health of NAT Gateway control and data plane."
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 1
      target_resource_type     = "Microsoft.Network/natGateways"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Network/natGateways"
          metric_name            = "DatapathAvailability"
          aggregation            = "Average"
          operator               = "LessThan"
          threshold              = 90.0
          skip_metric_validation = false
        },
      ]
      action_group_ids = [local.mgmt_servicenow_ag_id]
      tags             = { "CostCenterId" = "80025906", "Environment" = "Prod" }
    }
    restore_job_failed_connectivity_canadacentral = {
      name                     = "Restore-Job-Failed-Connectivity-canadacentral"
      resource_group_name      = "rg-dns-connectivity-canadacentral-001"
      scopes                   = ["/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourcegroups/rg-runners-connectivity-canadacentral-001"]
      description              = "Job triggers when restore job is faild"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT15M"
      severity                 = 2
      target_resource_type     = "microsoft.recoveryservices/vaults"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "microsoft.recoveryservices/vaults"
          metric_name            = "RestoreHealthEvent"
          aggregation            = "Count"
          operator               = "GreaterThan"
          threshold              = 1.0
          skip_metric_validation = false
        },
      ]
      action_group_ids = [local.mgmt_mail_ag_id]
      tags             = { "ApplicationId" = "BCH – LIX -0000001597", "ApplicationServiceLevel" = "Silver", "BusinessUnit" = "Capital Infrastructure Project Delivery", "CostCenterId" = "YT-01585.S.IMP.CLZ", "Environment" = "NonProd", "Name" = "Property Tax and Assessment" }
    }
    vm_os_disk_iops_alert_canadacentral = {
      name                     = "VM-OS-Disk-IOPS-Alert-canadacentral"
      resource_group_name      = "rg-dns-connectivity-canadacentral-001"
      scopes                   = [local.subscription_scope]
      description              = "Action will be triggered when Disk IOPS is greater"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 2
      target_resource_type     = "microsoft.compute/virtualmachines"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "microsoft.compute/virtualmachines"
          metric_name            = "OS Disk IOPS Consumed Percentage"
          aggregation            = "Average"
          operator               = "GreaterThan"
          threshold              = 80.0
          skip_metric_validation = false
        },
      ]
      action_group_ids = [local.mgmt_mail_ag_id]
      tags             = { "CostCenterId" = "80025906", "Environment" = "Prod" }
    }
    firewall_connectivity_health = {
      name                     = "firewall-connectivity-health"
      resource_group_name      = local.alerts_rg_name
      scopes                   = ["/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/azureFirewalls/azfw-connectivity-canadacentral-001"]
      description              = ""
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 0
      target_resource_type     = "Microsoft.Network/azureFirewalls"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Network/azureFirewalls"
          metric_name            = "FirewallHealth"
          aggregation            = "Average"
          operator               = "LessThan"
          threshold              = 99.0
          skip_metric_validation = false
        },
      ]
      action_group_ids = [local.mgmt_servicenow_ag_id]
      tags             = { "CostCenterId" = "80025906", "Environment" = "Prod" }
    }
    vm_connectivity_cpu_high_warning = {
      name                     = "vm-connectivity-cpu-high-warning"
      resource_group_name      = local.alerts_rg_name
      scopes                   = [local.subscription_scope]
      description              = "Action will be triggered when percentage CPU for VM is greater than 90%"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT30M"
      severity                 = 2
      target_resource_type     = "microsoft.compute/virtualmachines"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "microsoft.compute/virtualmachines"
          metric_name            = "Percentage CPU"
          aggregation            = "Average"
          operator               = "GreaterThan"
          threshold              = 90.0
          skip_metric_validation = false
        },
      ]
      action_group_ids = [local.mgmt_servicenow_ag_id]
      tags             = { "CostCenterId" = "80025906", "Environment" = "Prod" }
    }
    vm_connectivity_memory_high_warning = {
      name                     = "vm-connectivity-memory-high-warning"
      resource_group_name      = local.alerts_rg_name
      scopes                   = [local.subscription_scope]
      description              = "Action will be triggered when percentage CPU for VM is greater than 90%"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT1M"
      window_size              = "PT5M"
      severity                 = 2
      target_resource_type     = "microsoft.compute/virtualmachines"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "microsoft.compute/virtualmachines"
          metric_name            = "Available Memory Percentage"
          aggregation            = "Average"
          operator               = "LessThanOrEqual"
          threshold              = 10.0
          skip_metric_validation = false
        },
      ]
      action_group_ids = [local.mgmt_servicenow_ag_id]
      tags             = { "CostCenterId" = "80025906", "Environment" = "Prod" }
    }
  }

  # ---- Activity log alerts (6; Service-Outage stays in monitoring.tf) ----
  monitor_activity_log_alerts = {
    erc_health_status_alert_canadacentral = {
      name                = "ERC-Health-Status-Alert-canadacentral"
      resource_group_name = "rg-hub-connectivity-canadacentral-001"
      scopes              = [local.subscription_scope]
      location            = "global"
      description         = "Overall health status of ERC"
      enabled             = true
      criteria = {
        category        = "ResourceHealth"
        resource_group  = "rg-hub-connectivity-canadacentral-001"
        resource_id     = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/expressRouteCircuits/erc-toronto-connectivity-cacentral-001"
        resource_type   = "Microsoft.Network/expressRouteCircuits"
        resource_health = { current = ["Degraded", "Unavailable"] }
      }
      action_group_ids = [local.mgmt_servicenow_ag_id]
      tags             = { "CostCenterId" = "80025906", "Environment" = "Prod" }
    }
    erc_health_status_alert_canadaeast = {
      name                = "ERC-Health-Status-Alert-canadaeast"
      resource_group_name = "rg-hub-connectivity-canadacentral-001"
      scopes              = [local.subscription_scope]
      location            = "global"
      description         = "Overall health status of ERC"
      enabled             = true
      criteria = {
        category        = "ResourceHealth"
        resource_group  = "rg-hub-connectivity-canadacentral-001"
        resource_id     = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/expressRouteCircuits/erc-quebec-connectivity-caeast-001"
        resource_type   = "Microsoft.Network/expressRouteCircuits"
        resource_health = { current = ["Degraded", "Unavailable"] }
      }
      action_group_ids = [local.mgmt_servicenow_ag_id]
      tags             = { "CostCenterId" = "80025906", "Environment" = "Prod" }
    }
    vm_os_patch_available_connectivity_alert_canadacentral = {
      name                = "VM-OS-Patch-Available-Connectivity-Alert-canadacentral"
      resource_group_name = "rg-dns-connectivity-canadacentral-001"
      scopes              = ["/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourcegroups/rg-cyberark-canadacentral-001", "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourcegroups/rg-dns-connectivity-canadacentral-001", "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourcegroups/rg-ertest-canadacentral-001", "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourcegroups/rg-hub-connectivity-canadacentral-001", "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourcegroups/rg-shared-connectivity-canadacentral-001"]
      location            = "global"
      description         = "Monitor base operating system patching drift via Azure Monitor "
      enabled             = true
      criteria = {
        category       = "Administrative"
        resource_type  = "microsoft.compute/virtualmachines"
        operation_name = "Microsoft.Compute/virtualMachines/assessPatches/action"
      }
      action_group_ids = [local.mgmt_mail_ag_id]
      tags             = { "ApplicationId" = "BCH – LIX -0000001597", "ApplicationServiceLevel" = "Silver", "BusinessUnit" = "Capital Infrastructure Project Delivery", "CostCenterId" = "YT-01585.S.IMP.CLZ", "Environment" = "NonProd", "Name" = "Property Tax and Assessment" }
    }
    firewall_connectivity_update = {
      name                = "firewall-connectivity-update"
      resource_group_name = local.alerts_rg_name
      scopes              = ["/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/azureFirewalls/azfw-connectivity-canadacentral-001"]
      location            = "global"
      description         = ""
      enabled             = true
      criteria = {
        category       = "Administrative"
        operation_name = "Microsoft.Network/azurefirewalls/write"
      }
      action_group_ids = [local.mgmt_azfw_ag_id]
      tags             = { "CostCenterId" = "80025906", "Environment" = "Prod" }
    }
    vpn_connectivty_down = {
      name                = "vpn-connectivty-down"
      resource_group_name = local.alerts_rg_name
      scopes              = [local.subscription_scope]
      location            = "global"
      description         = ""
      enabled             = true
      criteria = {
        category        = "ResourceHealth"
        resource_group  = "rg-hub-connectivity-canadacentral-001"
        resource_id     = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/vpnGateways/vpn-connectivity-canadacentral-001"
        resource_type   = "Microsoft.Network/vpnGateways"
        resource_health = { current = ["Degraded", "Unavailable"] }
      }
      action_group_ids = [local.mgmt_servicenow_ag_id]
      tags             = { "CostCenterId" = "80025906", "Environment" = "Prod" }
    }
    vpn_connectivty_down_canadaeast = {
      name                = "vpn-connectivty-down-canadaeast"
      resource_group_name = local.alerts_rg_name
      scopes              = [local.subscription_scope]
      location            = "global"
      description         = ""
      enabled             = true
      criteria = {
        category        = "ResourceHealth"
        resource_group  = "rg-hub-connectivity-canadaeast-001"
        resource_id     = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadaeast-001/providers/Microsoft.Network/vpnGateways/vpn-connectivity-canadaeast-001"
        resource_type   = "Microsoft.Network/vpnGateways"
        resource_health = { current = ["Degraded", "Unavailable"] }
      }
      action_group_ids = [local.mgmt_servicenow_ag_id]
      tags             = { "CostCenterId" = "80025906", "Environment" = "Prod" }
    }
  }

  # ---- Log search alerts (16; 3 standard ones stay in monitoring.tf) ----
  monitor_log_search_alerts = {
    azureupdatemanager_update_failure = {
      name                    = "AzureUpdateManager-Update-failure"
      resource_group_name     = "AzureBackupRG_canadacentral_1"
      location                = "canadacentral"
      scopes                  = [local.subscription_scope]
      severity                = 3
      evaluation_frequency    = "PT5M"
      window_duration         = "PT5M"
      description             = "Alert rule created via quick create in AUM"
      display_name            = "AzureUpdateManager-Update-failure"
      enabled                 = false
      auto_mitigation_enabled = true
      criteria = [
        {
          query                   = "\narg('').patchinstallationresources\n| where type in~ (\"microsoft.compute/virtualmachines/patchinstallationresults\", \"microsoft.hybridcompute/machines/patchinstallationresults\") | where subscriptionId in~ (\"f3835bc1-9829-4ac8-9d7a-0999e0b29b90\")| where location in~ (\"canadacentral\")\n| where properties.status in~ (\"Failed\") // \"CompletedWithWarnings\" and other statuses can also be considered\n| where properties.lastModifiedDateTime > ago(1d)\n| parse id with vmResourceId \"/patchInstallationResults\" *\n| project vmResourceId\n| distinct vmResourceId"
          time_aggregation_method = "Count"
          threshold               = 1.0
          operator                = "GreaterThan"
          failing_periods         = { minimum_failing_periods_to_trigger_alert = 1, number_of_evaluation_periods = 1 }
        },
      ]
      action_group_ids = ["/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/AzureBackupRG_canadacentral_1/providers/microsoft.insights/actionGroups/ActionGroup_20260318T202530133Z"]
      tags             = { "CostCenterId" = "80025906", "Environment" = "Prod", "UsedByAzureUpdateManager" = "UsedByAzureUpdateManager" }
    }
    azureupdatemanager_updatecompletionalert = {
      name                    = "AzureupdateManager-UpdateCompletionAlert"
      resource_group_name     = "AzureBackupRG_canadacentral_1"
      location                = "canadacentral"
      scopes                  = [local.subscription_scope]
      severity                = 3
      evaluation_frequency    = "PT5M"
      window_duration         = "PT5M"
      description             = "Alert rule created via quick create in AUM"
      display_name            = "AzureupdateManager-UpdateCompletionAlert"
      enabled                 = false
      auto_mitigation_enabled = true
      criteria = [
        {
          query                   = "arg(\"\").patchinstallationresources\n| where type !has \"softwarepatches\"\n| extend status = tostring(parse_json(properties).status)\n| where status == \"Succeeded\"\n| where todatetime(parse_json(properties).lastModifiedDateTime) > ago(1h)\n| summarize count()"
          time_aggregation_method = "Count"
          threshold               = 1.0
          operator                = "GreaterThan"
          failing_periods         = { minimum_failing_periods_to_trigger_alert = 1, number_of_evaluation_periods = 1 }
        },
      ]
      action_group_ids = ["/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/AzureBackupRG_canadacentral_1/providers/microsoft.insights/actionGroups/ActionGroup_20260318T193824067Z", "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/AzureBackupRG_canadacentral_1/providers/microsoft.insights/actionGroups/ActionGroup_20260318T202530133Z"]
      tags             = { "CostCenterId" = "80025906", "Environment" = "Prod", "UsedByAzureUpdateManager" = "UsedByAzureUpdateManager" }
    }
    azureupdatemanager_updatecompletionalert_fit_prod = {
      name                    = "AzureupdateManager-UpdateCompletionAlert - FIT-Prod"
      resource_group_name     = "AzureBackupRG_canadacentral_1"
      location                = "canadacentral"
      scopes                  = [local.subscription_scope]
      severity                = 3
      evaluation_frequency    = "PT5M"
      window_duration         = "PT5M"
      description             = "Alert rule created via quick create in AUM"
      display_name            = "AzureupdateManager-UpdateCompletionAlert - FIT-Prod"
      enabled                 = false
      auto_mitigation_enabled = false
      criteria = [
        {
          query                   = "arg(\"\").patchinstallationresources\n| where type !has \"softwarepatches\"\n| extend status = tostring(parse_json(properties).status)\n| where status == \"Succeeded\"\n| where todatetime(parse_json(properties).lastModifiedDateTime) > ago(1h)\n| summarize count()"
          time_aggregation_method = "Count"
          threshold               = 1.0
          operator                = "GreaterThan"
          failing_periods         = { minimum_failing_periods_to_trigger_alert = 1, number_of_evaluation_periods = 1 }
        },
      ]
      action_group_ids = ["/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/AzureBackupRG_canadacentral_1/providers/microsoft.insights/actionGroups/ActionGroup_20260318T193824067Z"]
      tags             = { "CostCenterId" = "80025906", "Environment" = "Prod", "UsedByAzureUpdateManager" = "UsedByAzureUpdateManager" }
    }
    vm_backup_failure_alert_canadacentral = {
      name                    = "VM-Backup-Failure-Alert-canadacentral"
      resource_group_name     = "rg-dns-connectivity-canadacentral-001"
      location                = "canadacentral"
      scopes                  = [local.subscription_scope]
      severity                = 1
      evaluation_frequency    = "PT10M"
      window_duration         = "PT30M"
      description             = "Alert triggered when there is a VM Backup failure"
      display_name            = "VM-Backup-Failure-Alert-canadacentral"
      enabled                 = true
      auto_mitigation_enabled = false
      target_resource_types   = ["microsoft.compute/virtualmachines"]
      criteria = [
        {
          query                   = "        AzureDiagnostics\n| where Category == \"AzureBackupReport\"\n| where OperationName == \"Job\"\n| where ResultType != \"Success\"\n\n"
          time_aggregation_method = "Count"
          threshold               = 1.0
          operator                = "GreaterThanOrEqual"
          resource_id_column      = "_ResourceId"
          failing_periods         = { minimum_failing_periods_to_trigger_alert = 1, number_of_evaluation_periods = 1 }
        },
      ]
      action_group_ids = [local.mgmt_servicenow_ag_id]
      tags             = { "CostCenterId" = "80025906", "Environment" = "Prod" }
    }
    vm_free_disk_space_alert_canadcentral_rg_cyberark_canadacentral_001 = {
      name                    = "VM-Free-Disk-Space-Alert-canadcentral"
      resource_group_name     = "rg-cyberark-canadacentral-001"
      location                = "canadacentral"
      scopes                  = ["/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-cyberark-server-canadacentral-001"]
      severity                = 2
      evaluation_frequency    = "PT5M"
      window_duration         = "PT5M"
      description             = "Triggered when disk space has consumed >85%"
      display_name            = "VM-Free-Disk-Space-Alert-canadcentral"
      enabled                 = true
      auto_mitigation_enabled = false
      target_resource_types   = ["Microsoft.Compute/virtualMachines"]
      criteria = [
        {
          query                   = "Perf\n| where TimeGenerated > ago(15m)\n| where ObjectName in (\"LogicalDisk\", \"Logical Disk\")\n| where CounterName == \"% Free Space\"\n| where InstanceName == \"_Total\"\n| summarize \n    FreePercent = avg(CounterValue),\n    TimeGenerated = max(TimeGenerated)\n  by Computer\n| extend UsedPercent = round(100 - FreePercent, 2)\n| where UsedPercent >= 85\n| project TimeGenerated, Computer, UsedPercent\n"
          time_aggregation_method = "Count"
          threshold               = 1.0
          operator                = "GreaterThan"
          failing_periods         = { minimum_failing_periods_to_trigger_alert = 1, number_of_evaluation_periods = 1 }
        },
      ]
      action_group_ids = [local.mgmt_servicenow_ag_id]
      tags             = { "CostCenterId" = "80025906", "Environment" = "Prod" }
    }
    vm_free_disk_space_alert_canadcentral_rg_dns_connectivity_canadacentral_001 = {
      name                    = "VM-Free-Disk-Space-Alert-canadcentral"
      resource_group_name     = "rg-dns-connectivity-canadacentral-001"
      location                = "canadacentral"
      scopes                  = ["/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-cyberark-server-canadacentral-002"]
      severity                = 2
      evaluation_frequency    = "PT5M"
      window_duration         = "PT5M"
      description             = "Triggered when disk space has consumed >85%"
      display_name            = "VM-Free-Disk-Space-Alert-canadcentral"
      enabled                 = true
      auto_mitigation_enabled = false
      target_resource_types   = ["Microsoft.Compute/virtualMachines"]
      criteria = [
        {
          query                   = "Perf\n| where TimeGenerated > ago(15m)\n| where ObjectName in (\"LogicalDisk\", \"Logical Disk\")\n| where CounterName == \"% Free Space\"\n| where InstanceName == \"_Total\"\n| summarize \n    FreePercent = avg(CounterValue),\n    TimeGenerated = max(TimeGenerated)\n  by Computer\n| extend UsedPercent = round(100 - FreePercent, 2)\n| where UsedPercent >= 85\n| project TimeGenerated, Computer, UsedPercent\n"
          time_aggregation_method = "Count"
          threshold               = 1.0
          operator                = "GreaterThan"
          failing_periods         = { minimum_failing_periods_to_trigger_alert = 1, number_of_evaluation_periods = 1 }
        },
      ]
      action_group_ids = [local.mgmt_servicenow_ag_id]
      tags             = { "CostCenterId" = "80025906", "Environment" = "Prod" }
    }
    vm_free_disk_space_connectivity_alert_canadacentral = {
      name                    = "VM-Free-Disk-Space-Connectivity-Alert-canadacentral"
      resource_group_name     = "rg-ertest-canadacentral-001"
      location                = "canadaeast"
      scopes                  = ["/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-ertest-canadaeast-001/providers/Microsoft.Compute/virtualMachines/vm-ertest-canadaeast-001"]
      severity                = 2
      evaluation_frequency    = "PT5M"
      window_duration         = "PT5M"
      description             = "Triggered when disk space has consumed >85%"
      display_name            = "VM-Free-Disk-Space-Connectivity-Alert-canadacentral"
      enabled                 = true
      auto_mitigation_enabled = false
      target_resource_types   = ["Microsoft.Compute/virtualMachines"]
      criteria = [
        {
          query                   = "Perf\r\n| where TimeGenerated > ago(15m)\r\n| where ObjectName in (\"LogicalDisk\", \"Logical Disk\")\r\n| where CounterName == \"% Free Space\"\r\n| where InstanceName == \"_Total\"\r\n| summarize \r\n    FreePercent = avg(CounterValue),\r\n    TimeGenerated = max(TimeGenerated)\r\n  by Computer\r\n| extend UsedPercent = round(100 - FreePercent, 2)\r\n| where UsedPercent >= 85\r\n| project TimeGenerated, Computer, UsedPercent\r\n"
          time_aggregation_method = "Count"
          threshold               = 1.0
          operator                = "GreaterThan"
          failing_periods         = { minimum_failing_periods_to_trigger_alert = 1, number_of_evaluation_periods = 1 }
        },
      ]
      action_group_ids = [local.mgmt_servicenow_ag_id]
      tags             = { "CostCenterId" = "80025906", "Environment" = "Prod" }
    }
    vm_free_disk_space_dns_alert_canadcentral = {
      name                    = "VM-Free-Disk-Space-DNS-Alert-canadcentral"
      resource_group_name     = "rg-dns-connectivity-canadacentral-001"
      location                = "canadacentral"
      scopes                  = ["/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-ping-connectivity-canadacentral-001"]
      severity                = 2
      evaluation_frequency    = "PT5M"
      window_duration         = "PT5M"
      description             = "Triggered when disk space has consumed >90%"
      display_name            = "VM-Free-Disk-Space-DNS-Alert-canadcentral"
      enabled                 = false
      auto_mitigation_enabled = false
      target_resource_types   = ["Microsoft.Compute/virtualMachines"]
      criteria = [
        {
          query                   = "Perf\n| where ObjectName in (\"LogicalDisk\", \"Logical Disk\")\n| where CounterName in (\"Free Megabytes\", \"Total Megabytes\")\n| summarize \n    FreeMB = maxif(CounterValue, CounterName == \"Free Megabytes\"),\n    TotalMB = maxif(CounterValue, CounterName == \"Total Megabytes\"),\n    TimeGenerated = max(TimeGenerated)\n  by Computer, InstanceName\n| extend UsedPercent = round(((TotalMB - FreeMB) / TotalMB) * 100, 2)\n| where UsedPercent >= 90\n| project TimeGenerated, Computer, InstanceName, FreeMB, TotalMB, UsedPercent\n"
          time_aggregation_method = "Count"
          threshold               = 1.0
          operator                = "GreaterThan"
          failing_periods         = { minimum_failing_periods_to_trigger_alert = 1, number_of_evaluation_periods = 1 }
        },
      ]
      action_group_ids = [local.mgmt_servicenow_ag_id]
      tags             = { "CostCenterId" = "80025906", "Environment" = "Prod" }
    }
    vm_free_disk_space_runners_alert_canadacentral = {
      name                    = "VM-Free-Disk-Space-Runners-Alert-canadacentral"
      resource_group_name     = "rg-runners-connectivity-canadacentral-001"
      location                = "canadacentral"
      scopes                  = ["/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourcegroups/rg-runners-connectivity-canadacentral-001"]
      severity                = 2
      evaluation_frequency    = "PT5M"
      window_duration         = "PT5M"
      description             = "Triggered when disk space has consumed >85%"
      display_name            = "VM-Free-Disk-Space-Runners-Alert-canadacentral"
      enabled                 = true
      auto_mitigation_enabled = false
      target_resource_types   = ["microsoft.compute/virtualmachines"]
      criteria = [
        {
          query                   = "Perf\n| where TimeGenerated > ago(15m)\n| where ObjectName in (\"LogicalDisk\", \"Logical Disk\")\n| where CounterName == \"% Free Space\"\n| where InstanceName == \"_Total\"\n| summarize \n    FreePercent = avg(CounterValue),\n    TimeGenerated = max(TimeGenerated)\n  by Computer\n| extend UsedPercent = round(100 - FreePercent, 2)\n| where UsedPercent >= 85\n| project TimeGenerated, Computer, UsedPercent\n"
          time_aggregation_method = "Count"
          threshold               = 1.0
          operator                = "GreaterThan"
          failing_periods         = { minimum_failing_periods_to_trigger_alert = 1, number_of_evaluation_periods = 1 }
        },
      ]
      action_group_ids = [local.mgmt_servicenow_ag_id]
      tags             = { "CostCenterId" = "80025906", "Environment" = "Prod" }
    }
    vm_heartbeat_lost_alert_canadcentral = {
      name                    = "VM-Heartbeat-Lost-Alert-canadcentral"
      resource_group_name     = "rg-dns-connectivity-canadacentral-001"
      location                = "canadacentral"
      scopes                  = [local.subscription_scope]
      severity                = 0
      evaluation_frequency    = "PT5M"
      window_duration         = "PT5M"
      description             = "This alert will be triggered when VM state is unhealthy for more than 5min"
      display_name            = "VM-Heartbeat-Lost-Alert-canadcentral"
      enabled                 = true
      auto_mitigation_enabled = false
      target_resource_types   = ["microsoft.compute/virtualmachines"]
      criteria = [
        {
          query                   = "Heartbeat\n| where TimeGenerated > ago(1d)\n| summarize LastHeartbeat = max(TimeGenerated) by _ResourceId, Computer\n| extend TimeSinceLastHeartbeatSeconds = (now() - LastHeartbeat) / 1s\n| extend AgentState = iff(TimeSinceLastHeartbeatSeconds < 300, \"Healthy\", \"Unhealthy\")\n| where AgentState == \"Unhealthy\"\n| project _ResourceId, Computer, LastHeartbeat, TimeSinceLastHeartbeatSeconds, AgentState\n"
          time_aggregation_method = "Count"
          threshold               = 0.0
          operator                = "GreaterThan"
          resource_id_column      = "_ResourceId"
          failing_periods         = { minimum_failing_periods_to_trigger_alert = 1, number_of_evaluation_periods = 1 }
        },
      ]
      action_group_ids = [local.mgmt_servicenow_ag_id]
      tags             = { "CostCenterId" = "80025906", "Environment" = "Prod" }
    }
    vm_linux_syslog_connectivity_alert_canadacentral = {
      name                    = "VM-Linux-Syslog-Connectivity-Alert-canadacentral"
      resource_group_name     = "rg-dns-connectivity-canadacentral-001"
      location                = "canadacentral"
      scopes                  = [local.subscription_scope]
      severity                = 3
      evaluation_frequency    = "PT10M"
      window_duration         = "PT30M"
      description             = "Alert generated when syslog err occurs"
      display_name            = "VM-Linux-Syslog-Connectivity-Alert-canadacentral"
      enabled                 = false
      auto_mitigation_enabled = false
      target_resource_types   = ["microsoft.compute/virtualmachines"]
      criteria = [
        {
          query                   = "Syslog\n| where SeverityLevel == \"err\"\n"
          time_aggregation_method = "Count"
          threshold               = 1.0
          operator                = "GreaterThan"
          resource_id_column      = "_ResourceId"
          failing_periods         = { minimum_failing_periods_to_trigger_alert = 1, number_of_evaluation_periods = 1 }
        },
      ]
      action_group_ids = [local.mgmt_servicenow_ag_id]
      tags             = { "CostCenterId" = "80025906", "Environment" = "Prod" }
    }
    vm_patching_failed_connectivity = {
      name                    = "VM-Patching-Failed-Connectivity"
      resource_group_name     = "rg-cyberark-canadacentral-001"
      location                = "canadacentral"
      scopes                  = [local.subscription_scope]
      severity                = 3
      evaluation_frequency    = "PT10M"
      window_duration         = "PT10M"
      description             = "Alert rule created via quick create in AUM"
      display_name            = "VM-Patching-Failed-Connectivity"
      enabled                 = false
      auto_mitigation_enabled = false
      criteria = [
        {
          query                   = "\narg('').patchinstallationresources\n| where type in~ (\"microsoft.compute/virtualmachines/patchinstallationresults\", \"microsoft.hybridcompute/machines/patchinstallationresults\") | where subscriptionId in~ (\"f3835bc1-9829-4ac8-9d7a-0999e0b29b90\")| where location in~ (\"canadacentral\")\n| where properties.status in~ (\"Failed\") // \"CompletedWithWarnings\" and other statuses can also be considered\n| where properties.lastModifiedDateTime > ago(1d)\n| parse id with vmResourceId \"/patchInstallationResults\" *\n| project vmResourceId\n| distinct vmResourceId"
          time_aggregation_method = "Count"
          threshold               = 1.0
          operator                = "GreaterThan"
          failing_periods         = { minimum_failing_periods_to_trigger_alert = 1, number_of_evaluation_periods = 1 }
        },
      ]
      action_group_ids = [local.mgmt_servicenow_ag_id]
      tags             = { "CostCenterId" = "80025906", "Environment" = "Prod", "UsedByAzureUpdateManager" = "UsedByAzureUpdateManager" }
    }
    vm_patching_failed_runners_canadacentral = {
      name                    = "VM-Patching-Failed-Runners-canadacentral"
      resource_group_name     = "rg-runners-connectivity-canadacentral-001"
      location                = "canadacentral"
      scopes                  = [local.subscription_scope]
      severity                = 3
      evaluation_frequency    = "PT15M"
      window_duration         = "PT15M"
      description             = "Alert rule created via quick create in AUM"
      display_name            = "VM-Patching-Failed-Runners-canadacentral"
      enabled                 = false
      auto_mitigation_enabled = false
      criteria = [
        {
          query                   = "\narg('').patchinstallationresources\n| where type in~ (\"microsoft.compute/virtualmachines/patchinstallationresults\", \"microsoft.hybridcompute/machines/patchinstallationresults\") | where subscriptionId in~ (\"fa089a5b-f881-41a6-a30f-58bfdfd52abd\")| where location in~ (\"canadacentral\")\n| where properties.status in~ (\"Failed\") // \"CompletedWithWarnings\" and other statuses can also be considered\n| where properties.lastModifiedDateTime > ago(1d)\n| parse id with vmResourceId \"/patchInstallationResults\" *\n| project vmResourceId\n| distinct vmResourceId"
          time_aggregation_method = "Count"
          threshold               = 1.0
          operator                = "GreaterThan"
          failing_periods         = { minimum_failing_periods_to_trigger_alert = 1, number_of_evaluation_periods = 1 }
        },
      ]
      action_group_ids = [local.mgmt_servicenow_ag_id]
      tags             = { "CostCenterId" = "80025906", "Environment" = "Prod", "UsedByAzureUpdateManager" = "UsedByAzureUpdateManager" }
    }
    vm_pending_update_connectivity_canadacentral = {
      name                    = "VM-Pending-Update-Connectivity-canadacentral"
      resource_group_name     = "rg-cyberark-canadacentral-001"
      location                = "canadacentral"
      scopes                  = [local.subscription_scope]
      severity                = 3
      evaluation_frequency    = "PT15M"
      window_duration         = "PT15M"
      description             = "Alert rule created via quick create in AUM"
      display_name            = "VM-Pending-Update-Connectivity-canadacentral"
      enabled                 = false
      auto_mitigation_enabled = false
      criteria = [
        {
          query                   = "\narg('').patchassessmentresources\n| where properties.status =~ 'Succeeded' | where subscriptionId in~ (\"f3835bc1-9829-4ac8-9d7a-0999e0b29b90\")| where location in~ (\"canadacentral\")\n| extend pendingUpdateCount = toint(properties.availablePatchCountByClassification.updates) \n| where pendingUpdateCount > 0\n| extend vmResourceId = tostring(split(id, \"/patchAssessmentResults/\")[0])\n| project vmResourceId"
          time_aggregation_method = "Count"
          threshold               = 1.0
          operator                = "GreaterThan"
          failing_periods         = { minimum_failing_periods_to_trigger_alert = 1, number_of_evaluation_periods = 1 }
        },
      ]
      action_group_ids = [local.mgmt_servicenow_ag_id]
      tags             = { "CostCenterId" = "80025906", "Environment" = "Prod", "UsedByAzureUpdateManager" = "UsedByAzureUpdateManager" }
    }
    vm_pending_update_runners_canadacentral = {
      name                    = "VM-Pending-Update-Runners-canadacentral"
      resource_group_name     = "rg-runners-connectivity-canadacentral-001"
      location                = "canadacentral"
      scopes                  = [local.subscription_scope]
      severity                = 3
      evaluation_frequency    = "PT15M"
      window_duration         = "PT15M"
      description             = "Alert rule created via quick create in AUM"
      display_name            = "VM-Pending-Update-Runners-canadacentral"
      enabled                 = false
      auto_mitigation_enabled = false
      criteria = [
        {
          query                   = "\narg('').patchassessmentresources\n| where properties.status =~ 'Succeeded' | where subscriptionId in~ (\"f3835bc1-9829-4ac8-9d7a-0999e0b29b90\")| where location in~ (\"canadacentral\")\n| extend pendingUpdateCount = toint(properties.availablePatchCountByClassification.updates) \n| where pendingUpdateCount > 0\n| extend vmResourceId = tostring(split(id, \"/patchAssessmentResults/\")[0])\n| project vmResourceId"
          time_aggregation_method = "Count"
          threshold               = 1.0
          operator                = "GreaterThan"
          failing_periods         = { minimum_failing_periods_to_trigger_alert = 1, number_of_evaluation_periods = 1 }
        },
      ]
      action_group_ids = [local.mgmt_servicenow_ag_id]
      tags             = { "CostCenterId" = "80025906", "Environment" = "Prod", "UsedByAzureUpdateManager" = "UsedByAzureUpdateManager" }
    }
    vm_windows_service_stopped_connectivity_canadacentral = {
      name                    = "VM-Windows-Service-Stopped-Connectivity-canadacentral"
      resource_group_name     = "rg-dns-connectivity-canadacentral-001"
      location                = "canadacentral"
      scopes                  = [local.subscription_scope]
      severity                = 1
      evaluation_frequency    = "PT5M"
      window_duration         = "PT5M"
      description             = "Triggered when windows services are stopped"
      display_name            = "VM-Windows-Service-Stopped-Connectivity-canadacentral"
      enabled                 = true
      auto_mitigation_enabled = false
      target_resource_types   = ["microsoft.compute/virtualmachines"]
      criteria = [
        {
          query                   = "Perf\n| where ObjectName == \"Service\"\n| where CounterName == \"Service State\"\n| extend ServiceState = iff(CounterValue == 4, \"Running\", \"Stopped\")\n| where ServiceState == \"Stopped\"\n//| extend _ResourceId = strcat(\"/subscriptions/<SUB-ID>/resourceGroups/<RG-NAME>/providers/Microsoft.Compute/virtualMachines/\", Computer)\n| project TimeGenerated, Computer, InstanceName, ServiceState, _ResourceId\n"
          time_aggregation_method = "Count"
          threshold               = 1.0
          operator                = "GreaterThan"
          failing_periods         = { minimum_failing_periods_to_trigger_alert = 1, number_of_evaluation_periods = 1 }
        },
      ]
      action_group_ids = [local.mgmt_servicenow_ag_id]
      tags             = { "CostCenterId" = "80025906", "Environment" = "Prod" }
    }
  }

  # ---- Action groups (2, created by Azure Backup in AzureBackupRG) ----
  monitor_action_groups = {
    actiongroup_20260318t193824067z = {
      name                = "ActionGroup_20260318T193824067Z"
      resource_group_name = "AzureBackupRG_canadacentral_1"
      short_name          = "AUMAlert493"
      enabled             = true
      email_receivers = {
        "Email0_-EmailAction-" = { email_address = "ticda_tids_managedazure@telusinternational.com", use_common_alert_schema = true }
      }
      tags = { "CostCenterId" = "80025906", "Environment" = "Prod" }
    }
    actiongroup_20260318t202530133z = {
      name                = "ActionGroup_20260318T202530133Z"
      resource_group_name = "AzureBackupRG_canadacentral_1"
      short_name          = "AUMAlert742"
      enabled             = true
      email_receivers = {
        "Email1_-EmailAction-" = { email_address = "ticda_tids_managedazure@telusinternational.com", use_common_alert_schema = true }
        "email2_-EmailAction-" = { email_address = "MSPAMSupport@bchydro.com", use_common_alert_schema = false }
      }
      tags = { "CostCenterId" = "80025906", "Environment" = "Prod" }
    }
  }

  # ---- Alert processing rules (7) ----
  monitor_alert_processing_rules = {
    alert_suppression_for_vpn_canadacentral = {
      name                = "Alert suppression for VPN Canadacentral"
      resource_group_name = "rg-hub-connectivity-canadacentral-001"
      scopes              = [local.subscription_scope]
      enabled             = false
      description         = null
      schedule            = { effective_from = "2026-05-12T10:00:00", effective_until = "2026-05-12T17:30:00", time_zone = "Eastern Standard Time" }
    }
    alert_suppression_on_vpn_connectivity = {
      name                = "Alert suppression on VPN connectivity"
      resource_group_name = local.alerts_rg_name
      scopes              = [local.subscription_scope]
      enabled             = false
      description         = null
      schedule            = { effective_from = "2026-05-12T10:00:00", effective_until = "2026-05-12T17:30:00", time_zone = "Eastern Standard Time" }
    }
    alert_suppression_for_expressroutecircuit = {
      name                = "Alert-Suppression for ExpressRouteCircuit"
      resource_group_name = "rg-hub-connectivity-canadacentral-001"
      scopes              = ["/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001"]
      enabled             = false
      description         = null
      conditions = {
        alert_rule_name = { operator = "Equals", values = ["ERC-BGP-Availibility-Alert-canadaeast", "ERC-BGP-Availibility-Alert-canadacentral", "ERC-ARP-Availibility-Alert-canadacentral", "ERC-Health-Status-Alert-canadaeast", "ERC-Health-Status-Alert-canadacentral"] }
      }
      schedule = { effective_from = "2026-06-04T10:00:00", effective_until = "2026-06-04T14:00:00", time_zone = "Eastern Standard Time" }
    }
    alert_suppression_for_vpn_canadaeast = {
      name                = "alert suppression for VPN Canadaeast"
      resource_group_name = "rg-hub-connectivity-canadaeast-001"
      scopes              = [local.subscription_scope]
      enabled             = false
      description         = null
      schedule            = { effective_from = "2026-05-12T00:00:00", effective_until = "2026-05-12T17:30:00", time_zone = "Eastern Standard Time" }
    }
    alert_suppression_cyberarkvm = {
      name                = "alert-suppression-cyberarkvm"
      resource_group_name = "rg-cyberark-canadacentral-001"
      scopes              = ["/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-cyberark-test-vm-canadacentral-001", "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-cyberark-test-vm01-canadacentral-001", "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-ertest-canadacentral-001", "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-ertest-canadacentral-002", "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-ertest-canadacentral-003", "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-ertest-canadacentral-004", "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/RG-ERTEST-CANADACENTRAL-001/providers/Microsoft.Compute/virtualMachines/VM-ERTEST-CANADACENTRAL-005", "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-ertest-canadaeast-001/providers/Microsoft.Compute/virtualMachines/vm-ertest-canadaeast-001", "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-cistest-canadacentral001"]
      enabled             = true
      description         = null
    }
    supppress_heartbeat_alert = {
      name                = "supppress-heartbeat-alert"
      resource_group_name = "rg-ertest-canadacentral-001"
      scopes              = ["/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-cistest-canadacentral001", "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-pptest-canadacentral-001"]
      enabled             = true
      description         = null
    }
    suppress_backup_alerts = {
      name                = "suppress-backup-alerts"
      resource_group_name = local.alerts_rg_name
      scopes              = [local.subscription_scope]
      enabled             = false
      description         = null
      conditions = {
        monitor_condition = { operator = "Equals", values = ["Fired", "Resolved"] }
        alert_rule_name   = { operator = "Equals", values = ["Backup Alerts"] }
      }
      schedule = { effective_from = "2026-04-22T12:00:00", effective_until = "2026-04-22T14:00:00", time_zone = "Pacific Standard Time" }
    }
  }
}

module "monitor_alerts" {
  count = var.enable_conn_alerts ? 1 : 0

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-monitor-alerts/azurerm"
  version = "0.1.0"

  action_groups       = local.monitor_action_groups
  metric_alerts       = local.monitor_metric_alerts
  activity_log_alerts = local.monitor_activity_log_alerts
  log_search_alerts   = local.monitor_log_search_alerts

  tags = local.common_tags
}
