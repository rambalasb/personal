# imports_conn_alerts.tf — the alerts tier via tf-wrapper-avm-monitor-alerts.
# Alert processing rules are native; the wrapper does not model them.
# Confirm the module-internal addresses on the first plan.

# ── metricAlerts (19)
import {
  to = module.monitor_alerts[0].azurerm_monitor_metric_alert.this["backup_alerts"]
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Insights/metricAlerts/Backup Alerts"
}

import {
  to = module.monitor_alerts[0].azurerm_monitor_metric_alert.this["erc_arp_availibility_alert_canadacentral"]
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Insights/metricAlerts/ERC-ARP-Availibility-Alert-canadacentral"
}

import {
  to = module.monitor_alerts[0].azurerm_monitor_metric_alert.this["erc_arp_availibility_alert_canadaeast"]
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Insights/metricAlerts/ERC-ARP-Availibility-Alert-canadaeast"
}

import {
  to = module.monitor_alerts[0].azurerm_monitor_metric_alert.this["erc_bgp_availibility_alert_canadacentral"]
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Insights/metricAlerts/ERC-BGP-Availibility-Alert-canadacentral"
}

import {
  to = module.monitor_alerts[0].azurerm_monitor_metric_alert.this["erc_bgp_availibility_alert_canadaeast"]
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadaeast-001/providers/Microsoft.Insights/metricAlerts/ERC-BGP-Availibility-Alert-canadaeast"
}

import {
  to = module.monitor_alerts[0].azurerm_monitor_metric_alert.this["erc_bitsinpersecond_alert_canadaeast"]
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Insights/metricAlerts/ERC-Bitsinpersecond-Alert-canadaeast"
}

import {
  to = module.monitor_alerts[0].azurerm_monitor_metric_alert.this["erc_bitsinpersecond_alert_canadcentral"]
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Insights/metricAlerts/ERC-Bitsinpersecond-Alert-canadcentral"
}

import {
  to = module.monitor_alerts[0].azurerm_monitor_metric_alert.this["erc_bitsoutpersecond_alert_canadacentral"]
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Insights/metricAlerts/ERC-Bitsoutpersecond-Alert-canadacentral"
}

import {
  to = module.monitor_alerts[0].azurerm_monitor_metric_alert.this["erc_bitsoutpersecond_alert_canadaeast"]
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Insights/metricAlerts/ERC-Bitsoutpersecond-Alert-canadaeast"
}

import {
  to = module.monitor_alerts[0].azurerm_monitor_metric_alert.this["firewall_snat_port_exhaution_alert_canadacentral"]
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Insights/metricAlerts/Firewall-SNAT-Port-Exhaution-Alert-canadacentral"
}

import {
  to = module.monitor_alerts[0].azurerm_monitor_metric_alert.this["loadbalancer_health_probe_alert_canadcentral"]
  id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Insights/metricAlerts/LoadBalancer-Health-Probe-Alert-canadcentral"
}

import {
  to = module.monitor_alerts[0].azurerm_monitor_metric_alert.this["nat_gw_cyberark_datapathavailibilty_alert_canadacentral"]
  id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Insights/metricAlerts/NAT-GW-Cyberark-Datapathavailibilty-alert-canadacentral"
}

import {
  to = module.monitor_alerts[0].azurerm_monitor_metric_alert.this["nat_gw_runners_datapathavailibilty_alert_canadacentral"]
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Insights/metricAlerts/NAT-GW-runners-Datapathavailibilty-alert-canadacentral"
}

import {
  to = module.monitor_alerts[0].azurerm_monitor_metric_alert.this["nat_gw_shared_datapathavailibilty_alert_canadacentral"]
  id = "${local.sub}/resourceGroups/rg-shared-connectivity-canadacentral-001/providers/Microsoft.Insights/metricAlerts/NAT-GW-shared-Datapathavailibilty-alert-canadacentral"
}

import {
  to = module.monitor_alerts[0].azurerm_monitor_metric_alert.this["restore_job_failed_connectivity_canadacentral"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Insights/metricAlerts/Restore-Job-Failed-Connectivity-canadacentral"
}

import {
  to = module.monitor_alerts[0].azurerm_monitor_metric_alert.this["vm_os_disk_iops_alert_canadacentral"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Insights/metricAlerts/VM-OS-Disk-IOPS-Alert-canadacentral"
}

import {
  to = module.monitor_alerts[0].azurerm_monitor_metric_alert.this["firewall_connectivity_health"]
  id = "${local.sub}/resourceGroups/rg-alerts-connectivity-canadacentral-001/providers/Microsoft.Insights/metricAlerts/firewall-connectivity-health"
}

import {
  to = module.monitor_alerts[0].azurerm_monitor_metric_alert.this["vm_connectivity_cpu_high_warning"]
  id = "${local.sub}/resourceGroups/rg-alerts-connectivity-canadacentral-001/providers/Microsoft.Insights/metricAlerts/vm-connectivity-cpu-high-warning"
}

import {
  to = module.monitor_alerts[0].azurerm_monitor_metric_alert.this["vm_connectivity_memory_high_warning"]
  id = "${local.sub}/resourceGroups/rg-alerts-connectivity-canadacentral-001/providers/Microsoft.Insights/metricAlerts/vm-connectivity-memory-high-warning"
}


# ── activityLogAlerts (6)
import {
  to = module.monitor_alerts[0].azurerm_monitor_activity_log_alert.this["erc_health_status_alert_canadacentral"]
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/ERC-Health-Status-Alert-canadacentral"
}

import {
  to = module.monitor_alerts[0].azurerm_monitor_activity_log_alert.this["erc_health_status_alert_canadaeast"]
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/ERC-Health-Status-Alert-canadaeast"
}

import {
  to = module.monitor_alerts[0].azurerm_monitor_activity_log_alert.this["vm_os_patch_available_connectivity_alert_canadacentral"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/VM-OS-Patch-Available-Connectivity-Alert-canadacentral"
}

import {
  to = module.monitor_alerts[0].azurerm_monitor_activity_log_alert.this["firewall_connectivity_update"]
  id = "${local.sub}/resourceGroups/rg-alerts-connectivity-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/firewall-connectivity-update"
}

import {
  to = module.monitor_alerts[0].azurerm_monitor_activity_log_alert.this["vpn_connectivty_down"]
  id = "${local.sub}/resourceGroups/rg-alerts-connectivity-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/vpn-connectivty-down"
}

import {
  to = module.monitor_alerts[0].azurerm_monitor_activity_log_alert.this["vpn_connectivty_down_canadaeast"]
  id = "${local.sub}/resourceGroups/rg-alerts-connectivity-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/vpn-connectivty-down-canadaeast"
}


# ── scheduledQueryRules (16)
import {
  to = module.monitor_alerts[0].azurerm_monitor_scheduled_query_rules_alert_v2.this["azureupdatemanager_update_failure"]
  id = "${local.sub}/resourceGroups/AzureBackupRG_canadacentral_1/providers/Microsoft.Insights/scheduledQueryRules/AzureUpdateManager-Update-failure"
}

import {
  to = module.monitor_alerts[0].azurerm_monitor_scheduled_query_rules_alert_v2.this["azureupdatemanager_updatecompletionalert"]
  id = "${local.sub}/resourceGroups/AzureBackupRG_canadacentral_1/providers/Microsoft.Insights/scheduledQueryRules/AzureupdateManager-UpdateCompletionAlert"
}

import {
  to = module.monitor_alerts[0].azurerm_monitor_scheduled_query_rules_alert_v2.this["azureupdatemanager_updatecompletionalert_fit_prod"]
  id = "${local.sub}/resourceGroups/AzureBackupRG_canadacentral_1/providers/Microsoft.Insights/scheduledQueryRules/AzureupdateManager-UpdateCompletionAlert - FIT-Prod"
}

import {
  to = module.monitor_alerts[0].azurerm_monitor_scheduled_query_rules_alert_v2.this["vm_backup_failure_alert_canadacentral"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/VM-Backup-Failure-Alert-canadacentral"
}

import {
  to = module.monitor_alerts[0].azurerm_monitor_scheduled_query_rules_alert_v2.this["vm_free_disk_space_alert_canadcentral_rg_cyberark_canadacentral_001"]
  id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/VM-Free-Disk-Space-Alert-canadcentral"
}

import {
  to = module.monitor_alerts[0].azurerm_monitor_scheduled_query_rules_alert_v2.this["vm_free_disk_space_alert_canadcentral_rg_dns_connectivity_canadacentral_001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/VM-Free-Disk-Space-Alert-canadcentral"
}

import {
  to = module.monitor_alerts[0].azurerm_monitor_scheduled_query_rules_alert_v2.this["vm_free_disk_space_connectivity_alert_canadacentral"]
  id = "${local.sub}/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/VM-Free-Disk-Space-Connectivity-Alert-canadacentral"
}

import {
  to = module.monitor_alerts[0].azurerm_monitor_scheduled_query_rules_alert_v2.this["vm_free_disk_space_dns_alert_canadcentral"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/VM-Free-Disk-Space-DNS-Alert-canadcentral"
}

import {
  to = module.monitor_alerts[0].azurerm_monitor_scheduled_query_rules_alert_v2.this["vm_free_disk_space_runners_alert_canadacentral"]
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/VM-Free-Disk-Space-Runners-Alert-canadacentral"
}

import {
  to = module.monitor_alerts[0].azurerm_monitor_scheduled_query_rules_alert_v2.this["vm_heartbeat_lost_alert_canadcentral"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/VM-Heartbeat-Lost-Alert-canadcentral"
}

import {
  to = module.monitor_alerts[0].azurerm_monitor_scheduled_query_rules_alert_v2.this["vm_linux_syslog_connectivity_alert_canadacentral"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/VM-Linux-Syslog-Connectivity-Alert-canadacentral"
}

import {
  to = module.monitor_alerts[0].azurerm_monitor_scheduled_query_rules_alert_v2.this["vm_patching_failed_connectivity"]
  id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/VM-Patching-Failed-Connectivity"
}

import {
  to = module.monitor_alerts[0].azurerm_monitor_scheduled_query_rules_alert_v2.this["vm_patching_failed_runners_canadacentral"]
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/VM-Patching-Failed-Runners-canadacentral"
}

import {
  to = module.monitor_alerts[0].azurerm_monitor_scheduled_query_rules_alert_v2.this["vm_pending_update_connectivity_canadacentral"]
  id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/VM-Pending-Update-Connectivity-canadacentral"
}

import {
  to = module.monitor_alerts[0].azurerm_monitor_scheduled_query_rules_alert_v2.this["vm_pending_update_runners_canadacentral"]
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/VM-Pending-Update-Runners-canadacentral"
}

import {
  to = module.monitor_alerts[0].azurerm_monitor_scheduled_query_rules_alert_v2.this["vm_windows_service_stopped_connectivity_canadacentral"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/VM-Windows-Service-Stopped-Connectivity-canadacentral"
}


# ── actionGroups (2)
import {
  to = module.monitor_alerts[0].azurerm_monitor_action_group.this["actiongroup_20260318t193824067z"]
  id = "${local.sub}/resourceGroups/AzureBackupRG_canadacentral_1/providers/Microsoft.Insights/actionGroups/ActionGroup_20260318T193824067Z"
}

import {
  to = module.monitor_alerts[0].azurerm_monitor_action_group.this["actiongroup_20260318t202530133z"]
  id = "${local.sub}/resourceGroups/AzureBackupRG_canadacentral_1/providers/Microsoft.Insights/actionGroups/ActionGroup_20260318T202530133Z"
}


# ── actionRules (7)
import {
  to = module.monitoring[0].azurerm_monitor_alert_processing_rule_suppression.this["alert_suppression_for_vpn_canadacentral"]
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.AlertsManagement/actionRules/Alert suppression for VPN Canadacentral"
}

import {
  to = module.monitoring[0].azurerm_monitor_alert_processing_rule_suppression.this["alert_suppression_on_vpn_connectivity"]
  id = "${local.sub}/resourceGroups/rg-alerts-connectivity-canadacentral-001/providers/Microsoft.AlertsManagement/actionRules/Alert suppression on VPN connectivity"
}

import {
  to = module.monitoring[0].azurerm_monitor_alert_processing_rule_suppression.this["alert_suppression_for_expressroutecircuit"]
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.AlertsManagement/actionRules/Alert-Suppression for ExpressRouteCircuit"
}

import {
  to = module.monitoring[0].azurerm_monitor_alert_processing_rule_suppression.this["alert_suppression_for_vpn_canadaeast"]
  id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadaeast-001/providers/Microsoft.AlertsManagement/actionRules/alert suppression for VPN Canadaeast"
}

import {
  to = module.monitoring[0].azurerm_monitor_alert_processing_rule_suppression.this["alert_suppression_cyberarkvm"]
  id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.AlertsManagement/actionRules/alert-suppression-cyberarkvm"
}

import {
  to = module.monitoring[0].azurerm_monitor_alert_processing_rule_suppression.this["supppress_heartbeat_alert"]
  id = "${local.sub}/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.AlertsManagement/actionRules/supppress-heartbeat-alert"
}

import {
  to = module.monitoring[0].azurerm_monitor_alert_processing_rule_suppression.this["suppress_backup_alerts"]
  id = "${local.sub}/resourceGroups/rg-alerts-connectivity-canadacentral-001/providers/Microsoft.AlertsManagement/actionRules/suppress-backup-alerts"
}

