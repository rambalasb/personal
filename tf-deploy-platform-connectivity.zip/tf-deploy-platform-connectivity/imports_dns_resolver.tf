# imports_dns_resolver.tf — 1 resolver + inbound/outbound endpoints + forwarding ruleset
# confirm AVM internal import addresses on first plan

import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver.this
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsResolvers/pdr-connectivity-canadacentral-001"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_inbound_endpoint.this["pdr-inbound-connectivity-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsResolvers/pdr-connectivity-canadacentral-001/inboundEndpoints/pdr-inbound-connectivity-canadacentral-001"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_outbound_endpoint.this["pdr-outbound-connectivity-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsResolvers/pdr-connectivity-canadacentral-001/outboundEndpoints/pdr-outbound-connectivity-canadacentral-001"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_dns_forwarding_ruleset.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001"
}

# Forwarding rules (62). The wrapper's inner for_each key is
# "<outbound_endpoint_key>-<ruleset_key>-<rule_key>", read from the module
# source after terraform init rather than inferred.
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-bchydro-rule-0"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/bchydro-rule-0"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-bchydro-rule-1"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/bchydro-rule-1"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-0"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-0"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-1"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-1"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-10"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-10"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-11"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-11"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-12"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-12"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-13"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-13"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-14"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-14"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-15"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-15"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-16"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-16"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-17"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-17"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-18"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-18"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-19"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-19"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-2"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-2"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-20"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-20"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-21"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-21"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-22"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-22"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-23"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-23"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-24"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-24"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-25"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-25"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-26"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-26"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-27"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-27"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-28"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-28"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-29"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-29"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-3"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-3"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-30"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-30"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-31"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-31"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-32"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-32"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-33"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-33"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-34"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-34"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-35"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-35"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-36"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-36"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-37"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-37"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-38"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-38"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-39"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-39"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-4"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-4"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-40"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-40"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-41"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-41"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-42"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-42"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-43"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-43"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-44"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-44"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-45"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-45"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-46"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-46"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-47"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-47"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-48"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-48"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-49"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-49"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-5"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-5"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-50"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-50"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-51"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-51"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-52"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-52"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-53"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-53"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-54"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-54"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-55"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-55"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-56"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-56"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-57"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-57"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-58"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-58"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-59"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-59"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-6"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-6"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-7"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-7"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-8"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-8"
}
import {
  to = module.dns_resolver["pdr-connectivity-canadacentral-001"].module.dns_resolver.azurerm_private_dns_resolver_forwarding_rule.this["pdr-outbound-connectivity-canadacentral-001-frs-dns-connectivity-canadacentral-001-mvp-rule-9"]
  id = "${local.sub}/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/dnsForwardingRulesets/frs-dns-connectivity-canadacentral-001/forwardingRules/mvp-rule-9"
}
