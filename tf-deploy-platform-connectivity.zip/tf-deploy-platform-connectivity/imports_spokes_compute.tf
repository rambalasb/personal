# imports_spokes_compute.tf — Compute/spokes tier.
# confirm AVM internal import addresses on first plan (VM + NIC addresses inside
# the tf-wrapper-avm-virtual-machine-* modules and the recovery-services-vault module).

# ── Windows VMs (4) ───────────────────────────────────────────────────
#
# The ertest test environment was rebuilt under different names. The 11 VMs
# and their 11 NICs that these blocks targeted no longer exist in Azure; the
# blocks and their entries in spokes_compute.tf were removed on 2026-09-17.
# The VNets, NSGs, bastion hosts and maintenance configurations in the two
# ertest RGs are unaffected and still imported below.
#

import {
  to = module.windows_vm["vm-cyberark-server-canadacentral-001"].module.windows_vm.azurerm_windows_virtual_machine.this
  id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-cyberark-server-canadacentral-001"
}
import {
  to = module.windows_vm["VM-CYBERARK-SERVER-CANADACENTRAL-002"].module.windows_vm.azurerm_windows_virtual_machine.this
  id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Compute/virtualMachines/VM-CYBERARK-SERVER-CANADACENTRAL-002"
}
import {
  to = module.windows_vm["vm-runners-dev-canadacentral-001"].module.windows_vm.azurerm_windows_virtual_machine.this
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-runners-dev-canadacentral-001"
}
import {
  to = module.windows_vm["vm-runners-prod-canadacentral-001"].module.windows_vm.azurerm_windows_virtual_machine.this
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-runners-prod-canadacentral-001"
}
import {
  to = module.linux_vm["vm-runners-lin-dev-canadacentral-001"].module.linux_vm.azurerm_linux_virtual_machine.this
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-runners-lin-dev-canadacentral-001"
}
import {
  to = module.linux_vm["vm-runners-lin-prod-canadacentral-001"].module.linux_vm.azurerm_linux_virtual_machine.this
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-runners-lin-prod-canadacentral-001"
}
import {
  to = module.windows_vm["vm-cyberark-server-canadacentral-001"].module.windows_vm.azurerm_network_interface.this["nic-cyberark-server-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Network/networkInterfaces/nic-cyberark-server-canadacentral-001"
}
import {
  to = module.windows_vm["VM-CYBERARK-SERVER-CANADACENTRAL-002"].module.windows_vm.azurerm_network_interface.this["nic-cyberark-server-canadacentral-002"]
  id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Network/networkInterfaces/nic-cyberark-server-canadacentral-002"
}
import {
  to = module.windows_vm["vm-runners-dev-canadacentral-001"].module.windows_vm.azurerm_network_interface.this["nic-vm-runners-dev-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/networkInterfaces/nic-vm-runners-dev-canadacentral-001"
}
import {
  to = module.windows_vm["vm-runners-prod-canadacentral-001"].module.windows_vm.azurerm_network_interface.this["nic-vm-runners-prod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/networkInterfaces/nic-vm-runners-prod-canadacentral-001"
}
import {
  to = module.linux_vm["vm-runners-lin-dev-canadacentral-001"].module.linux_vm.azurerm_network_interface.this["nic-vm-runners-lin-dev-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/networkInterfaces/nic-vm-runners-lin-dev-canadacentral-001"
}
import {
  to = module.linux_vm["vm-runners-lin-prod-canadacentral-001"].module.linux_vm.azurerm_network_interface.this["nic-vm-runners-lin-prod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/networkInterfaces/nic-vm-runners-lin-prod-canadacentral-001"
}
import {
  to = module.ssh_public_key["vm-cyberark-test-vm01-canadacentral-001_key"].module.public_ssh_key.azurerm_ssh_public_key.this
  id = "${local.sub}/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.Compute/sshPublicKeys/vm-cyberark-test-vm01-canadacentral-001_key"
}
import {
  to = module.ssh_public_key["vm-cyberark-test-vm-canadacentral-001_key"].module.public_ssh_key.azurerm_ssh_public_key.this
  id = "${local.sub}/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.Compute/sshPublicKeys/vm-cyberark-test-vm-canadacentral-001_key"
}
import {
  to = module.ssh_public_key["sshkey-hosted-runners-canadacentral-001"].module.public_ssh_key.azurerm_ssh_public_key.this
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Compute/sshPublicKeys/sshkey-hosted-runners-canadacentral-001"
}
import {
  to = module.bastion_host["bh-cyberark-canadacentral-001"].module.bastion_host.azapi_resource.bastion_developer[0]
  id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Network/bastionHosts/bh-cyberark-canadacentral-001"
}
import {
  to = module.bastion_host["bh-ertest-canadacentral-001"].module.bastion_host.azapi_resource.bastion_developer[0]
  id = "${local.sub}/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.Network/bastionHosts/bh-ertest-canadacentral-001"
}
import {
  to = module.bastion_host["bh-ertest-canadaeast-001"].module.bastion_host.azapi_resource.bastion_developer[0]
  id = "${local.sub}/resourceGroups/rg-ertest-canadaeast-001/providers/Microsoft.Network/bastionHosts/bh-ertest-canadaeast-001"
}
import {
  to = module.bastion_host["bh-connectivity-canadacentral-001"].module.bastion_host.azapi_resource.bastion_developer[0]
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Network/bastionHosts/bh-connectivity-canadacentral-001"
}
import {
  to = azurerm_lb.cyberark
  id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Network/loadBalancers/lb-internal-cyberark-canadacentral-001"
}
import {
  to = azurerm_lb_backend_address_pool.cyberark
  id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Network/loadBalancers/lb-internal-cyberark-canadacentral-001/backendAddressPools/bkp-lb-internal-cyberark-canadacentral-001"
}
import {
  to = azurerm_lb_probe.cyberark["psm-health-probe"]
  id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Network/loadBalancers/lb-internal-cyberark-canadacentral-001/probes/psm-health-probe"
}
import {
  to = azurerm_lb_probe.cyberark["rds-health-probe"]
  id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Network/loadBalancers/lb-internal-cyberark-canadacentral-001/probes/rds-health-probe"
}
import {
  to = azurerm_lb_rule.cyberark["rds-inbound-lb-rule"]
  id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Network/loadBalancers/lb-internal-cyberark-canadacentral-001/loadBalancingRules/rds-inbound-lb-rule"
}
import {
  to = azurerm_lb_rule.cyberark["psm-inbound-lb-rule"]
  id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Network/loadBalancers/lb-internal-cyberark-canadacentral-001/loadBalancingRules/psm-inbound-lb-rule"
}
import {
  to = azurerm_maintenance_configuration.this["mc-cyberark-server-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Maintenance/maintenanceConfigurations/mc-cyberark-server-canadacentral-001"
}
import {
  to = azurerm_maintenance_configuration.this["mc-cyberark-server-canadacentral-002"]
  id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Maintenance/maintenanceConfigurations/mc-cyberark-server-canadacentral-002"
}
import {
  to = azurerm_maintenance_configuration.this["mc-cyberark-server-canadacentral-01"]
  id = "${local.sub}/resourceGroups/rg-cyberark-canadacentral-001/providers/Microsoft.Maintenance/maintenanceConfigurations/mc-cyberark-server-canadacentral-01"
}
import {
  to = azurerm_maintenance_configuration.this["vm-ertest-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-ertest-canadacentral-001/providers/Microsoft.Maintenance/maintenanceConfigurations/vm-ertest-canadacentral-001"
}
import {
  to = azurerm_maintenance_configuration.this["vm-ertest-canadaeast-001"]
  id = "${local.sub}/resourceGroups/rg-ertest-canadaeast-001/providers/Microsoft.Maintenance/maintenanceConfigurations/vm-ertest-canadaeast-001"
}
import {
  to = azurerm_maintenance_configuration.this["mc-runners-dev-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Maintenance/maintenanceConfigurations/mc-runners-dev-canadacentral-001"
}
import {
  to = azurerm_maintenance_configuration.this["mc-runners-prod-canadacentral-001"]
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.Maintenance/maintenanceConfigurations/mc-runners-prod-canadacentral-001"
}
import {
  to = module.recovery_services_vault["connectivity"].module.recovery_services_vault.azapi_resource.this
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.RecoveryServices/vaults/rsv-connectivity-canadacentral-001"
}
import {
  to = azurerm_backup_policy_vm.default
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.RecoveryServices/vaults/rsv-connectivity-canadacentral-001/backupPolicies/DefaultPolicy"
}
import {
  to = azurerm_backup_policy_vm.enhanced
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.RecoveryServices/vaults/rsv-connectivity-canadacentral-001/backupPolicies/EnhancedPolicy"
}
import {
  to = azurerm_backup_policy_vm_workload.hourly_log
  id = "${local.sub}/resourceGroups/rg-runners-connectivity-canadacentral-001/providers/Microsoft.RecoveryServices/vaults/rsv-connectivity-canadacentral-001/backupPolicies/HourlyLogBackup"
}
