# monitoring.tf
# Standard alerts via the amba-alz wrapper. Action groups are external (mgmt sub).
#
# PENDING — connectivity-specific alerts in rg-alerts-connectivity whose exact
# resource names `az group export` parameterized (need `az resource show` to
# confirm before import):
#   - metric: firewall health (scope=azfw), VM CPU high, VM memory high
#   - activity: firewall write (scope=azfw -> ag-AzFW), VPN down CC + CE
#     (ResourceHealth on the vpnGateways -> ServiceNow)
#   The firewall/VPN scopes live in rg-hub-* (added with the hub tier).
#
# NOT MANAGED (flagged for review):
#   - storage accounts sttestingitout1 / sttestingitout2 (+ their event grid
#     topics/subscriptions) — look like test artifacts in the alerts RG

module "monitoring" {
  count   = var.enable_monitoring ? 1 : 0
  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-ptn-monitoring-amba-alz/azurerm"
  version = "0.3.1"

  enable_amba                = var.enable_amba
  location                   = var.location
  root_management_group_name = var.root_management_group_name

  activity_log_alerts = local.activity_log_alerts
  log_search_alerts   = local.log_search_alerts

  # Owned by the conn_alerts tier; passed here because monitor-alerts has no input for them.
  alert_processing_rules = var.enable_conn_alerts ? local.monitor_alert_processing_rules : {}
  tags                   = local.common_tags

  depends_on = [module.resource_group]
}
