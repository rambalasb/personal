# Adding resources to the connectivity landing zone

How to add anything this workspace owns: resource groups, the vWAN hub tier,
network primitives, virtual networks, private DNS, the DNS resolver, spoke
compute, and the alerts tier.

This repo is larger and shaped differently from its siblings. Two things to
internalise before you start:

- **Most definitions live in `locals` inside the `.tf` files, not in tfvars.**
  Only `resource_group` and `private_dns_zones` are tfvars-driven. Everything
  else — hubs, VMs, NSGs, alerts — is a `locals` map in the tier's own file.
- **Tiers are split by file, and each has its own import file.** `hub_vwan.tf`
  pairs with `imports_hub_vwan.tf`, `spokes_compute.tf` with
  `imports_spokes_compute.tf`, and so on. Change a tier, update its import file.

And the rule that costs the most when missed:

- **The map key is the resource identity.** Change a key and Terraform renames
  the Azure resource. On VMs, NSGs, VNets and most things here, `name` is
  ForceNew — the rename is a destroy and recreate. Rename via a `moved` block
  or not at all.

---

## Order of operations

Terraform resolves dependencies inside a single plan, so a single PR is fine
within this workspace. What it cannot order is another workspace, and what it
cannot warn you about is a reference to a key you have not written yet.

| # | Layer | File | Referenced by |
| --- | --- | --- | --- |
| 1 | `resource_group` | `connectivity.tfvars` | everything, via `rg_key` / `resource_group_key` |
| 2 | Virtual networks and subnets | `virtual_network.tf` | NSGs, private endpoints, VMs, hub connections |
| 3 | Network primitives — public IPs, prefixes, NAT gateways, route tables, NSGs | `net_primitives.tf` | VMs, subnets, gateways |
| 4 | vWAN, hubs, route tables, routing intents | `hub_vwan.tf` | hub connections, gateways, the firewall repo |
| 5 | ExpressRoute and VPN gateways, circuits, connections | `hub_vwan.tf` | — |
| 6 | Private DNS zones and links | `connectivity.tfvars` | private endpoints |
| 7 | DNS resolver | `dns_resolver.tf` | — |
| 8 | Spoke compute — SSH keys, VMs, bastion, maintenance, LB | `spokes_compute.tf` | — |
| 9 | Alerts | `conn_alerts.tf` | — |

### What other workspaces depend on

This is the base layer for the platform, so changes here reach further than
this repo:

- **`tf-deploy-platform-firewall-management`** reads five resource groups from
  here through data sources, and its firewalls attach to hubs, VNets, subnets
  and public IPs defined here. Those must exist and be applied **before** a
  firewall plan runs there. Deleting or renaming one fails their plan.
- **Firewall alerts live here**, not in the firewall repo — scoped to the
  firewall by constructed ID. Watching a resource does not require owning it.

---

## A. Add a resource group

### Step 1 — add the entry to `resource_group` in `connectivity.tfvars`

```hcl
"example" = {
  name     = "rg-example-connectivity-canadacentral-001"
  location = "canadacentral"
  tags     = {}
}
```

Existing keys: `alerts`, `cyberark`, `dmz`, `dns`, `ertest_cc`, `ertest_ce`,
`hub_cc`, `hub_ce`, `ip_groups`, `runners`, `shared_cc`, `shared_ce`.

### Step 2 — confirm `enable_resource_group` is `true`

### Step 3 — tell the firewall repo if it needs to see the group

If the group will hold firewalls, policies or IP groups, that repo needs a
variable, a data source and an `rg_names` entry. See its `ADDING-RESOURCES.md`
section G. This repo owns the group; that one only reads it.

### Step 4 — ship the resource group

Go to [Shipping the change](#shipping-the-change).

---

## B. Add a virtual network or subnet

### Step 1 — edit `local.virtual_network_data` in `virtual_network.tf`

### Step 2 — check the address space does not overlap

Overlap is not caught by a plan. It fails at apply, or worse, applies and
breaks routing.

### Step 3 — add subnets in the same entry

Subnets are child resources and invisible to `az resource list`, so drift
detection will not report a subnet added by hand. The declaration here is the
only record.

### Step 4 — update `imports_virtual_network.tf` if adopting

Creating: no import block. Adopting an existing VNet: one block per VNet and
one per subnet.

### Step 5 — ship the network

Go to [Shipping the change](#shipping-the-change).

---

## C. Add a network primitive

Public IPs, public IP prefixes, NAT gateways, route tables, NSGs, private
endpoints, ExpressRoute circuits, network watchers, flow logs, traffic
collectors.

### Step 1 — find the right map in `net_primitives.tf`

One `locals` map per type: `net_public_ips`, `net_public_ip_prefixes`,
`net_nat_gateways`, `net_route_tables`, `net_nsgs`, `net_private_endpoints`,
`net_er_circuits`, `net_network_watchers`, `net_flow_logs`,
`net_traffic_collectors`, `net_collector_policies`.

### Step 2 — add the entry, keyed by the Azure resource name

### Step 3 — for NSGs, remember the rules are child resources

NSG security rules do not appear in `az resource list`. A rule added by hand in
the portal will not be reported as unmanaged — it will simply be removed on the
next apply.

Route-table routes are the same: `net_route_tables` takes `routes` as a map
keyed by route name, and the wrapper creates each route as its own resource
(`module.route_table[k].module.route_table.module.routes["<route>"].azapi_resource.route`),
so adopting a route needs its own import block alongside the table's.

### Step 4 — for flow logs, check the storage account exists

Flow log storage (`stnwconncanadacentral`, `stnwconncanadaeast`) is in this
subscription but may not yet be declared. Check before referencing.

### Step 5 — update `imports_net_primitives.tf` if adopting

### Step 6 — ship the primitive

Go to [Shipping the change](#shipping-the-change).

---

## D. Add to the vWAN hub tier

Virtual hubs, hub route tables, route maps, routing intents, hub virtual
network connections, BGP connections, ExpressRoute gateways and connections,
VPN sites, VPN gateways and connections.

### Step 1 — find the right map in `hub_vwan.tf`

`virtual_hubs`, `hub_route_tables`, `route_maps`, `routing_intents`,
`hub_virtual_network_connections`, `hub_bgp_connections`,
`express_route_gateways`, `express_route_connections`, `vpn_sites`,
`vpn_gateways`, `vpn_gateway_connections`.

### Step 2 — add the hub before anything that attaches to it

Connections, gateways and route tables all reference a hub. Within one plan
Terraform orders this itself, but the key must exist.

### Step 3 — check `local.hub_firewall_ids` if a firewall is involved

Routing intents reference the firewall by constructed ID. The firewall itself
is owned by `tf-deploy-platform-firewall-management` — this repo points at it,
it does not manage it.

### Step 4 — mind the child resources

Hub virtual network connections, hub route tables and route maps are children
of the hub and invisible to `az resource list`. Drift detection cannot see
them.

**Take `remote_virtual_network_id` from Azure, never reconstruct it.** It is
ForceNew, and the spoke VNets live in workload subscriptions:
`az network vhub connection show … --query remoteVirtualNetwork.id`.

**Do not add `defaultRouteTable` to `hub_route_tables`.** Routing intent owns
it. To change routing intent's additional private prefixes, edit
`azurerm_virtual_hub_route_table_route.private_traffic`; for anything else,
change the intent (`REMEDIATION.md`).

### Step 5 — update `imports_hub_vwan.tf` if adopting

### Step 6 — ship the hub change

Go to [Shipping the change](#shipping-the-change). Hub changes can interrupt
transit; read the plan for replaces with particular care.

---

## E. Add a private DNS zone or vnet link

### Step 1 — add the entry to `private_dns_zones` in `connectivity.tfvars`

```hcl
"privatelink.example.azure.com" = {
  domain_name = "privatelink.example.azure.com"
  virtual_network_links = {
    "link-dns-connectivity-canadacentral-001" = {
      name                 = "link-dns-connectivity-canadacentral-001"
      virtual_network_id   = "/subscriptions/.../virtualNetworks/vnet-dns-connectivity-canadacentral-001"
      registration_enabled = false
      resolution_policy    = "Default"
    }
  }
}
```

### Step 2 — set `resolution_policy` explicitly

It defaults to `Default`, but 13 live links use `NxDomainRedirect`. Getting
this wrong silently changes DNS resolution behaviour.

### Step 3 — use the full resource ID for `virtual_network_id`

Most links point at VNets in other subscriptions. There is no shortcut.

### Step 4 — confirm `enable_private_dns_zones` is `true`

### Step 5 — update `imports_private_dns.tf` if adopting

One import block per zone and one per link. The file currently holds 358 (43 zones, 315 links).

### Step 6 — ship the zone

Go to [Shipping the change](#shipping-the-change).

---

## F. Add spoke compute

VMs, SSH keys, bastion hosts, maintenance configurations, load balancer probes
and rules.

### Step 1 — add the SSH key first if it is a Linux VM

`local.spokes_ssh_public_keys` in `spokes_compute.tf`, created through
`tf-wrapper-avm-public-ssh-key`. The map key is the Azure resource name, and VMs
reference it as `local.spokes_ssh_public_keys["<key>"].public_key`. The key's
`location` must match its resource group's region — the wrapper checks it.
Prefer ed25519; the wrapper warns on RSA.

### Step 2 — add the VM to `spokes_windows_vms` or `spokes_linux_vms`

Every attribute is required, including the NIC name, subnet, IP allocation and
data disks.

### Step 3 — get the name casing exactly right

`module "windows_vm"` sets `name = each.key`, and `name` is ForceNew. Two live
VMs are uppercase — `VM-CYBERARK-SERVER-CANADACENTRAL-002` and
`VM-TESTVM-CANADACENTRAL-001`. The generic `az resource show` reports them
lowercased. Getting this wrong destroys and recreates a production server; it
was a live defect in this repo until 17 September 2026.

### Step 4 — the NIC is inline, not separate

`nic_name` inside the VM entry creates the NIC. There is no separate NIC map.
Removing a VM entry removes its NIC with it.

### Step 5 — add maintenance configuration and backup if it needs them

`spokes_maintenance_configurations`, and the backup policies in the same file.
Maintenance configurations are native because the wrapper rejects hyphens; a new
one can use the wrapper if its name has none.

Bastion hosts go in `spokes_bastion_hosts` and through
`tf-wrapper-avm-bastion-host`. For the Developer SKU, pass `zones = []` (the
wrapper defaults to three zones, which Developer rejects); the import target is
`module.bastion_host["<name>"].module.bastion_host.azapi_resource.bastion_developer[0]`.

### Step 6 — update `imports_spokes_compute.tf` if adopting

### Step 7 — ship the VM

Go to [Shipping the change](#shipping-the-change).

---

## G. Add an alert

### Step 1 — decide which of the three homes it belongs in

- **`conn_alerts.tf`** — connectivity-specific alerts through
  `tf-wrapper-avm-monitor-alerts`. 50 resources: metric alerts, log search
  alerts, activity log alerts, action groups, and alert processing rules.
- **`monitoring.tf`** — the four standard ALZ alerts on the amba-alz pattern
  module, shared with other landing zones. Do not pull alerts out of this into
  `conn_alerts.tf`; the pattern is deliberate.
- **Another repo** — an alert on a resource this subscription does not hold.

### Step 2 — add the entry to the right locals map

`monitor_metric_alerts`, `monitor_activity_log_alerts`,
`monitor_log_search_alerts`, `monitor_action_groups`, or
`monitor_alert_processing_rules` — all in `conn_alerts.tf`.

Alert processing rules are declared in `conn_alerts.tf` but created by
`module.monitoring` (`tf-wrapper-avm-ptn-monitoring-amba-alz` ≥ 0.3.1), because
`tf-wrapper-avm-monitor-alerts` has no input for them. Their import target is
`module.monitoring[0].azurerm_monitor_alert_processing_rule_suppression.this["<key>"]`
(or `..._action_group` for a rule that adds action groups). Copy every
`condition` from Azure — a suppression rule without its conditions suppresses
everything in scope.

### Step 3 — get the metric alert name from the right source

The generic `Microsoft.Resources` API lowercases `microsoft.insights` IDs and
derives `name` from them, so `az resource show` reports 16 of the 19 live
metric alert names in the wrong case. `name` is ForceNew. Take names from the
portal or a typed `az monitor` command.

### Step 4 — watch for carriage returns in KQL

Log search alert queries carry `\r\n`. A raw CR terminates an HCL string.

### Step 5 — check the key does not collide

Two live alerts share the name `VM-Free-Disk-Space-Alert-canadcentral` in
different resource groups. Keys that would collide carry the resource group as
a suffix.

### Step 6 — confirm `enable_conn_alerts` is `true`

### Step 7 — update `imports_conn_alerts.tf` if adopting

### Step 8 — ship the alert

Go to [Shipping the change](#shipping-the-change).

---

## Shipping the change

### Step 1 — branch, change, open a PR

`tflint.yml` and `trivy.yml` run on the PR. Neither reads state.

### Step 2 — run `import-verify.yml`

`workflow_dispatch` only. Plans and gates, never applies. Safe at any time.

### Step 3 — read the plan

For a new resource expect creates and nothing else. Any **replace** or
**destroy** on something you did not intend to change means a key or a name is
wrong. Stop and fix it rather than approving.

This repo is large enough that a plan is long. Do not skim it — the VM casing
defect would have shown up here as a replace.

### Step 4 — run `import-apply.yml`

The `check` job plans and publishes a digest; the `apply` job needs an
approver.

### Step 5 — tell the firewall team if you changed their dependencies

Resource groups, hubs, VNets, subnets or public IPs the firewall workspace
attaches to. Their plan fails if one disappears.

---

## Things worth knowing

**Child resources are invisible to drift detection.** Subnets, NSG security
rules, VNet peerings, hub connections, hub route tables, route maps, LB probes
and rules, backup policies — `az resource list` does not enumerate any of
them, so `detect_unmanaged.sh` cannot report one added by hand. Roughly 92 of
this subscription's resources are in that category. The declaration in this
repo is the only record.

**The type filter is a shared convention.** `unmanaged-detect.yml` here and in
the firewall repo use complementary `--scope-type` lists. If a type moves
between repos, both must change in the same PR. Nothing in CI catches a
mismatch, and the dangerous failure is a type dropped from both.

**Names are not always what the CLI reports.** Beyond the VMs and metric
alerts already noted, assume any adopted name needs confirming against the
portal or a typed `az` command.

**Some live names are malformed and reproduced verbatim.** Tidying one is a
rename, and a rename is a replace.
