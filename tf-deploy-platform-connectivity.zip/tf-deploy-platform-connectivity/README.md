# tf-deploy-platform-connectivity

Manages the network estate in the connectivity subscription
(`f3835bc1-9829-4ac8-9d7a-0999e0b29b90`, `canadacentral` + `canadaeast`)
through the `tf-wrapper-avm-*` modules, with native `azurerm_`/`azapi`
resources where a wrapper cannot express the live configuration. `HANDOVER.md`
§2 lists which, and why.

## What is managed

**726 import blocks** across nine tiers, reconciled against the 2026-10-05
inventory:

| Tier | File | Contents | Imports |
|---|---|---|---|
| Resource groups | `resource_group.tf` | 12 RGs across 2 regions | 12 |
| Standard alerts | `monitoring.tf`, `locals.tf` | Service-Outage (activity log), Resource-Creation and 2 storage-deletion (log search) | 4 |
| Private DNS | `private_dns_zones.tf`, `connectivity.tfvars` | 43 zones + 315 vnet links | 358 |
| Virtual networks | `virtual_network.tf` | 8 VNets, 14 subnets, 9 peerings | 31 |
| vWAN hub | `hub_vwan.tf` | vWAN, 2 hubs, 2 `noneRouteTable`s + 2 `private_traffic` routes, 17 route maps, 2 routing intents, 50 hub connections, 1 BGP connection, 2 ER gateways + 4 connections, 2 VPN gateways + 2 connections, 2 VPN sites | 89 |
| Network primitives | `net_primitives.tf` | DDoS, 3 NAT, 3 PIP prefixes, 2 PIPs, 11 NSGs (+33 rules), 2 route tables (+1 route), 8 private endpoints, 2 ER circuits (+2 peerings), 2 network watchers, 6 flow logs, 2 traffic collectors (+2 policies) | 80 |
| DNS resolver | `dns_resolver.tf` | resolver, inbound + outbound endpoints, forwarding ruleset + 62 rules | 66 |
| Spokes/compute | `spokes_compute.tf` | 6 VMs (4 Windows, 2 Linux) + 6 NICs, 4 Developer bastions, 3 SSH keys, 1 LB (+pool, 2 probes, 2 rules), 7 maintenance configs, recovery vault + 3 backup policies | 36 |
| Connectivity alerts | `conn_alerts.tf` | 19 metric, 16 log-search and 6 activity-log alerts, 2 action groups, 7 alert processing rules (declared here, created through `module.monitoring`) | 50 |

Five resource groups are Azure-managed and deliberately excluded:
`AzureBackupRG_canadacentral_1`, `DefaultResourceGroup-CCA`,
`DefaultResourceGroup-CCAN`, `microsoft-network-canadacentral`,
`microsoft-network-canadaeast`.

**Nothing has been applied yet.** See `HANDOVER.md` §4 for what must be settled
first, and `PRE-APPLY-NOTES.md` for the tier-by-tier build record.

## The boundary with tf-deploy-platform-firewall-management

The firewall estate was split out of this repo into
`tf-deploy-platform-firewall-management` (HCP workspace
`az-platform-firewall`), so a firewall rule change no longer requires a plan
that refreshes the VMs, 43 private DNS zones and 50 hub connections — and, more
to the point, so an apply from the firewall repo cannot modify a VNet, hub or
gateway.

Three resource types moved, wherever they sit in this subscription:

| | This repo | tf-deploy-platform-firewall-management |
|---|---|---|
| `Microsoft.Network/azureFirewalls` | — | owns (3) |
| `Microsoft.Network/firewallPolicies` | — | owns (2, plus 17 rule collection groups) |
| `Microsoft.Network/ipGroups` | — | owns (197) |
| resource groups | **owns (12)** | reads 4 via data sources |
| everything else | **owns** | — |

The split is by **resource type, not by resource group**. All 12 resource
groups stay here, including `rg-ip-groups-connectivity-global`, which now holds
nothing this repo owns. Three consequences:

1. **Nothing crosses between the two workspaces' state.** `hub_vwan.tf` points
   its route next-hops at the two hub firewalls, and `conn_alerts.tf` scopes the
   firewall health and write alerts to `azfw-connectivity-canadacentral-001`.
   Both use **constructed** resource IDs, not module outputs. The firewall
   **names** are therefore the contract between the two repos: renaming one
   there breaks these routes and alerts here, silently.
2. **The firewall's alerts stay in this repo.** They watch the firewall rather
   than configure it, and they belong with the rest of the alerts tier in
   `rg-alerts-connectivity-canadacentral-001`.
3. **The inventory check filters by type.** `unmanaged-detect.yml` passes
   `--exclude-type` for the three types above; the firewall repo passes
   `--scope-type` for the same three. The two filters are complements, so every
   top-level resource in the shared groups is covered exactly once. **If the
   boundary moves, both lists have to move together** — a type dropped from one
   and not added to the other stops being checked by either, and nothing fails
   to tell you.

## Running a change

```bash
terraform init
terraform plan -var-file=connectivity.tfvars -out=tfplan.binary
terraform apply tfplan.binary
```

`connectivity.tfvars` is passed explicitly rather than auto-loaded — it was
`terraform.tfvars`, renamed to match `identity.tfvars` and `firewall.tfvars` in
the sibling repos and to keep it out of Terraform's automatic loading.

`var.spokes_vm_admin_password` must come from the environment
(`TF_VAR_spokes_vm_admin_password`) or a workspace variable. Never commit it;
the placeholder in the repo is `REPLACE_ME_PLACEHOLDER`.

## Pipelines

The three below share the `sub-connectivity-lz` concurrency group, so one run
touches this subscription's network estate at a time. The group is deliberately
*not* shared with `tf-deploy-platform-firewall-management`: the two workspaces
own disjoint resources, so serialising them would only make a firewall rule
change wait behind a spoke VM refresh.

- `import-verify.yml`: fmt, plan and gate, never applies. `workflow_dispatch`
  only. Safe to run any time.
- `import-apply.yml`: two jobs in one run. `check` plans, gates, and publishes
  a digest of the change set; `apply` sits behind the `connectivity` GitHub
  environment and needs an approver. `workflow_dispatch` only.
- `unmanaged-detect.yml`: diffs Azure's inventory against state, with the three
  firewall types excluded. Daily at 14:15 UTC, plus `workflow_dispatch`. Skips
  unless `vars.AZURE_CLIENT_ID` is set. See [Drift](#drift).

The two scanning workflows are separate: `tflint.yml` runs on push to `main`
and on pull request, `trivy.yml` on pull request and weekly. Neither takes the
concurrency group; they never read state.

`plan-and-verify.yml` was removed. It drove HCP Terraform through the API,
creating and configuring the workspace on each run, and refused to run against
a configuration declaring its own `cloud` block — which `providers.tf` now
does. `import-verify.yml` covers the plan and the gate; `unmanaged-detect.yml`
covers the `az resource list` reconciliation it did, more precisely, because it
compares against state rather than against the plan's import targets.

**The `connectivity` environment must have required reviewers configured.**
Without them the job runs straight through and there is no approval stop.

Two controls sit between approval and apply, covering different failures:

1. The apply job re-plans and re-runs `verify_zero_diff.sh`, so attribute-level
   drift that appeared during the approval wait fails the run. It does not
   consume the check job's plan: applying a saved plan would replay a recorded
   diff without re-reading Azure.
2. It then compares its own change set against the digest the check job
   published, so a resource entering or leaving the plan between review and
   approval blocks the apply. The approver's summary shows the digest that has
   to match.

Neither `plan.json` nor `tfplan.binary` is uploaded; they carry resolved
attribute values, and this plan resolves `var.spokes_vm_admin_password`. The
artifacts hold the gate output and an address-level change list only.

## Drift

**HCP Terraform's drift detection** should be enabled on the
`az-platform-connectivity` workspace. It runs a refresh-only comparison and
reports when a resource *already in state* has changed in Azure. That is the
half Terraform can answer from state alone.

**Two questions are not covered.**

A resource that exists in Azure but has no state entry, created by hand, is
invisible to a refresh-only plan, because there is nothing to compare it
against. Detecting that needs Azure's inventory, which means an authenticated
call to Azure from outside Terraform. `unmanaged-detect.yml` is written and
scheduled for exactly this, but **it is not running**: the platform SPN has no
GitHub federated credential and no client secret, so the job has no way to
authenticate. It is gated on `vars.AZURE_CLIENT_ID` and **skips rather than
fails**, so an unconfigured run looks identical to a clean one in the Actions
list. **Read the job summary, not the green tick.**

Turning it on needs no code change: set `vars.AZURE_CLIENT_ID` to a Reader
identity holding a federated credential for this repository, with
`AZURE_TENANT_ID` and `AZURE_SUBSCRIPTION_ID` alongside it.

Whether the committed configuration still agrees with state (a tfvars change
merged without an apply) is also not covered. A `terraform plan
-detailed-exitcode` answers it if that becomes worth watching.

Child resources are outside all of the above. Azure's inventory API does not
enumerate subnets, peerings, hub connections, route tables or private DNS vnet
links, so `unmanaged-detect.yml` lists them rather than diffing them — and in
this repo that is a large share of what is managed (315 of the 358 private-DNS
imports are vnet links). HCP's refresh-only drift detection is the only control
that sees a change to one, which is the main reason to turn it on.

**Prevention is the stronger control for the unmanaged-resource gap.** Azure
Policy on these resource groups, denying creation outside the pipeline or
requiring a `managed-by` tag, stops the gap forming rather than reporting it a
day later.

## Reports

- `PRE-APPLY-NOTES.md`: the tier-by-tier build record and what must be filled in before the first apply
- `ADDING-RESOURCES.md`: step by step for adding anything this workspace owns, and the order to do it in
- `REMEDIATION.md`: every divergence from wrapper defaults, why it matters, and what breaks if it's ever "corrected" carelessly
- `HANDOVER.md`: the management boundary (what Terraform owns and what it does not, with reasons and owners)
- `MODULE_GAPS.md`: wrapper and AVM defects this configuration works around
