# =====================================================================
# Shared inputs. subscription_id / tenant_id come from the provider
# environment (ARM_SUBSCRIPTION_ID / ARM_TENANT_ID).
#
# NOTE: connectivity is a large, multi-region (canadacentral + canadaeast)
# hub-and-spoke sub. This repo owns the network estate: resource groups, VNets,
# vWAN, gateways, private DNS, network primitives, spoke compute and alerts.
#
# The firewall estate -- Microsoft.Network/azureFirewalls, firewallPolicies and
# ipGroups, wherever they sit in this subscription -- is owned by
# tf-deploy-platform-firewall-management. It reads four of the resource groups
# declared here through data sources and manages the firewall objects inside
# them. See README.md, "The boundary".
# =====================================================================

variable "environment" {
  type    = string
  default = "Prod"
}

variable "location" {
  type    = string
  default = "canadacentral"
}

variable "tags" {
  type    = map(string)
  default = {}
}

variable "enable_amba" {
  type    = bool
  default = false
}

variable "root_management_group_name" {
  type    = string
  default = null
}

# --- Feature flags ------------------------------------------------------
variable "enable_resource_group" {
  type    = bool
  default = false
}

variable "enable_monitoring" {
  type        = bool
  description = "Deploy alerts via the amba-alz wrapper (action groups are external, in the management sub)."
  default     = false
}

# --- Resource groups ----------------------------------------------------
variable "resource_group" {
  type = map(object({
    name     = string
    location = optional(string)
    tags     = optional(map(string), {})
  }))
  default = {}
}
