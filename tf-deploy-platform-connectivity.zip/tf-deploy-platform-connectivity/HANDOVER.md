# Terraform scope and handover: Platform Subscription Connectivity

The management boundary for the network estate in subscription
`f3835bc1-9829-4ac8-9d7a-0999e0b29b90`: what Terraform owns, what it
deliberately does not, and what remains before the first apply.

**Status: pre-apply.** The tiers were built from an offline ARM/JSON export of
the live estate, then reconciled against two full CLI inventories
(2026-09-28 and 2026-10-05). Nothing has
been applied and nothing is in state. Sections 1–3 describe the intended
boundary; §4 is the list of things that must be settled first. **No section
here claims confirmation against a plan** — the inventories are the evidence,
and where they cannot answer a question the section says so.

## Contents

1. [Summary of the boundary](#1-summary-of-the-boundary)
2. [What Terraform owns](#2-what-terraform-owns)
3. [What Terraform does not own](#3-what-terraform-does-not-own)
4. [Open items before the first apply](#4-open-items-before-the-first-apply)
5. [The firewall split](#5-the-firewall-split)
6. [Repository and state locations](#6-repository-and-state-locations)
7. [Drift detection and monitoring](#7-drift-detection-and-monitoring)
8. [Reproducing the inventory](#8-reproducing-the-inventory)

## 1. Summary of the boundary

This repo owns the network estate: resource groups, VNets, vWAN, gateways,
private DNS, network primitives, spoke compute and alerts. **726 import
blocks.**

Three resource types are owned by `tf-deploy-platform-firewall-management`
instead, wherever they sit in this subscription:

- `Microsoft.Network/azureFirewalls`
- `Microsoft.Network/firewallPolicies`
- `Microsoft.Network/ipGroups`

The split is by **resource type, not by resource group**. All 12 resource
groups stay here. Four of them are read by the firewall repo through data
sources, and **a resource group name does not tell you who owns what is inside
it**:

| Resource group | This repo owns | Firewall repo owns |
|---|---|---|
| `rg-hub-connectivity-canadacentral-001` | vWAN hub, route tables, route maps, routing intent, gateways, storage | 1 firewall, 2 policies, 17 rule collection groups |
| `rg-hub-connectivity-canadaeast-001` | vWAN hub, gateways | 1 firewall |
| `rg-shared-connectivity-canadacentral-001` | VNet, subnets, public IP | 1 firewall (transit) |
| `rg-ip-groups-connectivity-global` | the resource group itself, and nothing in it | 193 IP groups |
| the other 8 | everything | nothing |

## 2. What Terraform owns

| Tier | File | Contents | Imports |
|---|---|---|---|
| Resource groups | `resource_group.tf` | 12 RGs across 2 regions | 12 |
| Standard alerts | `monitoring.tf`, `locals.tf` | Service-Outage (activity log), Resource-Creation and 2 storage-deletion (log search) | 4 |
| Private DNS | `private_dns_zones.tf`, `connectivity.tfvars` | 43 zones + 315 vnet links | 358 |
| Virtual networks | `virtual_network.tf` | 8 VNets, 14 subnets, 9 peerings | 31 |
| vWAN hub | `hub_vwan.tf` | vWAN, 2 hubs, 2 `noneRouteTable`s + 2 `private_traffic` routes, 17 route maps, 2 routing intents, 50 hub connections, 1 BGP connection, 2 ER gateways + 4 connections, 2 VPN gateways + 2 connections, 2 VPN sites | 89 |
| Network primitives | `net_primitives.tf` | DDoS, 3 NAT, 3 PIP prefixes, 2 PIPs, 11 NSGs (+33 rules), 2 route tables (+1 route), 8 private endpoints, 2 ER circuits (+2 peerings), 2 network watchers, 6 flow logs, 2 traffic collectors (+2 policies) | 80 |
| DNS resolver | `dns_resolver.tf` | resolver, inbound + outbound endpoints, forwarding ruleset + 62 rules | 66 |
| Spokes/compute | `spokes_compute.tf` | 6 VMs (4 Windows, 2 Linux) + 6 NICs, 4 Developer bastions, 3 SSH keys, 1 LB (+pool, 2 probes, 2 rules), 7 maintenance configs, recovery vault + 3 backup policies | 36 |
| Connectivity alerts | `conn_alerts.tf` | 19 metric, 16 log-search and 6 activity-log alerts, 2 action groups, 7 alert processing rules (declared here, created through `module.monitoring`) | 50 |

Most tiers go through `tf-wrapper-avm-*`. The exceptions are native, each for
a reason that would otherwise surface as a live change or a resource the
wrapper cannot hold:

| Native | Why not the wrapper |
|---|---|
| The whole vWAN tier | Only the ALZ *pattern* module exists for it; see `MODULE_GAPS.md`. |
| Public IPs (2) | `tf-wrapper-avm-public-ip-address` was deliberately removed (`WRAPPER-BACKLOG.md`). |
| Network watchers (2), flow logs (6) | The wrapper manages settings on an existing watcher and cannot create or adopt one. |
| Traffic collectors + policies | No azurerm resource; `azapi_resource`. |
| Load balancer (+pool, probes, rules) | Both live probes have `numberOfProbes = 1`; the wrapper validates `>= 2`, so adopting through it would change them. |
| Maintenance configurations (7) | The wrapper rejects hyphens; all seven live names have them and the name is ForceNew. |
| Backup policies (3) | Azure-created defaults in the vault; adopted as found. |

Route tables, SSH keys and bastion hosts moved onto their wrappers on
2026-09-27; alert processing rules moved onto
`tf-wrapper-avm-ptn-monitoring-amba-alz` 0.3.1, which added the input for them.

## 3. What Terraform does not own

### Owned by another repo, by design

| Object | Owner | Note |
|---|---|---|
| 3 Azure Firewalls, 2 firewall policies, 17 rule collection groups, 1 classic rule collection, 197 IP groups | `tf-deploy-platform-firewall-management` | HCP workspace `az-platform-firewall`. See §5. |
| `mid-azfirewall-canadacentral-001`, `kvfwtlscanadacentral` | `sub-identity-lz` | Identity subscription. Consumed by the firewall policy, not by anything here. |
| `la-siem-security-canadacentral-001` | security LZ | Security subscription (`7d54d6f7-…`). Referenced by flow-log traffic analytics here and by the firewall policy's insights there. |
| Management-subscription action groups (`ag-servicenow-alerts-…`, `ag-monitor-mail-alerts-…`, `ag-AzFW-alert-…`) | management LZ | Most alerts here reference them by ID. The only action groups this repo manages are the two Azure Backup created in `AzureBackupRG_canadacentral_1`. |

### Azure-managed, excluded on purpose

| Object | Why |
|---|---|
| `AzureBackupRG_canadacentral_1`, `DefaultResourceGroup-CCA`, `DefaultResourceGroup-CCAN`, `microsoft-network-canadacentral`, `microsoft-network-canadaeast` | Created and managed by Azure services. Excluded from `var.resource_group`. |
| `defaultRouteTable` on both hubs | Owned by routing intent, which writes its `_policy__*` routes. Declaring the table would fight the intent. Only its `private_traffic` route (routing intent's additional prefix, 142.52.0.0/16) is managed, as `azurerm_virtual_hub_route_table_route.private_traffic`. |
| `Microsoft.Compute/restorePointCollections`, `Microsoft.Compute/snapshots`, `microsoft.devtestlab/schedules`, VM OS disks | Service-managed or lifecycle artefacts of the VMs, not independently configured. |
| NSG `defaultSecurityRules` | Read-only; the API returns them but they cannot be declared or imported. This is why a portal view shows more rules than the 33 managed here. |

### Not owned by anything, and why

| Object | Why | What would change it |
|---|---|---|
| `azurerm_vpn_gateway_connection.shared_key` | The API does not return it, so any committed value would plan a change on every run. Omitted rather than set to a placeholder that diffs forever. | Nothing, at the provider level. Supply it out of band, or accept it is unmanaged. |
| `sttestingitout1` / `sttestingitout2` storage accounts, their EventGrid system topics, the `StorageAntimalwareSubscription` event subscriptions, and the blob/file/queue/table service configs | Ad-hoc test artefacts sitting in the alerts RG, not connectivity infrastructure. | Confirm with whoever created them, then delete. Until then they will show as unmanaged. |
| 56 diagnostic settings (NSGs, bastions, NICs, VNets, ER circuits, VPN/ER gateways, LB, vault, traffic collectors, storage) | Exported (`diagnostic-settings.txt` in the 2026-10-05 inventory), not yet built. Logs go to la-siem-security, metrics to la-siem-management. | Adopt here — this repo owns every parent resource. Item 3 in §4. |
| 12 `CanNotDelete` resource-group locks | Exported (`locks.json`), not yet built. `rg-dmz-…`, `rg-dns-…` and `rg-runners-…` have none. | 9 through the resource-group wrapper's `lock` input, 3 (on excluded RGs) native or left alone. Item 3 in §4. |
| Not yet onboarded: AMPLS `ampls-connectivity-canadacentral-001`; storage `stnwconncanadacentral`, `stnwconncanadaeast`, `stazfwpkcapture`; 6 CyberArk managed disks; ertest leftovers (`vm-testvm-canadacentral-001`, Logic App `vm_start_task`, 2 API connections); 40 VM extensions | Gaps found on 2026-09-28, still open on 2026-10-05. Wrappers exist for the storage accounts, disks and API connections. | Item 4 in §4. |
| RBAC role assignments | Do not appear in a resource listing, and `unmanaged-detect.yml` sees one only if that assignment is in state. Nothing here manages or monitors them. | Out of scope for this repo. |

## 4. Open items before the first apply

In the order they block progress.

1. **Run the speculative plan.** 726 imports. Expect tag additions only
   (`managed-by`, `module`, `solution`, `owner`; `Environment` and
   `CostCenterId` already match), plus whatever item 2 produces.
2. **Windows VM `admin_password`.** It is ForceNew on
   `azurerm_windows_virtual_machine`, Azure never returns it, and the AVM VM
   module (0.20.0) does not ignore it. The first plan may propose replacing the
   4 Windows VMs **whatever value is supplied**. If it does, the fix is
   `ignore_changes = [admin_password]` in the module, not a different password.
   Supply the value through `TF_VAR_spokes_vm_admin_password` regardless.
3. **Adopt the 56 diagnostic settings and 12 resource-group locks** (§3), and
   decide whether `rg-dmz-…`, `rg-dns-…` and `rg-runners-…` should get locks.
4. **Decide the not-yet-onboarded resources** listed in §3, and whether
   `pep-kvonboarding-prod-canadacentral-001` (Disconnected) stays or is deleted.
5. **Confirm two wrapper versions against the registry:**
   `tf-wrapper-avm-route-table` (pinned 0.3.0; goanywheremft pins 0.0.1) and
   `tf-wrapper-avm-virtual-network` (0.1.0).
6. **Configure required reviewers on the `connectivity` GitHub environment.**
   Without them `import-apply.yml` runs straight through with no approval stop.
7. **Decide whether to level out the tier gating** (`REMEDIATION.md`).

Settled, and recorded here so they are not reopened:

- **Spoke VNet IDs.** All 50 hub connections and all 9 VNet peerings carry the
  remote VNet IDs from the 2026-10-05 export. Both fields are ForceNew; the
  earlier placeholders would have recreated every one of them.
- **Flow-log SIEM workspace** — security subscription `7d54d6f7-…`, from the
  flow-log export.
- **`defaultRouteTable` vs routing intent** — routing intent owns the table (§3).
- **Alert processing rules** — managed, with the conditions two of them carry.
- **`enable_conn_alerts = true`**, so the 50 alert imports have targets.
- **Tags** — `Environment = "Prod"` and `CostCenterId = "80025906"` match the
  516 tagged resources in the subscription.

## 5. The firewall split

The firewall estate moved to `tf-deploy-platform-firewall-management` (HCP
workspace `az-platform-firewall`, same subscription). What moved:
`firewall.tf`, `pending_imports_firewall.tf`, `ip_groups.tf`,
`pending_imports_ip_groups.tf`, and the 89 IP groups out of the tfvars — 111
of the original 564 import blocks, leaving 453 here. Both repos have grown
since: 726 here, 228 there (197 IP groups) as of 2026-10-05.

The IP groups moved with the firewall because they are firewall-policy
fixtures: 301 references from the rules, and nothing else in the subscription
reads them. A rule change and the IP group it references change together.

### What it buys

1. A firewall rule change plans only the rules, not the VMs, 4 bastion hosts, 43 private DNS zones and 50 hub connections.
2. A firewall apply **cannot** touch the network. That workspace's state holds no VNet, hub or gateway, so no apply from it can modify or destroy one — whatever the plan says and whoever approves it. Stronger than a review process.
3. Separate approvers: the `firewall` environment can require a network security reviewer, `connectivity` a network platform reviewer.

### What it costs

The boundary is by type, and it is enforced in three places that have to stay
in step:

| Place | What it does |
|---|---|
| `data.tf` in the firewall repo | Reads 4 resource groups instead of managing them, so that workspace cannot retag or delete one. |
| `--exclude-type` × 3 in this repo's `unmanaged-detect.yml` | Keeps the firewall repo's 202 top-level resources out of this report. |
| `--scope-type` × 3 in the firewall repo's `unmanaged-detect.yml` | Restricts that report to exactly those types. |

The two filters are complements, so every top-level resource in the shared
groups is covered exactly once. **If the boundary moves, both lists have to move
together.** A type dropped from one and not added to the other stops being
checked by either, and nothing fails to tell you.

### What still crosses the boundary, and how

Nothing crosses through state. Two references are **constructed** resource IDs:

- `hub_vwan.tf`'s `local.hub_firewall_ids` — route next-hops pointing at the two hub firewalls.
- `conn_alerts.tf`'s `local.conn_alerts_azfw_cc_id` — the scope of `firewall-connectivity-health` and `firewall-connectivity-update`.

Both stay in this repo. The alerts watch the firewall rather than configure it,
and they belong with the rest of the alerts tier in
`rg-alerts-connectivity-canadacentral-001`.

**The firewall names are therefore the contract between the two repos.**
Renaming `azfw-connectivity-canadacentral-001` in the firewall repo breaks
these routes and alerts here, and because the IDs are strings rather than
references, Terraform will not say so — the route will point at a firewall that
no longer exists and the alerts will stop firing.

## 6. Repository and state locations

| | |
|---|---|
| Repository | `tf-deploy-platform-connectivity` |
| HCP organisation | `BC_Hydro` |
| HCP workspace | `az-platform-connectivity` |
| Subscription | `f3835bc1-9829-4ac8-9d7a-0999e0b29b90` |
| tfvars | `connectivity.tfvars` (was `terraform.tfvars`; renamed to match the sibling repos and to keep it out of Terraform's automatic loading) |
| Concurrency group | `sub-connectivity-lz` |
| Sibling workspace | `az-platform-firewall` (repo `tf-deploy-platform-firewall-management`) |

The concurrency group is deliberately not shared with the firewall pipelines.
The two workspaces own disjoint resources, so a concurrent plan is safe;
serialising them would only mean a rule change waits behind a spoke VM refresh.

`providers.tf` now declares its own `cloud` block. It previously carried a
commented-out `azurerm` backend, and `plan-and-verify.yml` generated the cloud
block at run time — which is why that workflow refused to run against a config
declaring one, and why it was removed rather than kept alongside
`import-verify.yml`.

## 7. Drift detection and monitoring

Three questions, three different answers:

| Question | Answered by | Status |
|---|---|---|
| A resource **in state** changed in Azure | HCP Terraform drift detection on `az-platform-connectivity` | **Enable it.** For this repo it is also the only control that sees a change to a child resource — subnets, peerings, hub connections, private DNS vnet links. |
| A resource exists in Azure with **no state entry** | `unmanaged-detect.yml` | **Written, scheduled, not running.** No federated credential for the platform SPN, so it skips on `vars.AZURE_CLIENT_ID`. It skips rather than fails — read the job summary, not the green tick. |
| The committed configuration still agrees with state | nothing | A `terraform plan -detailed-exitcode` answers it if it becomes worth watching. |

`unmanaged-detect.yml` excludes the three firewall types (§5). Without that it
would report 3 firewalls, 2 policies and 197 IP groups as unmanaged on every
run, which is how a report like this gets muted.

**Child resources are a large share of what this repo manages** — 315 of the
358 private-DNS imports are vnet links, and subnets, peerings and hub
connections are all children too. Azure's inventory API does not enumerate any
of them, so `unmanaged-detect.yml` lists them under "child resources in state,
not compared" rather than diffing them. That is the main reason HCP's
refresh-only drift detection matters more here than in the other landing zones.

Role assignments are outside all of the above (§3).

## 8. Reproducing the inventory

```bash
SUB=f3835bc1-9829-4ac8-9d7a-0999e0b29b90
az account set --subscription "$SUB"

# 1. top-level inventory -> compare against `terraform state list`.
#    The three firewall types belong to tf-deploy-platform-firewall-management.
az resource list --subscription "$SUB" \
  --query "[?type!='Microsoft.Network/azureFirewalls' && type!='Microsoft.Network/firewallPolicies' && type!='Microsoft.Network/ipGroups'].{name:name,type:type,rg:resourceGroup}" \
  -o table

# 2. child resources -- absent from the listing above, so enumerate per parent
az network vnet list --subscription "$SUB" --query "[].{vnet:name,subnets:length(subnets),peerings:length(virtualNetworkPeerings)}" -o table
az network private-dns zone list --subscription "$SUB" --query "[].{zone:name,links:numberOfVirtualNetworkLinks}" -o table
for h in vhub-connectivity-canadacentral-001:rg-hub-connectivity-canadacentral-001 \
         vhub-connectivity-canadaeast-001:rg-hub-connectivity-canadaeast-001; do
  n=${h%%:*}; g=${h##*:}
  echo "== $n"
  az network vhub connection list --vhub-name "$n" -g "$g" --query "[].name" -o tsv
done

# 3. diagnostic settings, per resource -- never in a resource listing
az resource list --subscription "$SUB" --query "[].id" -o tsv | while read -r id; do
  out=$(az monitor diagnostic-settings list --resource "$id" --query "[].name" -o tsv 2>/dev/null)
  [ -n "$out" ] && printf '%s\n  %s\n' "$id" "$out"
done

# 4. locks
az lock list --subscription "$SUB" -o table

# 5. policy assignments and exemptions, including those inherited from MGs
az policy assignment list --disable-scope-strict-match -o table
az policy exemption list --disable-scope-strict-match -o table

# 6. defaultRouteTable: only private_traffic is managed; the _policy__* routes are routing intent's
for h in vhub-connectivity-canadacentral-001:rg-hub-connectivity-canadacentral-001 \
         vhub-connectivity-canadaeast-001:rg-hub-connectivity-canadaeast-001; do
  n=${h%%:*}; g=${h##*:}
  echo "== $n"
  az network vhub route-table show --vhub-name "$n" -g "$g" -n defaultRouteTable \
    --query "routes[].{name:name,destinations:join(',',destinations)}" -o tsv
  az network vhub routing-intent list --vhub "$n" -g "$g" --query "[].name" -o tsv
done

# The complete export behind the 2026-10-05 reconciliation -- every resource with
# full properties, the child resources, diagnostic settings, locks, IP groups and
# firewall rules -- is scripts/export_full_inventory.sh (run it in Cloud Shell).
```
