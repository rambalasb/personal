# Remediation report: `tf-deploy-platform-connectivity`

Every place the live configuration differs from a wrapper's hardened default,
or from what a reader would assume, is written explicitly into
`connectivity.tfvars` or the tier's `.tf` file. That is what keeps a plan from
silently hardening a live system.

**Nothing here has been applied.** The divergences below were read off the
ARM/JSON export the tiers were built from and the two CLI inventories they were
reconciled against (2026-09-28, 2026-10-05), not confirmed by a plan. The
speculative plan is item 1 in `HANDOVER.md` §4.

## Values taken from the inventory, not reconstructed

Every remote VNet ID below is ForceNew. A reconstructed guess, however
plausible, would plan the connection or peering for replacement — a transit
outage for that spoke — so each one is copied from the inventory.

| Where | What | Was |
|---|---|---|
| `hub_vwan.tf` | `remote_virtual_network_id` on all 50 hub connections | 26 rebuilt under the hub RG (`# TODO spoke RG assumed`); none matched |
| `virtual_network.tf` | the canadaeast hub peering of `vnet-ertest-canadaeast-001` | wrong subscription and an `RG_…_TODO` resource group |
| `virtual_network.tf` | `peering-ns2-edge-to-bch-transit` → `cre-s4-pce-customer0057-edge` | assumed to sit in this subscription; it is in `bfd181ab-…` |
| `net_primitives.tf` | flow-log traffic-analytics workspace | subscription `00000000-…`; now the security subscription `7d54d6f7-…` |

## Tags: `Environment` and `CostCenterId`

`local.common_tags` writes `Environment = var.environment` (`Prod`), and
`connectivity.tfvars` sets `CostCenterId = "80025906"`. 516 resources in the
subscription carry exactly that pair.

- **Azure tag keys are case-insensitive.** A lowercase `environment` does not
  add a tag; it rewrites the live one, key casing and value (`Prod` → `prod`),
  and anything matching on `Prod` stops matching. The newer app repos use
  lowercase — **do not "normalise" to them** without deciding the retag
  deliberately, and move `tf-deploy-platform-firewall-management` with it.
- **`CostCenterId` must stay in `var.tags`.** Without it the first apply strips
  the cost-centre tag from every resource this repo manages.

## `defaultRouteTable` belongs to routing intent

Both hubs run routing intent, which writes the `defaultRouteTable`'s
`_policy__PublicTraffic` and `_policy__PrivateTraffic` routes itself. Declaring
the table as an `azurerm_virtual_hub_route_table` made Terraform rewrite routes
the intent owns. The table is no longer declared; the one route that is not the
intent's own, `private_traffic` (142.52.0.0/16, how Azure stores routing
intent's additional private prefixes), is managed alone as
`azurerm_virtual_hub_route_table_route.private_traffic`. Connections associate
with the table through `azurerm_virtual_hub.this[...].default_route_table_id`.

**Do not re-add `defaultRouteTable` to `hub_route_tables`** to "complete" the
tier; the conflict comes back with it.

## Fixed on the way out: the firewall split

Two defects were carried by the firewall tier while it lived in this repo. Both
are recorded here because the fix is in the other repo and a reader of this
one's history will otherwise wonder what happened to them.

### `enable_firewall` was never set, so 22 imports targeted nothing

`firewall.tf` declared `variable "enable_firewall" { default = false }`, and
`terraform.tfvars` never set it. The three firewalls and two policies were
therefore instantiated as empty maps — while `imports_firewall.tf` declared 22
`import{}` blocks pointing at those non-existent instances.

**That plan could not have succeeded.** An `import{}` block whose target does
not exist is a hard error, not a warning, so every plan of this repo would have
failed on the firewall tier before reaching the gate. `enable_ip_groups` *was*
set to `true`, which is why the 89 IP-group imports were fine and the fault
sat entirely in the firewall half.

`tf-deploy-platform-firewall-management` sets `enable_firewall = true` in
`firewall.tfvars`. Nothing needs doing here — the tier is gone — but if the
firewall is ever folded back in, the flag has to come with it.

### The SIEM workspace ID was built under the wrong subscription

`firewall.tf` built the firewall policy's insights workspace as
`"${local.sub}/resourceGroups/rg-siem-security-…"`. `local.sub` is *this*
subscription. The workspace lives in the **security** subscription, so the ID
resolved to a resource that does not exist and the policy's insights block
would have failed to apply. The line carried a `# TODO confirm` comment.

It is now `var.firewall_insights_workspace_id` in the firewall repo, with a
placeholder that fails the plan until it is set — which is the intended
behaviour rather than an oversight.

## Alerts: action groups are all external

Almost every alert references action groups in the **management**
subscription (`ccac6a90-8b47-44a9-88b2-520506c45219`) by resource ID. The two
action groups this repo does manage were created by Azure Backup in
`AzureBackupRG_canadacentral_1` (`ActionGroup_20260318T…`) and are referenced
by the Update Manager alerts.

**`ag-servicenow-alerts-canadacentral-001` has a leading space in its name**,
and the ID in `locals.tf` reproduces it. That is what live carries. Trimming it
is not a cleanup — the ID stops resolving and the alerts silently stop
notifying ServiceNow. If it is ever to be fixed, it has to be renamed in the
management subscription first.

`enable_amba = false`. The amba-alz wrapper is used for the four standard
alerts and the alert processing rules (`enable_monitoring = true`); the full
AMBA policy set is not deployed from here.

### Alert processing rules carry conditions

The seven suppression rules are declared in `conn_alerts.tf`
(`local.monitor_alert_processing_rules`) and created through
`module.monitoring`, because `tf-wrapper-avm-monitor-alerts` has no input for
them and `tf-wrapper-avm-ptn-monitoring-amba-alz` gained one in 0.3.1.

Two of them filter on conditions: `suppress-backup-alerts` (monitor condition
Fired/Resolved and alert rule name `Backup Alerts`) and `Alert-Suppression for
ExpressRouteCircuit` (five ERC alert rule names). **Both are disabled today.**
Dropping the conditions would not change anything now, but whoever re-enables
one would suppress every alert in its scope. Keep them in the config.

## Tier gating is inconsistent, on purpose for now

Four tiers are behind feature flags; five are not.

| Gated (flag, value in `connectivity.tfvars`) | Ungated (always instantiated) |
|---|---|
| `enable_resource_group` (true), `enable_monitoring` (true), `enable_private_dns_zones` (true), `enable_conn_alerts` (true), plus `enable_amba` (false) inside monitoring | `virtual_network.tf`, `hub_vwan.tf`, `net_primitives.tf`, `dns_resolver.tf`, `spokes_compute.tf` |

`enable_conn_alerts` defaults to `false` and was unset in the tfvars until
2026-09-27 — the same fault the firewall tier carried: 50 `import{}` blocks
pointing at instances that did not exist, which is a hard plan error.

The ungated tiers drive their `for_each` straight off a `local`, so the only
way to disable one is to empty the local. This is a real inconsistency rather
than a design: the flagged tiers were written first, when tiers were landing
one export at a time and being able to switch one off mattered. It is worth
levelling out — every tier gated, or none — but **not as part of the firewall
split**, because adding a flag that defaults to `false` to a tier that is
currently always on is exactly the mistake the firewall tier made above.

## Secrets and placeholders

| Value | Where | How it must be supplied |
|---|---|---|
| `var.spokes_vm_admin_password` | `spokes_compute.tf` | `TF_VAR_spokes_vm_admin_password` or a sensitive workspace variable. The repo placeholder is `REPLACE_ME_PLACEHOLDER`. Never commit it. |
| `azurerm_vpn_gateway_connection.shared_key` | `hub_vwan.tf` | Omitted entirely. The API does not return it, so any committed value diffs on every run. See `MODULE_GAPS.md`. |

## Zero-diff verification: what is suppressed, and what is not

### Suppressed: no write reaches Azure

The `--ignore-attr` list in both pipelines is `azapi_resource`'s config-only
knobs — `response_export_values`, `retry`, `timeouts`, the four `*_headers`,
`ignore_null_property`, `ignore_casing`, `ignore_missing_property`,
`schema_validation_enabled`, `read_query_parameters`. They are provider
behaviour, not Azure state, and `terraform import` leaves them null, so they
read as a diff on every azapi import. Needed here because the resource-group
and amba-alz wrappers are AzAPI-based.

`type` and `body` are deliberately **not** ignored — those are the payload
actually sent. `body` takes `--subset-attr` rather than a full ignore, so an
added key fails the gate while a key Azure returns but the configuration does
not set does not.

`modtm_telemetry`, `random_uuid` and `time_sleep` are ignored by type: the AVM
wrappers instantiate them for telemetry and sequencing, and none is an Azure
resource.

### Not suppressed, on purpose

No NSG rule, route, peering or DNS record attribute is waived. A diff in any of
those is a real difference between the export and live, and it needs reading
rather than suppressing.

## Expected on the first plan

Two kinds of diff are expected and are **not** grounds for suppression:

1. **Tag additions.** `managed-by`, `solution` and `owner` from `local.common_tags`, and `module` from the wrappers. `Environment` and `CostCenterId` already match. In-place and additive.
2. **Import addresses that do not exist.** Most of the 726 `import{}` blocks target inferred wrapper internals. A wrong address is a hard error that prints the right one; see `MODULE_GAPS.md`.

One diff may appear that **is** grounds to stop: a replacement of the four
Windows VMs on `admin_password` (`HANDOVER.md` §4 item 2). Do not approve it.
