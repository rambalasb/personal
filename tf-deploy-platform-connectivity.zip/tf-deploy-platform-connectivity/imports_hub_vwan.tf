# imports_hub_vwan.tf
# Virtual WAN hub tier. Native azurerm_ resources, so import addresses are direct.
# Child-resource ids (route tables, route maps, connections) assume the parent
# vhub/gateway names inferred from the ARM export; confirm on first plan.

import {
  to = azurerm_virtual_wan.this
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualWans/vwan-connectivity-canadacentral-001"
}
import {
  to = azurerm_virtual_hub.this["cc"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001"
}
import {
  to = azurerm_virtual_hub.this["ce"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadaeast-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadaeast-001"
}
import {
  to = azurerm_virtual_hub_route_table.this["cc-none"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/hubRouteTables/noneRouteTable"
}
import {
  to = azurerm_virtual_hub_route_table_route.private_traffic["cc"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/hubRouteTables/defaultRouteTable/routes/private_traffic"
}
import {
  to = azurerm_virtual_hub_route_table.this["ce-none"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadaeast-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadaeast-001/hubRouteTables/noneRouteTable"
}
import {
  to = azurerm_virtual_hub_route_table_route.private_traffic["ce"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadaeast-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadaeast-001/hubRouteTables/defaultRouteTable/routes/private_traffic"
}
import {
  to = azurerm_route_map.this["cc-Advertise-ER-Peerings"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/routeMaps/Advertise-ER-Peerings"
}
import {
  to = azurerm_route_map.this["cc-cloud-network-summarization"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/routeMaps/cloud-network-summarization"
}
import {
  to = azurerm_route_map.this["cc-Quebec-ER-RouteMap"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/routeMaps/Quebec-ER-RouteMap"
}
import {
  to = azurerm_route_map.this["cc-rm-rfc-inbound"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/routeMaps/rm-rfc-inbound"
}
import {
  to = azurerm_route_map.this["cc-Toronto-ER-RouteMap"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/routeMaps/Toronto-ER-RouteMap"
}
import {
  to = azurerm_route_map.this["cc-rm-quebec-outbound"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/routeMaps/rm-quebec-outbound"
}
import {
  to = azurerm_route_map.this["cc-rm-toronto-outbound"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/routeMaps/rm-toronto-outbound"
}
import {
  to = azurerm_route_map.this["cc-rm-vpn-inbound"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/routeMaps/rm-vpn-inbound"
}
import {
  to = azurerm_route_map.this["cc-rm-vpn-outbound"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/routeMaps/rm-vpn-outbound"
}
import {
  to = azurerm_route_map.this["ce-Advertise-ER-Peerings"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadaeast-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadaeast-001/routeMaps/Advertise-ER-Peerings"
}
import {
  to = azurerm_route_map.this["ce-cloud-network-summarization"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadaeast-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadaeast-001/routeMaps/cloud-network-summarization"
}
import {
  to = azurerm_route_map.this["ce-Quebec-ER-RouteMap"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadaeast-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadaeast-001/routeMaps/Quebec-ER-RouteMap"
}
import {
  to = azurerm_route_map.this["ce-Toronto-ER-RouteMap"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadaeast-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadaeast-001/routeMaps/Toronto-ER-RouteMap"
}
import {
  to = azurerm_route_map.this["ce-rm-quebec-outbound"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadaeast-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadaeast-001/routeMaps/rm-quebec-outbound"
}
import {
  to = azurerm_route_map.this["ce-rm-toronto-outbound"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadaeast-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadaeast-001/routeMaps/rm-toronto-outbound"
}
import {
  to = azurerm_route_map.this["ce-rm-vpn-inbound"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadaeast-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadaeast-001/routeMaps/rm-vpn-inbound"
}
import {
  to = azurerm_route_map.this["ce-rm-vpn-outbound"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadaeast-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadaeast-001/routeMaps/rm-vpn-outbound"
}
import {
  to = azurerm_virtual_hub_routing_intent.this["cc"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/routingIntent/defaultRouteTable"
}
import {
  to = azurerm_virtual_hub_routing_intent.this["ce"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadaeast-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadaeast-001/routingIntent/defaultRouteTable"
}
import {
  to = azurerm_virtual_hub_connection.this["peering-hub-to-auritas-nonprod-canadacentral-001"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/hubVirtualNetworkConnections/peering-hub-to-auritas-nonprod-canadacentral-001"
}
import {
  to = azurerm_virtual_hub_connection.this["peering-hub-to-auritas-prod-canadacentral-001"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/hubVirtualNetworkConnections/peering-hub-to-auritas-prod-canadacentral-001"
}
import {
  to = azurerm_virtual_hub_connection.this["peering-hub-to-cops-nonprod-canadacentral-001"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/hubVirtualNetworkConnections/peering-hub-to-cops-nonprod-canadacentral-001"
}
import {
  to = azurerm_virtual_hub_connection.this["peering-hub-to-cops-prod-canadacentral-001"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/hubVirtualNetworkConnections/peering-hub-to-cops-prod-canadacentral-001"
}
import {
  to = azurerm_virtual_hub_connection.this["peering-hub-to-cyberark-canadacentral-001"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/hubVirtualNetworkConnections/peering-hub-to-cyberark-canadacentral-001"
}
import {
  to = azurerm_virtual_hub_connection.this["peering-hub-to-dns-canadacentral-001"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/hubVirtualNetworkConnections/peering-hub-to-dns-canadacentral-001"
}
import {
  to = azurerm_virtual_hub_connection.this["peering-hub-to-ertest-connectivity-canadacentral-001"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/hubVirtualNetworkConnections/peering-hub-to-ertest-connectivity-canadacentral-001"
}
import {
  to = azurerm_virtual_hub_connection.this["peering-hub-to-fabric-nonprod-canadacentral-001"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/hubVirtualNetworkConnections/peering-hub-to-fabric-nonprod-canadacentral-001"
}
import {
  to = azurerm_virtual_hub_connection.this["peering-hub-to-fabric-prod-canadacentral-001"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/hubVirtualNetworkConnections/peering-hub-to-fabric-prod-canadacentral-001"
}
import {
  to = azurerm_virtual_hub_connection.this["peering-hub-to-fitnonprod-canadacentral-001"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/hubVirtualNetworkConnections/peering-hub-to-fitnonprod-canadacentral-001"
}
import {
  to = azurerm_virtual_hub_connection.this["peering-hub-to-fitprod-canadacentral-001"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/hubVirtualNetworkConnections/peering-hub-to-fitprod-canadacentral-001"
}
import {
  to = azurerm_virtual_hub_connection.this["peering-hub-to-mds-prod-canadacentral"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/hubVirtualNetworkConnections/peering-hub-to-mds-prod-canadacentral"
}
import {
  to = azurerm_virtual_hub_connection.this["peering-hub-to-mft-dev-canadacentral-001"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/hubVirtualNetworkConnections/peering-hub-to-mft-dev-canadacentral-001"
}
import {
  to = azurerm_virtual_hub_connection.this["peering-hub-to-openai-nonprod-canadacentral-001"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/hubVirtualNetworkConnections/peering-hub-to-openai-nonprod-canadacentral-001"
}
import {
  to = azurerm_virtual_hub_connection.this["peering-hub-to-openai-prod-canadacentral-001"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/hubVirtualNetworkConnections/peering-hub-to-openai-prod-canadacentral-001"
}
import {
  to = azurerm_virtual_hub_connection.this["peering-hub-to-pta-nonprod-canadacentral-001"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/hubVirtualNetworkConnections/peering-hub-to-pta-nonprod-canadacentral-001"
}
import {
  to = azurerm_virtual_hub_connection.this["peering-hub-to-pta-prod-canadacentral-001"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/hubVirtualNetworkConnections/peering-hub-to-pta-prod-canadacentral-001"
}
import {
  to = azurerm_virtual_hub_connection.this["peering-hub-to-runners-connectivity-canadacentral-001"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/hubVirtualNetworkConnections/peering-hub-to-runners-connectivity-canadacentral-001"
}
import {
  to = azurerm_virtual_hub_connection.this["peering-hub-to-shared-canadacentral-001"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/hubVirtualNetworkConnections/peering-hub-to-shared-canadacentral-001"
}
import {
  to = azurerm_virtual_hub_connection.this["peering-hub-to-spo-prod-canadacentral-001"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/hubVirtualNetworkConnections/peering-hub-to-spo-prod-canadacentral-001"
}
import {
  to = azurerm_virtual_hub_connection.this["peering-hub-to-transit-connectivity-canadacentral-001"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/hubVirtualNetworkConnections/peering-hub-to-transit-connectivity-canadacentral-001"
}
import {
  to = azurerm_virtual_hub_connection.this["peering-solace-vnet-connection"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/hubVirtualNetworkConnections/peering-solace-vnet-connection"
}
import {
  to = azurerm_virtual_hub_connection.this["Peering-spo-vnet-nonprod-Connection"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/hubVirtualNetworkConnections/Peering-spo-vnet-nonprod-Connection"
}
import {
  to = azurerm_virtual_hub_connection.this["peering-hub-to-ertest-connectivity-canadaeast-001"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadaeast-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadaeast-001/hubVirtualNetworkConnections/peering-hub-to-ertest-connectivity-canadaeast-001"
}
import {
  to = azurerm_virtual_hub_connection.this["peering-hub-to-spo-prod-canadaeast-001"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadaeast-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadaeast-001/hubVirtualNetworkConnections/peering-hub-to-spo-prod-canadaeast-001"
}
import {
  to = azurerm_virtual_hub_connection.this["peering-spo-nonprod-canadaeast-vnet-connection"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadaeast-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadaeast-001/hubVirtualNetworkConnections/peering-spo-nonprod-canadaeast-vnet-connection"
}
import {
  to = azurerm_virtual_hub_connection.this["peering-hub-to-pea-dev-canadacentral-001"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/hubVirtualNetworkConnections/peering-hub-to-pea-dev-canadacentral-001"
}
import {
  to = azurerm_virtual_hub_connection.this["peering-hub-to-dthree-dev-canadacentral-001"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/hubVirtualNetworkConnections/peering-hub-to-dthree-dev-canadacentral-001"
}
import {
  to = azurerm_virtual_hub_connection.this["peering-hub-to-ecsi-nonprod-canadacentral-001"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/hubVirtualNetworkConnections/peering-hub-to-ecsi-nonprod-canadacentral-001"
}
import {
  to = azurerm_virtual_hub_connection.this["peering-hub-to-boundary-test-canadacentral-001"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/hubVirtualNetworkConnections/peering-hub-to-boundary-test-canadacentral-001"
}
import {
  to = azurerm_virtual_hub_connection.this["peering-hub-to-finops-canadacentral-001"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/hubVirtualNetworkConnections/peering-hub-to-finops-canadacentral-001"
}
import {
  to = azurerm_virtual_hub_connection.this["peering-hub-to-wrap-test-canadacentral-001"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/hubVirtualNetworkConnections/peering-hub-to-wrap-test-canadacentral-001"
}
import {
  to = azurerm_virtual_hub_connection.this["peering-hub-to-safehub-dev-canadacentral-001"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/hubVirtualNetworkConnections/peering-hub-to-safehub-dev-canadacentral-001"
}
import {
  to = azurerm_virtual_hub_connection.this["peering-hub-to-cns-nonprod-canadacentral-001"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/hubVirtualNetworkConnections/peering-hub-to-cns-nonprod-canadacentral-001"
}
import {
  to = azurerm_virtual_hub_connection.this["peering-hub-to-lims-dev-canadacentral-001"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/hubVirtualNetworkConnections/peering-hub-to-lims-dev-canadacentral-001"
}
import {
  to = azurerm_virtual_hub_connection.this["peering-hub-to-cswt-test-canadacentral-001"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/hubVirtualNetworkConnections/peering-hub-to-cswt-test-canadacentral-001"
}
import {
  to = azurerm_virtual_hub_connection.this["peering-hub-to-gom-test-canadacentral-001"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/hubVirtualNetworkConnections/peering-hub-to-gom-test-canadacentral-001"
}
import {
  to = azurerm_virtual_hub_connection.this["peering-hub-to-cep-qas-canadacentral-001"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/hubVirtualNetworkConnections/peering-hub-to-cep-qas-canadacentral-001"
}
import {
  to = azurerm_virtual_hub_connection.this["peering-hub-to-cep-dev-canadacentral-001"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/hubVirtualNetworkConnections/peering-hub-to-cep-dev-canadacentral-001"
}
import {
  to = azurerm_virtual_hub_connection.this["peering-hub-to-citt-canadacentral-001"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/hubVirtualNetworkConnections/peering-hub-to-citt-canadacentral-001"
}
import {
  to = azurerm_virtual_hub_connection.this["peering-hub-to-cep-stg-canadacentral-001"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/hubVirtualNetworkConnections/peering-hub-to-cep-stg-canadacentral-001"
}
import {
  to = azurerm_virtual_hub_connection.this["Peering-vhub-connectivity-shipping-nonprod"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/hubVirtualNetworkConnections/Peering-vhub-connectivity-shipping-nonprod"
}
import {
  to = azurerm_virtual_hub_connection.this["peering-hub-to-sub-dmz-internal-nonprod-canadacentral-001"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/hubVirtualNetworkConnections/peering-hub-to-sub-dmz-internal-nonprod-canadacentral-001"
}
import {
  to = azurerm_virtual_hub_connection.this["peering-hub-to-cep-prod-canadacentral-001"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/hubVirtualNetworkConnections/peering-hub-to-cep-prod-canadacentral-001"
}
import {
  to = azurerm_virtual_hub_connection.this["peering-hub-to-dthree-prod-canadacentral-001"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/hubVirtualNetworkConnections/peering-hub-to-dthree-prod-canadacentral-001"
}
import {
  to = azurerm_virtual_hub_connection.this["peering-hub-to-solace-vnet-002"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/hubVirtualNetworkConnections/peering-hub-to-solace-vnet-002"
}
import {
  to = azurerm_virtual_hub_connection.this["peering-hub-to-ampl-test-canadacentral-001"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/hubVirtualNetworkConnections/peering-hub-to-ampl-test-canadacentral-001"
}
import {
  to = azurerm_virtual_hub_connection.this["peering-hub-to-mft-qas-canadacentral-001"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/hubVirtualNetworkConnections/peering-hub-to-mft-qas-canadacentral-001"
}
import {
  to = azurerm_virtual_hub_connection.this["peering-hub-to-mft-prod-canadacentral-001"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/hubVirtualNetworkConnections/peering-hub-to-mft-prod-canadacentral-001"
}
import {
  to = azurerm_virtual_hub_connection.this["peering-hub-to-sharedservices-prod-canadacentral-001"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/hubVirtualNetworkConnections/peering-hub-to-sharedservices-prod-canadacentral-001"
}
import {
  to = azurerm_virtual_hub_bgp_connection.this["bgp-peer-transit-connectivity-canadacentral-001"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001/bgpConnections/bgp-peer-transit-connectivity-canadacentral-001"
}
import {
  to = azurerm_express_route_gateway.this["cc"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/expressRouteGateways/ergw-connectivity-canadacentral-001"
}
import {
  to = azurerm_express_route_gateway.this["ce"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadaeast-001/providers/Microsoft.Network/expressRouteGateways/ergw-connectivity-canadaeast-001"
}
import {
  to = azurerm_express_route_connection.this["ExRConnection-canadacentral-1765413785995"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/expressRouteGateways/ergw-connectivity-canadacentral-001/expressRouteConnections/ExRConnection-canadacentral-1765413785995"
}
import {
  to = azurerm_express_route_connection.this["ExRConnection-canadacentral-1765415088995"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/expressRouteGateways/ergw-connectivity-canadacentral-001/expressRouteConnections/ExRConnection-canadacentral-1765415088995"
}
import {
  to = azurerm_express_route_connection.this["ExRConnection-canadaeast-1765215308956"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadaeast-001/providers/Microsoft.Network/expressRouteGateways/ergw-connectivity-canadaeast-001/expressRouteConnections/ExRConnection-canadaeast-1765215308956"
}
import {
  to = azurerm_express_route_connection.this["ExRConnection-canadaeast-1765412290836"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadaeast-001/providers/Microsoft.Network/expressRouteGateways/ergw-connectivity-canadaeast-001/expressRouteConnections/ExRConnection-canadaeast-1765412290836"
}
import {
  to = azurerm_vpn_site.this["cc"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/vpnSites/vsite-onprem-connectivity-canadacentral-001"
}
import {
  to = azurerm_vpn_site.this["ce"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadaeast-001/providers/Microsoft.Network/vpnSites/vsite-onprem-connectivity-canadaeast-001"
}
import {
  to = azurerm_vpn_gateway.this["cc"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/vpnGateways/vpn-connectivity-canadacentral-001"
}
import {
  to = azurerm_vpn_gateway.this["ce"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadaeast-001/providers/Microsoft.Network/vpnGateways/vpn-connectivity-canadaeast-001"
}
import {
  to = azurerm_vpn_gateway_connection.this["cc"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/vpnGateways/vpn-connectivity-canadacentral-001/vpnConnections/vconn-onprem-connectivity-canadacentral-001"
}
import {
  to = azurerm_vpn_gateway_connection.this["ce"]
  id = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadaeast-001/providers/Microsoft.Network/vpnGateways/vpn-connectivity-canadaeast-001/vpnConnections/vconn-onprem-connectivity-canadaeast-001"
}
