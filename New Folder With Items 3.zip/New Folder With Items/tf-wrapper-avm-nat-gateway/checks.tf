check "at_least_one_prefix_attached" {
  assert {
    condition     = local.prefix_count_v4 + local.prefix_count_v6 > 0
    error_message = "NAT Gateway has no public IP prefixes attached. Supply public_ip_prefix_resource_ids and/or public_ip_prefix_v6_resource_ids."
  }
}

check "ipv6_prefixes_require_standardv2" {
  assert {
    condition     = local.prefix_count_v6 == 0 || var.sku_name == "StandardV2"
    error_message = "IPv6 public IP prefixes are configured but sku_name is not 'StandardV2'. Switch SKU or remove the IPv6 prefixes."
  }
}

check "sku_is_modern" {
  assert {
    condition     = var.sku_name == "StandardV2"
    error_message = "NAT Gateway should use 'StandardV2' SKU for IPv6 support and zone-redundancy by default. Override deliberately if the legacy 'Standard' SKU is required."
  }
}

check "idle_timeout_in_recommended_range" {
  assert {
    condition     = var.idle_timeout_in_minutes >= 4 && var.idle_timeout_in_minutes <= 120
    error_message = "idle_timeout_in_minutes should be between 4 and 120."
  }
}
