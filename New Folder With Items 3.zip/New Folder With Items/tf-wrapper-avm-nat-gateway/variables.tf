# =====================================================================
# Required inputs
# =====================================================================

variable "name" {
  type        = string
  description = "The name of the NAT Gateway. 1-80 chars, alphanumerics, underscores, periods, hyphens. Must start with alphanumeric and end with alphanumeric or underscore."

  validation {
    condition     = can(regex("^[a-zA-Z0-9][a-zA-Z0-9._-]{0,78}[a-zA-Z0-9_]$", var.name))
    error_message = "name must be 1-80 characters, alphanumerics/underscores/periods/hyphens, start with alphanumeric and end with alphanumeric or underscore."
  }
}

variable "parent_id" {
  type        = string
  description = "Full Azure resource ID of the Resource Group where the NAT Gateway will be deployed (e.g. /subscriptions/<sub>/resourceGroups/<rg>)."

  validation {
    condition     = can(regex("^/subscriptions/[^/]+/resourceGroups/[^/]+$", var.parent_id))
    error_message = "parent_id must be a valid resource group ID (/subscriptions/<sub>/resourceGroups/<rg>)."
  }
}

variable "location" {
  type        = string
  description = "Azure region where the NAT Gateway will be deployed."

  validation {
    condition     = length(var.location) > 0
    error_message = "location must not be empty."
  }
}

# =====================================================================
# Public IP attachment — PREFIXES ONLY
# This wrapper enforces a "public IP prefixes only" policy. Standalone
# public IPs (created or attached) are deliberately not exposed.
# =====================================================================

variable "public_ip_prefix_resource_ids" {
  type        = set(string)
  description = "Set of existing IPv4 Public IP Prefix resource IDs to associate with the NAT Gateway. At least one IPv4 prefix is required (set IPv6-only deployments require this to be empty AND public_ip_prefix_v6_resource_ids to be non-empty with sku_name = StandardV2)."
  default     = []

  validation {
    condition = alltrue([
      for id in var.public_ip_prefix_resource_ids :
      can(regex("^/subscriptions/[^/]+/resourceGroups/[^/]+/providers/Microsoft\\.Network/publicIPPrefixes/[^/]+$", id))
    ])
    error_message = "Each public_ip_prefix_resource_ids entry must be a valid Microsoft.Network/publicIPPrefixes resource ID."
  }
}

variable "public_ip_prefix_v6_resource_ids" {
  type        = set(string)
  description = "Set of existing IPv6 Public IP Prefix resource IDs to associate with the NAT Gateway. Only supported when sku_name = StandardV2."
  default     = []

  validation {
    condition = alltrue([
      for id in var.public_ip_prefix_v6_resource_ids :
      can(regex("^/subscriptions/[^/]+/resourceGroups/[^/]+/providers/Microsoft\\.Network/publicIPPrefixes/[^/]+$", id))
    ])
    error_message = "Each public_ip_prefix_v6_resource_ids entry must be a valid Microsoft.Network/publicIPPrefixes resource ID."
  }
}

# =====================================================================
# Behavior
# =====================================================================

variable "sku_name" {
  type        = string
  description = "NAT Gateway SKU. 'Standard' or 'StandardV2'. Defaults to 'StandardV2'. IPv6 prefixes require 'StandardV2'."
  default     = "StandardV2"

  validation {
    condition     = contains(["Standard", "StandardV2"], var.sku_name)
    error_message = "sku_name must be 'Standard' or 'StandardV2'."
  }
}

variable "idle_timeout_in_minutes" {
  type        = number
  description = "TCP idle timeout in minutes. Between 4 and 120."
  default     = 4

  validation {
    condition     = var.idle_timeout_in_minutes >= 4 && var.idle_timeout_in_minutes <= 120
    error_message = "idle_timeout_in_minutes must be between 4 and 120."
  }
}

variable "zones" {
  type        = set(string)
  description = "Availability zones for the NAT Gateway. Ignored when sku_name = 'StandardV2' (zones default to all three). For 'Standard', set explicitly or leave null."
  default     = null

  validation {
    condition     = var.zones == null || alltrue([for z in coalesce(var.zones, []) : contains(["1", "2", "3"], z)])
    error_message = "Each zone must be '1', '2', or '3'."
  }
}

# =====================================================================
# Governance
# =====================================================================

variable "role_assignments" {
  type = map(object({
    role_definition_id_or_name             = string
    principal_id                           = string
    description                            = optional(string, null)
    skip_service_principal_aad_check       = optional(bool, false)
    condition                              = optional(string, null)
    condition_version                      = optional(string, null)
    delegated_managed_identity_resource_id = optional(string, null)
    principal_type                         = optional(string, null)
  }))
  description = "RBAC role assignments scoped to the NAT Gateway. Common roles: 'Network Contributor', 'Reader'."
  default     = {}
}

variable "lock" {
  type = object({
    kind = string
    name = optional(string, null)
  })
  description = "Optional resource lock. kind must be 'CanNotDelete' or 'ReadOnly'."
  default     = null

  validation {
    condition     = var.lock == null || contains(["CanNotDelete", "ReadOnly"], try(var.lock.kind, ""))
    error_message = "lock.kind must be 'CanNotDelete' or 'ReadOnly' when lock is set."
  }
}

# =====================================================================
# Diagnostics
# =====================================================================

variable "diagnostic_settings" {
  type = map(object({
    name = optional(string, null)
    logs = optional(set(object({
      category       = optional(string, null)
      category_group = optional(string, null)
      enabled        = optional(bool, true)
      retention_policy = optional(object({
        days    = optional(number, 0)
        enabled = optional(bool, false)
      }), {})
    })), [])
    metrics = optional(set(object({
      category = optional(string, null)
      enabled  = optional(bool, true)
      retention_policy = optional(object({
        days    = optional(number, 0)
        enabled = optional(bool, false)
      }), {})
    })), [])
    log_analytics_destination_type           = optional(string, "Dedicated")
    workspace_resource_id                    = optional(string, null)
    storage_account_resource_id              = optional(string, null)
    event_hub_authorization_rule_resource_id = optional(string, null)
    event_hub_name                           = optional(string, null)
    marketplace_partner_resource_id          = optional(string, null)
  }))
  description = "Diagnostic settings for the NAT Gateway. At least one destination per entry."
  default     = {}
}

# =====================================================================
# Module behavior
# =====================================================================

variable "enable_telemetry" {
  type        = bool
  description = "Whether to enable AVM module telemetry. Set false to opt out."
  default     = true
}

variable "tags" {
  type        = map(string)
  description = "A map of tags to apply to the NAT Gateway."
  default     = null
}

variable "timeouts" {
  type = object({
    create = optional(string)
    delete = optional(string)
    read   = optional(string)
    update = optional(string)
  })
  description = "Operation timeouts for the NAT Gateway resource."
  default     = null
}

# =====================================================================
# Cross-input validations (Terraform >= 1.9 allows referencing other vars)
# =====================================================================

# At least one prefix (v4 or v6) is required.
variable "_validate_at_least_one_prefix" {
  type        = bool
  description = "Internal sentinel — do not set."
  default     = true

  validation {
    condition     = length(var.public_ip_prefix_resource_ids) + length(var.public_ip_prefix_v6_resource_ids) > 0
    error_message = "At least one prefix is required. Supply public_ip_prefix_resource_ids (IPv4) and/or public_ip_prefix_v6_resource_ids (IPv6)."
  }
}

# IPv6 prefixes require sku_name = StandardV2.
variable "_validate_ipv6_requires_standardv2" {
  type        = bool
  description = "Internal sentinel — do not set."
  default     = true

  validation {
    condition     = length(var.public_ip_prefix_v6_resource_ids) == 0 || var.sku_name == "StandardV2"
    error_message = "IPv6 public IP prefixes require sku_name = 'StandardV2'."
  }
}
