locals {
  module_tags = merge(
    var.tags == null ? {} : var.tags,
    {
      managed-by = "terraform"
      module     = "tf-wrapper-avm-nat-gateway"
    }
  )

  prefix_count_v4 = length(var.public_ip_prefix_resource_ids)
  prefix_count_v6 = length(var.public_ip_prefix_v6_resource_ids)
}
