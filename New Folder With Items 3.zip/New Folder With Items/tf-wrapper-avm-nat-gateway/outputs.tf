output "resource_id" {
  description = "The Azure resource ID of the NAT Gateway."
  value       = module.nat_gateway.resource_id
}

output "resource" {
  description = "The full azapi_resource NAT Gateway object."
  value       = module.nat_gateway.resource
}

# Note: the upstream module's public_ip_resource output is intentionally not
# re-exported. This wrapper does not create standalone public IPs — all
# egress addresses come from caller-supplied public IP prefixes.
