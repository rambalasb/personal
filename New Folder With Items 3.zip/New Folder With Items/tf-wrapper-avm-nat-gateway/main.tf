module "nat_gateway" {
  source  = "Azure/avm-res-network-natgateway/azurerm"
  version = "0.3.2"

  # Required
  name      = var.name
  parent_id = var.parent_id
  location  = var.location

  # Public IP attachment — PREFIXES ONLY.
  # The four "non-prefix" inputs are hardcoded to empty so the upstream module
  # cannot create new Public IPs or attach loose Public IPs. This is the
  # mechanical enforcement of the wrapper's prefix-only policy.
  public_ip_prefix_resource_ids    = var.public_ip_prefix_resource_ids
  public_ip_prefix_v6_resource_ids = var.public_ip_prefix_v6_resource_ids
  public_ips                       = {}
  public_ip_configuration          = {}
  public_ip_resource_ids           = []
  public_ip_v6_resource_ids        = []

  # Behavior
  sku_name                = var.sku_name
  idle_timeout_in_minutes = var.idle_timeout_in_minutes
  zones                   = var.zones

  # Governance
  role_assignments = var.role_assignments
  lock             = var.lock

  # Diagnostics
  diagnostic_settings = var.diagnostic_settings

  # Module behavior
  enable_telemetry = var.enable_telemetry
  tags             = local.module_tags
  timeouts         = var.timeouts
}
