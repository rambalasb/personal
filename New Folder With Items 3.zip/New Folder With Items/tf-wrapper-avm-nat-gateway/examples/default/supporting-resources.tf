# random suffix to avoid name collisions on reruns
resource "random_string" "suffix" {
  length  = 6
  lower   = true
  upper   = false
  numeric = true
  special = false
}

# native supporting RG so the example tests standalone, without a sibling module
resource "azurerm_resource_group" "this" {
  name     = "rg-avm-natgw-default-test-${random_string.suffix.result}"
  location = "canadacentral"
}

# wrapper enforces prefix-only egress, so supply one IPv4 prefix to attach
resource "azurerm_public_ip_prefix" "this" {
  name                = "pipp-avm-natgw-default-test-${random_string.suffix.result}"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location
  prefix_length       = 30
}
