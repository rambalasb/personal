module "nat_gateway" {
  source = "../.."

  name      = "natgw-avm-default-test-${random_string.suffix.result}"
  parent_id = azurerm_resource_group.this.id
  location  = azurerm_resource_group.this.location

  public_ip_prefix_resource_ids = [azurerm_public_ip_prefix.this.id]

  enable_telemetry = false
}
