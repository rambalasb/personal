output "resource_id" {
  value = module.nat_gateway.resource_id
}

output "resource" {
  value = module.nat_gateway.resource
}

output "name" {
  value = module.nat_gateway.resource.name
}
