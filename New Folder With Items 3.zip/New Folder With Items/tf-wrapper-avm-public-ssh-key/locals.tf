locals {
  module_tags = merge(
    var.tags == null ? {} : var.tags,
    {
      managed-by = "terraform"
      module     = "tf-wrapper-avm-public-ssh-key"
    }
  )

  trimmed_public_key = trimspace(var.public_key)
  key_algorithm      = element(split(" ", local.trimmed_public_key), 0)
  key_algorithm_is_modern = contains(
    ["ssh-ed25519", "ecdsa-sha2-nistp256", "ecdsa-sha2-nistp384", "ecdsa-sha2-nistp521"],
    local.key_algorithm
  )
}
