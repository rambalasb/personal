# random suffix to avoid name collisions on reruns
resource "random_string" "suffix" {
  length  = 6
  lower   = true
  upper   = false
  numeric = true
  special = false
}

# native supporting RG so the example tests standalone, without a sibling module
resource "azurerm_resource_group" "this" {
  name     = "rg-avm-sshkey-default-test-${random_string.suffix.result}"
  location = "canadacentral"
}

# public_key is required and has no upstream default, so generate one to feed the module
resource "tls_private_key" "this" {
  algorithm = "RSA"
  rsa_bits  = 4096
}
