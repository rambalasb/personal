output "resource_id" {
  value = module.public_ssh_key.resource_id
}

output "resource" {
  value = module.public_ssh_key.resource
}

output "public_key_openssh" {
  value = tls_private_key.this.public_key_openssh
}
