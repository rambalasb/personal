module "public_ssh_key" {
  source = "../.."

  # name regex requires lowercase alphanumerics only, 5-64 chars
  name                = "sshkeydefault${random_string.suffix.result}"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location
  public_key          = tls_private_key.this.public_key_openssh

  enable_telemetry = false
}
