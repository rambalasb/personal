# =====================================================================
# Required inputs
# =====================================================================

variable "name" {
  type        = string
  description = "Name of the SSH Public Key resource. 5-64 characters, lowercase letters and numbers only (no hyphens, underscores, periods)."

  validation {
    condition     = can(regex("^[a-z0-9]{5,64}$", var.name))
    error_message = "name must be 5-64 characters, lowercase alphanumerics only."
  }
}

variable "resource_group_name" {
  type        = string
  description = "Name of the Resource Group where the SSH Public Key resource will be deployed."

  validation {
    condition     = length(var.resource_group_name) > 0 && length(var.resource_group_name) <= 90
    error_message = "resource_group_name must be 1-90 characters."
  }
}

variable "location" {
  type        = string
  description = "Azure region where the SSH Public Key resource will be deployed."

  validation {
    condition     = length(var.location) > 0
    error_message = "location must not be empty."
  }
}

variable "public_key" {
  type        = string
  description = "OpenSSH-formatted public key. RSA keys must be at least 2048 bits; ed25519 and ECDSA keys are also supported."

  validation {
    condition     = can(regex("^(ssh-rsa|ssh-ed25519|ecdsa-sha2-nistp256|ecdsa-sha2-nistp384|ecdsa-sha2-nistp521) [A-Za-z0-9+/=]+( .*)?$", trimspace(var.public_key)))
    error_message = "public_key must be an OpenSSH-formatted key starting with 'ssh-rsa', 'ssh-ed25519', or 'ecdsa-sha2-*' followed by a base64 blob."
  }
}

# =====================================================================
# Governance
# =====================================================================

variable "role_assignments" {
  type = map(object({
    role_definition_id_or_name             = string
    principal_id                           = string
    description                            = optional(string, null)
    skip_service_principal_aad_check       = optional(bool, false)
    condition                              = optional(string, null)
    condition_version                      = optional(string, null)
    delegated_managed_identity_resource_id = optional(string, null)
    principal_type                         = optional(string, null)
  }))
  description = "RBAC role assignments scoped to the SSH Public Key resource."
  default     = {}
}

variable "lock" {
  type = object({
    kind = string
    name = optional(string, null)
  })
  description = "Optional resource lock. kind must be 'CanNotDelete' or 'ReadOnly'."
  default     = null

  validation {
    condition     = var.lock == null || contains(["CanNotDelete", "ReadOnly"], try(var.lock.kind, ""))
    error_message = "lock.kind must be 'CanNotDelete' or 'ReadOnly' when lock is set."
  }
}

variable "managed_identities" {
  type = object({
    system_assigned            = optional(bool, false)
    user_assigned_resource_ids = optional(set(string), [])
  })
  description = "Managed identity configuration. Note: the upstream module flags this as unused — set values here have no effect on the SSH Public Key resource itself."
  default     = {}
}

# =====================================================================
# Module behavior
# =====================================================================

variable "enable_telemetry" {
  type        = bool
  description = "Whether to enable AVM module telemetry. Set false to opt out."
  default     = true
}

variable "tags" {
  type        = map(string)
  description = "A map of tags to apply to the SSH Public Key resource."
  default     = null
}
