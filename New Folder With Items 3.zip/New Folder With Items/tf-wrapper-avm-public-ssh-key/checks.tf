check "modern_key_algorithm_preferred" {
  assert {
    condition     = local.key_algorithm_is_modern
    error_message = "SSH public key uses '${local.key_algorithm}'. Prefer ed25519 or ecdsa-sha2-nistp256/384/521 over RSA for new keys."
  }
}

check "no_inline_comment_with_sensitive_info" {
  assert {
    condition     = !can(regex("(?i)(password|secret|token|api[_-]?key)", local.trimmed_public_key))
    error_message = "SSH public key value or its trailing comment appears to contain a sensitive keyword (password / secret / token / api_key). Review and remove."
  }
}
