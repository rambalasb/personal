module "public_ssh_key" {
  source  = "Azure/avm-res-compute-sshpublickey/azurerm"
  version = "0.1.0"

  # Required
  name                = var.name
  resource_group_name = var.resource_group_name
  location            = var.location
  public_key          = local.trimmed_public_key

  # Governance
  role_assignments   = var.role_assignments
  lock               = var.lock
  managed_identities = var.managed_identities

  # Module behavior
  enable_telemetry = var.enable_telemetry
  tags             = local.module_tags
}
