output "resource_id" {
  description = "The Azure resource ID of the SSH Public Key."
  value       = module.public_ssh_key.resource_id
}

output "resource" {
  description = "The full azurerm_ssh_public_key resource object."
  value       = module.public_ssh_key.resource
}
