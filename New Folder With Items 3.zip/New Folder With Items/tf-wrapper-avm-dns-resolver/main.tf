module "dns_resolver" {
  source  = "Azure/avm-res-network-dnsresolver/azurerm"
  version = "0.8.0"

  # Required
  name                        = var.name
  resource_group_name         = var.resource_group_name
  location                    = var.location
  virtual_network_resource_id = var.virtual_network_resource_id

  # Endpoints
  inbound_endpoints  = var.inbound_endpoints
  outbound_endpoints = var.outbound_endpoints

  # Governance
  role_assignments = var.role_assignments
  lock             = var.lock

  # Module behavior
  enable_telemetry = var.enable_telemetry
  tags             = local.module_tags
}
