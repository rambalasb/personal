check "has_at_least_one_endpoint" {
  assert {
    condition     = local.inbound_endpoint_count + local.outbound_endpoint_count > 0
    error_message = "DNS Resolver has neither inbound nor outbound endpoints. The resolver does nothing without them."
  }
}

check "inbound_endpoints_use_static_allocation" {
  assert {
    condition     = length(local.dynamic_inbound_endpoints) == 0
    error_message = "Inbound endpoint(s) [${join(", ", local.dynamic_inbound_endpoints)}] use Dynamic IP allocation. Prefer 'Static' with an explicit private_ip_address so consuming VNets can hardcode the resolver IP."
  }
}

check "outbound_endpoints_have_forwarding_rules" {
  assert {
    condition     = length(local.outbound_endpoints_without_rules) == 0
    error_message = "Outbound endpoint(s) [${join(", ", local.outbound_endpoints_without_rules)}] have no forwarding rules. An outbound endpoint without a forwarding ruleset + rules is dead weight — add rules or remove the endpoint."
  }
}
