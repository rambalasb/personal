# =====================================================================
# Required inputs
# =====================================================================

variable "name" {
  type        = string
  description = "Name of the Private DNS Resolver. 1-80 chars; cannot contain '#'."

  validation {
    condition     = length(var.name) > 0 && length(var.name) <= 80 && can(regex("^[^#]+$", var.name))
    error_message = "name must be 1-80 characters and must not contain '#'."
  }
}

variable "resource_group_name" {
  type        = string
  description = "Name of the Resource Group where the DNS Resolver will be deployed."

  validation {
    condition     = length(var.resource_group_name) > 0 && length(var.resource_group_name) <= 90
    error_message = "resource_group_name must be 1-90 characters."
  }
}

variable "location" {
  type        = string
  description = "Azure region where the DNS Resolver will be deployed."

  validation {
    condition     = length(var.location) > 0
    error_message = "location must not be empty."
  }
}

variable "virtual_network_resource_id" {
  type        = string
  description = "Resource ID of the Virtual Network the DNS Resolver attaches to. Must contain subnets delegated to 'Microsoft.Network/dnsResolvers' for any inbound/outbound endpoints."

  validation {
    condition     = can(regex("^/subscriptions/[^/]+/resourceGroups/[^/]+/providers/Microsoft\\.Network/virtualNetworks/[^/]+$", var.virtual_network_resource_id))
    error_message = "virtual_network_resource_id must be a valid Microsoft.Network/virtualNetworks resource ID."
  }
}

# =====================================================================
# Inbound endpoints — give the resolver a private IP others can query
# =====================================================================

variable "inbound_endpoints" {
  type = map(object({
    name                         = optional(string)
    subnet_name                  = string
    private_ip_allocation_method = optional(string, "Dynamic")
    private_ip_address           = optional(string, null)
    tags                         = optional(map(string), null)
    merge_with_module_tags       = optional(bool, true)
  }))
  description = <<DESC
Map of inbound endpoints to create. Each entry:
- subnet_name: subnet in var.virtual_network_resource_id that's delegated to Microsoft.Network/dnsResolvers/inboundEndpoints
- private_ip_allocation_method: 'Dynamic' (default) or 'Static'. Static is strongly recommended so consumers can hardcode the resolver IP.
- private_ip_address: required when private_ip_allocation_method = 'Static'
DESC
  default     = {}

  validation {
    condition = alltrue([
      for k, e in var.inbound_endpoints :
      contains(["Dynamic", "Static"], e.private_ip_allocation_method)
    ])
    error_message = "Each inbound_endpoints.*.private_ip_allocation_method must be 'Dynamic' or 'Static'."
  }

  validation {
    condition = alltrue([
      for k, e in var.inbound_endpoints :
      e.private_ip_allocation_method != "Static" || e.private_ip_address != null
    ])
    error_message = "Each inbound_endpoints entry with private_ip_allocation_method = 'Static' must also set private_ip_address."
  }

  validation {
    condition = alltrue([
      for k, e in var.inbound_endpoints :
      length(e.subnet_name) > 0
    ])
    error_message = "Each inbound_endpoints.*.subnet_name must not be empty."
  }
}

# =====================================================================
# Outbound endpoints — let the resolver forward queries elsewhere
# =====================================================================

variable "outbound_endpoints" {
  type = map(object({
    name                   = optional(string)
    tags                   = optional(map(string), null)
    merge_with_module_tags = optional(bool, true)
    subnet_name            = string
    forwarding_ruleset = optional(map(object({
      name                                                = optional(string)
      link_with_outbound_endpoint_virtual_network         = optional(bool, true)
      metadata_for_outbound_endpoint_virtual_network_link = optional(map(string), null)
      tags                                                = optional(map(string), null)
      merge_with_module_tags                              = optional(bool, true)
      additional_outbound_endpoint_link = optional(object({
        outbound_endpoint_key = optional(string)
      }), null)
      additional_virtual_network_links = optional(map(object({
        name     = optional(string)
        vnet_id  = string
        metadata = optional(map(string), null)
      })), {})
      rules = optional(map(object({
        name                     = optional(string)
        domain_name              = string
        destination_ip_addresses = map(string)
        enabled                  = optional(bool, true)
        metadata                 = optional(map(string), null)
      })))
    })))
  }))
  description = <<DESC
Map of outbound endpoints. Each entry:
- subnet_name: subnet delegated to Microsoft.Network/dnsResolvers/outboundEndpoints
- forwarding_ruleset (optional): nested map of forwarding rulesets, each with:
  - rules: map of forwarding rules (domain_name + destination_ip_addresses {ip = port})
  - additional_virtual_network_links: additional VNets the ruleset applies to
DESC
  default     = {}

  validation {
    condition = alltrue([
      for k, e in var.outbound_endpoints :
      length(e.subnet_name) > 0
    ])
    error_message = "Each outbound_endpoints.*.subnet_name must not be empty."
  }
}

# =====================================================================
# Governance
# =====================================================================

variable "role_assignments" {
  type = map(object({
    role_definition_id_or_name             = string
    principal_id                           = string
    description                            = optional(string, null)
    skip_service_principal_aad_check       = optional(bool, false)
    condition                              = optional(string, null)
    condition_version                      = optional(string, null)
    delegated_managed_identity_resource_id = optional(string, null)
    principal_type                         = optional(string, null)
  }))
  description = "RBAC role assignments scoped to the DNS Resolver. Common roles: 'Private DNS Zone Contributor', 'Reader'."
  default     = {}
}

variable "lock" {
  type = object({
    kind = string
    name = optional(string, null)
  })
  description = "Optional resource lock. kind must be 'CanNotDelete' or 'ReadOnly'."
  default     = null

  validation {
    condition     = var.lock == null || contains(["CanNotDelete", "ReadOnly"], try(var.lock.kind, ""))
    error_message = "lock.kind must be 'CanNotDelete' or 'ReadOnly' when set."
  }
}

# =====================================================================
# Module behavior
# =====================================================================

variable "enable_telemetry" {
  type        = bool
  description = "Whether to enable AVM module telemetry. Set false to opt out."
  default     = true
}

variable "tags" {
  type        = map(string)
  description = "Tags applied to the DNS Resolver and (when merge_with_module_tags = true) its child endpoints/rulesets."
  default     = null
}

# =====================================================================
# Cross-input validation (Terraform >= 1.9)
# =====================================================================

variable "_validate_at_least_one_endpoint" {
  type        = bool
  description = "Internal sentinel — do not set."
  default     = true

  validation {
    condition     = length(var.inbound_endpoints) + length(var.outbound_endpoints) > 0
    error_message = "DNS Resolver requires at least one inbound or outbound endpoint to be useful. Add an entry to var.inbound_endpoints or var.outbound_endpoints."
  }
}
