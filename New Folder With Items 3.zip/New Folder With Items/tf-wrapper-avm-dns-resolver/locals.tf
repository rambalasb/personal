locals {
  module_tags = merge(
    var.tags == null ? {} : var.tags,
    {
      managed-by = "terraform"
      module     = "tf-wrapper-avm-dns-resolver"
    }
  )

  inbound_endpoint_count  = length(var.inbound_endpoints)
  outbound_endpoint_count = length(var.outbound_endpoints)

  # Inbound endpoints with Dynamic allocation (Static is recommended for stable resolver IPs)
  dynamic_inbound_endpoints = [
    for k, e in var.inbound_endpoints : k if e.private_ip_allocation_method == "Dynamic"
  ]

  # Outbound endpoints with no forwarding rules — a forwarder with no rules is dead weight.
  outbound_endpoints_without_rules = [
    for k, e in var.outbound_endpoints : k
    if e.forwarding_ruleset == null || alltrue([
      for rsk, rs in coalesce(e.forwarding_ruleset, {}) :
      rs.rules == null || length(coalesce(rs.rules, {})) == 0
    ])
  ]
}
