output "resource_id" {
  description = "The Azure resource ID of the DNS Resolver."
  value       = module.dns_resolver.resource_id
}

output "name" {
  description = "The name of the DNS Resolver."
  value       = module.dns_resolver.name
}

output "resource" {
  description = "The full azurerm_private_dns_resolver resource object."
  value       = module.dns_resolver.resource
}

output "inbound_endpoints" {
  description = "Map of inbound endpoints created on the resolver."
  value       = module.dns_resolver.inbound_endpoints
}

output "inbound_endpoint_ips" {
  description = "Map of inbound endpoint key to the assigned private IP. Use these IPs to point consuming VNets at the resolver."
  value       = module.dns_resolver.inbound_endpoint_ips
}

output "outbound_endpoints" {
  description = "Map of outbound endpoints created on the resolver."
  value       = module.dns_resolver.outbound_endpoints
}

output "forwarding_rulesets" {
  description = "Map of DNS forwarding rulesets created under outbound endpoints."
  value       = module.dns_resolver.forwarding_rulesets
}
