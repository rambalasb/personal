output "resource_id" {
  value = module.dns_resolver.resource_id
}

output "name" {
  value = module.dns_resolver.name
}

output "inbound_endpoint_ips" {
  value = module.dns_resolver.inbound_endpoint_ips
}
