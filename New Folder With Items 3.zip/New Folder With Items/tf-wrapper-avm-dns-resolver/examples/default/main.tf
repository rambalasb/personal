module "dns_resolver" {
  source = "../.."

  name                        = "dnspr-avm-${random_string.suffix.result}"
  resource_group_name         = azurerm_resource_group.this.name
  location                    = azurerm_resource_group.this.location
  virtual_network_resource_id = azurerm_virtual_network.this.id

  # at least one endpoint is required; static IP so consumers can hardcode it
  inbound_endpoints = {
    primary = {
      subnet_name                  = azurerm_subnet.inbound.name
      private_ip_allocation_method = "Static"
      private_ip_address           = "10.0.0.4"
    }
  }

  enable_telemetry = false
}
