output "resource_id" {
  description = "The Azure resource ID of the Public IP Prefix."
  value       = module.public_ip_prefix.resource_id
}

output "public_ip_prefix_address" {
  description = "The actual CIDR allocated by Azure for this Public IP Prefix (e.g. '52.226.0.0/28')."
  value       = module.public_ip_prefix.public_ip_prefix_address
}

output "resource" {
  description = "The full azurerm_public_ip_prefix resource object."
  value       = module.public_ip_prefix.resource
}
