module "public_ip_prefix" {
  source  = "Azure/avm-res-network-publicipprefix/azurerm"
  version = "0.1.0"

  # Required
  name                = var.name
  resource_group_name = var.resource_group_name
  location            = var.location
  prefix_length       = var.prefix_length

  # Defaulted toggles
  sku_name   = var.sku_name
  sku_tier   = var.sku_tier
  ip_version = var.ip_version
  zones      = var.zones

  # Governance
  lock = var.lock

  # Module behavior
  enable_telemetry = var.enable_telemetry
  tags             = local.module_tags
}
