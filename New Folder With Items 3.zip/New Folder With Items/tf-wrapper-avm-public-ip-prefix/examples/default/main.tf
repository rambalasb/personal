module "public_ip_prefix" {
  source = "../.."

  name                = "pipprefix-avm-default-test-${random_string.suffix.result}"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location
  prefix_length       = 30

  enable_telemetry = false
}
