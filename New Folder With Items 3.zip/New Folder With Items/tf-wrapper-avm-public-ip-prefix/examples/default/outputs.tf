output "resource_id" {
  value = module.public_ip_prefix.resource_id
}

output "public_ip_prefix_address" {
  value = module.public_ip_prefix.public_ip_prefix_address
}

output "resource" {
  value = module.public_ip_prefix.resource
}
