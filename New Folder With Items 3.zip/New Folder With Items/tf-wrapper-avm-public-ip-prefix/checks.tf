check "sku_is_standard" {
  assert {
    condition     = var.sku_name == "Standard"
    error_message = "Public IP Prefix SKU is '${var.sku_name}'. Basic SKU is being retired by Azure (September 30, 2025) — prefer 'Standard'."
  }
}

check "sku_tier_is_regional_for_most_workloads" {
  assert {
    condition     = var.sku_tier == "Regional"
    error_message = "Public IP Prefix sku_tier is 'Global'. Global tier is rarely needed and incompatible with several Azure services (NAT Gateway, Standard LB). Override deliberately for cross-region anycast scenarios only."
  }
}

check "address_count_within_reasonable_range" {
  assert {
    condition     = local.address_count <= 16
    error_message = "Public IP Prefix allocates ${local.address_count} addresses (prefix /${var.prefix_length}). Sizes larger than /28 (16 IPs) are unusual and may require Azure subscription quota approval. Confirm intent."
  }
}

check "zonal_redundancy" {
  assert {
    condition     = length(var.zones) >= 2 || length(var.zones) == 0
    error_message = "Public IP Prefix is configured with ${length(var.zones)} zone(s). For zonal resilience, use 2 or more zones. Set zones = [] to opt out of zonal placement (regions without zones)."
  }
}
