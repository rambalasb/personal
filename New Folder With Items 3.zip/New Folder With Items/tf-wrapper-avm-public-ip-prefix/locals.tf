locals {
  module_tags = merge(
    var.tags == null ? {} : var.tags,
    {
      managed-by = "terraform"
      module     = "tf-wrapper-avm-public-ip-prefix"
    }
  )

  # 2^(32 - prefix_length) for IPv4 or 2^(128 - prefix_length) for IPv6
  address_count = var.ip_version == "IPv4" ? pow(2, 32 - var.prefix_length) : pow(2, 128 - var.prefix_length)
}
