# =====================================================================
# Required inputs
# =====================================================================

variable "name" {
  type        = string
  description = "Name of the Public IP Prefix. 1-80 chars; alphanumerics, underscores, periods, hyphens. Must start with alphanumeric and end with alphanumeric or underscore."

  validation {
    condition     = can(regex("^[a-zA-Z0-9][a-zA-Z0-9._-]{0,78}[a-zA-Z0-9_]$", var.name))
    error_message = "name must be 1-80 characters, alphanumerics/underscores/periods/hyphens, start with alphanumeric, end with alphanumeric or underscore."
  }
}

variable "resource_group_name" {
  type        = string
  description = "Name of the Resource Group where the Public IP Prefix will be deployed."

  validation {
    condition     = length(var.resource_group_name) > 0 && length(var.resource_group_name) <= 90
    error_message = "resource_group_name must be 1-90 characters."
  }
}

variable "location" {
  type        = string
  description = "Azure region where the Public IP Prefix will be deployed."

  validation {
    condition     = length(var.location) > 0
    error_message = "location must not be empty."
  }
}

variable "prefix_length" {
  type        = number
  description = "Number of bits in the prefix. Smaller numbers reserve more IPs. For IPv4: 28 (16 IPs, default size) to 31 (2 IPs). For IPv6: 124 (16 IPs) to 127 (2 IPs)."

  validation {
    condition     = var.prefix_length >= 0 && var.prefix_length <= 127
    error_message = "prefix_length must be between 0 and 127. Typical IPv4 values: 28-31. Typical IPv6 values: 124-127."
  }
}

# =====================================================================
# Defaulted toggles
# =====================================================================

variable "sku_name" {
  type        = string
  description = "Public IP Prefix SKU. 'Standard' or 'Basic'. Basic is being retired by Azure — prefer 'Standard'."
  default     = "Standard"

  validation {
    condition     = contains(["Standard", "Basic"], var.sku_name)
    error_message = "sku_name must be 'Standard' or 'Basic'."
  }
}

variable "sku_tier" {
  type        = string
  description = "Public IP Prefix SKU tier. 'Regional' or 'Global'. Defaults to 'Regional'. Changing this forces a new resource."
  default     = "Regional"

  validation {
    condition     = contains(["Regional", "Global"], var.sku_tier)
    error_message = "sku_tier must be 'Regional' or 'Global'."
  }
}

variable "ip_version" {
  type        = string
  description = "IP version. 'IPv4' or 'IPv6'. Defaults to 'IPv4'. Changing this forces a new resource."
  default     = "IPv4"

  validation {
    condition     = contains(["IPv4", "IPv6"], var.ip_version)
    error_message = "ip_version must be 'IPv4' or 'IPv6'."
  }
}

variable "zones" {
  type        = set(string)
  description = "Availability zones for the prefix. Defaults to all three zones. Set to empty set ([]) for non-zonal regions."
  default     = ["1", "2", "3"]

  validation {
    condition     = alltrue([for z in var.zones : contains(["1", "2", "3"], z)])
    error_message = "Each zone must be '1', '2', or '3'."
  }
}

# =====================================================================
# Governance
# =====================================================================

variable "lock" {
  type = object({
    kind = string
    name = optional(string, null)
  })
  description = "Optional resource lock. kind must be 'CanNotDelete' or 'ReadOnly'."
  default     = null

  validation {
    condition     = var.lock == null || contains(["CanNotDelete", "ReadOnly"], try(var.lock.kind, ""))
    error_message = "lock.kind must be 'CanNotDelete' or 'ReadOnly' when lock is set."
  }
}

# =====================================================================
# Module behavior
# =====================================================================

variable "enable_telemetry" {
  type        = bool
  description = "Whether to enable AVM module telemetry. Set false to opt out."
  default     = true
}

variable "tags" {
  type        = map(string)
  description = "A map of tags to apply to the Public IP Prefix."
  default     = null
}

# =====================================================================
# Cross-input validation
# =====================================================================

variable "_validate_ipv4_prefix_length" {
  type        = bool
  description = "Internal sentinel — do not set."
  default     = true

  validation {
    condition     = var.ip_version != "IPv4" || (var.prefix_length >= 0 && var.prefix_length <= 31)
    error_message = "For IPv4, prefix_length must be between 0 and 31 (typical range 28-31)."
  }
}

variable "_validate_ipv6_prefix_length" {
  type        = bool
  description = "Internal sentinel — do not set."
  default     = true

  validation {
    condition     = var.ip_version != "IPv6" || (var.prefix_length >= 124 && var.prefix_length <= 127)
    error_message = "For IPv6, prefix_length must be between 124 and 127."
  }
}

variable "_validate_ipv6_requires_standard_sku" {
  type        = bool
  description = "Internal sentinel — do not set."
  default     = true

  validation {
    condition     = var.ip_version != "IPv6" || var.sku_name == "Standard"
    error_message = "IPv6 Public IP Prefixes require sku_name = 'Standard'."
  }
}
