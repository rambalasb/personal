module "windows_vm" {
  source  = "Azure/avm-res-compute-virtualmachine/azurerm"
  version = "0.20.0"

  # OS pinned by this wrapper — never expose os_type as a variable.
  os_type = "Windows"

  # Required
  name                = var.name
  resource_group_name = var.resource_group_name
  location            = var.location
  zone                = var.zone
  network_interfaces  = var.network_interfaces

  # Credentials — translated to the AVM shape; passwords are accepted.
  account_credentials = local.account_credentials_avm

  # Image
  source_image_reference   = var.source_image_resource_id == null ? var.source_image_reference : null
  source_image_resource_id = var.source_image_resource_id

  # Size & disks
  sku_size                 = var.sku_size
  os_disk                  = var.os_disk
  data_disk_managed_disks  = var.data_disk_managed_disks
  data_disk_existing_disks = var.data_disk_existing_disks
  disk_controller_type     = var.disk_controller_type

  # Security
  secure_boot_enabled        = var.secure_boot_enabled
  vtpm_enabled               = var.vtpm_enabled
  encryption_at_host_enabled = var.encryption_at_host_enabled

  # Identity & RBAC
  managed_identities                       = var.managed_identities
  role_assignments                         = var.role_assignments
  role_assignments_system_managed_identity = var.role_assignments_system_managed_identity

  # Extensions, backup, schedules, public IP, secrets, gallery apps, run commands
  extensions                             = var.extensions
  azure_backup_configurations            = var.azure_backup_configurations
  shutdown_schedules                     = var.shutdown_schedules
  public_ip_configuration_details        = var.public_ip_configuration_details
  maintenance_configuration_resource_ids = var.maintenance_configuration_resource_ids
  secrets                                = var.secrets
  gallery_applications                   = var.gallery_applications
  run_commands                           = var.run_commands
  run_commands_secrets                   = var.run_commands_secrets

  # Windows-specific
  winrm_listeners              = var.winrm_listeners
  additional_unattend_contents = var.additional_unattend_contents
  enable_automatic_updates     = var.enable_automatic_updates
  hotpatching_enabled          = var.hotpatching_enabled
  timezone                     = var.timezone

  # Diagnostics, boot, lock, tags, telemetry
  diagnostic_settings                  = var.diagnostic_settings
  boot_diagnostics                     = var.boot_diagnostics
  boot_diagnostics_storage_account_uri = var.boot_diagnostics_storage_account_uri
  lock                                 = var.lock
  tags                                 = local.module_tags
  enable_telemetry                     = var.enable_telemetry

  # Long-tail toggles
  custom_data                                            = var.custom_data
  user_data                                              = var.user_data
  computer_name                                          = var.computer_name
  allow_extension_operations                             = var.allow_extension_operations
  availability_set_resource_id                           = var.availability_set_resource_id
  capacity_reservation_group_resource_id                 = var.capacity_reservation_group_resource_id
  dedicated_host_group_resource_id                       = var.dedicated_host_group_resource_id
  dedicated_host_resource_id                             = var.dedicated_host_resource_id
  edge_zone                                              = var.edge_zone
  eviction_policy                                        = var.eviction_policy
  extensions_time_budget                                 = var.extensions_time_budget
  license_type                                           = var.license_type
  max_bid_price                                          = var.max_bid_price
  patch_assessment_mode                                  = var.patch_assessment_mode
  platform_fault_domain                                  = var.platform_fault_domain
  plan                                                   = var.plan
  priority                                               = var.priority
  provision_vm_agent                                     = var.provision_vm_agent
  proximity_placement_group_resource_id                  = var.proximity_placement_group_resource_id
  reboot_setting                                         = var.reboot_setting
  termination_notification                               = var.termination_notification
  timeouts                                               = var.timeouts
  virtual_machine_scale_set_resource_id                  = var.virtual_machine_scale_set_resource_id
  vm_additional_capabilities                             = var.vm_additional_capabilities
  bypass_platform_safety_checks_on_user_schedule_enabled = var.bypass_platform_safety_checks_on_user_schedule_enabled
}
