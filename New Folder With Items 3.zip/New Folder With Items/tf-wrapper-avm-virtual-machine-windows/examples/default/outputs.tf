output "resource_id" {
  value = module.virtual_machine_windows.resource_id
}

output "name" {
  value = module.virtual_machine_windows.name
}

output "admin_password" {
  value     = module.virtual_machine_windows.admin_password
  sensitive = true
}
