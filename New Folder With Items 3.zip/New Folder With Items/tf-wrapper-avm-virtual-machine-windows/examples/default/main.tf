module "virtual_machine_windows" {
  source = "../.."

  # computer name defaults to var.name, so keep it <= 15 chars
  name                = "vmw-${random_string.suffix.result}"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location
  zone                = "1"

  sku_size = "Standard_B2s"

  source_image_reference = {
    publisher = "MicrosoftWindowsServer"
    offer     = "WindowsServer"
    sku       = "2022-datacenter-azure-edition"
    version   = "latest"
  }

  os_disk = {
    caching              = "ReadWrite"
    storage_account_type = "Standard_LRS"
  }

  # password supplied explicitly so no auto-generation is needed
  account_credentials = {
    admin_credentials = {
      username                           = "azureadmin"
      password                           = random_password.admin.result
      generate_admin_password_or_ssh_key = false
    }
  }

  network_interfaces = {
    primary = {
      name = "nic-vmw-${random_string.suffix.result}"
      ip_configurations = {
        ipconfig1 = {
          name                          = "ipconfig1"
          private_ip_subnet_resource_id = azurerm_subnet.this.id
        }
      }
    }
  }

  enable_telemetry = false
}
