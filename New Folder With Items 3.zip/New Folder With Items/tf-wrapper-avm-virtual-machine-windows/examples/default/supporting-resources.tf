# random suffix to avoid name collisions on reruns
resource "random_string" "suffix" {
  length  = 6
  lower   = true
  upper   = false
  numeric = true
  special = false
}

# native supporting RG so the example tests standalone, without a sibling module
resource "azurerm_resource_group" "this" {
  name     = "rg-avm-vmwin-default-test-${random_string.suffix.result}"
  location = "canadacentral"
}

# vnet + subnet to back the VM's NIC
resource "azurerm_virtual_network" "this" {
  name                = "vnet-vmwin-default"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location
  address_space       = ["10.0.0.0/16"]
}

resource "azurerm_subnet" "this" {
  name                 = "snet-default"
  resource_group_name  = azurerm_resource_group.this.name
  virtual_network_name = azurerm_virtual_network.this.name
  address_prefixes     = ["10.0.1.0/24"]
}

# Windows admin password — generated rather than hardcoded
resource "random_password" "admin" {
  length  = 20
  special = true
}
