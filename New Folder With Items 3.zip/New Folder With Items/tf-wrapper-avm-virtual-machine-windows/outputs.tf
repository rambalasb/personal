output "resource_id" {
  description = "The Azure resource ID of the Windows VM."
  value       = module.windows_vm.resource_id
}

output "name" {
  description = "The name of the Windows VM."
  value       = module.windows_vm.name
}

output "resource" {
  description = "The full azurerm_windows_virtual_machine resource. Sensitive."
  value       = module.windows_vm.resource
  sensitive   = true
}

output "admin_username" {
  description = "The admin username configured on the VM."
  value       = module.windows_vm.admin_username
}

output "admin_password" {
  description = "The admin password (auto-generated unless supplied). Sensitive."
  value       = module.windows_vm.admin_password
  sensitive   = true
}

output "network_interfaces" {
  description = "Map of deployed NICs."
  value       = module.windows_vm.network_interfaces
}

output "public_ips" {
  description = "Map of deployed public IPs."
  value       = module.windows_vm.public_ips
}

output "data_disks" {
  description = "Map of deployed data disks."
  value       = module.windows_vm.data_disks
}

output "system_assigned_mi_principal_id" {
  description = "Principal ID of the system-assigned managed identity, if enabled."
  value       = module.windows_vm.system_assigned_mi_principal_id
}

output "virtual_machine_azurerm" {
  description = "Map of standard azurerm Windows VM attributes (id, identity, private/public IPs, virtual_machine_id)."
  value       = module.windows_vm.virtual_machine_azurerm
}
