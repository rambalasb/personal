check "secure_boot_enabled" {
  assert {
    condition     = var.secure_boot_enabled == true
    error_message = "Windows VMs should have Trusted Launch secure_boot enabled."
  }
}

check "vtpm_enabled" {
  assert {
    condition     = var.vtpm_enabled == true
    error_message = "Windows VMs should have Trusted Launch vTPM enabled."
  }
}

check "encryption_at_host_enabled" {
  assert {
    condition     = var.encryption_at_host_enabled == true
    error_message = "Windows VMs should have encryption_at_host_enabled = true."
  }
}

check "at_least_one_network_interface" {
  assert {
    condition     = length(var.network_interfaces) >= 1
    error_message = "Windows VM has no network interfaces defined."
  }
}

check "winrm_https_when_listener_configured" {
  assert {
    condition     = length(var.winrm_listeners) == 0 || alltrue([for l in var.winrm_listeners : l.protocol == "Https"])
    error_message = "WinRM listeners should use Https only. Http listeners expose management traffic in plaintext."
  }
}
