locals {
  module_tags = merge(
    var.tags == null ? {} : var.tags,
    {
      managed-by = "terraform"
      module     = "tf-wrapper-avm-virtual-machine-windows"
      os-type    = "windows"
    }
  )

  # Translate the wrapper's password-only account_credentials variable into the
  # AVM module's expected shape. The AVM module forbids password_authentication_disabled = false
  # on Windows, so we leave it at the upstream default (true) — which is internally
  # ignored for Windows; passwords are always how Windows authenticates.
  account_credentials_avm = {
    admin_credentials = {
      username                           = try(var.account_credentials.admin_credentials.username, "azureuser")
      password                           = try(var.account_credentials.admin_credentials.password, null)
      ssh_keys                           = []
      generate_admin_password_or_ssh_key = try(var.account_credentials.admin_credentials.generate_admin_password_or_ssh_key, true)
    }
    key_vault_configuration          = try(var.account_credentials.key_vault_configuration, null)
    password_authentication_disabled = true
  }
}
