output "resource_id" {
  description = "The Azure resource ID of the Private DNS Zone."
  value       = module.private_dns_zone.resource_id
}

output "name" {
  description = "The name (domain) of the Private DNS Zone."
  value       = module.private_dns_zone.name
}

output "resource" {
  description = "The full azapi Private DNS Zone object."
  value       = module.private_dns_zone.resource
}

# -----------------------------------------------------------
# Per-record-type outputs (map of name -> { id, fqdn })
# -----------------------------------------------------------

output "a_record_outputs" {
  description = "Map of A records keyed by input map key, each with id and fqdn."
  value       = module.private_dns_zone.a_record_outputs
}

output "aaaa_record_outputs" {
  description = "Map of AAAA records keyed by input map key."
  value       = module.private_dns_zone.aaaa_record_outputs
}

output "cname_record_outputs" {
  description = "Map of CNAME records keyed by input map key."
  value       = module.private_dns_zone.cname_record_outputs
}

output "mx_record_outputs" {
  description = "Map of MX records keyed by input map key."
  value       = module.private_dns_zone.mx_record_outputs
}

output "ptr_record_outputs" {
  description = "Map of PTR records keyed by input map key."
  value       = module.private_dns_zone.ptr_record_outputs
}

output "srv_record_outputs" {
  description = "Map of SRV records keyed by input map key."
  value       = module.private_dns_zone.srv_record_outputs
}

output "txt_record_outputs" {
  description = "Map of TXT records keyed by input map key."
  value       = module.private_dns_zone.txt_record_outputs
}

output "soa_record_outputs" {
  description = "SOA record output (default key when configured)."
  value       = module.private_dns_zone.soa_record_outputs
}

output "virtual_network_link_outputs" {
  description = "Map of VNet links keyed by input map key, each with the link's resource ID."
  value       = module.private_dns_zone.virtual_network_link_outputs
}
