# =====================================================================
# Required inputs
# =====================================================================

variable "domain_name" {
  type        = string
  description = "The DNS zone name (e.g. 'privatelink.blob.core.windows.net' or 'corp.example.com'). 1-253 characters; lowercase labels separated by periods."

  validation {
    condition     = can(regex("^([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)(\\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)+$", lower(var.domain_name)))
    error_message = "domain_name must be a valid FQDN: lowercase labels (alphanumerics + hyphens) separated by periods, e.g. 'privatelink.blob.core.windows.net'."
  }
}

variable "subscription_id" {
  type        = string
  description = "The subscription ID containing the Resource Group. Used with resource_group_name to derive the AVM parent_id."

  validation {
    condition     = can(regex("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$", var.subscription_id))
    error_message = "subscription_id must be a valid GUID."
  }
}

variable "resource_group_name" {
  type        = string
  description = "Name of the Resource Group where the Private DNS Zone will be deployed."

  validation {
    condition     = length(var.resource_group_name) > 0 && length(var.resource_group_name) <= 90
    error_message = "resource_group_name must be 1-90 characters."
  }
}

# =====================================================================
# DNS records (all maps, default empty)
# =====================================================================

variable "a_records" {
  type = map(object({
    name         = string
    ttl          = number
    records      = optional(list(string))
    ip_addresses = optional(set(string), null)
  }))
  description = "Map of A records. Each entry: name, ttl, plus exactly one of records (list) or ip_addresses (set)."
  default     = {}
}

variable "aaaa_records" {
  type = map(object({
    name         = string
    ttl          = number
    records      = optional(list(string))
    ip_addresses = optional(set(string), null)
  }))
  description = "Map of AAAA records. Same shape as a_records but IPv6 addresses."
  default     = {}
}

variable "cname_records" {
  type = map(object({
    name   = string
    ttl    = number
    record = optional(string, null)
    cname  = optional(string, null)
  }))
  description = "Map of CNAME records. Each entry must set one of: record or cname."
  default     = {}
}

variable "mx_records" {
  type = map(object({
    name = optional(string, "@")
    ttl  = number
    records = map(object({
      preference = number
      exchange   = string
    }))
  }))
  description = "Map of MX records. name defaults to '@' (zone apex). Each record entry: preference (priority) + exchange (mail server FQDN)."
  default     = {}
}

variable "ptr_records" {
  type = map(object({
    name         = string
    ttl          = number
    records      = optional(list(string), null)
    domain_names = optional(set(string), null)
  }))
  description = "Map of PTR records. Each entry: name, ttl, plus one of records (list) or domain_names (set)."
  default     = {}
}

variable "srv_records" {
  type = map(object({
    name = string
    ttl  = number
    records = map(object({
      priority = number
      weight   = number
      port     = number
      target   = string
    }))
  }))
  description = "Map of SRV records. Each record entry: priority, weight, port, target (FQDN)."
  default     = {}
}

variable "txt_records" {
  type = map(object({
    name = string
    ttl  = number
    records = map(object({
      value = list(string)
    }))
  }))
  description = "Map of TXT records. Each record entry contains a list of strings (concatenated by DNS)."
  default     = {}
}

variable "soa_record" {
  type = object({
    email        = string
    name         = optional(string, "@")
    expire_time  = optional(number, 2419200)
    minimum_ttl  = optional(number, 10)
    refresh_time = optional(number, 3600)
    retry_time   = optional(number, 300)
    ttl          = optional(number, 3600)
  })
  description = "Optional SOA record. email must be in dotted format (e.g. 'admin.corp.example.com', not 'admin@corp.example.com')."
  default     = null

  validation {
    condition     = var.soa_record == null || (try(var.soa_record.email, "") != "" && !can(regex("@", try(var.soa_record.email, ""))))
    error_message = "soa_record.email must be in dotted format (no '@'). Use 'admin.corp.example.com' instead of 'admin@corp.example.com'."
  }
}

# =====================================================================
# Virtual network links
# =====================================================================

variable "virtual_network_links" {
  type = map(object({
    vnetlinkname                           = optional(string, null)
    name                                   = optional(string, null)
    vnetid                                 = optional(string, null)
    virtual_network_id                     = optional(string, null)
    autoregistration                       = optional(bool, false)
    registration_enabled                   = optional(bool, null)
    private_dns_zone_supports_private_link = optional(bool, false)
    resolution_policy                      = optional(string, "Default")
    tags                                   = optional(map(string), null)
  }))
  description = <<DESC
Map of virtual network links. Each link must supply:
- name (or legacy vnetlinkname), 1-80 chars
- virtual_network_id (or legacy vnetid)
- autoregistration / registration_enabled: enables auto-DNS-record-creation for VMs in the linked VNet
- resolution_policy: 'Default' or 'NxDomainRedirect' (for fallback resolution)
- private_dns_zone_supports_private_link: enable when this zone is used for Azure Private Link
DESC
  default     = {}

  validation {
    condition     = alltrue([for v in var.virtual_network_links : coalesce(v.name, v.vnetlinkname) != null])
    error_message = "Each virtual_network_links entry must set name or vnetlinkname."
  }

  validation {
    condition     = alltrue([for v in var.virtual_network_links : coalesce(v.virtual_network_id, v.vnetid) != null])
    error_message = "Each virtual_network_links entry must set virtual_network_id or vnetid."
  }

  validation {
    condition     = alltrue([for v in var.virtual_network_links : length(coalesce(v.name, v.vnetlinkname)) < 80])
    error_message = "Each virtual_network_link name must be less than 80 characters."
  }

  validation {
    condition     = alltrue([for v in var.virtual_network_links : contains(["Default", "NxDomainRedirect"], v.resolution_policy)])
    error_message = "Each virtual_network_links.resolution_policy must be 'Default' or 'NxDomainRedirect'."
  }
}

# =====================================================================
# Governance
# =====================================================================

variable "role_assignments" {
  type = map(object({
    role_definition_id_or_name             = string
    principal_id                           = string
    description                            = optional(string, null)
    skip_service_principal_aad_check       = optional(bool, false)
    condition                              = optional(string, null)
    condition_version                      = optional(string, null)
    delegated_managed_identity_resource_id = optional(string, null)
    principal_type                         = optional(string, null)
  }))
  description = "RBAC role assignments scoped to the Private DNS Zone. Common roles: 'Private DNS Zone Contributor', 'Reader'."
  default     = {}
}

variable "role_assignment_name_use_random_uuid" {
  type        = bool
  description = "Whether role assignment names use a random UUID (recommended) instead of a deterministic UUID. Random UUIDs avoid graph-recreation issues from computed attribute changes."
  default     = true
}

variable "lock" {
  type = object({
    kind = string
    name = optional(string, null)
  })
  description = "Optional resource lock. kind must be 'CanNotDelete' or 'ReadOnly'."
  default     = null

  validation {
    condition     = var.lock == null || contains(["CanNotDelete", "ReadOnly"], try(var.lock.kind, ""))
    error_message = "lock.kind must be 'CanNotDelete' or 'ReadOnly' when set."
  }
}

# =====================================================================
# Module behavior
# =====================================================================

variable "enable_telemetry" {
  type        = bool
  description = "Whether to enable AVM module telemetry. Set false to opt out."
  default     = true
}

variable "tags" {
  type        = map(string)
  description = "A map of tags to apply to the Private DNS Zone."
  default     = null
}

variable "retry" {
  type = object({
    error_message_regex  = optional(list(string), ["ReferencedResourceNotProvisioned", "CannotDeleteResource"])
    interval_seconds     = optional(number, 10)
    max_interval_seconds = optional(number, 180)
    multiplier           = optional(number, 1.5)
    randomization_factor = optional(number, 0.5)
  })
  description = "Retry configuration applied to underlying azapi resources."
  default     = {}
}

variable "timeouts" {
  type = object({
    dns_zones = optional(object({
      create = optional(string, "30m")
      delete = optional(string, "30m")
      update = optional(string, "30m")
      read   = optional(string, "5m")
    }), {})
    vnet_links = optional(object({
      create = optional(string, "30m")
      delete = optional(string, "30m")
      update = optional(string, "30m")
      read   = optional(string, "5m")
    }), {})
  })
  description = "Operation timeouts for the DNS zone and VNet links."
  default     = {}
}
