check "has_at_least_one_vnet_link" {
  assert {
    condition     = local.vnet_link_count > 0
    error_message = "Private DNS Zone '${var.domain_name}' has no virtual_network_links. An unlinked zone resolves nothing — link at least one VNet via var.virtual_network_links."
  }
}

check "privatelink_zone_has_no_autoregistration" {
  assert {
    condition     = !local.is_privatelink_zone || !local.has_any_auto_register
    error_message = "Private Link zone '${var.domain_name}' has autoregistration / registration_enabled set on a VNet link. Private Link zones manage records via private endpoints — leave autoregistration disabled."
  }
}

check "soa_email_format" {
  assert {
    condition     = var.soa_record == null || !can(regex("@", try(var.soa_record.email, "")))
    error_message = "soa_record.email contains '@'. Azure requires SOA emails in dotted format (e.g. 'admin.corp.example.com', not 'admin@corp.example.com')."
  }
}

check "privatelink_zone_no_user_managed_records" {
  assert {
    condition     = !local.is_privatelink_zone || local.total_record_count == 0
    error_message = "Private Link zone '${var.domain_name}' has ${local.total_record_count} user-defined record(s). Private Link zones should be managed entirely by Azure (records appear automatically when private endpoints connect). Manual records may conflict."
  }
}
