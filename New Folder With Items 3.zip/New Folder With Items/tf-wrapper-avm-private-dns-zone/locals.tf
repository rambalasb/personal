locals {
  module_tags = merge(
    var.tags == null ? {} : var.tags,
    {
      managed-by = "terraform"
      module     = "tf-wrapper-avm-private-dns-zone"
    }
  )

  # The AVM module uses parent_id (RG resource ID). Derive it for caller convenience.
  parent_id = "/subscriptions/${var.subscription_id}/resourceGroups/${var.resource_group_name}"

  # Used by checks.tf
  is_privatelink_zone     = startswith(lower(var.domain_name), "privatelink.")
  vnet_link_count         = length(var.virtual_network_links)
  total_record_count      = length(var.a_records) + length(var.aaaa_records) + length(var.cname_records) + length(var.mx_records) + length(var.ptr_records) + length(var.srv_records) + length(var.txt_records)
  has_any_auto_register   = anytrue([for v in var.virtual_network_links : try(v.autoregistration, false) || try(v.registration_enabled, false)])
}
