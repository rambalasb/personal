module "private_dns_zone" {
  source  = "Azure/avm-res-network-privatednszone/azurerm"
  version = "0.5.0"

  # Required
  domain_name = var.domain_name
  parent_id   = local.parent_id

  # DNS records
  a_records     = var.a_records
  aaaa_records  = var.aaaa_records
  cname_records = var.cname_records
  mx_records    = var.mx_records
  ptr_records   = var.ptr_records
  srv_records   = var.srv_records
  txt_records   = var.txt_records
  soa_record    = var.soa_record

  # Virtual network links
  virtual_network_links = var.virtual_network_links

  # Governance
  role_assignments                     = var.role_assignments
  role_assignment_name_use_random_uuid = var.role_assignment_name_use_random_uuid
  lock                                 = var.lock

  # Module behavior
  enable_telemetry = var.enable_telemetry
  tags             = local.module_tags
  retry            = var.retry
  timeouts         = var.timeouts
}
