output "resource_id" {
  value = module.private_dns_zone.resource_id
}

output "name" {
  value = module.private_dns_zone.name
}

output "resource" {
  value = module.private_dns_zone.resource
}
