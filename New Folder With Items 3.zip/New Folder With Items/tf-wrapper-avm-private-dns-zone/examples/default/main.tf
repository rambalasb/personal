# subscription id for parent_id derivation in the wrapper
data "azurerm_client_config" "current" {}

module "private_dns_zone" {
  source = "../.."

  domain_name         = "${random_string.suffix.result}.example.com"
  subscription_id     = data.azurerm_client_config.current.subscription_id
  resource_group_name = azurerm_resource_group.this.name

  enable_telemetry = false
}
