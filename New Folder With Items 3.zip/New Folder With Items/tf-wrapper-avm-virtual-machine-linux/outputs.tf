output "resource_id" {
  description = "The Azure resource ID of the Linux VM."
  value       = module.linux_vm.resource_id
}

output "name" {
  description = "The name of the Linux VM."
  value       = module.linux_vm.name
}

output "resource" {
  description = "The full azurerm_linux_virtual_machine resource. Sensitive."
  value       = module.linux_vm.resource
  sensitive   = true
}

output "admin_username" {
  description = "The admin username configured on the VM."
  value       = module.linux_vm.admin_username
}

output "admin_ssh_keys" {
  description = "The SSH public keys configured on the VM. Sensitive."
  value       = module.linux_vm.admin_ssh_keys
  sensitive   = true
}

output "admin_generated_ssh_private_key" {
  description = "The auto-generated SSH private key, if the module generated one (no user keys supplied + generate_admin_password_or_ssh_key=true). Otherwise 'no_key'. Sensitive."
  value       = module.linux_vm.admin_generated_ssh_private_key
  sensitive   = true
}

output "network_interfaces" {
  description = "Map of deployed NICs."
  value       = module.linux_vm.network_interfaces
}

output "public_ips" {
  description = "Map of deployed public IPs."
  value       = module.linux_vm.public_ips
}

output "data_disks" {
  description = "Map of deployed data disks."
  value       = module.linux_vm.data_disks
}

output "system_assigned_mi_principal_id" {
  description = "Principal ID of the system-assigned managed identity, if enabled."
  value       = module.linux_vm.system_assigned_mi_principal_id
}

output "virtual_machine_azurerm" {
  description = "Map of standard azurerm Linux VM attributes (id, identity, private/public IPs, virtual_machine_id)."
  value       = module.linux_vm.virtual_machine_azurerm
}
