check "ssh_only_authentication" {
  assert {
    condition     = local.account_credentials_avm.password_authentication_disabled == true
    error_message = "Linux VMs deployed via this wrapper must use SSH key authentication only. password_authentication_disabled is hardcoded to true — this assertion catches any regression."
  }
}

check "secure_boot_enabled" {
  assert {
    condition     = var.secure_boot_enabled == true
    error_message = "Linux VMs should have Trusted Launch secure_boot enabled."
  }
}

check "vtpm_enabled" {
  assert {
    condition     = var.vtpm_enabled == true
    error_message = "Linux VMs should have Trusted Launch vTPM enabled."
  }
}

check "encryption_at_host_enabled" {
  assert {
    condition     = var.encryption_at_host_enabled == true
    error_message = "Linux VMs should have encryption_at_host_enabled = true."
  }
}

check "at_least_one_network_interface" {
  assert {
    condition     = length(var.network_interfaces) >= 1
    error_message = "Linux VM has no network interfaces defined."
  }
}
