locals {
  module_tags = merge(
    var.tags == null ? {} : var.tags,
    {
      managed-by = "terraform"
      module     = "tf-wrapper-avm-virtual-machine-linux"
      os-type    = "linux"
    }
  )

  # Translate the wrapper's no-password account_credentials variable into the
  # AVM module's expected shape. password_authentication_disabled is HARDCODED
  # to true — Linux VMs deployed via this wrapper never accept passwords.
  account_credentials_avm = {
    admin_credentials = {
      username                           = try(var.account_credentials.admin_credentials.username, "azureuser")
      password                           = null
      ssh_keys                           = try(var.account_credentials.admin_credentials.ssh_keys, [])
      generate_admin_password_or_ssh_key = try(var.account_credentials.admin_credentials.generate_admin_password_or_ssh_key, true)
    }
    key_vault_configuration          = try(var.account_credentials.key_vault_configuration, null)
    password_authentication_disabled = true
  }
}
