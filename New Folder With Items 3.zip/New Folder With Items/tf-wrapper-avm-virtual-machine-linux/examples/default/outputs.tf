output "resource_id" {
  value = module.virtual_machine_linux.resource_id
}

output "name" {
  value = module.virtual_machine_linux.name
}

output "admin_username" {
  value = module.virtual_machine_linux.admin_username
}
