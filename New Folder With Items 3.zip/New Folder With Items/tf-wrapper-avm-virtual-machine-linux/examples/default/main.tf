module "virtual_machine_linux" {
  source = "../.."

  name                = "vmlin${random_string.suffix.result}"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location
  zone                = "1"
  sku_size            = "Standard_D2s_v3"

  source_image_reference = {
    publisher = "Canonical"
    offer     = "0001-com-ubuntu-server-jammy"
    sku       = "22_04-lts"
    version   = "latest"
  }

  os_disk = {
    caching              = "ReadWrite"
    storage_account_type = "Standard_LRS"
  }

  # password auth is disabled by the wrapper; pass the generated public key
  account_credentials = {
    admin_credentials = {
      username = "azureuser"
      ssh_keys = [tls_private_key.this.public_key_openssh]
    }
  }

  network_interfaces = {
    primary = {
      name = "nic-primary"
      ip_configurations = {
        ipconfig1 = {
          name                          = "ipconfig1"
          private_ip_subnet_resource_id = azurerm_subnet.this.id
        }
      }
    }
  }

  enable_telemetry = false
}
