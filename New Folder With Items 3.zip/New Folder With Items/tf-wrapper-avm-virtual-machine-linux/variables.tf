# =====================================================================
# Required inputs
# =====================================================================

variable "name" {
  type        = string
  description = "The name of the Linux VM. Must be 1-64 characters."

  validation {
    condition     = can(regex("^.{1,64}$", var.name))
    error_message = "name must be 1-64 characters."
  }
}

variable "resource_group_name" {
  type        = string
  description = "Resource Group where the VM and supporting resources will be deployed."

  validation {
    condition     = length(var.resource_group_name) > 0 && length(var.resource_group_name) <= 90
    error_message = "resource_group_name must be 1-90 characters."
  }
}

variable "location" {
  type        = string
  description = "Azure region for the VM."

  validation {
    condition     = length(var.location) > 0
    error_message = "location must not be empty."
  }
}

variable "zone" {
  type        = string
  description = "Availability Zone to deploy into. Set to null when deploying to a region without zones."
}

variable "network_interfaces" {
  type = map(object({
    name = string
    ip_configurations = map(object({
      name = string
      app_gateway_backend_pools = optional(map(object({
        app_gateway_backend_pool_resource_id = string
      })), {})
      create_public_ip_address                                    = optional(bool, false)
      gateway_load_balancer_frontend_ip_configuration_resource_id = optional(string)
      is_primary_ipconfiguration                                  = optional(bool, true)
      load_balancer_backend_pools = optional(map(object({
        load_balancer_backend_pool_resource_id = string
      })), {})
      load_balancer_nat_rules = optional(map(object({
        load_balancer_nat_rule_resource_id = string
      })), {})
      private_ip_address            = optional(string)
      private_ip_address_allocation = optional(string, "Dynamic")
      private_ip_address_version    = optional(string, "IPv4")
      private_ip_subnet_resource_id = optional(string)
      public_ip_address_lock_name   = optional(string)
      public_ip_address_name        = optional(string)
      public_ip_address_resource_id = optional(string)
    }))
    accelerated_networking_enabled = optional(bool, false)
    application_security_groups = optional(map(object({
      application_security_group_resource_id = string
    })), {})
    diagnostic_settings = optional(map(object({
      name                                     = optional(string, null)
      log_categories                           = optional(set(string), [])
      log_groups                               = optional(set(string), [])
      metric_categories                        = optional(set(string), ["AllMetrics"])
      log_analytics_destination_type           = optional(string, null)
      workspace_resource_id                    = optional(string, null)
      storage_account_resource_id              = optional(string, null)
      event_hub_authorization_rule_resource_id = optional(string, null)
      event_hub_name                           = optional(string, null)
      marketplace_partner_resource_id          = optional(string, null)
    })), {})
    dns_servers             = optional(list(string))
    inherit_tags            = optional(bool, true)
    internal_dns_name_label = optional(string)
    ip_forwarding_enabled   = optional(bool, false)
    is_primary              = optional(bool, false)
    lock_level              = optional(string)
    lock_name               = optional(string)
    network_security_groups = optional(map(object({
      network_security_group_resource_id = string
    })), {})
    resource_group_name = optional(string)
    role_assignments = optional(map(object({
      principal_id                           = string
      role_definition_id_or_name             = string
      assign_to_child_public_ip_addresses    = optional(bool, true)
      condition                              = optional(string, null)
      condition_version                      = optional(string, null)
      delegated_managed_identity_resource_id = optional(string, null)
      description                            = optional(string, null)
      skip_service_principal_aad_check       = optional(bool, false)
      principal_type                         = optional(string, null)
    })), {})
    tags = optional(map(string), null)
  }))
  description = "Map of NIC configurations. At least one is required."

  validation {
    condition     = length(var.network_interfaces) > 0
    error_message = "At least one network_interfaces entry is required."
  }
}

# =====================================================================
# Authentication (Linux: SSH-only — no password field exposed)
# =====================================================================

variable "account_credentials" {
  type = object({
    admin_credentials = optional(object({
      username                           = optional(string, "azureuser")
      ssh_keys                           = optional(list(string), [])
      generate_admin_password_or_ssh_key = optional(bool, true)
    }), {})
    key_vault_configuration = optional(object({
      resource_id = string
      secret_configuration = optional(object({
        name                           = optional(string, null)
        expiration_date_length_in_days = optional(number, 45)
        content_type                   = optional(string, "text/plain")
        not_before_date                = optional(string, null)
        tags                           = optional(map(string), {})
      }), {})
    }), null)
  })
  description = <<DESC
Admin credentials for the Linux VM. Password authentication is permanently disabled by this wrapper — only SSH keys are accepted.

- admin_credentials.username: defaults to 'azureuser'
- admin_credentials.ssh_keys: list of SSH public keys. Leave empty + generate_admin_password_or_ssh_key=true to auto-generate one and surface the private key via the admin_generated_ssh_private_key output.
- key_vault_configuration: optional Key Vault to store the generated SSH key.
DESC
  default     = {}

  validation {
    condition     = !contains(["administrator", "admin", "user", "user1", "test", "user2", "test1", "user3", "admin1", "1", "123", "a", "actuser", "adm", "admin2", "aspnet", "backup", "console", "david", "guest", "john", "owner", "root", "server", "sql", "support", "support_388945a0", "sys", "test2", "test3", "user4", "user5"], lower(try(var.account_credentials.admin_credentials.username, "azureuser")))
    error_message = "Admin username is a reserved Azure value. Pick a different username."
  }
}

# =====================================================================
# Image (defaults to Ubuntu 22.04 LTS)
# =====================================================================

variable "source_image_reference" {
  type = object({
    publisher = string
    offer     = string
    sku       = string
    version   = string
  })
  description = "Marketplace image to source the VM from. Defaults to Ubuntu 22.04 LTS."
  default = {
    publisher = "Canonical"
    offer     = "0001-com-ubuntu-server-jammy"
    sku       = "22_04-lts-gen2"
    version   = "latest"
  }
}

variable "source_image_resource_id" {
  type        = string
  description = "Resource ID of a custom/shared image to use instead of source_image_reference. Mutually exclusive with source_image_reference."
  default     = null
}

# =====================================================================
# Size, disks, security
# =====================================================================

variable "sku_size" {
  type        = string
  description = "VM SKU size. Defaults to Standard_D2ds_v5."
  default     = "Standard_D2ds_v5"
}

variable "os_disk" {
  type = object({
    caching                          = string
    storage_account_type             = string
    disk_encryption_set_id           = optional(string)
    disk_size_gb                     = optional(number)
    name                             = optional(string)
    secure_vm_disk_encryption_set_id = optional(string)
    security_encryption_type         = optional(string)
    write_accelerator_enabled        = optional(bool, false)
    diff_disk_settings = optional(object({
      option    = string
      placement = optional(string, "CacheDisk")
    }), null)
  })
  description = "OS disk configuration."
  default = {
    caching              = "ReadWrite"
    storage_account_type = "Premium_LRS"
  }
}

variable "secure_boot_enabled" {
  type        = bool
  description = "Whether secure boot is enabled. Recommended for Trusted Launch."
  default     = true
}

variable "vtpm_enabled" {
  type        = bool
  description = "Whether vTPM is enabled. Recommended for Trusted Launch."
  default     = true
}

variable "encryption_at_host_enabled" {
  type        = bool
  description = "Whether encryption at host (including temp disk) is enabled."
  default     = true
}

variable "disk_controller_type" {
  type        = string
  description = "Disk controller type. 'SCSI' or 'NVME'."
  default     = null
}

variable "data_disk_managed_disks" {
  type = map(object({
    caching                                   = string
    lun                                       = number
    name                                      = string
    storage_account_type                      = string
    create_option                             = optional(string, "Empty")
    disk_access_resource_id                   = optional(string)
    disk_attachment_create_option             = optional(string)
    disk_encryption_set_resource_id           = optional(string)
    disk_iops_read_only                       = optional(number, null)
    disk_iops_read_write                      = optional(number, null)
    disk_mbps_read_only                       = optional(number, null)
    disk_mbps_read_write                      = optional(number, null)
    disk_size_gb                              = optional(number, 128)
    gallery_image_reference_resource_id       = optional(string)
    hyper_v_generation                        = optional(string)
    image_reference_resource_id               = optional(string)
    inherit_tags                              = optional(bool, true)
    lock_level                                = optional(string, null)
    lock_name                                 = optional(string, null)
    logical_sector_size                       = optional(number, null)
    max_shares                                = optional(number)
    network_access_policy                     = optional(string)
    on_demand_bursting_enabled                = optional(bool)
    optimized_frequent_attach_enabled         = optional(bool, false)
    os_type                                   = optional(string)
    performance_plus_enabled                  = optional(bool, false)
    public_network_access_enabled             = optional(bool)
    resource_group_name                       = optional(string)
    secure_vm_disk_encryption_set_resource_id = optional(string)
    security_type                             = optional(string)
    source_resource_id                        = optional(string)
    source_uri                                = optional(string)
    storage_account_resource_id               = optional(string)
    tags                                      = optional(map(string), null)
    tier                                      = optional(string)
    trusted_launch_enabled                    = optional(bool)
    upload_size_bytes                         = optional(number, null)
    write_accelerator_enabled                 = optional(bool)
    encryption_settings = optional(list(object({
      disk_encryption_key_vault_secret_url  = optional(string)
      disk_encryption_key_vault_resource_id = optional(string)
      key_encryption_key_vault_secret_url   = optional(string)
      key_encryption_key_vault_resource_id  = optional(string)
    })), [])
    role_assignments = optional(map(object({
      role_definition_id_or_name             = string
      principal_id                           = string
      description                            = optional(string, null)
      skip_service_principal_aad_check       = optional(bool, false)
      condition                              = optional(string, null)
      condition_version                      = optional(string, null)
      delegated_managed_identity_resource_id = optional(string, null)
      principal_type                         = optional(string, null)
    })), {})
  }))
  description = "Map of managed data disks to create and attach."
  default     = {}
}

variable "data_disk_existing_disks" {
  type = map(object({
    caching                       = string
    managed_disk_resource_id      = string
    lun                           = number
    disk_attachment_create_option = optional(string, "Attach")
    write_accelerator_enabled     = optional(bool, false)
  }))
  description = "Map of existing managed disks to attach to the VM."
  default     = {}
}

# =====================================================================
# Identity & RBAC
# =====================================================================

variable "managed_identities" {
  type = object({
    system_assigned            = optional(bool, false)
    user_assigned_resource_ids = optional(set(string), [])
  })
  description = "Managed identity configuration."
  default     = {}
}

variable "role_assignments" {
  type = map(object({
    role_definition_id_or_name             = string
    principal_id                           = string
    condition                              = optional(string, null)
    condition_version                      = optional(string, null)
    delegated_managed_identity_resource_id = optional(string, null)
    description                            = optional(string, null)
    principal_type                         = optional(string, null)
    skip_service_principal_aad_check       = optional(bool, false)
  }))
  description = "RBAC role assignments scoped to the VM."
  default     = {}
}

variable "role_assignments_system_managed_identity" {
  type = map(object({
    role_definition_id_or_name             = string
    scope_resource_id                      = string
    condition                              = optional(string, null)
    condition_version                      = optional(string, null)
    description                            = optional(string, null)
    skip_service_principal_aad_check       = optional(bool, false)
    delegated_managed_identity_resource_id = optional(string, null)
    principal_type                         = optional(string, null)
  }))
  description = "RBAC assignments granted to the VM's system-assigned identity on external scopes."
  default     = {}
}

# =====================================================================
# Extensions, backup, schedules, public IP
# =====================================================================

variable "extensions" {
  type = map(object({
    name                        = string
    publisher                   = string
    type                        = string
    type_handler_version        = string
    auto_upgrade_minor_version  = optional(bool)
    automatic_upgrade_enabled   = optional(bool)
    deploy_sequence             = optional(number, 5)
    failure_suppression_enabled = optional(bool, false)
    settings                    = optional(string)
    protected_settings          = optional(string)
    provision_after_extensions  = optional(list(string), [])
    tags                        = optional(map(string), null)
    protected_settings_from_key_vault = optional(object({
      secret_url      = string
      source_vault_id = string
    }))
    timeouts = optional(object({
      create = optional(string)
      delete = optional(string)
      update = optional(string)
      read   = optional(string)
    }))
  }))
  description = "Map of VM extensions to deploy."
  default     = {}
  sensitive   = true
}

variable "azure_backup_configurations" {
  type = map(object({
    resource_group_name        = optional(string, null)
    recovery_vault_name        = optional(string, null)
    recovery_vault_resource_id = string
    backup_policy_resource_id  = optional(string, null)
    exclude_disk_luns          = optional(list(number), null)
    include_disk_luns          = optional(list(number), null)
  }))
  description = "Azure Backup configurations for the VM."
  default     = {}
}

variable "shutdown_schedules" {
  type = map(object({
    daily_recurrence_time = string
    notification_settings = optional(object({
      enabled         = optional(bool, false)
      email           = optional(string, null)
      time_in_minutes = optional(string, "30")
      webhook_url     = optional(string, null)
    }), { enabled = false })
    timezone = string
    enabled  = optional(bool, true)
    tags     = optional(map(string), null)
  }))
  description = "Auto-shutdown schedules."
  default     = {}
}

variable "public_ip_configuration_details" {
  type = object({
    allocation_method       = optional(string, "Static")
    ddos_protection_mode    = optional(string, "VirtualNetworkInherited")
    ddos_protection_plan_id = optional(string)
    domain_name_label       = optional(string)
    idle_timeout_in_minutes = optional(number, 30)
    inherit_tags            = optional(bool, false)
    ip_version              = optional(string, "IPv4")
    lock_level              = optional(string, null)
    sku                     = optional(string, "Standard")
    sku_tier                = optional(string, "Regional")
    tags                    = optional(map(string), null)
    zones                   = optional(set(string), ["1", "2", "3"])
  })
  description = "Public IP configuration applied to any NIC that requests a public IP."
  default     = {}
}

variable "maintenance_configuration_resource_ids" {
  type        = map(string)
  description = "Map of maintenance configuration resource IDs to apply."
  default     = {}
}

variable "secrets" {
  type = list(object({
    key_vault_id = string
    certificate = set(object({
      url   = string
      store = optional(string)
    }))
  }))
  description = "Key Vault certificate secrets to install on the VM."
  default     = []
}

variable "gallery_applications" {
  type = map(object({
    version_id             = string
    configuration_blob_uri = optional(string)
    order                  = optional(number, 0)
    tag                    = optional(string)
  }))
  description = "Gallery application versions to deploy."
  default     = {}
}

variable "run_commands" {
  type = map(object({
    location        = string
    name            = string
    deploy_sequence = optional(number, 3)
    script_source = object({
      command_id = optional(string)
      script     = optional(string)
      script_uri = optional(string)
      script_uri_managed_identity = optional(object({
        client_id = optional(string)
        object_id = optional(string)
      }))
    })
    error_blob_managed_identity = optional(object({
      client_id = optional(string)
      object_id = optional(string)
    }))
    error_blob_uri = optional(string)
    output_blob_managed_identity = optional(object({
      client_id = optional(string)
      object_id = optional(string)
    }))
    output_blob_uri = optional(string)
    parameters = optional(map(object({
      name  = string
      value = string
    })), {})
    timeouts = optional(object({
      create = optional(string)
      delete = optional(string)
      update = optional(string)
      read   = optional(string)
    }))
    tags = optional(map(string))
  }))
  description = "Run command configurations for the VM."
  default     = {}
}

variable "run_commands_secrets" {
  type        = map(any)
  description = "Sensitive parameters for run_commands, keyed by matching run_commands map key."
  default     = {}
  sensitive   = true
}

# =====================================================================
# Diagnostics, locks, tags, telemetry
# =====================================================================

variable "diagnostic_settings" {
  type = map(object({
    name                                     = optional(string, null)
    log_categories                           = optional(set(string), [])
    log_groups                               = optional(set(string), [])
    metric_categories                        = optional(set(string), ["AllMetrics"])
    log_analytics_destination_type           = optional(string, "Dedicated")
    workspace_resource_id                    = optional(string, null)
    storage_account_resource_id              = optional(string, null)
    event_hub_authorization_rule_resource_id = optional(string, null)
    event_hub_name                           = optional(string, null)
    marketplace_partner_resource_id          = optional(string, null)
  }))
  description = "Diagnostic settings for the VM. Metrics-only — VM resources do not emit logs."
  default     = {}
}

variable "boot_diagnostics" {
  type        = bool
  description = "Whether boot diagnostics is enabled."
  default     = true
}

variable "boot_diagnostics_storage_account_uri" {
  type        = string
  description = "Storage Account URI for boot diagnostics. Null uses a managed storage account."
  default     = null
}

variable "lock" {
  type = object({
    name = optional(string, null)
    kind = string
  })
  description = "Resource lock. kind must be 'CanNotDelete' or 'ReadOnly'."
  default     = null

  validation {
    condition     = var.lock == null || contains(["CanNotDelete", "ReadOnly"], try(var.lock.kind, ""))
    error_message = "lock.kind must be 'CanNotDelete' or 'ReadOnly' when set."
  }
}

variable "tags" {
  type        = map(string)
  description = "Tags applied to the VM."
  default     = null
}

variable "enable_telemetry" {
  type        = bool
  description = "Whether to enable AVM module telemetry."
  default     = true
}

# =====================================================================
# Long-tail toggles
# =====================================================================

variable "custom_data" {
  type        = string
  description = "Base64-encoded custom data passed to cloud-init at first boot."
  default     = null

  validation {
    condition     = var.custom_data == null || can(base64decode(var.custom_data))
    error_message = "custom_data must be null or a valid Base64-encoded string."
  }
}

variable "user_data" {
  type        = string
  description = "Base64-encoded user data passed to the VM."
  default     = null

  validation {
    condition     = var.user_data == null || can(base64decode(var.user_data))
    error_message = "user_data must be null or a valid Base64-encoded string."
  }
}

variable "computer_name" {
  type        = string
  description = "Hostname for the VM (defaults to var.name when null)."
  default     = null
}

variable "allow_extension_operations" {
  type        = bool
  description = "Whether extension operations are allowed."
  default     = true
}

variable "availability_set_resource_id" {
  type        = string
  description = "Availability Set resource ID. Conflicts with zone, capacity_reservation_group, virtual_machine_scale_set."
  default     = null
}

variable "capacity_reservation_group_resource_id" {
  type        = string
  description = "Capacity Reservation Group resource ID."
  default     = null
}

variable "dedicated_host_group_resource_id" {
  type        = string
  description = "Dedicated Host Group resource ID."
  default     = null
}

variable "dedicated_host_resource_id" {
  type        = string
  description = "Dedicated Host resource ID."
  default     = null
}

variable "edge_zone" {
  type        = string
  description = "Edge Zone within the Azure region."
  default     = null
}

variable "eviction_policy" {
  type        = string
  description = "Eviction policy for Spot VMs. 'Deallocate' or 'Delete'."
  default     = null
}

variable "extensions_time_budget" {
  type        = string
  description = "ISO 8601 duration allowed for extensions to start. 15-120m."
  default     = "PT1H30M"
}

variable "license_type" {
  type        = string
  description = "License type for Azure Hybrid Use Benefit. Not commonly used for Linux."
  default     = null
}

variable "max_bid_price" {
  type        = number
  description = "Max bid price for Spot VMs in USD. -1 disables eviction by price."
  default     = -1
}

variable "patch_assessment_mode" {
  type        = string
  description = "VM Guest Patching assessment mode. 'AutomaticByPlatform' or 'ImageDefault'."
  default     = "ImageDefault"
}

variable "patch_mode" {
  type        = string
  description = "In-guest patching mode. 'AutomaticByPlatform' or 'ImageDefault'."
  default     = null
}

variable "platform_fault_domain" {
  type        = number
  description = "Platform fault domain in which the VM is created."
  default     = null
}

variable "plan" {
  type = object({
    name      = string
    product   = string
    publisher = string
  })
  description = "Marketplace plan for the image."
  default     = null
}

variable "priority" {
  type        = string
  description = "VM priority. 'Regular' or 'Spot'."
  default     = null
}

variable "provision_vm_agent" {
  type        = bool
  description = "Whether to provision the VM agent."
  default     = true
}

variable "proximity_placement_group_resource_id" {
  type        = string
  description = "Proximity Placement Group resource ID."
  default     = null
}

variable "reboot_setting" {
  type        = string
  description = "Reboot setting for platform-scheduled patching. 'Always', 'IfRequired', 'Never'."
  default     = null
}

variable "termination_notification" {
  type = object({
    enabled = optional(bool, false)
    timeout = optional(string, "PT5M")
  })
  description = "VM termination notification configuration."
  default     = null
}

variable "timeouts" {
  type = object({
    azurerm_virtual_machine_extension = optional(object({
      create = optional(string, "30m")
      delete = optional(string, "30m")
      update = optional(string, "30m")
      read   = optional(string, "5m")
    }), {})
    azurerm_virtual_machine_run_command = optional(object({
      create = optional(string, "30m")
      delete = optional(string, "30m")
      update = optional(string, "30m")
      read   = optional(string, "5m")
    }), {})
  })
  description = "Operation timeouts for extensions and run commands."
  default     = {}
}

variable "virtual_machine_scale_set_resource_id" {
  type        = string
  description = "Orchestrated VMSS resource ID. Conflicts with availability_set."
  default     = null
}

variable "vm_additional_capabilities" {
  type = object({
    ultra_ssd_enabled   = optional(bool, false)
    hibernation_enabled = optional(bool, null)
  })
  description = "Additional VM capabilities (UltraSSD, hibernation)."
  default     = null
}

variable "bypass_platform_safety_checks_on_user_schedule_enabled" {
  type        = bool
  description = "Skip platform-scheduled patching when a user schedule is associated. Requires patch_mode = 'AutomaticByPlatform'."
  default     = false
}
