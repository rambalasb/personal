locals {
  module_tags = merge(
    var.tags == null ? {} : var.tags,
    {
      managed-by = "terraform"
      module     = "tf-wrapper-avm-web-site"
    }
  )

  # AVM uses parent_id (RG resource ID). Derive for caller convenience.
  parent_id = "/subscriptions/${var.subscription_id}/resourceGroups/${var.resource_group_name}"

  # Used by checks.tf
  is_function_app       = var.kind == "functionapp"
  is_logic_app          = var.kind == "logicapp"
  has_private_endpoints = length(var.private_endpoints) > 0
}
