output "resource_id" {
  description = "The Azure resource ID of the App Service."
  value       = module.web_site.resource_id
  sensitive   = true
}

output "name" {
  description = "The name of the App Service."
  value       = module.web_site.name
}

output "kind" {
  description = "The kind of App Service ('webapp', 'functionapp', or 'logicapp')."
  value       = module.web_site.kind
}

output "os_type" {
  description = "The OS type of the App Service."
  value       = module.web_site.os_type
}

output "location" {
  description = "The Azure region of the App Service."
  value       = module.web_site.location
}

output "resource_uri" {
  description = "Default hostname of the App Service (e.g. myapp.azurewebsites.net)."
  value       = module.web_site.resource_uri
}

output "resource" {
  description = "The full azapi App Service resource object. Sensitive."
  value       = module.web_site.resource
  sensitive   = true
}

output "active_slot" {
  description = "Resource ID of the currently active slot (or the main site if no slot is active)."
  value       = module.web_site.active_slot
}

output "deployment_slots" {
  description = "Map of deployment slots created by the module."
  value       = module.web_site.deployment_slots
}

output "deployment_slot_locks" {
  description = "Map of locks applied to deployment slots."
  value       = module.web_site.deployment_slot_locks
}

output "custom_domain_verification_id" {
  description = "Custom domain verification ID — use to create an asuid TXT record before binding a custom domain."
  value       = module.web_site.custom_domain_verification_id
}

output "private_endpoints" {
  description = "Map of private endpoints attached to the App Service."
  value       = module.web_site.private_endpoints
}

output "resource_private_endpoints" {
  description = "Map of private endpoints (full azapi resource objects)."
  value       = module.web_site.resource_private_endpoints
}

output "identity_principal_id" {
  description = "The system-assigned managed identity principal ID."
  value       = module.web_site.identity_principal_id
  sensitive   = true
}

output "system_assigned_mi_principal_id" {
  description = "Alias for identity_principal_id."
  value       = module.web_site.system_assigned_mi_principal_id
  sensitive   = true
}

output "system_assigned_mi_principal_id_slots" {
  description = "Map of system-assigned managed identity principal IDs for each deployment slot."
  value       = module.web_site.system_assigned_mi_principal_id_slots
  sensitive   = true
}

output "resource_lock" {
  description = "Resource lock applied to the App Service."
  value       = module.web_site.resource_lock
}
