module "web_site" {
  source = "../.."

  name                     = "app-avm-${random_string.suffix.result}"
  subscription_id          = data.azurerm_client_config.current.subscription_id
  resource_group_name      = azurerm_resource_group.this.name
  location                 = azurerm_resource_group.this.location
  service_plan_resource_id = azurerm_service_plan.this.id
  os_type                  = "Linux"

  enable_telemetry = false
}
