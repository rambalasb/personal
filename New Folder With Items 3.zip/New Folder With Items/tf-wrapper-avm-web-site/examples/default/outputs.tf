output "resource_id" {
  value = module.web_site.resource_id
}

output "name" {
  value = module.web_site.name
}

output "resource_uri" {
  value = module.web_site.resource_uri
}
