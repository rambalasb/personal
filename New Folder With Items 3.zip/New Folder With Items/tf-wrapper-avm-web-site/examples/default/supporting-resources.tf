# random suffix to avoid name collisions on reruns
resource "random_string" "suffix" {
  length  = 6
  lower   = true
  upper   = false
  numeric = true
  special = false
}

# subscription_id for the wrapper's parent_id derivation
data "azurerm_client_config" "current" {}

# native supporting RG so the example tests standalone, without a sibling module
resource "azurerm_resource_group" "this" {
  name     = "rg-avm-website-default-test-${random_string.suffix.result}"
  location = "canadacentral"
}

# native plan to satisfy service_plan_resource_id; os_type must match the site
resource "azurerm_service_plan" "this" {
  name                = "asp-avm-website-default-test-${random_string.suffix.result}"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location
  os_type             = "Linux"
  sku_name            = "B1"
}
