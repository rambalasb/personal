check "https_only_enforced" {
  assert {
    condition     = var.https_only
    error_message = "App Service https_only is false. Enable HTTPS-only traffic for compliance."
  }
}

check "public_network_access_disabled_by_default" {
  assert {
    condition     = !var.public_network_access_enabled || local.has_private_endpoints
    error_message = "public_network_access_enabled = true without any private endpoints. Either disable public access or expose the site only via private endpoints."
  }
}

check "ftp_basic_auth_disabled" {
  assert {
    condition     = !var.ftp_publish_basic_authentication_enabled
    error_message = "FTP basic authentication is enabled (ftp_publish_basic_authentication_enabled = true). FTP is unencrypted — prefer disabled."
  }
}

check "scm_basic_auth_review" {
  assert {
    condition     = !var.scm_publish_basic_authentication_enabled
    error_message = "SCM basic authentication is enabled. For least-privilege deploys, switch to managed-identity-based deployment and set scm_publish_basic_authentication_enabled = false."
  }
}

check "functions_extension_version_set_for_function_apps" {
  assert {
    condition     = !local.is_function_app || var.functions_extension_version != null || var.function_app_uses_fc1 == true
    error_message = "Function App is configured but functions_extension_version is unset (and not a Flex Consumption app). Set functions_extension_version (e.g. '~4') to avoid version drift."
  }
}

check "application_insights_configured" {
  assert {
    condition     = var.application_insights_connection_string != null || var.application_insights_key != null
    error_message = "App Service has no Application Insights connection_string or instrumentation key. Telemetry won't flow to App Insights without one."
  }
}
