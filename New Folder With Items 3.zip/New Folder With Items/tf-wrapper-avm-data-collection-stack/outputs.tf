# =====================================================================
# Data Collection Endpoint outputs
# =====================================================================

output "dce_resource_id" {
  description = "Resource ID of the Data Collection Endpoint, if created by this module."
  value       = var.create_dce ? module.dce[0].resource_id : null
}

output "dce_name" {
  description = "Name of the Data Collection Endpoint, if created by this module."
  value       = var.create_dce ? module.dce[0].name : null
}

output "dce_configuration_access_endpoint" {
  description = "The configuration access endpoint URL of the DCE (used by AMA agents). Null if DCE was not created by this module."
  value       = var.create_dce ? module.dce[0].configuration_access_endpoint : null
}

output "dce_logs_ingestion_endpoint" {
  description = "The logs ingestion endpoint URL of the DCE (used by Logs Ingestion API clients). Null if DCE was not created by this module."
  value       = var.create_dce ? module.dce[0].logs_ingestion_endpoint : null
}

output "dce_metrics_ingestion_endpoint" {
  description = "The metrics ingestion endpoint URL of the DCE. Null if DCE was not created by this module."
  value       = var.create_dce ? module.dce[0].metrics_ingestion_endpoint : null
}

output "dce_resource" {
  description = "The full azapi DCE resource object. Null if DCE was not created by this module."
  value       = var.create_dce ? module.dce[0].resource : null
}

# =====================================================================
# Data Collection Rule outputs
# =====================================================================

output "dcr_resource_id" {
  description = "Resource ID of the Data Collection Rule, if created by this module."
  value       = var.create_dcr ? module.dcr[0].resource_id : null
}

output "dcr_name" {
  description = "Name of the Data Collection Rule, if created by this module."
  value       = var.create_dcr ? module.dcr[0].name : null
}

output "dcr_resource" {
  description = "The full azapi DCR resource object. Null if DCR was not created by this module."
  value       = var.create_dcr ? module.dcr[0].resource : null
}

# =====================================================================
# Composite / cross-component outputs
# =====================================================================

output "dcr_linked_to_dce" {
  description = "True if the DCR was created with a DCE association (either to the wrapper-created DCE or an external one)."
  value       = local.has_dce_linked_to_dcr
}

output "linked_dce_resource_id" {
  description = "The DCE resource ID that the DCR was associated with. Null if no DCE linkage was configured or DCR was not created."
  value       = var.create_dcr ? local.resolved_dce_resource_id : null
}
