# subscription_id feeds the wrapper's derived parent_id
data "azurerm_client_config" "current" {}

# default example provisions only the DCE; DCR needs non-trivial
# data_flows/destinations wiring, kept out of the minimal case
module "data_collection_stack" {
  source = "../.."

  name                = "dcs-avm-default-test-${random_string.suffix.result}"
  resource_group_name = azurerm_resource_group.this.name
  subscription_id     = data.azurerm_client_config.current.subscription_id
  location            = azurerm_resource_group.this.location

  create_dcr = false

  enable_telemetry = false
}
