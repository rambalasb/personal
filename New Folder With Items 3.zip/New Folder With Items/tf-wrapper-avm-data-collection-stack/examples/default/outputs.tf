output "dce_resource_id" {
  value = module.data_collection_stack.dce_resource_id
}

output "dce_name" {
  value = module.data_collection_stack.dce_name
}

output "dcr_resource_id" {
  value = module.data_collection_stack.dcr_resource_id
}

output "dcr_name" {
  value = module.data_collection_stack.dcr_name
}
