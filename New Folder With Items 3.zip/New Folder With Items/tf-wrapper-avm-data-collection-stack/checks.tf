check "at_least_one_component_created" {
  assert {
    condition     = var.create_dce || var.create_dcr
    error_message = "Neither DCE nor DCR was created. Set at least one of create_dce or create_dcr to true."
  }
}

check "dce_public_access_disabled_by_default" {
  assert {
    condition     = !var.create_dce || var.dce.public_network_access != "Enabled"
    error_message = "DCE public_network_access is 'Enabled'. Prefer 'Disabled' (default for this wrapper) or 'SecuredByPerimeter' and route ingestion via private endpoints."
  }
}

check "dcr_links_to_dce_when_both_managed" {
  assert {
    condition     = !(var.create_dce && var.create_dcr) || local.resolved_dce_resource_id != null
    error_message = "Both DCE and DCR are managed by this wrapper but the DCR was not linked to the DCE. This shouldn't happen — check that module.dce is producing a resource_id."
  }
}

check "dcr_uses_external_dce_or_skips_linkage_explicitly" {
  assert {
    condition     = var.create_dce || !var.create_dcr || var.external_dce_resource_id != null || true
    error_message = "DCR is being created without a DCE link (create_dce = false and external_dce_resource_id = null). This is valid only for scenarios like Log Analytics workspace ingestion via AMA without custom log files. Confirm this is intentional."
  }
}

check "dcr_has_destinations_when_data_flows_set" {
  assert {
    condition     = !var.create_dcr || length(coalesce(var.dcr.data_flows, [])) == 0 || var.dcr.destinations != null
    error_message = "DCR has data_flows defined but destinations is null. data_flows need destinations to send data to."
  }
}
