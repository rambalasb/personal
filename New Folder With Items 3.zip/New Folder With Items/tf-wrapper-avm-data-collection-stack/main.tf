# ---------------------------------------------------------------------
# Data Collection Endpoint (created first — DCR will reference it)
# ---------------------------------------------------------------------

module "dce" {
  source  = "Azure/avm-res-insights-datacollectionendpoint/azurerm"
  version = "0.2.0"
  count   = var.create_dce ? 1 : 0

  name        = local.dce_name
  parent_id   = local.parent_id
  location    = var.location
  description = var.dce.description
  kind        = var.dce.kind

  public_network_access = var.dce.public_network_access
  sku                   = var.dce.sku

  managed_identities  = var.dce.managed_identities
  role_assignments    = var.dce.role_assignments
  lock                = var.dce.lock
  diagnostic_settings = var.dce.diagnostic_settings

  enable_telemetry = var.enable_telemetry
  tags             = local.dce_tags
}

# ---------------------------------------------------------------------
# Data Collection Rule (references the DCE via data_collection_endpoint_id)
#
# The DCR's dependency on the DCE is expressed implicitly through the
# data_collection_endpoint_id attribute reference — Terraform's graph
# orders DCE before DCR automatically. No depends_on needed.
# ---------------------------------------------------------------------

module "dcr" {
  source  = "Azure/avm-res-insights-datacollectionrule/azurerm"
  version = "0.1.0"
  count   = var.create_dcr ? 1 : 0

  name        = local.dcr_name
  parent_id   = local.parent_id
  location    = var.location
  description = var.dcr.description
  kind        = var.dcr.kind

  # Wired automatically:
  #   - DCE created here -> module.dce[0].resource_id
  #   - external DCE     -> var.external_dce_resource_id
  #   - neither          -> null (DCR with no endpoint)
  data_collection_endpoint_id = local.resolved_dce_resource_id

  data_flows          = var.dcr.data_flows
  destinations        = var.dcr.destinations
  data_sources        = var.dcr.data_sources
  direct_data_sources = var.dcr.direct_data_sources
  stream_declarations = var.dcr.stream_declarations
  agent_settings      = var.dcr.agent_settings
  references          = var.dcr.references
  sku                 = var.dcr.sku

  managed_identities  = var.dcr.managed_identities
  role_assignments    = var.dcr.role_assignments
  lock                = var.dcr.lock
  diagnostic_settings = var.dcr.diagnostic_settings

  enable_telemetry = var.enable_telemetry
  tags             = local.dcr_tags
}
