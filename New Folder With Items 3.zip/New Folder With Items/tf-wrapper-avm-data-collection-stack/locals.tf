locals {
  module_tags = merge(
    var.tags == null ? {} : var.tags,
    {
      managed-by = "terraform"
      module     = "tf-wrapper-avm-data-collection-stack"
    }
  )

  # Both AVM modules use parent_id (resource group resource ID), not resource_group_name.
  parent_id = "/subscriptions/${var.subscription_id}/resourceGroups/${var.resource_group_name}"

  # Derive child resource names.
  dce_name = coalesce(var.dce.name_override, "${var.name}-dce")
  dcr_name = coalesce(var.dcr.name_override, "${var.name}-dcr")

  # Per-component tag merges (component-specific tags override shared defaults).
  dce_tags = merge(local.module_tags, var.dce.tags == null ? {} : var.dce.tags)
  dcr_tags = merge(local.module_tags, var.dcr.tags == null ? {} : var.dcr.tags)

  # Resolve the DCE resource ID that the DCR should associate with.
  #   - If we created a DCE, use its output.
  #   - Else, fall back to whatever the caller supplied (or null).
  resolved_dce_resource_id = var.create_dce ? (
    length(module.dce) > 0 ? module.dce[0].resource_id : null
  ) : var.external_dce_resource_id

  # Derived flags for checks.tf.
  has_dce_linked_to_dcr = var.create_dcr && local.resolved_dce_resource_id != null
}
