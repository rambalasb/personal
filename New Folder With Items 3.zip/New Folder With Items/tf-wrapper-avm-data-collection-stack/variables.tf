# =====================================================================
# Shared inputs
# =====================================================================

variable "name" {
  type        = string
  description = "Logical name used to derive child resource names (DCE: '<name>-dce', DCR: '<name>-dcr'). 1-44 chars; alphanumerics and hyphens; must start/end alphanumeric."

  validation {
    condition     = can(regex("^[a-zA-Z0-9][a-zA-Z0-9-]{0,42}[a-zA-Z0-9]$", var.name))
    error_message = "name must be 1-44 characters, alphanumerics and hyphens, start and end with alphanumeric."
  }
}

variable "resource_group_name" {
  type        = string
  description = "Name of the Resource Group where both DCE and DCR will be deployed."

  validation {
    condition     = length(var.resource_group_name) > 0 && length(var.resource_group_name) <= 90
    error_message = "resource_group_name must be 1-90 characters."
  }
}

variable "subscription_id" {
  type        = string
  description = "The subscription ID containing the Resource Group. Used to construct the AVM parent_id (resource group resource ID)."

  validation {
    condition     = can(regex("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$", var.subscription_id))
    error_message = "subscription_id must be a valid GUID."
  }
}

variable "location" {
  type        = string
  description = "Azure region for both DCE and DCR."

  validation {
    condition     = length(var.location) > 0
    error_message = "location must not be empty."
  }
}

variable "tags" {
  type        = map(string)
  description = "Tags applied to both DCE and DCR (merged with each component's individual tags)."
  default     = null
}

variable "enable_telemetry" {
  type        = bool
  description = "Whether to enable AVM module telemetry on both components."
  default     = true
}

# =====================================================================
# Feature flags
# =====================================================================

variable "create_dce" {
  type        = bool
  description = "Whether to provision a new Data Collection Endpoint. Set false to use an existing DCE via external_dce_resource_id, or omit DCE entirely."
  default     = true
}

variable "create_dcr" {
  type        = bool
  description = "Whether to provision a new Data Collection Rule. Set false to skip DCR creation entirely (useful when this wrapper only manages a DCE)."
  default     = true
}

# =====================================================================
# External references (when feature flags are false)
# =====================================================================

variable "external_dce_resource_id" {
  type        = string
  description = "Resource ID of an existing Data Collection Endpoint to associate with the DCR. Used only when create_dce = false and create_dcr = true. Leave null to skip DCE linkage on the DCR."
  default     = null

  validation {
    condition     = var.external_dce_resource_id == null || can(regex("^/subscriptions/[^/]+/resourceGroups/[^/]+/providers/Microsoft\\.Insights/dataCollectionEndpoints/[^/]+$", var.external_dce_resource_id))
    error_message = "external_dce_resource_id must be a valid Microsoft.Insights/dataCollectionEndpoints resource ID."
  }
}

# =====================================================================
# DCE configuration
# =====================================================================

variable "dce" {
  type = object({
    name_override         = optional(string, null)
    description           = optional(string, null)
    kind                  = optional(string, null)
    public_network_access = optional(string, "Disabled")
    sku = optional(object({
      capacity = optional(number, null)
      family   = optional(string, null)
      name     = string
      size     = optional(string, null)
      tier     = optional(string, null)
    }), null)
    managed_identities = optional(object({
      system_assigned            = optional(bool, false)
      user_assigned_resource_ids = optional(set(string), [])
    }), {})
    role_assignments = optional(map(object({
      name                                   = optional(string, null)
      role_definition_id_or_name             = string
      principal_id                           = string
      description                            = optional(string, null)
      skip_service_principal_aad_check       = optional(bool, false)
      condition                              = optional(string, null)
      condition_version                      = optional(string, null)
      delegated_managed_identity_resource_id = optional(string, null)
      principal_type                         = optional(string, null)
    })), {})
    lock = optional(object({
      kind = string
      name = optional(string, null)
    }), null)
    diagnostic_settings = optional(map(object({
      name                                     = optional(string, null)
      log_categories                           = optional(set(string), [])
      log_groups                               = optional(set(string), ["allLogs"])
      metric_categories                        = optional(set(string), ["AllMetrics"])
      log_analytics_destination_type           = optional(string, "Dedicated")
      workspace_resource_id                    = optional(string, null)
      storage_account_resource_id              = optional(string, null)
      event_hub_authorization_rule_resource_id = optional(string, null)
      event_hub_name                           = optional(string, null)
      marketplace_partner_resource_id          = optional(string, null)
    })), {})
    tags = optional(map(string), null)
  })
  description = <<DESC
Configuration for the Data Collection Endpoint. Only used when create_dce = true.

- name_override: explicit name; defaults to '<var.name>-dce' if null.
- kind: 'Linux' or 'Windows' (or null).
- public_network_access: 'Disabled' (default for this wrapper), 'Enabled', or 'SecuredByPerimeter'.
- sku: optional SKU config; tier must be 'Basic'/'Free'/'Premium'/'Standard' or null.
- managed_identities / role_assignments / lock / diagnostic_settings / tags: standard AVM interfaces.
DESC
  default     = {}

  validation {
    condition     = var.dce.kind == null || contains(["Linux", "Windows"], coalesce(var.dce.kind, "Linux"))
    error_message = "dce.kind must be 'Linux', 'Windows', or null."
  }

  validation {
    condition     = contains(["Disabled", "Enabled", "SecuredByPerimeter"], var.dce.public_network_access)
    error_message = "dce.public_network_access must be 'Disabled', 'Enabled', or 'SecuredByPerimeter'."
  }

  validation {
    condition     = var.dce.lock == null || contains(["CanNotDelete", "ReadOnly"], try(var.dce.lock.kind, ""))
    error_message = "dce.lock.kind must be 'CanNotDelete' or 'ReadOnly' when lock is set."
  }
}

# =====================================================================
# DCR configuration
# =====================================================================

variable "dcr" {
  type = object({
    name_override = optional(string, null)
    description   = optional(string, null)
    kind          = optional(string, null)

    data_flows = optional(list(object({
      built_in_transform = optional(string, null)
      capture_overflow   = optional(bool, null)
      destinations       = list(string)
      output_stream      = optional(string, null)
      streams            = list(string)
      transform_kql      = optional(string, null)
    })), [])

    destinations = optional(object({
      azure_data_explorer = optional(list(object({
        database_name = string
        name          = string
        resource_id   = string
      })), [])
      azure_monitor_metrics = optional(object({
        name = string
      }), null)
      event_hubs = optional(list(object({
        event_hub_resource_id = string
        name                  = string
      })), [])
      event_hubs_direct = optional(list(object({
        event_hub_resource_id = string
        name                  = string
      })), [])
      log_analytics = optional(list(object({
        name                  = string
        workspace_resource_id = string
      })), [])
      microsoft_fabric = optional(list(object({
        artifact_id   = string
        database_name = string
        ingestion_uri = string
        name          = string
        tenant_id     = optional(string, null)
      })), [])
      monitoring_accounts = optional(list(object({
        account_resource_id = string
        name                = string
      })), [])
      storage_accounts = optional(list(object({
        container_name              = string
        name                        = string
        storage_account_resource_id = string
      })), [])
      storage_blobs_direct = optional(list(object({
        container_name              = string
        name                        = string
        storage_account_resource_id = string
      })), [])
      storage_tables_direct = optional(list(object({
        name                        = string
        storage_account_resource_id = string
        table_name                  = string
      })), [])
    }), null)

    data_sources = optional(object({
      data_imports = optional(object({
        event_hub = optional(object({
          consumer_group = optional(string, null)
          name           = string
          stream         = optional(string, null)
        }), null)
      }), null)
      extensions = optional(list(object({
        extension_name     = string
        extension_settings = optional(any, null)
        input_data_sources = optional(list(string), null)
        name               = string
        streams            = list(string)
      })), [])
      etw_providers = optional(list(object({
        event_ids     = optional(list(string), null)
        keyword       = optional(string, null)
        log_level     = optional(string, null)
        name          = string
        provider      = string
        provider_type = string
        streams       = list(string)
      })), [])
      iis_logs = optional(list(object({
        log_directories = optional(list(string), null)
        name            = string
        streams         = list(string)
        transform_kql   = optional(string, null)
      })), [])
      log_files = optional(list(object({
        file_patterns = list(string)
        format        = string
        name          = string
        settings = optional(object({
          text = object({
            record_start_timestamp_format = string
          })
        }), null)
        streams       = list(string)
        transform_kql = optional(string, null)
      })), [])
      otel_logs = optional(list(object({
        enrich_with_reference              = optional(string, null)
        enrich_with_resource_attributes    = optional(list(string), null)
        name                               = string
        replace_resource_id_with_reference = optional(bool, null)
        resource_attribute_routing = optional(object({
          attribute_name  = optional(string, null)
          attribute_value = optional(string, null)
        }), null)
        streams = list(string)
      })), [])
      otel_metrics = optional(list(object({
        enrich_with_reference           = optional(string, null)
        enrich_with_resource_attributes = optional(list(string), null)
        name                            = string
        resource_attribute_routing = optional(object({
          attribute_name  = optional(string, null)
          attribute_value = optional(string, null)
        }), null)
        streams = list(string)
      })), [])
      otel_traces = optional(list(object({
        enrich_with_reference              = optional(string, null)
        enrich_with_resource_attributes    = optional(list(string), null)
        name                               = string
        replace_resource_id_with_reference = optional(bool, null)
        resource_attribute_routing = optional(object({
          attribute_name  = optional(string, null)
          attribute_value = optional(string, null)
        }), null)
        streams = list(string)
      })), [])
      performance_counters = optional(list(object({
        counter_specifiers            = list(string)
        name                          = string
        sampling_frequency_in_seconds = number
        streams                       = list(string)
        transform_kql                 = optional(string, null)
      })), [])
      performance_counters_otel = optional(list(object({
        counter_specifiers            = list(string)
        name                          = string
        sampling_frequency_in_seconds = number
        streams                       = list(string)
      })), [])
      platform_telemetry = optional(list(object({
        name    = string
        streams = list(string)
      })), [])
      prometheus_forwarder = optional(list(object({
        custom_vm_scrape_config = optional(list(any), null)
        label_include_filter    = optional(map(string), null)
        name                    = string
        streams                 = list(string)
      })), [])
      syslog = optional(list(object({
        facility_names = list(string)
        log_levels     = list(string)
        name           = string
        streams        = list(string)
        transform_kql  = optional(string, null)
      })), [])
      windows_event_logs = optional(list(object({
        name           = string
        streams        = list(string)
        transform_kql  = optional(string, null)
        x_path_queries = list(string)
      })), [])
      windows_firewall_logs = optional(list(object({
        name           = string
        profile_filter = optional(list(string), null)
        streams        = list(string)
      })), [])
    }), null)

    direct_data_sources = optional(object({
      otel_logs = optional(list(object({
        enrich_with_reference              = optional(string, null)
        enrich_with_resource_attributes    = optional(list(string), null)
        name                               = string
        replace_resource_id_with_reference = optional(bool, null)
        streams                            = list(string)
      })), [])
      otel_metrics = optional(list(object({
        enrich_with_reference           = optional(string, null)
        enrich_with_resource_attributes = optional(list(string), null)
        name                            = string
        streams                         = list(string)
      })), [])
      otel_traces = optional(list(object({
        enrich_with_reference              = optional(string, null)
        enrich_with_resource_attributes    = optional(list(string), null)
        name                               = string
        replace_resource_id_with_reference = optional(bool, null)
        streams                            = list(string)
      })), [])
    }), null)

    stream_declarations = optional(map(object({
      columns = list(object({
        name = string
        type = string
      }))
    })), {})

    agent_settings = optional(object({
      logs = optional(list(object({
        name  = string
        value = string
      })), [])
    }), null)

    references = optional(object({
      application_insights = optional(list(object({
        name        = string
        resource_id = string
      })), [])
      enrichment_data = optional(object({
        storage_blobs = optional(list(object({
          blob_url    = string
          lookup_type = string
          name        = string
          resource_id = string
        })), [])
      }), null)
    }), null)

    sku = optional(object({
      capacity = optional(number, null)
      family   = optional(string, null)
      name     = string
      size     = optional(string, null)
      tier     = optional(string, null)
    }), null)

    managed_identities = optional(object({
      system_assigned            = optional(bool, false)
      user_assigned_resource_ids = optional(set(string), [])
    }), {})

    role_assignments = optional(map(object({
      name                                   = optional(string, null)
      role_definition_id_or_name             = string
      principal_id                           = string
      description                            = optional(string, null)
      skip_service_principal_aad_check       = optional(bool, false)
      condition                              = optional(string, null)
      condition_version                      = optional(string, null)
      delegated_managed_identity_resource_id = optional(string, null)
      principal_type                         = optional(string, null)
    })), {})

    lock = optional(object({
      kind = string
      name = optional(string, null)
    }), null)

    diagnostic_settings = optional(map(object({
      name                                     = optional(string, null)
      log_categories                           = optional(set(string), [])
      log_groups                               = optional(set(string), ["allLogs"])
      metric_categories                        = optional(set(string), ["AllMetrics"])
      log_analytics_destination_type           = optional(string, "Dedicated")
      workspace_resource_id                    = optional(string, null)
      storage_account_resource_id              = optional(string, null)
      event_hub_authorization_rule_resource_id = optional(string, null)
      event_hub_name                           = optional(string, null)
      marketplace_partner_resource_id          = optional(string, null)
    })), {})

    tags = optional(map(string), null)
  })
  description = <<DESC
Configuration for the Data Collection Rule. Only used when create_dcr = true.

- name_override: explicit name; defaults to '<var.name>-dcr' if null.
- kind: 'Linux', 'Windows', or null.
- data_flows: REQUIRED for a working DCR — list of {streams, destinations} pairs.
- destinations: target sinks (Log Analytics, Event Hubs, Storage, etc.).
- data_sources: agent-collected sources (syslog, perf counters, IIS, etc.).
- direct_data_sources: OTel direct ingestion sources (no agent).
- stream_declarations: custom stream schemas.
- agent_settings / references / sku: optional AMA/OTel-related config.
- managed_identities / role_assignments / lock / diagnostic_settings / tags: standard AVM interfaces.

The DCR's data_collection_endpoint_id is wired automatically by the wrapper:
- create_dce = true               -> uses the DCE this wrapper provisions
- create_dce = false + external_dce_resource_id set -> uses that DCE
- create_dce = false + external null -> DCR has no DCE linkage (valid for some scenarios)
DESC
  default     = {}

  validation {
    condition     = var.dcr.kind == null || contains(["Linux", "Windows"], coalesce(var.dcr.kind, "Linux"))
    error_message = "dcr.kind must be 'Linux', 'Windows', or null."
  }

  validation {
    condition     = var.dcr.lock == null || contains(["CanNotDelete", "ReadOnly"], try(var.dcr.lock.kind, ""))
    error_message = "dcr.lock.kind must be 'CanNotDelete' or 'ReadOnly' when lock is set."
  }

  validation {
    condition = var.dcr.data_flows == null || alltrue([
      for f in coalesce(var.dcr.data_flows, []) :
      length(f.streams) > 0 && length(f.destinations) > 0
    ])
    error_message = "Each dcr.data_flows entry must have at least one stream and one destination."
  }
}

# =====================================================================
# Cross-component validation (Terraform >= 1.9 allows var-to-var refs)
# =====================================================================

variable "_validate_at_least_one_component" {
  type        = bool
  description = "Internal sentinel — do not set."
  default     = true

  validation {
    condition     = var.create_dce || var.create_dcr
    error_message = "At least one of create_dce or create_dcr must be true."
  }
}

variable "_validate_dcr_has_data_flows" {
  type        = bool
  description = "Internal sentinel — do not set."
  default     = true

  validation {
    condition     = !var.create_dcr || length(coalesce(var.dcr.data_flows, [])) > 0
    error_message = "When create_dcr = true, dcr.data_flows must define at least one flow (streams + destinations)."
  }
}

variable "_validate_dcr_has_destinations" {
  type        = bool
  description = "Internal sentinel — do not set."
  default     = true

  validation {
    condition     = !var.create_dcr || var.dcr.destinations != null
    error_message = "When create_dcr = true, dcr.destinations must be set so data_flows have somewhere to write."
  }
}
