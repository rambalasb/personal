output "resource_id" {
  value = module.fabric_capacity.resource_id
}

output "name" {
  value = module.fabric_capacity.name
}

output "state" {
  value = module.fabric_capacity.state
}
