module "fabric_capacity" {
  source = "../.."

  name      = "fcavmdefault${random_string.suffix.result}"
  parent_id = azurerm_resource_group.this.id
  location  = azurerm_resource_group.this.location

  # smallest SKU; the object ID only works when running as a service principal
  sku_name               = "F2"
  administration_members = [data.azurerm_client_config.current.object_id]

  enable_telemetry = false
}
