output "resource_id" {
  description = "The Azure resource ID of the Fabric capacity."
  value       = module.fabric_capacity.resource_id
}

output "name" {
  description = "The name of the Fabric capacity. Fabric workspaces are assigned to it by this name."
  value       = module.fabric_capacity.name
}

output "provisioning_state" {
  description = "Provisioning state of the capacity, e.g. Succeeded or Failed."
  value       = module.fabric_capacity.provisioning_state
}

output "state" {
  description = "Runtime state of the capacity, e.g. Active or Paused. A paused capacity provisions fine but serves no workloads."
  value       = module.fabric_capacity.state
}
