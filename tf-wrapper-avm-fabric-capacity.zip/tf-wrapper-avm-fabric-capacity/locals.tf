locals {
  # Suppressible so adopting an existing capacity does not force a write just to
  # add these.
  wrapper_tags = var.wrapper_tags_enabled ? {
    managed-by = "terraform"
    module     = "tf-wrapper-avm-fabric-capacity"
  } : {}

  module_tags = merge(
    var.tags == null ? {} : var.tags,
    local.wrapper_tags
  )
}
