check "lock_recommended" {
  assert {
    condition     = var.lock != null && try(var.lock.kind, "") == "CanNotDelete"
    error_message = "Deleting a Fabric capacity unassigns every workspace on it. Set lock = { kind = \"CanNotDelete\" }."
  }
}

check "cost_allocation_tags_present" {
  assert {
    condition     = length(var.tags == null ? {} : var.tags) > 0
    error_message = "Fabric capacity has no caller-supplied tags. Add cost-allocation tags (e.g. cost-center, owner, environment) via var.tags."
  }
}

check "more_than_one_admin" {
  assert {
    condition     = length(var.administration_members) > 1
    error_message = "Fabric capacity has a single admin. Add a second admin (e.g. the deployment service principal) so the capacity is not orphaned if that account is removed."
  }
}
