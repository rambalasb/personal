terraform {
  required_version = ">= 1.9, < 2.0"

  required_providers {
    # Upstream is azapi-only, lock and role assignments included. Floor matches
    # AVM avm-res-fabric-capacity v0.2.0.
    azapi = {
      source  = "Azure/azapi"
      version = "~> 2.12"
    }
  }
}
