module "fabric_capacity" {
  source  = "Azure/avm-res-fabric-capacity/azure"
  version = "0.2.0"

  # Required
  name      = var.name
  parent_id = var.parent_id
  location  = var.location

  # Capacity
  sku_name               = var.sku_name
  administration_members = var.administration_members

  # Governance
  role_assignments = var.role_assignments
  lock             = var.lock

  # Provider behaviour
  retry    = var.retry
  timeouts = var.timeouts

  # Module behavior
  enable_telemetry = var.enable_telemetry
  tags             = local.module_tags
}
