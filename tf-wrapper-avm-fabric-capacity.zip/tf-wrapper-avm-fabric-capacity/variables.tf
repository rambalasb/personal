# =====================================================================
# Required inputs
# =====================================================================

variable "name" {
  type        = string
  description = "Name of the Fabric capacity. 3-63 lowercase letters or numbers, starting with a letter. No hyphens."

  validation {
    condition     = can(regex("^[a-z][a-z0-9]{2,62}$", var.name))
    error_message = "name must be 3-63 lowercase letters or numbers and start with a lowercase letter."
  }
}

variable "parent_id" {
  type        = string
  description = "Resource ID of the resource group where the Fabric capacity will be deployed."

  validation {
    condition     = can(regex("^/subscriptions/[^/]+/resourceGroups/[^/]+$", var.parent_id))
    error_message = "parent_id must be a resource group resource ID: /subscriptions/<sub>/resourceGroups/<name>."
  }
}

variable "location" {
  type        = string
  description = "Azure region where the Fabric capacity will be deployed."

  validation {
    condition     = length(var.location) > 0
    error_message = "location must not be empty."
  }
}

variable "sku_name" {
  type        = string
  description = "Fabric F SKU. Changing it resizes the capacity in place."

  validation {
    condition     = contains(["F2", "F4", "F8", "F16", "F32", "F64", "F128", "F256", "F512", "F1024", "F2048"], var.sku_name)
    error_message = "sku_name must be one of F2, F4, F8, F16, F32, F64, F128, F256, F512, F1024, F2048."
  }
}

variable "administration_members" {
  type        = set(string)
  description = "Fabric capacity admins. UPN for an Entra user, object ID for a service principal. Entra groups are not accepted by the Fabric API."

  validation {
    condition = length(var.administration_members) > 0 && alltrue([
      for m in var.administration_members :
      can(regex("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$", m)) ||
      can(regex("(?i)^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", m))
    ])
    error_message = "administration_members must contain at least one Entra user UPN or service principal object ID."
  }
}

# =====================================================================
# Governance
# =====================================================================

variable "role_assignments" {
  type = map(object({
    role_definition_id_or_name             = string
    principal_id                           = string
    description                            = optional(string, null)
    skip_service_principal_aad_check       = optional(bool, false)
    condition                              = optional(string, null)
    condition_version                      = optional(string, null)
    delegated_managed_identity_resource_id = optional(string, null)
    principal_type                         = optional(string, null)
  }))
  description = "Azure RBAC (control-plane) role assignments scoped to the capacity. Workspace and capacity permissions inside Fabric are separate and not managed here."
  default     = {}
}

variable "lock" {
  type = object({
    kind = string
    name = optional(string, null)
  })
  description = "Optional resource lock. kind must be 'CanNotDelete' or 'ReadOnly'. ReadOnly also blocks pause/resume and SKU changes."
  default     = null

  validation {
    condition     = var.lock == null || contains(["CanNotDelete", "ReadOnly"], try(var.lock.kind, ""))
    error_message = "lock.kind must be 'CanNotDelete' or 'ReadOnly' when set."
  }
}

# =====================================================================
# Provider behaviour
# =====================================================================

variable "retry" {
  type = object({
    error_message_regex  = optional(list(string), ["ScopeLocked"])
    interval_seconds     = optional(number, null)
    max_interval_seconds = optional(number, null)
  })
  description = "azapi retry settings. Keep 'ScopeLocked' in error_message_regex if overriding; destroy races the lock removal without it."
  default     = {}
  nullable    = false
}

variable "timeouts" {
  type = object({
    create = optional(string, "30m")
    delete = optional(string, "30m")
    read   = optional(string, "5m")
    update = optional(string, "30m")
  })
  description = "Timeouts for capacity, lock and role assignment operations."
  default     = {}
  nullable    = false
}

# =====================================================================
# Module behavior
# =====================================================================

variable "enable_telemetry" {
  type        = bool
  description = "Whether to enable AVM module telemetry. Set false to opt out."
  default     = true
}

variable "tags" {
  type        = map(string)
  description = "A map of tags to apply to the Fabric capacity. Recommend cost-allocation tags given the capacity bills hourly while active."
  default     = null
}

variable "wrapper_tags_enabled" {
  type        = bool
  description = "Whether to add the wrapper's own managed-by/module tags. Set false only when adopting an existing capacity whose sole plan diff is those tags. Leave true otherwise."
  default     = true
}
