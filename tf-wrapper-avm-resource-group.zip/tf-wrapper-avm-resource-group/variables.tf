# =====================================================================
# Required inputs
# =====================================================================

variable "name" {
  type        = string
  description = "The name of the Resource Group. 1-90 characters; alphanumerics, underscores, parentheses, hyphens, periods. Cannot end with a period."

  validation {
    condition     = can(regex("^[a-zA-Z0-9_().-]{1,89}[a-zA-Z0-9_()-]$", var.name))
    error_message = "name must be 1-90 characters, contain only alphanumerics/underscores/parentheses/hyphens/periods, and cannot end with a period."
  }
}

variable "location" {
  type        = string
  description = "The Azure region where the Resource Group will be deployed."

  validation {
    condition     = length(var.location) > 0
    error_message = "location must not be empty."
  }
}

# =====================================================================
# Optional toggles
# =====================================================================

variable "enable_telemetry" {
  type        = bool
  description = "Whether to enable AVM module telemetry. Set false to opt out."
  default     = true
}

variable "lock" {
  type = object({
    kind = string
    name = optional(string, null)
  })
  description = "Optional resource lock applied to the Resource Group. kind must be 'CanNotDelete' or 'ReadOnly'."
  default     = null

  validation {
    condition     = var.lock == null || contains(["CanNotDelete", "ReadOnly"], try(var.lock.kind, ""))
    error_message = "lock.kind must be 'CanNotDelete' or 'ReadOnly' when lock is set."
  }
}

variable "managed_by" {
  type        = string
  description = "The Azure resource ID of the resource or application that manages this Resource Group (e.g. a Managed Application or Databricks workspace). Leave null for self-managed RGs."
  default     = null

  validation {
    condition     = var.managed_by == null || can(regex("^/.+/.+", var.managed_by))
    error_message = "managed_by must be null or a valid Azure resource ID starting with '/'."
  }
}

variable "role_assignments" {
  type = map(object({
    name                                   = optional(string, null)
    role_definition_id_or_name             = string
    principal_id                           = string
    description                            = optional(string, null)
    skip_service_principal_aad_check       = optional(bool, false)
    condition                              = optional(string, null)
    condition_version                      = optional(string, null)
    delegated_managed_identity_resource_id = optional(string, null)
    principal_type                         = optional(string, null)
  }))
  description = "Map of RBAC role assignments scoped to the Resource Group. Map key is a logical name. role_definition_id_or_name accepts a built-in role name (e.g. 'Reader'), a role GUID, or a full role-definition resource ID."
  default     = {}
}

variable "tags" {
  type        = map(string)
  description = "A map of tags to apply to the Resource Group."
  default     = null
}

# =====================================================================
# Provider behavior (retry, timeouts)
# =====================================================================

variable "retry" {
  type = object({
    error_message_regex  = optional(list(string), ["409 Conflict"])
    interval_seconds     = optional(number, null)
    max_interval_seconds = optional(number, null)
  })
  description = "Retry configuration applied to underlying azapi resources. Defaults retry on 409 Conflict responses."
  default     = {}
}

variable "timeouts" {
  type = object({
    create = optional(string, null)
    delete = optional(string, null)
    read   = optional(string, null)
    update = optional(string, null)
  })
  description = "Operation timeouts for the Resource Group, lock, and role assignments. Each value is a Go duration string (e.g. '5m', '1h30m')."
  default     = {}
}
