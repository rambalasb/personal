module "resource_group" {
  source = "../.."

  name     = "rg-avm-rg-default-test-${random_string.suffix.result}"
  location = "canadacentral"

  enable_telemetry = false
}
