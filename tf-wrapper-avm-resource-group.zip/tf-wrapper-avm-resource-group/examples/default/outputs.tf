output "resource_id" {
  value = module.resource_group.resource_id
}

output "name" {
  value = module.resource_group.name
}

output "location" {
  value = module.resource_group.location
}
