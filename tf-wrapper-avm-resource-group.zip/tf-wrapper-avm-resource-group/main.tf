module "resource_group" {
  source  = "Azure/avm-res-resources-resourcegroup/azurerm"
  version = "0.4.0"

  # Required
  name     = var.name
  location = var.location

  # Optional
  enable_telemetry = var.enable_telemetry
  lock             = var.lock
  managed_by       = var.managed_by
  role_assignments = var.role_assignments
  tags             = local.module_tags

  # Provider behavior
  retry    = var.retry
  timeouts = var.timeouts
}
