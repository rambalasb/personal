output "resource_id" {
  description = "The Azure resource ID of the Resource Group."
  value       = module.resource_group.resource_id
}

output "name" {
  description = "The name of the Resource Group."
  value       = module.resource_group.name
}

output "location" {
  description = "The Azure region of the Resource Group."
  value       = module.resource_group.location
}

output "resource" {
  description = "The full azapi_resource Resource Group object."
  value       = module.resource_group.resource
}
