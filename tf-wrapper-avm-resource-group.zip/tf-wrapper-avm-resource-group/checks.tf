check "tags_present" {
  assert {
    condition     = length(local.module_tags) > 0
    error_message = "Resource Group should have at least one tag for cost allocation and ownership tracking."
  }
}

check "lock_kind_valid_when_set" {
  assert {
    condition     = var.lock == null || contains(["CanNotDelete", "ReadOnly"], try(var.lock.kind, ""))
    error_message = "When lock is set, lock.kind must be 'CanNotDelete' or 'ReadOnly'."
  }
}

check "managed_by_format_valid" {
  assert {
    condition     = var.managed_by == null || can(regex("^/subscriptions/", var.managed_by))
    error_message = "When managed_by is set, it should be a full Azure resource ID starting with '/subscriptions/'."
  }
}
