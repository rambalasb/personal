check "vm_capture_targets_specialized_definition" {
  assert {
    condition = alltrue([
      for v in values(var.image_versions) : try(var.shared_image_definitions[v.image_key].specialized, false) == true
    ])
    error_message = "One or more image_versions capture a VM into a definition without specialized = true. Capturing a VM that was not sysprepped/deprovisioned into a generalized definition produces an image that fails to boot."
  }
}

check "trusted_launch_requires_gen2" {
  assert {
    condition = alltrue([
      for d in values(var.shared_image_definitions) : !(try(d.trusted_launch_enabled, false) == true || try(d.confidential_vm_supported, false) == true || try(d.confidential_vm_enabled, false) == true) || d.hyper_v_generation == "V2"
    ])
    error_message = "Trusted Launch / Confidential VM image definitions require hyper_v_generation = 'V2'. Azure rejects them on V1."
  }
}

check "gallery_not_shared_publicly" {
  assert {
    condition     = try(var.sharing.permission, "Private") != "Community"
    error_message = "Gallery sharing.permission is 'Community', which publishes images to every Azure tenant. Use 'Private' or 'Groups' unless this is intended."
  }
}

check "replicas_use_zrs" {
  assert {
    condition = alltrue(flatten([
      for regions in values(local.image_version_target_regions) : [
        for r in regions : r.storage_account_type != "Standard_LRS"
      ]
    ]))
    error_message = "One or more image version replicas use Standard_LRS. Prefer Standard_ZRS so the image survives a zone outage in its region."
  }
}
