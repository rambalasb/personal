locals {
  module_tags = merge(
    var.tags == null ? {} : var.tags,
    {
      managed-by = "terraform"
      module     = "tf-wrapper-avm-compute-gallery"
    }
  )

  shared_image_definitions = {
    for k, v in var.shared_image_definitions : k => merge(v, {
      tags = merge(local.module_tags, v.tags == null ? {} : v.tags)
    })
  }

  # Replicate to the gallery region only unless told otherwise.
  image_version_target_regions = {
    for k, v in var.image_versions : k => v.target_regions != null ? v.target_regions : [{
      name                        = var.location
      regional_replica_count      = 1
      storage_account_type        = "Standard_ZRS"
      disk_encryption_set_id      = null
      exclude_from_latest_enabled = false
    }]
  }

  # The AVM module only outputs the gallery ID, so definition IDs are derived.
  shared_image_definition_ids = {
    for k, v in var.shared_image_definitions : k => "${module.compute_gallery.resource_id}/images/${v.name}"
  }
}
