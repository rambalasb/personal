module "compute_gallery" {
  source = "../.."

  name                = "galavmdefaulttest${random_string.suffix.result}"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location

  shared_image_definitions = {
    linux_specialized = {
      name    = "img-linux-specialized"
      os_type = "Linux"
      identifier = {
        publisher = "bchydro"
        offer     = "avm-test"
        sku       = "linux-specialized"
      }
      specialized            = true
      hyper_v_generation     = "V2"
      trusted_launch_enabled = true
    }
  }

  # Capturing needs an existing, deallocated VM; add a version per capture:
  # image_versions = {
  #   v1_0_0 = {
  #     name                      = "1.0.0"
  #     image_key                 = "linux_specialized"
  #     source_virtual_machine_id = "<vm resource id>"
  #   }
  # }

  enable_telemetry = false
}
