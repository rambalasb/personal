output "resource_id" {
  value = module.compute_gallery.resource_id
}

output "shared_image_definition_ids" {
  value = module.compute_gallery.shared_image_definition_ids
}

output "image_version_ids" {
  value = module.compute_gallery.image_version_ids
}
