module "compute_gallery" {
  source  = "Azure/avm-res-compute-gallery/azurerm"
  version = "0.3.0"

  # Required
  name                = var.name
  resource_group_name = var.resource_group_name
  location            = var.location

  # Gallery
  description              = var.description
  sharing                  = var.sharing
  shared_image_definitions = local.shared_image_definitions

  # Governance
  role_assignments = var.role_assignments
  lock             = var.lock

  # Module behavior
  timeouts         = var.timeouts
  enable_telemetry = var.enable_telemetry
  tags             = local.module_tags
}

# Not covered by the AVM module. managed_image_id takes a VM ID directly, which
# captures the VM without going through an intermediate managed image.
resource "azurerm_shared_image_version" "this" {
  for_each = var.image_versions

  name                = each.value.name
  gallery_name        = module.compute_gallery.name
  image_name          = var.shared_image_definitions[each.value.image_key].name
  resource_group_name = var.resource_group_name
  location            = var.location
  managed_image_id    = each.value.source_virtual_machine_id

  exclude_from_latest                      = each.value.exclude_from_latest
  end_of_life_date                         = each.value.end_of_life_date
  replication_mode                         = each.value.replication_mode
  deletion_of_replicated_locations_enabled = each.value.deletion_of_replicated_locations_enabled
  tags                                     = merge(local.module_tags, each.value.tags == null ? {} : each.value.tags)

  dynamic "target_region" {
    for_each = local.image_version_target_regions[each.key]
    content {
      name                        = target_region.value.name
      regional_replica_count      = target_region.value.regional_replica_count
      storage_account_type        = target_region.value.storage_account_type
      disk_encryption_set_id      = target_region.value.disk_encryption_set_id
      exclude_from_latest_enabled = target_region.value.exclude_from_latest_enabled
    }
  }

  # Image definitions are created inside the module; the version cannot be
  # created until its definition exists.
  depends_on = [module.compute_gallery]
}
