output "resource_id" {
  description = "The Azure resource ID of the compute gallery."
  value       = module.compute_gallery.resource_id
}

output "name" {
  description = "The name of the compute gallery."
  value       = module.compute_gallery.name
}

output "shared_image_definition_ids" {
  description = "Map of image definition key to image definition resource ID."
  value       = local.shared_image_definition_ids
}

output "image_version_ids" {
  description = "Map of image version key to image version resource ID. Use as source_image_id on a VM."
  value       = { for k, v in azurerm_shared_image_version.this : k => v.id }
}
