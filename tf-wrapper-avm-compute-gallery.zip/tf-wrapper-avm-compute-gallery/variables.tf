# =====================================================================
# Required inputs
# =====================================================================

variable "name" {
  type        = string
  description = "Name of the compute gallery. 1-80 chars; letters, numbers, underscores and periods only. Hyphens are not allowed."

  validation {
    condition     = can(regex("^[A-Za-z0-9][A-Za-z0-9_.]{0,78}[A-Za-z0-9]$", var.name))
    error_message = "name must be 2-80 characters of letters, numbers, underscores or periods, starting and ending with a letter or number. Hyphens are not allowed."
  }
}

variable "resource_group_name" {
  type        = string
  description = "Name of the Resource Group where the gallery, image definitions and image versions will be deployed."

  validation {
    condition     = length(var.resource_group_name) > 0 && length(var.resource_group_name) <= 90
    error_message = "resource_group_name must be 1-90 characters."
  }
}

variable "location" {
  type        = string
  description = "Azure region of the gallery. Also the default replication region for image versions."

  validation {
    condition     = length(var.location) > 0
    error_message = "location must not be empty."
  }
}

# =====================================================================
# Gallery
# =====================================================================

variable "description" {
  type        = string
  description = "Description of the compute gallery."
  default     = null
}

variable "sharing" {
  type = object({
    permission = string
    community_gallery = optional(object({
      eula            = string
      prefix          = string
      publisher_email = string
      publisher_uri   = string
    }))
  })
  description = "Gallery sharing. permission is 'Private', 'Groups' or 'Community'. Leave null for a gallery shared only through RBAC. Forces a new gallery."
  default     = null

  validation {
    condition     = var.sharing == null || contains(["Private", "Groups", "Community"], try(var.sharing.permission, ""))
    error_message = "sharing.permission must be 'Private', 'Groups', or 'Community'."
  }
}

# =====================================================================
# Image definitions
# =====================================================================

variable "shared_image_definitions" {
  type = map(object({
    name = string
    identifier = object({
      publisher = string
      offer     = string
      sku       = string
    })
    os_type = string
    purchase_plan = optional(object({
      name      = string
      publisher = optional(string)
      product   = optional(string)
    }))
    description                         = optional(string)
    disk_controller_type_nvme_enabled   = optional(bool)
    disk_types_not_allowed              = optional(list(string))
    end_of_life_date                    = optional(string)
    eula                                = optional(string)
    specialized                         = optional(bool)
    architecture                        = optional(string, "x64")
    hyper_v_generation                  = optional(string, "V1")
    max_recommended_vcpu_count          = optional(number)
    min_recommended_vcpu_count          = optional(number)
    max_recommended_memory_in_gb        = optional(number)
    min_recommended_memory_in_gb        = optional(number)
    privacy_statement_uri               = optional(string)
    release_note_uri                    = optional(string)
    trusted_launch_enabled              = optional(bool)
    confidential_vm_supported           = optional(bool)
    confidential_vm_enabled             = optional(bool)
    accelerated_network_support_enabled = optional(bool)
    tags                                = optional(map(string))
  }))
  description = <<-EOT
    Image definitions in the gallery. For VM capture without sysprep set specialized = true.
    hyper_v_generation and trusted_launch_enabled must match the source VM; hyper_v_generation
    defaults to V1, so Gen2 VMs need V2 set explicitly. Most fields force a new definition.
  EOT
  default     = {}

  validation {
    condition     = alltrue([for d in values(var.shared_image_definitions) : contains(["Linux", "Windows"], d.os_type)])
    error_message = "os_type must be 'Linux' or 'Windows'."
  }

  validation {
    condition     = alltrue([for d in values(var.shared_image_definitions) : contains(["V1", "V2"], d.hyper_v_generation)])
    error_message = "hyper_v_generation must be 'V1' or 'V2'."
  }

  validation {
    condition     = alltrue([for d in values(var.shared_image_definitions) : contains(["x64", "Arm64"], d.architecture)])
    error_message = "architecture must be 'x64' or 'Arm64'."
  }
}

# =====================================================================
# Image versions
# =====================================================================

variable "image_versions" {
  type = map(object({
    name                      = string
    image_key                 = string
    source_virtual_machine_id = string
    target_regions = optional(list(object({
      name                        = string
      regional_replica_count      = optional(number, 1)
      storage_account_type        = optional(string, "Standard_ZRS")
      disk_encryption_set_id      = optional(string)
      exclude_from_latest_enabled = optional(bool, false)
    })))
    exclude_from_latest                      = optional(bool, false)
    end_of_life_date                         = optional(string)
    replication_mode                         = optional(string, "Full")
    deletion_of_replicated_locations_enabled = optional(bool, false)
    tags                                     = optional(map(string))
  }))
  description = <<-EOT
    Image versions captured from existing VMs. image_key is the key of the target entry in
    shared_image_definitions. Versions are immutable: recapture by adding a new entry with a
    new name rather than changing source_virtual_machine_id, which forces replacement.
    Deallocate the source VM before apply so the disks are consistent.
    target_regions defaults to the gallery region with one ZRS replica.
  EOT
  default     = {}

  validation {
    condition     = alltrue([for v in values(var.image_versions) : can(regex("^[0-9]+\\.[0-9]+\\.[0-9]+$", v.name))])
    error_message = "Image version name must be MAJOR.MINOR.PATCH, e.g. '1.0.0'."
  }

  validation {
    condition     = alltrue([for v in values(var.image_versions) : contains(keys(var.shared_image_definitions), v.image_key)])
    error_message = "Every image_versions[*].image_key must match a key in shared_image_definitions."
  }

  validation {
    condition     = alltrue([for v in values(var.image_versions) : can(regex("(?i)/providers/Microsoft\\.Compute/virtualMachines/[^/]+$", v.source_virtual_machine_id))])
    error_message = "source_virtual_machine_id must be a virtual machine resource ID."
  }

  validation {
    condition     = alltrue([for v in values(var.image_versions) : contains(["Full", "Shallow"], v.replication_mode)])
    error_message = "replication_mode must be 'Full' or 'Shallow'."
  }

  validation {
    condition = alltrue(flatten([
      for v in values(var.image_versions) : [
        for r in coalesce(v.target_regions, []) : contains(["Standard_LRS", "Standard_ZRS", "Premium_LRS"], r.storage_account_type)
      ]
    ]))
    error_message = "target_regions[*].storage_account_type must be 'Standard_LRS', 'Standard_ZRS', or 'Premium_LRS'."
  }
}

# =====================================================================
# Governance
# =====================================================================

variable "role_assignments" {
  type = map(object({
    role_definition_id_or_name             = string
    principal_id                           = string
    description                            = optional(string, null)
    skip_service_principal_aad_check       = optional(bool, false)
    condition                              = optional(string, null)
    condition_version                      = optional(string, null)
    delegated_managed_identity_resource_id = optional(string, null)
    principal_type                         = optional(string, null)
  }))
  description = "RBAC role assignments scoped to the gallery."
  default     = {}
}

variable "lock" {
  type = object({
    kind = string
    name = optional(string, null)
  })
  description = "Optional resource lock on the gallery. A CanNotDelete lock also blocks removing old image versions."
  default     = null

  validation {
    condition     = var.lock == null || contains(["CanNotDelete", "ReadOnly"], try(var.lock.kind, ""))
    error_message = "lock.kind must be 'CanNotDelete' or 'ReadOnly' when lock is set."
  }
}

# =====================================================================
# Module behavior
# =====================================================================

variable "timeouts" {
  type = object({
    create = optional(string)
    delete = optional(string)
    read   = optional(string)
    update = optional(string)
  })
  description = "Timeouts for the gallery resource."
  default     = null
}

variable "enable_telemetry" {
  type        = bool
  description = "Whether to enable AVM module telemetry. Set false to opt out."
  default     = true
}

variable "tags" {
  type        = map(string)
  description = "A map of tags to apply to the gallery, image definitions and image versions."
  default     = null
}
