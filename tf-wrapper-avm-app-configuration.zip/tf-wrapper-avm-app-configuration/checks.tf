check "purge_protection_enabled" {
  assert {
    condition     = var.purge_protection_enabled
    error_message = "App Configuration should have purge protection enabled. Set var.purge_protection_enabled = true to comply."
  }
}

check "entra_auth_only" {
  assert {
    condition     = !var.local_auth_enabled
    error_message = "App Configuration should use Microsoft Entra authentication only. Set var.local_auth_enabled = false to disable access-key auth."
  }
}

check "private_endpoint_implies_no_public_access" {
  assert {
    condition     = length(var.private_endpoints) == 0 || !var.public_network_access_enabled
    error_message = "When private endpoints are configured, public network access should be disabled. Set var.public_network_access_enabled = false."
  }
}

check "free_sku_has_no_soft_delete" {
  assert {
    condition     = var.sku != "free" || var.soft_delete_retention_days == null
    error_message = "The 'free' SKU does not support soft delete. Set var.soft_delete_retention_days = null when var.sku = \"free\"."
  }
}

check "paid_sku_soft_delete_meets_minimum" {
  assert {
    condition     = var.sku == "free" || var.soft_delete_retention_days == null ? true : var.soft_delete_retention_days >= 1
    error_message = "soft_delete_retention_days should be at least 1 day for recoverability on paid SKUs."
  }
}
