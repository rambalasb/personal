module "app_configuration" {
  source  = "Azure/avm-res-appconfiguration-configurationstore/azure"
  version = "0.5.1"

  # Required
  name                       = var.name
  location                   = var.location
  resource_group_resource_id = var.resource_group_resource_id

  # Core toggles
  sku                           = var.sku
  enable_telemetry              = var.enable_telemetry
  local_auth_enabled            = var.local_auth_enabled
  public_network_access_enabled = var.public_network_access_enabled
  purge_protection_enabled      = var.purge_protection_enabled
  soft_delete_retention_days    = var.soft_delete_retention_days
  data_plane_proxy              = var.data_plane_proxy

  # Networking
  private_endpoints                       = var.private_endpoints
  private_endpoints_manage_dns_zone_group = var.private_endpoints_manage_dns_zone_group

  # Identity, RBAC, CMK
  managed_identities   = var.managed_identities
  role_assignments     = var.role_assignments
  customer_managed_key = var.customer_managed_key

  # Store content & geo-replication
  key_values = var.key_values
  replicas   = var.replicas

  # Diagnostics, locks, tagging
  diagnostic_settings = var.diagnostic_settings
  lock                = var.lock
  tags                = local.module_tags
}
