output "resource_id" {
  description = "The Azure resource ID of the App Configuration store."
  value       = module.app_configuration.resource_id
}

output "name" {
  description = "The name of the App Configuration store."
  value       = module.app_configuration.name
}

output "endpoint" {
  description = "The endpoint (hostname) of the App Configuration store."
  value       = module.app_configuration.endpoint
}

output "private_endpoint_resource_ids" {
  description = "Map of private endpoints created for the store, keyed by the input map key, to their resource IDs."
  value       = module.app_configuration.private_endpoint_resource_ids
}

output "private_endpoint_network_interface_ids" {
  description = "Map of private endpoints created for the store to their network interface IDs."
  value       = module.app_configuration.private_endpoint_network_interface_ids
}

output "replica_resource_ids" {
  description = "Map of replicas created, keyed by the input map key, to their resource IDs."
  value       = module.app_configuration.replica_resource_ids
}

output "replica_names" {
  description = "Map of replicas created, keyed by the input map key, to their names."
  value       = module.app_configuration.replica_names
}
