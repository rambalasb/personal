# =====================================================================
# Required inputs
# =====================================================================

variable "name" {
  type        = string
  description = "The name of the App Configuration store. Must be 5-50 characters, alphanumerics and hyphens only, no leading/trailing hyphen, no run of three or more hyphens, and globally unique within Azure."

  validation {
    condition     = can(regex("^[a-zA-Z0-9-]{5,50}$", var.name))
    error_message = "name must be 5-50 characters and contain only alphanumerics and hyphens."
  }

  validation {
    condition     = !can(regex("^-.*|.*-$", var.name)) && !can(regex(".*---.*", var.name))
    error_message = "name must not start or end with a hyphen, nor contain a run of three or more hyphens."
  }
}

variable "location" {
  type        = string
  description = "The Azure region where the App Configuration store will be deployed."

  validation {
    condition     = length(var.location) > 0
    error_message = "location must not be empty."
  }
}

variable "resource_group_resource_id" {
  type        = string
  description = "The full resource ID of the resource group in which to create the store (e.g. /subscriptions/<sub>/resourceGroups/<rg>)."

  validation {
    condition     = can(regex("^/subscriptions/[^/]+/resourceGroups/[^/]+$", var.resource_group_resource_id))
    error_message = "resource_group_resource_id must be a valid resource group resource ID."
  }
}

# =====================================================================
# Core toggles (secured defaults — override per environment as needed)
# =====================================================================

variable "sku" {
  type        = string
  description = "The SKU of the store. Allowed values: 'free', 'developer', 'standard', 'premium'. Set soft_delete_retention_days = null for the 'free' SKU. Private endpoints and geo-replication require a paid SKU."
  default     = "standard"

  validation {
    condition     = contains(["free", "developer", "standard", "premium"], var.sku)
    error_message = "sku must be one of 'free', 'developer', 'standard', 'premium'."
  }
}

variable "enable_telemetry" {
  type        = bool
  description = "Whether to enable AVM module telemetry. Set false to opt out of anonymous usage data collection."
  default     = true
}

variable "local_auth_enabled" {
  type        = bool
  description = "Whether access-key (local) authentication is permitted. Leave false to require Microsoft Entra authentication only."
  default     = false
}

variable "public_network_access_enabled" {
  type        = bool
  description = "Whether the store is reachable from the public internet. Kept false so access is via private endpoint only."
  default     = false
}

variable "purge_protection_enabled" {
  type        = bool
  description = "Whether purge protection is enabled. Strongly recommended for production stores."
  default     = true
}

variable "soft_delete_retention_days" {
  type        = number
  description = "Number of days a soft-deleted store is retained before permanent deletion. Must be null for the 'free' SKU; a non-negative integer otherwise."
  default     = 7

  validation {
    condition     = var.soft_delete_retention_days == null ? true : var.soft_delete_retention_days >= 0 && floor(var.soft_delete_retention_days) == var.soft_delete_retention_days
    error_message = "soft_delete_retention_days must be a non-negative integer, or null."
  }
}

variable "data_plane_proxy" {
  type = object({
    authentication_mode     = string
    private_link_delegation = string
  })
  description = "Data plane proxy configuration (data-plane access via Azure Resource Manager). authentication_mode: 'Local' or 'Pass-through'. private_link_delegation: 'Enabled' or 'Disabled'. Null uses module defaults (Pass-through / Disabled)."
  default     = null

  validation {
    condition     = var.data_plane_proxy == null ? true : contains(["Local", "Pass-through"], var.data_plane_proxy.authentication_mode)
    error_message = "data_plane_proxy.authentication_mode must be 'Local' or 'Pass-through'."
  }

  validation {
    condition     = var.data_plane_proxy == null ? true : contains(["Enabled", "Disabled"], var.data_plane_proxy.private_link_delegation)
    error_message = "data_plane_proxy.private_link_delegation must be 'Enabled' or 'Disabled'."
  }
}

# =====================================================================
# Networking — private endpoints
# =====================================================================

variable "private_endpoints" {
  type = map(object({
    name = optional(string, null)
    role_assignments = optional(map(object({
      role_definition_id_or_name             = string
      principal_id                           = string
      principal_type                         = optional(string, null)
      description                            = optional(string, null)
      skip_service_principal_aad_check       = optional(bool, false)
      condition                              = optional(string, null)
      condition_version                      = optional(string, null)
      delegated_managed_identity_resource_id = optional(string, null)
    })), {})
    lock = optional(object({
      kind = string
      name = optional(string, null)
    }), null)
    tags                                    = optional(map(string), null)
    subnet_resource_id                      = string
    private_dns_zone_group_name             = optional(string, "default")
    private_dns_zone_resource_ids           = optional(set(string), [])
    application_security_group_associations = optional(map(string), {})
    private_service_connection_name         = optional(string, null)
    network_interface_name                  = optional(string, null)
    location                                = optional(string, null)
    resource_group_name                     = optional(string, null)
    ip_configurations = optional(map(object({
      name               = string
      private_ip_address = string
    })), {})
  }))
  description = "A map of private endpoint configurations. Map key is a logical name; subnet_resource_id is required per entry. Associate the 'privatelink.azconfig.io' zone via private_dns_zone_resource_ids. Set to {} to disable."
  default     = {}
}

variable "private_endpoints_manage_dns_zone_group" {
  type        = bool
  description = "Whether the module manages private DNS zone groups for private endpoints. Set false when DNS is managed externally (e.g. via Azure Policy)."
  default     = true
}

# =====================================================================
# Identity, RBAC, and customer-managed keys
# =====================================================================

variable "managed_identities" {
  type = object({
    system_assigned            = optional(bool, false)
    user_assigned_resource_ids = optional(set(string), [])
  })
  description = "Managed identity configuration. system_assigned enables a system-assigned identity; user_assigned_resource_ids attaches user-assigned identities. A user-assigned identity is required for customer-managed key encryption."
  default     = {}
}

variable "role_assignments" {
  type = map(object({
    role_definition_id_or_name             = string
    principal_id                           = string
    principal_type                         = optional(string, null)
    description                            = optional(string, null)
    skip_service_principal_aad_check       = optional(bool, false)
    condition                              = optional(string, null)
    condition_version                      = optional(string, null)
    delegated_managed_identity_resource_id = optional(string, null)
  }))
  description = "A map of role assignments to create on the store. Map key is a logical name. Use built-in role names like 'App Configuration Data Owner' or 'App Configuration Data Reader'."
  default     = {}
}

variable "customer_managed_key" {
  type = object({
    key_vault_resource_id = string
    key_name              = string
    key_version           = optional(string, null)
    user_assigned_identity = optional(object({
      resource_id = string
    }), null)
  })
  description = "Customer-managed key for encryption at rest. Requires a paid SKU and a user-assigned identity with access to the key. Null uses Microsoft-managed keys."
  default     = null
}

# =====================================================================
# Store content & geo-replication
# =====================================================================

variable "key_values" {
  type = map(object({
    key          = string
    value        = string
    content_type = optional(string, null)
    label        = optional(string, null)
    tags         = optional(map(string), null)
  }))
  description = "Map of key-value settings (and feature flags via content_type) to seed into the store. Map key is a logical name. Set to {} to skip."
  default     = {}
}

variable "replicas" {
  type = map(object({
    name     = string
    location = string
  }))
  description = "Map of geo-replicas to create. Each entry needs a unique name and a target location. Requires the 'standard' or 'premium' SKU. Set to {} to skip."
  default     = {}
}

# =====================================================================
# Diagnostics, locks, tagging
# =====================================================================

variable "diagnostic_settings" {
  type = map(object({
    name                                     = optional(string, null)
    log_categories                           = optional(set(string), [])
    log_groups                               = optional(set(string), ["allLogs"])
    metric_categories                        = optional(set(string), ["AllMetrics"])
    log_analytics_destination_type           = optional(string, "Dedicated")
    workspace_resource_id                    = optional(string, null)
    storage_account_resource_id              = optional(string, null)
    event_hub_authorization_rule_resource_id = optional(string, null)
    event_hub_name                           = optional(string, null)
    marketplace_partner_resource_id          = optional(string, null)
  }))
  description = "Map of diagnostic settings. Provide at least one destination per entry (workspace, storage, event hub, or marketplace partner)."
  default     = {}
}

variable "lock" {
  type = object({
    kind = string
    name = optional(string, null)
  })
  description = "Optional resource lock. kind must be 'CanNotDelete' or 'ReadOnly'. Set null to disable."
  default     = null

  validation {
    condition     = var.lock == null || contains(["CanNotDelete", "ReadOnly"], try(var.lock.kind, ""))
    error_message = "lock.kind must be 'CanNotDelete' or 'ReadOnly' when lock is set."
  }
}

variable "tags" {
  type        = map(string)
  description = "A map of tags applied to the App Configuration store."
  default     = null
}
