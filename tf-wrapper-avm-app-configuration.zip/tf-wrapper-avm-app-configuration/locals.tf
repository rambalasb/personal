locals {
  module_tags = merge(
    var.tags == null ? {} : var.tags,
    {
      managed-by = "terraform"
      module     = "tf-wrapper-avm-app-configuration"
    }
  )

  # Surfaced as non-blocking checks in checks.tf rather than enforced here, so
  # callers retain explicit control over posture.
  has_private_endpoints = length(var.private_endpoints) > 0
}
