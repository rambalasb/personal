module "app_configuration" {
  source = "../.."

  name                       = "appcs-avm-${random_string.suffix.result}"
  location                   = azurerm_resource_group.this.location
  resource_group_resource_id = azurerm_resource_group.this.id

  enable_telemetry = false
}
