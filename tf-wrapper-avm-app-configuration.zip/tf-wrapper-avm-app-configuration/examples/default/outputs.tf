output "resource_id" {
  value = module.app_configuration.resource_id
}

output "name" {
  value = module.app_configuration.name
}

output "endpoint" {
  value = module.app_configuration.endpoint
}
