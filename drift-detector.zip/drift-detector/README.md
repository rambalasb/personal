# drift-detector (POC)

A Function App that reports where Azure and Terraform state disagree, beyond
what HCP drift detection sees:

- resources created by hand, and resources in state that no longer exist
- child objects (subnets, containers, Key Vault secrets and keys, federated
  credentials, ...)
- role assignments, locks, policy assignments and exemptions, diagnostic settings
- **changes to anything not in state**, from one run to the next

It lives in a wrapper repo only so it can be deployed with that repo's
credentials. It doesn't use the repo's own module: everything, the resource
group included, comes from the `tf-wrapper-avm-*` modules in the private
registry. So it works from any wrapper repo.

## Deploy and test

Actions -> **drift-detector** -> Run workflow:

| action | does |
|---|---|
| `plan` | terraform plan only |
| `apply` | deploys the infra, runs the unit tests, publishes the code, then calls the function once and writes the result to the run summary |
| `check` | calls the deployed function once |
| `destroy` | tears it down and deletes the workspace |

It uses the same variables, Key Vault secrets and `test` environment as
`module-test.yml`. State lives in the TFC workspace `wrappers-drift-detector-poc`.

With no `targets` set, the function checks its own workspace and resource
group. To see it work:

1. Run `apply`. The first report is the baseline: no changes can be reported
   until there's a previous snapshot to compare against.
2. In the portal, in the `rg-tfdrift-poc` resource group, do one or more of
   these:
   - add a storage container
   - add a Key Vault secret
   - change a tag on the Key Vault
   - grant someone a role on the storage account
   - add a diagnostic setting
3. Run `check`. Each change should be listed as unmanaged or, on the next
   run, changed. The report also says who made the change when Resource Graph
   change history has it.

The function also runs on its own daily at 14:30 UTC. Reports are in the
storage account's `drift-reports` container, under `<name>/latest/report.txt`.

## Pointing it at real workspaces

Add a `drift.auto.tfvars` here (see `variables.tf` for the shape):

```hcl
targets = [
  { name = "platform-identity", workspace = "az-platform-identity", subscription_id = "<sub>" },
]
subscriptions = [
  { subscription_id = "<sub>", name = "platform-identity",
    waivers = ["check=role_assignments principal_type=User  # PIM"] },
]
```

The HCP token stored in the detector's Key Vault needs read access to those
workspaces' state. The detector's identity gets Reader on every subscription
listed.

## Test-only settings

- **Public endpoints.** The function, storage and Key Vault have public
  network access because the test subscription has no VNet. Production should
  use VNet integration and private endpoints.
- **Shared CI token.** The Key Vault holds `TF-API-TOKEN-TEST`, the same token
  CI uses. Production should use its own team token with read-state-versions
  only.
- **No purge protection** on the Key Vault, so a destroy can be re-applied
  with the same name.

## Running the checks locally

```bash
cd function
pip install -r requirements.txt pytest && python -m pytest -q
python drift.py coverage --subscription <sub> --state state.json --snapshot snap.json   # after az login
```
