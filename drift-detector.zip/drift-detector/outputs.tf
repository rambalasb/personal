output "resource_group_name" {
  value = module.resource_group.name
}

output "function_app_name" {
  value = module.function_app.name
}

output "function_identity_client_id" {
  value = module.user_assigned_identity.client_id
}

output "reports_url" {
  value = "${local.blob_endpoint}drift-reports"
}

output "drift_endpoint" {
  description = "Needs ?code=<function key>; the workflow fetches it."
  value       = "https://${module.function_app.resource_uri}/api/drift"
}
