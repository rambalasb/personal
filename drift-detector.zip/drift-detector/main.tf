# Subscription and tenant come from the runner's ARM_* login.
data "azurerm_client_config" "current" {}

resource "random_string" "suffix" {
  length  = 5
  upper   = false
  special = false
}

locals {
  common_tags = merge(var.tags, {
    managed-by = "terraform"
    solution   = "tf-drift-detector"
  })

  # Storage and Key Vault names are global and short.
  compact = substr(replace(var.name, "-", ""), 0, 16)
  suffix  = random_string.suffix.result

  storage_account_name = "st${local.compact}${local.suffix}"
  blob_endpoint        = "https://${local.storage_account_name}.blob.core.windows.net/"

  subscription_id = data.azurerm_client_config.current.subscription_id
  tenant_id       = data.azurerm_client_config.current.tenant_id

  # No targets given: check this deployment's own workspace and resource
  # group. Break something in the portal and the next run should say so.
  targets = length(var.targets) > 0 ? var.targets : [{
    name                  = "self"
    workspace             = var.tfc_workspace
    subscription_id       = local.subscription_id
    scope_resource_groups = []
    scope_types           = []
    exclude_types         = []
    waivers               = []
  }]
  subscriptions = length(var.subscriptions) > 0 ? var.subscriptions : [{
    subscription_id       = local.subscription_id
    name                  = "self-sub"
    checks                = []
    scope_resource_groups = [module.resource_group.name]
    waivers               = []
    expected              = []
    use_default_waivers   = true
    enabled               = true
  }]

  target_subscriptions = toset(concat(
    [for t in local.targets : t.subscription_id],
    [for s in local.subscriptions : s.subscription_id],
  ))

  func_principal = module.user_assigned_identity.principal_id
  deployer       = data.azurerm_client_config.current.object_id
}

# From the registry, not "../..", so the example works from any wrapper repo.
module "resource_group" {
  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-resource-group/azurerm"
  version = "2.0.0"

  name     = "rg-${var.name}"
  location = var.location

  enable_telemetry = false
  tags             = local.common_tags
}

module "user_assigned_identity" {
  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-user-assigned-identity/azurerm"
  version = "0.0.4"

  name                = "id-${var.name}"
  resource_group_name = module.resource_group.name
  location            = var.location

  enable_telemetry = false
  tags             = local.common_tags
}

# Function host storage (package container, timer leases) plus the reports.
module "storage_account" {
  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-storage-account/azurerm"
  version = "0.3.0"

  name                     = local.storage_account_name
  parent_id                = module.resource_group.resource_id
  location                 = var.location
  account_replication_type = "LRS"

  # Keys stay off; everything authenticates with Entra ID.
  shared_access_key_enabled = false

  # Flex Consumption without VNet integration reaches its storage over the
  # public endpoint. See var.public_network_access.
  public_network_access_enabled = var.public_network_access
  network_rules                 = var.public_network_access ? { default_action = "Allow" } : {}

  containers = {
    package = { name = "app-package" }
    reports = { name = "drift-reports" }
  }

  role_assignments = {
    func_blob = {
      role_definition_id_or_name = "Storage Blob Data Owner"
      principal_id               = local.func_principal
      principal_type             = "ServicePrincipal"
    }
    func_queue = {
      role_definition_id_or_name = "Storage Queue Data Contributor"
      principal_id               = local.func_principal
      principal_type             = "ServicePrincipal"
    }
    func_table = {
      role_definition_id_or_name = "Storage Table Data Contributor"
      principal_id               = local.func_principal
      principal_type             = "ServicePrincipal"
    }
    # whoever applies this can read the reports without a second grant
    deployer_blob = {
      role_definition_id_or_name = "Storage Blob Data Contributor"
      principal_id               = local.deployer
    }
  }

  enable_telemetry = false
  tags             = local.common_tags
}

# Holds the HCP token; the function reads it with its own identity.
module "key_vault" {
  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-key-vault/azurerm"
  version = "0.3.0"

  name                = "kv-${substr(local.compact, 0, 12)}-${local.suffix}"
  resource_group_name = module.resource_group.name
  location            = var.location
  tenant_id           = local.tenant_id
  sku_name            = "standard"

  # Test subscription: nothing worth keeping, and a purge-protected vault name
  # can't be reused for 90 days after a destroy.
  purge_protection_enabled   = false
  soft_delete_retention_days = 7

  public_network_access_enabled = var.public_network_access
  network_acls = var.public_network_access ? {
    bypass         = "AzureServices"
    default_action = "Allow"
  } : {}

  role_assignments = {
    func_secrets_user = {
      role_definition_id_or_name = "Key Vault Secrets User"
      principal_id               = local.func_principal
      principal_type             = "ServicePrincipal"
    }
    deployer_secrets_officer = {
      role_definition_id_or_name = "Key Vault Secrets Officer"
      principal_id               = local.deployer
    }
  }

  secrets       = var.tfc_token == null ? {} : { tfc_token = { name = "tfc-token" } }
  secrets_value = var.tfc_token == null ? null : { tfc_token = var.tfc_token }

  enable_telemetry = false
  tags             = local.common_tags
}

module "log_analytics_workspace" {
  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-log-analytics-workspace/azurerm"
  version = "0.1.2"

  name                                      = "log-${var.name}"
  resource_group_name                       = module.resource_group.name
  location                                  = var.location
  log_analytics_workspace_retention_in_days = 30

  enable_telemetry = false
  tags             = local.common_tags
}

module "application_insights" {
  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-application-insights/azurerm"
  version = "0.1.0"

  name                          = "appi-${var.name}"
  resource_group_name           = module.resource_group.name
  location                      = var.location
  workspace_id                  = module.log_analytics_workspace.resource_id
  application_type              = "other"
  local_authentication_disabled = true

  role_assignments = {
    func_publisher = {
      role_definition_id_or_name = "Monitoring Metrics Publisher"
      principal_id               = local.func_principal
      principal_type             = "ServicePrincipal"
    }
  }

  enable_telemetry = false
  tags             = local.common_tags
}

module "app_service_plan" {
  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-app-service-plan/azurerm"
  version = "0.1.0"

  subscription_id     = local.subscription_id
  name                = "asp-${var.name}"
  resource_group_name = module.resource_group.name
  location            = var.location
  os_type             = "Linux"
  sku_name            = "FC1"

  # FC1 scales per execution; the zone/worker checks are for dedicated plans.
  zone_balancing_enabled = false
  worker_count           = 1

  enable_telemetry = false
  tags             = local.common_tags
}

module "function_app" {
  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-function-app/azurerm"
  version = "0.1.0"

  subscription_id          = local.subscription_id
  name                     = "func-${var.name}-${local.suffix}"
  resource_group_name      = module.resource_group.name
  location                 = var.location
  service_plan_resource_id = module.app_service_plan.resource_id
  os_type                  = "Linux"

  function_app_uses_fc1  = true
  fc1_runtime_name       = "python"
  fc1_runtime_version    = "3.11"
  instance_memory_in_mb  = 2048
  maximum_instance_count = 40

  storage_container_type            = "blobContainer"
  storage_container_endpoint        = "${local.blob_endpoint}app-package"
  storage_authentication_type       = "UserAssignedIdentity"
  storage_user_assigned_identity_id = module.user_assigned_identity.resource_id
  # The deployment package above already uses the identity. Left false because
  # true makes AVM web-site 0.22.0 write AzureWebJobsStorage__accountName from
  # storage_account_name after app_settings, overwriting the three below.
  storage_uses_managed_identity = false

  managed_identities = {
    user_assigned_resource_ids = [module.user_assigned_identity.resource_id]
  }

  application_insights_connection_string = module.application_insights.connection_string

  # Needed for the HTTP trigger and for publishing from outside a VNet.
  public_network_access_enabled            = var.public_network_access
  https_only                               = true
  ftp_publish_basic_authentication_enabled = false
  scm_publish_basic_authentication_enabled = false

  app_settings = {
    AzureWebJobsStorage__accountName          = local.storage_account_name
    AzureWebJobsStorage__credential           = "managedidentity"
    AzureWebJobsStorage__clientId             = module.user_assigned_identity.client_id
    APPLICATIONINSIGHTS_AUTHENTICATION_STRING = "ClientId=${module.user_assigned_identity.client_id};Authorization=AAD"

    # DefaultAzureCredential picks the user-assigned identity from this.
    AZURE_CLIENT_ID = module.user_assigned_identity.client_id

    DRIFT_SCHEDULE             = var.schedule
    TFC_ORGANIZATION           = var.tfc_organization
    KEY_VAULT_URL              = module.key_vault.uri
    TFC_TOKEN_SECRET_NAME      = "tfc-token"
    TARGETS_JSON               = jsonencode({ targets = local.targets, subscriptions = local.subscriptions })
    REPORT_STORAGE_ACCOUNT_URL = local.blob_endpoint
    REPORT_CONTAINER           = "drift-reports"
  }

  enable_telemetry = false
  tags             = local.common_tags

  depends_on = [module.storage_account]
}

# Reader is enough for every check, role assignments and diagnostic settings
# included. In tf-deploy-platform-management this becomes one grant at a
# management group instead of one per subscription.
module "role_assignment" {
  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-role-assignment/azurerm"
  version = "0.3.6"

  role_assignments_azure_resource_manager = {
    for sub in local.target_subscriptions : "reader_${sub}" => {
      role_definition_name = "Reader"
      principal_id         = local.func_principal
      principal_type       = "ServicePrincipal"
      scope                = "/subscriptions/${sub}"
    }
  }
}

# Matches the line drift/runner.py writes per target and per coverage pass:
#   drift <name>: FAIL ...   /   drift <name>: ERROR ...
module "monitoring" {
  count = var.alert_email == null ? 0 : 1

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-ptn-monitoring-amba-alz/azurerm"
  version = "0.3.0"

  enable_amba = false
  location    = var.location

  action_groups = {
    drift = {
      name                = "ag-${var.name}"
      resource_group_name = module.resource_group.name
      short_name          = "tfdrift"
      email_receivers = {
        owner = { email_address = var.alert_email }
      }
    }
  }

  log_search_alerts = {
    drift = {
      name                 = "alert-${var.name}-drift"
      resource_group_name  = module.resource_group.name
      location             = var.location
      scopes               = [module.application_insights.resource_id]
      severity             = 2
      evaluation_frequency = "PT1H"
      window_duration      = "PT1H"
      description          = "Azure and Terraform state disagree, or a check could not complete. Reports are in the drift-reports container."
      criteria = [{
        query                   = <<-KQL
          traces
          | where message matches regex @"^drift \S+: (FAIL|ERROR)"
          | extend Target = extract(@"^drift (\S+):", 1, message), Status = extract(@": (FAIL|ERROR)", 1, message)
          | summarize Count = count() by Target, Status
        KQL
        time_aggregation_method = "Count"
        operator                = "GreaterThan"
        threshold               = 0
        dimensions = [{
          name     = "Target"
          operator = "Include"
          values   = ["*"]
        }]
      }]
      action_group_keys = ["drift"]
    }
  }

  enable_telemetry = false
  tags             = local.common_tags
}

check "self_target_needs_workspace" {
  assert {
    condition     = length(var.targets) > 0 || var.tfc_workspace != null
    error_message = "No targets and no tfc_workspace: the function has nothing to compare. Set tfc_workspace (the workflow does) or targets."
  }
}
