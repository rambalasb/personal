terraform {
  required_version = ">= 1.9, < 2.0"

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 4.37.0, < 5.0.0"
    }
    azapi = {
      source  = "Azure/azapi"
      version = ">= 1.15, < 3.0"
    }
    # tf-wrapper-avm-role-assignment declares it for its Entra ID input,
    # unused here.
    azuread = {
      source  = "hashicorp/azuread"
      version = ">= 2.46, < 4.0"
    }
    modtm = {
      source  = "Azure/modtm"
      version = "~> 0.3"
    }
    random = {
      source  = "hashicorp/random"
      version = ">= 3.5"
    }
  }
}

# auth from ARM_* env vars
provider "azurerm" {
  storage_use_azuread = true
  features {}
}

provider "azapi" {}
