"""Find where Azure and Terraform state disagree, beyond what HCP drift detection sees.

Two passes:

  target    one per HCP workspace. Port of scripts/detect_unmanaged.sh from the
            tf-deploy-* repos: top-level resources in the workspace's resource
            groups with no state entry, and state entries Azure no longer has.
  coverage  one per subscription, against the union of every workspace's state
            for it. Resource groups nobody owns, child objects, Key Vault
            secrets/keys and access policies, role assignments, locks, policy,
            diagnostic settings -- the list the HANDOVER docs record as having
            no coverage.

Every object that isn't in state is snapshotted each run, so the next run can
report changes to it. HCP drift detection only sees objects in state; this is
the only thing watching the rest.

Usage without the Functions host:
  python drift.py files azure.json state.json [--scope-type T]... [--waivers F]
  python drift.py coverage --subscription SUB --state state.json [--snapshot F]
  python drift.py live [--target NAME]...
"""

from __future__ import annotations

import argparse
import fnmatch
import json
import logging
import os
import shlex
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable
from urllib.parse import urlparse

import requests

log = logging.getLogger("drift")

ARM = "https://management.azure.com"
TIMEOUT = 60
WORKERS = 8


# ============================================================================
# ARM and Resource Graph
# ============================================================================

class ArmError(RuntimeError):
    def __init__(self, status: int, path: str, body: str):
        super().__init__(f"{status} on {path}: {body[:300]}")
        self.status = status


class ArmClient:
    """Plain REST rather than one SDK per resource provider."""

    def __init__(self, credential):
        self._cred = credential
        self._token = None
        self._lock = threading.Lock()
        self._api_cache: dict[str, dict[str, str]] = {}
        self.session = requests.Session()

    def _auth(self) -> str:
        with self._lock:
            if not self._token or self._token.expires_on - time.time() < 300:
                self._token = self._cred.get_token(f"{ARM}/.default")
            return self._token.token

    def _request(self, method: str, url: str, params: dict | None = None, body: dict | None = None):
        for attempt in range(6):
            r = self.session.request(
                method, url, params=params, json=body, timeout=TIMEOUT,
                headers={"Authorization": f"Bearer {self._auth()}"},
            )
            if r.status_code in (429, 500, 502, 503, 504) and attempt < 5:
                wait = int(r.headers.get("Retry-After", 2 ** attempt))
                log.info("ARM %s on %s, retrying in %ss", r.status_code, url, wait)
                time.sleep(min(wait, 60))
                continue
            return r
        return r

    def get(self, path: str, api_version: str) -> dict | None:
        """None on 404; anything else that isn't 2xx raises."""
        r = self._request("GET", f"{ARM}{path}", {"api-version": api_version})
        if r.status_code == 404:
            return None
        if not r.ok:
            raise ArmError(r.status_code, path, r.text)
        return r.json()

    def list(self, path: str, api_version: str) -> list[dict]:
        url, params, out = f"{ARM}{path}", {"api-version": api_version}, []
        while url:
            r = self._request("GET", url, params)
            if not r.ok:
                raise ArmError(r.status_code, path, r.text)
            body = r.json()
            out.extend(body.get("value", []))
            # nextLink already carries api-version and the skip token
            url, params = body.get("nextLink"), None
        return out

    def query(self, subscriptions: list[str], kql: str) -> list[dict]:
        """Resource Graph, all subscriptions in one call, paged by skip token."""
        path = "/providers/Microsoft.ResourceGraph/resources"
        out, token = [], None
        while True:
            options = {"resultFormat": "objectArray", "$top": 1000}
            if token:
                options["$skipToken"] = token
            r = self._request(
                "POST", f"{ARM}{path}", {"api-version": "2022-10-01"},
                {"subscriptions": subscriptions, "query": kql, "options": options},
            )
            if not r.ok:
                raise ArmError(r.status_code, path, r.text)
            body = r.json()
            out.extend(body.get("data", []))
            token = body.get("$skipToken")
            if not token:
                return out

    def api_version_for(self, subscription_id: str, rid: str) -> str:
        """Newest stable api-version for the type an ID points at."""
        parts = _parts(rid)
        # last providers segment wins, so extension resources resolve to their own type
        idx = max(i for i, p in enumerate(parts) if p.lower() == "providers")
        ns = parts[idx + 1].lower()
        type_path = "/".join(parts[idx + 2::2]).lower()

        with self._lock:
            cached = self._api_cache.get(ns)
        if cached is None:
            body = self.get(f"/subscriptions/{subscription_id}/providers/{ns}", "2021-04-01") or {}
            cached = {}
            for rt in body.get("resourceTypes", []):
                versions = rt.get("apiVersions", [])
                stable = [v for v in versions if "preview" not in v]
                if versions:
                    cached[rt["resourceType"].lower()] = (stable or versions)[0]
            with self._lock:
                self._api_cache[ns] = cached
        if type_path not in cached:
            raise LookupError(f"no api-version known for {ns}/{type_path}")
        return cached[type_path]


INVENTORY_KQL = """
resources
| project id, name, type, kind, location, resourceGroup, subscriptionId, managedBy, sku, identity, tags, properties
| order by id asc
"""

RG_KQL = """
resourcecontainers
| where type =~ 'microsoft.resources/subscriptions/resourcegroups'
| project id, name, type, location, subscriptionId, managedBy, tags, properties
| order by id asc
"""


@dataclass
class Inventory:
    resources: list[dict]  # top-level only, the same set `az resource list` returns
    children: list[dict]   # nested types Resource Graph also tracks (VM extensions, SQL DBs, ...)
    rgs: list[dict]


def load_inventory(arm: ArmClient, subscriptions: list[str]) -> dict[str, Inventory]:
    subs = sorted({s.lower() for s in subscriptions})
    out = {s: Inventory([], [], []) for s in subs}
    if not subs:
        return out
    for row in arm.query(subs, INVENTORY_KQL):
        inv = out.get(row["subscriptionId"].lower())
        if inv is not None:
            (inv.resources if classify(row["id"]) == "resource" else inv.children).append(row)
    for row in arm.query(subs, RG_KQL):
        inv = out.get(row["subscriptionId"].lower())
        if inv is not None:
            inv.rgs.append(row)
    return out


# ============================================================================
# IDs
# ============================================================================

def _parts(rid: str) -> list[str]:
    return [p for p in rid.split("/") if p]


def classify(rid: str) -> str:
    parts = _parts(rid)
    if len(parts) == 4 and parts[2].lower() == "resourcegroups":
        return "resource_group"
    if len(parts) == 8 and parts[4].lower() == "providers":
        return "resource"
    if len(parts) > 8 and parts[4].lower() == "providers":
        return "child"
    return "other"


def type_of(rid: str) -> str:
    parts = _parts(rid)
    if len(parts) == 8 and parts[4].lower() == "providers":
        return f"{parts[5]}/{parts[6]}".lower()
    return ""


def parent_type(rid: str) -> str:
    """Type of the top-level resource an ID is or hangs off."""
    parts = _parts(rid.lower())
    return f"{parts[5]}/{parts[6]}" if len(parts) >= 8 and parts[4] == "providers" else ""


def rg_of(rid: str) -> str:
    parts = _parts(rid)
    if len(parts) >= 4 and parts[2].lower() == "resourcegroups":
        return parts[3].lower()
    return ""


def parent_of(rid: str) -> str:
    return "/".join([""] + _parts(rid)[:8]).lower()


EXTENSION_KINDS = {
    "microsoft.authorization/roleassignments": "role_assignment",
    "microsoft.authorization/locks": "lock",
    "microsoft.authorization/policyassignments": "policy_assignment",
    "microsoft.authorization/policyexemptions": "policy_exemption",
    "microsoft.insights/diagnosticsettings": "diagnostic_setting",
}


def kind_of(rid: str) -> str:
    rid = rid.lower()
    if "/objectid/" in rid:
        return "access_policy"
    parts = _parts(rid)
    provs = [i for i, p in enumerate(parts) if p == "providers"]
    if provs and len(parts) >= provs[-1] + 4:
        t = f"{parts[provs[-1] + 1]}/{parts[provs[-1] + 2]}"
        if t in EXTENSION_KINDS:
            return EXTENSION_KINDS[t]
    return classify(rid)


def norm_state_id(rid: str, storage: dict[str, str], vaults: dict[str, str]) -> str | None:
    """State IDs as ARM spells them, lowercased. None = nothing we can compare."""
    rid = rid.strip().rstrip("/")
    if rid.startswith("https://"):
        u = urlparse(rid)
        host = u.netloc.lower().split(".")
        path = [p for p in u.path.split("/") if p]
        # azurerm_key_vault_secret/key: https://<vault>.vault.azure.net/secrets/<name>/<version>
        if len(host) > 1 and host[1] == "vault" and len(path) >= 2 and path[0] in ("secrets", "keys"):
            vault = vaults.get(host[0])
            return f"{vault}/{path[0]}/{path[1]}".lower() if vault else None
        # azurerm_storage_container/share with storage_account_name: https://<acct>.blob.core.windows.net/<name>
        coll = {"blob": "containers", "file": "shares", "queue": "queues", "table": "tables"}.get(host[1] if len(host) > 1 else "")
        acct = storage.get(host[0])
        if coll and acct and path:
            return f"{acct}/{host[1]}services/default/{coll}/{path[0]}".lower()
        return None
    if not rid.startswith("/subscriptions/"):
        return None
    if "|" in rid:
        left, right = rid.split("|", 1)
        # "<nic>|<nsg>" style association IDs aren't objects in their own right
        if right.startswith("/"):
            return None
        return f"{left}/providers/microsoft.insights/diagnosticsettings/{right}".lower()
    return rid.lower()


def managed_ids(state: dict, include_all: bool = False) -> dict[str, dict]:
    """IDs of managed resources in state, keyed lowercase.

    Accepts `terraform show -json` output and the raw v4 state file HCP serves.
    Data sources are skipped: they point at things state does not own.
    include_all keeps non-ARM IDs too (Key Vault and storage data-plane URLs).
    """
    managed: dict[str, dict] = {}

    def add(rid, address):
        if isinstance(rid, str) and (rid.startswith("/subscriptions/") or (include_all and rid)):
            clean = rid.split("?", 1)[0]  # azapi IDs can carry ?api-version=
            managed[clean.lower()] = {"id": clean, "address": address}

    def walk(node):
        if isinstance(node, dict):
            for res in node.get("resources", []) or []:
                if res.get("mode", "managed") != "managed":
                    continue
                if "instances" in res:
                    base = ".".join(p for p in (res.get("module"), res.get("type"), res.get("name")) if p)
                    for inst in res.get("instances") or []:
                        attrs = inst.get("attributes") or {}
                        key = inst.get("index_key")
                        addr = base if key is None else f"{base}[{json.dumps(key)}]"
                        add(attrs.get("id") or attrs.get("resource_id"), addr)
                else:
                    vals = res.get("values") or {}
                    add(vals.get("id") or vals.get("resource_id"), res.get("address", "?"))
            for child in node.get("child_modules", []) or []:
                walk(child)
            for key in ("values", "root_module"):
                if key in node:
                    walk(node[key])
        elif isinstance(node, list):
            for item in node:
                walk(item)

    walk(state)
    return managed


# ============================================================================
# Target pass: port of detect_unmanaged.sh
# ============================================================================

@dataclass
class Result:
    target: str
    scope_rgs: list[str]
    scope_derived: bool
    scope_types: list[str]
    exclude_types: list[str]
    azure_in_scope: int
    state_top_level: int
    state_rgs: int
    unmanaged: list[dict] = field(default_factory=list)
    ghosts: list[dict] = field(default_factory=list)
    waived: list[dict] = field(default_factory=list)
    child_in_state: list[dict] = field(default_factory=list)

    def covers(self, rid: str, declared_type: str = "") -> bool:
        """Whether this target's diff already looked at a top-level resource."""
        if rg_of(rid) not in self.scope_rgs:
            return False
        t = (declared_type or type_of(rid)).lower()
        if self.scope_types and t not in self.scope_types:
            return False
        return t not in self.exclude_types

    @property
    def status(self) -> str:
        # An empty scope has proved nothing; don't let it read as a pass.
        if not self.scope_rgs:
            return "INCONCLUSIVE"
        return "FAIL" if self.unmanaged or self.ghosts else "PASS"

    def to_dict(self) -> dict:
        return {
            "target": self.target,
            "status": self.status,
            "scope": {
                "resource_groups": self.scope_rgs,
                "derived_from_state": self.scope_derived,
                "types": self.scope_types,
                "exclude_types": self.exclude_types,
            },
            "counts": {
                "azure_in_scope": self.azure_in_scope,
                "state_top_level": self.state_top_level,
                "state_child_not_compared": len(self.child_in_state),
                "state_resource_groups": self.state_rgs,
                "waived": len(self.waived),
                "unmanaged": len(self.unmanaged),
                "ghosts": len(self.ghosts),
            },
            "unmanaged": self.unmanaged,
            "ghosts": self.ghosts,
            "waived": self.waived,
            "child_in_state": self.child_in_state,
        }


def detect(
    target: str,
    azure: list[dict],
    state: dict,
    scope_rgs: list[str] | None = None,
    scope_types: list[str] | None = None,
    exclude_types: list[str] | None = None,
    waivers: list[str] | None = None,
) -> Result:
    scope_rg_set = {r.lower() for r in scope_rgs or []}
    scope_type_set = {t.lower() for t in scope_types or []}
    exclude_type_set = {t.lower() for t in exclude_types or []}
    patterns = [w.strip().lower() for w in waivers or [] if w.strip() and not w.strip().startswith("#")]

    def in_type_scope(rid, declared=""):
        t = (declared or type_of(rid)).lower()
        if scope_type_set and t not in scope_type_set:
            return False
        return t not in exclude_type_set

    def waived(rid_lower):
        return any(fnmatch.fnmatch(rid_lower, p) for p in patterns)

    azure_ids = {}
    for r in azure:
        rid = (r or {}).get("id")
        if rid:
            azure_ids[rid.lower()] = {"id": rid, "type": r.get("type", "")}

    managed = managed_ids(state)
    managed_res = {k: v for k, v in managed.items() if classify(k) == "resource"}
    managed_child = {k: v for k, v in managed.items() if classify(k) == "child"}
    managed_rg = {k: v for k, v in managed.items() if classify(k) == "resource_group"}

    derived = not scope_rg_set
    if derived:
        scope_rg_set = {rg_of(k) for k in managed if rg_of(k)}

    in_scope_azure = {
        k: v for k, v in azure_ids.items()
        if classify(k) == "resource" and rg_of(k) in scope_rg_set and in_type_scope(k, v["type"])
    }

    unmanaged, waived_hits = {}, {}
    for k, v in in_scope_azure.items():
        if k in managed_res:
            continue
        (waived_hits if waived(k) else unmanaged)[k] = v

    ghosts = {
        k: v for k, v in managed_res.items()
        if rg_of(k) in scope_rg_set and k not in azure_ids and in_type_scope(k)
    }

    by_id = lambda x: x["id"].lower()  # noqa: E731
    return Result(
        target=target,
        scope_rgs=sorted(scope_rg_set),
        scope_derived=derived,
        scope_types=sorted(scope_type_set),
        exclude_types=sorted(exclude_type_set),
        azure_in_scope=len(in_scope_azure),
        state_top_level=len(managed_res),
        state_rgs=len(managed_rg),
        unmanaged=sorted(unmanaged.values(), key=by_id),
        ghosts=sorted(ghosts.values(), key=by_id),
        waived=sorted(waived_hits.values(), key=by_id),
        child_in_state=sorted(managed_child.values(), key=by_id),
    )


def render_text(res: Result) -> str:
    """Same layout as the script's stdout, so the two can be compared side by side."""
    out = [
        f"scope: {len(res.scope_rgs)} resource group(s)"
        + (" (derived from state)" if res.scope_derived else " (given)")
    ]
    out += [f"  - {rg}" for rg in res.scope_rgs]
    if res.scope_types:
        out.append(f"types: only {len(res.scope_types)}")
        out += [f"  - {t}" for t in res.scope_types]
    if res.exclude_types:
        out.append(f"types excluded: {len(res.exclude_types)}")
        out += [f"  - {t}" for t in res.exclude_types]
    out += [
        "",
        f"azure, in scope, top-level : {res.azure_in_scope}",
        f"state, top-level           : {res.state_top_level}",
        f"state, child (not compared): {len(res.child_in_state)}",
        f"state, resource groups     : {res.state_rgs}",
        f"waived                     : {len(res.waived)}",
        f"UNMANAGED                  : {len(res.unmanaged)}",
        f"GHOSTS                     : {len(res.ghosts)}",
    ]

    if res.status == "INCONCLUSIVE":
        out.append("\nINCONCLUSIVE: scope is empty -- state manages nothing, so there is")
        out.append("nothing to compare against. Set scope_resource_groups on the target to")
        out.append("inventory a resource group anyway.")
        return "\n".join(out) + "\n"

    if res.unmanaged:
        out.append("\nUNMANAGED -- in Azure, inside scope, not in state:")
        out += [f"  [{v['type']}] {v['id']}" for v in res.unmanaged]
    if res.ghosts:
        out.append("\nGHOSTS -- in state, absent from Azure:")
        for v in res.ghosts:
            out += [f"  {v['address']}", f"    {v['id']}"]
    if res.waived:
        out.append(f"\nwaived ({len(res.waived)}), expected to be unmanaged:")
        out += [f"  [{v['type']}] {v['id']}" for v in res.waived]

    out.append(
        "\nFAIL: Azure and state disagree about what exists." if res.status == "FAIL"
        else "\nPASS: every top-level resource in scope is accounted for."
    )
    return "\n".join(out) + "\n"


# ============================================================================
# Waivers
# ============================================================================

# Platform-created objects. Applied unless a subscription sets
# use_default_waivers: false. Matches still show in the report as waived.
DEFAULT_WAIVERS = """
check=resource_groups name=NetworkWatcherRG
check=resource_groups name=DefaultResourceGroup-*
check=resource_groups name=cloud-shell-storage-*
check=resource_groups name=AzureBackupRG_*
check=resource_groups name=MC_*
check=resource_groups name=databricks-rg-*
check=resource_groups name=LogAnalyticsDefaultResources
check=child_resources id=*/blobservices/default/containers/$logs
check=child_resources id=*/blobservices/default/containers/insights-*
check=child_resources id=*/blobservices/default/containers/azure-webjobs-*
check=child_resources id=*/blobservices/default/containers/bootdiagnostics-*
check=child_resources id=*/providers/microsoft.sql/servers/*/databases/master
check=child_resources id=*/backuppolicies/defaultpolicy
check=child_resources id=*/backuppolicies/hourlylogbackup
check=child_resources id=*/backuppolicies/enhancedpolicy
check=policy name=SecurityCenterBuiltIn
""".strip().splitlines()


def parse_waivers(lines: list[str]) -> list[dict[str, str]]:
    """One rule per line. A bare value is an ID glob; key=value pairs match
    finding fields, all must hold. Quote values with spaces:
        check=role_assignments principal_type=User
        check=role_assignments role="Key Vault Secrets User" scope=*/vaults/kvidn*
    A rule silences changes to an object only if it says kind=changed.
    """
    rules = []
    for line in lines:
        line = line.split(" #", 1)[0].strip()
        if not line or line.startswith("#"):
            continue
        tokens = shlex.split(line)
        if all("=" in t for t in tokens):
            rules.append({k.lower(): v.lower() for k, v in (t.split("=", 1) for t in tokens)})
        else:
            rules.append({"id": line.lower()})
    return rules


def waived_by(finding: dict, rules: list[dict[str, str]]) -> bool:
    return any(
        all(fnmatch.fnmatch(str(finding.get(k, "")).lower(), v) for k, v in rule.items())
        for rule in rules
    )


# ============================================================================
# Change tracking for objects that aren't in state
# ============================================================================

# Keys that move on their own. Dropped before comparing so a routine
# provisioning refresh isn't reported as a change. `updated` on a Key Vault
# secret is kept on purpose: it's how a new secret version shows up.
VOLATILE_KEYS = {
    "provisioningstate", "etag", "systemdata", "instanceview", "powerstate",
    "createdon", "updatedon", "createdby", "updatedby", "createdat", "changedtime",
    "creationtime", "timecreated", "lastmodified", "lastmodifiedtime", "lastmodifiedat",
    "lastupdatedtime", "statusofprimary", "statusofsecondary", "lastgeofailovertime",
    "metadata",
}


def clean_props(value):
    if isinstance(value, dict):
        return {
            k: clean_props(v) for k, v in sorted(value.items())
            if k.lower() not in VOLATILE_KEYS and v is not None
        }
    if isinstance(value, list):
        return [clean_props(v) for v in value]
    return value


def diff_props(before, after, path: str = "") -> list[dict]:
    if isinstance(before, dict) and isinstance(after, dict):
        out = []
        for k in sorted(set(before) | set(after)):
            out += diff_props(before.get(k), after.get(k), f"{path}.{k}" if path else k)
        return out
    if isinstance(before, list) and isinstance(after, list) and len(before) == len(after) \
            and all(isinstance(x, dict) for x in before + after):
        out = []
        for i, (b, a) in enumerate(zip(before, after)):
            out += diff_props(b, a, f"{path}[{i}]")
        return out
    if before != after:
        return [{"path": path or "(value)", "before": _short(before), "after": _short(after)}]
    return []


def _short(v, limit: int = 200):
    s = v if isinstance(v, str) else json.dumps(v, sort_keys=True)
    return s if len(s) <= limit else s[:limit] + "..."


def resource_props(row: dict) -> dict:
    return {k: row.get(k) for k in ("location", "kind", "sku", "identity", "tags", "properties", "managedBy")}


# ============================================================================
# Coverage pass
# ============================================================================

ALL_CHECKS = [
    "resource_groups",
    "resources",
    "child_resources",
    "access_policies",
    "role_assignments",
    "locks",
    "policy",
    "diagnostic_settings",
]

# Child collections listed under each managed parent. Neither the ARM list nor
# Resource Graph returns these, so without enumerating them a subnet or secret
# made by hand is invisible. Anything not here is still ghost-checked by GET.
CHILD_COLLECTIONS = {
    "microsoft.network/virtualnetworks": [("subnets", "2023-09-01"), ("virtualNetworkPeerings", "2023-09-01")],
    "microsoft.network/networksecuritygroups": [("securityRules", "2023-09-01")],
    "microsoft.network/routetables": [("routes", "2023-09-01")],
    "microsoft.network/firewallpolicies": [("ruleCollectionGroups", "2023-09-01")],
    "microsoft.network/virtualhubs": [("hubVirtualNetworkConnections", "2023-09-01"), ("hubRouteTables", "2023-09-01")],
    "microsoft.network/privatednszones": [("virtualNetworkLinks", "2020-06-01")],
    "microsoft.storage/storageaccounts": [
        ("blobServices/default/containers", "2023-01-01"),
        ("fileServices/default/shares", "2023-01-01"),
    ],
    # Management-plane listing: names and attributes (enabled, expiry,
    # updated), never values, and not blocked by the vault firewall. A new
    # secret version changes `updated`, which the snapshot picks up.
    "microsoft.keyvault/vaults": [("secrets", "2023-07-01"), ("keys", "2023-07-01")],
    "microsoft.managedidentity/userassignedidentities": [("federatedIdentityCredentials", "2023-01-31")],
    "microsoft.sql/servers": [("databases", "2021-11-01"), ("firewallRules", "2021-11-01")],
    "microsoft.eventhub/namespaces": [("eventhubs", "2021-11-01")],
    "microsoft.recoveryservices/vaults": [("backupPolicies", "2023-04-01")],
}

# Storage diagnostic settings sit on the service, not the account.
STORAGE_SERVICES = ["blobServices/default", "fileServices/default", "queueServices/default", "tableServices/default"]
DIAG_API = "2021-05-01-preview"

DETAIL_FIELDS = {
    "resource_groups": ["resources", "managed_by"],
    "role_assignments": ["role", "principal_type", "principal_id"],
    "locks": ["level"],
    "policy": ["display_name"],
    "diagnostic_settings": ["workspace", "logs"],
    "access_policies": ["principal_id"],
}


@dataclass
class CheckResult:
    name: str
    live: set[str] = field(default_factory=set)
    findings: list[dict] = field(default_factory=list)
    info: list[dict] = field(default_factory=list)
    unverified: list[dict] = field(default_factory=list)
    error: str | None = None


def _public(f: dict) -> dict:
    return {k: v for k, v in f.items() if not k.startswith("_")}


@dataclass
class CoverageResult:
    name: str
    subscription_id: str
    checks: list[CheckResult]
    unmanaged: list[dict]
    ghosts: list[dict]
    waived: list[dict]
    expected_missing: list[dict]
    changed: list[dict]
    removed_since_last_run: list[dict]
    snapshot: dict
    first_run: bool

    @property
    def status(self) -> str:
        # A failed check reads as ERROR even with findings: an empty list from
        # a 403 and an empty list from a clean subscription look the same.
        if any(c.error for c in self.checks):
            return "ERROR"
        if self.unmanaged or self.ghosts or self.expected_missing or self.changed:
            return "FAIL"
        return "PASS"

    def to_dict(self) -> dict:
        per_check = lambda rows, name: sum(1 for f in rows if f["check"] == name)  # noqa: E731
        return {
            "name": self.name,
            "subscription_id": self.subscription_id,
            "status": self.status,
            "first_run": self.first_run,
            "checks": [
                {
                    "name": c.name,
                    "status": "ERROR" if c.error else "OK",
                    "error": c.error,
                    "live": len(c.live),
                    "unmanaged": per_check(self.unmanaged, c.name),
                    "ghosts": per_check(self.ghosts, c.name),
                    "changed": per_check(self.changed, c.name),
                    "waived": per_check(self.waived, c.name),
                    "info": len(c.info),
                    "unverified": len(c.unverified),
                }
                for c in self.checks
            ],
            "counts": {
                "unmanaged": len(self.unmanaged),
                "ghosts": len(self.ghosts),
                "changed": len(self.changed),
                "expected_missing": len(self.expected_missing),
                "waived": len(self.waived),
                "not_in_state_tracked": len(self.snapshot.get("objects", {})),
            },
            "unmanaged": [_public(f) for f in self.unmanaged],
            "ghosts": self.ghosts,
            "changed": self.changed,
            "expected_missing": self.expected_missing,
            "removed_since_last_run": self.removed_since_last_run,
            "waived": [_public(f) for f in self.waived],
            "info": {c.name: c.info for c in self.checks if c.info},
            "unverified": {c.name: c.unverified for c in self.checks if c.unverified},
        }


class Coverage:
    def __init__(
        self,
        arm: ArmClient,
        subscription_id: str,
        states: list[dict],
        inventory: Inventory,
        scope_resource_groups: list[str] | None = None,
        covered_by_target: Callable[[str, str], bool] | None = None,
    ):
        self.arm = arm
        self.sub = subscription_id.lower()
        self.sub_path = f"/subscriptions/{self.sub}"
        self.scope_rgs = {r.lower() for r in scope_resource_groups or []}
        self.covered_by_target = covered_by_target or (lambda rid, rtype: False)
        self.inv = inventory

        by_type = lambda t: {  # noqa: E731
            r["name"].lower(): r["id"].lower() for r in inventory.resources if r["type"].lower() == t
        }
        storage, vaults = by_type("microsoft.storage/storageaccounts"), by_type("microsoft.keyvault/vaults")

        self.managed: dict[str, dict] = {}
        for state in states:
            for v in managed_ids(state, include_all=True).values():
                n = norm_state_id(v["id"], storage, vaults)
                if n and n.startswith(self.sub_path + "/"):
                    self.managed[n] = {"id": v["id"], "address": v["address"], "kind": kind_of(n)}

        self.unowned_rgs: set[str] = set()
        # every live object with no state entry, waived or not: id -> {check, props}
        self.not_in_state: dict[str, dict] = {}

    def in_scope(self, rid: str) -> bool:
        rg = rg_of(rid)
        # subscription-level objects are always in scope
        return not self.scope_rgs or not rg or rg in self.scope_rgs

    def managed_of(self, kind: str) -> dict[str, dict]:
        return {k: v for k, v in self.managed.items() if v["kind"] == kind and self.in_scope(k)}

    def _track(self, check: str, rid: str, props) -> None:
        self.not_in_state[rid.lower()] = {"check": check, "props": clean_props(props or {})}

    def _diff(self, res: CheckResult, kind: str, live: dict[str, dict], ghost_filter=lambda k: True):
        res.live |= set(live)
        managed = self.managed_of(kind)
        for k, f in live.items():
            if k not in managed:
                res.findings.append({"check": res.name, "kind": "unmanaged", **f})
                self._track(res.name, k, f.get("_props"))
        for k, v in managed.items():
            if k not in live and ghost_filter(k):
                res.findings.append({"check": res.name, "kind": "ghost", "id": v["id"], "address": v["address"], "type": kind})

    def _pmap(self, fn, items):
        with ThreadPoolExecutor(WORKERS) as ex:
            return list(ex.map(fn, items))

    def resource_groups(self, res: CheckResult):
        live = {}
        for g in self.inv.rgs:
            k = g["id"].lower()
            if not self.in_scope(k):
                continue
            live[k] = {
                "id": g["id"], "type": "microsoft.resources/resourcegroups", "rg": rg_of(k), "name": g["name"],
                "resources": sum(1 for r in self.inv.resources if rg_of(r["id"]) == rg_of(k)),
                "managed_by": g.get("managedBy") or "",
                "_props": {"location": g.get("location"), "tags": g.get("tags"), "managedBy": g.get("managedBy")},
            }
        self._diff(res, "resource_group", live)
        self.unowned_rgs = {rg_of(f["id"]) for f in res.findings if f["kind"] == "unmanaged"}

    def resources(self, res: CheckResult):
        """Top-level resources no target's scope covers: the ones the target pass never looks at.

        Everything not in state is snapshotted here, reported or not, so a
        change to it shows up next run.
        """
        for r in self.inv.resources:
            k = r["id"].lower()
            if not self.in_scope(k):
                continue
            res.live.add(k)
            if k in self.managed:
                continue
            self._track(res.name, k, resource_props(r))
            # in an unowned group it's summed into that group's finding; in a
            # target's scope the target report already lists it
            if rg_of(k) in self.unowned_rgs or self.covered_by_target(k, r["type"]):
                continue
            res.findings.append({"check": res.name, "kind": "unmanaged", "id": r["id"], "type": r["type"].lower(), "rg": rg_of(k), "name": r["name"]})

        all_live = {r["id"].lower() for r in self.inv.resources}
        for k, v in self.managed_of("resource").items():
            if k not in all_live and not self.covered_by_target(k, ""):
                res.findings.append({"check": res.name, "kind": "ghost", "id": v["id"], "address": v["address"], "type": "resource"})

    def child_resources(self, res: CheckResult):
        live_ids = {r["id"].lower() for r in self.inv.resources}
        managed_parents = {k for k in self.managed_of("resource") if k in live_ids}
        parents = [(k, CHILD_COLLECTIONS[parent_type(k)]) for k in managed_parents if parent_type(k) in CHILD_COLLECTIONS]
        enumerated: set[str] = set()  # "<parent>/<collection>" prefixes we have the full list for
        live: dict[str, dict] = {}

        def list_children(item):
            parent, colls = item
            out = []
            for path, api in colls:
                prefix = f"{parent}/{path}".lower()
                try:
                    out.append((prefix, self.arm.list(prefix, api), None))
                except ArmError as exc:
                    # 400/404: the parent's SKU or kind has no such collection
                    if exc.status not in (400, 404, 405):
                        out.append((prefix, [], str(exc)))
            return out

        def add(row):
            k = row["id"].lower()
            live[k] = {
                "id": row["id"], "type": (row.get("type") or "").lower(), "rg": rg_of(k), "parent": parent_of(k),
                "_props": row.get("properties") if "subscriptionId" not in row else resource_props(row),
            }

        for batch in self._pmap(list_children, parents):
            for prefix, rows, err in batch:
                if err:
                    # e.g. a 403 listing secrets: say so rather than report the vault clean
                    res.unverified.append({"id": prefix, "address": "(collection)", "reason": err})
                    continue
                enumerated.add(prefix)
                for row in rows:
                    add(row)
        # Resource Graph tracks some nested types itself: VM extensions, SQL DBs, slots
        for row in self.inv.children:
            if parent_of(row["id"]) in managed_parents and self.in_scope(row["id"]):
                add(row)

        self._diff(res, "child", live, ghost_filter=lambda k: any(k.startswith(p + "/") for p in enumerated))

        # Ghosts outside the enumerated collections: look each one up.
        to_get = [
            k for k in self.managed_of("child")
            if k not in live and not any(k.startswith(p + "/") for p in enumerated)
        ]
        # other/sub-level objects in state (Defender pricings and the like) too
        to_get += [k for k in self.managed_of("other") if "/providers/" in k]
        for k, outcome in zip(to_get, self._pmap(self._exists, to_get)):
            v = self.managed[k]
            if outcome is False:
                res.findings.append({"check": res.name, "kind": "ghost", "id": v["id"], "address": v["address"], "type": v["kind"]})
            elif outcome is not True:
                res.unverified.append({"id": v["id"], "address": v["address"], "reason": outcome})

    def _exists(self, rid: str):
        try:
            return self.arm.get(rid, self.arm.api_version_for(self.sub, rid)) is not None
        except (ArmError, LookupError) as exc:
            return str(exc)

    def access_policies(self, res: CheckResult):
        vaults = [k for k in self.managed_of("resource") if parent_type(k) == "microsoft.keyvault/vaults"]
        live: dict[str, dict] = {}
        for k, body in self._pmap(lambda v: (v, self.arm.get(v, "2023-07-01")), vaults):
            if not body:
                continue
            props = body.get("properties", {})
            # Listed on RBAC vaults too: Azure ignores them there, but they're
            # still objects, and flipping the vault back would make them live.
            for p in props.get("accessPolicies", []):
                pid = f"{k}/objectid/{p['objectId']}".lower()
                if p.get("applicationId"):
                    pid += f"/applicationid/{p['applicationId']}".lower()
                live[pid] = {
                    "id": pid, "type": "microsoft.keyvault/vaults/accesspolicies", "rg": rg_of(k),
                    "vault": k.rsplit("/", 1)[-1], "principal_id": p["objectId"],
                    "rbac_vault": bool(props.get("enableRbacAuthorization")),
                    "_props": p.get("permissions"),
                }
        vault_set = set(vaults)
        self._diff(res, "access_policy", live, ghost_filter=lambda k: parent_of(k) in vault_set)

    def role_assignments(self, res: CheckResult):
        roles = {
            d["name"].lower(): d["properties"]["roleName"]
            for d in self.arm.list(f"{self.sub_path}/providers/Microsoft.Authorization/roleDefinitions", "2022-04-01")
        }
        live = {}
        for a in self.arm.list(f"{self.sub_path}/providers/Microsoft.Authorization/roleAssignments", "2022-04-01"):
            p = a["properties"]
            scope = p["scope"].lower()
            row = {
                "id": a["id"], "type": "microsoft.authorization/roleassignments", "rg": rg_of(scope),
                "scope": p["scope"],
                "role": roles.get(p["roleDefinitionId"].rsplit("/", 1)[-1].lower(), p["roleDefinitionId"]),
                "principal_id": p["principalId"], "principal_type": p.get("principalType", ""),
                "description": p.get("description") or "",
                "_props": p,
            }
            # Management group and root assignments are inherited, owned above this subscription.
            if not scope.startswith(self.sub_path):
                res.info.append({**_public(row), "note": "inherited"})
            elif self.in_scope(scope):
                live[a["id"].lower()] = row
        self._diff(res, "role_assignment", live)

    def locks(self, res: CheckResult):
        live = {}
        for lk in self.arm.list(f"{self.sub_path}/providers/Microsoft.Authorization/locks", "2020-05-01"):
            k = lk["id"].lower()
            if self.in_scope(k):
                live[k] = {
                    "id": lk["id"], "type": "microsoft.authorization/locks", "rg": rg_of(k),
                    "level": lk["properties"].get("level", ""), "name": lk["name"], "_props": lk["properties"],
                }
        self._diff(res, "lock", live)

    def policy(self, res: CheckResult):
        live_a, live_e = {}, {}
        for a in self.arm.list(f"{self.sub_path}/providers/Microsoft.Authorization/policyAssignments", "2023-04-01"):
            p = a.get("properties", {})
            scope = (p.get("scope") or "").lower()
            row = {
                "id": a["id"], "type": "microsoft.authorization/policyassignments", "rg": rg_of(scope),
                "name": a["name"], "display_name": p.get("displayName") or "", "scope": p.get("scope") or "",
                "policy_definition_id": p.get("policyDefinitionId") or "", "_props": p,
            }
            if not scope.startswith(self.sub_path):
                res.info.append({**_public(row), "note": "inherited"})
            elif self.in_scope(scope):
                live_a[a["id"].lower()] = row
        for e in self.arm.list(f"{self.sub_path}/providers/Microsoft.Authorization/policyExemptions", "2022-07-01-preview"):
            k = e["id"].lower()
            p = e.get("properties", {})
            row = {
                "id": e["id"], "type": "microsoft.authorization/policyexemptions", "rg": rg_of(k),
                "name": e["name"], "display_name": p.get("displayName") or "",
                "category": p.get("exemptionCategory") or "", "expires_on": p.get("expiresOn") or "",
                "policy_assignment_id": p.get("policyAssignmentId") or "", "_props": p,
            }
            if not k.startswith(self.sub_path):
                res.info.append({**_public(row), "note": "inherited"})
            elif self.in_scope(k):
                live_e[k] = row
        self._diff(res, "policy_assignment", live_a)
        self._diff(res, "policy_exemption", live_e)

    def diagnostic_settings(self, res: CheckResult):
        targets = [self.sub_path]
        for r in self.inv.resources:
            k = r["id"].lower()
            if not self.in_scope(k):
                continue
            targets.append(k)
            if r["type"].lower() == "microsoft.storage/storageaccounts":
                targets += [f"{k}/{s}".lower() for s in STORAGE_SERVICES]
        # state may point a setting at something the list above doesn't include
        targets += sorted({
            k.split("/providers/microsoft.insights/diagnosticsettings/")[0] for k in self.managed_of("diagnostic_setting")
        } - set(targets))

        def list_diag(target):
            try:
                return target, self.arm.list(f"{target}/providers/Microsoft.Insights/diagnosticSettings", DIAG_API)
            except ArmError as exc:
                # most types that don't support diagnostics answer 400/404
                if exc.status in (400, 404, 405):
                    return target, []
                raise

        live = {}
        for target, rows in self._pmap(list_diag, targets):
            for d in rows:
                k = d["id"].lower()
                p = d.get("properties", {})
                live[k] = {
                    "id": d["id"], "type": "microsoft.insights/diagnosticsettings", "rg": rg_of(k),
                    "target": target, "name": d["name"], "workspace": p.get("workspaceId") or "",
                    "logs": ",".join(sorted(
                        (lg.get("category") or lg.get("categoryGroup") or "") for lg in p.get("logs", []) if lg.get("enabled")
                    )),
                    "_props": p,
                }
        self._diff(res, "diagnostic_setting", live)


def changed_by(arm: ArmClient, subscription_id: str, ids: list[str], since: str) -> dict[str, dict]:
    """Who last changed each ID since `since`, from Resource Graph change history.

    Covers what resourcechanges tracks (14 days, most top-level types); the rest
    just come back without a name.
    """
    out: dict[str, dict] = {}
    for i in range(0, len(ids), 100):
        chunk = ", ".join(f"'{x}'" for x in ids[i:i + 100])
        kql = f"""
resourcechanges
| extend target = tolower(tostring(properties.targetResourceId)),
         at = todatetime(properties.changeAttributes.timestamp),
         by = tostring(properties.changeAttributes.changedBy),
         client = tostring(properties.changeAttributes.clientType)
| where at > todatetime('{since}') and target in ({chunk})
| summarize arg_max(at, by, client) by target
"""
        for row in arm.query([subscription_id], kql):
            out[row["target"]] = {"changed_by": row.get("by") or "", "changed_at": row.get("at") or "", "client": row.get("client") or ""}
    return out


def run_coverage(
    arm: ArmClient,
    name: str,
    subscription_id: str,
    states: list[dict],
    inventory: Inventory,
    checks: list[str] | None = None,
    scope_resource_groups: list[str] | None = None,
    waivers: list[str] | None = None,
    expected: list[str] | None = None,
    use_default_waivers: bool = True,
    covered_by_target: Callable[[str, str], bool] | None = None,
    previous_snapshot: dict | None = None,
) -> CoverageResult:
    cov = Coverage(arm, subscription_id, states, inventory, scope_resource_groups, covered_by_target)
    rules = parse_waivers(list(waivers or []) + (DEFAULT_WAIVERS if use_default_waivers else []))

    results = []
    # resource_groups first: resources and the rest use its unowned set
    for check in [c for c in ALL_CHECKS if c in (checks or ALL_CHECKS)]:
        res = CheckResult(check)
        try:
            getattr(cov, check)(res)
        except Exception as exc:  # noqa: BLE001
            res.error = f"{type(exc).__name__}: {exc}"
        results.append(res)

    unmanaged, ghosts, waived = [], [], []
    for c in results:
        for f in c.findings:
            if f["kind"] == "ghost":
                ghosts.append(f)
            elif waived_by(f, rules):
                waived.append({**f, "kind": "waived"})
            else:
                unmanaged.append(f)

    # Deliberately unmanaged objects that something depends on, e.g. the key
    # vault diagnostic settings the identity alerts query (identity HANDOVER §6).
    live_all = set().union(*(c.live for c in results)) | set(cov.managed)
    expected_missing = [
        {"check": "expected", "kind": "expected_missing", "id": pat}
        for pat in (e.strip() for e in expected or [])
        if pat and not pat.startswith("#") and not any(fnmatch.fnmatch(k, pat.lower()) for k in live_all)
    ]

    # Compare against the last run. Objects whose check errored this run are
    # carried over untouched, so a 403 doesn't read as "everything removed".
    now = datetime.now(timezone.utc).isoformat(timespec="seconds")
    errored = {c.name for c in results if c.error}
    prev = (previous_snapshot or {}).get("objects", {})
    current = dict(cov.not_in_state)
    for k, v in prev.items():
        if v["check"] in errored and k not in current:
            current[k] = v

    changed, removed = [], []
    if previous_snapshot:
        change_rules = [r for r in rules if "kind" in r]
        for k, now_v in current.items():
            before = prev.get(k)
            if before and before["check"] not in errored:
                diffs = diff_props(before["props"], now_v["props"])
                f = {"check": now_v["check"], "kind": "changed", "id": k, "changes": diffs[:20], "more": max(0, len(diffs) - 20)}
                if diffs and not waived_by(f, change_rules):
                    changed.append(f)
        removed = [
            {"check": v["check"], "id": k} for k, v in prev.items()
            if k not in current and v["check"] not in errored
        ]
        new_ids = set(current) - set(prev)
        for f in unmanaged + waived:
            f["new_since_last_run"] = f["id"].lower() in new_ids
        if changed:
            try:
                who = changed_by(arm, subscription_id, [f["id"] for f in changed], previous_snapshot.get("taken_at", now))
                for f in changed:
                    f.update(who.get(f["id"], {}))
            except Exception as exc:  # noqa: BLE001
                # attribution is a nicety; the change itself is already known
                log.warning("change history lookup failed: %s", exc)

    by_id = lambda f: (f["check"], f["id"].lower())  # noqa: E731
    return CoverageResult(
        name=name,
        subscription_id=subscription_id,
        checks=results,
        unmanaged=sorted(unmanaged, key=by_id),
        ghosts=sorted(ghosts, key=by_id),
        waived=sorted(waived, key=by_id),
        expected_missing=expected_missing,
        changed=sorted(changed, key=by_id),
        removed_since_last_run=sorted(removed, key=by_id),
        snapshot={"taken_at": now, "objects": current},
        first_run=previous_snapshot is None,
    )


def render_coverage(res: CoverageResult) -> str:
    out = [f"subscription: {res.name} ({res.subscription_id})", ""]
    out.append(f"{'check':<22}{'status':<8}{'live':>6}{'unmgd':>7}{'ghost':>7}{'chgd':>6}{'waived':>8}{'info':>6}")
    for c in res.to_dict()["checks"]:
        out.append(
            f"{c['name']:<22}{c['status']:<8}{c['live']:>6}{c['unmanaged']:>7}{c['ghosts']:>7}"
            f"{c['changed']:>6}{c['waived']:>8}{c['info']:>6}"
        )
    for c in res.checks:
        if c.error:
            out.append(f"\nERROR in {c.name}: {c.error}")

    def detail(f):
        extra = [f"{k}={f[k]}" for k in DETAIL_FIELDS.get(f["check"], []) if f.get(k) not in (None, "")]
        new = " (new)" if f.get("new_since_last_run") else ""
        return f"  [{f['check']}]{new} {f['id']}" + (f"\n      {' '.join(extra)}" if extra else "")

    if res.unmanaged:
        out.append("\nUNMANAGED -- in Azure, not in any workspace's state:")
        out += [detail(f) for f in res.unmanaged]
    if res.ghosts:
        out.append("\nGHOSTS -- in state, absent from Azure:")
        for f in res.ghosts:
            out += [f"  [{f['check']}] {f.get('address', '?')}", f"    {f['id']}"]
    if res.changed:
        out.append("\nCHANGED SINCE LAST RUN -- not in state, so HCP drift detection can't see these:")
        for f in res.changed:
            who = f" by {f['changed_by']}" if f.get("changed_by") else ""
            out.append(f"  [{f['check']}] {f['id']}{who}")
            for d in f["changes"]:
                out.append(f"      {d['path']}: {d['before']} -> {d['after']}")
            if f.get("more"):
                out.append(f"      ... {f['more']} more")
    if res.expected_missing:
        out.append("\nEXPECTED BUT MISSING -- unmanaged on purpose, but something depends on it:")
        out += [f"  {f['id']}" for f in res.expected_missing]
    if res.removed_since_last_run:
        out.append(f"\nno longer outside state ({len(res.removed_since_last_run)}): deleted, or adopted into Terraform:")
        out += [f"  [{f['check']}] {f['id']}" for f in res.removed_since_last_run]
    unverified = [(c.name, u) for c in res.checks for u in c.unverified]
    if unverified:
        out.append(f"\nnot verified ({len(unverified)}), could not be looked up:")
        out += [f"  [{n}] {u['address']} {u['id']}: {u['reason']}" for n, u in unverified]
    if res.waived:
        out.append(f"\nwaived ({len(res.waived)}):")
        out += [detail(f) for f in res.waived]
    if res.first_run:
        out.append("\nfirst run: no previous snapshot, so changes are reported from the next run on.")

    out.append("")
    out.append({
        "PASS": "PASS: every object checked is accounted for, and nothing outside state changed.",
        "FAIL": "FAIL: Azure and state disagree, or something outside state changed.",
        "ERROR": "ERROR: at least one check did not complete; absence of findings proves nothing.",
    }[res.status])
    return "\n".join(out) + "\n"


# ============================================================================
# HCP Terraform state
# ============================================================================

class StateError(RuntimeError):
    pass


def fetch_hcp_state(org: str, workspace: str, token: str, address: str = "https://app.terraform.io") -> dict:
    """Current state of an HCP Terraform workspace.

    Prefers the JSON rendering (same shape as `terraform show -json`); falls
    back to the raw state file. The token needs read-state-versions on the
    workspace, not write.
    """
    base = address.rstrip("/")
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/vnd.api+json"}

    r = requests.get(f"{base}/api/v2/organizations/{org}/workspaces/{workspace}", headers=headers, timeout=TIMEOUT)
    if r.status_code == 404:
        raise StateError(f"workspace {org}/{workspace} not found, or the token cannot see it")
    r.raise_for_status()
    ws_id = r.json()["data"]["id"]

    r = requests.get(f"{base}/api/v2/workspaces/{ws_id}/current-state-version", headers=headers, timeout=TIMEOUT)
    if r.status_code == 404:
        # No state yet is a real state, not an error -- the target reports INCONCLUSIVE.
        log.warning("workspace %s has no state version", workspace)
        return {}
    r.raise_for_status()
    attrs = r.json()["data"]["attributes"]

    url = attrs.get("hosted-json-state-download-url") or attrs.get("hosted-state-download-url")
    if not url:
        raise StateError(f"workspace {workspace}: state version has no download URL (still processing?)")

    # Archivist URLs are pre-signed; only send the token back to the HCP host itself.
    dl_headers = headers if urlparse(url).netloc == urlparse(base).netloc else {}
    r = requests.get(url, headers=dl_headers, timeout=TIMEOUT)
    r.raise_for_status()
    log.info("workspace %s: state serial %s", workspace, attrs.get("serial"))
    return r.json()


# ============================================================================
# Configuration
# ============================================================================

@dataclass
class Target:
    """One HCP workspace, mirroring one unmanaged-detect.yml matrix entry."""

    name: str
    workspace: str
    subscription_id: str
    scope_resource_groups: list[str] = field(default_factory=list)
    scope_types: list[str] = field(default_factory=list)
    exclude_types: list[str] = field(default_factory=list)
    waivers: list[str] = field(default_factory=list)


@dataclass
class Subscription:
    """Coverage settings. Every subscription a target uses gets a coverage pass,
    with defaults if it isn't listed."""

    subscription_id: str
    name: str = ""
    checks: list[str] = field(default_factory=list)  # empty = all
    scope_resource_groups: list[str] = field(default_factory=list)
    waivers: list[str] = field(default_factory=list)
    expected: list[str] = field(default_factory=list)
    use_default_waivers: bool = True
    enabled: bool = True


@dataclass
class Config:
    targets: list[Target]
    subscriptions: list[Subscription]


def load_config() -> Config:
    """TARGETS_JSON app setting, else TARGETS_FILE / targets.json next to this file.

    Either a bare list of targets or {"targets": [...], "subscriptions": [...]}.
    """
    raw = os.environ.get("TARGETS_JSON", "").strip()
    if not raw:
        raw = Path(os.environ.get("TARGETS_FILE", Path(__file__).with_name("targets.json"))).read_text(encoding="utf-8")
    data = json.loads(raw)
    if isinstance(data, list):
        data = {"targets": data}

    targets = [Target(**t) for t in data.get("targets", [])]
    subs = {s["subscription_id"].lower(): Subscription(**s) for s in data.get("subscriptions", [])}
    for t in targets:
        subs.setdefault(t.subscription_id.lower(), Subscription(subscription_id=t.subscription_id))
    for s in subs.values():
        s.name = s.name or s.subscription_id

    names = [t.name for t in targets] + [f"{s.name}.coverage" for s in subs.values()]
    if len(names) != len(set(names)):
        raise ValueError("target and subscription names must be unique; they name the report folders")
    if any(" " in n for n in names):
        raise ValueError("names can't contain spaces; the alert query splits on them")
    return Config(targets=targets, subscriptions=list(subs.values()))


def env(name: str, default: str | None = None) -> str:
    val = os.environ.get(name, default)
    if val is None or val == "":
        raise RuntimeError(f"app setting {name} is not set")
    return val


# ============================================================================
# Run everything, publish reports
# ============================================================================

def hcp_token(credential) -> str:
    """TFC_TOKEN for local runs; in Azure the token stays in Key Vault."""
    if os.environ.get("TFC_TOKEN"):
        return os.environ["TFC_TOKEN"]
    from azure.keyvault.secrets import SecretClient

    client = SecretClient(env("KEY_VAULT_URL"), credential)
    return client.get_secret(os.environ.get("TFC_TOKEN_SECRET_NAME", "tfc-token")).value


def run_target(target: Target, state: dict, azure: list[dict]) -> Result:
    return detect(
        target.name, azure, state,
        scope_rgs=target.scope_resource_groups,
        scope_types=target.scope_types,
        exclude_types=target.exclude_types,
        waivers=target.waivers,
    )


def _lines(rows) -> str:
    return "".join(f"{r}\n" for r in rows)


def report_files(res: Result) -> dict[str, str]:
    """Same file set the unmanaged-detect workflow uploads, plus report.json."""
    types = [f"only  {t}" for t in res.scope_types] + [f"minus {t}" for t in res.exclude_types]
    return {
        "report.txt": render_text(res),
        "report.json": json.dumps(res.to_dict(), indent=2),
        "unmanaged.txt": _lines(f"{v['type']}\t{v['id']}" for v in res.unmanaged),
        "ghosts.txt": _lines(f"{v['address']}\t{v['id']}" for v in res.ghosts),
        "waived.txt": _lines(f"{v['type']}\t{v['id']}" for v in res.waived),
        "child-in-state.txt": _lines(f"{v['address']}\t{v['id']}" for v in res.child_in_state),
        "scope.txt": _lines(res.scope_rgs),
        "scope-types.txt": _lines(sorted(types) or ["(all types)"]),
    }


def coverage_files(res: CoverageResult) -> dict[str, str]:
    return {
        "report.txt": render_coverage(res),
        "report.json": json.dumps(res.to_dict(), indent=2),
        "unmanaged.txt": _lines(f"{f['check']}\t{f['id']}" for f in res.unmanaged),
        "ghosts.txt": _lines(f"{f['check']}\t{f.get('address', '?')}\t{f['id']}" for f in res.ghosts),
        "changed.txt": _lines(
            f"{f['check']}\t{f['id']}\t{d['path']}\t{d['before']}\t{d['after']}" for f in res.changed for d in f["changes"]
        ),
        "waived.txt": _lines(f"{f['check']}\t{f['id']}" for f in res.waived),
        "expected-missing.txt": _lines(f["id"] for f in res.expected_missing),
    }


class ReportStore:
    """<container>/<name>/latest/, <name>/<UTC stamp>/, and <name>/snapshot.json.

    latest/ is what people read; the stamped copies are history; the snapshot
    is what the next run diffs against.
    """

    def __init__(self, credential):
        self.cc = None
        url = os.environ.get("REPORT_STORAGE_ACCOUNT_URL")
        if not url:
            log.warning("REPORT_STORAGE_ACCOUNT_URL not set: reports go to the log only, and changes can't be tracked between runs")
            return
        from azure.storage.blob import BlobServiceClient

        self.location = f"{url.rstrip('/')}/{os.environ.get('REPORT_CONTAINER', 'drift-reports')}"
        self.cc = BlobServiceClient(url, credential=credential).get_container_client(
            os.environ.get("REPORT_CONTAINER", "drift-reports")
        )

    def read_json(self, path: str) -> dict | None:
        if not self.cc:
            return None
        from azure.core.exceptions import ResourceNotFoundError

        try:
            return json.loads(self.cc.download_blob(path).readall())
        except ResourceNotFoundError:
            return None

    def write(self, path: str, body: str) -> None:
        if not self.cc:
            return
        from azure.storage.blob import ContentSettings

        ctype = "application/json" if path.endswith(".json") else "text/plain; charset=utf-8"
        self.cc.upload_blob(path, body.encode("utf-8"), overwrite=True, content_settings=ContentSettings(content_type=ctype))

    def publish(self, name: str, files: dict[str, str], stamp: str) -> None:
        for fname, body in files.items():
            for prefix in (f"{name}/{stamp}", f"{name}/latest"):
                self.write(f"{prefix}/{fname}", body)


def _log(name: str, status: str, detail: str) -> None:
    # infra alerts on this exact shape: "drift <name>: <STATUS> ..."
    (log.warning if status in ("FAIL", "ERROR") else log.info)("drift %s: %s %s", name, status, detail)


def run_all(credential, only: list[str] | None = None, config: Config | None = None, store: ReportStore | None = None) -> dict:
    config = config or load_config()
    store = store or ReportStore(credential)
    arm = ArmClient(credential)
    token = hcp_token(credential)
    org = env("TFC_ORGANIZATION")
    address = os.environ.get("TFC_ADDRESS", "https://app.terraform.io")
    stamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H%MZ")

    targets = config.targets
    subs = [s for s in config.subscriptions if s.enabled]
    if only:
        targets = [t for t in targets if t.name in only]
        subs = [s for s in subs if f"{s.name}.coverage" in only or s.name in only]

    # Coverage needs every workspace's state for its subscription, not just
    # the ones selected with ?target=.
    sub_ids = {s.subscription_id.lower() for s in subs}
    needed = {t.workspace for t in config.targets if t.subscription_id.lower() in sub_ids} | {t.workspace for t in targets}

    states: dict[str, dict] = {}
    state_errors: dict[str, str] = {}
    for ws in sorted(needed):
        try:
            states[ws] = fetch_hcp_state(org, ws, token, address)
        except Exception as exc:  # noqa: BLE001
            log.exception("state for %s", ws)
            state_errors[ws] = f"{type(exc).__name__}: {exc}"

    inventory = load_inventory(arm, sorted(sub_ids | {t.subscription_id.lower() for t in targets}))

    summary, target_results = [], {}
    for t in targets:
        # One target failing (bad token scope, no Reader on a sub) must not
        # hide the result of the others.
        try:
            if t.workspace in state_errors:
                raise RuntimeError(f"state unavailable: {state_errors[t.workspace]}")
            res = run_target(t, states[t.workspace], inventory[t.subscription_id.lower()].resources)
        except Exception as exc:  # noqa: BLE001
            _log(t.name, "ERROR", str(exc))
            summary.append({"name": t.name, "kind": "target", "status": "ERROR", "error": str(exc)})
            continue
        target_results[t.name] = res
        summary.append({"name": t.name, "kind": "target", "status": res.status, "counts": res.to_dict()["counts"]})
        store.publish(t.name, report_files(res), stamp)
        _log(t.name, res.status, f"unmanaged={len(res.unmanaged)} ghosts={len(res.ghosts)}")

    for s in subs:
        name = f"{s.name}.coverage"
        sub_targets = [t for t in config.targets if t.subscription_id.lower() == s.subscription_id.lower()]
        missing = [t.workspace for t in sub_targets if t.workspace not in states]
        if missing:
            # Without every workspace's state, everything the missing one owns
            # would read as unmanaged. Refuse rather than mislead.
            err = f"state unavailable for {', '.join(missing)}"
            _log(name, "ERROR", err)
            summary.append({"name": name, "kind": "coverage", "status": "ERROR", "error": err})
            continue

        inv = inventory[s.subscription_id.lower()]
        # Targets not selected with ?target= still vouch for their scope; their
        # diff is cheap here since state and inventory are already loaded.
        covering = [target_results.get(t.name) or run_target(t, states[t.workspace], inv.resources) for t in sub_targets]
        try:
            res = run_coverage(
                arm, s.name, s.subscription_id,
                [states[t.workspace] for t in sub_targets],
                inv,
                checks=s.checks or None,
                scope_resource_groups=s.scope_resource_groups,
                waivers=s.waivers,
                expected=s.expected,
                use_default_waivers=s.use_default_waivers,
                covered_by_target=lambda rid, rtype, rs=covering: any(r.covers(rid, rtype) for r in rs),
                previous_snapshot=store.read_json(f"{name}/snapshot.json"),
            )
        except Exception as exc:  # noqa: BLE001
            log.exception("coverage %s", s.name)
            _log(name, "ERROR", str(exc))
            summary.append({"name": name, "kind": "coverage", "status": "ERROR", "error": str(exc)})
            continue

        d = res.to_dict()
        summary.append({"name": name, "kind": "coverage", "status": res.status, "counts": d["counts"], "checks": d["checks"]})
        store.publish(name, coverage_files(res), stamp)
        store.write(f"{name}/snapshot.json", json.dumps(res.snapshot))
        _log(name, res.status, " ".join(f"{k}={v}" for k, v in d["counts"].items()))

    store.write(f"_summary/{stamp}.json", json.dumps(summary, indent=2))
    return {
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "reports": getattr(store, "location", None),
        "results": summary,
    }


# ============================================================================
# Command line
# ============================================================================

def write_baseline(path: str, res: CoverageResult) -> None:
    """Starting point for a subscription's waivers. Every line still needs a
    reason and an owner; a baseline accepted unread is how yesterday's portal
    Owner grant becomes a permanent exception."""
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"# baseline for {res.subscription_id}, {len(res.unmanaged)} unmanaged objects\n")
        f.write("# Delete a line to keep reporting that object. Add a reason after ' # '.\n")
        for finding in res.unmanaged:
            extra = [f"{k}={finding[k]}" for k in DETAIL_FIELDS.get(finding["check"], []) if finding.get(k)]
            f.write(f"\n# {' '.join([finding['check'], finding.get('type', '')] + extra).strip()}\n{finding['id']}\n")
    print(f"baseline: {len(res.unmanaged)} entries -> {path}", file=sys.stderr)


def _read_json(path: str):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def _read_lines(path: str | None) -> list[str]:
    if not path:
        return []
    with open(path, encoding="utf-8") as f:
        return f.read().splitlines()


def main(argv=None) -> int:
    p = argparse.ArgumentParser(prog="drift", description=__doc__.split("\n\n")[0])
    sub = p.add_subparsers(dest="cmd", required=True)

    f = sub.add_parser("files", help="target pass on local azure.json + state.json, same inputs as detect_unmanaged.sh")
    f.add_argument("azure")
    f.add_argument("state")
    f.add_argument("--scope-rg", action="append", default=[])
    f.add_argument("--scope-type", action="append", default=[])
    f.add_argument("--exclude-type", action="append", default=[])
    f.add_argument("--waivers")
    f.add_argument("--json", action="store_true")

    c = sub.add_parser("coverage", help="coverage pass for one subscription, after `az login`")
    c.add_argument("--subscription", required=True)
    c.add_argument("--name", default="local")
    c.add_argument("--state", action="append", required=True, help="terraform show -json output; once per workspace in the subscription")
    c.add_argument("--check", action="append", default=[])
    c.add_argument("--scope-rg", action="append", default=[])
    c.add_argument("--waivers", help="file, one rule per line")
    c.add_argument("--expected", help="file, one ID glob per line")
    c.add_argument("--snapshot", help="file to diff against and then overwrite; enables change tracking")
    c.add_argument("--no-default-waivers", action="store_true")
    c.add_argument("--write-baseline", metavar="FILE")
    c.add_argument("--json", action="store_true")

    lv = sub.add_parser("live", help="same path as the function, using app settings from the environment")
    lv.add_argument("--target", action="append", default=[])

    a = p.parse_args(argv)

    if a.cmd == "files":
        azure = _read_json(a.azure)
        if not isinstance(azure, list):
            print("error: Azure inventory must be a JSON array (az resource list -o json)", file=sys.stderr)
            return 2
        res = detect(
            "local", azure, _read_json(a.state),
            scope_rgs=a.scope_rg, scope_types=a.scope_type, exclude_types=a.exclude_type,
            waivers=_read_lines(a.waivers),
        )
        print(json.dumps(res.to_dict(), indent=2) if a.json else render_text(res), end="")
        # same exit codes as the script: 1 on disagreement
        return 1 if res.status == "FAIL" else 0

    from azure.identity import DefaultAzureCredential

    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
    cred = DefaultAzureCredential()

    if a.cmd == "coverage":
        arm = ArmClient(cred)
        prev = _read_json(a.snapshot) if a.snapshot and os.path.exists(a.snapshot) else None
        res = run_coverage(
            arm, a.name, a.subscription,
            [_read_json(s) for s in a.state],
            load_inventory(arm, [a.subscription])[a.subscription.lower()],
            checks=a.check or None,
            scope_resource_groups=a.scope_rg,
            waivers=_read_lines(a.waivers),
            expected=_read_lines(a.expected),
            use_default_waivers=not a.no_default_waivers,
            previous_snapshot=prev,
        )
        print(json.dumps(res.to_dict(), indent=2) if a.json else render_coverage(res), end="")
        if a.snapshot:
            with open(a.snapshot, "w", encoding="utf-8") as fh:
                json.dump(res.snapshot, fh)
        if a.write_baseline:
            write_baseline(a.write_baseline, res)
        return {"PASS": 0, "FAIL": 1}.get(res.status, 2)

    result = run_all(cred, only=a.target or None)
    print(json.dumps(result, indent=2))
    return 1 if any(r["status"] in ("FAIL", "ERROR") for r in result["results"]) else 0


if __name__ == "__main__":
    sys.exit(main())
