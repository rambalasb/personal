import copy
import json
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import drift  # noqa: E402
from drift import (  # noqa: E402
    ArmError, Config, Subscription, Target, detect, kind_of, load_inventory, managed_ids,
    norm_state_id, parse_waivers, render_coverage, render_text, run_coverage, waived_by,
)

ROOT = Path(__file__).resolve().parents[1]
FIX = Path(__file__).parent / "fixtures"
SCRIPT = ROOT.parent / "avm-terraform-wrappers/tf-deploy-platform-firewall-management/scripts/detect_unmanaged.sh"
FW_TYPES = ["Microsoft.Network/azureFirewalls", "Microsoft.Network/firewallPolicies", "Microsoft.Network/ipGroups"]


def load(name):
    return json.loads((FIX / name).read_text())


def names(rows, check=None):
    return sorted(r["id"].rsplit("/", 1)[-1] for r in rows if check is None or r["check"] == check)


# ---- target pass (detect_unmanaged.sh port) ----------------------------------

def fixture_waivers():
    return (FIX / "waivers.txt").read_text().splitlines()


@pytest.mark.parametrize("state_file", ["state.json", "state-raw.json"])
def test_both_state_formats_give_the_same_ids(state_file):
    got = managed_ids(load(state_file))
    assert set(got) == set(managed_ids(load("state.json")))
    assert not any("rg-data-only" in k for k in got)  # data sources aren't ownership


def test_raw_state_addresses():
    addrs = {v["address"] for v in managed_ids(load("state-raw.json")).values()}
    assert 'module.fw.azurerm_firewall_policy.p["gone"]' in addrs
    assert "module.fw.azapi_resource.ipg[0]" in addrs


def test_scope_derived_from_state():
    res = detect("t", load("azure.json"), load("state.json"), waivers=fixture_waivers())
    assert res.scope_derived and res.scope_rgs == ["rg-hub"]
    assert names(res.unmanaged) == ["afwp-clickops", "vnet-hub"]
    assert names(res.ghosts) == ["afwp-deleted", "ipg1"]
    assert names(res.waived) == ["pip-waived"]
    assert names(res.child_in_state) == ["rcg1"]
    assert res.status == "FAIL"


def test_type_scope_and_exclude_are_complements():
    assert names(detect("t", load("azure.json"), load("state.json"), scope_types=FW_TYPES).unmanaged) == ["afwp-clickops"]
    res = detect("t", load("azure.json"), load("state.json"), exclude_types=FW_TYPES, waivers=fixture_waivers())
    assert names(res.unmanaged) == ["vnet-hub"] and res.ghosts == []


def test_empty_state_is_inconclusive_not_pass():
    res = detect("t", load("azure.json"), {})
    assert res.status == "INCONCLUSIVE" and "INCONCLUSIVE" in render_text(res)


@pytest.mark.skipif(not SCRIPT.exists() or not shutil.which("bash"), reason="detect_unmanaged.sh not alongside")
@pytest.mark.parametrize("extra", [[], ["--scope-type", FW_TYPES[1]], ["--exclude-type", FW_TYPES[0]]])
def test_parity_with_detect_unmanaged_sh(tmp_path, extra):
    args = [str(FIX / "azure.json"), str(FIX / "state.json"), "--waivers", str(FIX / "waivers.txt")] + extra
    sh = subprocess.run(["bash", str(SCRIPT), *args, "--out", str(tmp_path)], capture_output=True, text=True)
    py = subprocess.run([sys.executable, str(ROOT / "drift.py"), "files", *args, "--json"], capture_output=True, text=True)
    assert py.returncode == sh.returncode
    res = json.loads(py.stdout)
    for fname, key, col in (("unmanaged.txt", "unmanaged", "type"), ("ghosts.txt", "ghosts", "address")):
        want = sorted((tmp_path / fname).read_text().splitlines())
        assert sorted(f"{r[col]}\t{r['id']}" for r in res[key]) == want, fname


# ---- coverage pass -------------------------------------------------------------

SUBID = "s1"
SUB = f"/subscriptions/{SUBID}"
RG = f"{SUB}/resourceGroups/rg-mid-identity"
KV = f"{RG}/providers/Microsoft.KeyVault/vaults/kvfwtls"
VNET = f"{RG}/providers/Microsoft.Network/virtualNetworks/vnet1"
UAMI = f"{RG}/providers/Microsoft.ManagedIdentity/userAssignedIdentities/mid-azfirewall"
ST = f"{RG}/providers/Microsoft.Storage/storageAccounts/stmid"
VM = f"{RG}/providers/Microsoft.Compute/virtualMachines/vm1"
PIP = f"{RG}/providers/Microsoft.Network/publicIPAddresses/pip-portal"
MG = "/providers/Microsoft.Management/managementGroups/mg-platform"


def res_row(rid, rtype, **props):
    return {"id": rid, "name": rid.rsplit("/", 1)[-1], "type": rtype, "subscriptionId": SUBID,
            "resourceGroup": "x", "location": "canadacentral", "tags": {}, "properties": props}


def ra(scope, guid, role_guid, ptype, pid="p1"):
    return {
        "id": f"{scope}/providers/Microsoft.Authorization/roleAssignments/{guid}", "name": guid,
        "properties": {"scope": scope, "principalId": pid, "principalType": ptype,
                       "roleDefinitionId": f"{SUB}/providers/Microsoft.Authorization/roleDefinitions/{role_guid}"},
    }


class FakeArm:
    def __init__(self):
        self.resources = [
            res_row(KV, "Microsoft.KeyVault/vaults"),
            res_row(VNET, "Microsoft.Network/virtualNetworks"),
            res_row(UAMI, "Microsoft.ManagedIdentity/userAssignedIdentities"),
            res_row(ST, "Microsoft.Storage/storageAccounts"),
            res_row(VM, "Microsoft.Compute/virtualMachines"),
            {**res_row(PIP, "Microsoft.Network/publicIPAddresses", publicIPAllocationMethod="Static"), "sku": {"name": "Standard"}},
            res_row(f"{SUB}/resourceGroups/rg-clickops/providers/Microsoft.Web/sites/app1", "Microsoft.Web/sites"),
            # nested type Resource Graph returns on its own
            res_row(f"{VM}/extensions/portal-ext", "Microsoft.Compute/virtualMachines/extensions"),
        ]
        self.rgs = [
            {"id": RG, "name": "rg-mid-identity", "subscriptionId": SUBID},
            {"id": f"{SUB}/resourceGroups/NetworkWatcherRG", "name": "NetworkWatcherRG", "subscriptionId": SUBID},
            {"id": f"{SUB}/resourceGroups/rg-clickops", "name": "rg-clickops", "subscriptionId": SUBID},
        ]
        self.lists = {
            f"{VNET}/subnets": [{"id": f"{VNET}/subnets/snet-a", "properties": {}}, {"id": f"{VNET}/subnets/snet-portal", "properties": {}}],
            f"{VNET}/virtualNetworkPeerings": [],
            f"{UAMI}/federatedIdentityCredentials": [{"id": f"{UAMI}/federatedIdentityCredentials/gh-main", "properties": {}}],
            f"{ST}/blobServices/default/containers": [
                {"id": f"{ST}/blobServices/default/containers/tfstate", "properties": {}},
                {"id": f"{ST}/blobServices/default/containers/$logs", "properties": {}},
            ],
            f"{ST}/fileServices/default/shares": [],
            f"{KV}/secrets": [
                {"id": f"{KV}/secrets/tf-managed", "properties": {"attributes": {"enabled": True, "updated": 1}}},
                {"id": f"{KV}/secrets/app-secret", "properties": {"attributes": {"enabled": True, "updated": 1}}},
            ],
            f"{KV}/keys": ArmError(403, "keys", "Forbidden"),
            f"{SUB}/providers/Microsoft.Authorization/roleDefinitions": [
                {"name": "owner-guid", "properties": {"roleName": "Owner"}},
                {"name": "kvsu-guid", "properties": {"roleName": "Key Vault Secrets User"}},
            ],
            f"{SUB}/providers/Microsoft.Authorization/roleAssignments": [
                ra(KV, "ra-managed", "kvsu-guid", "ServicePrincipal"),
                ra(KV, "ra-user", "kvsu-guid", "User", "alice"),
                ra(SUB, "ra-portal-owner", "owner-guid", "User", "mallory"),
                ra(MG, "ra-inherited", "owner-guid", "Group"),
            ],
            f"{SUB}/providers/Microsoft.Authorization/locks": [
                {"id": f"{RG}/providers/Microsoft.Authorization/locks/ro", "name": "ro", "properties": {"level": "ReadOnly"}},
            ],
            f"{SUB}/providers/Microsoft.Authorization/policyAssignments": [
                {"id": f"{SUB}/providers/Microsoft.Authorization/policyAssignments/SecurityCenterBuiltIn", "name": "SecurityCenterBuiltIn", "properties": {"scope": SUB}},
                {"id": f"{MG}/providers/Microsoft.Authorization/policyAssignments/deny-public", "name": "deny-public", "properties": {"scope": MG}},
            ],
            f"{SUB}/providers/Microsoft.Authorization/policyExemptions": [],
            f"{KV}/providers/Microsoft.Insights/diagnosticSettings": [
                {"id": f"{KV}/providers/Microsoft.Insights/diagnosticSettings/to-law", "name": "to-law",
                 "properties": {"workspaceId": "/law", "logs": [{"category": "AuditEvent", "enabled": True}]}},
            ],
        }
        self.gets = {KV: {"properties": {"accessPolicies": [
            {"objectId": "ap-managed", "permissions": {"secrets": ["Get"]}},
            {"objectId": "ap-portal", "permissions": {"secrets": ["Get", "List"]}},
        ]}}}
        self.queries = []

    def list(self, path, api):
        for k, v in self.lists.items():
            if k.lower() == path.lower():
                if isinstance(v, Exception):
                    raise v
                return copy.deepcopy(v)
        raise ArmError(404, path, "not found")

    def get(self, path, api):
        return next((copy.deepcopy(v) for k, v in self.gets.items() if k.lower() == path.lower()), None)

    def query(self, subs, kql):
        self.queries.append(kql)
        if "resourcecontainers" in kql:
            return copy.deepcopy(self.rgs)
        if "resourcechanges" in kql:
            return [{"target": PIP.lower(), "by": "mallory@example.com", "at": "2026-09-29T10:00:00Z", "client": "Azure Portal"}]
        return copy.deepcopy(self.resources)

    def api_version_for(self, sub, rid):
        return "2023-01-01"


STATE = {"values": {"root_module": {"resources": [
    {"address": a, "mode": "managed", "values": {"id": i}} for a, i in [
        ("rg", RG), ("kv", KV), ("vnet", VNET), ("uami", UAMI), ("st", ST), ("vm", VM),
        ("snet", f"{VNET}/subnets/snet-a"),
        ("snet_gone", f"{VNET}/subnets/snet-deleted"),
        ("container", "https://stmid.blob.core.windows.net/tfstate"),     # old-style data-plane ID
        ("secret", "https://kvfwtls.vault.azure.net/secrets/tf-managed/0123abcd"),
        ("ap", f"{KV}/objectId/ap-managed"),
        ("ra", f"{KV}/providers/Microsoft.Authorization/roleAssignments/ra-managed"),
        ("lock", f"{RG}/providers/Microsoft.Authorization/locks/ro"),
        ("lock_gone", f"{RG}/providers/Microsoft.Authorization/locks/cannotdelete"),
        ("pec", f"{KV}/privateEndpointConnections/pe1"),
    ]
]}}}

WAIVERS = ["check=role_assignments principal_type=User scope=*/vaults/*  # PIM, identity HANDOVER §5"]
EXPECTED = [
    f"{KV}/providers/microsoft.insights/diagnosticsettings/*",
    f"{VNET}/providers/microsoft.insights/diagnosticsettings/*",
]


def run(arm=None, **kw):
    arm = arm or FakeArm()
    kw.setdefault("waivers", WAIVERS)
    kw.setdefault("expected", EXPECTED)
    inv = load_inventory(arm, [SUBID])[SUBID]
    return run_coverage(arm, "identity", SUBID, [STATE], inv, **kw)


def test_inventory_splits_top_level_and_nested():
    inv = load_inventory(FakeArm(), [SUBID])[SUBID]
    assert len(inv.resources) == 7 and names(inv.children) == ["portal-ext"] and len(inv.rgs) == 3


def test_portal_owner_grant_is_found():
    res = run()
    assert names(res.unmanaged, "role_assignments") == ["ra-portal-owner"]
    assert names(res.waived, "role_assignments") == ["ra-user"]
    ra_check = next(c for c in res.checks if c.name == "role_assignments")
    assert [i["id"].rsplit("/", 1)[-1] for i in ra_check.info] == ["ra-inherited"]


def test_resource_groups_and_resources():
    res = run()
    assert names(res.unmanaged, "resource_groups") == ["rg-clickops"]
    assert names(res.waived, "resource_groups") == ["NetworkWatcherRG"]
    # app1 is in the unowned group, so it's summed there rather than listed
    assert names(res.unmanaged, "resources") == ["pip-portal"]
    assert next(f for f in res.unmanaged if f["check"] == "resource_groups")["resources"] == 1
    # ...but still snapshotted for change tracking
    assert any(k.endswith("/sites/app1") for k in res.snapshot["objects"])


def test_resources_covered_by_a_target_are_left_to_it():
    res = run(covered_by_target=lambda rid, t: rid.endswith("pip-portal"))
    assert names(res.unmanaged, "resources") == []
    assert PIP.lower() in res.snapshot["objects"]


def test_children_secrets_and_arg_nested_types():
    res = run()
    assert names(res.unmanaged, "child_resources") == ["app-secret", "gh-main", "portal-ext", "snet-portal"]
    assert names(res.waived, "child_resources") == ["$logs"]
    # enumerated collection -> set difference; pe1 isn't enumerated, so GET (404 here)
    assert names(res.ghosts, "child_resources") == ["pe1", "snet-deleted"]
    # a 403 listing keys is reported, not read as "no keys"
    child = next(c for c in res.checks if c.name == "child_resources")
    assert [u["id"] for u in child.unverified] == [f"{KV}/keys".lower()]
    assert child.error is None


def test_access_policies_locks_diag_expected():
    res = run()
    assert names(res.unmanaged, "access_policies") == ["ap-portal"]
    assert names(res.ghosts, "locks") == ["cannotdelete"]
    assert names(res.unmanaged, "diagnostic_settings") == ["to-law"]
    assert names(res.waived, "policy") == ["SecurityCenterBuiltIn"]
    assert [f["id"] for f in res.expected_missing] == [EXPECTED[1]]
    assert res.status == "FAIL" and res.first_run


def test_changes_to_objects_outside_state_are_reported_next_run():
    first = run()
    assert first.changed == [] and "first run" in render_coverage(first)

    arm = FakeArm()
    arm.resources[5]["sku"] = {"name": "Basic"}                            # pip-portal
    arm.lists[f"{KV}/secrets"][1]["properties"]["attributes"]["updated"] = 2  # new app-secret version
    arm.lists[f"{KV}/providers/Microsoft.Insights/diagnosticSettings"][0]["properties"]["logs"][0]["enabled"] = False
    arm.lists[f"{SUB}/providers/Microsoft.Authorization/roleAssignments"].append(ra(SUB, "ra-new", "owner-guid", "User", "eve"))
    arm.lists[f"{VNET}/subnets"].pop(1)                                    # snet-portal deleted

    second = run(arm, previous_snapshot=first.snapshot)
    changed = {f["id"].rsplit("/", 1)[-1]: f for f in second.changed}
    assert set(changed) == {"pip-portal", "app-secret", "to-law"}
    assert changed["pip-portal"]["changes"] == [{"path": "sku.name", "before": "Standard", "after": "Basic"}]
    assert changed["pip-portal"]["changed_by"] == "mallory@example.com"
    assert changed["app-secret"]["changes"][0]["path"] == "attributes.updated"
    new = [f["id"].rsplit("/", 1)[-1] for f in second.unmanaged if f.get("new_since_last_run")]
    assert new == ["ra-new"]
    assert names(second.removed_since_last_run) == ["snet-portal"]
    assert "CHANGED SINCE LAST RUN" in render_coverage(second)


def test_errored_check_carries_its_snapshot_forward():
    first = run()
    arm = FakeArm()
    arm.lists[f"{SUB}/providers/Microsoft.Authorization/roleAssignments"] = ArmError(403, "x", "AuthorizationFailed")
    second = run(arm, previous_snapshot=first.snapshot)
    assert second.status == "ERROR"
    assert not any(f["check"] == "role_assignments" for f in second.removed_since_last_run)
    assert any(v["check"] == "role_assignments" for v in second.snapshot["objects"].values())


def test_change_waivers_need_kind_changed():
    first = run()
    arm = FakeArm()
    arm.resources[5]["sku"] = {"name": "Basic"}
    # a plain waiver on the object does not hide changes to it...
    assert names(run(arm, previous_snapshot=first.snapshot, waivers=[PIP.lower()]).changed) == ["pip-portal"]
    # ...one that says kind=changed does
    silenced = run(arm, previous_snapshot=first.snapshot, waivers=[f"kind=changed id={PIP.lower()}"])
    assert silenced.changed == []


def test_clean_subscription_passes():
    state_ok = {"values": {"root_module": {"resources": [
        {"address": "lock", "values": {"id": f"{RG}/providers/Microsoft.Authorization/locks/ro"}},
    ]}}}
    arm = FakeArm()
    res = run_coverage(arm, "x", SUBID, [state_ok], load_inventory(arm, [SUBID])[SUBID], checks=["locks"])
    assert res.status == "PASS"


def test_scope_limits_everything_but_subscription_level():
    res = run(scope_resource_groups=["rg-clickops"], checks=["resource_groups", "role_assignments"], waivers=[])
    assert names(res.unmanaged, "resource_groups") == ["rg-clickops"]
    assert names(res.unmanaged, "role_assignments") == ["ra-portal-owner"]


@pytest.mark.parametrize("rid,kind", [
    (f"{KV}/objectId/x", "access_policy"),
    (f"{SUB}/providers/Microsoft.Authorization/roleAssignments/x", "role_assignment"),
    (f"{KV}/providers/Microsoft.Authorization/roleAssignments/x", "role_assignment"),
    (f"{RG}/providers/Microsoft.Authorization/locks/x", "lock"),
    (f"{KV}/providers/Microsoft.Insights/diagnosticSettings/x", "diagnostic_setting"),
    (f"{VNET}/subnets/a", "child"),
    (VNET, "resource"),
    (RG, "resource_group"),
])
def test_kind_of(rid, kind):
    assert kind_of(rid) == kind


def test_norm_state_id():
    st, kv = {"stmid": ST.lower()}, {"kvfwtls": KV.lower()}
    assert norm_state_id(f"{KV}|to-law", st, kv) == f"{KV}/providers/microsoft.insights/diagnosticsettings/to-law".lower()
    assert norm_state_id(f"{VNET}/subnets/a|{VNET}/x", st, kv) is None
    assert norm_state_id("https://stmid.file.core.windows.net/share1", st, kv) == f"{ST}/fileservices/default/shares/share1".lower()
    assert norm_state_id("https://kvfwtls.vault.azure.net/keys/k1/abc", st, kv) == f"{KV}/keys/k1".lower()
    assert norm_state_id("https://unknown.blob.core.windows.net/c", st, kv) is None


def test_waiver_rules():
    rules = parse_waivers(['# comment', 'check=role_assignments role="Key Vault Secrets User"', '/subscriptions/*/resourcegroups/rg-x/*   # glob'])
    assert waived_by({"check": "role_assignments", "role": "Key Vault Secrets User"}, rules)
    assert not waived_by({"check": "role_assignments", "role": "Owner"}, rules)
    assert waived_by({"id": "/subscriptions/s/resourceGroups/RG-X/providers/a/b/c"}, rules)


# ---- run_all end to end --------------------------------------------------------

class FakeStore:
    def __init__(self):
        self.blobs = {}

    def read_json(self, path):
        return json.loads(self.blobs[path]) if path in self.blobs else None

    def write(self, path, body):
        self.blobs[path] = body

    def publish(self, name, files, stamp):
        for f, body in files.items():
            self.blobs[f"{name}/latest/{f}"] = body


CFG = Config(
    targets=[
        Target(name="identity", workspace="az-platform-identity", subscription_id=SUBID),
        Target(name="other", workspace="az-other", subscription_id=SUBID),
    ],
    subscriptions=[Subscription(subscription_id=SUBID, name="identity-sub", waivers=WAIVERS)],
)


@pytest.fixture
def live(monkeypatch):
    def setup(fail_ws=()):
        monkeypatch.setenv("TFC_TOKEN", "x")
        monkeypatch.setenv("TFC_ORGANIZATION", "BC_Hydro")
        monkeypatch.setattr(drift, "ArmClient", lambda cred: FakeArm())

        def fake_state(org, ws, token, address):
            if ws in fail_ws:
                raise RuntimeError("401")
            return STATE if ws == "az-platform-identity" else {}

        monkeypatch.setattr(drift, "fetch_hcp_state", fake_state)
    return setup


def by_name(result):
    return {r["name"]: r for r in result["results"]}


def test_run_all_targets_coverage_and_snapshot(live):
    live()
    store = FakeStore()
    r = by_name(drift.run_all(None, config=CFG, store=store))
    assert r["identity"]["status"] == "FAIL"          # pip-portal, per-target view
    assert r["other"]["status"] == "INCONCLUSIVE"     # empty workspace
    cov = r["identity-sub.coverage"]
    checks = {c["name"]: c for c in cov["checks"]}
    assert checks["resources"]["unmanaged"] == 0     # pip-portal left to the target report
    assert checks["role_assignments"]["unmanaged"] == 1
    assert "identity-sub.coverage/snapshot.json" in store.blobs
    # second run reads the snapshot back
    r2 = by_name(drift.run_all(None, config=CFG, store=store))
    assert r2["identity-sub.coverage"]["counts"]["changed"] == 0


def test_coverage_refuses_without_every_state(live):
    live(fail_ws={"az-other"})
    r = by_name(drift.run_all(None, config=CFG, store=FakeStore()))
    assert r["other"]["status"] == "ERROR"
    assert r["identity-sub.coverage"]["status"] == "ERROR"
    assert "az-other" in r["identity-sub.coverage"]["error"]


def test_only_coverage(live):
    live()
    r = by_name(drift.run_all(None, only=["identity-sub.coverage"], config=CFG, store=FakeStore()))
    assert set(r) == {"identity-sub.coverage"}
    checks = {c["name"]: c for c in r["identity-sub.coverage"]["checks"]}
    assert checks["resources"]["unmanaged"] == 0     # unselected targets still vouch for their scope
