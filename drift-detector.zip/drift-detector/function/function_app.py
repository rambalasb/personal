import json
import logging

import azure.functions as func
from azure.identity import DefaultAzureCredential

from drift import run_all

app = func.FunctionApp()


def _credential():
    # AZURE_CLIENT_ID selects the user-assigned identity in Azure, or the
    # service principal locally when AZURE_CLIENT_SECRET is also set.
    return DefaultAzureCredential(exclude_interactive_browser_credential=True)


@app.timer_trigger(schedule="%DRIFT_SCHEDULE%", arg_name="timer", run_on_startup=False, use_monitor=True)
def drift_scheduled(timer: func.TimerRequest) -> None:
    if timer.past_due:
        logging.warning("timer is past due")
    result = run_all(_credential())
    logging.info("drift run complete: %s", json.dumps([(r["name"], r["status"]) for r in result["results"]]))


@app.route(route="drift", methods=["GET", "POST"], auth_level=func.AuthLevel.FUNCTION)
def drift_on_demand(req: func.HttpRequest) -> func.HttpResponse:
    """?target=a,b limits the run to those targets, or to <subscription>.coverage."""
    only = [t for t in (req.params.get("target") or "").split(",") if t.strip()]
    try:
        result = run_all(_credential(), only=only or None)
    except Exception as exc:  # noqa: BLE001
        logging.exception("drift run failed")
        return func.HttpResponse(json.dumps({"error": str(exc)}), status_code=500, mimetype="application/json")

    statuses = {r["status"] for r in result["results"]}
    # 200 even on FAIL: the run worked, the finding is in the body.
    code = 500 if statuses == {"ERROR"} else 200
    return func.HttpResponse(json.dumps(result, indent=2), status_code=code, mimetype="application/json")
