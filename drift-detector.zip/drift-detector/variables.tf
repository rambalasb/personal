variable "name" {
  type        = string
  description = "Base name; resources get their type prefix, e.g. func-<name>."
  default     = "tfdrift-poc"
}

variable "location" {
  type        = string
  description = "Azure region."
  default     = "canadacentral"
}

variable "tfc_organization" {
  type        = string
  description = "HCP Terraform organization the target workspaces live in. The workflow passes it from Key Vault."
  default     = "BC_Hydro"
}

variable "tfc_workspace" {
  type        = string
  description = "This deployment's own workspace. With no targets set, the detector checks it, so the POC has something real to compare against."
  default     = null
}

variable "tfc_token" {
  type        = string
  description = "HCP token with read-state-versions on every target workspace. Stored in the Key Vault this creates. Null = set the secret by hand."
  default     = null
  sensitive   = true
}

variable "targets" {
  type = list(object({
    name                  = string
    workspace             = string
    subscription_id       = string
    scope_resource_groups = optional(list(string), [])
    scope_types           = optional(list(string), [])
    exclude_types         = optional(list(string), [])
    waivers               = optional(list(string), [])
  }))
  description = "Workspaces to compare, one per HCP workspace. Empty = this deployment's own workspace (var.tfc_workspace). The function gets Reader on every subscription listed here or in var.subscriptions."
  default     = []
}

variable "subscriptions" {
  type = list(object({
    subscription_id       = string
    name                  = string
    checks                = optional(list(string), [])
    scope_resource_groups = optional(list(string), [])
    waivers               = optional(list(string), [])
    expected              = optional(list(string), [])
    use_default_waivers   = optional(bool, true)
    enabled               = optional(bool, true)
  }))
  description = "Coverage settings per subscription. Empty = this subscription, scoped to this deployment's resource group (subscription-level objects like role assignments are always included)."
  default     = []
}

variable "schedule" {
  type        = string
  description = "NCRONTAB, six fields, UTC."
  default     = "0 30 14 * * *"
}

variable "public_network_access" {
  type        = bool
  description = "Public endpoints on the function, storage and Key Vault. True for the test subscription, which has no VNet; production needs VNet integration and private endpoints instead."
  default     = true
}

variable "alert_email" {
  type        = string
  description = "Gets the FAIL/ERROR alert. Null = no alert."
  default     = null
}

variable "tags" {
  type        = map(string)
  description = "Tags on everything this creates."
  default     = {}
}
