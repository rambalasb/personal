check "private_endpoint_subnet_supplied" {
  assert {
    condition     = length(var.private_endpoints) == 0 || var.private_endpoint_subnet_id != null
    error_message = "var.private_endpoint_subnet_id must be set when private_endpoints is non-empty."
  }
}

check "diagnostics_destination_configured" {
  assert {
    condition     = var.log_analytics_workspace_id != null || length(var.diagnostic_settings) > 0
    error_message = "Either var.log_analytics_workspace_id or var.diagnostic_settings must be set so Key Vault audit/access logs are captured."
  }
}

check "rbac_assignments_supplied" {
  assert {
    condition     = length(var.role_assignments) > 0
    error_message = "Key Vault uses RBAC authorization (legacy access policies are disabled by the LSM). Provide at least one role_assignment, or grant access at a higher scope. The LSM cannot detect RG/subscription-scoped assignments."
  }
}
