module "key_vault" {
  source = "git::https://github.com/BCH-CloudAzure/avm-terraform-wrappers.git//tf-wrapper-avm-key-vault?ref=main"

  # Required
  name                = var.name
  resource_group_name = var.resource_group_name
  location            = var.location
  tenant_id           = var.tenant_id

  # LSM-enforced hardened defaults
  sku_name                        = var.sku_name
  purge_protection_enabled        = true
  soft_delete_retention_days      = var.soft_delete_retention_days
  legacy_access_policies_enabled  = false
  enabled_for_deployment          = false
  enabled_for_disk_encryption     = false
  enabled_for_template_deployment = false
  public_network_access_enabled   = length(var.private_endpoints) > 0 ? false : var.public_network_access_enabled

  # Networking
  private_endpoints                       = local.private_endpoints
  private_endpoints_manage_dns_zone_group = true
  network_acls = var.network_acls != null ? var.network_acls : {
    bypass                     = "None"
    default_action             = "Deny"
    ip_rules                   = []
    virtual_network_subnet_ids = []
  }

  # RBAC
  role_assignments = var.role_assignments

  # Vault content
  keys          = var.keys
  secrets       = var.secrets
  secrets_value = var.secrets_value
  contacts      = var.contacts

  # Diagnostics, locks, tagging
  diagnostic_settings = length(var.diagnostic_settings) > 0 ? var.diagnostic_settings : local.diagnostic_destination
  lock                = var.lock
  tags                = local.lsm_tags
}
