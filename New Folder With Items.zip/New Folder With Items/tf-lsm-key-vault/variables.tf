# =====================================================================
# Required
# =====================================================================

variable "name" {
  type        = string
  description = "Key Vault name. 3-24 chars; starts with a letter; alphanumerics and hyphens; ends with letter or digit; globally unique in Azure; no consecutive hyphens."

  validation {
    condition     = can(regex("^[a-zA-Z][a-zA-Z0-9-]{1,22}[a-zA-Z0-9]$", var.name)) && !can(regex("--", var.name))
    error_message = "name must be 3-24 chars, start with a letter, contain only alphanumerics and hyphens, end with letter/digit, no consecutive hyphens."
  }
}

variable "resource_group_name" {
  type        = string
  description = "Resource Group name."
}

variable "location" {
  type        = string
  description = "Azure region."
}

variable "tenant_id" {
  type        = string
  description = "Entra ID tenant ID (GUID) used to authenticate vault requests."

  validation {
    condition     = can(regex("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$", var.tenant_id))
    error_message = "tenant_id must be a valid GUID."
  }
}

# =====================================================================
# Vault tier and lifecycle (LSM applies hardened defaults in main.tf)
# =====================================================================

variable "sku_name" {
  type        = string
  description = "Vault SKU. 'standard' or 'premium'. Defaults to 'premium' (required for HSM-backed keys)."
  default     = "premium"

  validation {
    condition     = contains(["standard", "premium"], var.sku_name)
    error_message = "sku_name must be 'standard' or 'premium'."
  }
}

variable "soft_delete_retention_days" {
  type        = number
  description = "Soft-delete retention in days. 7-90. Defaults to 90."
  default     = 90

  validation {
    condition     = var.soft_delete_retention_days >= 7 && var.soft_delete_retention_days <= 90
    error_message = "soft_delete_retention_days must be between 7 and 90."
  }
}

# =====================================================================
# Networking (LSM forces public-off when PEs configured + deny-all ACL)
# =====================================================================

variable "public_network_access_enabled" {
  type        = bool
  description = "Whether the vault is reachable from the public internet. Forced to false when private_endpoints is non-empty."
  default     = false
}

variable "private_endpoint_subnet_id" {
  type        = string
  description = "Subnet resource ID hosting the private endpoints. Required when private_endpoints is non-empty."
  default     = null
}

variable "private_endpoints" {
  type = map(object({
    name                          = string
    private_dns_zone_resource_ids = optional(set(string), [])
  }))
  description = "Private endpoints to create, keyed by logical name. Subnet is shared via var.private_endpoint_subnet_id."
  default     = {}
}

variable "network_acls" {
  type = object({
    bypass                     = optional(string, "None")
    default_action             = optional(string, "Deny")
    ip_rules                   = optional(list(string), [])
    virtual_network_subnet_ids = optional(set(string), [])
  })
  description = "Override the default deny-all + bypass=None firewall ACL. When null, the LSM applies the default."
  default     = null
}

# =====================================================================
# RBAC (legacy access policies are disabled by the LSM)
# =====================================================================

variable "role_assignments" {
  type = map(object({
    role_definition_id_or_name             = string
    principal_id                           = string
    description                            = optional(string, null)
    skip_service_principal_aad_check       = optional(bool, false)
    condition                              = optional(string, null)
    condition_version                      = optional(string, null)
    delegated_managed_identity_resource_id = optional(string, null)
    principal_type                         = optional(string, null)
  }))
  description = "RBAC role assignments scoped to the Vault. Common roles: 'Key Vault Administrator', 'Key Vault Secrets User', 'Key Vault Crypto User'."
  default     = {}
}

# =====================================================================
# Vault content (pass-through)
# =====================================================================

variable "keys" {
  type        = map(any)
  description = "Cryptographic keys to create. Pass-through to the wrapper."
  default     = {}
}

variable "secrets" {
  type        = map(any)
  description = "Secret metadata (names) to create. Values supplied via var.secrets_value."
  default     = {}
}

variable "secrets_value" {
  type        = map(string)
  description = "Secret values keyed identically to var.secrets. Marked sensitive."
  default     = null
  sensitive   = true
}

variable "contacts" {
  type = map(object({
    email = string
    name  = optional(string, null)
    phone = optional(string, null)
  }))
  description = "Certificate-lifecycle contacts."
  default     = {}
}

# =====================================================================
# Diagnostics
# =====================================================================

variable "log_analytics_workspace_id" {
  type        = string
  description = "Log Analytics Workspace resource ID. When set, the LSM auto-wires diagnostic settings unless overridden via var.diagnostic_settings."
  default     = null
}

variable "diagnostic_settings" {
  type        = map(any)
  description = "Override diagnostic settings. Empty map = inherit from var.log_analytics_workspace_id."
  default     = {}
}

# =====================================================================
# Governance
# =====================================================================

variable "lock" {
  type = object({
    kind = string
    name = optional(string, null)
  })
  description = "Optional resource lock. 'CanNotDelete' or 'ReadOnly'."
  default     = null
}

variable "tags" {
  type        = map(string)
  description = "Workload tags. The LSM adds managed-by/lsm tags automatically."
  default     = null
}
