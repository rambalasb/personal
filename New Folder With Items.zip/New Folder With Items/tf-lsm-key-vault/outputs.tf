output "resource_id" {
  description = "Azure resource ID of the Key Vault."
  value       = module.key_vault.resource_id
}

output "name" {
  description = "Name of the Key Vault."
  value       = module.key_vault.name
}

output "uri" {
  description = "Vault URI for key/secret operations."
  value       = module.key_vault.uri
}

output "private_endpoints" {
  description = "Map of private endpoints created on the Vault."
  value       = module.key_vault.private_endpoints
}

output "keys_resource_ids" {
  description = "Map of key names to resource IDs (id, resource_id, versionless_id)."
  value       = module.key_vault.keys_resource_ids
}

output "secrets_resource_ids" {
  description = "Map of secret names to resource IDs."
  value       = module.key_vault.secrets_resource_ids
}
