check "min_tls_v12_enforced" {
  assert {
    condition     = var.min_tls_version == "TLS1_2"
    error_message = "Storage Account should enforce TLS 1.2. Set var.min_tls_version = \"TLS1_2\"."
  }
}

check "anonymous_blob_access_disabled" {
  assert {
    condition     = !var.allow_nested_items_to_be_public
    error_message = "Storage Account should not allow anonymous blob access. Set var.allow_nested_items_to_be_public = false."
  }
}

check "https_only_traffic" {
  assert {
    condition     = var.https_traffic_only_enabled
    error_message = "Storage Account should enforce HTTPS-only traffic. Set var.https_traffic_only_enabled = true."
  }
}

check "shared_key_disabled_rbac_enforced" {
  assert {
    condition     = !var.shared_access_key_enabled
    error_message = "Storage Account should disable Shared Key authorization to enforce Azure AD / RBAC. Set var.shared_access_key_enabled = false."
  }
}

check "private_endpoint_implies_no_public_access" {
  assert {
    condition     = length(var.private_endpoints) == 0 || !var.public_network_access_enabled
    error_message = "When private endpoints are configured, public network access should be disabled. Set var.public_network_access_enabled = false."
  }
}

check "network_rules_default_deny" {
  assert {
    condition     = var.network_rules == null || try(var.network_rules.default_action, "Deny") == "Deny"
    error_message = "Storage Account network_rules.default_action should be 'Deny' with explicit IP/subnet allowlists."
  }
}

check "infrastructure_encryption_enabled" {
  assert {
    condition     = var.infrastructure_encryption_enabled
    error_message = "Storage Account should enable infrastructure encryption (double-encryption-at-rest). Set var.infrastructure_encryption_enabled = true."
  }
}

check "cross_tenant_replication_disabled" {
  assert {
    condition     = !var.cross_tenant_replication_enabled
    error_message = "Storage Account should disable cross-tenant replication unless explicitly required. Set var.cross_tenant_replication_enabled = false."
  }
}
