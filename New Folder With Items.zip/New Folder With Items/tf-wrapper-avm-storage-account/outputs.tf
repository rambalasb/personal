output "resource_id" {
  description = "The resource ID of the Storage Account."
  value       = module.storage_account.resource_id
}

output "name" {
  description = "The name of the Storage Account."
  value       = module.storage_account.name
}

output "fqdn" {
  description = "Map of FQDNs per service endpoint (blob, file, queue, table, dfs, web)."
  value       = module.storage_account.fqdn
}

output "private_endpoints" {
  description = "Map of private endpoints created on the Storage Account, keyed by the input map key."
  value       = module.storage_account.private_endpoints
}

output "containers" {
  description = "Map of containers created in the Storage Account."
  value       = module.storage_account.containers
}

output "queues" {
  description = "Map of queues created in the Storage Account."
  value       = module.storage_account.queues
}

output "tables" {
  description = "Map of tables created in the Storage Account."
  value       = module.storage_account.tables
}

output "shares" {
  description = "Map of file shares created in the Storage Account."
  value       = module.storage_account.shares
}

output "data_lake_gen2_filesystems" {
  description = "Map of Data Lake Gen2 filesystems created in the Storage Account."
  value       = module.storage_account.data_lake_gen2_filesystems
}

output "local_users" {
  description = "Map of Storage Account Local Users (SFTP). Contains sensitive password data when ssh_password_enabled is true."
  value       = module.storage_account.local_users
  sensitive   = true
}

output "resource" {
  description = "The full azurerm_storage_account resource object."
  value       = module.storage_account.resource
  sensitive   = true
}

# Access keys are exposed as ephemeral outputs by AVM (Terraform >= 1.10).
# Re-export with ephemeral = true to preserve the contract.
output "primary_access_key" {
  description = "The primary access key for the Storage Account. Ephemeral — never persisted to state."
  value       = module.storage_account.primary_access_key
  ephemeral   = true
}

output "secondary_access_key" {
  description = "The secondary access key for the Storage Account. Ephemeral — never persisted to state."
  value       = module.storage_account.secondary_access_key
  ephemeral   = true
}
