module "storage_account" {
  source  = "Azure/avm-res-storage-storageaccount/azurerm"
  version = "0.6.8"

  # Required
  name                = var.name
  resource_group_name = var.resource_group_name
  location            = var.location

  # Account-level toggles
  account_kind                      = var.account_kind
  account_tier                      = var.account_tier
  account_replication_type          = var.account_replication_type
  access_tier                       = var.access_tier
  min_tls_version                   = var.min_tls_version
  allow_nested_items_to_be_public   = var.allow_nested_items_to_be_public
  https_traffic_only_enabled        = var.https_traffic_only_enabled
  shared_access_key_enabled         = var.shared_access_key_enabled
  default_to_oauth_authentication   = var.default_to_oauth_authentication
  public_network_access_enabled     = var.public_network_access_enabled
  cross_tenant_replication_enabled  = var.cross_tenant_replication_enabled
  infrastructure_encryption_enabled = var.infrastructure_encryption_enabled
  is_hns_enabled                    = var.is_hns_enabled
  nfsv3_enabled                     = var.nfsv3_enabled
  sftp_enabled                      = var.sftp_enabled
  large_file_share_enabled          = var.large_file_share_enabled
  local_user_enabled                = var.local_user_enabled
  allowed_copy_scope                = var.allowed_copy_scope
  queue_encryption_key_type         = var.queue_encryption_key_type
  table_encryption_key_type         = var.table_encryption_key_type
  edge_zone                         = var.edge_zone
  provisioned_billing_model_version = var.provisioned_billing_model_version
  enable_telemetry                  = var.enable_telemetry

  # Networking
  private_endpoints                       = var.private_endpoints
  private_endpoints_manage_dns_zone_group = var.private_endpoints_manage_dns_zone_group
  network_rules                           = var.network_rules

  # RBAC, identity, encryption
  role_assignments     = var.role_assignments
  managed_identities   = var.managed_identities
  customer_managed_key = var.customer_managed_key

  # Sub-resources
  containers                         = var.containers
  queues                             = var.queues
  tables                             = var.tables
  shares                             = var.shares
  storage_data_lake_gen2_filesystems = var.storage_data_lake_gen2_filesystems
  storage_data_lake_gen2_paths       = var.storage_data_lake_gen2_paths
  storage_management_policy_rule     = var.storage_management_policy_rule
  storage_management_policy_timeouts = var.storage_management_policy_timeouts
  local_user                         = var.local_user

  # Object-level service properties
  blob_properties            = var.blob_properties
  queue_properties           = var.queue_properties
  share_properties           = var.share_properties
  azure_files_authentication = var.azure_files_authentication
  immutability_policy        = var.immutability_policy
  static_website             = var.static_website
  routing                    = var.routing
  sas_policy                 = var.sas_policy
  custom_domain              = var.custom_domain

  # Diagnostics
  diagnostic_settings_storage_account = var.diagnostic_settings_storage_account
  diagnostic_settings_blob            = var.diagnostic_settings_blob
  diagnostic_settings_file            = var.diagnostic_settings_file
  diagnostic_settings_queue           = var.diagnostic_settings_queue
  diagnostic_settings_table           = var.diagnostic_settings_table

  # Locks, tagging, timeouts
  lock     = var.lock
  tags     = local.module_tags
  timeouts = var.timeouts
}
