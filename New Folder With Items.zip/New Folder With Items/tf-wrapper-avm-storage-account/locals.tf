locals {
  module_tags = merge(
    var.tags == null ? {} : var.tags,
    {
      managed-by = "terraform"
      module     = "tf-wrapper-avm-storage-account"
    }
  )

  has_private_endpoints = length(var.private_endpoints) > 0
  rbac_enforced         = !var.shared_access_key_enabled
}
