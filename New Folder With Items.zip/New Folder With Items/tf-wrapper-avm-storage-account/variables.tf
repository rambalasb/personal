# =====================================================================
# Required inputs
# =====================================================================

variable "name" {
  type        = string
  description = "The name of the Storage Account. Must be 3-24 characters, lowercase letters and numbers only, globally unique within Azure."

  validation {
    condition     = can(regex("^[a-z0-9]{3,24}$", var.name))
    error_message = "name must be 3-24 characters, lowercase letters and numbers only."
  }
}

variable "resource_group_name" {
  type        = string
  description = "The name of the resource group where the Storage Account will be deployed."

  validation {
    condition     = length(var.resource_group_name) > 0 && length(var.resource_group_name) <= 90
    error_message = "resource_group_name must be between 1 and 90 characters."
  }
}

variable "location" {
  type        = string
  description = "The Azure region where the Storage Account will be deployed."

  validation {
    condition     = length(var.location) > 0
    error_message = "location must not be empty."
  }
}

# =====================================================================
# Account-level toggles (secure-by-default)
# =====================================================================

variable "account_kind" {
  type        = string
  description = "The kind of storage account. Valid: 'BlobStorage', 'BlockBlobStorage', 'FileStorage', 'Storage', 'StorageV2'."
  default     = "StorageV2"

  validation {
    condition     = contains(["BlobStorage", "BlockBlobStorage", "FileStorage", "Storage", "StorageV2"], var.account_kind)
    error_message = "account_kind must be one of: BlobStorage, BlockBlobStorage, FileStorage, Storage, StorageV2."
  }
}

variable "account_tier" {
  type        = string
  description = "Storage account tier. Valid: 'Standard', 'Premium'. Premium is required for BlockBlobStorage and FileStorage."
  default     = "Standard"

  validation {
    condition     = contains(["Standard", "Premium"], var.account_tier)
    error_message = "account_tier must be 'Standard' or 'Premium'."
  }
}

variable "account_replication_type" {
  type        = string
  description = "Replication type. Valid: 'LRS', 'GRS', 'RAGRS', 'ZRS', 'GZRS', 'RAGZRS'. Defaults to ZRS for zone resilience."
  default     = "ZRS"

  validation {
    condition     = contains(["LRS", "GRS", "RAGRS", "ZRS", "GZRS", "RAGZRS"], var.account_replication_type)
    error_message = "account_replication_type must be one of: LRS, GRS, RAGRS, ZRS, GZRS, RAGZRS."
  }
}

variable "access_tier" {
  type        = string
  description = "Access tier for BlobStorage, FileStorage, and StorageV2. Valid: 'Hot', 'Cool', 'Cold', 'Premium'."
  default     = "Hot"

  validation {
    condition     = contains(["Hot", "Cool", "Cold", "Premium"], var.access_tier)
    error_message = "access_tier must be one of: Hot, Cool, Cold, Premium."
  }
}

variable "min_tls_version" {
  type        = string
  description = "Minimum TLS version. Defaults to TLS1_2 for compliance. TLS1_0 and TLS1_1 are deprecated and should not be used."
  default     = "TLS1_2"

  validation {
    condition     = contains(["TLS1_0", "TLS1_1", "TLS1_2"], var.min_tls_version)
    error_message = "min_tls_version must be one of: TLS1_0, TLS1_1, TLS1_2."
  }
}

variable "allow_nested_items_to_be_public" {
  type        = bool
  description = "Whether nested items (blobs, containers) can opt into public access. Defaults to false to disallow anonymous blob access."
  default     = false
}

variable "https_traffic_only_enabled" {
  type        = bool
  description = "Whether HTTPS-only traffic is enforced on the storage account."
  default     = true
}

variable "shared_access_key_enabled" {
  type        = bool
  description = "Whether requests can be authorized with the storage account access key. Defaults to false to enforce Azure AD / RBAC authorization."
  default     = false
}

variable "default_to_oauth_authentication" {
  type        = bool
  description = "Whether the Azure Portal defaults to Azure AD authorization when accessing the storage account."
  default     = true
}

variable "public_network_access_enabled" {
  type        = bool
  description = "Whether public network access is enabled. Defaults to false; pair with private_endpoints for private access."
  default     = false
}

variable "cross_tenant_replication_enabled" {
  type        = bool
  description = "Whether cross-tenant object replication is permitted."
  default     = false
}

variable "infrastructure_encryption_enabled" {
  type        = bool
  description = "Whether infrastructure encryption (double-encryption-at-rest) is enabled. Forces a new resource."
  default     = true
}

variable "is_hns_enabled" {
  type        = bool
  description = "Whether Hierarchical Namespace (Data Lake Gen2) is enabled. Forces a new resource."
  default     = null
}

variable "nfsv3_enabled" {
  type        = bool
  description = "Whether NFSv3 protocol is enabled. Requires HNS. Forces a new resource."
  default     = false
}

variable "sftp_enabled" {
  type        = bool
  description = "Whether SFTP is enabled. Requires HNS."
  default     = false
}

variable "large_file_share_enabled" {
  type        = bool
  description = "Whether large file shares (up to 100 TiB) are enabled."
  default     = null
}

variable "local_user_enabled" {
  type        = bool
  description = "Whether Storage Account Local Users (SFTP/local SAS) are enabled."
  default     = false
}

variable "allowed_copy_scope" {
  type        = string
  description = "Restrict copy operations. Valid: 'AAD', 'PrivateLink', or null."
  default     = null

  validation {
    condition     = var.allowed_copy_scope == null || contains(["AAD", "PrivateLink"], coalesce(var.allowed_copy_scope, "AAD"))
    error_message = "allowed_copy_scope must be 'AAD', 'PrivateLink', or null."
  }
}

variable "queue_encryption_key_type" {
  type        = string
  description = "Queue service encryption key type. Valid: 'Service', 'Account'. Forces new resource."
  default     = null
}

variable "table_encryption_key_type" {
  type        = string
  description = "Table service encryption key type. Valid: 'Service', 'Account'. Forces new resource."
  default     = null
}

variable "edge_zone" {
  type        = string
  description = "The Edge Zone within the Azure region. Forces a new resource."
  default     = null
}

variable "provisioned_billing_model_version" {
  type        = string
  description = "Provisioned billing model version (e.g. 'V2' for FileStorage). Forces a new resource."
  default     = null

  validation {
    condition     = var.provisioned_billing_model_version == null || var.provisioned_billing_model_version == "V2"
    error_message = "provisioned_billing_model_version must be 'V2' or null."
  }
}

variable "enable_telemetry" {
  type        = bool
  description = "Whether to enable AVM module telemetry. Set false to opt out."
  default     = true
}

# =====================================================================
# Networking — private endpoints, network rules
# =====================================================================

variable "private_endpoints" {
  type = map(object({
    name = optional(string, null)
    role_assignments = optional(map(object({
      role_definition_id_or_name             = string
      principal_id                           = string
      description                            = optional(string, null)
      skip_service_principal_aad_check       = optional(bool, false)
      condition                              = optional(string, null)
      condition_version                      = optional(string, null)
      delegated_managed_identity_resource_id = optional(string, null)
      principal_type                         = optional(string, null)
    })), {})
    lock = optional(object({
      kind = string
      name = optional(string, null)
    }), null)
    tags                                    = optional(map(string), null)
    subnet_resource_id                      = string
    subresource_name                        = string
    private_dns_zone_group_name             = optional(string, "default")
    private_dns_zone_resource_ids           = optional(set(string), [])
    application_security_group_associations = optional(map(string), {})
    private_service_connection_name         = optional(string, null)
    network_interface_name                  = optional(string, null)
    location                                = optional(string, null)
    resource_group_name                     = optional(string, null)
    ip_configurations = optional(map(object({
      name               = string
      private_ip_address = string
    })), {})
  }))
  description = "Map of private endpoints. Map key is a logical name. subresource_name must be one of: blob, dfs, file, queue, table, web."
  default     = {}
}

variable "private_endpoints_manage_dns_zone_group" {
  type        = bool
  description = "Whether the module manages private DNS zone groups. Set false when DNS is managed externally (e.g. via Azure Policy)."
  default     = true
}

variable "network_rules" {
  type = object({
    bypass                     = optional(set(string), ["AzureServices"])
    default_action             = optional(string, "Deny")
    ip_rules                   = optional(set(string), [])
    virtual_network_subnet_ids = optional(set(string), [])
    private_link_access = optional(list(object({
      endpoint_resource_id = string
      endpoint_tenant_id   = optional(string)
    })))
    timeouts = optional(object({
      create = optional(string)
      delete = optional(string)
      read   = optional(string)
      update = optional(string)
    }))
  })
  description = "Network ACL rules. Defaults deny-all with AzureServices bypass. Set to null to disable network rules entirely (not recommended)."
  default     = {}
}

# =====================================================================
# RBAC, identity, encryption
# =====================================================================

variable "role_assignments" {
  type = map(object({
    role_definition_id_or_name             = string
    principal_id                           = string
    description                            = optional(string, null)
    skip_service_principal_aad_check       = optional(bool, false)
    condition                              = optional(string, null)
    condition_version                      = optional(string, null)
    delegated_managed_identity_resource_id = optional(string, null)
    principal_type                         = optional(string, null)
  }))
  description = "Map of RBAC role assignments on the Storage Account. Common roles: 'Storage Blob Data Owner/Contributor/Reader', 'Storage Queue Data Contributor'."
  default     = {}
}

variable "managed_identities" {
  type = object({
    system_assigned            = optional(bool, false)
    user_assigned_resource_ids = optional(set(string), [])
  })
  description = "Managed identity configuration. Enable system_assigned for CMK or service-to-service auth."
  default     = {}
}

variable "customer_managed_key" {
  type = object({
    key_vault_resource_id = string
    key_name              = string
    key_version           = optional(string, null)
    user_assigned_identity = optional(object({
      resource_id = string
    }), null)
  })
  description = "Customer-managed key for encryption at rest. Requires a managed identity with Key Vault Crypto Service Encryption User role."
  default     = null
}

# =====================================================================
# Sub-resources (containers, queues, tables, shares, data lake, policy)
# =====================================================================

variable "containers" {
  type = map(object({
    public_access                  = optional(string, "None")
    metadata                       = optional(map(string))
    name                           = string
    default_encryption_scope       = optional(string)
    deny_encryption_scope_override = optional(bool)
    enable_nfs_v3_all_squash       = optional(bool)
    enable_nfs_v3_root_squash      = optional(bool)
    immutable_storage_with_versioning = optional(object({
      enabled = bool
    }))
    role_assignments = optional(map(object({
      role_definition_id_or_name             = string
      principal_id                           = string
      principal_type                         = optional(string, null)
      description                            = optional(string, null)
      skip_service_principal_aad_check       = optional(bool, false)
      condition                              = optional(string, null)
      condition_version                      = optional(string, null)
      delegated_managed_identity_resource_id = optional(string, null)
    })), {})
    timeouts = optional(object({
      create = optional(string)
      delete = optional(string)
      read   = optional(string)
      update = optional(string)
    }))
  }))
  description = "Map of blob containers to create. public_access defaults to 'None' to align with anonymous-access-disabled posture."
  default     = {}
}

variable "queues" {
  type = map(object({
    metadata = optional(map(string))
    name     = string
    role_assignments = optional(map(object({
      role_definition_id_or_name             = string
      principal_id                           = string
      principal_type                         = optional(string, null)
      description                            = optional(string, null)
      skip_service_principal_aad_check       = optional(bool, false)
      condition                              = optional(string, null)
      condition_version                      = optional(string, null)
      delegated_managed_identity_resource_id = optional(string, null)
    })), {})
    timeouts = optional(object({
      create = optional(string)
      delete = optional(string)
      read   = optional(string)
      update = optional(string)
    }))
  }))
  description = "Map of storage queues to create."
  default     = {}
}

variable "tables" {
  type = map(object({
    name = string
    signed_identifiers = optional(list(object({
      id = string
      access_policy = optional(object({
        expiry_time = string
        permission  = string
        start_time  = string
      }))
    })))
    role_assignments = optional(map(object({
      role_definition_id_or_name             = string
      principal_id                           = string
      principal_type                         = optional(string, null)
      description                            = optional(string, null)
      skip_service_principal_aad_check       = optional(bool, false)
      condition                              = optional(string, null)
      condition_version                      = optional(string, null)
      delegated_managed_identity_resource_id = optional(string, null)
    })), {})
    timeouts = optional(object({
      create = optional(string)
      delete = optional(string)
      read   = optional(string)
      update = optional(string)
    }))
  }))
  description = "Map of storage tables to create."
  default     = {}
}

variable "shares" {
  type = map(object({
    access_tier      = optional(string)
    enabled_protocol = optional(string)
    metadata         = optional(map(string))
    name             = string
    quota            = number
    root_squash      = optional(string)
    signed_identifiers = optional(list(object({
      id = string
      access_policy = optional(object({
        expiry_time = string
        permission  = string
        start_time  = string
      }))
    })))
    role_assignments = optional(map(object({
      role_definition_id_or_name             = string
      principal_id                           = string
      principal_type                         = optional(string, null)
      description                            = optional(string, null)
      skip_service_principal_aad_check       = optional(bool, false)
      condition                              = optional(string, null)
      condition_version                      = optional(string, null)
      delegated_managed_identity_resource_id = optional(string, null)
    })), {})
    timeouts = optional(object({
      create = optional(string)
      delete = optional(string)
      read   = optional(string)
      update = optional(string)
    }))
  }))
  description = "Map of file shares to create."
  default     = {}
}

variable "storage_data_lake_gen2_filesystems" {
  type = map(object({
    default_encryption_scope = optional(string)
    group                    = optional(string)
    name                     = string
    owner                    = optional(string)
    properties               = optional(map(string))
    ace = optional(set(object({
      id          = optional(string)
      permissions = string
      scope       = optional(string)
      type        = string
    })))
    timeouts = optional(object({
      create = optional(string)
      delete = optional(string)
      read   = optional(string)
      update = optional(string)
    }))
  }))
  description = "Map of Data Lake Gen2 filesystems. Requires is_hns_enabled = true."
  default     = {}
}

variable "storage_data_lake_gen2_paths" {
  type = map(object({
    path            = string
    filesystem_name = string
    resource        = string
    owner           = optional(string)
    group           = optional(string)
    ace = optional(set(object({
      id          = optional(string)
      permissions = string
      scope       = optional(string)
      type        = string
    })))
    timeouts = optional(object({
      create = optional(string)
      delete = optional(string)
      read   = optional(string)
      update = optional(string)
    }))
  }))
  description = "Map of Data Lake Gen2 paths (directories or files) within filesystems."
  default     = {}
}

variable "storage_management_policy_rule" {
  type = map(object({
    enabled = bool
    name    = string
    actions = object({
      base_blob = optional(object({
        auto_tier_to_hot_from_cool_enabled                             = optional(bool)
        delete_after_days_since_creation_greater_than                  = optional(number)
        delete_after_days_since_last_access_time_greater_than          = optional(number)
        delete_after_days_since_modification_greater_than              = optional(number)
        tier_to_archive_after_days_since_creation_greater_than         = optional(number)
        tier_to_archive_after_days_since_last_access_time_greater_than = optional(number)
        tier_to_archive_after_days_since_last_tier_change_greater_than = optional(number)
        tier_to_archive_after_days_since_modification_greater_than     = optional(number)
        tier_to_cold_after_days_since_creation_greater_than            = optional(number)
        tier_to_cold_after_days_since_last_access_time_greater_than    = optional(number)
        tier_to_cold_after_days_since_modification_greater_than        = optional(number)
        tier_to_cool_after_days_since_creation_greater_than            = optional(number)
        tier_to_cool_after_days_since_last_access_time_greater_than    = optional(number)
        tier_to_cool_after_days_since_modification_greater_than        = optional(number)
      }))
      snapshot = optional(object({
        change_tier_to_archive_after_days_since_creation               = optional(number)
        change_tier_to_cool_after_days_since_creation                  = optional(number)
        delete_after_days_since_creation_greater_than                  = optional(number)
        tier_to_archive_after_days_since_last_tier_change_greater_than = optional(number)
        tier_to_cold_after_days_since_creation_greater_than            = optional(number)
      }))
      version = optional(object({
        change_tier_to_archive_after_days_since_creation               = optional(number)
        change_tier_to_cool_after_days_since_creation                  = optional(number)
        delete_after_days_since_creation                               = optional(number)
        tier_to_archive_after_days_since_last_tier_change_greater_than = optional(number)
        tier_to_cold_after_days_since_creation_greater_than            = optional(number)
      }))
    })
    filters = object({
      blob_types   = set(string)
      prefix_match = optional(set(string))
      match_blob_index_tag = optional(set(object({
        name      = string
        operation = optional(string)
        value     = string
      })))
    })
  }))
  description = "Map of lifecycle management rules for blob tiering and deletion."
  default     = {}
}

variable "storage_management_policy_timeouts" {
  type = object({
    create = optional(string)
    delete = optional(string)
    read   = optional(string)
    update = optional(string)
  })
  description = "Timeouts for the storage management policy resource."
  default     = null
}

# =====================================================================
# Local user (SFTP)
# =====================================================================

variable "local_user" {
  type = map(object({
    home_directory       = optional(string)
    name                 = string
    ssh_key_enabled      = optional(bool)
    ssh_password_enabled = optional(bool)
    permission_scope = optional(list(object({
      resource_name = string
      service       = string
      permissions = object({
        create = optional(bool)
        delete = optional(bool)
        list   = optional(bool)
        read   = optional(bool)
        write  = optional(bool)
      })
    })))
    ssh_authorized_key = optional(list(object({
      description = optional(string)
      key         = string
    })))
    timeouts = optional(object({
      create = optional(string)
      delete = optional(string)
      read   = optional(string)
      update = optional(string)
    }))
  }))
  description = "Map of Storage Account Local Users for SFTP access."
  default     = {}
}

# =====================================================================
# Object-level service properties
# =====================================================================

variable "blob_properties" {
  type = object({
    change_feed_enabled           = optional(bool)
    change_feed_retention_in_days = optional(number)
    default_service_version       = optional(string)
    last_access_time_enabled      = optional(bool)
    versioning_enabled            = optional(bool, true)
    container_delete_retention_policy = optional(object({
      enabled = optional(bool, true)
      days    = optional(number, 7)
    }), {})
    cors_rule = optional(list(object({
      allowed_headers    = list(string)
      allowed_methods    = list(string)
      allowed_origins    = list(string)
      exposed_headers    = list(string)
      max_age_in_seconds = number
    })))
    delete_retention_policy = optional(object({
      enabled                  = optional(bool, true)
      days                     = optional(number, 7)
      permanent_delete_enabled = optional(bool, false)
    }), {})
    diagnostic_settings = optional(map(object({
      name                                     = optional(string, null)
      log_categories                           = optional(set(string), [])
      log_groups                               = optional(set(string), ["allLogs"])
      metric_categories                        = optional(set(string), ["AllMetrics"])
      log_analytics_destination_type           = optional(string, "Dedicated")
      workspace_resource_id                    = optional(string, null)
      resource_id                              = optional(string, null)
      event_hub_authorization_rule_resource_id = optional(string, null)
      event_hub_name                           = optional(string, null)
      marketplace_partner_resource_id          = optional(string, null)
    })), {})
    restore_policy = optional(object({
      days = number
    }))
  })
  description = "Blob service properties (versioning, soft delete, change feed, CORS, restore policy)."
  default     = null
}

variable "queue_properties" {
  type = map(object({
    cors_rule = optional(map(object({
      allowed_headers    = list(string)
      allowed_methods    = list(string)
      allowed_origins    = list(string)
      exposed_headers    = list(string)
      max_age_in_seconds = number
    })), {})
    hour_metrics = optional(object({
      include_apis          = optional(bool)
      retention_policy_days = optional(number)
      version               = string
    }))
    logging = optional(object({
      delete                = bool
      read                  = bool
      retention_policy_days = optional(number)
      version               = string
      write                 = bool
    }))
    minute_metrics = optional(object({
      include_apis          = optional(bool)
      retention_policy_days = optional(number)
      version               = string
    }))
  }))
  description = "Queue service properties (CORS, logging, metrics)."
  default     = {}
}

variable "share_properties" {
  type = object({
    cors_rule = optional(list(object({
      allowed_headers    = list(string)
      allowed_methods    = list(string)
      allowed_origins    = list(string)
      exposed_headers    = list(string)
      max_age_in_seconds = number
    })))
    diagnostic_settings = optional(map(object({
      name                                     = optional(string, null)
      log_categories                           = optional(set(string), [])
      log_groups                               = optional(set(string), ["allLogs"])
      metric_categories                        = optional(set(string), ["AllMetrics"])
      log_analytics_destination_type           = optional(string, "Dedicated")
      workspace_resource_id                    = optional(string, null)
      resource_id                              = optional(string, null)
      event_hub_authorization_rule_resource_id = optional(string, null)
      event_hub_name                           = optional(string, null)
      marketplace_partner_resource_id          = optional(string, null)
    })), {})
    retention_policy = optional(object({
      days = optional(number)
    }))
    smb = optional(object({
      authentication_types            = optional(set(string))
      channel_encryption_type         = optional(set(string))
      kerberos_ticket_encryption_type = optional(set(string))
      multichannel_enabled            = optional(bool)
      versions                        = optional(set(string))
    }))
  })
  description = "File share service properties (CORS, retention, SMB settings)."
  default     = null
}

variable "azure_files_authentication" {
  type = object({
    directory_type                 = optional(string, "AADKERB")
    default_share_level_permission = optional(string)
    active_directory = optional(object({
      domain_guid         = string
      domain_name         = string
      domain_sid          = optional(string)
      forest_name         = optional(string)
      netbios_domain_name = optional(string)
      storage_sid         = optional(string)
    }))
  })
  description = "Azure Files identity-based authentication. directory_type: 'AADDS', 'AD', or 'AADKERB'."
  default     = null
}

variable "immutability_policy" {
  type = object({
    allow_protected_append_writes = bool
    period_since_creation_in_days = number
    state                         = string
  })
  description = "Immutability policy. state: 'Disabled', 'Unlocked', or 'Locked'. Locked state cannot be reverted."
  default     = null

  validation {
    condition     = var.immutability_policy == null || contains(["Disabled", "Unlocked", "Locked"], try(var.immutability_policy.state, ""))
    error_message = "immutability_policy.state must be 'Disabled', 'Unlocked', or 'Locked'."
  }
}

variable "static_website" {
  type = map(object({
    error_404_document = optional(string)
    index_document     = optional(string)
  }))
  description = "Static website configuration."
  default     = null
}

variable "routing" {
  type = object({
    choice                      = optional(string, "MicrosoftRouting")
    publish_internet_endpoints  = optional(bool, false)
    publish_microsoft_endpoints = optional(bool, false)
  })
  description = "Network routing preference. choice: 'MicrosoftRouting' or 'InternetRouting'."
  default     = null
}

variable "sas_policy" {
  type = object({
    expiration_action = optional(string, "Log")
    expiration_period = string
  })
  description = "SAS expiration policy. expiration_period format: 'DD.HH:MM:SS'."
  default     = null
}

variable "custom_domain" {
  type = object({
    name          = string
    use_subdomain = optional(bool)
  })
  description = "Custom domain for the storage account. name will be validated by Azure."
  default     = null
}

# =====================================================================
# Diagnostics
# =====================================================================

variable "diagnostic_settings_storage_account" {
  type = map(object({
    name                                     = optional(string, null)
    metric_categories                        = optional(set(string), ["AllMetrics"])
    log_analytics_destination_type           = optional(string, "Dedicated")
    workspace_resource_id                    = optional(string, null)
    storage_account_resource_id              = optional(string, null)
    event_hub_authorization_rule_resource_id = optional(string, null)
    event_hub_name                           = optional(string, null)
    marketplace_partner_resource_id          = optional(string, null)
  }))
  description = "Diagnostic settings for the Storage Account resource itself (metrics only). Supported metric categories: 'Transaction', 'AllMetrics'."
  default     = {}
}

variable "diagnostic_settings_blob" {
  type = map(object({
    name                                     = optional(string, null)
    log_categories                           = optional(set(string), [])
    log_groups                               = optional(set(string), ["allLogs"])
    metric_categories                        = optional(set(string), ["AllMetrics"])
    log_analytics_destination_type           = optional(string, "Dedicated")
    workspace_resource_id                    = optional(string, null)
    storage_account_resource_id              = optional(string, null)
    event_hub_authorization_rule_resource_id = optional(string, null)
    event_hub_name                           = optional(string, null)
    marketplace_partner_resource_id          = optional(string, null)
  }))
  description = "Diagnostic settings for the Blob service. At least one destination must be specified per entry."
  default     = {}
}

variable "diagnostic_settings_file" {
  type = map(object({
    name                                     = optional(string, null)
    log_categories                           = optional(set(string), [])
    log_groups                               = optional(set(string), ["allLogs"])
    metric_categories                        = optional(set(string), ["AllMetrics"])
    log_analytics_destination_type           = optional(string, "Dedicated")
    workspace_resource_id                    = optional(string, null)
    storage_account_resource_id              = optional(string, null)
    event_hub_authorization_rule_resource_id = optional(string, null)
    event_hub_name                           = optional(string, null)
    marketplace_partner_resource_id          = optional(string, null)
    category                                 = optional(set(string), [])
  }))
  description = "Diagnostic settings for the File service."
  default     = {}
}

variable "diagnostic_settings_queue" {
  type = map(object({
    name                                     = optional(string, null)
    log_categories                           = optional(set(string), [])
    log_groups                               = optional(set(string), ["allLogs"])
    metric_categories                        = optional(set(string), ["AllMetrics"])
    log_analytics_destination_type           = optional(string, "Dedicated")
    workspace_resource_id                    = optional(string, null)
    storage_account_resource_id              = optional(string, null)
    event_hub_authorization_rule_resource_id = optional(string, null)
    event_hub_name                           = optional(string, null)
    marketplace_partner_resource_id          = optional(string, null)
  }))
  description = "Diagnostic settings for the Queue service."
  default     = {}
}

variable "diagnostic_settings_table" {
  type = map(object({
    name                                     = optional(string, null)
    log_categories                           = optional(set(string), [])
    log_groups                               = optional(set(string), ["allLogs"])
    metric_categories                        = optional(set(string), ["AllMetrics"])
    log_analytics_destination_type           = optional(string, "Dedicated")
    workspace_resource_id                    = optional(string, null)
    storage_account_resource_id              = optional(string, null)
    event_hub_authorization_rule_resource_id = optional(string, null)
    event_hub_name                           = optional(string, null)
    marketplace_partner_resource_id          = optional(string, null)
  }))
  description = "Diagnostic settings for the Table service."
  default     = {}
}

# =====================================================================
# Locks, tagging, timeouts
# =====================================================================

variable "lock" {
  type = object({
    name = optional(string, null)
    kind = string
  })
  description = "Optional resource lock. kind must be 'CanNotDelete' or 'ReadOnly'."
  default     = null

  validation {
    condition     = var.lock == null || contains(["CanNotDelete", "ReadOnly"], try(var.lock.kind, ""))
    error_message = "lock.kind must be 'CanNotDelete' or 'ReadOnly' when lock is set."
  }
}

variable "tags" {
  type        = map(string)
  description = "A map of tags to apply to the storage account."
  default     = null
}

variable "timeouts" {
  type = object({
    create = optional(string)
    delete = optional(string)
    read   = optional(string)
    update = optional(string)
  })
  description = "Operation timeouts for the storage account resource."
  default     = null
}
