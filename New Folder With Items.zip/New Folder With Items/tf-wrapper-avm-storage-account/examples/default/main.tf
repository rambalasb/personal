module "storage_account" {
  source = "../.."

  name                = "stavm${random_string.suffix.result}"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location

  enable_telemetry = false
}
