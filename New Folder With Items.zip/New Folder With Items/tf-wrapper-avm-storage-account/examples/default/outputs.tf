output "resource_id" {
  value = module.storage_account.resource_id
}

output "name" {
  value = module.storage_account.name
}

output "fqdn" {
  value = module.storage_account.fqdn
}
