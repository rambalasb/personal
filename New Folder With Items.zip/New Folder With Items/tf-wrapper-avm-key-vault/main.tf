module "key_vault" {
  source  = "Azure/avm-res-keyvault-vault/azurerm"
  version = "0.10.2"

  # Required
  name                = var.name
  resource_group_name = var.resource_group_name
  location            = var.location
  tenant_id           = var.tenant_id

  # Core toggles
  sku_name                        = var.sku_name
  enable_telemetry                = var.enable_telemetry
  purge_protection_enabled        = var.purge_protection_enabled
  soft_delete_retention_days      = var.soft_delete_retention_days
  public_network_access_enabled   = var.public_network_access_enabled
  enabled_for_deployment          = var.enabled_for_deployment
  enabled_for_disk_encryption     = var.enabled_for_disk_encryption
  enabled_for_template_deployment = var.enabled_for_template_deployment
  legacy_access_policies_enabled  = var.legacy_access_policies_enabled

  # Networking
  private_endpoints                       = var.private_endpoints
  private_endpoints_manage_dns_zone_group = var.private_endpoints_manage_dns_zone_group
  network_acls                            = var.network_acls

  # RBAC / access
  role_assignments       = var.role_assignments
  legacy_access_policies = var.legacy_access_policies

  # Vault content
  keys          = var.keys
  secrets       = var.secrets
  secrets_value = var.secrets_value
  contacts      = var.contacts

  # Diagnostics, locks, tagging
  diagnostic_settings = var.diagnostic_settings
  lock                = var.lock
  tags                = local.module_tags

  # RBAC propagation safety nets
  wait_for_rbac_before_key_operations     = var.wait_for_rbac_before_key_operations
  wait_for_rbac_before_secret_operations  = var.wait_for_rbac_before_secret_operations
  wait_for_rbac_before_contact_operations = var.wait_for_rbac_before_contact_operations
}
