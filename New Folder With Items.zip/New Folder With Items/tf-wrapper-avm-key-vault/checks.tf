check "purge_protection_enabled" {
  assert {
    condition     = var.purge_protection_enabled
    error_message = "Key Vault should have purge protection enabled. Set var.purge_protection_enabled = true to comply."
  }
}

check "rbac_authorization_used" {
  assert {
    condition     = !var.legacy_access_policies_enabled
    error_message = "Key Vault should use Azure RBAC, not legacy access policies. Set var.legacy_access_policies_enabled = false."
  }
}

check "private_endpoint_implies_no_public_access" {
  assert {
    condition     = length(var.private_endpoints) == 0 || !var.public_network_access_enabled
    error_message = "When private endpoints are configured, public network access should be disabled. Set var.public_network_access_enabled = false."
  }
}

check "network_acls_default_deny" {
  assert {
    condition     = !var.public_network_access_enabled || try(var.network_acls.default_action, "Deny") == "Deny"
    error_message = "When public network access is enabled, network_acls.default_action should be 'Deny' with explicit IP/subnet allowlists."
  }
}

check "soft_delete_retention_meets_minimum" {
  assert {
    condition     = var.soft_delete_retention_days == null || var.soft_delete_retention_days >= 7
    error_message = "soft_delete_retention_days should be at least 7 days for recoverability."
  }
}
