locals {
  module_tags = merge(
    var.tags == null ? {} : var.tags,
    {
      managed-by = "terraform"
      module     = "tf-wrapper-avm-key-vault"
    }
  )

  # When private endpoints are configured, public network access should be disabled.
  # Surfaced as a check (non-blocking) in checks.tf rather than enforced here, so
  # that callers retain explicit control.
  has_private_endpoints = length(var.private_endpoints) > 0
  uses_rbac             = !var.legacy_access_policies_enabled
}
