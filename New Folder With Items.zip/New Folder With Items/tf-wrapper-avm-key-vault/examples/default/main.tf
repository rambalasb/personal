module "key_vault" {
  source = "../.."

  name                = "kv-avm-${random_string.suffix.result}"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location
  tenant_id           = data.azurerm_client_config.current.tenant_id

  enable_telemetry = false
}
