output "resource_id" {
  value = module.key_vault.resource_id
}

output "name" {
  value = module.key_vault.name
}

output "uri" {
  value = module.key_vault.uri
}
