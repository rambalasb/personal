# random suffix to avoid name collisions on reruns
resource "random_string" "suffix" {
  length  = 6
  lower   = true
  upper   = false
  numeric = true
  special = false
}

# tenant_id for the vault is sourced from the authenticated context
data "azurerm_client_config" "current" {}

# native supporting RG so the example tests standalone, without a sibling module
resource "azurerm_resource_group" "this" {
  name     = "rg-avm-kv-default-test-${random_string.suffix.result}"
  location = "canadacentral"
}
