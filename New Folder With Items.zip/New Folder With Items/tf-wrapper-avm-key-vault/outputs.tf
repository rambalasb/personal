output "resource_id" {
  description = "The Azure resource ID of the Key Vault."
  value       = module.key_vault.resource_id
}

output "name" {
  description = "The name of the Key Vault."
  value       = module.key_vault.name
}

output "uri" {
  description = "The URI of the Key Vault for performing operations on keys and secrets."
  value       = module.key_vault.uri
}

output "private_endpoints" {
  description = "Map of private endpoints created for the Key Vault, keyed by the input map key."
  value       = module.key_vault.private_endpoints
}

output "keys" {
  description = "Map of keys created in the Key Vault. Each value is the full azurerm_key_vault_key resource (including id, resource_id, versionless_id)."
  value       = module.key_vault.keys
  sensitive   = true
}

output "keys_resource_ids" {
  description = "Map of key names to resource IDs (id, resource_id, versionless_id, resource_versionless_id)."
  value       = module.key_vault.keys_resource_ids
}

output "secrets" {
  description = "Map of secrets created in the Key Vault. Each value is the full azurerm_key_vault_secret resource."
  value       = module.key_vault.secrets
  sensitive   = true
}

output "secrets_resource_ids" {
  description = "Map of secret names to resource IDs (id, resource_id, versionless_id, resource_versionless_id)."
  value       = module.key_vault.secrets_resource_ids
}
