# =====================================================================
# Required inputs
# =====================================================================

variable "name" {
  type        = string
  description = "The name of the Key Vault. Must be 3-24 characters, alphanumerics and hyphens only, start with a letter, end with a letter or digit, and globally unique within Azure."

  validation {
    condition     = can(regex("^[a-zA-Z][a-zA-Z0-9-]{1,22}[a-zA-Z0-9]$", var.name)) && !can(regex("--", var.name))
    error_message = "name must be 3-24 characters, start with a letter, contain only alphanumerics and hyphens, end with a letter or digit, and contain no consecutive hyphens."
  }
}

variable "resource_group_name" {
  type        = string
  description = "The name of the resource group in which to create the Key Vault."

  validation {
    condition     = length(var.resource_group_name) > 0 && length(var.resource_group_name) <= 90
    error_message = "resource_group_name must be between 1 and 90 characters."
  }
}

variable "location" {
  type        = string
  description = "The Azure region where the Key Vault will be deployed."

  validation {
    condition     = length(var.location) > 0
    error_message = "location must not be empty."
  }
}

variable "tenant_id" {
  type        = string
  description = "The Azure Active Directory tenant ID used to authenticate requests to the Key Vault. Must be a valid GUID."

  validation {
    condition     = can(regex("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$", var.tenant_id))
    error_message = "tenant_id must be a valid GUID."
  }
}

# =====================================================================
# Core toggles (sane defaults — override per environment as needed)
# =====================================================================

variable "sku_name" {
  type        = string
  description = "The SKU of the Key Vault. Allowed values: 'standard', 'premium'. Premium is required for HSM-backed keys."
  default     = "premium"

  validation {
    condition     = contains(["standard", "premium"], var.sku_name)
    error_message = "sku_name must be 'standard' or 'premium'."
  }
}

variable "enable_telemetry" {
  type        = bool
  description = "Whether to enable AVM module telemetry. Set false to opt out of anonymous usage data collection."
  default     = true
}

variable "purge_protection_enabled" {
  type        = bool
  description = "Whether purge protection is enabled. Once enabled it cannot be disabled. Strongly recommended for production vaults."
  default     = true
}

variable "soft_delete_retention_days" {
  type        = number
  description = "Number of days that soft-deleted items are retained before permanent deletion. Must be between 7 and 90. Set null to use the AVM default."
  default     = null

  validation {
    condition     = var.soft_delete_retention_days == null || (try(var.soft_delete_retention_days, 0) >= 7 && try(var.soft_delete_retention_days, 0) <= 90)
    error_message = "soft_delete_retention_days must be between 7 and 90, or null."
  }
}

variable "public_network_access_enabled" {
  type        = bool
  description = "Whether the Key Vault is reachable from the public internet. Set false when private endpoints are used."
  default     = true
}

variable "enabled_for_deployment" {
  type        = bool
  description = "Whether Azure Virtual Machines are permitted to retrieve certificates stored as secrets from this Key Vault."
  default     = false
}

variable "enabled_for_disk_encryption" {
  type        = bool
  description = "Whether Azure Disk Encryption is permitted to retrieve secrets from this Key Vault and unwrap keys."
  default     = false
}

variable "enabled_for_template_deployment" {
  type        = bool
  description = "Whether Azure Resource Manager is permitted to retrieve secrets from this Key Vault during template deployments."
  default     = false
}

variable "legacy_access_policies_enabled" {
  type        = bool
  description = "Whether to enable legacy access policies. When true, RBAC authorization is disabled. Leave false to use Azure RBAC."
  default     = false
}

# =====================================================================
# Networking — private endpoints & firewall (toggle on as needed)
# =====================================================================

variable "private_endpoints" {
  type = map(object({
    name                            = optional(string, null)
    role_assignments                = optional(map(object({
      role_definition_id_or_name             = string
      principal_id                           = string
      description                            = optional(string, null)
      skip_service_principal_aad_check       = optional(bool, false)
      condition                              = optional(string, null)
      condition_version                      = optional(string, null)
      delegated_managed_identity_resource_id = optional(string, null)
      principal_type                         = optional(string, null)
    })), {})
    lock = optional(object({
      kind = string
      name = optional(string, null)
    }), null)
    tags                                    = optional(map(string), null)
    subnet_resource_id                      = string
    private_dns_zone_group_name             = optional(string, "default")
    private_dns_zone_resource_ids           = optional(set(string), [])
    application_security_group_associations = optional(map(string), {})
    private_service_connection_name         = optional(string, null)
    network_interface_name                  = optional(string, null)
    location                                = optional(string, null)
    resource_group_name                     = optional(string, null)
    ip_configurations = optional(map(object({
      name               = string
      private_ip_address = string
    })), {})
  }))
  description = "A map of private endpoint configurations. Map key is a logical name; subnet_resource_id is required per entry. Set to {} to disable."
  default     = {}
}

variable "private_endpoints_manage_dns_zone_group" {
  type        = bool
  description = "Whether the module manages private DNS zone groups for private endpoints. Set false when DNS is managed externally (e.g. via Azure Policy)."
  default     = true
}

variable "network_acls" {
  type = object({
    bypass                     = optional(string, "None")
    default_action             = optional(string, "Deny")
    ip_rules                   = optional(list(string), [])
    virtual_network_subnet_ids = optional(set(string), [])
  })
  description = "Network ACL rules. bypass: 'AzureServices' or 'None'. default_action: 'Allow' or 'Deny'. Defaults deny-all with no bypass."
  default     = {}

  validation {
    condition     = contains(["AzureServices", "None"], coalesce(var.network_acls.bypass, "None"))
    error_message = "network_acls.bypass must be 'AzureServices' or 'None'."
  }

  validation {
    condition     = contains(["Allow", "Deny"], coalesce(var.network_acls.default_action, "Deny"))
    error_message = "network_acls.default_action must be 'Allow' or 'Deny'."
  }
}

# =====================================================================
# RBAC — Azure role assignments
# =====================================================================

variable "role_assignments" {
  type = map(object({
    role_definition_id_or_name             = string
    principal_id                           = string
    description                            = optional(string, null)
    skip_service_principal_aad_check       = optional(bool, false)
    condition                              = optional(string, null)
    condition_version                      = optional(string, null)
    delegated_managed_identity_resource_id = optional(string, null)
    principal_type                         = optional(string, null)
  }))
  description = "A map of role assignments to create on the Key Vault. Map key is a logical name. Use built-in role names like 'Key Vault Administrator', 'Key Vault Secrets User', 'Key Vault Crypto User'."
  default     = {}
}

variable "legacy_access_policies" {
  type = map(object({
    object_id               = string
    application_id          = optional(string, null)
    certificate_permissions = optional(list(string), [])
    key_permissions         = optional(list(string), [])
    secret_permissions      = optional(list(string), [])
    storage_permissions     = optional(list(string), [])
  }))
  description = "Legacy access policy entries. Only used when legacy_access_policies_enabled = true. Prefer role_assignments (RBAC) where possible."
  default     = {}
}

# =====================================================================
# Optional: vault content (keys, secrets, certificates contacts)
# =====================================================================

variable "keys" {
  type = map(object({
    name     = string
    key_type = string
    key_opts = optional(list(string), ["sign", "verify", "wrapKey", "unwrapKey", "encrypt", "decrypt"])
    curve    = optional(string, null)
    key_size = optional(number, null)
    not_before_date = optional(string, null)
    expiration_date = optional(string, null)
    tags            = optional(map(string), null)
    rotation_policy = optional(object({
      automatic = optional(object({
        time_after_creation = optional(string, null)
        time_before_expiry  = optional(string, null)
      }), null)
      expire_after         = optional(string, null)
      notify_before_expiry = optional(string, null)
    }), null)
    role_assignments = optional(map(object({
      role_definition_id_or_name             = string
      principal_id                           = string
      description                            = optional(string, null)
      skip_service_principal_aad_check       = optional(bool, false)
      condition                              = optional(string, null)
      condition_version                      = optional(string, null)
      delegated_managed_identity_resource_id = optional(string, null)
      principal_type                         = optional(string, null)
    })), {})
  }))
  description = "Map of cryptographic keys to create in the Key Vault. Set to {} to skip key creation."
  default     = {}
}

variable "secrets" {
  type = map(object({
    name            = string
    content_type    = optional(string, null)
    not_before_date = optional(string, null)
    expiration_date = optional(string, null)
    tags            = optional(map(string), null)
    role_assignments = optional(map(object({
      role_definition_id_or_name             = string
      principal_id                           = string
      description                            = optional(string, null)
      skip_service_principal_aad_check       = optional(bool, false)
      condition                              = optional(string, null)
      condition_version                      = optional(string, null)
      delegated_managed_identity_resource_id = optional(string, null)
      principal_type                         = optional(string, null)
    })), {})
  }))
  description = "Map of secret metadata to create. Values are supplied separately via secrets_value to avoid storing sensitive material in plan output."
  default     = {}
}

variable "secrets_value" {
  type        = map(string)
  description = "Map of secret name to value, keyed identically to var.secrets. Marked sensitive."
  default     = null
  sensitive   = true
}

variable "contacts" {
  type = map(object({
    email = string
    name  = optional(string, null)
    phone = optional(string, null)
  }))
  description = "Map of contacts notified for certificate lifecycle events."
  default     = {}
}

# =====================================================================
# Optional: diagnostics, locks, tagging
# =====================================================================

variable "diagnostic_settings" {
  type = map(object({
    name                                     = optional(string, null)
    log_categories                           = optional(set(string), [])
    log_groups                               = optional(set(string), ["allLogs"])
    metric_categories                        = optional(set(string), ["AllMetrics"])
    log_analytics_destination_type           = optional(string, "Dedicated")
    workspace_resource_id                    = optional(string, null)
    storage_account_resource_id              = optional(string, null)
    event_hub_authorization_rule_resource_id = optional(string, null)
    event_hub_name                           = optional(string, null)
    marketplace_partner_resource_id          = optional(string, null)
  }))
  description = "Map of diagnostic settings. Provide at least one destination per entry (workspace, storage, event hub, or marketplace partner)."
  default     = {}
}

variable "lock" {
  type = object({
    kind = string
    name = optional(string, null)
  })
  description = "Optional resource lock. kind must be 'CanNotDelete' or 'ReadOnly'. Set null to disable."
  default     = null

  validation {
    condition     = var.lock == null || contains(["CanNotDelete", "ReadOnly"], try(var.lock.kind, ""))
    error_message = "lock.kind must be 'CanNotDelete' or 'ReadOnly' when lock is set."
  }
}

variable "tags" {
  type        = map(string)
  description = "A map of tags applied to the Key Vault."
  default     = null
}

# =====================================================================
# Optional: RBAC propagation timing safety nets
# =====================================================================

variable "wait_for_rbac_before_key_operations" {
  type = object({
    create  = optional(string, "30s")
    destroy = optional(string, "0s")
  })
  description = "Delay before performing key operations after role assignments are created/destroyed. Helps mitigate RBAC propagation lag."
  default     = {}
}

variable "wait_for_rbac_before_secret_operations" {
  type = object({
    create  = optional(string, "30s")
    destroy = optional(string, "0s")
  })
  description = "Delay before performing secret operations after role assignments are created/destroyed."
  default     = {}
}

variable "wait_for_rbac_before_contact_operations" {
  type = object({
    create  = optional(string, "30s")
    destroy = optional(string, "0s")
  })
  description = "Delay before performing contact operations after role assignments are created/destroyed."
  default     = {}
}
