module "resource_group" {
  source = "git::https://github.com/BCH-CloudAzure/avm-terraform-wrappers.git//tf-wrapper-avm-resource-group?ref=main"

  # Required
  name     = var.name
  location = var.location

  # Governance
  managed_by       = var.managed_by
  role_assignments = var.role_assignments
  lock             = var.lock
  tags             = local.lsm_tags
}
