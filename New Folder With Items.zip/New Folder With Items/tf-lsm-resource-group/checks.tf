check "ownership_defined" {
  assert {
    condition     = length(var.role_assignments) > 0 || var.managed_by != null
    error_message = "Resource Group must have at least one role_assignment or be managed_by an external resource. Orphaned RGs with no defined ownership are not permitted."
  }
}
