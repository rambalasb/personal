output "resource_id" {
  description = "Resource ID of the Resource Group."
  value       = module.resource_group.resource_id
}

output "name" {
  description = "Name of the Resource Group."
  value       = module.resource_group.name
}

output "location" {
  description = "Azure region of the Resource Group."
  value       = module.resource_group.location
}
