locals {
  lsm_tags = merge(
    var.tags == null ? {} : var.tags,
    {
      managed-by  = "terraform"
      lsm         = "tf-lsm-resource-group"
      lsm-version = "1.0.0"
    }
  )
}
