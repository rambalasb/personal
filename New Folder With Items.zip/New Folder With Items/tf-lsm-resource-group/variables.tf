# =====================================================================
# Required
# =====================================================================

variable "name" {
  type        = string
  description = "Resource Group name. 1-90 chars; alphanumerics, underscores, parentheses, hyphens, periods. Cannot end with a period."

  validation {
    condition     = can(regex("^[a-zA-Z0-9_().-]{1,89}[a-zA-Z0-9_()-]$", var.name))
    error_message = "name must be 1-90 chars, alphanumerics/underscores/parentheses/hyphens/periods, and cannot end with a period."
  }
}

variable "location" {
  type        = string
  description = "Azure region where the Resource Group will be deployed."
}

# =====================================================================
# Governance
# =====================================================================

variable "managed_by" {
  type        = string
  description = "Optional Azure resource ID of the resource or application that manages this Resource Group (e.g. a Managed Application or Databricks workspace). null for self-managed RGs."
  default     = null
}

variable "role_assignments" {
  type = map(object({
    role_definition_id_or_name             = string
    principal_id                           = string
    description                            = optional(string, null)
    skip_service_principal_aad_check       = optional(bool, false)
    condition                              = optional(string, null)
    condition_version                      = optional(string, null)
    delegated_managed_identity_resource_id = optional(string, null)
    principal_type                         = optional(string, null)
  }))
  description = "RBAC role assignments scoped to the Resource Group."
  default     = {}
}

variable "lock" {
  type = object({
    kind = string
    name = optional(string, null)
  })
  description = "Optional resource lock. kind must be 'CanNotDelete' or 'ReadOnly'."
  default     = null
}

variable "tags" {
  type        = map(string)
  description = "Workload tags. The LSM adds managed-by/lsm tags automatically."
  default     = null
}
