locals {
  lsm_tags = merge(
    var.tags == null ? {} : var.tags,
    {
      managed-by  = "terraform"
      lsm         = "tf-lsm-log-analytics"
      lsm-version = "1.0.0"
    }
  )

  private_endpoints = {
    for k, pe in var.private_endpoints :
    k => {
      name                            = pe.name
      subnet_resource_id              = var.private_endpoint_subnet_id
      private_dns_zone_resource_ids   = pe.private_dns_zone_resource_ids
      private_service_connection_name = "${pe.name}-psc"
      tags                            = local.lsm_tags
    }
  }
}
