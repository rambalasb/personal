module "log_analytics_workspace" {
  source = "git::https://github.com/BCH-CloudAzure/avm-terraform-wrappers.git//tf-wrapper-avm-log-analytics-workspace?ref=main"

  # Required
  name                = var.name
  resource_group_name = var.resource_group_name
  location            = var.location

  # Tier and retention
  log_analytics_workspace_sku               = var.sku
  log_analytics_workspace_retention_in_days = var.retention_in_days
  log_analytics_workspace_daily_quota_gb    = var.daily_quota_gb

  # LSM enforces Entra-only auth and PE-aware public toggles
  log_analytics_workspace_local_authentication_enabled = false
  log_analytics_workspace_internet_ingestion_enabled   = length(var.private_endpoints) > 0 ? "false" : var.internet_ingestion_enabled
  log_analytics_workspace_internet_query_enabled       = length(var.private_endpoints) > 0 ? "false" : var.internet_query_enabled

  # Networking
  private_endpoints = local.private_endpoints

  # RBAC, identity, encryption
  role_assignments     = var.role_assignments
  customer_managed_key = var.customer_managed_key

  # Diagnostics, locks, tags
  diagnostic_settings = var.diagnostic_settings
  lock                = var.lock
  tags                = local.lsm_tags
}
