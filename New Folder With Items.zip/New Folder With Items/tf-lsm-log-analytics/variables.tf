# =====================================================================
# Required
# =====================================================================

variable "name" {
  type        = string
  description = "Log Analytics Workspace name. 4-63 chars; alphanumerics and hyphens; start and end with alphanumeric."

  validation {
    condition     = can(regex("^[A-Za-z0-9][A-Za-z0-9-]{2,61}[A-Za-z0-9]$", var.name))
    error_message = "name must be 4-63 chars, alphanumerics and hyphens, starting and ending with alphanumeric."
  }
}

variable "resource_group_name" {
  type        = string
  description = "Resource Group name where the Workspace will be deployed."
}

variable "location" {
  type        = string
  description = "Azure region."
}

# =====================================================================
# Workspace tier and retention
# =====================================================================

variable "sku" {
  type        = string
  description = "Workspace SKU. null = upstream default ('PerGB2018'). Allowed: Free, PerNode, Premium, Standard, Standalone, Unlimited, CapacityReservation, PerGB2018."
  default     = null
}

variable "retention_in_days" {
  type        = number
  description = "Workspace data retention in days. 7 (Free only) or 30-730. Defaults to 90."
  default     = 90
}

variable "daily_quota_gb" {
  type        = number
  description = "Daily ingestion cap in GB. null = unlimited."
  default     = null
}

# =====================================================================
# Network access (LSM forces public-off when PEs are configured)
# =====================================================================

variable "internet_ingestion_enabled" {
  type        = string
  description = "Public ingestion. 'true' | 'false' | 'SecuredByPerimeter'. Forced to 'false' when private_endpoints is non-empty."
  default     = "false"
}

variable "internet_query_enabled" {
  type        = string
  description = "Public query. 'true' | 'false' | 'SecuredByPerimeter'. Forced to 'false' when private_endpoints is non-empty."
  default     = "false"
}

variable "private_endpoint_subnet_id" {
  type        = string
  description = "Subnet resource ID hosting the private endpoints. Required when private_endpoints is non-empty."
  default     = null
}

variable "private_endpoints" {
  type = map(object({
    name                          = string
    private_dns_zone_resource_ids = optional(set(string), [])
  }))
  description = "Private endpoints to create, keyed by logical name. Subnet is shared via var.private_endpoint_subnet_id."
  default     = {}
}

# =====================================================================
# Identity, RBAC, CMK
# =====================================================================

variable "role_assignments" {
  type = map(object({
    role_definition_id_or_name             = string
    principal_id                           = string
    description                            = optional(string, null)
    skip_service_principal_aad_check       = optional(bool, false)
    condition                              = optional(string, null)
    condition_version                      = optional(string, null)
    delegated_managed_identity_resource_id = optional(string, null)
    principal_type                         = optional(string, null)
  }))
  description = "RBAC role assignments scoped to the Workspace. Required because local (shared-key) auth is disabled by the LSM."
  default     = {}
}

variable "customer_managed_key" {
  type = object({
    key_vault_resource_id = string
    key_name              = string
    key_version           = optional(string, null)
    user_assigned_identity = optional(object({
      resource_id = string
    }), null)
  })
  description = "Optional customer-managed key for workspace encryption."
  default     = null
}

# =====================================================================
# Diagnostics
# =====================================================================

variable "diagnostic_settings" {
  type        = map(any)
  description = "Diagnostic settings on the Workspace itself (audit logs). Pass-through to the wrapper; self-pointing to this Workspace is allowed."
  default     = {}
}

# =====================================================================
# Governance
# =====================================================================

variable "lock" {
  type = object({
    kind = string
    name = optional(string, null)
  })
  description = "Optional resource lock. 'CanNotDelete' or 'ReadOnly'."
  default     = null
}

variable "tags" {
  type        = map(string)
  description = "Workload tags. The LSM adds managed-by/lsm tags automatically."
  default     = null
}
