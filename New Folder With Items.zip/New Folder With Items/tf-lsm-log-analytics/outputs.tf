output "resource_id" {
  description = "Azure resource ID of the Log Analytics Workspace. Pass this as log_analytics_workspace_id to downstream LSMs."
  value       = module.log_analytics_workspace.resource_id
}

output "name" {
  description = "Name of the Workspace."
  value       = var.name
}

output "workspace_id" {
  description = "Workspace GUID (customer_id) used by Azure Monitor agents and ingestion endpoints. Marked sensitive because it is derived from the upstream wrapper's sensitive resource object."
  value       = module.log_analytics_workspace.resource.workspace_id
  sensitive   = true
}

output "private_endpoints" {
  description = "Map of private endpoints created on the Workspace, keyed by the input map key."
  value       = module.log_analytics_workspace.private_endpoints
}
