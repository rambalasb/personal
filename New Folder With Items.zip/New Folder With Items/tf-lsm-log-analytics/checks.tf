check "private_endpoint_subnet_supplied" {
  assert {
    condition     = length(var.private_endpoints) == 0 || var.private_endpoint_subnet_id != null
    error_message = "var.private_endpoint_subnet_id must be set when private_endpoints is non-empty."
  }
}

check "rbac_required_when_local_auth_disabled" {
  assert {
    condition     = length(var.role_assignments) > 0
    error_message = "Local (shared-key) auth is disabled by the LSM. Provide at least one role_assignment so principals can read/write workspace data via Entra ID. Role assignments at higher scopes (RG, subscription) also satisfy this, but the LSM cannot detect those."
  }
}
