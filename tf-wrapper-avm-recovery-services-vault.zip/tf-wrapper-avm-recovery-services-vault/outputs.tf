output "resource_id" {
  description = "The Azure resource ID of the Recovery Services Vault."
  value       = module.recovery_services_vault.resource_id
}

output "resource" {
  description = "The full azapi Recovery Services Vault object."
  value       = module.recovery_services_vault.resource
}

output "private_endpoints" {
  description = "Map of private endpoints attached to the vault."
  value       = module.recovery_services_vault.private_endpoints
}

output "recovery_services_vault_vm_policy" {
  description = "Map of VM backup policy outputs, keyed by input map key."
  value       = module.recovery_services_vault.recovery_services_vault_vm_policy
}

output "recovery_services_vault_file_share_policy" {
  description = "Map of file share backup policy outputs, keyed by input map key."
  value       = module.recovery_services_vault.recovery_services_vault_file_share_policy
}

output "recovery_workload_policy" {
  description = "Map of workload (SQL/SAP HANA) backup policy outputs, keyed by input map key."
  value       = module.recovery_services_vault.recovery_workload_policy
}

output "backup_protected_vm" {
  description = "Map of registered protected VMs, keyed by input map key."
  value       = module.recovery_services_vault.backup_protected_vm
}
