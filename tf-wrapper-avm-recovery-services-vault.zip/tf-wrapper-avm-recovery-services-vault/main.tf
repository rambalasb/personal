module "recovery_services_vault" {
  source  = "Azure/avm-res-recoveryservices-vault/azurerm"
  version = "1.1.2"

  # Required
  name                = var.name
  resource_group_name = var.resource_group_name
  location            = var.location
  sku                 = var.sku

  # Vault behavior
  storage_mode_type             = var.storage_mode_type
  cross_region_restore_enabled  = var.cross_region_restore_enabled
  soft_delete_enabled           = var.soft_delete_enabled
  immutability                  = var.immutability
  public_network_access_enabled = var.public_network_access_enabled

  # Monitoring alerts
  alerts_for_all_job_failures_enabled            = var.alerts_for_all_job_failures_enabled
  alerts_for_critical_operation_failures_enabled = var.alerts_for_critical_operation_failures_enabled

  # Backup policies
  vm_backup_policy         = var.vm_backup_policy
  file_share_backup_policy = var.file_share_backup_policy
  workload_backup_policy   = var.workload_backup_policy

  # Protected items
  backup_protected_vm         = var.backup_protected_vm
  backup_protected_file_share = var.backup_protected_file_share

  # Networking
  private_endpoints                       = var.private_endpoints
  private_endpoints_manage_dns_zone_group = var.private_endpoints_manage_dns_zone_group

  # Identity & encryption
  managed_identities   = var.managed_identities
  customer_managed_key = var.customer_managed_key

  # Governance & diagnostics
  role_assignments    = var.role_assignments
  lock                = var.lock
  diagnostic_settings = var.diagnostic_settings

  # Deprecated
  classic_vmware_replication_enabled = var.classic_vmware_replication_enabled

  # Module behavior
  enable_telemetry = var.enable_telemetry
  tags             = local.module_tags
}
