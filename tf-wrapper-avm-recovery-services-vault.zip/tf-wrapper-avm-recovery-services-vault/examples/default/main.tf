module "recovery_services_vault" {
  source = "../.."

  name                = "rsv-avm-default-test-${random_string.suffix.result}"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location
  sku                 = "Standard"

  enable_telemetry = false
}
