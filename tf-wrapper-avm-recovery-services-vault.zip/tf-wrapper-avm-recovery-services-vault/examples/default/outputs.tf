output "resource_id" {
  value = module.recovery_services_vault.resource_id
}

output "name" {
  value = "rsv-avm-default-test-${random_string.suffix.result}"
}

output "resource" {
  value = module.recovery_services_vault.resource
}
