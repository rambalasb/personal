check "soft_delete_enabled" {
  assert {
    condition     = var.soft_delete_enabled
    error_message = "Recovery Services Vault has soft_delete_enabled = false. Soft delete protects against accidental or malicious deletion; keep it enabled unless you have a documented reason not to."
  }
}

check "immutability_set" {
  assert {
    condition     = var.immutability != "Disabled"
    error_message = "Recovery Services Vault immutability is 'Disabled'. Set 'Unlocked' (reversible) or 'Locked' (irreversible) for production-grade ransomware protection."
  }
}

check "private_endpoint_implies_no_public_access" {
  assert {
    condition     = !local.has_private_endpoints || !var.public_network_access_enabled
    error_message = "Private endpoints are configured but public_network_access_enabled = true. Disable public access when using private endpoints."
  }
}

check "geo_redundant_when_cross_region_restore_enabled" {
  assert {
    condition     = !var.cross_region_restore_enabled || var.storage_mode_type == "GeoRedundant"
    error_message = "cross_region_restore_enabled = true but storage_mode_type is '${var.storage_mode_type}'. Cross-region restore requires GeoRedundant storage."
  }
}

check "cmk_identity_present_in_managed_identities" {
  assert {
    condition     = !local.cmk_configured || try(var.customer_managed_key.user_assigned_identity, null) == null || contains(var.managed_identities.user_assigned_resource_ids, var.customer_managed_key.user_assigned_identity.resource_id)
    error_message = "CMK is configured but its user-assigned identity is not in managed_identities.user_assigned_resource_ids. Add it to avoid ManagedIdentityDetailsNotPresent errors."
  }
}

check "immutability_locked_for_production" {
  assert {
    condition     = var.immutability == "Locked"
    error_message = "Recovery Services Vault immutability is 'Unlocked'. For production vaults, set 'Locked' to make backup deletion irreversible — but note this is permanent."
  }
}
