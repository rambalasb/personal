# =====================================================================
# Required inputs
# =====================================================================

variable "name" {
  type        = string
  description = "Name of the Recovery Services Vault. 2-50 chars; upper/lowercase letters, numbers, and hyphens."

  validation {
    condition     = can(regex("^[a-zA-Z0-9-]{2,50}$", var.name))
    error_message = "name must be 2-50 characters, alphanumerics and hyphens only."
  }
}

variable "resource_group_name" {
  type        = string
  description = "Name of the Resource Group where the vault will be deployed."

  validation {
    condition     = length(var.resource_group_name) > 0 && length(var.resource_group_name) <= 90
    error_message = "resource_group_name must be 1-90 characters."
  }
}

variable "location" {
  type        = string
  description = "Azure region where the vault will be deployed."

  validation {
    condition     = length(var.location) > 0
    error_message = "location must not be empty."
  }
}

variable "sku" {
  type        = string
  description = "Vault SKU. 'Standard' or 'RS0'."

  validation {
    condition     = contains(["Standard", "RS0"], var.sku)
    error_message = "sku must be 'Standard' or 'RS0'."
  }
}

# =====================================================================
# Vault behavior — secure defaults
# =====================================================================

variable "storage_mode_type" {
  type        = string
  description = "Storage replication mode. 'GeoRedundant' (default), 'LocallyRedundant', or 'ZoneRedundant'. GeoRedundant is required for cross_region_restore_enabled."
  default     = "GeoRedundant"

  validation {
    condition     = contains(["GeoRedundant", "LocallyRedundant", "ZoneRedundant"], var.storage_mode_type)
    error_message = "storage_mode_type must be 'GeoRedundant', 'LocallyRedundant', or 'ZoneRedundant'."
  }
}

variable "cross_region_restore_enabled" {
  type        = bool
  description = "Whether cross-region restore is enabled. Requires storage_mode_type = 'GeoRedundant'."
  default     = true
}

variable "soft_delete_enabled" {
  type        = bool
  description = "Whether soft delete is enabled. Keep true for compliance (default)."
  default     = true
}

variable "immutability" {
  type        = string
  description = "Immutability setting. 'Locked' (irreversible), 'Unlocked' (reversible, default), or 'Disabled'. Locked vaults cannot be reverted — use only in production after testing."
  default     = "Unlocked"

  validation {
    condition     = contains(["Locked", "Unlocked", "Disabled"], var.immutability)
    error_message = "immutability must be 'Locked', 'Unlocked', or 'Disabled'."
  }
}

variable "public_network_access_enabled" {
  type        = bool
  description = "Whether public network access is enabled. Set false when using private endpoints."
  default     = true
}

# =====================================================================
# Monitoring alerts
# =====================================================================

variable "alerts_for_all_job_failures_enabled" {
  type        = bool
  description = "Whether to enable monitoring alerts for all job failures."
  default     = true
}

variable "alerts_for_critical_operation_failures_enabled" {
  type        = bool
  description = "Whether to enable monitoring alerts for critical operation failures."
  default     = true
}

# =====================================================================
# Backup policies
# =====================================================================

variable "vm_backup_policy" {
  type = map(object({
    name                           = string
    timezone                       = string
    instant_restore_retention_days = optional(number, null)
    instant_restore_resource_group = optional(map(object({
      prefix = optional(string, null)
      suffix = optional(string, null)
    })), {})
    policy_type     = string
    frequency       = string
    retention_daily = optional(number, null)
    backup = object({
      time          = string
      hour_interval = optional(number, null)
      hour_duration = optional(number, null)
      weekdays      = optional(list(string), [])
    })
    retention_weekly = optional(object({
      count    = optional(number, 7)
      weekdays = optional(list(string), [])
    }), {})
    retention_monthly = optional(object({
      count             = optional(number, 0)
      weekdays          = optional(list(string), [])
      weeks             = optional(list(string), [])
      days              = optional(list(number), [])
      include_last_days = optional(bool, false)
    }), {})
    retention_yearly = optional(object({
      count             = optional(number, 0)
      months            = optional(list(string), [])
      weekdays          = optional(list(string), [])
      weeks             = optional(list(string), [])
      days              = optional(list(number), [])
      include_last_days = optional(bool, false)
    }), {})
  }))
  description = "Map of VM backup policies. policy_type: 'V1' or 'V2' (V2 supports hourly + 30-day instant restore). frequency: 'Hourly', 'Daily', 'Weekly'."
  default     = null
}

variable "file_share_backup_policy" {
  type = map(object({
    name                       = string
    timezone                   = string
    frequency                  = string
    backup_tier                = optional(string, "snapshot")
    snapshot_retention_in_days = optional(number, 0)
    retention_daily            = optional(number, null)
    backup = object({
      time = string
      hourly = optional(object({
        interval        = number
        start_time      = string
        window_duration = number
      }))
    })
    retention_weekly = optional(object({
      count    = optional(number, 7)
      weekdays = optional(list(string), [])
    }), {})
    retention_monthly = optional(object({
      count             = optional(number, 0)
      weekdays          = optional(list(string), [])
      weeks             = optional(list(string), [])
      days              = optional(list(number), [])
      include_last_days = optional(bool, false)
    }), {})
    retention_yearly = optional(object({
      count             = optional(number, 0)
      months            = optional(list(string), [])
      weekdays          = optional(list(string), [])
      weeks             = optional(list(string), [])
      days              = optional(list(number), [])
      include_last_days = optional(bool, false)
    }), {})
  }))
  description = "Map of file share backup policies. backup_tier: 'snapshot' or 'vault-standard'. frequency: 'Daily' or 'Hourly'."
  default     = null
}

variable "workload_backup_policy" {
  type = map(object({
    name          = string
    workload_type = string
    settings = object({
      time_zone           = string
      compression_enabled = bool
    })
    backup_frequency = string
    protection_policy = map(object({
      policy_type           = string
      retention_daily_count = number
      retention_weekly = optional(object({
        count    = optional(number, null)
        weekdays = optional(set(string), null)
      }), null)
      backup = optional(object({
        time                 = optional(string)
        frequency_in_minutes = optional(number)
        weekdays             = optional(set(string))
      }), null)
      retention_monthly = optional(object({
        count             = optional(number, null)
        weekdays          = optional(set(string), null)
        weeks             = optional(set(string), null)
        monthdays         = optional(set(number), null)
        include_last_days = optional(bool, false)
      }), null)
      retention_yearly = optional(object({
        count             = optional(number, null)
        months            = optional(set(string), null)
        weekdays          = optional(set(string), null)
        weeks             = optional(set(string), null)
        monthdays         = optional(set(number), null)
        include_last_days = optional(bool, false)
      }), null)
    }))
  }))
  description = "Map of workload backup policies for SQL or SAP HANA databases. workload_type: 'SQLDataBase' or 'SAPHanaDatabase'. protection_policy entries: Full, Differential, Log."
  default     = null
}

# =====================================================================
# Protected items
# =====================================================================

variable "backup_protected_vm" {
  type = map(object({
    source_vm_id          = string
    vm_backup_policy_name = string
    sleep_timer           = optional(string, "60s")
  }))
  description = "Map of VMs to register with the vault for backup. vm_backup_policy_name must match a key in var.vm_backup_policy.*.name."
  default     = null

  validation {
    condition = var.backup_protected_vm == null || alltrue([
      for k, v in coalesce(var.backup_protected_vm, {}) :
      can(regex("^/subscriptions/[^/]+/resourceGroups/[^/]+/providers/Microsoft\\.Compute/virtualMachines/[^/]+$", v.source_vm_id))
    ])
    error_message = "Each backup_protected_vm.source_vm_id must be a Microsoft.Compute/virtualMachines resource ID."
  }
}

variable "backup_protected_file_share" {
  type = map(object({
    source_storage_account_id     = string
    backup_file_share_policy_name = string
    source_file_share_name        = string
    disable_registration          = optional(bool, false)
    sleep_timer                   = optional(string, "60s")
  }))
  description = "Map of file shares to register with the vault for backup. backup_file_share_policy_name must match a key in var.file_share_backup_policy.*.name."
  default     = null

  validation {
    condition = var.backup_protected_file_share == null || alltrue([
      for k, v in coalesce(var.backup_protected_file_share, {}) :
      can(regex("^/subscriptions/[^/]+/resourceGroups/[^/]+/providers/Microsoft\\.Storage/storageAccounts/[^/]+$", v.source_storage_account_id))
    ])
    error_message = "Each backup_protected_file_share.source_storage_account_id must be a Microsoft.Storage/storageAccounts resource ID."
  }
}

# =====================================================================
# Networking — private endpoints
# =====================================================================

variable "private_endpoints" {
  type = map(object({
    name = optional(string, null)
    role_assignments = optional(map(object({
      role_definition_id_or_name             = string
      principal_id                           = string
      description                            = optional(string, null)
      skip_service_principal_aad_check       = optional(bool, false)
      condition                              = optional(string, null)
      condition_version                      = optional(string, null)
      delegated_managed_identity_resource_id = optional(string, null)
      principal_type                         = optional(string, null)
    })), {})
    lock = optional(object({
      kind = string
      name = optional(string, null)
    }), null)
    tags                                    = optional(map(string), null)
    subnet_resource_id                      = string
    subresource_name                        = string
    private_dns_zone_group_name             = optional(string, "default")
    private_dns_zone_resource_ids           = optional(set(string), [])
    application_security_group_associations = optional(map(string), {})
    private_service_connection_name         = optional(string, null)
    network_interface_name                  = optional(string, null)
    location                                = optional(string, null)
    resource_group_name                     = optional(string, null)
    ip_configurations = optional(map(object({
      name               = string
      private_ip_address = string
    })), {})
  }))
  description = "Map of private endpoints. subresource_name should be 'AzureBackup' or 'AzureSiteRecovery'."
  default     = {}
}

variable "private_endpoints_manage_dns_zone_group" {
  type        = bool
  description = "Whether the module manages private DNS zone groups. Set false when DNS is managed externally (e.g. via Azure Policy)."
  default     = true
}

# =====================================================================
# Identity & encryption
# =====================================================================

variable "managed_identities" {
  type = object({
    system_assigned            = optional(bool, false)
    user_assigned_resource_ids = optional(set(string), [])
  })
  description = "Managed identity configuration. CMK requires a user-assigned identity present here."
  default     = {}
}

variable "customer_managed_key" {
  type = object({
    key_vault_resource_id = string
    key_name              = string
    key_version           = optional(string, null)
    user_assigned_identity = optional(object({
      resource_id = string
    }), null)
  })
  description = "Customer-managed key for vault encryption. user_assigned_identity is mandatory and must be included in var.managed_identities.user_assigned_resource_ids."
  default     = null

  validation {
    condition     = var.customer_managed_key == null || var.customer_managed_key.user_assigned_identity != null
    error_message = "customer_managed_key.user_assigned_identity is required (the Recovery Services API rejects CMK without an explicit identity)."
  }
}

# =====================================================================
# Governance & diagnostics
# =====================================================================

variable "role_assignments" {
  type = map(object({
    role_definition_id_or_name             = string
    principal_id                           = string
    description                            = optional(string, null)
    skip_service_principal_aad_check       = optional(bool, false)
    condition                              = optional(string, null)
    condition_version                      = optional(string, null)
    delegated_managed_identity_resource_id = optional(string, null)
    principal_type                         = optional(string, null)
  }))
  description = "RBAC role assignments scoped to the vault. Common roles: 'Backup Contributor', 'Backup Operator', 'Backup Reader'."
  default     = {}
}

variable "lock" {
  type = object({
    name = optional(string, null)
    kind = string
  })
  description = "Optional resource lock. kind must be 'CanNotDelete' or 'ReadOnly'."
  default     = null

  validation {
    condition     = var.lock == null || contains(["CanNotDelete", "ReadOnly"], try(var.lock.kind, ""))
    error_message = "lock.kind must be 'CanNotDelete' or 'ReadOnly' when set."
  }
}

variable "diagnostic_settings" {
  type = map(object({
    name                                     = optional(string, null)
    log_categories                           = optional(set(string), [])
    log_groups                               = optional(set(string), ["allLogs"])
    metric_categories                        = optional(set(string), ["AllMetrics"])
    log_analytics_destination_type           = optional(string, "Dedicated")
    workspace_resource_id                    = optional(string, null)
    storage_account_resource_id              = optional(string, null)
    event_hub_authorization_rule_resource_id = optional(string, null)
    event_hub_name                           = optional(string, null)
    marketplace_partner_resource_id          = optional(string, null)
  }))
  description = "Diagnostic settings for the vault. At least one destination required per entry."
  default     = {}
}

# =====================================================================
# Deprecated / no-op (retained for backward compatibility)
# =====================================================================

variable "classic_vmware_replication_enabled" {
  type        = bool
  description = "Deprecated upstream: has no effect in the AzAPI-based AVM module. Retained only for backward compatibility."
  default     = false
}

# =====================================================================
# Module behavior
# =====================================================================

variable "enable_telemetry" {
  type        = bool
  description = "Whether to enable AVM module telemetry. Set false to opt out."
  default     = true
}

variable "tags" {
  type        = map(string)
  description = "A map of tags to apply to the vault."
  default     = null
}

# =====================================================================
# Cross-input validation (Terraform >= 1.9)
# =====================================================================

variable "_validate_geo_redundant_required_for_cross_region_restore" {
  type        = bool
  description = "Internal sentinel — do not set."
  default     = true

  validation {
    condition     = !var.cross_region_restore_enabled || var.storage_mode_type == "GeoRedundant"
    error_message = "cross_region_restore_enabled = true requires storage_mode_type = 'GeoRedundant'."
  }
}

variable "_validate_cmk_identity_in_managed_identities" {
  type        = bool
  description = "Internal sentinel — do not set."
  default     = true

  validation {
    condition     = var.customer_managed_key == null || try(var.customer_managed_key.user_assigned_identity, null) == null || contains(var.managed_identities.user_assigned_resource_ids, var.customer_managed_key.user_assigned_identity.resource_id)
    error_message = "customer_managed_key.user_assigned_identity.resource_id must also be included in var.managed_identities.user_assigned_resource_ids."
  }
}
