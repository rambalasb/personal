locals {
  module_tags = merge(
    var.tags == null ? {} : var.tags,
    {
      managed-by = "terraform"
      module     = "tf-wrapper-avm-recovery-services-vault"
    }
  )

  has_private_endpoints = length(var.private_endpoints) > 0
  cmk_configured        = var.customer_managed_key != null
}
