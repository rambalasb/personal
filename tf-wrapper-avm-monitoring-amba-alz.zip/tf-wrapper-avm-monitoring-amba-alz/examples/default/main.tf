# Example: AMBA baseline + all 8 exported alerts through the one wrapper.
# Replace the locals below with real values before applying.

locals {
  subscription_id = "00000000-0000-0000-0000-000000000000"
  location        = "canadacentral"
  alerts_rg       = "rg-alerts-identity-canadacentral-001"
  siem_rg         = "rg-siem-identity-canadacentral-001"

  law_resource_id = "/subscriptions/${local.subscription_id}/resourceGroups/rg-siem-identity-canadacentral-001/providers/Microsoft.OperationalInsights/workspaces/law-identity"
  rsv_resource_id = "/subscriptions/${local.subscription_id}/resourceGroups/${local.siem_rg}/providers/Microsoft.RecoveryServices/vaults/rsv-identity-canadacentral-001"

  ag_mail       = "/subscriptions/${local.subscription_id}/resourceGroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actionGroups/ag-monitor-mail-alerts-canadacentral-001"
  ag_servicenow = "/subscriptions/${local.subscription_id}/resourceGroups/lga-servicenow-integration_group/providers/microsoft.insights/actionGroups/ag-servicenow-alerts-canadacentral-001"

  subscription_scope = "/subscriptions/${local.subscription_id}"
}

module "monitoring" {
  source = "../../"

  # AMBA baseline
  enable_amba                = true
  location                   = local.location
  root_management_group_name = "alz"

  tags = { environment = "prod" }

  # ── Metric alert ──
  metric_alerts = {
    backup = {
      name                     = "Backup Alert"
      resource_group_name      = local.siem_rg
      scopes                   = [local.rsv_resource_id]
      severity                 = 3
      frequency                = "PT15M"
      window_size              = "PT6H"
      target_resource_type     = "Microsoft.RecoveryServices/vaults"
      target_resource_location = local.location
      criteria = [{
        metric_namespace = "Microsoft.RecoveryServices/vaults"
        metric_name      = "BackupHealthEvent"
        aggregation      = "Count"
        operator         = "GreaterThan"
        threshold        = 0
      }]
      action_group_ids = [local.ag_mail]
    }
  }

  # ── Activity log alerts ──
  activity_log_alerts = {
    service_outage = {
      name                = "Service-Outage-Alert-canadacentral"
      resource_group_name = local.alerts_rg
      scopes              = [local.subscription_scope]
      location            = "global"
      description         = "Azure Landing Zone Service Health Alert"
      criteria = {
        category       = "ServiceHealth"
        service_health = { events = [], locations = ["Global"], services = [] }
      }
      action_group_ids = [local.ag_mail]
    }
    keyvault_deletion = {
      name                = "KeyVault-Deletion-Alert-canadacentral"
      resource_group_name = local.alerts_rg
      scopes              = [local.subscription_scope]
      location            = "global"
      description         = "This alert will monitor any deletion of key vault"
      criteria            = { category = "Administrative", operation_name = "Microsoft.KeyVault/vaults/delete" }
      action_group_ids    = [local.ag_servicenow]
    }
  }

  # ── Log search alerts ──
  log_search_alerts = {
    kv_secret_expired = {
      name                 = "KeyVault-Secret-Expired-Alert-canadacentral"
      resource_group_name  = local.alerts_rg
      location             = local.location
      scopes               = [local.law_resource_id]
      severity             = 0
      evaluation_frequency = "PT5M"
      window_duration      = "PT30M"
      criteria = [{
        query                   = "AzureDiagnostics\n| where ResourceProvider == \"MICROSOFT.KEYVAULT\"\n| where OperationName contains \"SecretExpired\""
        time_aggregation_method = "Count"
        threshold               = 1
        operator                = "GreaterThanOrEqual"
        resource_id_column      = "ResourceId"
        failing_periods         = { minimum_failing_periods_to_trigger_alert = 1, number_of_evaluation_periods = 1 }
      }]
      action_group_ids = [local.ag_servicenow]
    }
    kv_secret_near_expiry = {
      name                 = "KeyVault-Secret-Near-Expiry-Alert-canadacentral"
      resource_group_name  = local.alerts_rg
      location             = local.location
      scopes               = [local.law_resource_id]
      severity             = 1
      evaluation_frequency = "PT5M"
      window_duration      = "PT30M"
      criteria = [{
        query                   = "AzureDiagnostics\n| where ResourceProvider == \"MICROSOFT.KEYVAULT\"\n| where OperationName contains \"SecretNearExpiry\""
        time_aggregation_method = "Count"
        threshold               = 1
        operator                = "GreaterThanOrEqual"
        resource_id_column      = "ResourceId"
        failing_periods         = { minimum_failing_periods_to_trigger_alert = 1, number_of_evaluation_periods = 1 }
      }]
      action_group_ids = [local.ag_servicenow]
    }
    resource_creation = {
      name                 = "Resource-Creation-Alert-canadacentral"
      resource_group_name  = local.alerts_rg
      location             = local.location
      scopes               = [local.law_resource_id]
      severity             = 4
      evaluation_frequency = "PT10M"
      window_duration      = "PT30M"
      criteria = [{
        query                   = "AzureActivity\n| where OperationNameValue has \"Microsoft.Resources/deployments/write\"\n| where CategoryValue == \"Administrative\"\n| where ActivityStatusValue == \"Success\""
        time_aggregation_method = "Count"
        threshold               = 10
        operator                = "GreaterThanOrEqual"
        resource_id_column      = "_ResourceId"
        failing_periods         = { minimum_failing_periods_to_trigger_alert = 1, number_of_evaluation_periods = 1 }
      }]
      action_group_ids = [local.ag_servicenow]
    }
    storage_container_deletion = {
      name                 = "Storage-Account-Container-Deletion-Alert-canadacentral"
      resource_group_name  = local.alerts_rg
      location             = local.location
      scopes               = [local.law_resource_id]
      severity             = 0
      evaluation_frequency = "PT5M"
      window_duration      = "PT30M"
      criteria = [{
        query                   = "AzureActivity\n| where ResourceProviderValue == \"MICROSOFT.STORAGE\" and OperationNameValue == \"MICROSOFT.STORAGE/STORAGEACCOUNTS/BLOBSERVICES/CONTAINERS/DELETE\""
        time_aggregation_method = "Count"
        threshold               = 1
        operator                = "GreaterThanOrEqual"
        resource_id_column      = "_ResourceId"
        failing_periods         = { minimum_failing_periods_to_trigger_alert = 1, number_of_evaluation_periods = 1 }
      }]
      action_group_ids = [local.ag_servicenow]
    }
    storage_deletion = {
      name                 = "Storage-Account-Deletion-Alert-canadacentral"
      resource_group_name  = local.alerts_rg
      location             = local.location
      scopes               = [local.law_resource_id]
      severity             = 0
      evaluation_frequency = "PT5M"
      window_duration      = "PT30M"
      criteria = [{
        query                   = "AzureActivity\n| where ResourceProviderValue == \"MICROSOFT.STORAGE\" and OperationNameValue == \"MICROSOFT.STORAGE/STORAGEACCOUNTS/DELETE\""
        time_aggregation_method = "Count"
        threshold               = 1
        operator                = "GreaterThanOrEqual"
        resource_id_column      = "_ResourceId"
        failing_periods         = { minimum_failing_periods_to_trigger_alert = 1, number_of_evaluation_periods = 1 }
      }]
      action_group_ids = [local.ag_servicenow]
    }
  }
}
