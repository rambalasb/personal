# =====================================================================
# AMBA-ALZ baseline
# =====================================================================

variable "enable_amba" {
  type        = bool
  description = "Deploy the AMBA-ALZ baseline (health/service-health/resource metric alerts via Azure Policy across the MG hierarchy)."
  default     = true
}

variable "location" {
  type        = string
  description = "Azure region for the AMBA monitoring resources and any alerts that need a region."

  validation {
    condition     = length(var.location) > 0
    error_message = "location must not be empty."
  }
}

variable "root_management_group_name" {
  type        = string
  description = "Management group ID the AMBA policies assign to (the ALZ intermediate root). Required when enable_amba = true."
  default     = null

  validation {
    condition     = !var.enable_amba || try(length(var.root_management_group_name) > 0, false)
    error_message = "root_management_group_name is required when enable_amba = true."
  }
}

variable "resource_group_name" {
  type        = string
  description = "Resource group AMBA creates for its monitoring identity and assets."
  default     = "rg-amba-monitoring-001"
}

variable "user_assigned_managed_identity_name" {
  type        = string
  description = "Name of the user-assigned managed identity AMBA creates."
  default     = "id-amba-prod-001"

  validation {
    condition     = can(regex("^[a-zA-Z0-9-_]{3,128}$", var.user_assigned_managed_identity_name))
    error_message = "user_assigned_managed_identity_name must be 3-128 characters: letters, numbers, hyphens, underscores."
  }
}

variable "lock" {
  type = object({
    kind = string
    name = optional(string, null)
  })
  description = "Optional resource lock on the AMBA resources. kind must be 'CanNotDelete' or 'ReadOnly'."
  default     = null

  validation {
    condition     = var.lock == null || contains(["CanNotDelete", "ReadOnly"], try(var.lock.kind, ""))
    error_message = "lock.kind must be 'CanNotDelete' or 'ReadOnly' when set."
  }
}

variable "enable_telemetry" {
  type        = bool
  description = "Whether to enable AVM module telemetry. Set false to opt out."
  default     = true
}

# =====================================================================
# Built-in governance alerts
# Administrative / Security / Recommendation activity-log alerts AMBA does
# not emit. Enabled as a set; scope, action groups, and RG are supplied here.
# =====================================================================

variable "enable_governance_alerts" {
  type        = bool
  description = "Deploy the built-in Administrative / Security / Recommendation activity-log alert set alongside AMBA."
  default     = false
}

variable "governance_alert_scopes" {
  type        = list(string)
  description = "Scopes for the built-in governance alerts, typically [\"/subscriptions/<id>\"]. Required when enable_governance_alerts = true."
  default     = []
}

variable "governance_action_group_ids" {
  type        = list(string)
  description = "Action group resource IDs the built-in governance alerts route to."
  default     = []
}

variable "governance_resource_group_name" {
  type        = string
  description = "Resource group the built-in governance alerts are created in. Required when enable_governance_alerts = true."
  default     = null
}

# =====================================================================
# Tagging (shared by AMBA resources and alerts)
# =====================================================================

variable "tags" {
  type        = map(string)
  description = "Tags applied to the AMBA resources and every alert / action group."
  default     = {}
}

# =====================================================================
# Action groups
# Optional — alerts may also target existing action groups by ID via
# `action_group_ids` on each alert.
# =====================================================================

variable "action_groups" {
  type = map(object({
    name                = string
    resource_group_name = string
    short_name          = string
    enabled             = optional(bool, true)
    location            = optional(string, "global")
    email_receivers = optional(map(object({
      email_address           = string
      use_common_alert_schema = optional(bool, true)
    })), {})
    sms_receivers = optional(map(object({
      country_code = string
      phone_number = string
    })), {})
    webhook_receivers = optional(map(object({
      service_uri             = string
      use_common_alert_schema = optional(bool, true)
    })), {})
    arm_role_receivers = optional(map(object({
      role_id                 = string
      use_common_alert_schema = optional(bool, true)
    })), {})
    event_hub_receivers = optional(map(object({
      event_hub_namespace     = string
      event_hub_name          = string
      subscription_id         = optional(string)
      tenant_id               = optional(string)
      use_common_alert_schema = optional(bool, true)
    })), {})
    logic_app_receivers = optional(map(object({
      resource_id             = string
      callback_url            = string
      use_common_alert_schema = optional(bool, true)
    })), {})
    tags = optional(map(string), {})
  }))
  description = "Action groups to create, keyed by a logical name. Alerts reference these via action_group_keys. short_name must be 1-12 characters."
  default     = {}

  validation {
    condition     = alltrue([for ag in var.action_groups : length(ag.short_name) >= 1 && length(ag.short_name) <= 12])
    error_message = "action_groups short_name must be 1-12 characters."
  }
}

variable "default_action_group_keys" {
  type        = list(string)
  description = "Keys into var.action_groups attached to every alert."
  default     = []
}

variable "default_action_group_ids" {
  type        = list(string)
  description = "Resource IDs of existing action groups attached to every alert."
  default     = []
}

# =====================================================================
# Metric alerts -> azurerm_monitor_metric_alert
# =====================================================================

variable "metric_alerts" {
  type = map(object({
    name                     = string
    resource_group_name      = string
    scopes                   = list(string)
    description              = optional(string)
    enabled                  = optional(bool, true)
    auto_mitigate            = optional(bool, true)
    frequency                = optional(string, "PT1M")
    window_size              = optional(string, "PT5M")
    severity                 = optional(number, 3)
    target_resource_type     = optional(string)
    target_resource_location = optional(string)
    criteria = optional(list(object({
      metric_namespace       = string
      metric_name            = string
      aggregation            = string
      operator               = string
      threshold              = number
      skip_metric_validation = optional(bool, false)
      dimensions = optional(list(object({
        name     = string
        operator = string
        values   = list(string)
      })), [])
    })), [])
    dynamic_criteria = optional(object({
      metric_namespace         = string
      metric_name              = string
      aggregation              = string
      operator                 = string
      alert_sensitivity        = string
      evaluation_total_count   = optional(number)
      evaluation_failure_count = optional(number)
      ignore_data_before       = optional(string)
      skip_metric_validation   = optional(bool, false)
      dimensions = optional(list(object({
        name     = string
        operator = string
        values   = list(string)
      })), [])
    }))
    action_group_ids   = optional(list(string), [])
    action_group_keys  = optional(list(string), [])
    webhook_properties = optional(map(string), {})
    tags               = optional(map(string), {})
  }))
  description = "Metric alerts, keyed by logical name. Set exactly one of criteria (static) or dynamic_criteria (ML-based)."
  default     = {}

  validation {
    condition     = alltrue([for a in var.metric_alerts : a.severity >= 0 && a.severity <= 4])
    error_message = "metric_alerts severity must be between 0 and 4."
  }

  validation {
    condition     = alltrue([for a in var.metric_alerts : (length(a.criteria) > 0) != (a.dynamic_criteria != null)])
    error_message = "Each metric alert must set exactly one of criteria or dynamic_criteria."
  }
}

# =====================================================================
# Activity log alerts -> azurerm_monitor_activity_log_alert
# =====================================================================

variable "activity_log_alerts" {
  type = map(object({
    name                = string
    resource_group_name = string
    scopes              = list(string)
    location            = optional(string, "global")
    description         = optional(string)
    enabled             = optional(bool, true)
    criteria = object({
      category                = string
      operation_name          = optional(string)
      resource_provider       = optional(string)
      resource_type           = optional(string)
      resource_group          = optional(string)
      resource_id             = optional(string)
      caller                  = optional(string)
      level                   = optional(string)
      status                  = optional(string)
      sub_status              = optional(string)
      recommendation_category = optional(string) # Recommendation category alerts
      recommendation_impact   = optional(string)
      recommendation_type     = optional(string)
      service_health = optional(object({
        events    = optional(list(string))
        locations = optional(list(string))
        services  = optional(list(string))
      }))
      resource_health = optional(object({
        current  = optional(list(string))
        previous = optional(list(string))
        reason   = optional(list(string))
      }))
    })
    action_group_ids   = optional(list(string), [])
    action_group_keys  = optional(list(string), [])
    webhook_properties = optional(map(string), {})
    tags               = optional(map(string), {})
  }))
  description = "Activity log alerts, keyed by logical name. criteria.category is one of Administrative, ServiceHealth, ResourceHealth, Autoscale, Security, Recommendation, Policy. recommendation_* apply only when category = Recommendation."
  default     = {}
}

# =====================================================================
# Log search alerts -> azurerm_monitor_scheduled_query_rules_alert_v2
# =====================================================================

variable "log_search_alerts" {
  type = map(object({
    name                              = string
    resource_group_name               = string
    location                          = string
    scopes                            = list(string)
    severity                          = optional(number, 3)
    evaluation_frequency              = optional(string, "PT5M")
    window_duration                   = optional(string, "PT5M")
    description                       = optional(string)
    display_name                      = optional(string)
    enabled                           = optional(bool, true)
    auto_mitigation_enabled           = optional(bool, false)
    skip_query_validation             = optional(bool, false)
    mute_actions_after_alert_duration = optional(string)
    query_time_range_override         = optional(string)
    target_resource_types             = optional(list(string))
    criteria = list(object({
      query                   = string
      time_aggregation_method = string
      threshold               = number
      operator                = string
      resource_id_column      = optional(string)
      metric_measure_column   = optional(string)
      dimensions = optional(list(object({
        name     = string
        operator = string
        values   = list(string)
      })), [])
      failing_periods = optional(object({
        minimum_failing_periods_to_trigger_alert = number
        number_of_evaluation_periods             = number
      }))
    }))
    action_group_ids  = optional(list(string), [])
    action_group_keys = optional(list(string), [])
    custom_properties = optional(map(string), {})
    tags              = optional(map(string), {})
  }))
  description = "Log search alerts (scheduled query rules v2), keyed by logical name. scopes is typically a Log Analytics workspace or Application Insights resource ID."
  default     = {}

  validation {
    condition     = alltrue([for a in var.log_search_alerts : a.severity >= 0 && a.severity <= 4])
    error_message = "log_search_alerts severity must be between 0 and 4."
  }
}
