locals {
  module_tags = merge(
    var.tags == null ? {} : var.tags,
    {
      managed-by = "terraform"
      module     = "tf-wrapper-avm-monitoring-amba-alz"
    }
  )

  # Built-in governance alert set (categories AMBA does not emit). Deployed as
  # azurerm_monitor_activity_log_alert.governance when enable_governance_alerts.
  governance_alerts = var.enable_governance_alerts ? {
    role_assignment_write = {
      name                  = "Admin-RoleAssignment-Write-Alert"
      description           = "A role assignment was created or updated."
      category              = "Administrative"
      operation_name        = "Microsoft.Authorization/roleAssignments/write"
      level                 = null
      recommendation_impact = null
    }
    policy_assignment_delete = {
      name                  = "Admin-PolicyAssignment-Delete-Alert"
      description           = "A policy assignment was deleted."
      category              = "Administrative"
      operation_name        = "Microsoft.Authorization/policyAssignments/delete"
      level                 = null
      recommendation_impact = null
    }
    security_critical = {
      name                  = "Security-Critical-Alert"
      description           = "Critical security events surfaced in the activity log."
      category              = "Security"
      operation_name        = null
      level                 = "Critical"
      recommendation_impact = null
    }
    advisor_high_impact = {
      name                  = "Advisor-HighImpact-Recommendation-Alert"
      description           = "High-impact Azure Advisor recommendations."
      category              = "Recommendation"
      operation_name        = null
      level                 = null
      recommendation_impact = "High"
    }
  } : {}

  # IDs of action groups created by this module, keyed by logical name.
  created_action_group_ids = { for k, ag in azurerm_monitor_action_group.this : k => ag.id }

  # Module-wide defaults attached to every alert.
  default_action_group_ids = concat(
    var.default_action_group_ids,
    [for key in var.default_action_group_keys : local.created_action_group_ids[key]]
  )

  # Per-alert action group IDs = module defaults + explicit external IDs + keys
  # resolved against the action groups this module creates.
  metric_alert_action_group_ids = {
    for k, a in var.metric_alerts : k => distinct(concat(
      local.default_action_group_ids,
      a.action_group_ids,
      [for key in a.action_group_keys : local.created_action_group_ids[key]]
    ))
  }
  activity_log_alert_action_group_ids = {
    for k, a in var.activity_log_alerts : k => distinct(concat(
      local.default_action_group_ids,
      a.action_group_ids,
      [for key in a.action_group_keys : local.created_action_group_ids[key]]
    ))
  }
  log_search_alert_action_group_ids = {
    for k, a in var.log_search_alerts : k => distinct(concat(
      local.default_action_group_ids,
      a.action_group_ids,
      [for key in a.action_group_keys : local.created_action_group_ids[key]]
    ))
  }
}
