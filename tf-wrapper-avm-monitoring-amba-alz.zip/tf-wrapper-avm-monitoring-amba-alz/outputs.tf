# AMBA baseline outputs (null when enable_amba = false)
output "amba_resource_group_name" {
  description = "The AMBA monitoring resource group name."
  value       = one(module.amba[*].resource_group_name)
}

output "amba_resource_id" {
  description = "The resource ID of the AMBA monitoring resource group."
  value       = one(module.amba[*].resource_id)
}

output "amba_user_assigned_managed_identity_resource_id" {
  description = "The resource ID of the AMBA user-assigned managed identity."
  value       = one(module.amba[*].user_assigned_managed_identity_resource_id)
}

# Alert outputs
output "metric_alert_ids" {
  description = "Metric alert resource IDs, keyed by logical name."
  value       = { for k, a in azurerm_monitor_metric_alert.this : k => a.id }
}

output "activity_log_alert_ids" {
  description = "Activity log alert resource IDs, keyed by logical name."
  value       = { for k, a in azurerm_monitor_activity_log_alert.this : k => a.id }
}

output "log_search_alert_ids" {
  description = "Log search alert resource IDs, keyed by logical name."
  value       = { for k, a in azurerm_monitor_scheduled_query_rules_alert_v2.this : k => a.id }
}

output "governance_alert_ids" {
  description = "Built-in governance alert resource IDs, keyed by logical name."
  value       = { for k, a in azurerm_monitor_activity_log_alert.governance : k => a.id }
}

output "action_group_ids" {
  description = "IDs of action groups created by this module, keyed by logical name."
  value       = local.created_action_group_ids
}
