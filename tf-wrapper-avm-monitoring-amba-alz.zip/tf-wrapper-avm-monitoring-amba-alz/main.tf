# AMBA-ALZ baseline — health, service-health, and resource metric alerts rolled
# out via Azure Policy (DINE) across the management-group hierarchy, plus the
# monitoring resource group, user-assigned identity, and Monitoring Reader role.
module "amba" {
  count = var.enable_amba ? 1 : 0

  source  = "Azure/avm-ptn-monitoring-amba-alz/azurerm"
  version = "0.4.0"

  location                            = var.location
  root_management_group_name          = var.root_management_group_name
  resource_group_name                 = var.resource_group_name
  user_assigned_managed_identity_name = var.user_assigned_managed_identity_name
  lock                                = var.lock
  enable_telemetry                    = var.enable_telemetry
  tags                                = var.tags
}

# Action groups — optional; alerts can also target pre-existing groups by ID.
resource "azurerm_monitor_action_group" "this" {
  for_each = var.action_groups

  name                = each.value.name
  resource_group_name = each.value.resource_group_name
  short_name          = each.value.short_name
  enabled             = each.value.enabled
  tags                = merge(local.module_tags, each.value.tags)

  dynamic "email_receiver" {
    for_each = each.value.email_receivers
    content {
      name                    = email_receiver.key
      email_address           = email_receiver.value.email_address
      use_common_alert_schema = email_receiver.value.use_common_alert_schema
    }
  }

  dynamic "sms_receiver" {
    for_each = each.value.sms_receivers
    content {
      name         = sms_receiver.key
      country_code = sms_receiver.value.country_code
      phone_number = sms_receiver.value.phone_number
    }
  }

  dynamic "webhook_receiver" {
    for_each = each.value.webhook_receivers
    content {
      name                    = webhook_receiver.key
      service_uri             = webhook_receiver.value.service_uri
      use_common_alert_schema = webhook_receiver.value.use_common_alert_schema
    }
  }

  dynamic "arm_role_receiver" {
    for_each = each.value.arm_role_receivers
    content {
      name                    = arm_role_receiver.key
      role_id                 = arm_role_receiver.value.role_id
      use_common_alert_schema = arm_role_receiver.value.use_common_alert_schema
    }
  }

  dynamic "event_hub_receiver" {
    for_each = each.value.event_hub_receivers
    content {
      name                    = event_hub_receiver.key
      event_hub_namespace     = event_hub_receiver.value.event_hub_namespace
      event_hub_name          = event_hub_receiver.value.event_hub_name
      subscription_id         = event_hub_receiver.value.subscription_id
      tenant_id               = event_hub_receiver.value.tenant_id
      use_common_alert_schema = event_hub_receiver.value.use_common_alert_schema
    }
  }

  dynamic "logic_app_receiver" {
    for_each = each.value.logic_app_receivers
    content {
      name                    = logic_app_receiver.key
      resource_id             = logic_app_receiver.value.resource_id
      callback_url            = logic_app_receiver.value.callback_url
      use_common_alert_schema = logic_app_receiver.value.use_common_alert_schema
    }
  }
}

# Metric alerts — static-threshold alerts on platform/resource metrics.
resource "azurerm_monitor_metric_alert" "this" {
  for_each = var.metric_alerts

  name                     = each.value.name
  resource_group_name      = each.value.resource_group_name
  scopes                   = each.value.scopes
  description              = each.value.description
  enabled                  = each.value.enabled
  auto_mitigate            = each.value.auto_mitigate
  frequency                = each.value.frequency
  window_size              = each.value.window_size
  severity                 = each.value.severity
  target_resource_type     = each.value.target_resource_type
  target_resource_location = each.value.target_resource_location
  tags                     = merge(local.module_tags, each.value.tags)

  dynamic "criteria" {
    for_each = each.value.criteria
    content {
      metric_namespace       = criteria.value.metric_namespace
      metric_name            = criteria.value.metric_name
      aggregation            = criteria.value.aggregation
      operator               = criteria.value.operator
      threshold              = criteria.value.threshold
      skip_metric_validation = criteria.value.skip_metric_validation

      dynamic "dimension" {
        for_each = criteria.value.dimensions
        content {
          name     = dimension.value.name
          operator = dimension.value.operator
          values   = dimension.value.values
        }
      }
    }
  }

  dynamic "dynamic_criteria" {
    for_each = each.value.dynamic_criteria == null ? [] : [each.value.dynamic_criteria]
    content {
      metric_namespace         = dynamic_criteria.value.metric_namespace
      metric_name              = dynamic_criteria.value.metric_name
      aggregation              = dynamic_criteria.value.aggregation
      operator                 = dynamic_criteria.value.operator
      alert_sensitivity        = dynamic_criteria.value.alert_sensitivity
      evaluation_total_count   = dynamic_criteria.value.evaluation_total_count
      evaluation_failure_count = dynamic_criteria.value.evaluation_failure_count
      ignore_data_before       = dynamic_criteria.value.ignore_data_before
      skip_metric_validation   = dynamic_criteria.value.skip_metric_validation

      dynamic "dimension" {
        for_each = dynamic_criteria.value.dimensions
        content {
          name     = dimension.value.name
          operator = dimension.value.operator
          values   = dimension.value.values
        }
      }
    }
  }

  dynamic "action" {
    for_each = local.metric_alert_action_group_ids[each.key]
    content {
      action_group_id    = action.value
      webhook_properties = each.value.webhook_properties
    }
  }
}

# Activity log alerts — fire on control-plane / service-health events.
resource "azurerm_monitor_activity_log_alert" "this" {
  for_each = var.activity_log_alerts

  name                = each.value.name
  resource_group_name = each.value.resource_group_name
  scopes              = each.value.scopes
  location            = each.value.location
  description         = each.value.description
  enabled             = each.value.enabled
  tags                = merge(local.module_tags, each.value.tags)

  criteria {
    category                = each.value.criteria.category
    operation_name          = each.value.criteria.operation_name
    resource_provider       = each.value.criteria.resource_provider
    resource_type           = each.value.criteria.resource_type
    resource_group          = each.value.criteria.resource_group
    resource_id             = each.value.criteria.resource_id
    caller                  = each.value.criteria.caller
    level                   = each.value.criteria.level
    status                  = each.value.criteria.status
    sub_status              = each.value.criteria.sub_status
    recommendation_category = each.value.criteria.recommendation_category
    recommendation_impact   = each.value.criteria.recommendation_impact
    recommendation_type     = each.value.criteria.recommendation_type

    dynamic "service_health" {
      for_each = each.value.criteria.service_health == null ? [] : [each.value.criteria.service_health]
      content {
        events    = service_health.value.events
        locations = service_health.value.locations
        services  = service_health.value.services
      }
    }

    dynamic "resource_health" {
      for_each = each.value.criteria.resource_health == null ? [] : [each.value.criteria.resource_health]
      content {
        current  = resource_health.value.current
        previous = resource_health.value.previous
        reason   = resource_health.value.reason
      }
    }
  }

  dynamic "action" {
    for_each = local.activity_log_alert_action_group_ids[each.key]
    content {
      action_group_id    = action.value
      webhook_properties = each.value.webhook_properties
    }
  }
}

# Built-in governance alerts — Administrative / Security / Recommendation.
resource "azurerm_monitor_activity_log_alert" "governance" {
  for_each = local.governance_alerts

  name                = each.value.name
  resource_group_name = var.governance_resource_group_name
  scopes              = var.governance_alert_scopes
  location            = "global"
  description         = each.value.description
  tags                = local.module_tags

  criteria {
    category              = each.value.category
    operation_name        = each.value.operation_name
    level                 = each.value.level
    recommendation_impact = each.value.recommendation_impact
  }

  dynamic "action" {
    for_each = var.governance_action_group_ids
    content {
      action_group_id = action.value
    }
  }
}

# Log search alerts — scheduled KQL queries against a workspace / App Insights.
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "this" {
  for_each = var.log_search_alerts

  name                              = each.value.name
  resource_group_name               = each.value.resource_group_name
  location                          = each.value.location
  scopes                            = each.value.scopes
  severity                          = each.value.severity
  evaluation_frequency              = each.value.evaluation_frequency
  window_duration                   = each.value.window_duration
  description                       = each.value.description
  display_name                      = each.value.display_name
  enabled                           = each.value.enabled
  auto_mitigation_enabled           = each.value.auto_mitigation_enabled
  skip_query_validation             = each.value.skip_query_validation
  mute_actions_after_alert_duration = each.value.mute_actions_after_alert_duration
  query_time_range_override         = each.value.query_time_range_override
  target_resource_types             = each.value.target_resource_types
  tags                              = merge(local.module_tags, each.value.tags)

  dynamic "criteria" {
    for_each = each.value.criteria
    content {
      query                   = criteria.value.query
      time_aggregation_method = criteria.value.time_aggregation_method
      threshold               = criteria.value.threshold
      operator                = criteria.value.operator
      resource_id_column      = criteria.value.resource_id_column
      metric_measure_column   = criteria.value.metric_measure_column

      dynamic "dimension" {
        for_each = criteria.value.dimensions
        content {
          name     = dimension.value.name
          operator = dimension.value.operator
          values   = dimension.value.values
        }
      }

      dynamic "failing_periods" {
        for_each = criteria.value.failing_periods == null ? [] : [criteria.value.failing_periods]
        content {
          minimum_failing_periods_to_trigger_alert = failing_periods.value.minimum_failing_periods_to_trigger_alert
          number_of_evaluation_periods             = failing_periods.value.number_of_evaluation_periods
        }
      }
    }
  }

  dynamic "action" {
    for_each = length(local.log_search_alert_action_group_ids[each.key]) > 0 ? [1] : []
    content {
      action_groups     = local.log_search_alert_action_group_ids[each.key]
      custom_properties = each.value.custom_properties
    }
  }
}
