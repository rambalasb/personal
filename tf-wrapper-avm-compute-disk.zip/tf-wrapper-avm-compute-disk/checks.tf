check "encryption_configured" {
  assert {
    condition     = local.cmk_configured
    error_message = "Disk has no customer-managed encryption configured. Supply one of: customer_managed_key, disk_encryption_set_id, secure_vm_disk_encryption_set_id, or encryption_settings (ADE). Platform-managed-key encryption still applies by default."
  }
}

check "network_access_not_allow_all" {
  assert {
    condition     = var.network_access_policy != "AllowAll"
    error_message = "Disk network_access_policy is 'AllowAll'. Prefer 'AllowPrivate' (with disk_access_id + private endpoints) or 'DenyAll'."
  }
}

check "public_network_access_disabled" {
  assert {
    condition     = !var.public_network_access_enabled
    error_message = "Disk public_network_access_enabled is true. Disable unless explicitly required for import/upload scenarios."
  }
}

check "private_endpoint_requires_disk_access" {
  assert {
    condition     = !local.has_private_endpoints || var.disk_access_id != null
    error_message = "Private endpoints are configured but disk_access_id is null. Disks require a Disk Access resource to terminate private endpoints — supply disk_access_id."
  }
}

check "trusted_launch_recommended_for_os_disks" {
  assert {
    condition     = var.os_type == null || var.trusted_launch_enabled == true || var.security_type != null
    error_message = "Disk is OS-typed (os_type = '${coalesce(var.os_type, "n/a")}') but neither Trusted Launch nor a Confidential VM security_type is enabled. Enable trusted_launch_enabled = true for non-Confidential OS disks."
  }
}

check "confidential_vm_requires_secure_encryption_set" {
  assert {
    condition     = var.security_type == null || var.security_type != "ConfidentialVM_DiskEncryptedWithCustomerKey" || var.secure_vm_disk_encryption_set_id != null
    error_message = "security_type = 'ConfidentialVM_DiskEncryptedWithCustomerKey' requires secure_vm_disk_encryption_set_id to be set."
  }
}
