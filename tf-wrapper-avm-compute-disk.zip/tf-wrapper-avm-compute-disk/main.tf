module "compute_disk" {
  source  = "Azure/avm-res-compute-disk/azurerm"
  version = "0.3.2"

  # Required
  name                 = var.name
  resource_group_name  = var.resource_group_name
  location             = var.location
  create_option        = var.create_option
  storage_account_type = var.storage_account_type
  zone                 = var.zone

  # Size & performance
  disk_size_gb                      = var.disk_size_gb
  disk_iops_read_only               = var.disk_iops_read_only
  disk_iops_read_write              = var.disk_iops_read_write
  disk_mbps_read_only               = var.disk_mbps_read_only
  disk_mbps_read_write              = var.disk_mbps_read_write
  tier                              = var.tier
  on_demand_bursting_enabled        = var.on_demand_bursting_enabled
  performance_plus_enabled          = var.performance_plus_enabled
  max_shares                        = var.max_shares
  logical_sector_size               = var.logical_sector_size
  optimized_frequent_attach_enabled = var.optimized_frequent_attach_enabled

  # Source / image
  source_resource_id         = var.source_resource_id
  source_uri                 = var.source_uri
  storage_account_id         = var.storage_account_id
  gallery_image_reference_id = var.gallery_image_reference_id
  image_reference_id         = var.image_reference_id
  hyper_v_generation         = var.hyper_v_generation
  upload_size_bytes          = var.upload_size_bytes
  os_type                    = var.os_type

  # Security & encryption
  disk_encryption_set_id           = var.disk_encryption_set_id
  secure_vm_disk_encryption_set_id = var.secure_vm_disk_encryption_set_id
  customer_managed_key             = var.customer_managed_key
  encryption_settings              = var.encryption_settings
  security_type                    = var.security_type
  trusted_launch_enabled           = var.trusted_launch_enabled

  # Network access
  network_access_policy                   = var.network_access_policy
  public_network_access_enabled           = var.public_network_access_enabled
  disk_access_id                          = var.disk_access_id
  private_endpoints                       = var.private_endpoints
  private_endpoints_manage_dns_zone_group = var.private_endpoints_manage_dns_zone_group

  # Governance
  role_assignments = var.role_assignments
  lock             = var.lock

  # Module behavior
  edge_zone        = var.edge_zone
  enable_telemetry = var.enable_telemetry
  tags             = local.module_tags
}
