output "resource_id" {
  value = module.compute_disk.resource_id
}

output "resource_group_name" {
  value = module.compute_disk.resource_group_name
}

output "location" {
  value = module.compute_disk.location
}
