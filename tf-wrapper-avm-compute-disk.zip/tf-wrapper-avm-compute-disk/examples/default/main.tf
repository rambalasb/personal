module "compute_disk" {
  source = "../.."

  name                 = "disk-avm-default-test-${random_string.suffix.result}"
  resource_group_name  = azurerm_resource_group.this.name
  location             = azurerm_resource_group.this.location
  create_option        = "Empty"
  storage_account_type = "Standard_LRS"
  zone                 = "1"
  disk_size_gb         = 32

  enable_telemetry = false
}
