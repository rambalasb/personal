output "resource_id" {
  description = "The Azure resource ID of the managed disk."
  value       = module.compute_disk.resource_id
}

output "resource" {
  description = "The full azurerm_managed_disk resource object."
  value       = module.compute_disk.resource
}

output "resource_group_name" {
  description = "The Resource Group hosting the disk."
  value       = module.compute_disk.resource_group_name
}

output "location" {
  description = "The Azure region of the disk."
  value       = module.compute_disk.location
}

output "private_endpoints" {
  description = "Map of private endpoints attached to the disk."
  value       = module.compute_disk.private_endpoints
}
