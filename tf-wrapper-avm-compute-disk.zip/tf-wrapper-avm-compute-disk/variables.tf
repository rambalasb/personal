# =====================================================================
# Required inputs
# =====================================================================

variable "name" {
  type        = string
  description = "Name of the managed disk. 1-80 chars; must start with a letter/number, end with a letter/number/underscore, contain only letters/numbers/underscores/periods/hyphens."

  validation {
    condition     = can(regex("^[A-Za-z0-9][A-Za-z0-9_.-]{0,78}[A-Za-z0-9_]$", var.name))
    error_message = "name must be 1-80 characters, start with alphanumeric, end with alphanumeric or underscore, and contain only alphanumerics/underscores/periods/hyphens."
  }
}

variable "resource_group_name" {
  type        = string
  description = "Name of the Resource Group where the disk will be deployed."

  validation {
    condition     = length(var.resource_group_name) > 0 && length(var.resource_group_name) <= 90
    error_message = "resource_group_name must be 1-90 characters."
  }
}

variable "location" {
  type        = string
  description = "Azure region where the disk will be deployed."

  validation {
    condition     = length(var.location) > 0
    error_message = "location must not be empty."
  }
}

variable "create_option" {
  type        = string
  description = "Method used to create the managed disk. Common values: 'Empty' (new blank disk), 'FromImage' (copy from platform/gallery image), 'Copy' (clone a disk/snapshot), 'Import' (import a VHD), 'Restore' (recover from backup), 'Upload' (upload a VHD via SAS)."

  validation {
    condition     = contains(["Attach", "Copy", "CopyStart", "Empty", "FromImage", "Import", "ImportSecure", "Restore", "Upload", "UploadPreparedSecure"], var.create_option)
    error_message = "create_option must be one of: 'Attach', 'Copy', 'CopyStart', 'Empty', 'FromImage', 'Import', 'ImportSecure', 'Restore', 'Upload', 'UploadPreparedSecure'."
  }
}

variable "storage_account_type" {
  type        = string
  description = "Disk storage SKU. 'Standard_LRS', 'StandardSSD_LRS', 'StandardSSD_ZRS', 'Premium_LRS', 'Premium_ZRS', 'PremiumV2_LRS', or 'UltraSSD_LRS'."

  validation {
    condition     = contains(["Standard_LRS", "StandardSSD_ZRS", "Premium_LRS", "PremiumV2_LRS", "Premium_ZRS", "StandardSSD_LRS", "UltraSSD_LRS"], var.storage_account_type)
    error_message = "storage_account_type must be one of: 'Standard_LRS', 'StandardSSD_LRS', 'StandardSSD_ZRS', 'Premium_LRS', 'Premium_ZRS', 'PremiumV2_LRS', 'UltraSSD_LRS'."
  }
}

variable "zone" {
  type        = string
  description = "Availability Zone for the disk. Set to null when deploying to a region without zones."

  validation {
    condition     = var.zone == null || contains(["1", "2", "3"], coalesce(var.zone, "0"))
    error_message = "zone must be '1', '2', '3', or null."
  }
}

# =====================================================================
# Size & performance
# =====================================================================

variable "disk_size_gb" {
  type        = number
  description = "Size of the disk in GiB. Required for new disks; must be >= source size for Copy/FromImage."
  default     = null

  validation {
    condition     = var.disk_size_gb == null ? true : (var.disk_size_gb >= 1 && var.disk_size_gb <= 65536)
    error_message = "disk_size_gb must be between 1 and 65536, or null."
  }
}

variable "disk_iops_read_only" {
  type        = number
  description = "IOPS for read-only operations across shared disk mounts. UltraSSD / PremiumV2 with max_shares > 1 only."
  default     = null
}

variable "disk_iops_read_write" {
  type        = number
  description = "IOPS for this disk. UltraSSD / PremiumV2 only."
  default     = null
}

variable "disk_mbps_read_only" {
  type        = number
  description = "Throughput in MB/s for read-only operations across shared disk mounts. UltraSSD / PremiumV2 with max_shares > 1 only."
  default     = null
}

variable "disk_mbps_read_write" {
  type        = number
  description = "Throughput in MB/s for this disk. UltraSSD / PremiumV2 only."
  default     = null
}

variable "tier" {
  type        = string
  description = "Performance tier for Premium SSDs (e.g. P30, P40). See Azure docs for valid values."
  default     = null
}

variable "on_demand_bursting_enabled" {
  type        = bool
  description = "Whether On-Demand Bursting is enabled. Premium SSDs only."
  default     = null
}

variable "performance_plus_enabled" {
  type        = bool
  description = "Whether Performance Plus is enabled. UltraSSD only. Changing this forces a new resource."
  default     = null
}

variable "max_shares" {
  type        = number
  description = "Max VMs that can attach this disk simultaneously (shared disk). Premium SSD / UltraSSD only."
  default     = null
}

variable "logical_sector_size" {
  type        = number
  description = "Logical sector size in bytes. 512 or 4096 (default). UltraSSD / PremiumV2 only."
  default     = null

  validation {
    condition     = var.logical_sector_size == null || contains([512, 4096], coalesce(var.logical_sector_size, 4096))
    error_message = "logical_sector_size must be 512 or 4096, or null."
  }
}

variable "optimized_frequent_attach_enabled" {
  type        = bool
  description = "Optimize for frequent attach/detach (>5/day). May break fault-domain alignment with the VM."
  default     = null
}

# =====================================================================
# Source / image (used when create_option != Empty)
# =====================================================================

variable "source_resource_id" {
  type        = string
  description = "Source disk/snapshot/recovery point resource ID. Required for Copy/Restore."
  default     = null
}

variable "source_uri" {
  type        = string
  description = "VHD source URI. Required for Import/ImportSecure."
  default     = null
}

variable "storage_account_id" {
  type        = string
  description = "Storage Account holding the source VHD. Required when create_option is Import/ImportSecure."
  default     = null
}

variable "gallery_image_reference_id" {
  type        = string
  description = "Gallery Image Version ID for FromImage. Mutually exclusive with image_reference_id."
  default     = null
}

variable "image_reference_id" {
  type        = string
  description = "Platform / marketplace image ID for FromImage. Mutually exclusive with gallery_image_reference_id."
  default     = null
}

variable "hyper_v_generation" {
  type        = string
  description = "Hyper-V generation. 'V1' or 'V2'. 'V2' required for ImportSecure."
  default     = null

  validation {
    condition     = var.hyper_v_generation == null || contains(["V1", "V2"], coalesce(var.hyper_v_generation, "V1"))
    error_message = "hyper_v_generation must be 'V1' or 'V2', or null."
  }
}

variable "upload_size_bytes" {
  type        = number
  description = "Size in bytes for Upload create_option. Must equal the source VHD size."
  default     = null
}

variable "os_type" {
  type        = string
  description = "OS contained in the source (for Import/ImportSecure/Copy). 'Linux' or 'Windows'."
  default     = null

  validation {
    condition     = var.os_type == null || contains(["Linux", "Windows"], coalesce(var.os_type, "Linux"))
    error_message = "os_type must be 'Linux' or 'Windows', or null."
  }
}

# =====================================================================
# Security & encryption
# =====================================================================

variable "disk_encryption_set_id" {
  type        = string
  description = "Disk Encryption Set ID for CMK-at-rest. Conflicts with secure_vm_disk_encryption_set_id."
  default     = null
}

variable "secure_vm_disk_encryption_set_id" {
  type        = string
  description = "Disk Encryption Set ID for Confidential VM. Conflicts with disk_encryption_set_id."
  default     = null
}

variable "customer_managed_key" {
  type = object({
    key_vault_resource_id = string
    key_name              = string
    key_version           = optional(string, null)
    user_assigned_identity = optional(object({
      resource_id = string
    }), null)
  })
  description = "Customer-managed key reference. Provides CMK-at-rest via Key Vault."
  default     = null
}

variable "encryption_settings" {
  type = object({
    enabled = optional(bool)
    disk_encryption_key = optional(object({
      secret_url      = string
      source_vault_id = string
    }))
    key_encryption_key = optional(object({
      key_url         = string
      source_vault_id = string
    }))
  })
  description = "Azure Disk Encryption (ADE) settings — BYOK at the OS level (BitLocker / dm-crypt). For server-side CMK, use customer_managed_key or disk_encryption_set_id instead."
  default     = null
}

variable "security_type" {
  type        = string
  description = "Security type for Confidential VM disks. 'ConfidentialVM_VMGuestStateOnlyEncryptedWithPlatformKey', 'ConfidentialVM_DiskEncryptedWithPlatformKey', or 'ConfidentialVM_DiskEncryptedWithCustomerKey'."
  default     = null

  validation {
    condition     = var.security_type == null || contains(["ConfidentialVM_VMGuestStateOnlyEncryptedWithPlatformKey", "ConfidentialVM_DiskEncryptedWithPlatformKey", "ConfidentialVM_DiskEncryptedWithCustomerKey"], coalesce(var.security_type, "ConfidentialVM_VMGuestStateOnlyEncryptedWithPlatformKey"))
    error_message = "security_type must be one of the three ConfidentialVM_* values, or null."
  }
}

variable "trusted_launch_enabled" {
  type        = bool
  description = "Whether Trusted Launch is enabled. Recommended for non-Confidential VMs. Changing this forces a new resource."
  default     = null
}

# =====================================================================
# Network access
# =====================================================================

variable "network_access_policy" {
  type        = string
  description = "Disk network access policy. 'AllowAll', 'AllowPrivate', or 'DenyAll'. Defaults to 'AllowPrivate' for private-endpoint-only access."
  default     = "AllowPrivate"

  validation {
    condition     = contains(["AllowAll", "AllowPrivate", "DenyAll"], var.network_access_policy)
    error_message = "network_access_policy must be 'AllowAll', 'AllowPrivate', or 'DenyAll'."
  }
}

variable "public_network_access_enabled" {
  type        = bool
  description = "Whether the disk is reachable over the public internet. Defaults to false."
  default     = false
}

variable "disk_access_id" {
  type        = string
  description = "Disk Access resource ID. Required when network_access_policy = 'AllowPrivate' and private endpoints are used."
  default     = null
}

variable "private_endpoints" {
  type = map(object({
    name = optional(string, null)
    role_assignments = optional(map(object({
      role_definition_id_or_name             = string
      principal_id                           = string
      description                            = optional(string, null)
      skip_service_principal_aad_check       = optional(bool, false)
      condition                              = optional(string, null)
      condition_version                      = optional(string, null)
      delegated_managed_identity_resource_id = optional(string, null)
      principal_type                         = optional(string, null)
    })), {})
    lock = optional(object({
      kind = string
      name = optional(string, null)
    }), null)
    tags                                    = optional(map(string), null)
    subnet_resource_id                      = string
    private_dns_zone_group_name             = optional(string, "default")
    private_dns_zone_resource_ids           = optional(set(string), [])
    application_security_group_associations = optional(map(string), {})
    private_service_connection_name         = optional(string, null)
    network_interface_name                  = optional(string, null)
    location                                = optional(string, null)
    resource_group_name                     = optional(string, null)
    ip_configurations = optional(map(object({
      name               = string
      private_ip_address = string
    })), {})
  }))
  description = "Map of private endpoints to attach to the disk via Disk Access."
  default     = {}
}

variable "private_endpoints_manage_dns_zone_group" {
  type        = bool
  description = "Whether the module manages private DNS zone groups. Set false if DNS is managed externally."
  default     = true
}

# =====================================================================
# Governance
# =====================================================================

variable "role_assignments" {
  type = map(object({
    role_definition_id_or_name             = string
    principal_id                           = string
    description                            = optional(string, null)
    skip_service_principal_aad_check       = optional(bool, false)
    condition                              = optional(string, null)
    condition_version                      = optional(string, null)
    delegated_managed_identity_resource_id = optional(string, null)
    principal_type                         = optional(string, null)
  }))
  description = "RBAC role assignments scoped to the disk."
  default     = {}
}

variable "lock" {
  type = object({
    kind = string
    name = optional(string, null)
  })
  description = "Optional resource lock. kind must be 'CanNotDelete' or 'ReadOnly'."
  default     = null

  validation {
    condition     = var.lock == null || contains(["CanNotDelete", "ReadOnly"], try(var.lock.kind, ""))
    error_message = "lock.kind must be 'CanNotDelete' or 'ReadOnly' when lock is set."
  }
}

# =====================================================================
# Module behavior
# =====================================================================

variable "edge_zone" {
  type        = string
  description = "Edge Zone within the Azure region. Forces a new resource."
  default     = null
}

variable "enable_telemetry" {
  type        = bool
  description = "Whether to enable AVM module telemetry. Set false to opt out."
  default     = true
}

variable "tags" {
  type        = map(string)
  description = "A map of tags to apply to the disk."
  default     = null
}
