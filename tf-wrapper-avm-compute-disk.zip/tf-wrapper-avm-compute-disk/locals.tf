locals {
  module_tags = merge(
    var.tags == null ? {} : var.tags,
    {
      managed-by = "terraform"
      module     = "tf-wrapper-avm-compute-disk"
    }
  )

  cmk_configured = (
    var.customer_managed_key != null ||
    var.disk_encryption_set_id != null ||
    var.secure_vm_disk_encryption_set_id != null ||
    var.encryption_settings != null
  )

  has_private_endpoints = length(var.private_endpoints) > 0
}
