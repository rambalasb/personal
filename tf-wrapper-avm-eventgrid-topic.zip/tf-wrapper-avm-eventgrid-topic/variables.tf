# =====================================================================
# Required inputs
# =====================================================================

variable "name" {
  type        = string
  description = "The name of the Event Grid Topic. Must be 3-50 characters, letters, numbers and hyphens only, and unique within the region."

  validation {
    condition     = can(regex("^[a-zA-Z0-9-]{3,50}$", var.name))
    error_message = "name must be 3-50 characters, letters, numbers and hyphens only."
  }
}

variable "parent_id" {
  type        = string
  description = "Resource ID of the resource group where the Event Grid Topic will be deployed."

  validation {
    condition     = can(regex("^/subscriptions/[^/]+/resourceGroups/[^/]+$", var.parent_id))
    error_message = "parent_id must be a resource group resource ID: /subscriptions/<sub>/resourceGroups/<name>."
  }
}

variable "location" {
  type        = string
  description = "The Azure region where the Event Grid Topic will be deployed."

  validation {
    condition     = length(var.location) > 0
    error_message = "location must not be empty."
  }
}

# =====================================================================
# Topic behaviour
# =====================================================================

variable "input_schema" {
  type        = string
  description = "Schema the topic accepts from publishers. Valid: 'EventGridSchema', 'CloudEventSchemaV1_0', 'CustomEventSchema'. Forces a new resource."
  default     = "EventGridSchema"

  validation {
    condition     = contains(["EventGridSchema", "CloudEventSchemaV1_0", "CustomEventSchema"], var.input_schema)
    error_message = "input_schema must be one of: EventGridSchema, CloudEventSchemaV1_0, CustomEventSchema."
  }
}

variable "input_schema_mapping" {
  type = object({
    input_schema_mapping_type = string
    properties = optional(object({
      data_version = optional(object({
        default_value = optional(string)
        source_field  = optional(string)
      }))
      event_time = optional(object({
        source_field = optional(string)
      }))
      event_type = optional(object({
        default_value = optional(string)
        source_field  = optional(string)
      }))
      id = optional(object({
        source_field = optional(string)
      }))
      subject = optional(object({
        default_value = optional(string)
        source_field  = optional(string)
      }))
      topic = optional(object({
        source_field = optional(string)
      }))
    }))
  })
  description = "Field mapping from a custom publisher payload onto the Event Grid schema. Only meaningful when input_schema is 'CustomEventSchema'; input_schema_mapping_type must be 'Json'."
  default     = null

  validation {
    condition     = var.input_schema_mapping == null || try(var.input_schema_mapping.input_schema_mapping_type, "") == "Json"
    error_message = "input_schema_mapping.input_schema_mapping_type must be 'Json'."
  }
}

variable "data_residency_boundary" {
  type        = string
  description = "Where topic metadata may be replicated. Valid: 'WithinGeopair' (Azure default), 'WithinRegion'. Null sends WithinGeopair explicitly."
  default     = null

  validation {
    condition     = var.data_residency_boundary == null || contains(["WithinGeopair", "WithinRegion"], coalesce(var.data_residency_boundary, "WithinGeopair"))
    error_message = "data_residency_boundary must be 'WithinGeopair', 'WithinRegion', or null."
  }
}

variable "properties" {
  type        = map(string)
  description = "Additional Microsoft.EventGrid/topics ARM properties not modelled by the module, merged last so they override the values derived from the other inputs. String values only."
  default     = {}
  nullable    = false
}

variable "enable_telemetry" {
  type        = bool
  description = "Whether to enable AVM module telemetry. Set false to opt out."
  default     = true
}

# =====================================================================
# Access control (secure-by-default)
# =====================================================================

variable "disable_local_auth" {
  type        = bool
  description = "Whether access-key authentication is disabled. Defaults to true so publishers authenticate with Entra ID and the 'EventGrid Data Sender' role."
  default     = true
  nullable    = false
}

variable "minimum_tls_version_allowed" {
  type        = string
  description = "Minimum TLS version publishers may negotiate. Valid: '1.0', '1.1', '1.2'."
  default     = "1.2"

  validation {
    condition     = contains(["1.0", "1.1", "1.2"], var.minimum_tls_version_allowed)
    error_message = "minimum_tls_version_allowed must be one of: 1.0, 1.1, 1.2."
  }
}

variable "public_network_access" {
  type        = string
  description = "Whether the topic is reachable over the public endpoint. Valid: 'Enabled', 'Disabled'. Defaults to Disabled; pair with private_endpoints for private ingestion."
  default     = "Disabled"

  validation {
    condition     = contains(["Enabled", "Disabled"], var.public_network_access)
    error_message = "public_network_access must be 'Enabled' or 'Disabled'."
  }
}

variable "inbound_ip_rules" {
  type = list(object({
    ip_mask = string
    action  = string
  }))
  description = "IP allowlist applied when public_network_access is 'Enabled'. Each entry is a CIDR or single address in ip_mask; action must be 'Allow' (the API has no deny rules). Ignored while public access is disabled."
  default     = []
  nullable    = false

  validation {
    condition     = alltrue([for r in var.inbound_ip_rules : r.action == "Allow"])
    error_message = "inbound_ip_rules[*].action must be 'Allow'. The Event Grid API models the list as an allowlist and rejects any other action."
  }
  validation {
    condition     = alltrue([for r in var.inbound_ip_rules : can(cidrnetmask(strcontains(r.ip_mask, "/") ? r.ip_mask : "${r.ip_mask}/32"))])
    error_message = "inbound_ip_rules[*].ip_mask must be an IPv4 address or CIDR block, e.g. '10.1.0.0/16' or '203.0.113.7'."
  }
}

# =====================================================================
# Networking
# =====================================================================

variable "private_endpoints" {
  type = map(object({
    name = optional(string, null)
    role_assignments = optional(map(object({
      role_definition_id_or_name             = string
      principal_id                           = string
      description                            = optional(string, null)
      skip_service_principal_aad_check       = optional(bool, false)
      condition                              = optional(string, null)
      condition_version                      = optional(string, null)
      delegated_managed_identity_resource_id = optional(string, null)
      principal_type                         = optional(string, null)
    })), {})
    lock = optional(object({
      kind = string
      name = optional(string, null)
    }), null)
    tags                                    = optional(map(string), null)
    subnet_resource_id                      = string
    private_dns_zone_group_name             = optional(string, "default")
    private_dns_zone_resource_ids           = optional(set(string), [])
    application_security_group_associations = optional(map(string), {})
    private_service_connection_name         = optional(string, null)
    network_interface_name                  = optional(string, null)
    location                                = optional(string, null)
    resource_group_name                     = optional(string, null)
    ip_configurations = optional(map(object({
      name               = string
      private_ip_address = string
    })), {})
  }))
  default     = {}
  nullable    = false
  description = <<DESCRIPTION
A map of private endpoints to create on the topic. The map key is deliberately arbitrary to avoid issues where map keys may be unknown at plan time. Defaults to `{}` (no private endpoints).

The subresource is always `topic`; a topic exposes no others, so it is not an input.

- `subnet_resource_id` - (Required) The resource ID of the subnet to deploy the private endpoint in.
- `name` - (Optional) The name of the private endpoint. Defaults to `pe-<topic name>-<map key>`.
- `role_assignments` - (Optional) A map of role assignments to create on the private endpoint. Defaults to `{}`. See `var.role_assignments` for the attribute list.
- `lock` - (Optional) The management lock to apply to the private endpoint. Defaults to `null` (no lock). Supports `kind` (`CanNotDelete` or `ReadOnly`) and an optional `name`.
- `tags` - (Optional) A mapping of tags to assign to the private endpoint. Defaults to `null`.
- `private_dns_zone_group_name` - (Optional) The name of the private DNS zone group. Defaults to `default`.
- `private_dns_zone_resource_ids` - (Optional) A set of private DNS zone resource IDs to associate. Defaults to `[]`, which creates no zone group and leaves DNS records to be managed externally. Event Grid resolves through `privatelink.eventgrid.azure.net`.
- `application_security_group_associations` - (Optional) A map of application security group resource IDs to associate with the private endpoint. Defaults to `{}`; the map key is arbitrary.
- `private_service_connection_name` - (Optional) The name of the private service connection. Generated if not set.
- `network_interface_name` - (Optional) The name of the network interface. Defaults to `nic-<private endpoint name>`.
- `location` - (Optional) The region to deploy the private endpoint in. Defaults to the topic's location; set it to place the endpoint in a different region from the topic.
- `resource_group_name` - (Optional) The resource group to deploy the private endpoint in. Defaults to the topic's resource group.
- `ip_configurations` - (Optional) A map of static IP configurations for the private endpoint. Defaults to `{}` (the platform allocates the IP). Each value supports `name` and `private_ip_address`.
DESCRIPTION

  validation {
    condition     = alltrue([for pe in var.private_endpoints : pe.lock == null || contains(["CanNotDelete", "ReadOnly"], try(pe.lock.kind, ""))])
    error_message = "private_endpoints[*].lock.kind must be 'CanNotDelete' or 'ReadOnly' when a lock is set."
  }
}

variable "private_endpoints_manage_dns_zone_group" {
  type        = bool
  description = "Whether the module manages private DNS zone groups. Set false when DNS is managed externally (e.g. via Azure Policy)."
  default     = true
  nullable    = false
}

# =====================================================================
# Identity and RBAC
# =====================================================================

variable "managed_identities" {
  type = object({
    system_assigned            = optional(bool, false)
    user_assigned_resource_ids = optional(set(string), [])
  })
  description = "Managed identity configuration on the topic. An identity is required for event subscriptions that deliver with delivery_with_resource_identity."
  default     = {}
  nullable    = false
}

variable "role_assignments" {
  type = map(object({
    role_definition_id_or_name             = string
    principal_id                           = string
    description                            = optional(string, null)
    skip_service_principal_aad_check       = optional(bool, false)
    condition                              = optional(string, null)
    condition_version                      = optional(string, null)
    delegated_managed_identity_resource_id = optional(string, null)
    principal_type                         = optional(string, null)
  }))
  description = "Map of RBAC role assignments scoped to the topic. Publishers need 'EventGrid Data Sender' once local auth is disabled; 'EventGrid Contributor' manages the topic itself."
  default     = {}
  nullable    = false
}

# =====================================================================
# Event subscriptions
# =====================================================================

variable "event_subscriptions" {
  type = map(object({
    name = string

    # Direct delivery. Exactly one destination type per subscription.
    destination = optional(object({
      azure_function = optional(object({
        resource_id                       = string
        max_events_per_batch              = optional(number)
        preferred_batch_size_in_kilobytes = optional(number)
        delivery_attribute_mappings = optional(list(object({
          name         = string
          type         = string
          value        = optional(string)
          is_secret    = optional(bool)
          source_field = optional(string)
        })))
      }))
      event_hub = optional(object({
        resource_id = string
        delivery_attribute_mappings = optional(list(object({
          name         = string
          type         = string
          value        = optional(string)
          is_secret    = optional(bool)
          source_field = optional(string)
        })))
      }))
      hybrid_connection = optional(object({
        resource_id = string
        delivery_attribute_mappings = optional(list(object({
          name         = string
          type         = string
          value        = optional(string)
          is_secret    = optional(bool)
          source_field = optional(string)
        })))
      }))
      monitor_alert = optional(object({
        severity      = string
        action_groups = optional(list(string))
        description   = optional(string)
      }))
      namespace_topic = optional(object({
        resource_id = string
      }))
      service_bus_queue = optional(object({
        resource_id = string
        delivery_attribute_mappings = optional(list(object({
          name         = string
          type         = string
          value        = optional(string)
          is_secret    = optional(bool)
          source_field = optional(string)
        })))
      }))
      service_bus_topic = optional(object({
        resource_id = string
        delivery_attribute_mappings = optional(list(object({
          name         = string
          type         = string
          value        = optional(string)
          is_secret    = optional(bool)
          source_field = optional(string)
        })))
      }))
      storage_queue = optional(object({
        resource_id                           = string
        queue_name                            = string
        queue_message_time_to_live_in_seconds = optional(number)
      }))
      webhook = optional(object({
        endpoint_url                         = string
        max_events_per_batch                 = optional(number)
        preferred_batch_size_in_kilobytes    = optional(number)
        azure_active_directory_tenant_id     = optional(string)
        azure_active_directory_app_id_or_uri = optional(string)
        minimum_tls_version_allowed          = optional(string)
        delivery_attribute_mappings = optional(list(object({
          name         = string
          type         = string
          value        = optional(string)
          is_secret    = optional(bool)
          source_field = optional(string)
        })))
      }))
    }))

    # Delivery authenticated with the topic's managed identity.
    delivery_with_resource_identity = optional(object({
      identity = object({
        type                   = string
        user_assigned_identity = optional(string)
      })
      destination = object({
        azure_function = optional(object({
          resource_id                       = string
          max_events_per_batch              = optional(number)
          preferred_batch_size_in_kilobytes = optional(number)
          delivery_attribute_mappings = optional(list(object({
            name         = string
            type         = string
            value        = optional(string)
            is_secret    = optional(bool)
            source_field = optional(string)
          })))
        }))
        event_hub = optional(object({
          resource_id = string
          delivery_attribute_mappings = optional(list(object({
            name         = string
            type         = string
            value        = optional(string)
            is_secret    = optional(bool)
            source_field = optional(string)
          })))
        }))
        hybrid_connection = optional(object({
          resource_id = string
          delivery_attribute_mappings = optional(list(object({
            name         = string
            type         = string
            value        = optional(string)
            is_secret    = optional(bool)
            source_field = optional(string)
          })))
        }))
        monitor_alert = optional(object({
          severity      = string
          action_groups = optional(list(string))
          description   = optional(string)
        }))
        namespace_topic = optional(object({
          resource_id = string
        }))
        service_bus_queue = optional(object({
          resource_id = string
          delivery_attribute_mappings = optional(list(object({
            name         = string
            type         = string
            value        = optional(string)
            is_secret    = optional(bool)
            source_field = optional(string)
          })))
        }))
        service_bus_topic = optional(object({
          resource_id = string
          delivery_attribute_mappings = optional(list(object({
            name         = string
            type         = string
            value        = optional(string)
            is_secret    = optional(bool)
            source_field = optional(string)
          })))
        }))
        storage_queue = optional(object({
          resource_id                           = string
          queue_name                            = string
          queue_message_time_to_live_in_seconds = optional(number)
        }))
        webhook = optional(object({
          endpoint_url                         = string
          max_events_per_batch                 = optional(number)
          preferred_batch_size_in_kilobytes    = optional(number)
          azure_active_directory_tenant_id     = optional(string)
          azure_active_directory_app_id_or_uri = optional(string)
          minimum_tls_version_allowed          = optional(string)
          delivery_attribute_mappings = optional(list(object({
            name         = string
            type         = string
            value        = optional(string)
            is_secret    = optional(bool)
            source_field = optional(string)
          })))
        }))
      })
    }))

    # Dead lettering. Storage blob is the only destination Azure supports.
    dead_letter_destination = optional(object({
      storage_blob = object({
        resource_id         = string
        blob_container_name = string
      })
    }))
    dead_letter_with_resource_identity = optional(object({
      identity = object({
        type                   = string
        user_assigned_identity = optional(string)
      })
      dead_letter_destination = object({
        storage_blob = object({
          resource_id         = string
          blob_container_name = string
        })
      })
    }))

    event_delivery_schema = optional(string)
    expiration_time_utc   = optional(string)

    filter = optional(object({
      subject_begins_with                 = optional(string)
      subject_ends_with                   = optional(string)
      included_event_types                = optional(list(string))
      is_subject_case_sensitive           = optional(bool)
      enable_advanced_filtering_on_arrays = optional(bool)
      advanced_filters = optional(list(object({
        key           = string
        operator_type = string
        value         = optional(any)
        values        = optional(list(any))
      })))
    }))

    labels = optional(list(string))

    retry_policy = optional(object({
      max_delivery_attempts         = optional(number)
      event_time_to_live_in_minutes = optional(number)
    }))
  }))
  default     = {}
  nullable    = false
  description = <<DESCRIPTION
A map of event subscriptions to create on the topic. The map key is deliberately arbitrary to avoid issues where map keys may be unknown at plan time. Defaults to `{}` (no subscriptions).

- `name` - (Required) The name of the event subscription.
- `destination` - (Optional) Direct delivery, authenticated with the destination's own keys. Set exactly one of `azure_function`, `event_hub`, `hybrid_connection`, `monitor_alert`, `namespace_topic`, `service_bus_queue`, `service_bus_topic`, `storage_queue`, `webhook`.
- `delivery_with_resource_identity` - (Optional) Delivery authenticated with a managed identity on the topic. Preferred over `destination`: it removes destination keys from the delivery path. Takes `identity` (`type` of `SystemAssigned` or `UserAssigned`, plus `user_assigned_identity` for the latter) and a `destination` with the same shape as above. The identity must exist on the topic via `var.managed_identities` and hold the data-plane role on the destination, e.g. 'Storage Queue Data Message Sender'.
- `dead_letter_destination` / `dead_letter_with_resource_identity` - (Optional) Where events land after the retry policy is exhausted. Storage blob is the only destination Azure supports.
- `event_delivery_schema` - (Optional) Schema events are delivered in. One of `EventGridSchema`, `CloudEventSchemaV1_0`, `CustomInputSchema`.
- `expiration_time_utc` - (Optional) RFC 3339 timestamp after which the subscription stops delivering. Defaults to `null` (never expires).
- `filter` - (Optional) Server-side filtering: `subject_begins_with`, `subject_ends_with`, `included_event_types`, `is_subject_case_sensitive`, `enable_advanced_filtering_on_arrays`, and `advanced_filters` (each with `key`, `operator_type`, and `value` or `values`).
- `labels` - (Optional) A list of labels on the subscription.
- `retry_policy` - (Optional) `max_delivery_attempts` (default 30) and `event_time_to_live_in_minutes` (default 1440).
DESCRIPTION

  validation {
    condition = alltrue([
      for _, v in var.event_subscriptions :
      v.destination != null || v.delivery_with_resource_identity != null
    ])
    error_message = "Each event_subscriptions entry must set either `destination` or `delivery_with_resource_identity`."
  }
  validation {
    condition = alltrue([
      for _, v in var.event_subscriptions :
      !(v.destination != null && v.delivery_with_resource_identity != null)
    ])
    error_message = "Each event_subscriptions entry must set only one of `destination` or `delivery_with_resource_identity`, not both."
  }
  validation {
    condition = alltrue([
      for _, v in var.event_subscriptions : v.destination == null ? true : length([
        for set in [
          v.destination.azure_function != null,
          v.destination.event_hub != null,
          v.destination.hybrid_connection != null,
          v.destination.monitor_alert != null,
          v.destination.namespace_topic != null,
          v.destination.service_bus_queue != null,
          v.destination.service_bus_topic != null,
          v.destination.storage_queue != null,
          v.destination.webhook != null,
        ] : set if set
      ]) == 1
    ])
    error_message = "Each event_subscriptions entry must set exactly one destination type under `destination`."
  }
  validation {
    condition = alltrue([
      for _, v in var.event_subscriptions : v.delivery_with_resource_identity == null ? true : length([
        for set in [
          v.delivery_with_resource_identity.destination.azure_function != null,
          v.delivery_with_resource_identity.destination.event_hub != null,
          v.delivery_with_resource_identity.destination.hybrid_connection != null,
          v.delivery_with_resource_identity.destination.monitor_alert != null,
          v.delivery_with_resource_identity.destination.namespace_topic != null,
          v.delivery_with_resource_identity.destination.service_bus_queue != null,
          v.delivery_with_resource_identity.destination.service_bus_topic != null,
          v.delivery_with_resource_identity.destination.storage_queue != null,
          v.delivery_with_resource_identity.destination.webhook != null,
        ] : set if set
      ]) == 1
    ])
    error_message = "Each event_subscriptions entry must set exactly one destination type under `delivery_with_resource_identity.destination`."
  }
  validation {
    condition = alltrue([
      for _, v in var.event_subscriptions :
      v.delivery_with_resource_identity == null ? true : contains(["SystemAssigned", "UserAssigned"], v.delivery_with_resource_identity.identity.type)
    ])
    error_message = "event_subscriptions[*].delivery_with_resource_identity.identity.type must be 'SystemAssigned' or 'UserAssigned'."
  }
  validation {
    condition = alltrue([
      for _, v in var.event_subscriptions :
      v.delivery_with_resource_identity == null ? true : (
        v.delivery_with_resource_identity.identity.type != "UserAssigned" || v.delivery_with_resource_identity.identity.user_assigned_identity != null
      )
    ])
    error_message = "event_subscriptions[*].delivery_with_resource_identity.identity.user_assigned_identity is required when identity.type is 'UserAssigned'."
  }
  validation {
    condition = alltrue([
      for _, v in var.event_subscriptions :
      v.event_delivery_schema == null ? true : contains(["EventGridSchema", "CloudEventSchemaV1_0", "CustomInputSchema"], v.event_delivery_schema)
    ])
    error_message = "event_subscriptions[*].event_delivery_schema must be one of: EventGridSchema, CloudEventSchemaV1_0, CustomInputSchema."
  }
}

# =====================================================================
# Diagnostics, locks, tagging
# =====================================================================

variable "diagnostic_settings" {
  type = map(object({
    name                                     = optional(string, null)
    log_categories                           = optional(set(string), [])
    log_groups                               = optional(set(string), ["allLogs"])
    metric_categories                        = optional(set(string), ["AllMetrics"])
    log_analytics_destination_type           = optional(string, "Dedicated")
    workspace_resource_id                    = optional(string, null)
    storage_account_resource_id              = optional(string, null)
    event_hub_authorization_rule_resource_id = optional(string, null)
    event_hub_name                           = optional(string, null)
    marketplace_partner_resource_id          = optional(string, null)
  }))
  default     = {}
  nullable    = false
  description = <<DESCRIPTION
A map of diagnostic settings to create on the topic. The map key is deliberately arbitrary to avoid issues where map keys may be unknown at plan time. Defaults to `{}` (no diagnostic settings).

- `name` - (Optional) The name of the diagnostic setting. Defaults to `<topic name>-diag-<map key>`.
- `log_categories` - (Optional) A set of log categories to send. Defaults to `[]`. Event Grid topics emit `DeliveryFailures` and `PublishFailures`. Ignored when `log_groups` is non-empty.
- `log_groups` - (Optional) A set of log category groups to send. Defaults to `["allLogs"]` and takes precedence over `log_categories`.
- `metric_categories` - (Optional) A set of metric categories to send. Defaults to `["AllMetrics"]`.
- `log_analytics_destination_type` - (Optional) `Dedicated` or `AzureDiagnostics`. Defaults to `Dedicated`.
- `workspace_resource_id` - (Optional) The Log Analytics workspace to send to.
- `storage_account_resource_id` - (Optional) The storage account to archive to.
- `event_hub_authorization_rule_resource_id` - (Optional) The event hub authorization rule to stream to.
- `event_hub_name` - (Optional) The event hub to stream to. Defaults to the rule's default hub.
- `marketplace_partner_resource_id` - (Optional) The Marketplace partner resource to send to.

At least one destination must be set per entry.
DESCRIPTION

  validation {
    condition     = alltrue([for _, v in var.diagnostic_settings : contains(["Dedicated", "AzureDiagnostics"], v.log_analytics_destination_type)])
    error_message = "diagnostic_settings[*].log_analytics_destination_type must be 'Dedicated' or 'AzureDiagnostics'."
  }
  validation {
    condition = alltrue([
      for _, v in var.diagnostic_settings :
      v.workspace_resource_id != null || v.storage_account_resource_id != null || v.event_hub_authorization_rule_resource_id != null || v.marketplace_partner_resource_id != null
    ])
    error_message = "At least one of `workspace_resource_id`, `storage_account_resource_id`, `event_hub_authorization_rule_resource_id`, or `marketplace_partner_resource_id` must be set."
  }
  validation {
    condition = alltrue([
      for _, v in var.diagnostic_settings :
      alltrue([for c in v.log_categories : contains(["DeliveryFailures", "PublishFailures"], c)])
    ])
    error_message = "diagnostic_settings[*].log_categories must be drawn from: DeliveryFailures, PublishFailures."
  }
}

variable "lock" {
  type = object({
    kind = string
    name = optional(string, null)
  })
  description = "Optional resource lock. kind must be 'CanNotDelete' or 'ReadOnly'."
  default     = null

  validation {
    condition     = var.lock == null || contains(["CanNotDelete", "ReadOnly"], try(var.lock.kind, ""))
    error_message = "lock.kind must be 'CanNotDelete' or 'ReadOnly' when lock is set."
  }
}

variable "tags" {
  type        = map(string)
  description = "A map of tags to apply to the Event Grid Topic."
  default     = null
}

variable "wrapper_tags_enabled" {
  type        = bool
  description = "Whether to add the wrapper's own managed-by/module tags. Set false only when adopting an existing resource whose sole plan diff is those tags -- it turns the adoption into a true no-op instead of a write. Leave true otherwise."
  default     = true
}
