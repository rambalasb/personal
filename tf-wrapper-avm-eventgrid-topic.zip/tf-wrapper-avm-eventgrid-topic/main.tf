module "eventgrid_topic" {
  source  = "Azure/avm-res-eventgrid-topic/azurerm"
  version = "0.1.1"

  # Required
  name      = var.name
  parent_id = var.parent_id
  location  = var.location

  # Topic behaviour
  input_schema            = var.input_schema
  input_schema_mapping    = var.input_schema_mapping
  data_residency_boundary = var.data_residency_boundary
  enable_telemetry        = var.enable_telemetry

  # Access control plane
  disable_local_auth          = var.disable_local_auth
  minimum_tls_version_allowed = var.minimum_tls_version_allowed
  public_network_access       = var.public_network_access
  inbound_ip_rules            = var.inbound_ip_rules

  # Networking
  private_endpoints                       = var.private_endpoints
  private_endpoints_manage_dns_zone_group = var.private_endpoints_manage_dns_zone_group

  # Identity and RBAC
  managed_identities = var.managed_identities
  role_assignments   = var.role_assignments

  # Subscriptions
  event_subscriptions = var.event_subscriptions

  # Diagnostics, locks, tagging
  diagnostic_settings = var.diagnostic_settings
  lock                = var.lock
  tags                = local.module_tags

  # Escape hatch for ARM properties the module does not model.
  properties = var.properties
}
