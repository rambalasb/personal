terraform {
  required_version = ">= 1.9, < 2.0"

  required_providers {
    # The topic itself and its private endpoints are azapi; diagnostic settings,
    # the management lock and role assignments are azurerm. Both floors match
    # AVM avm-res-eventgrid-topic v0.1.1.
    azapi = {
      source  = "Azure/azapi"
      version = "~> 2.4"
    }
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 4.0, < 5.0"
    }
  }
}
