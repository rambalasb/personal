output "resource_id" {
  value = module.eventgrid_topic.resource_id
}

output "event_subscription_ids" {
  value = module.eventgrid_topic.event_subscription_ids
}

output "event_subscription_names" {
  value = module.eventgrid_topic.event_subscription_names
}
