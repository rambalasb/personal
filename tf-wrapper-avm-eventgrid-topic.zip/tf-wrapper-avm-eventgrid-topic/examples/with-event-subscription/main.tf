module "eventgrid_topic" {
  source = "../.."

  name      = "evgt-avm-sub-${random_string.suffix.result}"
  parent_id = azurerm_resource_group.this.id
  location  = azurerm_resource_group.this.location

  managed_identities = {
    user_assigned_resource_ids = [azurerm_user_assigned_identity.this.id]
  }

  event_subscriptions = {
    to_queue = {
      name = "sub-storage-queue"

      delivery_with_resource_identity = {
        identity = {
          type                   = "UserAssigned"
          user_assigned_identity = azurerm_user_assigned_identity.this.id
        }
        destination = {
          storage_queue = {
            resource_id                           = azurerm_storage_account.this.id
            queue_name                            = azurerm_storage_queue.this.name
            queue_message_time_to_live_in_seconds = 604800
          }
        }
      }

      dead_letter_with_resource_identity = {
        identity = {
          type                   = "UserAssigned"
          user_assigned_identity = azurerm_user_assigned_identity.this.id
        }
        dead_letter_destination = {
          storage_blob = {
            resource_id         = azurerm_storage_account.this.id
            blob_container_name = azurerm_storage_container.deadletter.name
          }
        }
      }

      filter = {
        subject_begins_with  = "/orders/"
        included_event_types = ["Order.Created", "Order.Cancelled"]
      }

      retry_policy = {
        max_delivery_attempts         = 10
        event_time_to_live_in_minutes = 120
      }
    }
  }

  enable_telemetry = false

  # RBAC must land before the subscription, or Event Grid rejects it
  depends_on = [
    azurerm_role_assignment.queue_sender,
    azurerm_role_assignment.deadletter_writer,
  ]
}
