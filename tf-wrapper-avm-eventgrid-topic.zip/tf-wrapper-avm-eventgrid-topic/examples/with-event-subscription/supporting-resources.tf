# unique names for the storage account and the topic
resource "random_string" "suffix" {
  length  = 6
  lower   = true
  upper   = false
  numeric = true
  special = false
}

resource "azurerm_resource_group" "this" {
  name     = "rg-avm-egt-sub-test-${random_string.suffix.result}"
  location = "canadacentral"
}

# delivery target and dead letter store for the subscription below
resource "azurerm_storage_account" "this" {
  account_replication_type = "LRS"
  account_tier             = "Standard"
  location                 = azurerm_resource_group.this.location
  name                     = "stavmegt${random_string.suffix.result}"
  resource_group_name      = azurerm_resource_group.this.name
  min_tls_version          = "TLS1_2"
}

resource "azurerm_storage_queue" "this" {
  name               = "topic-events"
  storage_account_id = azurerm_storage_account.this.id
}

resource "azurerm_storage_container" "deadletter" {
  name                  = "deadletter"
  container_access_type = "private"
  storage_account_id    = azurerm_storage_account.this.id
}

# user-assigned identity rather than system-assigned: the role assignments the
# subscription needs can then be created before the topic, which Event Grid
# requires -- it validates delivery rights when the subscription is created.
resource "azurerm_user_assigned_identity" "this" {
  location            = azurerm_resource_group.this.location
  name                = "id-avm-egt-sub-test-${random_string.suffix.result}"
  resource_group_name = azurerm_resource_group.this.name
}

resource "azurerm_role_assignment" "queue_sender" {
  principal_id         = azurerm_user_assigned_identity.this.principal_id
  scope                = azurerm_storage_account.this.id
  role_definition_name = "Storage Queue Data Message Sender"
}

resource "azurerm_role_assignment" "deadletter_writer" {
  principal_id         = azurerm_user_assigned_identity.this.principal_id
  scope                = azurerm_storage_account.this.id
  role_definition_name = "Storage Blob Data Contributor"
}
