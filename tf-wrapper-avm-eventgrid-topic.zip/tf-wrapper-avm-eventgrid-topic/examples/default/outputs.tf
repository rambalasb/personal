output "resource_id" {
  value = module.eventgrid_topic.resource_id
}

output "name" {
  value = module.eventgrid_topic.name
}

output "topic_location" {
  value = module.eventgrid_topic.topic_location
}
