# deploying identity, granted data-plane publish rights on the topic
data "azurerm_client_config" "current" {}

# topic names must be unique within the region
resource "random_string" "suffix" {
  length  = 6
  lower   = true
  upper   = false
  numeric = true
  special = false
}

# native supporting resources so the example tests standalone, without a sibling module
resource "azurerm_resource_group" "this" {
  name     = "rg-avm-egt-default-test-${random_string.suffix.result}"
  location = "canadacentral"
}

resource "azurerm_log_analytics_workspace" "this" {
  location            = azurerm_resource_group.this.location
  name                = "log-avm-egt-default-test-${random_string.suffix.result}"
  resource_group_name = azurerm_resource_group.this.name
  retention_in_days   = 30
  sku                 = "PerGB2018"
}
