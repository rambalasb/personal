module "eventgrid_topic" {
  source = "../.."

  name      = "evgt-avm-default-${random_string.suffix.result}"
  parent_id = azurerm_resource_group.this.id
  location  = azurerm_resource_group.this.location

  diagnostic_settings = {
    to_law = {
      workspace_resource_id = azurerm_log_analytics_workspace.this.id
    }
  }

  role_assignments = {
    publisher = {
      role_definition_id_or_name = "EventGrid Data Sender"
      principal_id               = data.azurerm_client_config.current.object_id
    }
  }

  enable_telemetry = false
}
