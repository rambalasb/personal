check "entra_auth_only" {
  assert {
    condition     = var.disable_local_auth
    error_message = "Event Grid Topic should reject access-key authentication. Set var.disable_local_auth = true and grant publishers the 'EventGrid Data Sender' role."
  }
}

check "tls_minimum_1_2" {
  assert {
    condition     = var.minimum_tls_version_allowed == "1.2"
    error_message = "Event Grid Topic should require TLS 1.2. Set var.minimum_tls_version_allowed = \"1.2\"."
  }
}

check "public_network_access_disabled_by_default" {
  assert {
    condition     = var.public_network_access == "Disabled" || length(var.inbound_ip_rules) > 0
    error_message = "Public network access is enabled with no IP allowlist, leaving the topic reachable from any address. Set var.public_network_access = \"Disabled\", or populate var.inbound_ip_rules."
  }
}

check "private_endpoint_implies_no_public_access" {
  assert {
    condition     = length(var.private_endpoints) == 0 || var.public_network_access == "Disabled"
    error_message = "When private endpoints are configured, public network access should be disabled. Set var.public_network_access = \"Disabled\"."
  }
}

check "diagnostic_settings_configured" {
  assert {
    condition     = length(var.diagnostic_settings) > 0
    error_message = "Event Grid Topic has no diagnostic settings configured. Send PublishFailures and DeliveryFailures to a workspace so dropped events are visible."
  }
}

check "subscriptions_deliver_with_managed_identity" {
  assert {
    condition = alltrue([
      for _, v in var.event_subscriptions : v.delivery_with_resource_identity != null
    ])
    error_message = "Event subscriptions should deliver with a managed identity rather than destination keys. Move the destination under delivery_with_resource_identity and grant the identity the destination's data-plane role."
  }
}

check "subscriptions_have_dead_letter_destination" {
  assert {
    condition = alltrue([
      for _, v in var.event_subscriptions :
      v.dead_letter_destination != null || v.dead_letter_with_resource_identity != null
    ])
    error_message = "Event subscriptions should set a dead letter destination. Without one, events that exhaust the retry policy are dropped silently."
  }
}

check "webhook_destinations_enforce_tls_1_2" {
  assert {
    condition = alltrue(flatten([
      for _, v in var.event_subscriptions : [
        for w in [
          try(v.destination.webhook, null),
          try(v.delivery_with_resource_identity.destination.webhook, null),
        ] : w.minimum_tls_version_allowed == "1.2" if w != null
      ]
    ]))
    error_message = "Webhook destinations should require TLS 1.2. Set minimum_tls_version_allowed = \"1.2\" on each webhook destination."
  }
}
