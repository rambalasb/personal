locals {
  # managed-by/module mark the resource as wrapper-managed. Suppressible because
  # adopting an existing topic otherwise forces a write purely to add them.
  # Greenfield callers should leave this alone.
  wrapper_tags = var.wrapper_tags_enabled ? {
    managed-by = "terraform"
    module     = "tf-wrapper-avm-eventgrid-topic"
  } : {}

  module_tags = merge(
    var.tags == null ? {} : var.tags,
    local.wrapper_tags
  )
}
