output "resource_id" {
  description = "The resource ID of the Event Grid Topic."
  value       = module.eventgrid_topic.resource_id
}

output "name" {
  description = "The name of the Event Grid Topic."
  value       = module.eventgrid_topic.name
}

output "topic_id" {
  description = "The resource ID of the Event Grid Topic. Alias of resource_id, kept to match the upstream output surface."
  value       = module.eventgrid_topic.topic_id
}

output "topic_name" {
  description = "The name of the Event Grid Topic. Alias of name, kept to match the upstream output surface."
  value       = module.eventgrid_topic.topic_name
}

output "topic_location" {
  description = "The Azure region the Event Grid Topic was deployed to."
  value       = module.eventgrid_topic.topic_location
}

output "topic_tags" {
  description = "The tags applied to the Event Grid Topic, including the wrapper's own managed-by/module tags."
  value       = module.eventgrid_topic.topic_tags
}

output "identity" {
  description = "The managed identity block of the topic, including principal_id and tenant_id. Null when no identity is enabled."
  value       = module.eventgrid_topic.identity
}

output "system_assigned_mi_principal_id" {
  description = "Principal ID of the system-assigned managed identity. Use it to grant the topic RBAC on delivery destinations such as Storage Queues or Event Hubs."
  value       = module.eventgrid_topic.system_assigned_mi_principal_id
}

output "event_subscription_ids" {
  description = "Map of event subscriptions created on the topic, keyed by the input map key, to their resource IDs."
  value       = module.eventgrid_topic.event_subscription_ids
}

output "event_subscription_names" {
  description = "Map of event subscriptions created on the topic, keyed by the input map key, to their names."
  value       = module.eventgrid_topic.event_subscription_names
}

# The topic endpoint is not exported upstream and the access keys are deliberately
# not surfaced: local auth is disabled by default, so publishers should use Entra ID
# with the 'EventGrid Data Sender' role.
