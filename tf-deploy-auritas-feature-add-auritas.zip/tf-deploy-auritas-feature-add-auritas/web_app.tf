module "web_app" {
  for_each = var.enable_web_app ? var.web_app : {}
  source   = "app.terraform.io/BC_Hydro/tf-wrapper-avm-web-app/azurerm"
  version  = "0.0.4"

  name                                     = each.value.name
  resource_group_name                      = module.resource_group[each.value.resource_group_key].name
  subscription_id                          = var.subscription_id
  location                                 = coalesce(each.value.location, module.resource_group[each.value.resource_group_key].location)
  service_plan_resource_id                 = each.value.service_plan_resource_id
  os_type                                  = "Linux"
  client_affinity_enabled                  = each.value.client_affinity_enabled
  ftp_publish_basic_authentication_enabled = each.value.ftp_publish_basic_authentication_enabled
  https_only                               = each.value.https_only
  key_vault_reference_identity             = each.value.key_vault_reference_identity
  public_network_access_enabled            = each.value.public_network_access_enabled
  vnet_image_pull_enabled                  = each.value.vnet_image_pull_enabled
  scm_publish_basic_authentication_enabled = each.value.scm_publish_basic_authentication_enabled
  managed_identities                       = each.value.managed_identities
  site_config = merge(
    { for attribute, value in each.value.site_config : attribute => value if value != null },
    { application_stack = {} }
  )
  logs = each.value.logs
  tags = each.value.tags

  app_settings        = {}
  private_endpoints   = {}
  diagnostic_settings = {}
  deployment_slots    = {}
  backup              = {}
  certificates        = {}
  custom_domains      = {}
  connection_strings  = {}
  sticky_settings     = {}
  role_assignments    = {}
  lock                = null
  zip_deploy_file     = null
  enable_telemetry    = false
}

import {
  for_each = var.enable_web_app ? var.web_app_imports : {}
  to       = module.web_app[each.key].module.web_app.azapi_resource.this
  id       = "${each.value}?api-version=2025-03-01"
}