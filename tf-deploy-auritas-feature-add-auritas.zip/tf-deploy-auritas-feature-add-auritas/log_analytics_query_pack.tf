resource "azurerm_log_analytics_query_pack" "this" {
  for_each = var.enable_log_analytics_query_pack ? var.log_analytics_query_pack : {}

  name                = each.value.name
  resource_group_name = module.resource_group[each.value.resource_group_key].name
  location            = coalesce(each.value.location, module.resource_group[each.value.resource_group_key].location)
  tags                = each.value.tags

  lifecycle {
    prevent_destroy = true
  }
}

import {
  for_each = var.enable_log_analytics_query_pack ? var.log_analytics_query_pack_imports : {}

  to = azurerm_log_analytics_query_pack.this[each.key]
  id = each.value
}