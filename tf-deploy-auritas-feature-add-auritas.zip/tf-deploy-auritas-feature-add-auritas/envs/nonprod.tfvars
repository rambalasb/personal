# Sub-Auritas-NonProd (1193f1e2-8eb0-42a9-8d99-415231eaebc7)
# Values come from the Azure resource export of 2026-11-03.
# The jump VM (and its NIC) and the VNet are off for the first apply;
# adopt them in separate runs.

subscription_id = "1193f1e2-8eb0-42a9-8d99-415231eaebc7"

enable_resource_group           = true
enable_monitoring               = true
enable_app_service_environment  = true
enable_app_service_plan         = true
enable_application_insights     = true
enable_bastion_host             = true
enable_container_registry       = true
enable_event_grid_system_topic  = true
enable_windows_virtual_machine  = false
enable_log_analytics_workspace  = true
enable_nat_gateway              = true
enable_network_interface        = false
enable_network_watcher          = true
enable_private_dns_zone         = true
enable_private_endpoint         = true
enable_public_ip_prefix         = true
enable_recovery_services_vault  = true
enable_restore_point_collection = true
enable_storage_account          = true
enable_virtual_network          = false
enable_web_app                  = false
enable_function_app             = false

enable_resource_group_role_assignment           = false
enable_monitoring_role_assignment               = false
enable_app_service_environment_role_assignment  = false
enable_app_service_plan_role_assignment         = false
enable_application_insights_role_assignment     = false
enable_bastion_host_role_assignment             = false
enable_container_registry_role_assignment       = false
enable_event_grid_system_topic_role_assignment  = false
enable_windows_virtual_machine_role_assignment  = false
enable_log_analytics_workspace_role_assignment  = false
enable_nat_gateway_role_assignment              = false
enable_network_interface_role_assignment        = false
enable_network_watcher_role_assignment          = false
enable_private_dns_zone_role_assignment         = false
enable_private_endpoint_role_assignment         = false
enable_public_ip_prefix_role_assignment         = false
enable_recovery_services_vault_role_assignment  = false
enable_restore_point_collection_role_assignment = false
enable_storage_account_role_assignment          = false
enable_virtual_network_role_assignment          = false

role_assignments = {}

# AzureBackupRG_canadacentral_1 is left out: managedBy Microsoft.RecoveryServices; ARM rejects a PUT that drops it.
resource_group = {
  network = {
    name     = "rg-auritas-nonprod-network-canadacentral-001"
    location = "canadacentral"
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "NonProd"
    }
  }
  networkwatcherrg = {
    name     = "NetworkWatcherRG"
    location = "canadacentral"
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "NonProd"
    }
  }
  app = {
    name     = "rg-auritas-nonprod-app-canadacentral-001"
    location = "canadacentral"
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "NonProd"
    }
  }
  defaultresourcegroup_ccan = {
    name     = "DefaultResourceGroup-CCAN"
    location = "canadacentral"
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "NonProd"
    }
  }
  testrg = {
    name     = "testrg"
    location = "canadacentral"
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "NonProd"
    }
  }
}

import_resource_group = {
  network                   = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-network-canadacentral-001"
  networkwatcherrg          = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/NetworkWatcherRG"
  app                       = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-app-canadacentral-001"
  defaultresourcegroup_ccan = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/DefaultResourceGroup-CCAN"
  testrg                    = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/testrg"
}

alert = {
  resource_group_key         = "app"
  root_management_group_name = null
  tags                       = {}
  activity_log_alerts = {
    service_outage = {
      name                = "Service-Outage-Alert-CanadaCentral"
      resource_group_name = "rg-auritas-nonprod-network-canadacentral-001"
      scopes              = ["/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7"]
      location            = "global"
      description         = "Azure Landing Zone Service Health Alert"
      enabled             = true
      criteria = {
        category = "ServiceHealth"
      }
      action_group_keys = []
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-monitor-mail-alerts-canadacentral-001"
      ]
      webhook_properties = {}
      tags = {
        CostCenterId = "YT-02054.S.IMP"
        Environment  = "NonProd"
      }
    }
  }
  metric_alerts          = {}
  log_search_alerts      = {}
  alert_processing_rules = {}
}

activity_log_alert_imports = {
  service_outage = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-network-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/Service-Outage-Alert-CanadaCentral"
}

metric_alert_imports = {}

log_search_alert_imports = {}

alert_processing_rule_imports = {}

# zone_redundancy_enabled and the subnet force replacement; both match the export.
# The export reports dedicatedHostCount = 0; the wrapper only accepts null or 2.
app_service_environment = {
  app = {
    name                                   = "ase-auritas-nonprod-canadacentral"
    resource_group_key                     = "app"
    location                               = "canadacentral"
    subnet_id                              = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-auritas-nonprod-canadacentral-001/subnets/snet-auritas-nonprod-app-canadacentral-001"
    internal_load_balancing_mode           = "Web, Publishing"
    zone_redundancy_enabled                = true
    internal_encryption_enabled            = false
    ftp_enabled                            = false
    remote_debug_enabled                   = true
    allow_new_private_endpoint_connections = true
    tls_1_enabled                          = false # clusterSettings has DisableTls1.0 = 1
    inbound_ip_address_override            = null
    upgrade_preference                     = "None"
    dedicated_host_count                   = null
    system_assigned_identity               = false
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "NonProd"
    }
  }
}

app_service_environment_imports = {
  app = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-app-canadacentral-001/providers/Microsoft.Web/hostingEnvironments/ase-auritas-nonprod-canadacentral"
}

app_service_plan = {
  app = {
    name                            = "asp-auritas-nonprod-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    os_type                         = "Linux"
    sku_name                        = "I1v2"
    worker_count                    = 2
    maximum_elastic_worker_count    = 2
    per_site_scaling_enabled        = false
    premium_plan_auto_scale_enabled = false
    zone_balancing_enabled          = false
    app_service_environment_id      = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-app-canadacentral-001/providers/Microsoft.Web/hostingEnvironments/ase-auritas-nonprod-canadacentral"
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "NonProd"
    }
  }
}

app_service_plan_imports = {
  app = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-app-canadacentral-001/providers/Microsoft.Web/serverFarms/asp-auritas-nonprod-canadacentral-001"
}

# The daily cap is not in the export (100 is the provider default); confirm with
# az monitor app-insights component billing show.
application_insights = {
  app = {
    name                          = "ai-auritas-nonprod-canadacentral-001"
    resource_group_key            = "app"
    location                      = "canadacentral"
    workspace_id                  = "/subscriptions/7d54d6f7-83d9-48cf-ac35-1068bcfd0561/resourceGroups/rg-siem-security-canadacentral-001/providers/Microsoft.OperationalInsights/workspaces/la-siem-security-canadacentral-001"
    application_type              = "web"
    retention_in_days             = 90
    daily_data_cap_in_gb          = 100
    sampling_percentage           = 100
    internet_ingestion_enabled    = true
    internet_query_enabled        = true
    local_authentication_disabled = false
    disable_ip_masking            = false
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "NonProd"
    }
  }
}

application_insights_imports = {
  app = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-app-canadacentral-001/providers/Microsoft.Insights/components/ai-auritas-nonprod-canadacentral-001"
}

bastion_host = {
  app = {
    name               = "bh-auritas-nonprod-canadacentral-001"
    resource_group_key = "network"
    location           = "canadacentral"
    sku                = "Developer"
    scale_units        = 2
    virtual_network_id = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-auritas-nonprod-canadacentral-001"
    zones              = []
    copy_paste_enabled = true
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "NonProd"
    }
  }
}

bastion_host_imports = {
  app = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-network-canadacentral-001/providers/Microsoft.Network/bastionHosts/bh-auritas-nonprod-canadacentral-001"
}

# zone_redundancy_enabled forces replacement. Retention is disabled on the live
# registry, so retention_policy_in_days stays null; admin_enabled matches the export.
container_registry = {}

# Public network access is enabled on these, and Deny_Public_Access_On_PaaS_Services_v0
# denies any write to them, so they are read, not adopted, until exempted.
container_registry_existing = {
  app = {
    name               = "acrauritasnonprod"
    resource_group_key = "app"
  }
}

container_registry_imports = {}

event_grid_system_topic = {
  app_storage = {
    name                        = "stauritasnonprodcac01-f0867302-558c-4114-8ba0-ab369a55c997"
    resource_group_key          = "app"
    location                    = "canadacentral"
    topic_type                  = "microsoft.storage.storageaccounts"
    source_resource_id          = null
    exported_source_resource_id = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-app-canadacentral-001/providers/microsoft.storage/storageaccounts/stauritasnonprodcac01"
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "NonProd"
    }
  }
  network_watcher_storage = {
    name                        = "stnwauritasnprdcac001xdf-937215f4-e62b-44d8-947c-f80154b81052"
    resource_group_key          = "networkwatcherrg"
    location                    = "canadacentral"
    topic_type                  = "microsoft.storage.storageaccounts"
    source_resource_id          = null
    exported_source_resource_id = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/networkwatcherrg/providers/microsoft.storage/storageaccounts/stnwauritasnprdcac001xdf"
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "NonProd"
    }
  }
}

event_grid_system_topic_imports = {
  app_storage             = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-app-canadacentral-001/providers/Microsoft.EventGrid/systemTopics/stauritasnonprodcac01-f0867302-558c-4114-8ba0-ab369a55c997"
  network_watcher_storage = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/NetworkWatcherRG/providers/Microsoft.EventGrid/systemTopics/stnwauritasnprdcac001xdf-937215f4-e62b-44d8-947c-f80154b81052"
}

# Switched off for the first apply; adopt in its own run. The admin password goes in
# the sensitive variable windows_virtual_machine_admin_passwords, never in tfvars.
# The OS disk is owned inline; extensions stay unmanaged.
windows_virtual_machine = {
  jump = {
    name               = "auritascacjumpp1"
    resource_group_key = "app"
    location           = "canadacentral"
    size               = "Standard_E2s_v3"
    zone               = "1"
    admin_username     = "azauritasuser"
    computer_name      = "auritascacjumpp"
    network_interface_ids = [
      "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-app-canadacentral-001/providers/Microsoft.Network/networkInterfaces/auritascacjumpp1365_z1"
    ]
    os_managed_disk_id                                     = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-app-canadacentral-001/providers/Microsoft.Compute/disks/auritascacjumpp1_OsDisk_1_77a95712ff464e9d8ce00a25a78dc577"
    allow_extension_operations                             = true
    automatic_updates_enabled                              = true
    bypass_platform_safety_checks_on_user_schedule_enabled = true
    disk_controller_type                                   = "SCSI"
    encryption_at_host_enabled                             = false
    license_type                                           = "Windows_Server"
    patch_assessment_mode                                  = "AutomaticByPlatform"
    patch_mode                                             = "AutomaticByPlatform"
    provision_vm_agent                                     = true
    secure_boot_enabled                                    = true
    vtpm_enabled                                           = true
    additional_capabilities = {
      hibernation_enabled = false
    }
    boot_diagnostics = {}
    identity = {
      type                       = "SystemAssigned"
      user_assigned_identity_ids = []
    }
    os_disk = {
      name                 = "auritascacjumpp1_OsDisk_1_77a95712ff464e9d8ce00a25a78dc577"
      caching              = "ReadWrite"
      disk_size_gb         = 127
      storage_account_type = "Premium_LRS"
    }
    source_image_reference = {
      publisher = "MicrosoftWindowsServer"
      offer     = "WindowsServer"
      sku       = "2025-datacenter-azure-edition"
      version   = "latest"
    }
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "NonProd"
    }
    vm_agent_platform_updates_enabled = true
  }
}

windows_virtual_machine_imports = {
  jump = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-app-canadacentral-001/providers/Microsoft.Compute/virtualMachines/auritascacjumpp1"
}

# Created by the platform (Defender/AMA default workspace).
log_analytics_workspace = {
  default_ccan = {
    name                            = "DefaultWorkspace-1193f1e2-8eb0-42a9-8d99-415231eaebc7-CCAN"
    resource_group_key              = "defaultresourcegroup_ccan"
    location                        = "canadacentral"
    sku                             = "PerGB2018"
    retention_in_days               = 30
    daily_quota_gb                  = -1
    internet_ingestion_enabled      = "true"
    internet_query_enabled          = "true"
    local_authentication_enabled    = true
    allow_resource_only_permissions = true
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "NonProd"
    }
  }
}

log_analytics_workspace_imports = {
  default_ccan = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/DefaultResourceGroup-CCAN/providers/Microsoft.OperationalInsights/workspaces/DefaultWorkspace-1193f1e2-8eb0-42a9-8d99-415231eaebc7-CCAN"
}

nat_gateway = {
  app = {
    name                    = "ngw-auritas-nonprod-canadacentral-001"
    resource_group_key      = "network"
    location                = "canadacentral"
    sku_name                = "Standard"
    idle_timeout_in_minutes = 10
    public_ip_prefix_resource_ids = [
      "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-network-canadacentral-001/providers/Microsoft.Network/publicIPPrefixes/pip-ngw-auritas-nonprod-canadacentral-001"
    ]
    zones = []
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "NonProd"
    }
  }
}

nat_gateway_imports = {
  app = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-network-canadacentral-001/providers/Microsoft.Network/natGateways/ngw-auritas-nonprod-canadacentral-001"
}

network_interface = {
  jump_primary = {
    name                           = "auritascacjumpp1365_z1"
    resource_group_key             = "app"
    location                       = "canadacentral"
    enabled                        = true
    accelerated_networking_enabled = true
    ip_forwarding_enabled          = false
    ip_configurations = {
      primary = {
        name                          = "ipconfig1"
        primary                       = true
        private_ip_address            = "10.195.121.197"
        private_ip_address_allocation = "Dynamic"
        subnet_id                     = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-auritas-nonprod-canadacentral-001/subnets/snet-auritas-nonprod-pep-canadacentral-001"
      }
    }
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "NonProd"
    }
  }
}

# No NIC-level NSGs.
network_interface_nsg_associations = {}

# Their VNet flow logs stay unmanaged.
network_watcher = {
  canadacentral = {
    name               = "NetworkWatcher_canadacentral"
    resource_group_key = "networkwatcherrg"
    location           = "canadacentral"
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "NonProd"
    }
  }
}

network_watcher_imports = {
  canadacentral = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/NetworkWatcherRG/providers/Microsoft.Network/networkWatchers/NetworkWatcher_canadacentral"
}

private_dns_zone = {
  ase = {
    name               = "ase-auritas-nonprod-canadacentral.appserviceenvironment.net"
    resource_group_key = "app"
    virtual_network_links = {
      link_vnet_auritas_nonprod_canadacentral_001 = {
        name                 = "link-vnet-auritas-nonprod-canadacentral-001"
        virtual_network_id   = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-auritas-nonprod-canadacentral-001"
        registration_enabled = false
        resolution_policy    = "Default"
        tags = {
          CostCenterId = "YT-02054.S.IMP"
          Environment  = "NonProd"
        }
      }
      link_dns_connectivity_001 = {
        name                 = "link-dns-connectivity-001"
        virtual_network_id   = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dns-connectivity-canadacentral-001"
        registration_enabled = false
        resolution_policy    = "Default"
        tags = {
          CostCenterId = "YT-02054.S.IMP"
          Environment  = "NonProd"
        }
      }
    }
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "NonProd"
    }
  }
  backup = {
    name                  = "privatelink.cnc.backup.windowsazure.com"
    resource_group_key    = "network"
    virtual_network_links = {}
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "NonProd"
    }
  }
}

private_dns_zone_imports = {
  ase    = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-app-canadacentral-001/providers/Microsoft.Network/privateDnsZones/ase-auritas-nonprod-canadacentral.appserviceenvironment.net"
  backup = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-network-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.cnc.backup.windowsazure.com"
}

private_dns_zone_link_imports = {
  "ase/link_vnet_auritas_nonprod_canadacentral_001" = {
    zone_key = "ase"
    link_key = "link_vnet_auritas_nonprod_canadacentral_001"
    id       = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-app-canadacentral-001/providers/Microsoft.Network/privateDnsZones/ase-auritas-nonprod-canadacentral.appserviceenvironment.net/virtualNetworkLinks/link-vnet-auritas-nonprod-canadacentral-001"
  }
  "ase/link_dns_connectivity_001" = {
    zone_key = "ase"
    link_key = "link_dns_connectivity_001"
    id       = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-app-canadacentral-001/providers/Microsoft.Network/privateDnsZones/ase-auritas-nonprod-canadacentral.appserviceenvironment.net/virtualNetworkLinks/link-dns-connectivity-001"
  }
}

# pep-app-auritas-nonprod-canadacentral-001, pep-appauritasnonprodcac: the connection to the site is Disconnected.
# They stay switched off (enabled = false); delete them in Azure or adopt them deliberately.
private_endpoint = {
  storage_blob = {
    enabled                         = true
    name                            = "pep-stauritasnonprodcac01"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-auritas-nonprod-canadacentral-001/subnets/snet-auritas-nonprod-pep-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-app-canadacentral-001/providers/Microsoft.Storage/storageAccounts/stauritasnonprodcac01"
    private_service_connection_name = "stauritasnonprodcac01"
    subresource_names               = ["blob"]
    network_interface_name          = null
    private_dns_zone_group_name     = "privatelink.blob.core.windows.net"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net"
    ]
    ip_configurations = {}
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "NonProd"
    }
  }
  web_app_disconnected = {
    enabled                         = false
    name                            = "pep-app-auritas-nonprod-canadacentral-001"
    resource_group_key              = "network"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-auritas-nonprod-canadacentral-001/subnets/snet-auritas-nonprod-pep-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-app-canadacentral-001/providers/Microsoft.Web/sites/app-auritas-nonprod-canadacentral-001"
    private_service_connection_name = "pep-app-auritas-nonprod-canadacentral-001-aa37"
    subresource_names               = ["sites"]
    network_interface_name          = null
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids   = []
    ip_configurations               = {}
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "NonProd"
    }
  }
  web_app = {
    enabled                         = true
    name                            = "pep-app-auritas-nonprod-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-auritas-nonprod-canadacentral-001/subnets/snet-auritas-nonprod-pep-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-app-canadacentral-001/providers/Microsoft.Web/sites/app-auritas-nonprod-canadacentral-001"
    private_service_connection_name = "pep-app-auritas-nonprod-canadacentral-001"
    subresource_names               = ["sites"]
    network_interface_name          = "pep-app-auritas-nonprod-canadacentral-001-nic"
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-app-canadacentral-001/providers/Microsoft.Network/privateDnsZones/ase-auritas-nonprod-canadacentral.appserviceenvironment.net"
    ]
    ip_configurations = {}
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "NonProd"
    }
  }
  function_app = {
    enabled                         = true
    name                            = "pep-func-auritas-nonprod-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-auritas-nonprod-canadacentral-001/subnets/snet-auritas-nonprod-pep-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourcegroups/rg-auritas-nonprod-app-canadacentral-001/providers/Microsoft.Web/sites/funcauritasnonprodcac"
    private_service_connection_name = "pep-func-auritas-nonprod-canadacentral-001"
    subresource_names               = ["sites"]
    network_interface_name          = "pep-func-auritas-nonprod-canadacentral-001-nic"
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-app-canadacentral-001/providers/Microsoft.Network/privateDnsZones/ase-auritas-nonprod-canadacentral.appserviceenvironment.net"
    ]
    ip_configurations = {
      pep_func_auritas_nonprod_canadacentral_001 = {
        name               = "pep-func-auritas-nonprod-canadacentral-001"
        private_ip_address = "10.195.121.200"
        subresource_name   = "sites"
        member_name        = "sites"
      }
    }
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "NonProd"
    }
  }
  network_watcher_storage = {
    enabled                         = true
    name                            = "pep-stnwauritasnprdcac001xdf"
    resource_group_key              = "networkwatcherrg"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-auritas-nonprod-canadacentral-001/subnets/snet-auritas-nonprod-pep-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/NetworkWatcherRG/providers/Microsoft.Storage/storageAccounts/stnwauritasnprdcac001xdf"
    private_service_connection_name = "pep-stnwauritasnprdcac001xdf"
    subresource_names               = ["blob"]
    network_interface_name          = "pep-stnwauritasnprdcac001xdf-nic"
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net"
    ]
    ip_configurations = {}
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "NonProd"
    }
  }
  web_app_disconnected_2 = {
    enabled                         = false
    name                            = "pep-appauritasnonprodcac"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-auritas-nonprod-canadacentral-001/subnets/snet-auritas-nonprod-pep-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-app-canadacentral-001/providers/Microsoft.Web/sites/app-auritas-nonprod-canadacentral-001"
    private_service_connection_name = "pep-appauritasnonprodcac"
    subresource_names               = ["sites"]
    network_interface_name          = "pep-appauritasnonprodcac-nic"
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids   = []
    ip_configurations               = {}
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "NonProd"
    }
  }
  backup = {
    enabled                         = true
    name                            = "pep-rsv-auritas-nonprod-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-auritas-nonprod-canadacentral-001/subnets/snet-auritas-nonprod-pep-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourcegroups/rg-auritas-nonprod-app-canadacentral-001/providers/Microsoft.RecoveryServices/vaults/rsv-auritas-nonprod-canadacentral-001"
    private_service_connection_name = "pep-rsv-auritas-nonprod-canadacentral-001_4741b5b8-1613-4db5-92f8-407297b0b021"
    subresource_names               = ["AzureBackup"]
    network_interface_name          = null
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net",
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.cnc.backup.windowsazure.com",
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.queue.core.windows.net"
    ]
    ip_configurations = {}
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "NonProd"
    }
  }
}

private_endpoint_imports = {
  storage_blob            = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-app-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-stauritasnonprodcac01"
  web_app_disconnected    = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-network-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-app-auritas-nonprod-canadacentral-001"
  web_app                 = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-app-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-app-auritas-nonprod-canadacentral-001"
  function_app            = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-app-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-func-auritas-nonprod-canadacentral-001"
  network_watcher_storage = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/NetworkWatcherRG/providers/Microsoft.Network/privateEndpoints/pep-stnwauritasnprdcac001xdf"
  web_app_disconnected_2  = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-app-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-appauritasnonprodcac"
  backup                  = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-app-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-rsv-auritas-nonprod-canadacentral-001"
}

public_ip_prefix = {
  nat_gateway = {
    name               = "pip-ngw-auritas-nonprod-canadacentral-001"
    resource_group_key = "network"
    location           = "canadacentral"
    prefix_length      = 31
    ip_version         = "IPv4"
    sku_name           = "Standard"
    sku_tier           = "Regional"
    zones              = []
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "NonProd"
    }
  }
}

public_ip_prefix_imports = {
  nat_gateway = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-network-canadacentral-001/providers/Microsoft.Network/publicIPPrefixes/pip-ngw-auritas-nonprod-canadacentral-001"
}

# monitoringSettings is null on the live vault; alert flags default to false
# so adoption does not switch alerting on.
recovery_services_vault = {
  app = {
    name                          = "rsv-auritas-nonprod-canadacentral-001"
    resource_group_key            = "app"
    location                      = "canadacentral"
    sku                           = "RS0"
    storage_mode_type             = "GeoRedundant"
    cross_region_restore_enabled  = false
    soft_delete_enabled           = true
    immutability                  = "Disabled"
    public_network_access_enabled = false
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "NonProd"
    }
  }
}

recovery_services_vault_imports = {
  app = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-app-canadacentral-001/providers/Microsoft.RecoveryServices/vaults/rsv-auritas-nonprod-canadacentral-001"
}

# Azure Backup owns these; only the containers are adopted.
restore_point_collection = {
  jump = {
    name                      = "AzureBackup_auritascacjumpp1_6310633795160452588"
    resource_group_name       = "AzureBackupRG_canadacentral_1"
    location                  = "canadacentral"
    source_virtual_machine_id = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-app-canadacentral-001/providers/Microsoft.Compute/virtualMachines/auritascacjumpp1"
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "NonProd"
    }
  }
}

restore_point_collection_imports = {
  jump = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/AzureBackupRG_canadacentral_1/providers/Microsoft.Compute/restorePointCollections/AzureBackup_auritascacjumpp1_6310633795160452588"
}

# Blob service properties were not exported, so blob_properties stays null.
storage_account = {
  app = {
    name                              = "stauritasnonprodcac01"
    resource_group_key                = "app"
    location                          = "canadacentral"
    account_kind                      = "StorageV2"
    account_tier                      = "Standard"
    account_replication_type          = "ZRS"
    access_tier                       = "Hot"
    allow_nested_items_to_be_public   = false
    cross_tenant_replication_enabled  = false
    default_to_oauth_authentication   = false
    https_traffic_only_enabled        = true
    infrastructure_encryption_enabled = false
    is_hns_enabled                    = false
    large_file_share_enabled          = null
    min_tls_version                   = "TLS1_2"
    public_network_access_enabled     = false
    sftp_enabled                      = false
    shared_access_key_enabled         = true
    blob_properties                   = null
    network_rules = {
      bypass                     = ["AzureServices"]
      default_action             = "Deny"
      ip_rules                   = []
      virtual_network_subnet_ids = []
      private_link_access = [
        {
          endpoint_resource_id = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/providers/Microsoft.Security/datascanners/storageDataScanner"
          endpoint_tenant_id   = "8fbb85e8-0cbc-48c3-a2e9-528cef30ec27"
        }
      ]
    }
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "NonProd"
    }
  }
  network_watcher = {
    name                              = "stnwauritasnprdcac001xdf"
    resource_group_key                = "networkwatcherrg"
    location                          = "canadacentral"
    account_kind                      = "StorageV2"
    account_tier                      = "Standard"
    account_replication_type          = "LRS"
    access_tier                       = "Hot"
    allow_nested_items_to_be_public   = false
    cross_tenant_replication_enabled  = false
    default_to_oauth_authentication   = true
    https_traffic_only_enabled        = true
    infrastructure_encryption_enabled = false
    is_hns_enabled                    = false
    large_file_share_enabled          = null
    min_tls_version                   = "TLS1_2"
    public_network_access_enabled     = false
    sftp_enabled                      = false
    shared_access_key_enabled         = false
    blob_properties                   = null
    network_rules = {
      bypass                     = ["AzureServices"]
      default_action             = "Deny"
      ip_rules                   = []
      virtual_network_subnet_ids = []
      private_link_access = [
        {
          endpoint_resource_id = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/providers/Microsoft.Security/datascanners/storageDataScanner"
          endpoint_tenant_id   = "8fbb85e8-0cbc-48c3-a2e9-528cef30ec27"
        }
      ]
    }
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "NonProd"
    }
  }
}

storage_account_existing = {}

storage_account_imports = {
  app             = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-app-canadacentral-001/providers/Microsoft.Storage/storageAccounts/stauritasnonprodcac01"
  network_watcher = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/NetworkWatcherRG/providers/Microsoft.Storage/storageAccounts/stnwauritasnprdcac001xdf"
}

# vnet-auritas-nonprod-canadacentral-001 peerings (unmanaged): RemoteVnetToHubPeering_a8db0ae7-e4bd-4112-a74f-86be5b004e19
# Disabled for now, as in Fit and Fabric: the VNet module's body omits subnets and
# peerings, so the import plan removes them, and the only peering is the vWAN
# hub connection owned by tf-deploy-platform-connectivity. Adopt it with the
# connectivity team on hand to restore the hub connection.
# defaultOutboundAccess is taken from the export where reported, otherwise Azure's
# default (enabled). It is create-time only, so a replace in the plan means the
# value is wrong. The hub peering stays unmanaged.
virtual_network = {
  app = {
    name               = "vnet-auritas-nonprod-canadacentral-001"
    resource_group_key = "network"
    location           = "canadacentral"
    address_space      = ["10.195.121.128/25"]
    dns_servers = {
      dns_servers = ["10.195.1.4"]
    }
    ddos_protection_plan = {
      enable = true
      id     = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/ddosProtectionPlans/ddos-protection-plan"
    }
    encryption = {
      enabled     = false
      enforcement = "AllowUnencrypted"
    }
    subnets = {
      pep = {
        name                                          = "snet-auritas-nonprod-pep-canadacentral-001"
        address_prefixes                              = ["10.195.121.192/26"]
        default_outbound_access_enabled               = true
        private_endpoint_network_policies             = "RouteTableEnabled"
        private_link_service_network_policies_enabled = true
        nat_gateway = {
          id = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-network-canadacentral-001/providers/Microsoft.Network/natGateways/ngw-auritas-nonprod-canadacentral-001"
        }
        service_endpoint_policies       = {}
        service_endpoints_with_location = []
        delegations                     = []
      }
      app = {
        name                                          = "snet-auritas-nonprod-app-canadacentral-001"
        address_prefixes                              = ["10.195.121.128/26"]
        default_outbound_access_enabled               = true
        private_endpoint_network_policies             = "RouteTableEnabled"
        private_link_service_network_policies_enabled = true
        nat_gateway = {
          id = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-network-canadacentral-001/providers/Microsoft.Network/natGateways/ngw-auritas-nonprod-canadacentral-001"
        }
        service_endpoint_policies       = {}
        service_endpoints_with_location = []
        delegations = [
          {
            name = "Microsoft.Web.hostingEnvironments"
            service_delegation = {
              name    = "Microsoft.Web/hostingEnvironments"
              actions = ["Microsoft.Network/virtualNetworks/subnets/action"]
            }
          }
        ]
      }
    }
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "NonProd"
    }
  }
}

virtual_network_imports = {
  app = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-auritas-nonprod-canadacentral-001"
}

virtual_network_subnet_imports = {
  app_pep = {
    vnet_key   = "app"
    subnet_key = "pep"
    id         = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-auritas-nonprod-canadacentral-001/subnets/snet-auritas-nonprod-pep-canadacentral-001"
  }
  app_app = {
    vnet_key   = "app"
    subnet_key = "app"
    id         = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-auritas-nonprod-canadacentral-001/subnets/snet-auritas-nonprod-app-canadacentral-001"
  }
}

web_app = {
  auritas_nonprod = {
    name                                     = "app-auritas-nonprod-canadacentral-001"
    resource_group_key                       = "app"
    location                                 = "canadacentral"
    service_plan_resource_id                 = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-app-canadacentral-001/providers/Microsoft.Web/serverFarms/asp-auritas-nonprod-canadacentral-001"
    client_affinity_enabled                  = true
    https_only                               = true
    key_vault_reference_identity             = "SystemAssigned"
    public_network_access_enabled            = false
    vnet_image_pull_enabled                  = true
    scm_publish_basic_authentication_enabled = false
    managed_identities = {
      system_assigned = true
    }
    site_config = {
      default_documents = [
        "Default.htm", "Default.html", "Default.asp", "index.htm",
        "index.html", "iisstart.htm", "default.aspx", "index.php",
        "hostingstart.html"
      ]
      remote_debugging_version = "VS2022"
      worker_count             = 1
    }
    logs = {
      main = {
        http_logs = {
          main = {
            file_system = {
              retention_in_days = 90
              retention_in_mb   = 35
            }
          }
        }
      }
    }
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "NonProd"
    }
  }
}

web_app_imports = {
  auritas_nonprod = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-app-canadacentral-001/providers/Microsoft.Web/sites/app-auritas-nonprod-canadacentral-001"
}

function_app = {
  "auritas_nonprod" = {
    name                                     = "funcauritasnonprodcac"
    resource_group_key                       = "app"
    location                                 = "canadacentral"
    service_plan_resource_id                 = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-app-canadacentral-001/providers/Microsoft.Web/serverFarms/asp-auritas-nonprod-canadacentral-001"
    os_type                                  = "Linux"
    function_app_uses_fc1                    = false
    builtin_logging_enabled                  = false
    client_certificate_mode                  = "Required"
    ftp_publish_basic_authentication_enabled = false
    scm_publish_basic_authentication_enabled = false
    functions_extension_version              = ""
    key_vault_reference_identity             = "SystemAssigned"
    public_network_access_enabled            = false
    vnet_image_pull_enabled                  = true
    app_settings                             = {}
    managed_identities                       = {}
    site_config = {
      always_on                         = true
      default_documents                 = ["Default.htm", "Default.html", "Default.asp", "index.htm", "index.html", "iisstart.htm", "default.aspx", "index.php"]
      elastic_instance_minimum          = 1
      ftps_state                        = "FtpsOnly"
      ip_restriction_default_action     = ""
      remote_debugging_version          = "VS2022"
      scm_ip_restriction_default_action = ""
      worker_count                      = 1
      cors = {
        allowed_origins     = ["https://app-auritas-nonprod-canadacentral-001.ase-auritas-nonprod-canadacentral.appserviceenvironment.net", "https://appauritasnonprodcac.internal.bchydro.bc.ca"]
        support_credentials = true
      }
    }
    tags = {
      CostCenterId                             = "YT-02054.S.IMP"
      Environment                              = "NonProd"
      "hidden-link: /app-insights-resource-id" = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-app-canadacentral-001/providers/microsoft.insights/components/ai-auritas-nonprod-canadacentral-001"
    }
  }
}

function_app_imports = {
  "auritas_nonprod" = "/subscriptions/1193f1e2-8eb0-42a9-8d99-415231eaebc7/resourceGroups/rg-auritas-nonprod-app-canadacentral-001/providers/Microsoft.Web/sites/funcauritasnonprodcac"
}
