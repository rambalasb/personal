# Sub-Auritas-Prod (a91a891c-4a13-426c-972a-0ddea5db8f07)
# Values come from the Azure resource export of 2026-11-03.
# The VNet is off for the first apply; adopt it in a separate run.

subscription_id = "a91a891c-4a13-426c-972a-0ddea5db8f07"

enable_resource_group           = true
enable_monitoring               = true
enable_app_service_environment  = true
enable_app_service_plan         = true
enable_application_insights     = true
enable_bastion_host             = false
enable_container_registry       = true
enable_event_grid_system_topic  = false
enable_windows_virtual_machine  = false
enable_log_analytics_workspace  = true
enable_nat_gateway              = true
enable_network_interface        = false
enable_network_watcher          = true
enable_private_dns_zone         = true
enable_private_endpoint         = true
enable_public_ip_prefix         = true
enable_recovery_services_vault  = false
enable_restore_point_collection = false
enable_storage_account          = true
enable_virtual_network          = false
enable_web_app                  = false
enable_function_app             = false
enable_log_analytics_query_pack = true

enable_resource_group_role_assignment           = false
enable_monitoring_role_assignment               = false
enable_app_service_environment_role_assignment  = false
enable_app_service_plan_role_assignment         = false
enable_application_insights_role_assignment     = false
enable_bastion_host_role_assignment             = false
enable_container_registry_role_assignment       = false
enable_event_grid_system_topic_role_assignment  = false
enable_windows_virtual_machine_role_assignment  = false
enable_log_analytics_workspace_role_assignment  = false
enable_nat_gateway_role_assignment              = false
enable_network_interface_role_assignment        = false
enable_network_watcher_role_assignment          = false
enable_private_dns_zone_role_assignment         = false
enable_private_endpoint_role_assignment         = false
enable_public_ip_prefix_role_assignment         = false
enable_recovery_services_vault_role_assignment  = false
enable_restore_point_collection_role_assignment = false
enable_storage_account_role_assignment          = false
enable_virtual_network_role_assignment          = false

role_assignments = {}

# The existing CanNotDelete locks are separate resources and stay unmanaged.
resource_group = {
  app = {
    name     = "rg-auritas-prod-app-canadacentral-001"
    location = "canadacentral"
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "Prod"
    }
  }
  network = {
    name     = "rg-auritas-prod-network-canadacentral-001"
    location = "canadacentral"
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "Prod"
    }
  }
  networkwatcherrg = {
    name     = "NetworkWatcherRG"
    location = "canadacentral"
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "Prod"
    }
  }
  defaultresourcegroup_ccan = {
    name     = "DefaultResourceGroup-CCAN"
    location = "canadacentral"
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "Prod"
    }
  }
  loganalyticsdefaultresources = {
    name     = "LogAnalyticsDefaultResources"
    location = "canadacentral"
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "Prod"
    }
  }
}

import_resource_group = {
  app                          = "/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07/resourceGroups/rg-auritas-prod-app-canadacentral-001"
  network                      = "/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07/resourceGroups/rg-auritas-prod-network-canadacentral-001"
  networkwatcherrg             = "/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07/resourceGroups/NetworkWatcherRG"
  defaultresourcegroup_ccan    = "/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07/resourceGroups/DefaultResourceGroup-CCAN"
  loganalyticsdefaultresources = "/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07/resourceGroups/LogAnalyticsDefaultResources"
}

alert = {
  resource_group_key         = "app"
  root_management_group_name = null
  tags                       = {}
  activity_log_alerts = {
    service_outage = {
      name                = "Service-Outage-Alert-CanadaCentral"
      resource_group_name = "rg-auritas-prod-app-canadacentral-001"
      scopes              = ["/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07"]
      location            = "global"
      description         = "Azure Landing Zone Service Health Alert"
      enabled             = true
      criteria = {
        category = "ServiceHealth"
      }
      action_group_keys = []
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-monitor-mail-alerts-canadacentral-001"
      ]
      webhook_properties = {}
      tags = {
        CostCenterId = "YT-02054.S.IMP"
        Environment  = "Prod"
      }
    }
  }
  metric_alerts          = {}
  log_search_alerts      = {}
  alert_processing_rules = {}
}

activity_log_alert_imports = {
  service_outage = "/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07/resourceGroups/rg-auritas-prod-app-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/Service-Outage-Alert-CanadaCentral"
}

metric_alert_imports = {}

log_search_alert_imports = {}

alert_processing_rule_imports = {}

# zone_redundancy_enabled and the subnet force replacement; both match the export.
# The export reports dedicatedHostCount = 0; the wrapper only accepts null or 2.
app_service_environment = {
  app = {
    name                                   = "ase-auritas-prod-canadacentral"
    resource_group_key                     = "app"
    location                               = "canadacentral"
    subnet_id                              = "/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07/resourceGroups/rg-auritas-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-auritas-prod-canadacentral-001/subnets/snet-auritas-prod-app-canadacentral-001"
    internal_load_balancing_mode           = "Web, Publishing"
    zone_redundancy_enabled                = true
    internal_encryption_enabled            = false
    ftp_enabled                            = false
    remote_debug_enabled                   = true
    allow_new_private_endpoint_connections = true
    tls_1_enabled                          = false # clusterSettings has DisableTls1.0 = 1
    inbound_ip_address_override            = null
    upgrade_preference                     = "None"
    dedicated_host_count                   = null
    system_assigned_identity               = false
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "Prod"
    }
  }
}

app_service_environment_imports = {
  app = "/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07/resourceGroups/rg-auritas-prod-app-canadacentral-001/providers/Microsoft.Web/hostingEnvironments/ase-auritas-prod-canadacentral"
}

app_service_plan = {
  app = {
    name                            = "asp-auritas-prod-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    os_type                         = "Linux"
    sku_name                        = "I1v2"
    worker_count                    = 2
    maximum_elastic_worker_count    = 2
    per_site_scaling_enabled        = false
    premium_plan_auto_scale_enabled = false
    zone_balancing_enabled          = true
    app_service_environment_id      = "/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07/resourceGroups/rg-auritas-prod-app-canadacentral-001/providers/Microsoft.Web/hostingEnvironments/ase-auritas-prod-canadacentral"
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "Prod"
    }
  }
}

app_service_plan_imports = {
  app = "/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07/resourceGroups/rg-auritas-prod-app-canadacentral-001/providers/Microsoft.Web/serverFarms/asp-auritas-prod-canadacentral-001"
}

# The daily cap is not in the export (100 is the provider default); confirm with
# az monitor app-insights component billing show.
application_insights = {
  app = {
    name                          = "ai-auritas-prod-canadacentral-001"
    resource_group_key            = "app"
    location                      = "canadacentral"
    workspace_id                  = "/subscriptions/7d54d6f7-83d9-48cf-ac35-1068bcfd0561/resourceGroups/rg-siem-security-canadacentral-001/providers/Microsoft.OperationalInsights/workspaces/la-siem-security-canadacentral-001"
    application_type              = "web"
    retention_in_days             = 90
    daily_data_cap_in_gb          = 100
    sampling_percentage           = null
    internet_ingestion_enabled    = true
    internet_query_enabled        = true
    local_authentication_disabled = false
    disable_ip_masking            = false
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "Prod"
    }
  }
}

application_insights_imports = {
  app = "/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07/resourceGroups/rg-auritas-prod-app-canadacentral-001/providers/Microsoft.Insights/components/ai-auritas-prod-canadacentral-001"
}

bastion_host = {}

bastion_host_imports = {}

# zone_redundancy_enabled forces replacement. Retention is disabled on the live
# registry, so retention_policy_in_days stays null; admin_enabled matches the export.
container_registry = {}

# Public network access is enabled on these, and Deny_Public_Access_On_PaaS_Services_v0
# denies any write to them, so they are read, not adopted, until exempted.
container_registry_existing = {
  app = {
    name               = "acrauritasprod"
    resource_group_key = "app"
  }
}

container_registry_imports = {}

event_grid_system_topic = {}

event_grid_system_topic_imports = {}

windows_virtual_machine = {}

windows_virtual_machine_admin_passwords = {}

windows_virtual_machine_imports = {}

# Created by the platform (Defender/AMA default workspace).
log_analytics_workspace = {
  default_ccan = {
    name                            = "DefaultWorkspace-a91a891c-4a13-426c-972a-0ddea5db8f07-CCAN"
    resource_group_key              = "defaultresourcegroup_ccan"
    location                        = "canadacentral"
    sku                             = "PerGB2018"
    retention_in_days               = 30
    daily_quota_gb                  = -1
    internet_ingestion_enabled      = "true"
    internet_query_enabled          = "true"
    local_authentication_enabled    = true
    allow_resource_only_permissions = true
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "Prod"
    }
  }
}

log_analytics_workspace_imports = {
  default_ccan = "/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07/resourceGroups/DefaultResourceGroup-CCAN/providers/Microsoft.OperationalInsights/workspaces/DefaultWorkspace-a91a891c-4a13-426c-972a-0ddea5db8f07-CCAN"
}

nat_gateway = {
  app = {
    name                    = "ngw-auritas-prod-canadacentral-001"
    resource_group_key      = "network"
    location                = "canadacentral"
    sku_name                = "StandardV2"
    idle_timeout_in_minutes = 10
    public_ip_prefix_resource_ids = [
      "/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07/resourceGroups/rg-auritas-prod-network-canadacentral-001/providers/Microsoft.Network/publicIPPrefixes/pipfx-ngw-auritas-prod-canadacentral-001"
    ]
    zones = ["1", "2", "3"]
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "Prod"
    }
  }
}

nat_gateway_imports = {
  app = "/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07/resourceGroups/rg-auritas-prod-network-canadacentral-001/providers/Microsoft.Network/natGateways/ngw-auritas-prod-canadacentral-001"
}

network_interface = {}

# No NIC-level NSGs.
network_interface_nsg_associations = {}

# Their VNet flow logs stay unmanaged.
network_watcher = {
  canadacentral = {
    name               = "NetworkWatcher_canadacentral"
    resource_group_key = "networkwatcherrg"
    location           = "canadacentral"
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "Prod"
    }
  }
}

network_watcher_imports = {
  canadacentral = "/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07/resourceGroups/NetworkWatcherRG/providers/Microsoft.Network/networkWatchers/NetworkWatcher_canadacentral"
}

private_dns_zone = {
  ase = {
    name               = "ase-auritas-prod-canadacentral.appserviceenvironment.net"
    resource_group_key = "app"
    virtual_network_links = {
      vnetlink = {
        name                 = "vnetLink"
        virtual_network_id   = "/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07/resourceGroups/rg-auritas-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-auritas-prod-canadacentral-001"
        registration_enabled = false
        resolution_policy    = "Default"
        tags = {
          CostCenterId = "YT-02054.S.IMP"
          Environment  = "Prod"
        }
      }
      link_connectivity_canadacentral_001 = {
        name                 = "link-connectivity-canadacentral-001"
        virtual_network_id   = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-dns-connectivity-canadacentral-001"
        registration_enabled = false
        resolution_policy    = "Default"
        tags = {
          CostCenterId = "YT-02054.S.IMP"
          Environment  = "Prod"
        }
      }
    }
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "Prod"
    }
  }
}

private_dns_zone_imports = {
  ase = "/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07/resourceGroups/rg-auritas-prod-app-canadacentral-001/providers/Microsoft.Network/privateDnsZones/ase-auritas-prod-canadacentral.appserviceenvironment.net"
}

private_dns_zone_link_imports = {
  "ase/vnetlink" = {
    zone_key = "ase"
    link_key = "vnetlink"
    id       = "/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07/resourceGroups/rg-auritas-prod-app-canadacentral-001/providers/Microsoft.Network/privateDnsZones/ase-auritas-prod-canadacentral.appserviceenvironment.net/virtualNetworkLinks/vnetLink"
  }
  "ase/link_connectivity_canadacentral_001" = {
    zone_key = "ase"
    link_key = "link_connectivity_canadacentral_001"
    id       = "/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07/resourceGroups/rg-auritas-prod-app-canadacentral-001/providers/Microsoft.Network/privateDnsZones/ase-auritas-prod-canadacentral.appserviceenvironment.net/virtualNetworkLinks/link-connectivity-canadacentral-001"
  }
}

private_endpoint = {
  web_app = {
    enabled                         = true
    name                            = "pep-appauritasprodcac"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07/resourceGroups/rg-auritas-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-auritas-prod-canadacentral-001/subnets/snet-auritas-prod-pep-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07/resourcegroups/rg-auritas-prod-app-canadacentral-001/providers/Microsoft.Web/sites/appauritasprodcac"
    private_service_connection_name = "pep-appauritasprodcac"
    subresource_names               = ["sites"]
    network_interface_name          = "pep-appauritasprodcac-nic"
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07/resourceGroups/rg-auritas-prod-app-canadacentral-001/providers/Microsoft.Network/privateDnsZones/ase-auritas-prod-canadacentral.appserviceenvironment.net"
    ]
    ip_configurations = {
      pep_appauritasprodcac = {
        name               = "pep-appauritasprodcac"
        private_ip_address = "10.195.121.10"
        subresource_name   = "sites"
        member_name        = "sites"
      }
    }
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "Prod"
    }
  }
  storage_blob = {
    enabled                         = true
    name                            = "pep-stauritasprodcac01"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07/resourceGroups/rg-auritas-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-auritas-prod-canadacentral-001/subnets/snet-auritas-prod-pep-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07/resourceGroups/rg-auritas-prod-app-canadacentral-001/providers/Microsoft.Storage/storageAccounts/stauritasprodcac01"
    private_service_connection_name = "pep-stauritasprodcac01"
    subresource_names               = ["blob"]
    network_interface_name          = "pep-stauritasprodcac01-nic"
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net"
    ]
    ip_configurations = {}
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "Prod"
    }
  }
  network_watcher_storage = {
    enabled                         = true
    name                            = "pep-stnwauritasprdcac001xdf"
    resource_group_key              = "networkwatcherrg"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07/resourceGroups/rg-auritas-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-auritas-prod-canadacentral-001/subnets/snet-auritas-prod-pep-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07/resourceGroups/NetworkWatcherRG/providers/Microsoft.Storage/storageAccounts/stnwauritasprdcac001xdf"
    private_service_connection_name = "pep-stnwauritasprdcac001xdf"
    subresource_names               = ["blob"]
    network_interface_name          = "pep-stnwauritasprdcac001xdf-nic"
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net"
    ]
    ip_configurations = {}
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "Prod"
    }
  }
  function_app = {
    enabled                         = true
    name                            = "pep-funcauritasprodcac"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07/resourceGroups/rg-auritas-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-auritas-prod-canadacentral-001/subnets/snet-auritas-prod-pep-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07/resourceGroups/rg-auritas-prod-app-canadacentral-001/providers/Microsoft.Web/sites/funcauritasprodcac"
    private_service_connection_name = "pep-funcauritasprodcac"
    subresource_names               = ["sites"]
    network_interface_name          = "pep-funcauritasprodcac-nic"
    private_dns_zone_group_name     = null
    private_dns_zone_resource_ids   = []
    ip_configurations = {
      pep_funcauritasprodcac = {
        name               = "pep-funcauritasprodcac"
        private_ip_address = "10.195.121.12"
        subresource_name   = "sites"
        member_name        = "sites"
      }
    }
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "Prod"
    }
  }
}

private_endpoint_imports = {
  web_app                 = "/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07/resourceGroups/rg-auritas-prod-app-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-appauritasprodcac"
  storage_blob            = "/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07/resourceGroups/rg-auritas-prod-app-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-stauritasprodcac01"
  network_watcher_storage = "/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07/resourceGroups/NetworkWatcherRG/providers/Microsoft.Network/privateEndpoints/pep-stnwauritasprdcac001xdf"
  function_app            = "/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07/resourceGroups/rg-auritas-prod-app-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-funcauritasprodcac"
}

public_ip_prefix = {
  nat_gateway = {
    name               = "pipfx-ngw-auritas-prod-canadacentral-001"
    resource_group_key = "network"
    location           = "canadacentral"
    prefix_length      = 31
    ip_version         = "IPv4"
    sku_name           = "StandardV2"
    sku_tier           = "Regional"
    zones              = []
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "Prod"
    }
  }
}

public_ip_prefix_imports = {
  nat_gateway = "/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07/resourceGroups/rg-auritas-prod-network-canadacentral-001/providers/Microsoft.Network/publicIPPrefixes/pipfx-ngw-auritas-prod-canadacentral-001"
}

recovery_services_vault = {}

recovery_services_vault_imports = {}

restore_point_collection = {}

restore_point_collection_imports = {}

# Blob service properties were not exported, so blob_properties stays null.
storage_account = {
  app = {
    name                              = "stauritasprodcac01"
    resource_group_key                = "app"
    location                          = "canadacentral"
    account_kind                      = "StorageV2"
    account_tier                      = "Standard"
    account_replication_type          = "ZRS"
    access_tier                       = "Hot"
    allow_nested_items_to_be_public   = false
    cross_tenant_replication_enabled  = false
    default_to_oauth_authentication   = false
    https_traffic_only_enabled        = true
    infrastructure_encryption_enabled = false
    is_hns_enabled                    = false
    large_file_share_enabled          = null
    min_tls_version                   = "TLS1_2"
    public_network_access_enabled     = false
    sftp_enabled                      = false
    shared_access_key_enabled         = true
    blob_properties                   = null
    network_rules = {
      bypass                     = ["AzureServices"]
      default_action             = "Deny"
      ip_rules                   = []
      virtual_network_subnet_ids = []
      private_link_access        = []
    }
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "Prod"
    }
  }
  network_watcher = {
    name                              = "stnwauritasprdcac001xdf"
    resource_group_key                = "networkwatcherrg"
    location                          = "canadacentral"
    account_kind                      = "StorageV2"
    account_tier                      = "Standard"
    account_replication_type          = "LRS"
    access_tier                       = "Hot"
    allow_nested_items_to_be_public   = false
    cross_tenant_replication_enabled  = false
    default_to_oauth_authentication   = false
    https_traffic_only_enabled        = true
    infrastructure_encryption_enabled = false
    is_hns_enabled                    = false
    large_file_share_enabled          = null
    min_tls_version                   = "TLS1_2"
    public_network_access_enabled     = false
    sftp_enabled                      = false
    shared_access_key_enabled         = false
    blob_properties                   = null
    network_rules = {
      bypass                     = ["AzureServices"]
      default_action             = "Deny"
      ip_rules                   = []
      virtual_network_subnet_ids = []
      private_link_access        = []
    }
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "Prod"
    }
  }
}

storage_account_existing = {}

storage_account_imports = {
  app             = "/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07/resourceGroups/rg-auritas-prod-app-canadacentral-001/providers/Microsoft.Storage/storageAccounts/stauritasprodcac01"
  network_watcher = "/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07/resourceGroups/NetworkWatcherRG/providers/Microsoft.Storage/storageAccounts/stnwauritasprdcac001xdf"
}

# vnet-auritas-prod-canadacentral-001 peerings (unmanaged): RemoteVnetToHubPeering_a8db0ae7-e4bd-4112-a74f-86be5b004e19
# Disabled for now, as in Fit and Fabric: the VNet module's body omits subnets and
# peerings, so the import plan removes them, and the only peering is the vWAN
# hub connection owned by tf-deploy-platform-connectivity. Adopt it with the
# connectivity team on hand to restore the hub connection.
# defaultOutboundAccess is taken from the export where reported, otherwise Azure's
# default (enabled). It is create-time only, so a replace in the plan means the
# value is wrong. The hub peering stays unmanaged.
virtual_network = {
  app = {
    name               = "vnet-auritas-prod-canadacentral-001"
    resource_group_key = "network"
    location           = "canadacentral"
    address_space      = ["10.195.121.0/25"]
    dns_servers = {
      dns_servers = ["10.195.1.4"]
    }
    ddos_protection_plan = {
      enable = true
      id     = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/ddosProtectionPlans/ddos-protection-plan"
    }
    encryption = {
      enabled     = false
      enforcement = "AllowUnencrypted"
    }
    subnets = {
      pep = {
        name                                          = "snet-auritas-prod-pep-canadacentral-001"
        address_prefixes                              = ["10.195.121.0/26"]
        default_outbound_access_enabled               = false
        private_endpoint_network_policies             = "RouteTableEnabled"
        private_link_service_network_policies_enabled = true
        nat_gateway = {
          id = "/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07/resourceGroups/rg-auritas-prod-network-canadacentral-001/providers/Microsoft.Network/natGateways/ngw-auritas-prod-canadacentral-001"
        }
        service_endpoint_policies       = {}
        service_endpoints_with_location = []
        delegations                     = []
      }
      app = {
        name                                          = "snet-auritas-prod-app-canadacentral-001"
        address_prefixes                              = ["10.195.121.64/26"]
        default_outbound_access_enabled               = false
        private_endpoint_network_policies             = "RouteTableEnabled"
        private_link_service_network_policies_enabled = true
        nat_gateway = {
          id = "/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07/resourceGroups/rg-auritas-prod-network-canadacentral-001/providers/Microsoft.Network/natGateways/ngw-auritas-prod-canadacentral-001"
        }
        service_endpoint_policies       = {}
        service_endpoints_with_location = []
        delegations = [
          {
            name = "Microsoft.Web/hostingEnvironments"
            service_delegation = {
              name    = "Microsoft.Web/hostingEnvironments"
              actions = ["Microsoft.Network/virtualNetworks/subnets/action"]
            }
          }
        ]
      }
    }
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "Prod"
    }
  }
}

virtual_network_imports = {
  app = "/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07/resourceGroups/rg-auritas-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-auritas-prod-canadacentral-001"
}

virtual_network_subnet_imports = {
  app_pep = {
    vnet_key   = "app"
    subnet_key = "pep"
    id         = "/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07/resourceGroups/rg-auritas-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-auritas-prod-canadacentral-001/subnets/snet-auritas-prod-pep-canadacentral-001"
  }
  app_app = {
    vnet_key   = "app"
    subnet_key = "app"
    id         = "/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07/resourceGroups/rg-auritas-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-auritas-prod-canadacentral-001/subnets/snet-auritas-prod-app-canadacentral-001"
  }
}

web_app = {
  auritas_prod = {
    name                                     = "appauritasprodcac"
    resource_group_key                       = "app"
    location                                 = "canadacentral"
    service_plan_resource_id                 = "/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07/resourceGroups/rg-auritas-prod-app-canadacentral-001/providers/Microsoft.Web/serverFarms/asp-auritas-prod-canadacentral-001"
    ftp_publish_basic_authentication_enabled = false
    https_only                               = true
    key_vault_reference_identity             = "SystemAssigned"
    public_network_access_enabled            = false
    vnet_image_pull_enabled                  = true
    scm_publish_basic_authentication_enabled = false
    site_config = {
      default_documents = [
        "Default.htm", "Default.html", "Default.asp", "index.htm",
        "index.html", "iisstart.htm", "default.aspx", "index.php",
        "hostingstart.html"
      ]
      ftps_state                        = "FtpsOnly"
      ip_restriction_default_action     = ""
      scm_ip_restriction_default_action = ""
      worker_count                      = 1
      cors = {
        allowed_origins     = ["https://appauritasprodcac.ase-auritas-prod-canadacentral.appserviceenvironment.net"]
        support_credentials = true
      }
    }
    tags = {
      CostCenterId                             = "YT-02054.S.IMP"
      Environment                              = "Prod"
      "hidden-link: /app-insights-resource-id" = "/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07/resourceGroups/rg-auritas-prod-app-canadacentral-001/providers/microsoft.insights/components/ai-auritas-prod-canadacentral-001"
    }
  }
}

web_app_imports = {
  auritas_prod = "/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07/resourceGroups/rg-auritas-prod-app-canadacentral-001/providers/Microsoft.Web/sites/appauritasprodcac"
}

function_app = {
  "auritas_prod" = {
    name                                     = "funcauritasprodcac"
    resource_group_key                       = "app"
    location                                 = "canadacentral"
    service_plan_resource_id                 = "/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07/resourceGroups/rg-auritas-prod-app-canadacentral-001/providers/Microsoft.Web/serverFarms/asp-auritas-prod-canadacentral-001"
    os_type                                  = "Linux"
    function_app_uses_fc1                    = false
    builtin_logging_enabled                  = false
    client_certificate_mode                  = "Required"
    ftp_publish_basic_authentication_enabled = false
    scm_publish_basic_authentication_enabled = false
    functions_extension_version              = ""
    https_only                               = true
    key_vault_reference_identity             = "SystemAssigned"
    public_network_access_enabled            = false
    vnet_image_pull_enabled                  = true
    app_settings                             = {}
    managed_identities                       = {}
    app_service_logs = {
      retention_period_days = 90
    }
    site_config = {
      always_on                         = true
      default_documents                 = ["Default.htm", "Default.html", "Default.asp", "index.htm", "index.html", "iisstart.htm", "default.aspx", "index.php"]
      ftps_state                        = "FtpsOnly"
      ip_restriction_default_action     = ""
      scm_ip_restriction_default_action = ""
      worker_count                      = 1
      cors = {
        allowed_origins = [
          "https://appauritasprodcac.ase-auritas-prod-canadacentral.appserviceenvironment.net",
          "https://appauritasprodcac.internal.bchydro.bc.ca"
        ]
        support_credentials = true
      }
    }
    tags = {
      CostCenterId                             = "YT-02054.S.IMP"
      Environment                              = "Prod"
      "hidden-link: /app-insights-resource-id" = "/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07/resourceGroups/rg-auritas-prod-app-canadacentral-001/providers/microsoft.insights/components/ai-auritas-prod-canadacentral-001"
    }
  }
}

function_app_imports = {
  "auritas_prod" = "/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07/resourceGroups/rg-auritas-prod-app-canadacentral-001/providers/Microsoft.Web/sites/funcauritasprodcac"
}

log_analytics_query_pack = {
  default = {
    name               = "DefaultQueryPack"
    resource_group_key = "loganalyticsdefaultresources"
    location           = "canadacentral"
    tags = {
      CostCenterId = "YT-02054.S.IMP"
      Environment  = "Prod"
    }
  }
}

log_analytics_query_pack_imports = {
  default = "/subscriptions/a91a891c-4a13-426c-972a-0ddea5db8f07/resourceGroups/LogAnalyticsDefaultResources/providers/Microsoft.OperationalInsights/queryPacks/DefaultQueryPack"
}
