output "resource_id" {
  value = module.sql_server.resource_id
}
