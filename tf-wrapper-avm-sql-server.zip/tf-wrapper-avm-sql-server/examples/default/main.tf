module "sql_server" {
  source = "../.."

  name                = "sqlsrv-avm-${random_string.suffix.result}"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location

  server_version = "12.0"

  administrator_login          = "sqladmin"
  administrator_login_password = random_password.this.result

  # public access left at the module default (false); the server still deploys and this
  # keeps the example secure by default. Add private_endpoints or firewall_rules for access.

  databases = {
    appdb = {
      name        = "appdb"
      sku_name    = "GP_S_Gen5_1"
      max_size_gb = 32
    }
  }

  enable_telemetry = false
}
