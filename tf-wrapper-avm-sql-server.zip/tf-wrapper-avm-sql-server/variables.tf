variable "location" {
  type        = string
  description = "Azure region where the resource should be deployed."
  nullable    = false

  validation {
    condition     = length(var.location) > 0
    error_message = "location must not be empty."
  }
}

variable "name" {
  type        = string
  description = "The name of the SQL Server (logical server). Must be 1-63 lowercase alphanumeric characters or hyphens, starting and ending with an alphanumeric character."
  nullable    = false

  validation {
    condition     = can(regex("^[a-z0-9][a-z0-9-]{0,61}[a-z0-9]$", var.name))
    error_message = "name must be 1-63 characters, lowercase letters, numbers and hyphens, and start and end with a letter or number."
  }
}

# This is required for most resource modules
variable "resource_group_name" {
  type        = string
  description = "The resource group where the resources will be deployed."

  validation {
    condition     = length(var.resource_group_name) > 0 && length(var.resource_group_name) <= 90
    error_message = "resource_group_name must be between 1 and 90 characters."
  }
}

variable "server_version" {
  type        = string
  description = "(Required) The version for the new server. Valid values are `2.0` (for a v11 server) and `12.0` (for a v12 server). Changing this forces a new resource to be created."
  nullable    = false

  validation {
    condition     = contains(["2.0", "12.0"], var.server_version)
    error_message = "server_version must be either '2.0' or '12.0'."
  }
}

variable "administrator_login" {
  type        = string
  default     = null
  description = "(Optional) The administrator login name for the new server. Required unless `azuread_authentication_only` in the `azuread_administrator` block is `true`. When omitted, Azure will generate a default username which cannot be subsequently changed. Changing this forces a new resource to be created."
}

variable "administrator_login_password" {
  type        = string
  default     = null
  sensitive   = true
  description = "(Optional) The password associated with the `administrator_login` user. Needs to comply with Azure's Password Policy. Required unless `azuread_authentication_only` in the `azuread_administrator` block is `true`. If omitted and `generate_administrator_login_password` is `true`, a random password will be generated. Cannot be used together with `administrator_login_password_wo`."
}

variable "administrator_login_password_wo" {
  type        = string
  ephemeral   = true
  default     = null
  description = "(Optional) The password associated with the `administrator_login` user (write-only). Not stored in Terraform state. Alternative to `administrator_login_password`. Using write-only resource arguments requires Terraform 1.11+ and azurerm 4.26+. Cannot be used together with `administrator_login_password` or `generate_administrator_login_password`."

  validation {
    condition     = !(var.administrator_login_password != null && var.administrator_login_password_wo != null)
    error_message = "administrator_login_password and administrator_login_password_wo cannot be used together. Specify only one."
  }
}

variable "administrator_login_password_wo_version" {
  type        = number
  default     = null
  description = "(Optional) The version of the write-only password, used with `administrator_login_password_wo` to track password rotations. Increment (e.g. 1, 2) to signal a rotation."
}

variable "generate_administrator_login_password" {
  type        = bool
  default     = false
  nullable    = false
  description = "(Optional) When `true` and `administrator_login_password` is `null`, a random password is generated for the administrator login. Can optionally be stored in Key Vault via `administrator_login_password_key_vault_configuration`. Defaults to `false`."
}

variable "administrator_login_password_key_vault_configuration" {
  type = object({
    key_vault_resource_id = string
    secret_name           = optional(string, "sql-administrator-login-password")
    expiration_date       = optional(string, null)
    content_type          = optional(string, null)
    tags                  = optional(map(string), null)
  })
  default     = null
  description = <<-DESCRIPTION
(Optional) When set, the administrator login password is stored as a secret in the specified Azure Key Vault. Supported with an explicit `administrator_login_password` or with `generate_administrator_login_password = true`; not supported with `administrator_login_password_wo`.

- `key_vault_resource_id` - (Required) The resource ID of the Key Vault in which to store the secret.
- `secret_name` - (Optional) The name of the Key Vault secret. Defaults to `sql-administrator-login-password`.
- `expiration_date` - (Optional) The expiration date of the secret in RFC3339 format. If omitted, the secret does not expire.
- `content_type` - (Optional) The content type of the Key Vault secret.
- `tags` - (Optional) A map of tags to assign to the Key Vault secret.
DESCRIPTION
}

variable "azuread_administrator" {
  type = object({
    azuread_authentication_only = optional(bool)
    login_username              = string
    object_id                   = string
    tenant_id                   = optional(string)
  })
  default     = null
  description = <<-DESCRIPTION
 - `azuread_authentication_only` - (Optional) Specifies whether only AD users and administrators can be used to login, or also local database users. When `true`, `administrator_login` and `administrator_login_password` can be omitted.
 - `login_username` - (Required) The login username of the Azure AD Administrator of this SQL Server.
 - `object_id` - (Required) The object id of the Azure AD Administrator of this SQL Server.
 - `tenant_id` - (Optional) The tenant id of the Azure AD Administrator of this SQL Server.
DESCRIPTION
}

variable "connection_policy" {
  type        = string
  default     = null
  description = "(Optional) The connection policy the server will use. Possible values are `Default`, `Proxy`, and `Redirect`. Defaults to `Default`."

  validation {
    condition     = var.connection_policy == null ? true : contains(["Default", "Proxy", "Redirect"], var.connection_policy)
    error_message = "connection_policy must be null, 'Default', 'Proxy', or 'Redirect'."
  }
}

variable "express_vulnerability_assessment_enabled" {
  type        = bool
  default     = false
  description = "(Optional) Whether the Express Vulnerability Assessment feature is enabled for this server. Defaults to `false`."
}

variable "outbound_network_restriction_enabled" {
  type        = bool
  default     = null
  description = "(Optional) Whether outbound network traffic is restricted for this server. Defaults to `false`."
}

variable "public_network_access_enabled" {
  type        = bool
  default     = false
  description = "(Optional) Whether public network access is allowed for this server. Defaults to `false`."
}

variable "primary_user_assigned_identity_id" {
  type        = string
  default     = null
  description = "(Optional) The primary user managed identity id. Required if `type` within the identity block is `SystemAssigned, UserAssigned` or `UserAssigned`, and should be set at the same time as the user assigned identity ids in `managed_identities`."
}

variable "transparent_data_encryption_key_vault_key_id" {
  type        = string
  default     = null
  description = "(Optional) The fully versioned Key Vault Key URL (e.g. `https://<vault>.vault.azure.net/keys/<key>/<version>`) to use as the Customer Managed Key (CMK/BYOK) for the Transparent Data Encryption (TDE) layer at the server level."
}

variable "databases" {
  type = map(object({
    name                                                       = string
    auto_pause_delay_in_minutes                                = optional(number)
    create_mode                                                = optional(string, "Default")
    collation                                                  = optional(string)
    elastic_pool_key                                           = optional(string)
    geo_backup_enabled                                         = optional(bool, true)
    maintenance_configuration_name                             = optional(string)
    ledger_enabled                                             = optional(bool, false)
    license_type                                               = optional(string)
    max_size_gb                                                = optional(number)
    min_capacity                                               = optional(number)
    restore_point_in_time                                      = optional(string)
    recover_database_id                                        = optional(string)
    restore_dropped_database_id                                = optional(string)
    read_replica_count                                         = optional(number)
    read_scale                                                 = optional(bool)
    sample_name                                                = optional(string)
    sku_name                                                   = optional(string)
    storage_account_type                                       = optional(string, "Geo")
    transparent_data_encryption_enabled                        = optional(bool, true)
    transparent_data_encryption_key_vault_key_id               = optional(string)
    transparent_data_encryption_key_automatic_rotation_enabled = optional(bool)
    zone_redundant                                             = optional(bool)

    import = optional(object({
      storage_uri                  = string
      storage_key                  = string
      storage_key_type             = string
      administrator_login          = string
      administrator_login_password = string
      authentication_type          = string
      storage_account_id           = optional(string)
    }))

    long_term_retention_policy = optional(object({
      weekly_retention  = optional(string)
      monthly_retention = optional(string)
      yearly_retention  = optional(string)
      week_of_year      = optional(number)
    }))

    short_term_retention_policy = optional(object({
      retention_days           = number
      backup_interval_in_hours = optional(number, 12)
    }))

    threat_detection_policy = optional(object({
      state                      = optional(string, "Disabled")
      disabled_alerts            = optional(list(string))
      email_account_admins       = optional(string, "Disabled")
      email_addresses            = optional(list(string))
      retention_days             = optional(number)
      storage_account_access_key = optional(string)
      storage_endpoint           = optional(string)
    }))

    role_assignments = optional(map(object({
      role_definition_id_or_name             = string
      principal_id                           = string
      description                            = optional(string, null)
      skip_service_principal_aad_check       = optional(bool, false)
      condition                              = optional(string, null)
      condition_version                      = optional(string, null)
      delegated_managed_identity_resource_id = optional(string, null)
      principal_type                         = optional(string, null)
    })))

    lock = optional(object({
      kind = string
      name = optional(string, null)
    }))

    diagnostic_settings = optional(map(object({
      name                                     = optional(string, null)
      event_hub_authorization_rule_resource_id = optional(string, null)
      event_hub_name                           = optional(string, null)
      log_analytics_destination_type           = optional(string, null)
      workspace_resource_id                    = optional(string, null)
      marketplace_partner_resource_id          = optional(string, null)
      storage_account_resource_id              = optional(string, null)
      log_categories                           = optional(list(string))
      log_groups                               = optional(list(string))
      metric_categories                        = optional(list(string))
    })))

    managed_identities = optional(object({
      system_assigned            = optional(bool, false)
      user_assigned_resource_ids = optional(set(string), [])
    }))

    tags = optional(map(string))
  }))
  default     = {}
  nullable    = false
  description = <<-DESCRIPTION
A map of databases to create on this server. The map key is deliberately arbitrary to avoid issues where map keys may be unknown at plan time.

Key attributes (see the AVM module documentation for the full list):
- `name` - (Required) The name of the database.
- `sku_name` - (Optional) The SKU used by the database, e.g. `GP_S_Gen5_2`, `HS_Gen5_2`, `BC_Gen5_2`, `S0`, `P2`, `ElasticPool`, `Basic`.
- `elastic_pool_key` - (Optional) The map key of an entry in `var.elastic_pools` to place this database into an elastic pool.
- `max_size_gb`, `min_capacity`, `auto_pause_delay_in_minutes`, `read_scale`, `read_replica_count`, `zone_redundant` - sizing/scaling knobs (availability depends on the chosen SKU/tier).
- `collation`, `license_type`, `create_mode`, `sample_name`, `ledger_enabled`, `geo_backup_enabled`, `storage_account_type`, `maintenance_configuration_name`.
- `transparent_data_encryption_enabled` (defaults to `true`), `transparent_data_encryption_key_vault_key_id`, `transparent_data_encryption_key_automatic_rotation_enabled`.
- `import`, `long_term_retention_policy`, `short_term_retention_policy`, `threat_detection_policy` - nested objects.
- `role_assignments`, `lock`, `diagnostic_settings`, `managed_identities`, `tags` - standard AVM per-database interfaces.
DESCRIPTION
}

variable "elastic_pools" {
  type = map(object({
    name     = string
    location = optional(string)
    sku = optional(object({
      name     = string
      capacity = number
      tier     = string
      family   = optional(string)
    }))
    per_database_settings = optional(object({
      min_capacity = number
      max_capacity = number
    }))
    maintenance_configuration_name = optional(string, "SQL_Default")
    zone_redundant                 = optional(bool, true)
    license_type                   = optional(string)
    max_size_gb                    = optional(number)
    max_size_bytes                 = optional(number)

    role_assignments = optional(map(object({
      role_definition_id_or_name             = string
      principal_id                           = string
      description                            = optional(string, null)
      skip_service_principal_aad_check       = optional(bool, false)
      condition                              = optional(string, null)
      condition_version                      = optional(string, null)
      delegated_managed_identity_resource_id = optional(string, null)
      principal_type                         = optional(string, null)
    })))

    lock = optional(object({
      kind = string
      name = optional(string, null)
    }))

    diagnostic_settings = optional(map(object({
      name                                     = optional(string, null)
      event_hub_authorization_rule_resource_id = optional(string, null)
      event_hub_name                           = optional(string, null)
      log_analytics_destination_type           = optional(string, null)
      workspace_resource_id                    = optional(string, null)
      marketplace_partner_resource_id          = optional(string, null)
      storage_account_resource_id              = optional(string, null)
      log_categories                           = optional(list(string))
      log_groups                               = optional(list(string))
      metric_categories                        = optional(list(string))
    })))

    tags = optional(map(string))
  }))
  default     = {}
  description = <<-DESCRIPTION
A map of elastic pools to create on this server. The map key is referenced by `elastic_pool_key` on entries in `var.databases`.

- `name` - (Required) The name of the elastic pool.
- `sku` - (Optional) `name`, `capacity`, `tier`, and optional `family`.
- `per_database_settings` - (Optional) `min_capacity` and `max_capacity` per database.
- `maintenance_configuration_name` - (Optional) Defaults to `SQL_Default`.
- `zone_redundant` - (Optional) Defaults to `true`.
- `license_type`, `max_size_gb`, `max_size_bytes`.
- `role_assignments`, `lock`, `diagnostic_settings`, `tags` - standard AVM per-pool interfaces.
DESCRIPTION
}

variable "firewall_rules" {
  type = map(object({
    end_ip_address   = string
    start_ip_address = string
    timeouts = optional(object({
      create = optional(string)
      delete = optional(string)
      read   = optional(string)
      update = optional(string)
    }))
  }))
  default     = {}
  nullable    = false
  description = <<-DESCRIPTION
A map of server-level firewall rules. The map key is used as the firewall rule name.

- `start_ip_address` - (Required) The start IP address of the firewall rule. Use `0.0.0.0` for both start and end to allow all Azure services.
- `end_ip_address` - (Required) The end IP address of the firewall rule.
- `timeouts` - (Optional) `create`, `delete`, `read`, `update`.
DESCRIPTION
}

variable "managed_identities" {
  type = object({
    system_assigned            = optional(bool, false)
    user_assigned_resource_ids = optional(set(string), [])
  })
  default     = {}
  nullable    = false
  description = <<-DESCRIPTION
Controls the Managed Identity configuration on this resource. The following properties can be specified:

- `system_assigned` - (Optional) Specifies if the System Assigned Managed Identity should be enabled.
- `user_assigned_resource_ids` - (Optional) Specifies a list of User Assigned Managed Identity resource IDs to be assigned to this resource.
DESCRIPTION
}

variable "role_assignments" {
  type = map(object({
    role_definition_id_or_name             = string
    principal_id                           = string
    description                            = optional(string, null)
    skip_service_principal_aad_check       = optional(bool, false)
    condition                              = optional(string, null)
    condition_version                      = optional(string, null)
    delegated_managed_identity_resource_id = optional(string, null)
    principal_type                         = optional(string, null)
  }))
  default     = {}
  nullable    = false
  description = <<-DESCRIPTION
A map of role assignments to create on this resource. The map key is deliberately arbitrary to avoid issues where map keys maybe unknown at plan time.

- `role_definition_id_or_name` - The ID or name of the role definition to assign to the principal.
- `principal_id` - The ID of the principal to assign the role to.
- `description` - The description of the role assignment.
- `skip_service_principal_aad_check` - If set to true, skips the Azure Active Directory check for the service principal in the tenant. Defaults to false.
- `condition` - The condition which will be used to scope the role assignment.
- `condition_version` - The version of the condition syntax. Valid values are '2.0'.

> Note: only set `skip_service_principal_aad_check` to true if you are assigning a role to a service principal.
DESCRIPTION
}

variable "lock" {
  type = object({
    kind = string
    name = optional(string, null)
  })
  default     = null
  description = <<-DESCRIPTION
Controls the Resource Lock configuration for this resource. The following properties can be specified:

- `kind` - (Required) The type of lock. Possible values are `CanNotDelete` and `ReadOnly`.
- `name` - (Optional) The name of the lock. If not specified, a name will be generated based on the `kind` value. Changing this forces the creation of a new resource.
DESCRIPTION

  validation {
    condition     = var.lock != null ? contains(["CanNotDelete", "ReadOnly"], var.lock.kind) : true
    error_message = "The lock level must be one of: 'CanNotDelete' or 'ReadOnly'."
  }
}

variable "diagnostic_settings" {
  type = map(object({
    name                                     = optional(string, null)
    log_categories                           = optional(set(string), [])
    log_groups                               = optional(set(string), ["allLogs"])
    metric_categories                        = optional(set(string), ["AllMetrics"])
    log_analytics_destination_type           = optional(string, "Dedicated")
    workspace_resource_id                    = optional(string, null)
    storage_account_resource_id              = optional(string, null)
    event_hub_authorization_rule_resource_id = optional(string, null)
    event_hub_name                           = optional(string, null)
    marketplace_partner_resource_id          = optional(string, null)
  }))
  default     = {}
  nullable    = false
  description = <<-DESCRIPTION
A map of diagnostic settings to create on the SQL Server. The map key is deliberately arbitrary to avoid issues where map keys maybe unknown at plan time.

- `name` - (Optional) The name of the diagnostic setting. One will be generated if not set, however this will not be unique if you want to create multiple diagnostic setting resources.
- `log_categories` - (Optional) A set of log categories to send to the log analytics workspace. Defaults to `[]`.
- `log_groups` - (Optional) A set of log groups to send to the log analytics workspace. Defaults to `["allLogs"]`.
- `metric_categories` - (Optional) A set of metric categories to send to the log analytics workspace. Defaults to `["AllMetrics"]`.
- `log_analytics_destination_type` - (Optional) The destination type for the diagnostic setting. Possible values are `Dedicated` and `AzureDiagnostics`. Defaults to `Dedicated`.
- `workspace_resource_id` - (Optional) The resource ID of the log analytics workspace to send logs and metrics to.
- `storage_account_resource_id` - (Optional) The resource ID of the storage account to send logs and metrics to.
- `event_hub_authorization_rule_resource_id` - (Optional) The resource ID of the event hub authorization rule to send logs and metrics to.
- `event_hub_name` - (Optional) The name of the event hub. If none is specified, the default event hub will be selected.
- `marketplace_partner_resource_id` - (Optional) The full ARM resource ID of the Marketplace resource to which you would like to send Diagnostic Logs.
DESCRIPTION

  validation {
    condition     = alltrue([for _, v in var.diagnostic_settings : contains(["Dedicated", "AzureDiagnostics"], v.log_analytics_destination_type)])
    error_message = "Log analytics destination type must be one of: 'Dedicated', 'AzureDiagnostics'."
  }
  validation {
    condition = alltrue(
      [
        for _, v in var.diagnostic_settings :
        v.workspace_resource_id != null || v.storage_account_resource_id != null || v.event_hub_authorization_rule_resource_id != null || v.marketplace_partner_resource_id != null
      ]
    )
    error_message = "At least one of `workspace_resource_id`, `storage_account_resource_id`, `marketplace_partner_resource_id`, or `event_hub_authorization_rule_resource_id`, must be set."
  }
}

variable "private_endpoints" {
  type = map(object({
    name = optional(string, null)
    role_assignments = optional(map(object({
      role_definition_id_or_name             = string
      principal_id                           = string
      description                            = optional(string, null)
      skip_service_principal_aad_check       = optional(bool, false)
      condition                              = optional(string, null)
      condition_version                      = optional(string, null)
      delegated_managed_identity_resource_id = optional(string, null)
      principal_type                         = optional(string, null)
    })), {})
    lock = optional(object({
      kind = string
      name = optional(string, null)
    }), null)
    tags                                    = optional(map(string), null)
    subnet_resource_id                      = string
    subresource_name                        = string
    private_dns_zone_group_name             = optional(string, "default")
    private_dns_zone_resource_ids           = optional(set(string), [])
    application_security_group_associations = optional(map(string), {})
    private_service_connection_name         = optional(string, null)
    network_interface_name                  = optional(string, null)
    location                                = optional(string, null)
    resource_group_name                     = optional(string, null)
    ip_configurations = optional(map(object({
      name               = string
      private_ip_address = string
    })), {})
  }))
  default     = {}
  nullable    = false
  description = <<-DESCRIPTION
A map of private endpoints to create on this resource. The map key is deliberately arbitrary to avoid issues where map keys maybe unknown at plan time.

- `name` - (Optional) The name of the private endpoint. One will be generated if not set.
- `role_assignments` - (Optional) A map of role assignments to create on the private endpoint. See `var.role_assignments` for more information.
- `lock` - (Optional) The lock level to apply to the private endpoint. Possible values are `CanNotDelete` and `ReadOnly`.
- `tags` - (Optional) A mapping of tags to assign to the private endpoint.
- `subnet_resource_id` - The resource ID of the subnet to deploy the private endpoint in.
- `subresource_name` - The name of the sub resource for the private endpoint. For a SQL Server this is `sqlServer`.
- `private_dns_zone_group_name` - (Optional) The name of the private DNS zone group. One will be generated if not set.
- `private_dns_zone_resource_ids` - (Optional) A set of resource IDs of private DNS zones to associate with the private endpoint. If not set, no zone groups will be created and DNS records must be managed externally.
- `application_security_group_associations` - (Optional) A map of resource IDs of application security groups to associate with the private endpoint.
- `private_service_connection_name` - (Optional) The name of the private service connection. One will be generated if not set.
- `network_interface_name` - (Optional) The name of the network interface. One will be generated if not set.
- `location` - (Optional) The Azure location where the resources will be deployed. Defaults to the location of the resource group.
- `resource_group_name` - (Optional) The resource group where the resources will be deployed. Defaults to the resource group of this resource.
- `ip_configurations` - (Optional) A map of IP configurations to create on the private endpoint. If not specified the platform will create one.
  - `name` - The name of the IP configuration.
  - `private_ip_address` - The private IP address of the IP configuration.
DESCRIPTION
}

# This variable is used to determine if the private_dns_zone_group block should be included,
# or if it is to be managed externally, e.g. using Azure Policy.
variable "private_endpoints_manage_dns_zone_group" {
  type        = bool
  default     = true
  nullable    = false
  description = "Whether to manage private DNS zone groups with this module. If set to false, you must manage private DNS zone groups externally, e.g. using Azure Policy."
}

variable "tags" {
  type        = map(string)
  default     = null
  description = "(Optional) Tags of the resource."
}

variable "enable_telemetry" {
  type        = bool
  default     = true
  nullable    = false
  description = <<-DESCRIPTION
This variable controls whether or not telemetry is enabled for the module.
For more information see <https://aka.ms/avm/telemetryinfo>.
If it is set to false, then no telemetry will be collected.
DESCRIPTION
}
