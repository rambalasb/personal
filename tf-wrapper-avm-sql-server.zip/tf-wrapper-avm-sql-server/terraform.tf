terraform {
  # >= 1.10 (not the >= 1.9 baseline of sibling wrappers) because administrator_login_password_wo
  # is declared as an ephemeral variable, which Terraform only supports from 1.10 onwards.
  required_version = ">= 1.10, < 2.0"

  required_providers {
    # AVM avm-res-sql-server v0.2.1 requires azurerm ~> 4.26.
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 4.26, < 5.0"
    }
  }
}
