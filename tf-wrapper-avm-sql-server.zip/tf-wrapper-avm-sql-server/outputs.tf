output "resource_id" {
  description = "The resource ID of the SQL Server (logical server)."
  value       = module.sql_server.resource_id
}

output "resource_name" {
  description = "The name of the SQL Server."
  value       = module.sql_server.resource_name
}

output "resource" {
  description = "The full azurerm_mssql_server resource output object."
  value       = module.sql_server.resource
  sensitive   = true
}

output "resource_databases" {
  description = "A map of the databases created. The map key is the input key from var.databases; the value is the full database module output."
  value       = module.sql_server.resource_databases
  sensitive   = true
}

output "resource_elasticpools" {
  description = "A map of the elastic pools created. The map key is the input key from var.elastic_pools; the value is the full elastic pool module output."
  value       = module.sql_server.resource_elasticpools
}

output "private_endpoints" {
  description = "A map of the private endpoints created for the SQL Server."
  value       = module.sql_server.private_endpoints
}

output "generated_administrator_login_password" {
  description = "The auto-generated administrator login password. Only populated when generate_administrator_login_password = true; null otherwise."
  value       = module.sql_server.generated_administrator_login_password
  sensitive   = true
}

output "administrator_login_password_key_vault_secret" {
  description = "The Key Vault secret resource storing the administrator login password. Only populated when administrator_login_password_key_vault_configuration is set."
  value       = module.sql_server.administrator_login_password_key_vault_secret
  sensitive   = true
}
