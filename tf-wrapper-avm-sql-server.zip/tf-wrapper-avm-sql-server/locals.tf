locals {
  module_tags = merge(
    var.tags == null ? {} : var.tags,
    {
      managed-by = "terraform"
      module     = "tf-wrapper-avm-sql-server"
    }
  )

  # A valid admin authentication path exists when either a local SQL admin login is set or
  # Entra-only authentication is enabled. Used by checks.tf.
  entra_only_auth = var.azuread_administrator != null ? coalesce(var.azuread_administrator.azuread_authentication_only, false) : false

  # Whether some administrator login password source is provided.
  password_provided = var.administrator_login_password != null || var.administrator_login_password_wo != null || var.generate_administrator_login_password
}
