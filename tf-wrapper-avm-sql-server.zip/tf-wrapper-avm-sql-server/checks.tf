# Post-plan/apply advisory checks. These surface as warnings (never block apply) and
# assert compliance / cross-configuration invariants that the AVM module does not enforce.

check "public_network_access_disabled_with_private_endpoints" {
  assert {
    condition     = length(var.private_endpoints) == 0 || !var.public_network_access_enabled
    error_message = "When private endpoints are configured, public network access should be disabled. Set public_network_access_enabled = false."
  }
}

check "administrator_authentication_configured" {
  assert {
    condition     = var.administrator_login != null || local.entra_only_auth
    error_message = "No administrator authentication is configured. Set administrator_login, or set azuread_administrator.azuread_authentication_only = true. Otherwise Azure generates a default admin username that cannot be changed later."
  }
}

check "administrator_password_available" {
  assert {
    condition     = var.administrator_login == null || local.entra_only_auth || local.password_provided
    error_message = "administrator_login is set but no password source is provided. Set administrator_login_password, administrator_login_password_wo, or generate_administrator_login_password = true."
  }
}

check "database_elastic_pool_key_exists" {
  assert {
    condition     = alltrue([for _, db in var.databases : db.elastic_pool_key == null || contains(keys(var.elastic_pools), db.elastic_pool_key)])
    error_message = "A database references an elastic_pool_key that is not defined in var.elastic_pools."
  }
}
