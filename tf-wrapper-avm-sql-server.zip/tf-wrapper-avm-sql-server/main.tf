module "sql_server" {
  source  = "Azure/avm-res-sql-server/azurerm"
  version = "0.2.1"

  # Required
  name                = var.name
  resource_group_name = var.resource_group_name
  location            = var.location
  server_version      = var.server_version

  # Administrator authentication.
  # The module hardcodes minimum_tls_version = "1.2"; it is not a variable here.
  administrator_login                                  = var.administrator_login
  administrator_login_password                         = var.administrator_login_password
  administrator_login_password_wo                      = var.administrator_login_password_wo
  administrator_login_password_wo_version              = var.administrator_login_password_wo_version
  generate_administrator_login_password                = var.generate_administrator_login_password
  administrator_login_password_key_vault_configuration = var.administrator_login_password_key_vault_configuration
  azuread_administrator                                = var.azuread_administrator

  # Server configuration
  connection_policy                            = var.connection_policy
  express_vulnerability_assessment_enabled     = var.express_vulnerability_assessment_enabled
  outbound_network_restriction_enabled         = var.outbound_network_restriction_enabled
  public_network_access_enabled                = var.public_network_access_enabled
  primary_user_assigned_identity_id            = var.primary_user_assigned_identity_id
  transparent_data_encryption_key_vault_key_id = var.transparent_data_encryption_key_vault_key_id

  # Databases, elastic pools & firewall rules
  databases      = var.databases
  elastic_pools  = var.elastic_pools
  firewall_rules = var.firewall_rules

  # Networking
  private_endpoints                       = var.private_endpoints
  private_endpoints_manage_dns_zone_group = var.private_endpoints_manage_dns_zone_group

  # Identity, RBAC, locks, diagnostics
  managed_identities  = var.managed_identities
  role_assignments    = var.role_assignments
  lock                = var.lock
  diagnostic_settings = var.diagnostic_settings

  enable_telemetry = var.enable_telemetry
  tags             = local.module_tags
}
