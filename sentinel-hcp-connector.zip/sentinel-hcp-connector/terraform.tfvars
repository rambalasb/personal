location                     = "canadacentral"
resource_group_name          = "rg-sentinel-hcp-poc"
log_analytics_workspace_name = "law-sentinel-hcp-poc"

# template is populated — deploy the connector
enable_hcp_connector = true

# optional runs poller; leave "" to skip
hcp_workspace_id         = ""
polling_interval_minutes = 5

tags = {
  environment = "poc"
  owner       = "security"
}

# hcp_org_name and hcp_audit_token come from the pipeline env (TF_VAR_*),
# never put the token here.
