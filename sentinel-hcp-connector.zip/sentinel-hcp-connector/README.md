# Sentinel + HCP Terraform connector

Terraform config + GitHub Actions pipeline that stands up a Microsoft Sentinel
workspace and the HCP Terraform audit-log connector (CCF).

- **Execution**: local — the GitHub runner runs `terraform`, authenticating to
  Azure via GitHub OIDC (no client secret).
- **State**: HCP Terraform. The pipeline creates the workspace with execution
  mode = Local so the runner applies, not HCP.

## What it creates

Single apply builds the whole chain:

RG -> Log Analytics workspace -> Sentinel onboarding -> DCE -> 3 custom tables
-> DCR -> connector definition -> 3 pollers (audit / workspaces / runs).

Terraform owns RG, workspace, onboarding, and DCE; `azuredeploy.json` (ARM)
owns the CCF objects, since those have no first-class azurerm resources.

## GitHub configuration

**Secrets**

| Name | Value |
| --- | --- |
| `TF_API_TOKEN` | HCP Terraform API token (state backend + workspace creation) |
| `HCP_AUDIT_TOKEN` | HCP Terraform audit-trail token (connector) |

**Variables**

| Name | Value |
| --- | --- |
| `AZURE_CLIENT_ID` | Entra app (client) ID with the repo FIC |
| `AZURE_TENANT_ID` | Tenant ID |
| `AZURE_SUBSCRIPTION_ID` | Target subscription |
| `TF_CLOUD_ORGANIZATION` | HCP Terraform org slug (also the org the connector polls) |
| `TF_WORKSPACE` | HCP Terraform workspace name (created by the pipeline) |

## Prerequisites (outside GitHub)

1. **Federated credential** on the Entra app matching this workflow's subject
   (a flexible FIC covering the repo ref/environment is fine).
2. **Contributor** on the target subscription/RG for that app. Sufficient here —
   the config creates no role assignments. Do not add `azurerm_role_assignment`
   or module `role_assignments` blocks without an admin granting a role that
   includes `roleAssignments/write`.

The TFC workspace does not need to exist beforehand — the pipeline creates it
(or reasserts it) with execution mode = Local before init.

## Configure

Edit `terraform.tfvars` (committed, non-secret): `resource_group_name`,
`log_analytics_workspace_name`, `location`, and optionally `hcp_workspace_id`
(`ws-xxxx`) to enable the runs poller. The audit token and org come from the
pipeline env — never put the token in tfvars.

## Deploy

`azuredeploy.json` is populated and `enable_hcp_connector = true`, so one apply
does everything.

- **Push to `main`** — runs init/validate/plan and auto-applies.
- **Manual run** — plan only, unless `apply = true`. Set `destroy_on_failure =
  true` to tear down the whole managed state if apply fails partway. Terraform
  has no partial rollback, so this destroys everything in state; dispatch-only.

## Validate (~10-15 min for data)

1. Sentinel -> Data connectors -> "HCP Terraform" -> pollers show Connected.
2. Logs: `HCPTerraformAuditTrail_CL | summarize count(), max(TimeGenerated)`.

## Notes

- Pre-flight the token before deploying (audit trail API needs Standard/Premium):
  `curl -H "Authorization: Bearer $TOKEN" -H "Accept: application/vnd.api+json"
  "https://app.terraform.io/api/v2/organization/audit-trail?page%5Bsize%5D=1"`
  — expect HTTP 200.
- If pollers come up 401/Disconnected: the `[[parameters('hcpApiToken')]`
  double-bracket in `azuredeploy.json` can resolve to a literal in single-layer
  deployment. Change the three `ApiKey` lines to single bracket and re-run.
- HCP retains only 14 days of audit history — enable the connector promptly.
- Run `terraform fmt` locally before committing.
- If this folder is nested inside a larger repo, move the workflow to that repo's
  `.github/workflows/`, adjust the `paths:` filter, and add a `working-directory`
  default pointing at this folder.
