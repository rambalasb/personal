terraform {
  required_version = ">= 1.9.0"

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.0"
    }
  }

  # State only. The TFC workspace execution mode is set to Local, so the GitHub
  # runner applies — not HCP. Org and workspace come from TF_CLOUD_ORGANIZATION
  # and TF_WORKSPACE in the pipeline.
  cloud {}
}

provider "azurerm" {
  features {}
  # subscription/client/tenant + OIDC come from ARM_* env vars
}
