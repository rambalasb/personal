output "resource_group_name" {
  value = azurerm_resource_group.this.name
}

output "sentinel_workspace_name" {
  value = azurerm_log_analytics_workspace.this.name
}

output "log_analytics_workspace_id" {
  value = azurerm_log_analytics_workspace.this.id
}

output "data_collection_endpoint_id" {
  value = azurerm_monitor_data_collection_endpoint.this.id
}

output "logs_ingestion_endpoint" {
  value = azurerm_monitor_data_collection_endpoint.this.logs_ingestion_endpoint
}
