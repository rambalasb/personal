variable "location" {
  type        = string
  description = "Azure region for all resources."
  default     = "canadacentral"
}

variable "resource_group_name" {
  type        = string
  description = "Resource group holding the Sentinel workspace and connector."
}

variable "log_analytics_workspace_name" {
  type        = string
  description = "Log Analytics workspace onboarded to Microsoft Sentinel."
}

variable "data_collection_endpoint_name" {
  type        = string
  description = "Data collection endpoint the connector ingests through."
  default     = "dce-hcp-terraform"
}

variable "log_analytics_retention_days" {
  type        = number
  description = "Workspace retention in days."
  default     = 90
}

variable "hcp_org_name" {
  type        = string
  description = "HCP Terraform organization slug the connector polls."
}

variable "hcp_audit_token" {
  type        = string
  description = "HCP Terraform audit-trail token. Supplied via TF_VAR_hcp_audit_token."
  sensitive   = true
}

variable "hcp_workspace_id" {
  type        = string
  description = "Optional HCP workspace ID (ws-xxxx) for the runs poller. Empty skips it."
  default     = ""
}

variable "polling_interval_minutes" {
  type        = number
  description = "Connector polling frequency in minutes."
  default     = 5
}

variable "enable_hcp_connector" {
  type        = bool
  description = "Deploy the connector ARM template. Keep false until azuredeploy.json holds the real solution resources; the first apply then stands up RG + workspace + Sentinel + DCE only."
  default     = false
}

variable "tags" {
  type        = map(string)
  description = "Tags applied to all resources."
  default     = {}
}
