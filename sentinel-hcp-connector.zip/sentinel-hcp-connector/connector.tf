# CCF objects (custom tables, DCR, connector definition, pollers) have no
# first-class azurerm resources, so they ship as an ARM template. The parameter
# contract is wired here; populate azuredeploy.json with the real HCP Terraform
# solution resources before setting enable_hcp_connector = true.
resource "azurerm_resource_group_template_deployment" "hcp_connector" {
  count = var.enable_hcp_connector ? 1 : 0

  name                = "hcp-terraform-sentinel-connector"
  resource_group_name = azurerm_resource_group.this.name
  deployment_mode     = "Incremental"
  template_content    = file("${path.module}/azuredeploy.json")

  parameters_content = jsonencode({
    workspaceName            = { value = azurerm_log_analytics_workspace.this.name }
    workspaceLocation        = { value = azurerm_resource_group.this.location }
    dceResourceId            = { value = azurerm_monitor_data_collection_endpoint.this.id }
    dceLogsIngestionEndpoint = { value = azurerm_monitor_data_collection_endpoint.this.logs_ingestion_endpoint }
    hcpOrgName               = { value = var.hcp_org_name }
    hcpApiToken              = { value = var.hcp_audit_token }
    hcpWorkspaceId           = { value = var.hcp_workspace_id }
    pollingIntervalMinutes   = { value = var.polling_interval_minutes }
  })

  depends_on = [azurerm_sentinel_log_analytics_workspace_onboarding.this]
}
