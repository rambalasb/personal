check "address_allocation_configured" {
  assert {
    condition     = (var.address_space != null) != (var.ipam_pools != null)
    error_message = "Exactly one of var.address_space or var.ipam_pools must be set (not both, not neither)."
  }
}

check "at_least_one_subnet" {
  assert {
    condition     = length(var.subnets) > 0
    error_message = "Virtual Network has no subnets defined. Most VNets need at least one subnet to be useful."
  }
}

check "ddos_plan_enabled_when_attached" {
  assert {
    condition     = var.ddos_protection_plan == null || try(var.ddos_protection_plan.enable, false)
    error_message = "When ddos_protection_plan.id is supplied, ddos_protection_plan.enable should be true to actually protect the VNet."
  }
}

check "encryption_enforcement_set_when_enabled" {
  assert {
    condition     = var.encryption == null || !try(var.encryption.enabled, false) || contains(["AllowUnencrypted", "DropUnencrypted"], try(var.encryption.enforcement, ""))
    error_message = "When encryption.enabled is true, encryption.enforcement must be 'AllowUnencrypted' or 'DropUnencrypted'."
  }
}

check "no_default_outbound_access_on_subnets" {
  assert {
    condition     = alltrue([for _, s in var.subnets : try(s.default_outbound_access_enabled, false) == false])
    error_message = "Subnets should set default_outbound_access_enabled = false. Default outbound access is being deprecated by Azure; use NAT Gateway, a load balancer, or explicit egress."
  }
}
