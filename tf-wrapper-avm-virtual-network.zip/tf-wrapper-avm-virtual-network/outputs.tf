output "resource_id" {
  description = "The resource ID of the Virtual Network."
  value       = module.virtual_network.resource_id
}

output "name" {
  description = "The name of the Virtual Network."
  value       = module.virtual_network.name
}

output "address_spaces" {
  description = "The address spaces of the Virtual Network. When ipam_pools is used, this reflects the dynamically allocated prefixes."
  value       = module.virtual_network.address_spaces
}

output "subnets" {
  description = "Map of subnets created by the module, keyed by the input map key. See the upstream subnet module documentation for the full attribute set."
  value       = module.virtual_network.subnets
}

output "peerings" {
  description = "Map of peerings created by the module, keyed by the input map key. See the upstream peering module documentation for the full attribute set."
  value       = module.virtual_network.peerings
}

output "resource" {
  description = "The full azapi_resource Virtual Network object."
  value       = module.virtual_network.resource
}
