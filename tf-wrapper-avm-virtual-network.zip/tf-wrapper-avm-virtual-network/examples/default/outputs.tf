output "resource_id" {
  value = module.virtual_network.resource_id
}

output "name" {
  value = module.virtual_network.name
}

output "subnets" {
  value = module.virtual_network.subnets
}
