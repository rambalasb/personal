module "virtual_network" {
  source = "../.."

  name          = "vnet-avm-default-test-${random_string.suffix.result}"
  parent_id     = azurerm_resource_group.this.id
  location      = azurerm_resource_group.this.location
  address_space = ["10.0.0.0/16"]

  subnets = {
    default = {
      name             = "snet-default"
      address_prefixes = ["10.0.1.0/24"]
    }
  }

  enable_telemetry = false
}
