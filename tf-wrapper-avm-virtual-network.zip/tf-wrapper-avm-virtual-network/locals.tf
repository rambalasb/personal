locals {
  module_tags = merge(
    var.tags == null ? {} : var.tags,
    {
      managed-by = "terraform"
      module     = "tf-wrapper-avm-virtual-network"
    }
  )

  uses_ipam_pools                    = var.ipam_pools != null
  has_subnets                        = length(var.subnets) > 0
  has_peerings                       = length(var.peerings) > 0
  encryption_enabled                 = var.encryption != null && try(var.encryption.enabled, false)
  ddos_protection_attached           = var.ddos_protection_plan != null && try(var.ddos_protection_plan.enable, false)
}
