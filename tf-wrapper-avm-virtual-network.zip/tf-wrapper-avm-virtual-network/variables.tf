# =====================================================================
# Required inputs
# =====================================================================

variable "name" {
  type        = string
  description = "The name of the Virtual Network. 2-64 characters, alphanumerics, underscores, periods, and hyphens; must start with alphanumeric and end with alphanumeric or underscore."

  validation {
    condition     = can(regex("^[a-zA-Z0-9][a-zA-Z0-9._-]{0,62}[a-zA-Z0-9_]$", var.name))
    error_message = "name must be 2-64 characters, start with an alphanumeric, end with alphanumeric or underscore, and contain only alphanumerics, underscores, periods, or hyphens."
  }
}

variable "parent_id" {
  type        = string
  description = "The full Azure resource ID of the resource group where the Virtual Network will be deployed (e.g. /subscriptions/<sub>/resourceGroups/<rg>)."

  validation {
    condition     = can(regex("^/subscriptions/[^/]+/resourceGroups/[^/]+$", var.parent_id))
    error_message = "parent_id must be a valid resource group ID (/subscriptions/<sub>/resourceGroups/<rg>)."
  }
}

variable "location" {
  type        = string
  description = "The Azure region where the Virtual Network will be deployed."

  validation {
    condition     = length(var.location) > 0
    error_message = "location must not be empty."
  }
}

# =====================================================================
# Address allocation — supply EITHER address_space OR ipam_pools (XOR)
# =====================================================================

variable "address_space" {
  type        = set(string)
  description = "CIDR address space(s) for the Virtual Network. Mutually exclusive with var.ipam_pools — exactly one must be set."
  default     = null

  validation {
    condition     = var.address_space == null || alltrue([for cidr in coalesce(var.address_space, []) : can(cidrnetmask(cidr))])
    error_message = "Each address_space entry must be a valid CIDR block (e.g. '10.0.0.0/16')."
  }
}

variable "ipam_pools" {
  type = list(object({
    id            = string
    prefix_length = number
  }))
  description = "IPAM pool allocations. One IPv4 pool (prefix 2-29) and one IPv6 pool (prefix 48-64) max. Mutually exclusive with var.address_space."
  default     = null
}

# =====================================================================
# Subnets, peerings
# =====================================================================

variable "subnets" {
  type = map(object({
    address_prefix   = optional(string)
    address_prefixes = optional(list(string))
    name             = string
    ipam_pools = optional(list(object({
      pool_id         = string
      prefix_length   = optional(number)
      allocation_type = optional(string, "Static")
    })))
    nat_gateway = optional(object({
      id = string
    }))
    network_security_group = optional(object({
      id = string
    }))
    private_endpoint_network_policies             = optional(string, "Enabled")
    private_link_service_network_policies_enabled = optional(bool, true)
    route_table = optional(object({
      id = string
    }))
    service_endpoint_policies = optional(map(object({
      id = string
    })))
    service_endpoints_with_location = optional(list(object({
      service   = string
      locations = optional(list(string), ["*"])
    })))
    default_outbound_access_enabled = optional(bool, false)
    sharing_scope                   = optional(string, null)
    delegations = optional(list(object({
      name = string
      service_delegation = object({
        name = string
      })
    })))
    timeouts = optional(object({
      create = optional(string, "30m")
      read   = optional(string, "5m")
      update = optional(string, "30m")
      delete = optional(string, "30m")
    }), {})
    retry = optional(object({
      error_message_regex  = optional(list(string), ["ReferencedResourceNotProvisioned"])
      interval_seconds     = optional(number, 10)
      max_interval_seconds = optional(number, 180)
    }), {})
    role_assignments = optional(map(object({
      role_definition_id_or_name             = string
      principal_id                           = string
      description                            = optional(string, null)
      skip_service_principal_aad_check       = optional(bool, false)
      condition                              = optional(string, null)
      condition_version                      = optional(string, null)
      delegated_managed_identity_resource_id = optional(string, null)
      principal_type                         = optional(string, null)
    })))
  }))
  description = "Map of subnets to create. Each subnet must specify exactly one of: ipam_pools, address_prefix, or address_prefixes."
  default     = {}
}

variable "peerings" {
  type = map(object({
    name                               = string
    remote_virtual_network_resource_id = string
    allow_forwarded_traffic            = optional(bool, false)
    allow_gateway_transit              = optional(bool, false)
    allow_virtual_network_access       = optional(bool, true)
    do_not_verify_remote_gateways      = optional(bool, false)
    enable_only_ipv6_peering           = optional(bool, false)
    peer_complete_vnets                = optional(bool, true)
    local_peered_address_spaces = optional(list(object({
      address_prefix = string
    })))
    remote_peered_address_spaces = optional(list(object({
      address_prefix = string
    })))
    local_peered_subnets = optional(list(object({
      subnet_name = string
    })))
    remote_peered_subnets = optional(list(object({
      subnet_name = string
    })))
    use_remote_gateways                   = optional(bool, false)
    create_reverse_peering                = optional(bool, false)
    reverse_name                          = optional(string)
    reverse_allow_forwarded_traffic       = optional(bool, false)
    reverse_allow_gateway_transit         = optional(bool, false)
    reverse_allow_virtual_network_access  = optional(bool, true)
    reverse_do_not_verify_remote_gateways = optional(bool, false)
    reverse_enable_only_ipv6_peering      = optional(bool, false)
    reverse_peer_complete_vnets           = optional(bool, true)
    reverse_local_peered_address_spaces = optional(list(object({
      address_prefix = string
    })))
    reverse_remote_peered_address_spaces = optional(list(object({
      address_prefix = string
    })))
    reverse_local_peered_subnets = optional(list(object({
      subnet_name = string
    })))
    reverse_remote_peered_subnets = optional(list(object({
      subnet_name = string
    })))
    reverse_use_remote_gateways        = optional(bool, false)
    sync_remote_address_space_enabled  = optional(bool, false)
    sync_remote_address_space_triggers = optional(any, null)
    timeouts = optional(object({
      create = optional(string, "30m")
      read   = optional(string, "5m")
      update = optional(string, "30m")
      delete = optional(string, "30m")
    }), {})
    retry = optional(object({
      error_message_regex  = optional(list(string), ["ReferencedResourceNotProvisioned"])
      interval_seconds     = optional(number, 10)
      max_interval_seconds = optional(number, 180)
    }), {})
  }))
  description = "Map of VNet peerings. Supports reverse peering, address-space sync, and per-peering timeouts/retry."
  default     = {}
}

# =====================================================================
# Networking knobs
# =====================================================================

variable "dns_servers" {
  type = object({
    dns_servers = list(string)
  })
  description = "Custom DNS servers for the VNet. Set null to use Azure-provided DNS."
  default     = null
}

variable "bgp_community" {
  type        = string
  description = "BGP community string sent to the virtual network gateway."
  default     = null
}

variable "flow_timeout_in_minutes" {
  type        = number
  description = "Flow timeout in minutes (4-30). Defaults to 4 when null."
  default     = null

  validation {
    condition     = var.flow_timeout_in_minutes == null || (try(var.flow_timeout_in_minutes, 0) >= 4 && try(var.flow_timeout_in_minutes, 0) <= 30)
    error_message = "flow_timeout_in_minutes must be between 4 and 30, or null."
  }
}

variable "enable_vm_protection" {
  type        = bool
  description = "Whether VM Protection is enabled on the VNet."
  default     = false
}

variable "encryption" {
  type = object({
    enabled     = bool
    enforcement = string
  })
  description = "VNet encryption settings. enforcement: 'AllowUnencrypted' or 'DropUnencrypted'. DropUnencrypted requires the AllowDropUnecryptedVnet subscription feature."
  default     = null

  validation {
    condition     = var.encryption == null || contains(["AllowUnencrypted", "DropUnencrypted"], try(var.encryption.enforcement, ""))
    error_message = "encryption.enforcement must be 'AllowUnencrypted' or 'DropUnencrypted' when encryption is set."
  }
}

variable "extended_location" {
  type = object({
    name = string
    type = string
  })
  description = "Extended location (Edge Zone) for the VNet. type must be 'EdgeZone'."
  default     = null
}

# =====================================================================
# Security / governance
# =====================================================================

variable "ddos_protection_plan" {
  type = object({
    id     = string
    enable = bool
  })
  description = "Azure DDoS Protection Plan association. id is the DDoS plan resource ID; enable toggles protection on the VNet."
  default     = null
}

variable "role_assignments" {
  type = map(object({
    role_definition_id_or_name             = string
    principal_id                           = string
    description                            = optional(string, null)
    skip_service_principal_aad_check       = optional(bool, false)
    condition                              = optional(string, null)
    condition_version                      = optional(string, null)
    delegated_managed_identity_resource_id = optional(string, null)
    principal_type                         = optional(string, null)
  }))
  description = "RBAC role assignments scoped to the Virtual Network. Common roles: 'Network Contributor', 'Reader'."
  default     = {}
}

variable "lock" {
  type = object({
    kind = string
    name = optional(string, null)
  })
  description = "Optional resource lock. kind must be 'CanNotDelete' or 'ReadOnly'."
  default     = null

  validation {
    condition     = var.lock == null || contains(["CanNotDelete", "ReadOnly"], try(var.lock.kind, ""))
    error_message = "lock.kind must be 'CanNotDelete' or 'ReadOnly' when lock is set."
  }
}

# =====================================================================
# Diagnostics
# =====================================================================

variable "diagnostic_settings" {
  type = map(object({
    name                                     = optional(string, null)
    log_categories                           = optional(set(string), [])
    log_groups                               = optional(set(string), ["allLogs"])
    metric_categories                        = optional(set(string), ["AllMetrics"])
    log_analytics_destination_type           = optional(string, "Dedicated")
    workspace_resource_id                    = optional(string, null)
    storage_account_resource_id              = optional(string, null)
    event_hub_authorization_rule_resource_id = optional(string, null)
    event_hub_name                           = optional(string, null)
    marketplace_partner_resource_id          = optional(string, null)
  }))
  description = "Map of diagnostic settings. At least one destination per entry is required."
  default     = {}
}

# =====================================================================
# Module behavior
# =====================================================================

variable "enable_telemetry" {
  type        = bool
  description = "Whether to enable AVM module telemetry. Set false to opt out."
  default     = true
}

variable "tags" {
  type        = map(string)
  description = "A map of tags to apply to the Virtual Network."
  default     = null
}

variable "retry" {
  type = object({
    error_message_regex  = optional(list(string), ["ReferencedResourceNotProvisioned"])
    interval_seconds     = optional(number, 10)
    max_interval_seconds = optional(number, 180)
  })
  description = "Retry configuration for resource operations."
  default     = {}
}

variable "timeouts" {
  type = object({
    create = optional(string, "30m")
    read   = optional(string, "5m")
    update = optional(string, "30m")
    delete = optional(string, "30m")
  })
  description = "Operation timeouts for the VNet resource."
  default     = {}
}
