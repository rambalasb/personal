module "virtual_network" {
  source  = "Azure/avm-res-network-virtualnetwork/azurerm"
  version = "0.17.1"

  # Required
  name      = var.name
  parent_id = var.parent_id
  location  = var.location

  # Address allocation (XOR)
  address_space = var.address_space
  ipam_pools    = var.ipam_pools

  # Subnets and peerings
  subnets  = var.subnets
  peerings = var.peerings

  # Networking knobs
  dns_servers             = var.dns_servers
  bgp_community           = var.bgp_community
  flow_timeout_in_minutes = var.flow_timeout_in_minutes
  enable_vm_protection    = var.enable_vm_protection
  encryption              = var.encryption
  extended_location       = var.extended_location

  # Security / governance
  ddos_protection_plan = var.ddos_protection_plan
  role_assignments     = var.role_assignments
  lock                 = var.lock

  # Diagnostics
  diagnostic_settings = var.diagnostic_settings

  # Module behavior
  enable_telemetry = var.enable_telemetry
  tags             = local.module_tags
  retry            = var.retry
  timeouts         = var.timeouts
}
