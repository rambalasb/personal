output "resource_id" {
  value = module.api_connection.resource_id
}

output "name" {
  value = module.api_connection.name
}

output "managed_api_id" {
  value = module.api_connection.managed_api_id
}
