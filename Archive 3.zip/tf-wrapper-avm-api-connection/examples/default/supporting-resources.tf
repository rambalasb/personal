# resource group names must be unique within the subscription
resource "random_string" "suffix" {
  length  = 6
  lower   = true
  upper   = false
  numeric = true
  special = false
}

# native supporting resources so the example tests standalone, without a sibling module
resource "azurerm_resource_group" "this" {
  name     = "rg-avm-apicon-default-test-${random_string.suffix.result}"
  location = "canadacentral"
}
