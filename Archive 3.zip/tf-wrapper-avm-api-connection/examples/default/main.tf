# The connection is created without parameter_values, which is how an OAuth
# managed API is meant to be set up: the resource exists unauthorised until a
# user or managed identity consents to it. Key-based APIs such as servicebus
# instead need their connection string, which belongs out-of-band rather than
# in Terraform state.
module "api_connection" {
  source = "../.."

  name                = "azureblob"
  resource_group_name = azurerm_resource_group.this.name

  location         = azurerm_resource_group.this.location
  managed_api_name = "azureblob"

  display_name = "Blob storage (example)"

  enable_telemetry = false
}
