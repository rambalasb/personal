check "parameter_values_are_not_inline_secrets" {
  assert {
    condition     = length(nonsensitive(var.parameter_values)) == 0
    error_message = "parameter_values is set. The values land in state in clear text and any edit replaces the connection, breaking every Logic App run in flight. Authorise the connection out-of-band, or store the values in Key Vault and reference them from the Logic App."
  }
}

check "managed_api_region_matches_location" {
  assert {
    condition     = var.managed_api_id == null || var.location == null || can(regex("/locations/${lower(var.location)}/", lower(var.managed_api_id)))
    error_message = "managed_api_id points at a managed API in a different region from var.location. A Logic App can only use a connection whose managed API is in its own region."
  }
}

check "lock_is_not_read_only" {
  assert {
    condition     = var.lock == null || try(var.lock.kind, "") != "ReadOnly"
    error_message = "A ReadOnly lock blocks the connection-auth handshake, so the connection cannot be re-consented when its token expires. Use CanNotDelete."
  }
}
