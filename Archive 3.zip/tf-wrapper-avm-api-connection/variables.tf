# =====================================================================
# Required inputs
# =====================================================================

variable "name" {
  type        = string
  description = "The name of the API Connection. Forces a new resource. Azure-generated connections are usually named after the managed API, for example 'azureblob' or 'office365'."

  validation {
    condition     = can(regex("^[a-zA-Z0-9][a-zA-Z0-9._-]{0,78}[a-zA-Z0-9]$", var.name))
    error_message = "name must be 2-80 characters, start and end alphanumeric, and otherwise contain only letters, numbers, hyphens, underscores and periods."
  }
}

variable "resource_group_name" {
  type        = string
  description = "Name of the resource group the API Connection lives in. Must be the same group as the Logic App that consumes it."

  validation {
    condition     = length(var.resource_group_name) > 0
    error_message = "resource_group_name must not be empty."
  }
}

# =====================================================================
# Managed API target -- supply managed_api_id, or location + managed_api_name
# =====================================================================

variable "managed_api_id" {
  type        = string
  description = "Resource ID of the managed API this connection is linked to. Leave null and set location + managed_api_name to have it built. Forces a new resource."
  default     = null

  validation {
    condition     = var.managed_api_id == null || can(regex("^/subscriptions/[^/]+/providers/Microsoft.Web/locations/[^/]+/managedApis/[^/]+$", coalesce(var.managed_api_id, "/")))
    error_message = "managed_api_id must be /subscriptions/<sub>/providers/Microsoft.Web/locations/<region>/managedApis/<api>."
  }
}

variable "managed_api_name" {
  type        = string
  description = "Name of the managed API, for example 'azureblob', 'servicebus', 'office365' or 'azuremonitorlogs'. Used with location to build managed_api_id when that is not given directly."
  default     = null

  validation {
    condition     = var.managed_api_name != null || var.managed_api_id != null
    error_message = "Set either managed_api_name (with location) or managed_api_id."
  }

  validation {
    condition     = var.managed_api_name == null || var.location != null
    error_message = "managed_api_name needs location to build the managed API ID. Set location, or pass managed_api_id instead."
  }
}

variable "location" {
  type        = string
  description = "Azure region of the managed API. Ignored when managed_api_id is supplied. The connection itself has no location of its own -- it inherits the resource group's."
  default     = null
}

# =====================================================================
# Connection configuration
# =====================================================================

variable "display_name" {
  type        = string
  description = "Display name shown in the portal and in the Logic App designer. Defaults to var.name. Forces a new resource."
  default     = null
}

variable "parameter_values" {
  type        = map(string)
  description = "Parameter values for the connection, such as an account name or a connection string. Held in clear text in state and any change forces the connection to be replaced. Leave empty for connections authorised interactively or through a managed identity."
  default     = {}
  sensitive   = true
}

# =====================================================================
# Governance
# =====================================================================

variable "role_assignments" {
  type = map(object({
    role_definition_id_or_name             = string
    principal_id                           = string
    description                            = optional(string, null)
    skip_service_principal_aad_check       = optional(bool, false)
    condition                              = optional(string, null)
    condition_version                      = optional(string, null)
    delegated_managed_identity_resource_id = optional(string, null)
    principal_type                         = optional(string, null)
  }))
  description = "Role assignments to create on the connection, keyed by an arbitrary string. RBAC here is control-plane only; it does not grant the connection access to its backing service."
  default     = {}
  nullable    = false
}

variable "lock" {
  type = object({
    kind = string
    name = optional(string, null)
  })
  description = "Management lock to place on the connection. kind is 'CanNotDelete' or 'ReadOnly'. A ReadOnly lock blocks the connection-auth handshake, so prefer CanNotDelete."
  default     = null

  validation {
    condition     = var.lock == null ? true : contains(["CanNotDelete", "ReadOnly"], var.lock.kind)
    error_message = "lock.kind must be CanNotDelete or ReadOnly."
  }
}

# =====================================================================
# Tagging and module behaviour
# =====================================================================

variable "tags" {
  type        = map(string)
  description = "A map of tags to apply to the API Connection."
  default     = null
}

variable "wrapper_tags_enabled" {
  type        = bool
  description = "Adds managed-by and module tags identifying the wrapper. Set false when adopting an existing connection whose tags must not change."
  default     = true
  nullable    = false
}

variable "enable_telemetry" {
  type        = bool
  description = "Controls AVM telemetry collection in the upstream module. See https://aka.ms/avm/telemetryinfo."
  default     = true
  nullable    = false
}
