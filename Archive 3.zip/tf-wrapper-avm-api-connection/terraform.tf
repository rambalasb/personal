terraform {
  required_version = ">= 1.9, < 2.0"

  required_providers {
    # The connection, its lock and role assignments are azurerm. azapi appears
    # only in the upstream telemetry block. Both floors match AVM
    # avm-res-web-connection v0.1.0.
    azapi = {
      source  = "Azure/azapi"
      version = "~> 2.4"
    }
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 4.0, < 5.0"
    }
  }
}
