output "resource_id" {
  description = "The resource ID of the API Connection."
  value       = module.api_connection.resource_id
}

output "name" {
  description = "The name of the API Connection."
  value       = module.api_connection.name
}

output "managed_api_id" {
  description = "Resource ID of the managed API the connection is linked to, whether passed in or built from location and managed_api_name."
  value       = local.managed_api_id
}

output "resource" {
  description = "The full API Connection resource. Sensitive because parameter_values can carry connection secrets."
  value       = module.api_connection.resource
  sensitive   = true
}
