locals {
  # managed-by/module mark the resource as wrapper-managed. Suppressible because
  # adopting an existing connection otherwise forces a write purely to add them.
  # Greenfield callers should leave this alone.
  wrapper_tags = var.wrapper_tags_enabled ? {
    managed-by = "terraform"
    module     = "tf-wrapper-avm-api-connection"
  } : {}

  module_tags = merge(
    var.tags == null ? {} : var.tags,
    local.wrapper_tags
  )

  managed_api_id = coalesce(var.managed_api_id, one(data.azurerm_managed_api.this[*].id))
}
