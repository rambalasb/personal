# Resolves the managed API when the caller names one instead of passing its ID.
# The data source fails at plan time on a name Azure does not publish in the
# region, which a hand-built ID would only surface on apply.
data "azurerm_managed_api" "this" {
  count = var.managed_api_name == null ? 0 : 1

  name     = var.managed_api_name
  location = var.location
}

module "api_connection" {
  source  = "Azure/avm-res-web-connection/azurerm"
  version = "0.1.0"

  # Required
  name                = var.name
  resource_group_name = var.resource_group_name
  managed_api_id      = local.managed_api_id

  # Upstream defaults display_name to the literal "Service Bus" regardless of
  # which API is connected, and changing it later replaces the connection.
  display_name = coalesce(var.display_name, var.name)

  # Connection auth. Every value here is stored in state in clear text and any
  # change forces replacement -- see the check in checks.tf.
  parameter_values = var.parameter_values

  # Governance
  role_assignments = var.role_assignments
  lock             = var.lock

  # Module behavior
  enable_telemetry = var.enable_telemetry
  tags             = local.module_tags
}
