locals {
  # managed-by/module mark the resource as wrapper-managed. Suppressible because
  # adopting an existing namespace otherwise forces a write purely to add them.
  # Greenfield callers should leave this alone.
  wrapper_tags = var.wrapper_tags_enabled ? {
    managed-by = "terraform"
    module     = "tf-wrapper-avm-eventhub-namespace"
  } : {}

  module_tags = merge(
    var.tags == null ? {} : var.tags,
    local.wrapper_tags
  )

  namespace_name = coalesce(try(var.existing_parent_resource.name, null), var.name)

  event_hubs = {
    for k, v in var.event_hubs : k => merge(v, {
      namespace_name      = local.namespace_name
      resource_group_name = var.resource_group_name
    })
  }

  # Basic caps retention at one day and rejects capture; Standard caps it at
  # seven. Only a dedicated cluster reaches 90.
  max_message_retention = var.dedicated_cluster_id != null ? 90 : (var.sku == "Basic" ? 1 : 7)
}
