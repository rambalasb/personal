# =====================================================================
# Required inputs
# =====================================================================

variable "name" {
  type        = string
  description = "The name of the Event Hub Namespace. Must be 6-50 characters, letters, numbers and hyphens, starting with a letter and ending alphanumeric, and globally unique."

  validation {
    condition     = can(regex("^[a-zA-Z][a-zA-Z0-9-]{4,48}[a-zA-Z0-9]$", var.name))
    error_message = "name must be 6-50 characters, start with a letter, end alphanumeric, and contain only letters, numbers and hyphens."
  }
}

variable "resource_group_name" {
  type        = string
  description = "Name of the resource group the namespace and its hubs live in."

  validation {
    condition     = length(var.resource_group_name) > 0
    error_message = "resource_group_name must not be empty."
  }
}

variable "location" {
  type        = string
  description = "Azure region for the namespace. Required: upstream documents that a null infers the resource group's region, but the variable is declared nullable = false, so a null fails the plan."

  validation {
    condition     = length(var.location) > 0
    error_message = "location must not be empty."
  }
}

# =====================================================================
# Tier and throughput
# =====================================================================

variable "sku" {
  type        = string
  description = "Namespace tier: 'Basic', 'Standard' or 'Premium'. Basic has no capture, no consumer groups beyond $Default and one day of retention. Private endpoints need Premium."
  default     = "Standard"

  validation {
    condition     = contains(["Basic", "Standard", "Premium"], var.sku)
    error_message = "sku must be one of: Basic, Standard, Premium."
  }
}

variable "capacity" {
  type        = number
  description = "Throughput units (Basic/Standard) or processing units (Premium). Standard allows 1-40; Premium allows 1, 2, 4, 8 or 16."
  default     = 1

  validation {
    condition     = var.capacity >= 1 && var.capacity <= 40
    error_message = "capacity must be between 1 and 40."
  }
}

variable "auto_inflate_enabled" {
  type        = bool
  description = "Auto-inflate throughput units. Upstream v0.1.0 carries a precondition that fails whenever this is true, so it must stay false until that is fixed."
  default     = false
  nullable    = false

  validation {
    condition     = var.auto_inflate_enabled == false
    error_message = "auto_inflate_enabled must be false. Upstream avm-res-eventhub-namespace v0.1.0 asserts 'maximum_throughput_units == null && !auto_inflate_enabled', so any true value fails the plan. Scale capacity instead, or set auto-inflate outside Terraform."
  }
}

variable "maximum_throughput_units" {
  type        = number
  description = "Ceiling for auto-inflate. Unusable while auto_inflate_enabled is forced false, so it must stay null."
  default     = null

  validation {
    condition     = var.maximum_throughput_units == null
    error_message = "maximum_throughput_units must be null. The upstream precondition rejects any value, and its own validation is inverted -- it accepts only values outside 1-20."
  }
}

variable "dedicated_cluster_id" {
  type        = string
  description = "Resource ID of an Event Hubs dedicated cluster to place the namespace in. Forces a new resource."
  default     = null
}

# =====================================================================
# Access control plane
# =====================================================================

variable "local_authentication_enabled" {
  type        = bool
  description = "Allow SAS key authentication. Leave false so publishers and consumers authenticate with Entra ID."
  default     = false
  nullable    = false
}

variable "public_network_access_enabled" {
  type        = bool
  description = "Allow access from public networks. Leave false and reach the namespace over a private endpoint."
  default     = false
  nullable    = false
}

variable "network_rulesets" {
  type = object({
    default_action                 = optional(string, "Deny")
    public_network_access_enabled  = bool
    trusted_service_access_enabled = bool
    ip_rule = optional(list(object({
      action  = optional(string, "Allow")
      ip_mask = string
    })), [])
    virtual_network_rule = optional(list(object({
      ignore_missing_virtual_network_service_endpoint = optional(bool)
      subnet_id                                       = string
    })), [])
  })
  description = <<DESCRIPTION
Network rule set for the namespace. Not supported on the Basic tier.

- `default_action` - 'Allow' or 'Deny'. Defaults to 'Deny'.
- `public_network_access_enabled` - must agree with the namespace-level setting.
- `trusted_service_access_enabled` - lets first-party services such as Event Grid and Monitor bypass the rules.
- `ip_rule` - CIDR allowlist; only the 'Allow' action exists.
- `virtual_network_rule` - service-endpoint subnets allowed through.
DESCRIPTION
  default     = null

  validation {
    condition     = var.network_rulesets == null ? true : contains(["Allow", "Deny"], var.network_rulesets.default_action)
    error_message = "network_rulesets.default_action must be Allow or Deny."
  }

  validation {
    condition     = var.network_rulesets == null ? true : var.sku != "Basic"
    error_message = "network_rulesets is not supported on the Basic tier. Use Standard or Premium."
  }
}

# =====================================================================
# Hubs
# =====================================================================

variable "event_hubs" {
  type = map(object({
    partition_count   = number
    message_retention = number
    status            = optional(string)
    capture_description = optional(object({
      enabled             = bool
      encoding            = string
      interval_in_seconds = optional(number)
      size_limit_in_bytes = optional(number)
      skip_empty_archives = optional(bool)
      destination = object({
        name                = optional(string, "EventHubArchive.AzureBlockBlob")
        archive_name_format = string
        blob_container_name = string
        storage_account_id  = string
      })
    }))
    role_assignments = optional(map(object({
      role_definition_id_or_name             = string
      principal_id                           = string
      description                            = optional(string, null)
      skip_service_principal_aad_check       = optional(bool, false)
      condition                              = optional(string, null)
      condition_version                      = optional(string, null)
      delegated_managed_identity_resource_id = optional(string, null)
    })), {})
  }))
  description = <<DESCRIPTION
Event hubs to create in the namespace, keyed by hub name. The namespace and
resource group are filled in by the wrapper.

- `partition_count` - fixed at creation on Standard; 1-32 on a shared namespace, 1-1024 on a dedicated cluster.
- `message_retention` - retention in days. Basic allows 1, Standard 7, a dedicated cluster 90.
- `status` - 'Active', 'Disabled' or 'SendDisabled'.
- `capture_description` - Avro capture to a blob container. Standard tier or above.
  - `destination.archive_name_format` - must contain every token: {Namespace}, {EventHub}, {PartitionId}, {Year}, {Month}, {Day}, {Hour}, {Minute}, {Second}.
- `role_assignments` - data-plane RBAC on the hub, such as 'Azure Event Hubs Data Sender'.
DESCRIPTION
  default     = {}
  nullable    = false

  validation {
    condition = alltrue([
      for _, v in var.event_hubs : v.status == null || contains(["Active", "Disabled", "SendDisabled"], coalesce(v.status, "Active"))
    ])
    error_message = "event_hubs status must be Active, Disabled or SendDisabled."
  }

  validation {
    condition = alltrue([
      for _, v in var.event_hubs : v.partition_count >= 1 && v.partition_count <= 1024
    ])
    error_message = "event_hubs partition_count must be between 1 and 1024, and no more than 32 unless the namespace sits on a dedicated cluster."
  }

  validation {
    condition = alltrue([
      for _, v in var.event_hubs :
      v.capture_description == null || contains(["Avro", "AvroDeflate"], try(v.capture_description.encoding, "Avro"))
    ])
    error_message = "event_hubs capture_description.encoding must be Avro or AvroDeflate."
  }
}

variable "existing_parent_resource" {
  type = object({
    name = string
  })
  description = "Name of an existing namespace to attach hubs to instead of creating one. The namespace itself is then read, not managed, so lock and role_assignments must be left unset."
  default     = null

  validation {
    condition     = var.existing_parent_resource == null || (var.lock == null && length(var.role_assignments) == 0)
    error_message = "existing_parent_resource cannot be combined with lock or role_assignments: upstream scopes both to the namespace it creates and fails on an empty index when none is created."
  }
}

# =====================================================================
# Networking
# =====================================================================

variable "private_endpoints" {
  type = map(object({
    name = optional(string, null)
    role_assignments = optional(map(object({
      role_definition_id_or_name             = string
      principal_id                           = string
      description                            = optional(string, null)
      skip_service_principal_aad_check       = optional(bool, false)
      condition                              = optional(string, null)
      condition_version                      = optional(string, null)
      delegated_managed_identity_resource_id = optional(string, null)
      principal_type                         = optional(string, null)
    })), {})
    lock = optional(object({
      kind = string
      name = optional(string, null)
    }), null)
    tags                                    = optional(map(string), null)
    subnet_resource_id                      = string
    subresource_name                        = string
    private_dns_zone_group_name             = optional(string, "default")
    private_dns_zone_resource_ids           = optional(set(string), [])
    application_security_group_associations = optional(map(string), {})
    private_service_connection_name         = optional(string, null)
    network_interface_name                  = optional(string, null)
    location                                = optional(string, null)
    resource_group_name                     = optional(string, null)
    ip_configurations = optional(map(object({
      name               = string
      private_ip_address = string
    })), {})
  }))
  description = <<DESCRIPTION
Private endpoints to create on the namespace, keyed by an arbitrary string.
Not available on the Basic tier. `subresource_name` is 'namespace' for Event Hubs.
The private DNS zone is privatelink.servicebus.windows.net.

Note that every tf-deploy-app-* repo declares private endpoints as their own
tier through tf-wrapper-avm-private-endpoint. Using both for one endpoint gives
a single Azure resource two Terraform owners -- pick one.
DESCRIPTION
  default     = {}
  nullable    = false

  validation {
    condition     = alltrue([for _, v in var.private_endpoints : v.subresource_name == "namespace"])
    error_message = "private_endpoints subresource_name must be 'namespace' for an Event Hub Namespace."
  }
}

variable "private_endpoints_manage_dns_zone_group" {
  type        = bool
  description = "Let this module manage the private DNS zone group. Set false where a policy or a central DNS pipeline owns the records."
  default     = true
  nullable    = false
}

# =====================================================================
# Identity, governance and diagnostics
# =====================================================================

variable "managed_identities" {
  type = object({
    system_assigned            = optional(bool, false)
    user_assigned_resource_ids = optional(set(string), [])
  })
  description = "Managed identity configuration. Upstream v0.1.0 attaches a system-assigned identity whether or not this is set; the input only adds user-assigned ones."
  default     = {}
  nullable    = false
}

variable "role_assignments" {
  type = map(object({
    role_definition_id_or_name             = string
    principal_id                           = string
    description                            = optional(string, null)
    skip_service_principal_aad_check       = optional(bool, false)
    condition                              = optional(string, null)
    condition_version                      = optional(string, null)
    delegated_managed_identity_resource_id = optional(string, null)
    principal_type                         = optional(string, null)
  }))
  description = "Role assignments scoped to the whole namespace, keyed by an arbitrary string. Prefer per-hub assignments in var.event_hubs for data-plane access."
  default     = {}
  nullable    = false
}

variable "lock" {
  type = object({
    kind = string
    name = optional(string, null)
  })
  description = "Management lock on the namespace. kind is 'CanNotDelete' or 'ReadOnly'. ReadOnly blocks hub and consumer-group changes."
  default     = null

  validation {
    condition     = var.lock == null ? true : contains(["CanNotDelete", "ReadOnly"], var.lock.kind)
    error_message = "lock.kind must be CanNotDelete or ReadOnly."
  }
}

variable "diagnostic_settings" {
  type = map(object({
    name                                     = optional(string, null)
    log_categories                           = optional(set(string), [])
    log_groups                               = optional(set(string), ["allLogs"])
    metric_categories                        = optional(set(string), ["AllMetrics"])
    log_analytics_destination_type           = optional(string, "Dedicated")
    workspace_resource_id                    = optional(string, null)
    storage_account_resource_id              = optional(string, null)
    event_hub_authorization_rule_resource_id = optional(string, null)
    event_hub_name                           = optional(string, null)
    marketplace_partner_resource_id          = optional(string, null)
  }))
  description = <<DESCRIPTION
Diagnostic settings on the namespace, keyed by an arbitrary string. Created by
this wrapper rather than the upstream module, which declares the input but
never reads it in v0.1.0.

- `name` - defaults to 'diag-<key>'.
- `log_categories` / `log_groups` - set one or the other; 'allLogs' covers ArchiveLogs, OperationalLogs, AutoScaleLogs, KafkaCoordinatorLogs, KafkaUserErrorLogs, EventHubVNetConnectionEvent and CustomerManagedKeyUserLogs.
- `metric_categories` - 'AllMetrics' is the only category the namespace publishes.
DESCRIPTION
  default     = {}
  nullable    = false

  validation {
    condition = alltrue([
      for _, v in var.diagnostic_settings :
      v.workspace_resource_id != null || v.storage_account_resource_id != null || v.event_hub_authorization_rule_resource_id != null || v.marketplace_partner_resource_id != null
    ])
    error_message = "Each diagnostic setting needs a destination: workspace_resource_id, storage_account_resource_id, event_hub_authorization_rule_resource_id or marketplace_partner_resource_id."
  }
}

# =====================================================================
# Tagging and module behaviour
# =====================================================================

variable "tags" {
  type        = map(string)
  description = "A map of tags to apply to the Event Hub Namespace."
  default     = null
}

variable "wrapper_tags_enabled" {
  type        = bool
  description = "Adds managed-by and module tags identifying the wrapper. Set false when adopting an existing namespace whose tags must not change."
  default     = true
  nullable    = false
}

variable "enable_telemetry" {
  type        = bool
  description = "Controls AVM telemetry collection in the upstream module. See https://aka.ms/avm/telemetryinfo."
  default     = true
  nullable    = false
}
