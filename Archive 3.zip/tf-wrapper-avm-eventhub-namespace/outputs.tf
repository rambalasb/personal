output "resource_id" {
  description = "The resource ID of the Event Hub Namespace, whether created here or read through existing_parent_resource."
  value       = module.eventhub_namespace.resource_id
}

output "name" {
  description = "The name of the Event Hub Namespace."
  value       = local.namespace_name
}

output "resource" {
  description = "The full Event Hub Namespace resource. Sensitive upstream because the namespace carries its default SAS connection strings."
  value       = module.eventhub_namespace.resource
  sensitive   = true
}

output "event_hubs" {
  description = "Map of the event hubs created, keyed by hub name."
  value       = module.eventhub_namespace.resource_eventhubs
}

output "event_hub_ids" {
  description = "Map of hub name to resource ID. Use these to scope RBAC or to point a diagnostic setting at a hub."
  value       = { for k, v in module.eventhub_namespace.resource_eventhubs : k => v.id }
}

output "private_endpoints" {
  description = "Map of the private endpoints created on the namespace."
  value       = module.eventhub_namespace.private_endpoints
}

output "diagnostic_setting_ids" {
  description = "Resource IDs of the diagnostic settings this wrapper created on the namespace, keyed by the input map key."
  value       = { for k, v in azurerm_monitor_diagnostic_setting.this : k => v.id }
}

# Unwrapped from the sensitive resource output: a principal ID is not a secret,
# and callers need it in plain form to grant the namespace access to a capture
# storage account or a customer-managed key.
output "system_assigned_mi_principal_id" {
  description = "Principal ID of the namespace's system-assigned managed identity. Null when the namespace is read rather than created."
  value       = try(nonsensitive(module.eventhub_namespace.resource.identity[0].principal_id), null)
}
