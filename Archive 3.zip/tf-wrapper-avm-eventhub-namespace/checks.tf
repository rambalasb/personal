check "entra_auth_only" {
  assert {
    condition     = var.local_authentication_enabled == false
    error_message = "Event Hub Namespace accepts SAS key authentication. Set var.local_authentication_enabled = false and grant clients 'Azure Event Hubs Data Sender' or 'Data Receiver'."
  }
}

check "public_network_access_disabled_by_default" {
  assert {
    condition     = var.public_network_access_enabled == false || (var.network_rulesets != null && var.network_rulesets.default_action == "Deny")
    error_message = "Public network access is enabled with no deny-by-default rule set, leaving the namespace reachable from any address. Set var.public_network_access_enabled = false, or supply var.network_rulesets with default_action = \"Deny\"."
  }
}

check "private_endpoint_implies_no_public_access" {
  assert {
    condition     = length(var.private_endpoints) == 0 || var.public_network_access_enabled == false
    error_message = "When private endpoints are configured, public network access should be disabled. Set var.public_network_access_enabled = false."
  }
}

check "private_endpoints_not_on_basic" {
  assert {
    condition     = length(var.private_endpoints) == 0 || var.sku != "Basic"
    error_message = "Private Link is not supported on the Basic tier. Move the namespace to Standard or Premium."
  }
}

check "diagnostic_settings_configured" {
  assert {
    condition     = length(var.diagnostic_settings) > 0 || var.existing_parent_resource != null
    error_message = "Event Hub Namespace has no diagnostic settings configured. Send allLogs and AllMetrics to a workspace so throttling and failed sends are visible."
  }
}

check "message_retention_within_tier" {
  assert {
    condition = alltrue([
      for _, v in var.event_hubs : v.message_retention <= local.max_message_retention
    ])
    error_message = "An event hub asks for more retention than the namespace tier allows. Basic keeps 1 day, Standard 7, and only a dedicated cluster reaches 90."
  }
}

check "capture_needs_standard_or_above" {
  assert {
    condition = var.sku != "Basic" || alltrue([
      for _, v in var.event_hubs : try(v.capture_description.enabled, false) == false
    ])
    error_message = "Event Hubs Capture is not available on the Basic tier. Move the namespace to Standard or Premium, or drop capture_description."
  }
}

check "capture_archive_name_format_is_complete" {
  assert {
    condition = alltrue([
      for _, v in var.event_hubs : alltrue([
        for token in ["{Namespace}", "{EventHub}", "{PartitionId}", "{Year}", "{Month}", "{Day}", "{Hour}", "{Minute}", "{Second}"] :
        strcontains(try(v.capture_description.destination.archive_name_format, ""), token)
      ]) if try(v.capture_description, null) != null
    ])
    error_message = "A capture archive_name_format is missing one of the required tokens. Azure rejects the hub unless {Namespace}, {EventHub}, {PartitionId}, {Year}, {Month}, {Day}, {Hour}, {Minute} and {Second} all appear."
  }
}

check "trusted_service_access_for_capture" {
  assert {
    condition = var.network_rulesets == null || var.network_rulesets.trusted_service_access_enabled || alltrue([
      for _, v in var.event_hubs : try(v.capture_description.enabled, false) == false
    ])
    error_message = "Capture is enabled while the network rule set blocks trusted services, so the namespace cannot write to the capture storage account. Set network_rulesets.trusted_service_access_enabled = true."
  }
}
