terraform {
  required_version = ">= 1.9, < 2.0"

  required_providers {
    # Everything the upstream module and this wrapper create is azurerm. The
    # floor matches AVM avm-res-eventhub-namespace v0.1.0.
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 4.0, < 5.0"
    }
  }
}
