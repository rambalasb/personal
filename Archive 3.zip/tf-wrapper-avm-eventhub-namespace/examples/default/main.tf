# Public access stays on here because the example has no virtual network to
# reach the namespace from; a real namespace pairs public_network_access_enabled
# = false with a private endpoint, which the wrapper's checks will point out.
module "eventhub_namespace" {
  source = "../.."

  name                = "evhns-avm-default-${random_string.suffix.result}"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location

  sku      = "Standard"
  capacity = 1

  public_network_access_enabled = true

  event_hubs = {
    telemetry = {
      partition_count   = 2
      message_retention = 1

      role_assignments = {
        receiver = {
          role_definition_id_or_name = "Azure Event Hubs Data Receiver"
          principal_id               = data.azurerm_client_config.current.object_id
        }
      }
    }
  }

  diagnostic_settings = {
    to_law = {
      workspace_resource_id = azurerm_log_analytics_workspace.this.id
    }
  }

  enable_telemetry = false
}
