output "resource_id" {
  value = module.eventhub_namespace.resource_id
}

output "name" {
  value = module.eventhub_namespace.name
}

output "event_hub_ids" {
  value = module.eventhub_namespace.event_hub_ids
}
