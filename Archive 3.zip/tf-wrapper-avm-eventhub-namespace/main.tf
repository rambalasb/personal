# Upstream v0.1.0 emits its identity block unconditionally -- the guard is
# `var.managed_identities != {}`, and the defaulted object never equals an empty
# one -- so the namespace always ends up with a system-assigned identity, even
# with managed_identities left alone. Adopting a namespace that has none will
# therefore show an identity diff on the first plan.
module "eventhub_namespace" {
  source  = "Azure/avm-res-eventhub-namespace/azurerm"
  version = "0.1.0"

  # Required
  name                = var.name
  resource_group_name = var.resource_group_name
  location            = var.location

  # Namespace tier and throughput
  sku                      = var.sku
  capacity                 = var.capacity
  auto_inflate_enabled     = var.auto_inflate_enabled
  maximum_throughput_units = var.maximum_throughput_units
  dedicated_cluster_id     = var.dedicated_cluster_id

  # Access control plane. minimum_tls_version is pinned to 1.2 upstream and is
  # not an input.
  local_authentication_enabled  = var.local_authentication_enabled
  public_network_access_enabled = var.public_network_access_enabled
  network_rulesets              = var.network_rulesets

  # Hubs. namespace_name and resource_group_name are required by the upstream
  # object type but ignored by its resource, so they are filled in locals.tf
  # rather than repeated by every caller.
  event_hubs = local.event_hubs

  # Adopt a namespace this module does not own, to hang hubs off it.
  existing_parent_resource = var.existing_parent_resource

  # Networking
  private_endpoints                       = var.private_endpoints
  private_endpoints_manage_dns_zone_group = var.private_endpoints_manage_dns_zone_group

  # Identity and governance
  managed_identities = var.managed_identities
  role_assignments   = var.role_assignments
  lock               = var.lock

  # Module behavior
  enable_telemetry = var.enable_telemetry
  tags             = local.module_tags
}

# Upstream declares diagnostic_settings and customer_managed_key but wires
# neither to a resource in v0.1.0, so diagnostics are created here. Move them
# back to the module input once upstream implements it, and re-import: the
# address changes.
resource "azurerm_monitor_diagnostic_setting" "this" {
  for_each = var.diagnostic_settings

  name                           = coalesce(each.value.name, "diag-${each.key}")
  target_resource_id             = module.eventhub_namespace.resource_id
  eventhub_authorization_rule_id = each.value.event_hub_authorization_rule_resource_id
  eventhub_name                  = each.value.event_hub_name
  log_analytics_destination_type = each.value.workspace_resource_id == null ? null : each.value.log_analytics_destination_type
  log_analytics_workspace_id     = each.value.workspace_resource_id
  partner_solution_id            = each.value.marketplace_partner_resource_id
  storage_account_id             = each.value.storage_account_resource_id

  dynamic "enabled_log" {
    for_each = each.value.log_categories

    content {
      category = enabled_log.value
    }
  }
  dynamic "enabled_log" {
    for_each = each.value.log_groups

    content {
      category_group = enabled_log.value
    }
  }
  dynamic "enabled_metric" {
    for_each = each.value.metric_categories

    content {
      category = enabled_metric.value
    }
  }
}
