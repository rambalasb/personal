locals {
  module_tags = merge(
    var.tags == null ? {} : var.tags,
    {
      managed-by = "terraform"
      module     = "tf-wrapper-avm-network-loadbalancer"
    }
  )

  # Upstream defaults an unset frontend name to "frontend-<lb name>". Rule
  # cross-references resolve against the name, not the map key, so they have to
  # be compared against the same coalesce.
  frontend_names = [
    for k, v in var.frontend_ip_configurations : coalesce(v.name, "frontend-${var.name}")
  ]

  # Rules address backend pools and probes by map key, not by name.
  backend_pool_keys = keys(var.backend_address_pools)
  probe_keys        = keys(var.lb_probes)

  public_frontend_names = [
    for k, v in var.frontend_ip_configurations :
    coalesce(v.name, "frontend-${var.name}")
    if v.create_public_ip_address || v.public_ip_address_resource_id != null
  ]

  non_zone_redundant_frontends = [
    for k, v in var.frontend_ip_configurations : k
    if length(v.zones) < 2 || contains(v.zones, "None")
  ]

  outbound_rule_frontend_names = flatten([
    for k, v in var.lb_outbound_rules : [
      for f in(v.frontend_ip_configurations == null ? [] : v.frontend_ip_configurations) :
      f.name if f.name != null
    ]
  ])

  # Azure rejects an apply where one frontend backs both an outbound rule and a
  # load balancing rule that still has outbound SNAT enabled.
  snat_conflicting_rules = [
    for k, v in var.lb_rules : k
    if !v.disable_outbound_snat && contains(local.outbound_rule_frontend_names, v.frontend_ip_configuration_name)
  ]

  unknown_rule_frontends = [
    for k, v in var.lb_rules : k
    if v.frontend_ip_configuration_name != null && !contains(local.frontend_names, v.frontend_ip_configuration_name)
  ]

  unknown_rule_probes = [
    for k, v in var.lb_rules : k
    if v.probe_object_name != null && !contains(local.probe_keys, v.probe_object_name)
  ]

  unknown_rule_pools = [
    for k, v in var.lb_rules : k
    if length(setsubtract(
      toset(v.backend_address_pool_object_names == null ? [] : v.backend_address_pool_object_names),
      toset(local.backend_pool_keys)
    )) > 0
  ]

  unknown_nat_rule_pools = [
    for k, v in var.lb_nat_rules : k
    if v.backend_address_pool_object_name != null && !contains(local.backend_pool_keys, v.backend_address_pool_object_name)
  ]

  unknown_outbound_rule_pools = [
    for k, v in var.lb_outbound_rules : k
    if v.backend_address_pool_object_name != null && !contains(local.backend_pool_keys, v.backend_address_pool_object_name)
  ]

  unknown_address_pools = [
    for k, v in var.backend_address_pool_addresses : k
    if v.backend_address_pool_object_name != null && !contains(local.backend_pool_keys, v.backend_address_pool_object_name)
  ]

  unknown_nic_pools = [
    for k, v in var.backend_address_pool_network_interfaces : k
    if v.backend_address_pool_object_name != null && !contains(local.backend_pool_keys, v.backend_address_pool_object_name)
  ]
}
