# =====================================================================
# Required inputs
# =====================================================================

variable "name" {
  type        = string
  description = "The name of the Load Balancer. 1-80 chars, alphanumerics, underscores, periods, hyphens. Must start with alphanumeric and end with alphanumeric or underscore."
  nullable    = false

  validation {
    condition     = can(regex("^[a-zA-Z0-9][a-zA-Z0-9._-]{0,78}[a-zA-Z0-9_]$", var.name))
    error_message = "name must be 1-80 characters, alphanumerics/underscores/periods/hyphens, start with alphanumeric and end with alphanumeric or underscore."
  }
}

variable "resource_group_name" {
  type        = string
  description = "Name of the Resource Group where the Load Balancer will be deployed. Note this is the resource group NAME, not its resource ID — unlike the bastion-host, nat-gateway, storage-account and virtual-network wrappers, which take parent_id."
  nullable    = false

  validation {
    condition     = can(regex("^[a-zA-Z0-9._()-]{1,90}$", var.resource_group_name)) && !endswith(var.resource_group_name, ".")
    error_message = "resource_group_name must be 1-90 characters of alphanumerics, underscores, parentheses, hyphens or periods, and must not end with a period."
  }
}

variable "location" {
  type        = string
  description = "Azure region where the Load Balancer will be deployed."
  nullable    = false

  validation {
    condition     = length(var.location) > 0
    error_message = "location must not be empty."
  }
}

variable "frontend_ip_configurations" {
  type = map(object({
    name                                               = optional(string)
    frontend_private_ip_address                        = optional(string)
    frontend_private_ip_address_version                = optional(string)
    frontend_private_ip_address_allocation             = optional(string, "Dynamic")
    frontend_private_ip_subnet_resource_id             = optional(string)
    gateway_load_balancer_frontend_ip_configuration_id = optional(string)
    public_ip_address_resource_name                    = optional(string)
    public_ip_address_resource_id                      = optional(string)
    public_ip_prefix_resource_id                       = optional(string)
    tags                                               = optional(map(any), {})
    create_public_ip_address                           = optional(bool, false)
    new_public_ip_resource_group_name                  = optional(string)
    new_public_ip_location                             = optional(string)
    inherit_lock                                       = optional(bool, true)
    lock_type_if_not_inherited                         = optional(string, null)
    inherit_tags                                       = optional(bool, true)
    edge_zone                                          = optional(string)
    zones                                              = optional(list(string), ["1", "2", "3"])

    role_assignments = optional(map(object({
      role_definition_id_or_name             = string
      principal_id                           = string
      description                            = optional(string, null)
      skip_service_principal_aad_check       = optional(bool, false)
      condition                              = optional(string, null)
      condition_version                      = optional(string, null)
      delegated_managed_identity_resource_id = optional(string, null)
    })), {})

    diagnostic_settings = optional(map(object({
      name                                     = optional(string, null)
      log_categories                           = optional(set(string), [])
      log_groups                               = optional(set(string), ["allLogs"])
      metric_categories                        = optional(set(string), ["AllMetrics"])
      log_analytics_destination_type           = optional(string, "Dedicated")
      workspace_resource_id                    = optional(string, null)
      storage_account_resource_id              = optional(string, null)
      event_hub_authorization_rule_resource_id = optional(string, null)
      event_hub_name                           = optional(string, null)
      marketplace_partner_resource_id          = optional(string, null)
    })), {})
  }))
  description = <<DESCRIPTION
Frontend IP configurations, keyed by an arbitrary map key. At least one is required.

A frontend is either public or private, never both:
- Public: set `create_public_ip_address = true` (the module creates the address, shaped by `public_ip_address_configuration`) or supply an existing `public_ip_address_resource_id`.
- Private: set `frontend_private_ip_subnet_resource_id`, or leave it unset and supply the shared `frontend_subnet_resource_id`.

`name` defaults to "frontend-<load balancer name>". Load balancing, NAT and outbound
rules reference frontends by that name, not by the map key.

`zones` applies to the created public IP for public frontends and to the frontend IP
configuration itself for private ones. Use ["None"] for a non-zonal frontend.

Example:
```terraform
frontend_ip_configurations = {
  internal = {
    name                                   = "feip-internal"
    frontend_private_ip_address_allocation = "Static"
    frontend_private_ip_address            = "10.60.1.10"
    frontend_private_ip_subnet_resource_id = module.virtual_network.subnets["app"].resource_id
  }
}
```
DESCRIPTION
  nullable    = false

  validation {
    condition     = length(var.frontend_ip_configurations) > 0
    error_message = "At least one frontend IP configuration is required to deploy a Load Balancer."
  }
  validation {
    condition = alltrue([
      for v in var.frontend_ip_configurations :
      contains(["Dynamic", "Static"], v.frontend_private_ip_address_allocation)
    ])
    error_message = "frontend_private_ip_address_allocation must be 'Dynamic' or 'Static'."
  }
  validation {
    condition = alltrue([
      for v in var.frontend_ip_configurations :
      v.frontend_private_ip_address_version == null || contains(["IPv4", "IPv6"], v.frontend_private_ip_address_version)
    ])
    error_message = "frontend_private_ip_address_version must be 'IPv4' or 'IPv6'."
  }
  validation {
    condition = alltrue([
      for v in var.frontend_ip_configurations :
      !((v.create_public_ip_address || v.public_ip_address_resource_id != null) && v.frontend_private_ip_subnet_resource_id != null)
    ])
    error_message = "A frontend IP configuration is either public or private. Do not set a subnet alongside create_public_ip_address or public_ip_address_resource_id."
  }
  validation {
    condition = alltrue([
      for v in var.frontend_ip_configurations :
      !(v.create_public_ip_address && v.public_ip_address_resource_id != null)
    ])
    error_message = "Set either create_public_ip_address or public_ip_address_resource_id on a frontend, not both."
  }
  validation {
    condition = alltrue([
      for v in var.frontend_ip_configurations :
      v.frontend_private_ip_address_allocation != "Static" || v.create_public_ip_address || v.public_ip_address_resource_id != null || v.frontend_private_ip_address != null
    ])
    error_message = "A private frontend with frontend_private_ip_address_allocation = 'Static' must also set frontend_private_ip_address."
  }
  validation {
    condition = alltrue(flatten([
      for v in var.frontend_ip_configurations : [
        for z in v.zones : contains(["1", "2", "3", "None"], z)
      ]
    ]))
    error_message = "Each frontend zone must be '1', '2', '3' or 'None'."
  }
  validation {
    condition = alltrue([
      for v in var.frontend_ip_configurations :
      v.lock_type_if_not_inherited == null || contains(["CanNotDelete", "ReadOnly"], v.lock_type_if_not_inherited)
    ])
    error_message = "lock_type_if_not_inherited must be 'CanNotDelete' or 'ReadOnly'."
  }
}

# =====================================================================
# Backend pools
# =====================================================================

variable "backend_address_pools" {
  type = map(object({
    name                        = optional(string, "bepool-1")
    virtual_network_resource_id = optional(string)
    tunnel_interfaces = optional(map(object({
      identifier = optional(number)
      type       = optional(string)
      protocol   = optional(string)
      port       = optional(number)
    })), {})
  }))
  description = <<DESCRIPTION
Backend address pools, keyed by an arbitrary map key. Rules reference a pool by its
map key (`backend_address_pool_object_name(s)`), not by `name`.

- `virtual_network_resource_id`: set only for an IP-based pool. Leave unset when members join through network interfaces.
- `tunnel_interfaces`: Gateway SKU only.
DESCRIPTION
  default     = {}
  nullable    = false

  validation {
    condition = alltrue(flatten([
      for v in var.backend_address_pools : [
        for t in v.tunnel_interfaces :
        t.type == null || contains(["Internal", "External"], t.type)
      ]
    ]))
    error_message = "tunnel_interfaces type must be 'Internal' or 'External'."
  }
  validation {
    condition = alltrue(flatten([
      for v in var.backend_address_pools : [
        for t in v.tunnel_interfaces :
        t.protocol == null || contains(["VXLAN", "Native", "None"], t.protocol)
      ]
    ]))
    error_message = "tunnel_interfaces protocol must be 'VXLAN', 'Native' or 'None'."
  }
}

variable "backend_address_pool_addresses" {
  type = map(object({
    name                             = optional(string)
    backend_address_pool_object_name = optional(string)
    ip_address                       = optional(string)
    virtual_network_resource_id      = optional(string)
  }))
  description = "Static IP addresses to add to a backend pool, keyed by an arbitrary map key. `backend_address_pool_object_name` is the map key of an entry in backend_address_pools. IP-based pools require a virtual network, either here, on the pool, or via backend_address_pool_configuration."
  default     = {}
  nullable    = false

  validation {
    condition = alltrue([
      for k, v in var.backend_address_pool_addresses :
      v.backend_address_pool_object_name != null
    ])
    error_message = "Every backend_address_pool_addresses entry must set backend_address_pool_object_name."
  }
}

variable "backend_address_pool_network_interfaces" {
  type = map(object({
    backend_address_pool_object_name = optional(string)
    ip_configuration_name            = optional(string)
    network_interface_resource_id    = optional(string)
  }))
  description = "Network interface IP configurations to join to a backend pool, keyed by an arbitrary map key. `backend_address_pool_object_name` is the map key of an entry in backend_address_pools."
  default     = {}
  nullable    = false

  validation {
    condition = alltrue([
      for k, v in var.backend_address_pool_network_interfaces :
      v.backend_address_pool_object_name != null && v.ip_configuration_name != null && v.network_interface_resource_id != null
    ])
    error_message = "Every backend_address_pool_network_interfaces entry must set backend_address_pool_object_name, ip_configuration_name and network_interface_resource_id."
  }
}

variable "backend_address_pool_configuration" {
  type        = string
  description = "Resource ID of the virtual network used by every IP-based backend pool that does not set its own. Leave null when pool members join through network interfaces."
  default     = null
}

# =====================================================================
# Rules and probes
# =====================================================================

variable "lb_probes" {
  type = map(object({
    name                            = optional(string)
    protocol                        = optional(string, "Tcp")
    port                            = optional(number, 80)
    interval_in_seconds             = optional(number, 15)
    probe_threshold                 = optional(number, 1)
    request_path                    = optional(string)
    number_of_probes_before_removal = optional(number, 2)
  }))
  description = <<DESCRIPTION
Health probes, keyed by an arbitrary map key. Load balancing rules reference a probe by
that map key (`probe_object_name`).

`request_path` is required for Http/Https and rejected for Tcp. `name` defaults to
"probe-<load balancer name>".
DESCRIPTION
  default     = {}
  nullable    = false

  validation {
    condition = alltrue([
      for v in var.lb_probes : contains(["Tcp", "Http", "Https"], v.protocol)
    ])
    error_message = "lb_probes protocol must be 'Tcp', 'Http' or 'Https'."
  }
  validation {
    condition = alltrue([
      for v in var.lb_probes : v.port >= 1 && v.port <= 65535
    ])
    error_message = "lb_probes port must be between 1 and 65535."
  }
  validation {
    condition = alltrue([
      for v in var.lb_probes : v.probe_threshold >= 1 && v.probe_threshold <= 100
    ])
    error_message = "lb_probes probe_threshold must be between 1 and 100."
  }
  validation {
    condition = alltrue([
      for v in var.lb_probes : v.interval_in_seconds >= 5
    ])
    error_message = "lb_probes interval_in_seconds must be at least 5."
  }
  validation {
    condition = alltrue([
      for v in var.lb_probes : v.number_of_probes_before_removal >= 2
    ])
    error_message = "lb_probes number_of_probes_before_removal must be at least 2."
  }
  validation {
    condition = alltrue([
      for v in var.lb_probes :
      (v.protocol == "Tcp" && v.request_path == null) || (contains(["Http", "Https"], v.protocol) && v.request_path != null)
    ])
    error_message = "lb_probes request_path is required for 'Http'/'Https' and must be null for 'Tcp'."
  }
  validation {
    condition = alltrue([
      for v in var.lb_probes : v.number_of_probes_before_removal * v.interval_in_seconds >= 10
    ])
    error_message = "lb_probes number_of_probes_before_removal multiplied by interval_in_seconds must be at least 10."
  }
}

variable "lb_rules" {
  type = map(object({
    name                              = optional(string)
    frontend_ip_configuration_name    = optional(string)
    protocol                          = optional(string, "Tcp")
    frontend_port                     = optional(number, 3389)
    backend_port                      = optional(number, 3389)
    backend_address_pool_resource_ids = optional(list(string))
    backend_address_pool_object_names = optional(list(string))
    probe_resource_id                 = optional(string)
    probe_object_name                 = optional(string)
    enable_floating_ip                = optional(bool, false)
    idle_timeout_in_minutes           = optional(number, 4)
    load_distribution                 = optional(string, "Default")
    disable_outbound_snat             = optional(bool, false)
    enable_tcp_reset                  = optional(bool, false)
  }))
  description = <<DESCRIPTION
Load balancing rules, keyed by an arbitrary map key.

`probe_object_name` is mandatory even when `probe_resource_id` is supplied: upstream
indexes its probe map with it unconditionally, so a null value fails the plan.

`frontend_ip_configuration_name` matches the frontend's resolved `name`.
`backend_address_pool_object_names` holds map keys of backend_address_pools. More than
one backend pool per rule is Gateway SKU only.

For high availability ports set `protocol = "All"`, `frontend_port = 0` and
`backend_port = 0`. Set `disable_outbound_snat = true` when the same frontend also
backs an outbound rule.
DESCRIPTION
  default     = {}
  nullable    = false

  validation {
    condition = alltrue([
      for v in var.lb_rules : contains(["Udp", "Tcp", "All"], v.protocol)
    ])
    error_message = "lb_rules protocol must be 'Udp', 'Tcp' or 'All'."
  }
  validation {
    condition = alltrue([
      for v in var.lb_rules : v.probe_object_name != null
    ])
    error_message = "Every lb_rules entry must set probe_object_name to the map key of an lb_probes entry. The upstream module indexes its probe map with this value even when probe_resource_id is set."
  }
  validation {
    condition = alltrue([
      for v in var.lb_rules : v.frontend_ip_configuration_name != null
    ])
    error_message = "Every lb_rules entry must set frontend_ip_configuration_name."
  }
  validation {
    condition = alltrue([
      for v in var.lb_rules : v.idle_timeout_in_minutes >= 4 && v.idle_timeout_in_minutes <= 100
    ])
    error_message = "lb_rules idle_timeout_in_minutes must be between 4 and 100."
  }
  validation {
    condition = alltrue([
      for v in var.lb_rules : contains(["Default", "SourceIP", "SourceIPProtocol"], v.load_distribution)
    ])
    error_message = "lb_rules load_distribution must be 'Default', 'SourceIP' or 'SourceIPProtocol'."
  }
  validation {
    condition = alltrue([
      for v in var.lb_rules :
      v.protocol != "All" || (v.frontend_port == 0 && v.backend_port == 0)
    ])
    error_message = "lb_rules with protocol 'All' are high availability ports rules and require frontend_port = 0 and backend_port = 0."
  }
  validation {
    condition = alltrue([
      for v in var.lb_rules :
      v.protocol == "All" || (v.frontend_port >= 1 && v.frontend_port <= 65534 && v.backend_port >= 1 && v.backend_port <= 65535)
    ])
    error_message = "lb_rules frontend_port must be between 1 and 65534 and backend_port between 1 and 65535 unless protocol is 'All'."
  }
}

variable "lb_nat_rules" {
  type = map(object({
    name                             = optional(string)
    frontend_ip_configuration_name   = optional(string)
    protocol                         = optional(string)
    frontend_port                    = optional(number)
    backend_port                     = optional(number)
    frontend_port_start              = optional(number)
    frontend_port_end                = optional(number)
    backend_address_pool_resource_id = optional(string)
    backend_address_pool_object_name = optional(string)
    idle_timeout_in_minutes          = optional(number, 4)
    enable_floating_ip               = optional(bool, false)
    enable_tcp_reset                 = optional(bool, false)
  }))
  description = <<DESCRIPTION
Inbound NAT rules, keyed by an arbitrary map key. Upstream re-keys this map by `name`,
so `name` is mandatory and must be unique.

Use `frontend_port`/`backend_port` for a single mapping, or
`frontend_port_start`/`frontend_port_end` with a backend pool for a port range.
DESCRIPTION
  default     = {}
  nullable    = false

  validation {
    condition = alltrue([
      for v in var.lb_nat_rules : v.name != null
    ])
    error_message = "Every lb_nat_rules entry must set name. The upstream module re-keys this map by name."
  }
  validation {
    condition     = length(distinct([for v in var.lb_nat_rules : v.name])) == length(var.lb_nat_rules)
    error_message = "lb_nat_rules names must be unique."
  }
  validation {
    condition = alltrue([
      for v in var.lb_nat_rules : v.protocol != null && contains(["Udp", "Tcp", "All"], coalesce(v.protocol, "Tcp"))
    ])
    error_message = "Every lb_nat_rules entry must set protocol to 'Udp', 'Tcp' or 'All'."
  }
  validation {
    condition = alltrue([
      for v in var.lb_nat_rules : v.frontend_ip_configuration_name != null
    ])
    error_message = "Every lb_nat_rules entry must set frontend_ip_configuration_name."
  }
  validation {
    condition = alltrue([
      for v in var.lb_nat_rules :
      v.backend_port == null || v.backend_port == 0 || (v.backend_port >= 1 && v.backend_port <= 65535)
    ])
    error_message = "lb_nat_rules backend_port must be between 1 and 65535."
  }
  validation {
    condition = alltrue([
      for v in var.lb_nat_rules : v.idle_timeout_in_minutes >= 4 && v.idle_timeout_in_minutes <= 30
    ])
    error_message = "lb_nat_rules idle_timeout_in_minutes must be between 4 and 30."
  }
  validation {
    condition = alltrue([
      for v in var.lb_nat_rules :
      (v.frontend_port_start == null) == (v.frontend_port_end == null)
    ])
    error_message = "lb_nat_rules frontend_port_start and frontend_port_end must be set together."
  }
}

variable "lb_nat_pools" {
  type = map(object({
    name                           = optional(string)
    frontend_ip_configuration_name = optional(string)
    protocol                       = optional(string, "Tcp")
    frontend_port_start            = optional(number, 3000)
    frontend_port_end              = optional(number, 3389)
    backend_port                   = optional(number, 3389)
    idle_timeout_in_minutes        = optional(number, 4)
    enable_floating_ip             = optional(bool, false)
    enable_tcp_reset               = optional(bool, false)
  }))
  description = <<DESCRIPTION
Inbound NAT pools, keyed by an arbitrary map key. Upstream re-keys this map by `name`,
so `name` is mandatory and must be unique.

NAT pools only bind to Virtual Machine Scale Sets. For standalone VMs use `lb_nat_rules`.
DESCRIPTION
  default     = {}
  nullable    = false

  validation {
    condition = alltrue([
      for v in var.lb_nat_pools : v.name != null
    ])
    error_message = "Every lb_nat_pools entry must set name. The upstream module re-keys this map by name."
  }
  validation {
    condition     = length(distinct([for v in var.lb_nat_pools : v.name])) == length(var.lb_nat_pools)
    error_message = "lb_nat_pools names must be unique."
  }
  validation {
    condition = alltrue([
      for v in var.lb_nat_pools : contains(["Udp", "Tcp", "All"], v.protocol)
    ])
    error_message = "lb_nat_pools protocol must be 'Udp', 'Tcp' or 'All'."
  }
  validation {
    condition = alltrue([
      for v in var.lb_nat_pools : v.frontend_ip_configuration_name != null
    ])
    error_message = "Every lb_nat_pools entry must set frontend_ip_configuration_name."
  }
  validation {
    condition = alltrue([
      for v in var.lb_nat_pools :
      v.frontend_port_start >= 1 && v.frontend_port_end <= 65534 && v.frontend_port_start <= v.frontend_port_end
    ])
    error_message = "lb_nat_pools frontend_port_start and frontend_port_end must be between 1 and 65534, with start no greater than end."
  }
  validation {
    condition = alltrue([
      for v in var.lb_nat_pools : v.idle_timeout_in_minutes >= 4 && v.idle_timeout_in_minutes <= 30
    ])
    error_message = "lb_nat_pools idle_timeout_in_minutes must be between 4 and 30."
  }
}

variable "lb_outbound_rules" {
  type = map(object({
    name                               = optional(string)
    frontend_ip_configurations         = optional(list(object({ name = optional(string) })))
    backend_address_pool_resource_id   = optional(string)
    backend_address_pool_object_name   = optional(string)
    protocol                           = optional(string, "Tcp")
    enable_tcp_reset                   = optional(bool, false)
    number_of_allocated_outbound_ports = optional(number, 1024)
    idle_timeout_in_minutes            = optional(number, 4)
  }))
  description = <<DESCRIPTION
Outbound rules, keyed by an arbitrary map key. Upstream re-keys this map by `name`, so
`name` is mandatory and must be unique.

`backend_address_pool_object_name` is mandatory even when
`backend_address_pool_resource_id` is supplied: upstream indexes its pool map with it
unconditionally, so a null value fails the plan.

Outbound rules require the Standard SKU and a public frontend. Any load balancing rule
sharing that frontend must set `disable_outbound_snat = true`.
DESCRIPTION
  default     = {}
  nullable    = false

  validation {
    condition = alltrue([
      for v in var.lb_outbound_rules : v.name != null
    ])
    error_message = "Every lb_outbound_rules entry must set name. The upstream module re-keys this map by name."
  }
  validation {
    condition     = length(distinct([for v in var.lb_outbound_rules : v.name])) == length(var.lb_outbound_rules)
    error_message = "lb_outbound_rules names must be unique."
  }
  validation {
    condition = alltrue([
      for v in var.lb_outbound_rules : v.backend_address_pool_object_name != null
    ])
    error_message = "Every lb_outbound_rules entry must set backend_address_pool_object_name to the map key of a backend_address_pools entry. The upstream module indexes its pool map with this value even when backend_address_pool_resource_id is set."
  }
  validation {
    condition = alltrue([
      for v in var.lb_outbound_rules : contains(["Udp", "Tcp", "All"], v.protocol)
    ])
    error_message = "lb_outbound_rules protocol must be 'Udp', 'Tcp' or 'All'."
  }
  validation {
    condition = alltrue([
      for v in var.lb_outbound_rules :
      v.frontend_ip_configurations != null && length(coalesce(v.frontend_ip_configurations, [])) > 0
    ])
    error_message = "Every lb_outbound_rules entry must list at least one frontend IP configuration."
  }
  validation {
    condition = alltrue([
      for v in var.lb_outbound_rules : v.idle_timeout_in_minutes >= 4 && v.idle_timeout_in_minutes <= 100
    ])
    error_message = "lb_outbound_rules idle_timeout_in_minutes must be between 4 and 100."
  }
  validation {
    condition = alltrue([
      for v in var.lb_outbound_rules :
      v.number_of_allocated_outbound_ports >= 0 && v.number_of_allocated_outbound_ports <= 64000
    ])
    error_message = "lb_outbound_rules number_of_allocated_outbound_ports must be between 0 and 64000."
  }
}

# =====================================================================
# SKU and placement
# =====================================================================

variable "sku" {
  type        = string
  description = "Load Balancer SKU. 'Standard' or 'Gateway'. The Basic SKU was retired on 30 September 2025 and is not offered. 'Gateway' requires the Microsoft.Network/AllowGatewayLoadBalancer feature, which only Microsoft can register."
  default     = "Standard"
  nullable    = false

  validation {
    condition     = contains(["Standard", "Gateway"], var.sku)
    error_message = "sku must be 'Standard' or 'Gateway'."
  }
}

variable "sku_tier" {
  type        = string
  description = "SKU tier. 'Regional' or 'Global'. 'Global' builds a cross-region load balancer whose backend pool holds regional Standard load balancer frontends. Changing this forces a new resource."
  default     = "Regional"
  nullable    = false

  validation {
    condition     = contains(["Global", "Regional"], var.sku_tier)
    error_message = "sku_tier must be 'Global' or 'Regional'."
  }
}

variable "edge_zone" {
  type        = string
  description = "Edge Zone within the Azure region for the Load Balancer and any public IP it creates. Changing this forces new resources."
  default     = null
}

variable "frontend_subnet_resource_id" {
  type        = string
  description = "Subnet resource ID shared by every private frontend that does not set its own frontend_private_ip_subnet_resource_id. Leave null for a public Load Balancer."
  default     = null

  validation {
    condition     = var.frontend_subnet_resource_id == null || can(regex("^/subscriptions/[^/]+/resourceGroups/[^/]+/providers/Microsoft\\.Network/virtualNetworks/[^/]+/subnets/[^/]+$", coalesce(var.frontend_subnet_resource_id, "")))
    error_message = "frontend_subnet_resource_id must be a valid Microsoft.Network/virtualNetworks/subnets resource ID."
  }
}

# =====================================================================
# Public IP creation
# Applies to every frontend with create_public_ip_address = true.
# =====================================================================

variable "public_ip_address_configuration" {
  type = object({
    resource_group_name              = optional(string)
    allocation_method                = optional(string, "Static")
    ddos_protection_mode             = optional(string, "VirtualNetworkInherited")
    ddos_protection_plan_resource_id = optional(string)
    domain_name_label                = optional(string)
    idle_timeout_in_minutes          = optional(number, 4)
    ip_tags                          = optional(map(string))
    ip_version                       = optional(string, "IPv4")
    public_ip_prefix_resource_id     = optional(string)
    reverse_fqdn                     = optional(string)
    sku                              = optional(string, "Standard")
    sku_tier                         = optional(string, "Regional")
    tags                             = optional(map(any), {})
  })
  description = <<DESCRIPTION
Settings shared by every public IP the module creates for a frontend. Has no effect
unless at least one frontend sets `create_public_ip_address = true`; frontends that
reference an existing `public_ip_address_resource_id` are unaffected.

Public IPs created this way are owned by this wrapper's state, the same arrangement the
bastion-host wrapper uses. Do not also declare them through a separate public IP tier.
DESCRIPTION
  default     = {}
  nullable    = false

  validation {
    condition     = contains(["Dynamic", "Static"], var.public_ip_address_configuration.allocation_method)
    error_message = "public_ip_address_configuration.allocation_method must be 'Dynamic' or 'Static'."
  }
  validation {
    condition     = contains(["Disabled", "Enabled", "VirtualNetworkInherited"], var.public_ip_address_configuration.ddos_protection_mode)
    error_message = "public_ip_address_configuration.ddos_protection_mode must be 'Disabled', 'Enabled' or 'VirtualNetworkInherited'."
  }
  validation {
    condition     = var.public_ip_address_configuration.idle_timeout_in_minutes >= 4 && var.public_ip_address_configuration.idle_timeout_in_minutes <= 30
    error_message = "public_ip_address_configuration.idle_timeout_in_minutes must be between 4 and 30."
  }
  validation {
    condition     = contains(["IPv4", "IPv6"], var.public_ip_address_configuration.ip_version)
    error_message = "public_ip_address_configuration.ip_version must be 'IPv4' or 'IPv6'."
  }
  validation {
    condition     = var.public_ip_address_configuration.ip_version != "IPv6" || var.public_ip_address_configuration.allocation_method == "Static"
    error_message = "public_ip_address_configuration with ip_version 'IPv6' requires allocation_method 'Static'."
  }
  validation {
    condition     = contains(["Basic", "Standard"], var.public_ip_address_configuration.sku)
    error_message = "public_ip_address_configuration.sku must be 'Basic' or 'Standard'."
  }
  validation {
    condition     = contains(["Global", "Regional"], var.public_ip_address_configuration.sku_tier)
    error_message = "public_ip_address_configuration.sku_tier must be 'Global' or 'Regional'."
  }
}

# =====================================================================
# Governance
# =====================================================================

variable "role_assignments" {
  type = map(object({
    role_definition_id_or_name             = string
    principal_id                           = string
    description                            = optional(string, null)
    skip_service_principal_aad_check       = optional(bool, false)
    condition                              = optional(string, null)
    condition_version                      = optional(string, null)
    delegated_managed_identity_resource_id = optional(string, null)
    principal_type                         = optional(string, null)
  }))
  description = "RBAC role assignments scoped to the Load Balancer. Common roles: 'Network Contributor', 'Reader'. Per-frontend assignments on created public IPs are set inside frontend_ip_configurations."
  default     = {}
  nullable    = false

  validation {
    condition = alltrue([
      for v in var.role_assignments :
      v.condition_version == null || contains(["2.0"], v.condition_version)
    ])
    error_message = "role_assignments condition_version must be '2.0'."
  }
}

variable "lock" {
  type = object({
    kind = string
    name = optional(string, null)
  })
  description = "Optional resource lock on the Load Balancer. kind must be 'CanNotDelete' or 'ReadOnly'. Frontends inherit it unless they set inherit_lock = false."
  default     = null

  validation {
    condition     = var.lock == null || contains(["CanNotDelete", "ReadOnly"], try(var.lock.kind, ""))
    error_message = "lock.kind must be 'CanNotDelete' or 'ReadOnly' when lock is set."
  }
}

# =====================================================================
# Diagnostics
# =====================================================================

variable "diagnostic_settings" {
  type = map(object({
    name                                     = optional(string, null)
    log_categories                           = optional(set(string), [])
    log_groups                               = optional(set(string), ["allLogs"])
    metric_categories                        = optional(set(string), ["AllMetrics"])
    log_analytics_destination_type           = optional(string, "Dedicated")
    workspace_resource_id                    = optional(string, null)
    storage_account_resource_id              = optional(string, null)
    event_hub_authorization_rule_resource_id = optional(string, null)
    event_hub_name                           = optional(string, null)
    marketplace_partner_resource_id          = optional(string, null)
  }))
  description = "Diagnostic settings for the Load Balancer. Each entry needs at least one destination. A Load Balancer emits metrics only; log_groups has no effect."
  default     = {}
  nullable    = false

  validation {
    condition = alltrue([
      for v in var.diagnostic_settings : contains(["Dedicated", "AzureDiagnostics"], v.log_analytics_destination_type)
    ])
    error_message = "diagnostic_settings log_analytics_destination_type must be 'Dedicated' or 'AzureDiagnostics'."
  }
  validation {
    condition = alltrue([
      for v in var.diagnostic_settings :
      v.workspace_resource_id != null || v.storage_account_resource_id != null || v.event_hub_authorization_rule_resource_id != null || v.marketplace_partner_resource_id != null
    ])
    error_message = "Each diagnostic_settings entry needs at least one of workspace_resource_id, storage_account_resource_id, event_hub_authorization_rule_resource_id or marketplace_partner_resource_id."
  }
}

# =====================================================================
# Module behavior
# =====================================================================

variable "enable_telemetry" {
  type        = bool
  description = "Whether to enable AVM module telemetry. Set false to opt out."
  default     = true
  nullable    = false
}

variable "tags" {
  type        = map(string)
  description = "A map of tags to apply to the Load Balancer. Frontends inherit these onto created public IPs unless they set inherit_tags = false."
  default     = null
}

# Cross-input rules — rules pointing at undeclared pools, probes or frontends,
# SKU/tier pairing, SNAT conflicts — live in checks.tf. Variable validation cannot
# reference another variable.
