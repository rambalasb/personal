# Post-plan/apply advisory checks. These surface as warnings (never block apply) and
# assert cross-configuration invariants the AVM module does not enforce on its own.

check "rules_reference_declared_probes" {
  assert {
    condition     = length(local.unknown_rule_probes) == 0
    error_message = "lb_rules ${join(", ", local.unknown_rule_probes)} set probe_object_name to a key that is not in lb_probes. The value is a map key of lb_probes, not a probe name."
  }
}

check "rules_reference_declared_frontends" {
  assert {
    condition     = length(local.unknown_rule_frontends) == 0
    error_message = "lb_rules ${join(", ", local.unknown_rule_frontends)} reference a frontend_ip_configuration_name that no frontend resolves to. The value is the frontend's name, not its map key, and defaults to \"frontend-${var.name}\"."
  }
}

check "rules_reference_declared_pools" {
  assert {
    condition     = length(local.unknown_rule_pools) == 0
    error_message = "lb_rules ${join(", ", local.unknown_rule_pools)} list backend_address_pool_object_names that are not keys of backend_address_pools."
  }
}

check "nat_rules_reference_declared_pools" {
  assert {
    condition     = length(local.unknown_nat_rule_pools) == 0
    error_message = "lb_nat_rules ${join(", ", local.unknown_nat_rule_pools)} set backend_address_pool_object_name to a key that is not in backend_address_pools."
  }
}

check "outbound_rules_reference_declared_pools" {
  assert {
    condition     = length(local.unknown_outbound_rule_pools) == 0
    error_message = "lb_outbound_rules ${join(", ", local.unknown_outbound_rule_pools)} set backend_address_pool_object_name to a key that is not in backend_address_pools."
  }
}

check "pool_members_reference_declared_pools" {
  assert {
    condition     = length(local.unknown_address_pools) + length(local.unknown_nic_pools) == 0
    error_message = "backend_address_pool_addresses ${join(", ", local.unknown_address_pools)} and backend_address_pool_network_interfaces ${join(", ", local.unknown_nic_pools)} target a backend_address_pool_object_name that is not a key of backend_address_pools."
  }
}

check "outbound_rules_disable_snat_on_shared_frontend" {
  assert {
    condition     = length(local.snat_conflicting_rules) == 0
    error_message = "lb_rules ${join(", ", local.snat_conflicting_rules)} share a frontend with an outbound rule but leave disable_outbound_snat = false. Azure rejects that combination; set disable_outbound_snat = true on those rules."
  }
}

check "outbound_rules_need_public_frontend" {
  assert {
    condition     = length(var.lb_outbound_rules) == 0 || length(local.public_frontend_names) > 0
    error_message = "Outbound rules are configured but no frontend carries a public IP. Outbound rules require a public frontend."
  }
}

check "outbound_rules_need_standard_sku" {
  assert {
    condition     = length(var.lb_outbound_rules) == 0 || var.sku == "Standard"
    error_message = "Outbound rules require sku = 'Standard'."
  }
}

check "global_tier_requires_standard_sku" {
  assert {
    condition     = var.sku_tier != "Global" || var.sku == "Standard"
    error_message = "sku_tier 'Global' is only valid with sku 'Standard'."
  }
}

check "global_tier_frontend_is_public" {
  assert {
    condition     = var.sku_tier != "Global" || length(local.public_frontend_names) == length(var.frontend_ip_configurations)
    error_message = "A cross-region (Global) Load Balancer only supports public frontends. Remove the private frontend IP configurations."
  }
}

check "multiple_pools_per_rule_need_gateway_sku" {
  assert {
    condition = var.sku == "Gateway" || alltrue([
      for v in var.lb_rules :
      length(coalesce(v.backend_address_pool_object_names, [])) <= 1 && length(coalesce(v.backend_address_pool_resource_ids, [])) <= 1
    ])
    error_message = "More than one backend pool per load balancing rule requires sku = 'Gateway'."
  }
}

check "tunnel_interfaces_need_gateway_sku" {
  assert {
    condition = var.sku == "Gateway" || alltrue([
      for v in var.backend_address_pools : length(v.tunnel_interfaces) == 0
    ])
    error_message = "backend_address_pools tunnel_interfaces require sku = 'Gateway'."
  }
}

check "sku_is_standard" {
  assert {
    condition     = var.sku == "Standard"
    error_message = "Load Balancers should use the 'Standard' SKU. 'Gateway' is for third-party network virtual appliance chaining and needs a Microsoft-registered feature flag."
  }
}

check "frontends_are_zone_redundant" {
  assert {
    condition     = length(local.non_zone_redundant_frontends) == 0
    error_message = "Frontend IP configurations ${join(", ", local.non_zone_redundant_frontends)} are not zone-redundant. For production resilience set zones = [\"1\", \"2\", \"3\"] unless the region has no zones or a zonal placement is deliberate."
  }
}

check "rules_have_backend_pool" {
  assert {
    condition = alltrue([
      for v in var.lb_rules :
      length(coalesce(v.backend_address_pool_object_names, [])) > 0 || length(coalesce(v.backend_address_pool_resource_ids, [])) > 0
    ])
    error_message = "Every load balancing rule should reference a backend address pool; a rule with none has nowhere to send traffic."
  }
}

check "backend_pools_have_members" {
  assert {
    condition     = length(var.backend_address_pools) == 0 || length(var.backend_address_pool_addresses) + length(var.backend_address_pool_network_interfaces) > 0
    error_message = "Backend address pools are declared but no addresses or network interfaces join them. Add members here, or attach them from the tier that owns the VMs or scale sets."
  }
}

check "ip_based_pools_have_virtual_network" {
  assert {
    condition = var.backend_address_pool_configuration != null || alltrue([
      for k, v in var.backend_address_pool_addresses :
      v.virtual_network_resource_id != null || try(var.backend_address_pools[v.backend_address_pool_object_name].virtual_network_resource_id, null) != null
    ])
    error_message = "IP-based backend pool addresses need a virtual network. Set virtual_network_resource_id on the address or its pool, or set backend_address_pool_configuration."
  }
}
