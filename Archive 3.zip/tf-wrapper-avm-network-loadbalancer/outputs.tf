output "resource_id" {
  description = "The Azure resource ID of the Load Balancer."
  value       = module.load_balancer.resource_id
}

output "name" {
  description = "The name of the Load Balancer."
  value       = module.load_balancer.name
}

output "resource" {
  description = "The full azurerm_lb object."
  value       = module.load_balancer.resource
}

output "frontend_ip_configurations" {
  description = "Frontend IP configurations keyed by name. Carries private_ip_address, public_ip_address_id and id — the values callers need for DNS records and NSG rules."
  value       = { for f in module.load_balancer.resource.frontend_ip_configuration : f.name => f }
}

output "backend_address_pools" {
  description = "Backend address pools keyed by the map key used in var.backend_address_pools. Callers attach VM and scale set NICs using each pool's id."
  value       = module.load_balancer.azurerm_lb_backend_address_pool
}

output "nat_rules" {
  description = "Inbound NAT rules keyed by rule name."
  value       = module.load_balancer.azurerm_lb_nat_rule
}

output "public_ip_addresses" {
  description = "Public IPs created by this module, keyed by the frontend map key. Empty unless a frontend sets create_public_ip_address."
  value       = module.load_balancer.azurerm_public_ip
}
