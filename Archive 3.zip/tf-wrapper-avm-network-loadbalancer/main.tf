module "load_balancer" {
  source  = "Azure/avm-res-network-loadbalancer/azurerm"
  version = "0.5.0"

  # Required
  name                = var.name
  resource_group_name = var.resource_group_name
  location            = var.location

  # Frontends
  frontend_ip_configurations  = var.frontend_ip_configurations
  frontend_subnet_resource_id = var.frontend_subnet_resource_id

  # Backend pools
  backend_address_pools                   = var.backend_address_pools
  backend_address_pool_addresses          = var.backend_address_pool_addresses
  backend_address_pool_network_interfaces = var.backend_address_pool_network_interfaces
  backend_address_pool_configuration      = var.backend_address_pool_configuration

  # Rules and probes
  lb_probes         = var.lb_probes
  lb_rules          = var.lb_rules
  lb_nat_rules      = var.lb_nat_rules
  lb_nat_pools      = var.lb_nat_pools
  lb_outbound_rules = var.lb_outbound_rules

  # SKU and placement
  sku       = var.sku
  sku_tier  = var.sku_tier
  edge_zone = var.edge_zone

  # Public IP creation for frontends with create_public_ip_address = true
  public_ip_address_configuration = var.public_ip_address_configuration

  # Governance
  role_assignments = var.role_assignments
  lock             = var.lock

  # Diagnostics
  diagnostic_settings = var.diagnostic_settings

  # Module behavior
  enable_telemetry = var.enable_telemetry
  tags             = local.module_tags
}
