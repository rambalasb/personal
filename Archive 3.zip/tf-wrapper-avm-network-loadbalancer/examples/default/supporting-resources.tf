# random suffix to avoid name collisions on reruns
resource "random_string" "suffix" {
  length  = 6
  lower   = true
  upper   = false
  numeric = true
  special = false
}

# native supporting RG so the example tests standalone, without a sibling module
resource "azurerm_resource_group" "this" {
  name     = "rg-avm-lb-default-test-${random_string.suffix.result}"
  location = "canadacentral"
}

# the example builds an internal load balancer, so the frontend needs a subnet
resource "azurerm_virtual_network" "this" {
  name                = "vnet-avm-lb-default-test-${random_string.suffix.result}"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location
  address_space       = ["10.60.0.0/16"]
}

resource "azurerm_subnet" "frontend" {
  name                 = "snet-lb-frontend"
  resource_group_name  = azurerm_resource_group.this.name
  virtual_network_name = azurerm_virtual_network.this.name
  address_prefixes     = ["10.60.1.0/24"]
}

# a NIC costs nothing and needs no VM, so the example can demonstrate backend
# pool membership without a billable compute resource
resource "azurerm_subnet" "backend" {
  name                 = "snet-lb-backend"
  resource_group_name  = azurerm_resource_group.this.name
  virtual_network_name = azurerm_virtual_network.this.name
  address_prefixes     = ["10.60.2.0/24"]
}

resource "azurerm_network_interface" "backend" {
  name                = "nic-avm-lb-default-test-${random_string.suffix.result}"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location

  ip_configuration {
    name                          = "ipconfig1"
    subnet_id                     = azurerm_subnet.backend.id
    private_ip_address_allocation = "Dynamic"
  }
}
