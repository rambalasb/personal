# Internal Standard load balancer: zone-redundant private frontend, one backend
# pool, a TCP probe and one balancing rule. No public IP, so the example applies
# and destroys without leaving a billable address behind.
module "load_balancer" {
  source = "../.."

  name                = "lb-avm-default-test-${random_string.suffix.result}"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location

  frontend_ip_configurations = {
    internal = {
      name                                   = "feip-internal"
      frontend_private_ip_address_version    = "IPv4"
      frontend_private_ip_address_allocation = "Static"
      frontend_private_ip_address            = "10.60.1.10"
      frontend_private_ip_subnet_resource_id = azurerm_subnet.frontend.id
      zones                                  = ["1", "2", "3"]
    }
  }

  backend_address_pools = {
    app = {
      name = "bepool-app"
    }
  }

  backend_address_pool_network_interfaces = {
    vm1 = {
      backend_address_pool_object_name = "app"
      ip_configuration_name            = azurerm_network_interface.backend.ip_configuration[0].name
      network_interface_resource_id    = azurerm_network_interface.backend.id
    }
  }

  lb_probes = {
    tcp80 = {
      name                = "probe-tcp-80"
      protocol            = "Tcp"
      port                = 80
      interval_in_seconds = 5
    }
  }

  lb_rules = {
    http = {
      name                              = "rule-http"
      frontend_ip_configuration_name    = "feip-internal"
      protocol                          = "Tcp"
      frontend_port                     = 80
      backend_port                      = 80
      probe_object_name                 = "tcp80"
      backend_address_pool_object_names = ["app"]
      idle_timeout_in_minutes           = 4
    }
  }

  enable_telemetry = false
}
