output "resource_id" {
  value = module.load_balancer.resource_id
}

output "name" {
  value = module.load_balancer.name
}

output "resource" {
  value = module.load_balancer.resource
}

output "frontend_ip_configurations" {
  value = module.load_balancer.frontend_ip_configurations
}

output "backend_address_pools" {
  value = module.load_balancer.backend_address_pools
}
