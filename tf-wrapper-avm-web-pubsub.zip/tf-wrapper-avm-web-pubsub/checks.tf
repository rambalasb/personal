check "entra_auth_only" {
  assert {
    condition     = !var.local_auth_enabled
    error_message = "Web PubSub should use Microsoft Entra authentication only. Set var.local_auth_enabled = false to disable access-key auth."
  }
}

check "public_network_access_disabled" {
  assert {
    condition     = !var.public_network_access_enabled
    error_message = "Web PubSub should be reached through a private endpoint. Set var.public_network_access_enabled = false."
  }
}

check "hubs_deny_anonymous_connections" {
  assert {
    condition     = alltrue([for hub in values(var.hubs) : lower(hub.anonymous_connect_policy) == "deny"])
    error_message = "Every hub should deny anonymous connections. Set anonymous_connect_policy = \"deny\"."
  }
}
