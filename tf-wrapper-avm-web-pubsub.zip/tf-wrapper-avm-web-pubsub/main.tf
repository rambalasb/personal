module "web_pubsub" {
  source  = "Azure/avm-res-signalrservice-webpubsub/azure"
  version = "0.2.0"

  # Required
  name      = var.name
  location  = var.location
  parent_id = var.resource_group_resource_id

  # Service
  kind                       = var.kind
  sku                        = var.sku
  aad_auth_enabled           = var.aad_auth_enabled
  local_auth_enabled         = var.local_auth_enabled
  client_certificate_enabled = var.client_certificate_enabled
  region_endpoint_enabled    = var.region_endpoint_enabled
  resource_stopped           = var.resource_stopped
  socket_io_service_mode     = var.socket_io_service_mode
  live_trace_configuration   = var.live_trace_configuration
  resource_log_configuration = var.resource_log_configuration

  # Networking
  public_network_access_enabled           = var.public_network_access_enabled
  network_acls                            = var.network_acls
  private_endpoints                       = var.private_endpoints
  private_endpoints_manage_dns_zone_group = var.private_endpoints_manage_dns_zone_group

  # Identity, RBAC, diagnostics, locks, tagging
  managed_identities  = var.managed_identities
  role_assignments    = var.role_assignments
  diagnostic_settings = var.diagnostic_settings
  lock                = var.lock
  tags                = local.module_tags

  ignore_body_changes = var.ignore_body_changes
  enable_telemetry    = var.enable_telemetry
}

# The AVM module has no hub input. Hubs are a PUT-only child resource, so the
# body states every writable property.
resource "azapi_resource" "hub" {
  for_each = var.hubs

  type      = "Microsoft.SignalRService/webPubSub/hubs@2024-03-01"
  name      = each.value.name
  parent_id = module.web_pubsub.resource_id

  body = {
    properties = local.hub_properties[each.key]
  }

  response_export_values = []
}
