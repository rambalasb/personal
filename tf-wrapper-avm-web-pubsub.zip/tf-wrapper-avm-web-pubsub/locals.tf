locals {
  module_tags = merge(
    var.tags == null ? {} : var.tags,
    var.wrapper_tags_enabled ? {
      managed-by = "terraform"
      module     = "tf-wrapper-avm-web-pubsub"
    } : {}
  )

  # Hub bodies with unset optional fields left out, so the body matches what
  # Azure returns for an existing hub.
  hub_properties = {
    for hub_key, hub in var.hubs : hub_key => {
      anonymousConnectPolicy              = hub.anonymous_connect_policy
      webSocketKeepAliveIntervalInSeconds = hub.web_socket_keep_alive_interval_in_seconds
      eventHandlers = [
        for handler in hub.event_handlers : merge(
          { urlTemplate = handler.url_template },
          handler.user_event_pattern == null ? {} : { userEventPattern = handler.user_event_pattern },
          length(handler.system_events) == 0 ? {} : { systemEvents = handler.system_events },
          handler.auth == null ? {} : {
            auth = merge(
              { type = handler.auth.type },
              handler.auth.managed_identity_resource == null ? {} : { managedIdentity = { resource = handler.auth.managed_identity_resource } }
            )
          }
        )
      ]
      eventListeners = [
        for listener in hub.event_listeners : {
          filter = merge(
            { type = "EventName" },
            length(listener.system_events) == 0 ? {} : { systemEvents = listener.system_events },
            listener.user_event_pattern == null ? {} : { userEventPattern = listener.user_event_pattern }
          )
          endpoint = {
            type                    = "EventHub"
            fullyQualifiedNamespace = listener.event_hub_fully_qualified_namespace
            eventHubName            = listener.event_hub_name
          }
        }
      ]
    }
  }
}
