output "resource_id" {
  description = "The Azure resource ID of the Web PubSub service."
  value       = module.web_pubsub.resource_id
}

output "name" {
  description = "The name of the Web PubSub service."
  value       = module.web_pubsub.name
}

output "hostname" {
  description = "The public hostname of the Web PubSub service."
  value       = module.web_pubsub.hostname
}

output "system_assigned_mi_principal_id" {
  description = "The principal ID of the system-assigned identity, or null when it is not enabled."
  value       = module.web_pubsub.system_assigned_mi_principal_id
}

output "private_endpoints" {
  description = "The private endpoints created by the module, keyed by the input map key."
  value       = module.web_pubsub.private_endpoints
}

output "hub_resource_ids" {
  description = "Map of hubs, keyed by the input map key, to their resource IDs."
  value       = { for hub_key, hub in azapi_resource.hub : hub_key => hub.id }
}
