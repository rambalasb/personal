module "web_pubsub" {
  source = "../.."

  name                       = "wps-avm-${random_string.suffix.result}"
  location                   = azurerm_resource_group.this.location
  resource_group_resource_id = azurerm_resource_group.this.id

  sku = {
    name     = "Standard_S1"
    capacity = 1
  }

  hubs = {
    default = {
      name = "default_hub"
    }
  }

  enable_telemetry = false
}
