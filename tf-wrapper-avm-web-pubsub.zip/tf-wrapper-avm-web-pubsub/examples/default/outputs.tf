output "resource_id" {
  value = module.web_pubsub.resource_id
}

output "name" {
  value = module.web_pubsub.name
}

output "hub_resource_ids" {
  value = module.web_pubsub.hub_resource_ids
}
