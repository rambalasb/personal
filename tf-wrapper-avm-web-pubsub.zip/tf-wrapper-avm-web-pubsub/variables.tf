# =====================================================================
# Required inputs
# =====================================================================

variable "name" {
  type        = string
  description = "The globally unique name of the Web PubSub service. 3-63 characters: starts with a letter, ends with a letter or digit, letters, digits and hyphens only."

  validation {
    condition     = can(regex("^[a-zA-Z][a-zA-Z0-9-]{1,61}[a-zA-Z0-9]$", var.name))
    error_message = "name must be 3-63 characters, start with a letter, end with a letter or digit, and contain only letters, digits and hyphens."
  }
}

variable "location" {
  type        = string
  description = "The Azure region where the Web PubSub service is deployed."

  validation {
    condition     = length(var.location) > 0
    error_message = "location must not be empty."
  }
}

variable "resource_group_resource_id" {
  type        = string
  description = "The full resource ID of the resource group that holds the service (e.g. /subscriptions/<sub>/resourceGroups/<rg>)."

  validation {
    condition     = can(regex("^/subscriptions/[^/]+/resourceGroups/[^/]+$", var.resource_group_resource_id))
    error_message = "resource_group_resource_id must be a valid resource group resource ID."
  }
}

# =====================================================================
# Service (secured defaults: override per environment as needed)
# =====================================================================

variable "kind" {
  type        = string
  description = "The service kind: 'WebPubSub' or 'SocketIO'. Changing it replaces the service."
  default     = "WebPubSub"

  validation {
    condition     = contains(["WebPubSub", "SocketIO"], var.kind)
    error_message = "kind must be 'WebPubSub' or 'SocketIO'."
  }
}

variable "sku" {
  type = object({
    name     = optional(string, "Standard_S1")
    capacity = optional(number)
  })
  description = "The SKU. name is 'Free_F1', 'Standard_S1', 'Premium_P1' or 'Premium_P2'; capacity is the unit count (Azure defaults to 1, or 100 for Premium_P2)."
  default     = {}
  nullable    = false
}

variable "aad_auth_enabled" {
  type        = bool
  description = "Whether Microsoft Entra ID authentication is enabled."
  default     = true
}

variable "local_auth_enabled" {
  type        = bool
  description = "Whether access-key authentication is permitted. Leave false to require Microsoft Entra authentication only."
  default     = false
}

variable "client_certificate_enabled" {
  type        = bool
  description = "Whether a client certificate is requested during the TLS handshake. Not supported on Free_F1."
  default     = false
}

variable "region_endpoint_enabled" {
  type        = bool
  description = "Whether new connections are routed to the regional endpoint. Disabling it requires a replica."
  default     = true
}

variable "resource_stopped" {
  type        = bool
  description = "Whether the service's data plane is stopped."
  default     = false
}

variable "socket_io_service_mode" {
  type        = string
  description = "The Socket.IO service mode, 'Default' or 'Serverless'. Only sent when kind is 'SocketIO'."
  default     = "Default"
}

variable "live_trace_configuration" {
  type = object({
    enabled = optional(bool, false)
    categories = optional(list(object({
      name    = string
      enabled = optional(bool, true)
    })), [])
  })
  description = "Live trace configuration. Null leaves it unset."
  default     = null
}

variable "resource_log_configuration" {
  type = object({
    categories = list(object({
      name    = string
      enabled = optional(bool, true)
    }))
  })
  description = "Resource log categories ('ConnectivityLogs', 'MessagingLogs', 'HttpRequestLogs') and whether each is enabled. Diagnostic settings route them to a destination. Null leaves it unset."
  default     = null
}

# =====================================================================
# Networking
# =====================================================================

variable "public_network_access_enabled" {
  type        = bool
  description = "Whether the service is reachable from the public internet. Kept false so access is through a private endpoint."
  default     = false
}

variable "network_acls" {
  type = object({
    default_action = optional(string, "Deny")
    public_network = optional(object({
      allow = optional(set(string), [])
      deny  = optional(set(string), [])
    }), {})
    private_endpoints = optional(list(object({
      name  = string
      allow = optional(set(string), [])
      deny  = optional(set(string), [])
    })), [])
    ip_rules = optional(list(object({
      action = string
      value  = string
    })), [])
  })
  description = "Network ACLs. Request types are 'ClientConnection', 'ServerConnection', 'RESTAPI' and 'Trace'. private_endpoints[].name is the private endpoint connection name on the service. Null leaves them unset."
  default     = null
}

variable "private_endpoints" {
  type = map(object({
    name = optional(string, null)
    role_assignments = optional(map(object({
      name                                   = optional(string, null)
      role_definition_id_or_name             = string
      principal_id                           = string
      description                            = optional(string, null)
      skip_service_principal_aad_check       = optional(bool, false)
      condition                              = optional(string, null)
      condition_version                      = optional(string, null)
      delegated_managed_identity_resource_id = optional(string, null)
      principal_type                         = optional(string, null)
    })), {})
    lock = optional(object({
      kind  = string
      name  = optional(string, null)
      notes = optional(string, null)
    }), null)
    tags                                    = optional(map(string), null)
    subnet_resource_id                      = string
    subresource_name                        = optional(string, null)
    private_dns_zone_group_name             = optional(string, "default")
    private_dns_zone_resource_ids           = optional(set(string), [])
    application_security_group_associations = optional(map(string), {})
    private_service_connection_name         = optional(string, null)
    network_interface_name                  = optional(string, null)
    location                                = optional(string, null)
    resource_group_name                     = optional(string, null)
    ip_configurations = optional(map(object({
      name               = string
      private_ip_address = string
      member_name        = optional(string)
    })), {})
  }))
  description = "Private endpoints created by the module. Associate the 'privatelink.webpubsub.azure.com' zone through private_dns_zone_resource_ids. Set to {} when the endpoint is managed elsewhere."
  default     = {}
  nullable    = false
}

variable "private_endpoints_manage_dns_zone_group" {
  type        = bool
  description = "Whether the module manages the private DNS zone groups of its private endpoints. Set false when DNS is handled externally (e.g. by Azure Policy)."
  default     = true
}

# =====================================================================
# Hubs (not covered by the AVM module)
# =====================================================================

variable "hubs" {
  type = map(object({
    name                                      = string
    anonymous_connect_policy                  = optional(string, "deny")
    web_socket_keep_alive_interval_in_seconds = optional(number, 20)
    event_handlers = optional(list(object({
      url_template       = string
      user_event_pattern = optional(string)
      system_events      = optional(list(string), [])
      auth = optional(object({
        type                      = string
        managed_identity_resource = optional(string)
      }))
    })), [])
    event_listeners = optional(list(object({
      system_events                       = optional(list(string), [])
      user_event_pattern                  = optional(string)
      event_hub_fully_qualified_namespace = string
      event_hub_name                      = string
    })), [])
  }))
  description = "Hubs on the service, keyed by a logical name. anonymous_connect_policy is 'allow' or 'deny'; auth.type is 'None' or 'ManagedIdentity'. Handlers and listeners keep their list order, which Azure preserves."
  default     = {}
  nullable    = false

  validation {
    condition     = alltrue([for hub in values(var.hubs) : contains(["allow", "deny"], lower(hub.anonymous_connect_policy))])
    error_message = "anonymous_connect_policy must be 'allow' or 'deny'."
  }

  validation {
    condition     = alltrue([for hub in values(var.hubs) : hub.web_socket_keep_alive_interval_in_seconds >= 1 && hub.web_socket_keep_alive_interval_in_seconds <= 120])
    error_message = "web_socket_keep_alive_interval_in_seconds must be between 1 and 120."
  }

  validation {
    condition = alltrue(flatten([
      for hub in values(var.hubs) : [
        for handler in hub.event_handlers : handler.auth == null ? true : contains(["None", "ManagedIdentity"], handler.auth.type)
      ]
    ]))
    error_message = "event_handlers[].auth.type must be 'None' or 'ManagedIdentity'."
  }
}

# =====================================================================
# Identity, RBAC, diagnostics, locks, tagging
# =====================================================================

variable "managed_identities" {
  type = object({
    system_assigned            = optional(bool, false)
    user_assigned_resource_ids = optional(set(string), [])
  })
  description = "Managed identity. Web PubSub supports one identity: either system-assigned or a single user-assigned identity."
  default     = {}
  nullable    = false
}

variable "role_assignments" {
  type = map(object({
    name                                   = optional(string, null)
    role_definition_id_or_name             = string
    principal_id                           = string
    description                            = optional(string, null)
    skip_service_principal_aad_check       = optional(bool, false)
    condition                              = optional(string, null)
    condition_version                      = optional(string, null)
    delegated_managed_identity_resource_id = optional(string, null)
    principal_type                         = optional(string, null)
  }))
  description = "Role assignments on the service, keyed by a logical name. Use built-in roles such as 'Web PubSub Service Owner' or 'Web PubSub Service Reader'."
  default     = {}
  nullable    = false
}

variable "diagnostic_settings" {
  type = map(object({
    name = optional(string, null)
    logs = optional(set(object({
      category       = optional(string, null)
      category_group = optional(string, null)
      enabled        = optional(bool, true)
      retention_policy = optional(object({
        days    = optional(number, 0)
        enabled = optional(bool, false)
      }), {})
    })), [])
    metrics = optional(set(object({
      category = optional(string, null)
      enabled  = optional(bool, true)
      retention_policy = optional(object({
        days    = optional(number, 0)
        enabled = optional(bool, false)
      }), {})
    })), [])
    log_analytics_destination_type           = optional(string, "Dedicated")
    workspace_resource_id                    = optional(string, null)
    storage_account_resource_id              = optional(string, null)
    event_hub_authorization_rule_resource_id = optional(string, null)
    event_hub_name                           = optional(string, null)
    marketplace_partner_resource_id          = optional(string, null)
  }))
  description = "Diagnostic settings. Each entry needs at least one destination (workspace, storage, event hub or marketplace partner), and each log entry exactly one of category or category_group."
  default     = {}
  nullable    = false
}

variable "lock" {
  type = object({
    kind  = string
    name  = optional(string, null)
    notes = optional(string, null)
  })
  description = "Optional resource lock. kind must be 'CanNotDelete' or 'ReadOnly'. Set null to disable."
  default     = null
}

variable "tags" {
  type        = map(string)
  description = "A map of tags applied to the service."
  default     = null
}

variable "wrapper_tags_enabled" {
  type        = bool
  description = "Whether the wrapper adds its managed-by and module tags. Set false when adopting an existing service, so the tags stay exactly as they are."
  default     = true
}

# =====================================================================
# AzAPI behaviour
# =====================================================================

variable "ignore_body_changes" {
  type = object({
    signalrservice_web_pub_sub                        = optional(list(string), [])
    authorization_locks                               = optional(list(string), [])
    authorization_role_assignments                    = optional(list(string), [])
    insights_diagnostic_settings                      = optional(list(string), [])
    network_private_endpoints                         = optional(list(string), [])
    network_private_endpoints_private_dns_zone_groups = optional(list(string), [])
  })
  description = "Body paths (dot notation) the AVM module ignores on each resource it manages. Ignored values are not sent to Azure until the path is removed."
  default     = {}
  nullable    = false
}

variable "enable_telemetry" {
  type        = bool
  description = "Whether to enable AVM module telemetry. Set false to opt out of anonymous usage data collection."
  default     = true
}
