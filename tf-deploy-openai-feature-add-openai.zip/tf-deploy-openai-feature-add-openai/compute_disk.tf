# OS disks are owned inline by their VM; data disks stay unmanaged for now.
# Drops any standalone disk from state without deleting it in Azure.
removed {
  from = module.compute_disk

  lifecycle {
    destroy = false
  }
}
