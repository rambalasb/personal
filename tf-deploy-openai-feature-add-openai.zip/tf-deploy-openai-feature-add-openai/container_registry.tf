module "container_registry" {
  for_each = var.enable_container_registry ? var.container_registry : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-container-registry/azurerm"
  version = "0.1.0"

  name                          = each.value.name
  resource_group_name           = module.resource_group[each.value.resource_group_key].name
  location                      = coalesce(each.value.location, module.resource_group[each.value.resource_group_key].location)
  sku                           = each.value.sku
  admin_enabled                 = each.value.admin_enabled
  anonymous_pull_enabled        = each.value.anonymous_pull_enabled
  data_endpoint_enabled         = each.value.data_endpoint_enabled
  export_policy_enabled         = each.value.export_policy_enabled
  quarantine_policy_enabled     = each.value.quarantine_policy_enabled
  retention_policy_in_days      = each.value.retention_policy_in_days
  enable_trust_policy           = each.value.trust_policy_enabled
  public_network_access_enabled = each.value.public_network_access_enabled
  network_rule_bypass_option    = each.value.network_rule_bypass_option
  network_rule_set              = each.value.network_rule_set
  zone_redundancy_enabled       = each.value.zone_redundancy_enabled
  tags                          = each.value.tags

  # The endpoint is its own tier in private_endpoint.tf; declaring it here too
  # would give it two owners.
  georeplications     = []
  managed_identities  = {}
  private_endpoints   = {}
  scope_maps          = {}
  role_assignments    = {}
  diagnostic_settings = {}
  lock                = null
  enable_telemetry    = false
}

import {
  for_each = var.enable_container_registry ? var.container_registry_imports : {}

  to = module.container_registry[each.key].module.container_registry.azurerm_container_registry.this
  id = each.value
}

# Read-only: Deny_Public_Access_On_PaaS_Services_v0 denies any write to a
# registry with public network access enabled. Move to container_registry
# once it is exempted.
data "azapi_resource" "container_registry_existing" {
  for_each = var.container_registry_existing

  type      = "Microsoft.ContainerRegistry/registries@2025-04-01"
  name      = each.value.name
  parent_id = "/subscriptions/${var.subscription_id}/resourceGroups/${var.resource_group[each.value.resource_group_key].name}"
}
