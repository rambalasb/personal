module "virtual_network" {
  for_each = var.enable_virtual_network ? var.virtual_network : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-virtual-network/azurerm"
  version = "0.1.0"

  name                    = each.value.name
  parent_id               = module.resource_group[each.value.resource_group_key].resource_id
  location                = coalesce(each.value.location, module.resource_group[each.value.resource_group_key].location)
  address_space           = each.value.address_space
  dns_servers             = each.value.dns_servers
  ddos_protection_plan    = each.value.ddos_protection_plan
  enable_vm_protection    = each.value.enable_vm_protection
  flow_timeout_in_minutes = each.value.flow_timeout_in_minutes
  encryption              = each.value.encryption
  tags                    = each.value.tags

  subnets = {
    for subnet_key, subnet in each.value.subnets : subnet_key => merge(subnet, {
      delegations = [for delegation in subnet.delegations : {
        name = delegation.name
        service_delegation = {
          name = delegation.service_delegation.name
        }
      }]
    })
  }

  peerings         = {}
  enable_telemetry = false
}

import {
  for_each = var.enable_virtual_network ? var.virtual_network_imports : {}

  to = module.virtual_network[each.key].module.virtual_network.azapi_resource.vnet
  id = "${each.value}?api-version=2024-07-01"
}

import {
  for_each = var.enable_virtual_network ? var.virtual_network_subnet_imports : {}

  to = module.virtual_network[each.value.vnet_key].module.virtual_network.module.subnet[each.value.subnet_key].azapi_resource.subnet[0]
  id = "${each.value.id}?api-version=2024-07-01"
}