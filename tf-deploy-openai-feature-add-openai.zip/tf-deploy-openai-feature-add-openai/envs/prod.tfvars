# Sub-OpenAI-Prod (ab6893cb-e4ea-447e-a514-0ae1b4929416)
# Values come from the Azure resource export of 2026-11-03.
# The VM (and its NIC) and the VNet are off for the first apply;
# adopt them in separate runs.

subscription_id = "ab6893cb-e4ea-447e-a514-0ae1b4929416"

enable_resource_group           = true
enable_monitoring               = true
enable_app_service_plan         = true
enable_application_insights     = true
enable_bastion_host             = true
enable_container_registry       = true
enable_event_grid_system_topic  = true
enable_key_vault                = true
enable_linux_virtual_machine    = false
enable_log_analytics_workspace  = true
enable_network_interface        = false
enable_network_watcher          = true
enable_private_endpoint         = true
enable_public_ssh_key           = true
enable_recovery_services_vault  = true
enable_restore_point_collection = true
enable_storage_account          = true
enable_virtual_network          = false

enable_resource_group_role_assignment           = false
enable_monitoring_role_assignment               = false
enable_app_service_plan_role_assignment         = false
enable_application_insights_role_assignment     = false
enable_bastion_host_role_assignment             = false
enable_container_registry_role_assignment       = false
enable_event_grid_system_topic_role_assignment  = false
enable_key_vault_role_assignment                = false
enable_linux_virtual_machine_role_assignment    = false
enable_log_analytics_workspace_role_assignment  = false
enable_network_interface_role_assignment        = false
enable_network_watcher_role_assignment          = false
enable_private_endpoint_role_assignment         = false
enable_public_ssh_key_role_assignment           = false
enable_recovery_services_vault_role_assignment  = false
enable_restore_point_collection_role_assignment = false
enable_storage_account_role_assignment          = false
enable_virtual_network_role_assignment          = false

role_assignments = {}

# MA_defaultazuremonitorworkspace-cca_canadacentral_managed is left out: managedBy defaultazuremonitorworkspace-cca; ARM rejects a PUT that drops it.
# AzureBackupRG_canadacentral_1 is left out: managedBy Microsoft.RecoveryServices; ARM rejects a PUT that drops it.
# The existing CanNotDelete locks are separate resources and stay unmanaged.
resource_group = {
  network = {
    name     = "rg-openai-prod-network-canadacentral-001"
    location = "canadacentral"
    tags = {
      CostCenterId = "80045905"
      Environment  = "Prod"
    }
  }
  siem = {
    name     = "rg-openai-prod-siem-canadacentral-001"
    location = "canadacentral"
    tags = {
      CostCenterId = "80045905"
      Environment  = "Prod"
    }
  }
  app = {
    name     = "rg-openai-prod-app-canadacentral-001"
    location = "canadacentral"
    tags = {
      CostCenterId = "80045905"
      Environment  = "Prod"
    }
  }
  networkwatcherrg = {
    name     = "NetworkWatcherRG"
    location = "canadacentral"
    tags = {
      CostCenterId = "80045905"
      Environment  = "Prod"
    }
  }
  defaultresourcegroup_cca = {
    name     = "defaultresourcegroup-cca"
    location = "canadacentral"
    tags = {
      CostCenterId = "80045905"
      Environment  = "Prod"
    }
  }
  alerts = {
    name     = "rg-openai-prod-alerts-canadacentral-001"
    location = "canadacentral"
    tags = {
      CostCenterId = "80045905"
      Environment  = "Prod"
    }
  }
  app_canadaeast = {
    name     = "rg-openai-prod-app-canadaeast-001"
    location = "canadaeast"
    tags = {
      CostCenterId = "80045905"
      Environment  = "Prod"
    }
  }
  alerts_canadaeast = {
    name     = "rg-openai-prod-alerts-canadaeast-001"
    location = "canadaeast"
    tags = {
      CostCenterId = "80045905"
      Environment  = "Prod"
    }
  }
}

import_resource_group = {
  network                  = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-network-canadacentral-001"
  siem                     = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-siem-canadacentral-001"
  app                      = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadacentral-001"
  networkwatcherrg         = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/NetworkWatcherRG"
  defaultresourcegroup_cca = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/defaultresourcegroup-cca"
  alerts                   = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-alerts-canadacentral-001"
  app_canadaeast           = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadaeast-001"
  alerts_canadaeast        = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-alerts-canadaeast-001"
}

alert = {
  resource_group_key         = "alerts"
  root_management_group_name = null
  tags                       = {}
  activity_log_alerts = {
    kv_delete = {
      name                = "kv-delete-alert-openai-prod-cc"
      resource_group_name = "rg-openai-prod-siem-canadacentral-001"
      scopes              = ["/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416"]
      location            = "global"
      description         = "Fires when a Key Vault deletion is attempted"
      enabled             = true
      criteria = {
        category       = "Administrative"
        operation_name = "Microsoft.KeyVault/vaults/delete"
        status         = "Started"
      }
      action_group_keys = []
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/lga-servicenow-integration_group/providers/Microsoft.Insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      webhook_properties = {}
      tags = {
        CostCenterId = "80045905"
        Environment  = "Prod"
      }
    }
    app_delete = {
      name                = "app-delete-alert-openai-prod-cc"
      resource_group_name = "rg-openai-prod-alerts-canadacentral-001"
      scopes              = ["/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416"]
      location            = "global"
      description         = "Fires when an App Service is deleted"
      enabled             = true
      criteria = {
        category       = "Administrative"
        operation_name = "Microsoft.Web/sites/Delete"
        status         = "Started"
      }
      action_group_keys = []
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/lga-servicenow-integration_group/providers/Microsoft.Insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      webhook_properties = {}
      tags = {
        CostCenterId = "80045905"
        Environment  = "Prod"
      }
    }
    app_stop = {
      name                = "app-stop-alert-openai-prod-cc"
      resource_group_name = "rg-openai-prod-alerts-canadacentral-001"
      scopes              = ["/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416"]
      location            = "global"
      description         = "Fires when an App Service is stopped"
      enabled             = true
      criteria = {
        category       = "Administrative"
        operation_name = "Microsoft.Web/sites/stop/Action"
        status         = "Started"
      }
      action_group_keys = []
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/lga-servicenow-integration_group/providers/Microsoft.Insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      webhook_properties = {}
      tags = {
        CostCenterId = "80045905"
        Environment  = "Prod"
      }
    }
    cosmosdb_delete = {
      name                = "cosmosdb-delete-alert-openai-prod-cc"
      resource_group_name = "rg-openai-prod-alerts-canadacentral-001"
      scopes              = ["/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416"]
      location            = "global"
      description         = "Fires when a CosmosDB account deletion is attempted"
      enabled             = true
      criteria = {
        category       = "Administrative"
        operation_name = "Microsoft.DocumentDB/databaseAccounts/delete"
        status         = "Started"
      }
      action_group_keys = []
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/lga-servicenow-integration_group/providers/Microsoft.Insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      webhook_properties = {}
      tags = {
        CostCenterId = "80045905"
        Environment  = "Prod"
      }
    }
    docintel_delete = {
      name                = "docintel-delete-alert-openai-prod-cc"
      resource_group_name = "rg-openai-prod-alerts-canadacentral-001"
      scopes              = ["/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416"]
      location            = "global"
      description         = "Fires when a Document Intelligence account deletion is attempted"
      enabled             = true
      criteria = {
        category       = "Administrative"
        operation_name = "Microsoft.CognitiveServices/accounts/delete"
        status         = "Started"
      }
      action_group_keys = []
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/lga-servicenow-integration_group/providers/Microsoft.Insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      webhook_properties = {}
      tags = {
        CostCenterId = "80045905"
        Environment  = "Prod"
      }
    }
    psql_delete = {
      name                = "psql-delete-alert-openai-prod-cc"
      resource_group_name = "rg-openai-prod-alerts-canadacentral-001"
      scopes              = ["/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416"]
      location            = "global"
      description         = "Fires when a PostgreSQL Flexible Server deletion is attempted"
      enabled             = true
      criteria = {
        category       = "Administrative"
        operation_name = "Microsoft.DBforPostgreSQL/flexibleServers/delete"
        status         = "Started"
      }
      action_group_keys = []
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/lga-servicenow-integration_group/providers/Microsoft.Insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      webhook_properties = {}
      tags = {
        CostCenterId = "80045905"
        Environment  = "Prod"
      }
    }
    openai_delete_ce = {
      name                = "openai-delete-alert-openai-prod-ce"
      resource_group_name = "rg-openai-prod-alerts-canadaeast-001"
      scopes              = ["/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416"]
      location            = "global"
      description         = "Fires when an OpenAI account deletion is attempted"
      enabled             = true
      criteria = {
        category       = "Administrative"
        operation_name = "Microsoft.CognitiveServices/accounts/delete"
        status         = "Started"
      }
      action_group_keys = []
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/lga-servicenow-integration_group/providers/Microsoft.Insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      webhook_properties = {}
      tags = {
        CostCenterId = "80045905"
        Environment  = "Prod"
      }
    }
  }
  metric_alerts = {
    psql_storage = {
      name                = "psql-storage-alert-openai-prod-cc"
      resource_group_name = "rg-openai-prod-alerts-canadacentral-001"
      scopes = [
        "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadacentral-001/providers/Microsoft.DBforPostgreSQL/flexibleServers/psql-openai-prod-cc-001"
      ]
      description              = "Fires when PostgreSQL storage usage exceeds 85% — server will go read-only if full"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT15M"
      window_size              = "PT1H"
      severity                 = 1
      target_resource_type     = "Microsoft.DBforPostgreSQL/flexibleServers"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.DBforPostgreSQL/flexibleServers"
          metric_name            = "storage_percent"
          aggregation            = "Average"
          operator               = "GreaterThan"
          threshold              = 85
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/lga-servicenow-integration_group/providers/Microsoft.Insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        CostCenterId = "80045905"
        Environment  = "Prod"
      }
    }
    cosmosdb_throttled_requests = {
      name                = "cosmosdb-throttled-requests-alert-openai-prod-cc"
      resource_group_name = "rg-openai-prod-alerts-canadacentral-001"
      scopes = [
        "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadacentral-001/providers/Microsoft.DocumentDB/databaseAccounts/cdb-openai-prod-canadacentral-001"
      ]
      description              = "Fires when CosmosDB returns 429 throttling errors"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT15M"
      severity                 = 1
      target_resource_type     = "Microsoft.DocumentDB/databaseAccounts"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.DocumentDB/databaseAccounts"
          metric_name            = "TotalRequests"
          aggregation            = "Count"
          operator               = "GreaterThan"
          threshold              = 0
          skip_metric_validation = false
          dimensions = [
            {
              name     = "StatusCode"
              operator = "Include"
              values   = ["429"]
            }
          ]
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/lga-servicenow-integration_group/providers/Microsoft.Insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        CostCenterId = "80045905"
        Environment  = "Prod"
      }
    }
    docintel_latency = {
      name                = "docintel-latency-alert-openai-prod-cc"
      resource_group_name = "rg-openai-prod-alerts-canadacentral-001"
      scopes = [
        "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadacentral-001/providers/Microsoft.CognitiveServices/accounts/doc-openai-prod-cc-001"
      ]
      description              = "Fires when Document Intelligence latency deviates from dynamic baseline"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT1H"
      severity                 = 2
      target_resource_type     = "Microsoft.CognitiveServices/accounts"
      target_resource_location = "canadacentral"
      dynamic_criteria = {
        metric_namespace         = "Microsoft.CognitiveServices/accounts"
        metric_name              = "Latency"
        aggregation              = "Average"
        operator                 = "GreaterOrLessThan"
        alert_sensitivity        = "Medium"
        evaluation_total_count   = 4
        evaluation_failure_count = 4
        ignore_data_before       = null
        skip_metric_validation   = false
        dimensions               = []
      }
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/lga-servicenow-integration_group/providers/Microsoft.Insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        CostCenterId = "80045905"
        Environment  = "Prod"
      }
    }
    psql_connection = {
      name                = "psql-connection-alert-openai-prod-cc"
      resource_group_name = "rg-openai-prod-alerts-canadacentral-001"
      scopes = [
        "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadacentral-001/providers/Microsoft.DBforPostgreSQL/flexibleServers/psql-openai-prod-cc-001"
      ]
      description              = "Fires when active connections exceed 80% of server limit"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT15M"
      severity                 = 1
      target_resource_type     = "Microsoft.DBforPostgreSQL/flexibleServers"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.DBforPostgreSQL/flexibleServers"
          metric_name            = "active_connections"
          aggregation            = "Average"
          operator               = "GreaterThan"
          threshold              = 675
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/lga-servicenow-integration_group/providers/Microsoft.Insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        CostCenterId = "80045905"
        Environment  = "Prod"
      }
    }
    docintel_blockedcalls = {
      name                = "docintel-blockedcalls-alert-openai-prod-cc"
      resource_group_name = "rg-openai-prod-alerts-canadacentral-001"
      scopes = [
        "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadacentral-001/providers/Microsoft.CognitiveServices/accounts/doc-openai-prod-cc-001"
      ]
      description              = "Fires when Document Intelligence calls are throttled or blocked"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT15M"
      severity                 = 1
      target_resource_type     = "Microsoft.CognitiveServices/accounts"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.CognitiveServices/accounts"
          metric_name            = "BlockedCalls"
          aggregation            = "Total"
          operator               = "GreaterThan"
          threshold              = 0
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/lga-servicenow-integration_group/providers/Microsoft.Insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        CostCenterId = "80045905"
        Environment  = "Prod"
      }
    }
    docintel_servererror = {
      name                = "docintel-servererror-alert-openai-prod-cc"
      resource_group_name = "rg-openai-prod-alerts-canadacentral-001"
      scopes = [
        "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadacentral-001/providers/Microsoft.CognitiveServices/accounts/doc-openai-prod-cc-001"
      ]
      description              = "Fires when Document Intelligence returns server-side errors"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT15M"
      severity                 = 1
      target_resource_type     = "Microsoft.CognitiveServices/accounts"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.CognitiveServices/accounts"
          metric_name            = "ServerErrors"
          aggregation            = "Total"
          operator               = "GreaterThan"
          threshold              = 0
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/lga-servicenow-integration_group/providers/Microsoft.Insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        CostCenterId = "80045905"
        Environment  = "Prod"
      }
    }
    cosmosdb_availability = {
      name                = "cosmosdb-availability-alert-openai-prod-cc"
      resource_group_name = "rg-openai-prod-alerts-canadacentral-001"
      scopes = [
        "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadacentral-001/providers/Microsoft.DocumentDB/databaseAccounts/cdb-openai-prod-canadacentral-001"
      ]
      description              = "Fires when CosmosDB service availability drops below 99.9%"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT1H"
      severity                 = 0
      target_resource_type     = "Microsoft.DocumentDB/databaseAccounts"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.DocumentDB/databaseAccounts"
          metric_name            = "ServiceAvailability"
          aggregation            = "Average"
          operator               = "LessThan"
          threshold              = 99.9
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/lga-servicenow-integration_group/providers/Microsoft.Insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        CostCenterId = "80045905"
        Environment  = "Prod"
      }
    }
    psql_cpu = {
      name                = "psql-cpu-alert-openai-prod-cc"
      resource_group_name = "rg-openai-prod-alerts-canadacentral-001"
      scopes = [
        "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadacentral-001/providers/Microsoft.DBforPostgreSQL/flexibleServers/psql-openai-prod-cc-001"
      ]
      description              = "Fires when PostgreSQL CPU usage exceeds 90%"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT15M"
      severity                 = 1
      target_resource_type     = "Microsoft.DBforPostgreSQL/flexibleServers"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.DBforPostgreSQL/flexibleServers"
          metric_name            = "cpu_percent"
          aggregation            = "Average"
          operator               = "GreaterThan"
          threshold              = 90
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/lga-servicenow-integration_group/providers/Microsoft.Insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        CostCenterId = "80045905"
        Environment  = "Prod"
      }
    }
    docintel_clienterror = {
      name                = "docintel-clienterror-alert-openai-prod-cc"
      resource_group_name = "rg-openai-prod-alerts-canadacentral-001"
      scopes = [
        "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadacentral-001/providers/Microsoft.CognitiveServices/accounts/doc-openai-prod-cc-001"
      ]
      description              = "Fires when Document Intelligence client errors deviate from baseline"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT1H"
      severity                 = 2
      target_resource_type     = "Microsoft.CognitiveServices/accounts"
      target_resource_location = "canadacentral"
      dynamic_criteria = {
        metric_namespace         = "Microsoft.CognitiveServices/accounts"
        metric_name              = "ClientErrors"
        aggregation              = "Total"
        operator                 = "GreaterOrLessThan"
        alert_sensitivity        = "Medium"
        evaluation_total_count   = 4
        evaluation_failure_count = 4
        ignore_data_before       = null
        skip_metric_validation   = false
        dimensions               = []
      }
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/lga-servicenow-integration_group/providers/Microsoft.Insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        CostCenterId = "80045905"
        Environment  = "Prod"
      }
    }
    cosmosdb_ruconsumption = {
      name                = "cosmosdb-ruconsumption-alert-openai-prod-cc"
      resource_group_name = "rg-openai-prod-alerts-canadacentral-001"
      scopes = [
        "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadacentral-001/providers/Microsoft.DocumentDB/databaseAccounts/cdb-openai-prod-canadacentral-001"
      ]
      description              = "Fires when normalized RU consumption exceeds 80% — throttling is imminent"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT15M"
      severity                 = 1
      target_resource_type     = "Microsoft.DocumentDB/databaseAccounts"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.DocumentDB/databaseAccounts"
          metric_name            = "NormalizedRUConsumption"
          aggregation            = "Maximum"
          operator               = "GreaterThan"
          threshold              = 80
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/rg-alerts-management-canadacentral-001/providers/Microsoft.Insights/actionGroups/ag-monitor-mail-alerts-canadacentral-001"
      ]
      tags = {
        CostCenterId = "80045905"
        Environment  = "Prod"
      }
    }
    app_httpresponsetime = {
      name                = "app-httpresponsetime-alert-openai-prod-cc"
      resource_group_name = "rg-openai-prod-alerts-canadacentral-001"
      scopes = [
        "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadacentral-001/providers/Microsoft.Web/sites/app-openai-prod-canadacentral-001"
      ]
      description              = "Fires when HttpResponseTime deviates from dynamic baseline"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT1H"
      severity                 = 2
      target_resource_type     = "Microsoft.Web/sites"
      target_resource_location = "canadacentral"
      dynamic_criteria = {
        metric_namespace         = "Microsoft.Web/sites"
        metric_name              = "HttpResponseTime"
        aggregation              = "Average"
        operator                 = "GreaterOrLessThan"
        alert_sensitivity        = "Medium"
        evaluation_total_count   = 4
        evaluation_failure_count = 4
        ignore_data_before       = null
        skip_metric_validation   = false
        dimensions               = []
      }
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/lga-servicenow-integration_group/providers/Microsoft.Insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        CostCenterId = "80045905"
        Environment  = "Prod"
      }
    }
    app_http4xx = {
      name                = "app-http4xx-alert-openai-prod-cc"
      resource_group_name = "rg-openai-prod-alerts-canadacentral-001"
      scopes = [
        "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadacentral-001/providers/Microsoft.Web/sites/app-openai-prod-canadacentral-001"
      ]
      description              = "Fires when Http4xx errors deviate from dynamic baseline"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT1H"
      severity                 = 1
      target_resource_type     = "Microsoft.Web/sites"
      target_resource_location = "canadacentral"
      dynamic_criteria = {
        metric_namespace         = "Microsoft.Web/sites"
        metric_name              = "Http4xx"
        aggregation              = "Total"
        operator                 = "GreaterOrLessThan"
        alert_sensitivity        = "Medium"
        evaluation_total_count   = 4
        evaluation_failure_count = 4
        ignore_data_before       = null
        skip_metric_validation   = false
        dimensions               = []
      }
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/lga-servicenow-integration_group/providers/Microsoft.Insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        CostCenterId = "80045905"
        Environment  = "Prod"
      }
    }
    app_cputime = {
      name                = "app-cputime-alert-openai-prod-cc"
      resource_group_name = "rg-openai-prod-alerts-canadacentral-001"
      scopes = [
        "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadacentral-001/providers/Microsoft.Web/sites/app-openai-prod-canadacentral-001"
      ]
      description              = "Fires when CpuTime exceeds 300 seconds"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT15M"
      severity                 = 2
      target_resource_type     = "Microsoft.Web/sites"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Web/sites"
          metric_name            = "CpuTime"
          aggregation            = "Total"
          operator               = "GreaterThan"
          threshold              = 300
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/lga-servicenow-integration_group/providers/Microsoft.Insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        CostCenterId = "80045905"
        Environment  = "Prod"
      }
    }
    app_http5xx = {
      name                = "app-http5xx-alert-openai-prod-cc"
      resource_group_name = "rg-openai-prod-alerts-canadacentral-001"
      scopes = [
        "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadacentral-001/providers/Microsoft.Web/sites/app-openai-prod-canadacentral-001"
      ]
      description              = "Fires when Http5xx server errors exceed 5"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT15M"
      severity                 = 1
      target_resource_type     = "Microsoft.Web/sites"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Web/sites"
          metric_name            = "Http5xx"
          aggregation            = "Total"
          operator               = "GreaterThan"
          threshold              = 5
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/lga-servicenow-integration_group/providers/Microsoft.Insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        CostCenterId = "80045905"
        Environment  = "Prod"
      }
    }
    app_healthcheck = {
      name                = "app-healthcheck-alert-openai-prod-cc"
      resource_group_name = "rg-openai-prod-alerts-canadacentral-001"
      scopes = [
        "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadacentral-001/providers/Microsoft.Web/sites/app-openai-prod-canadacentral-001"
      ]
      description              = "Fires when Health Check status drops below 100"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT15M"
      severity                 = 1
      target_resource_type     = "Microsoft.Web/sites"
      target_resource_location = "canadacentral"
      criteria = [
        {
          metric_namespace       = "Microsoft.Web/sites"
          metric_name            = "HealthCheckStatus"
          aggregation            = "Average"
          operator               = "LessThan"
          threshold              = 100
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourcegroups/rg-alerts-management-canadacentral-001/providers/microsoft.insights/actiongroups/ag-monitor-mail-alerts-canadacentral-001"
      ]
      tags = {
        CostCenterId = "80045905"
        Environment  = "Prod"
      }
    }
    openai_responsetime_ce = {
      name                = "openai-responsetime-alert-openai-prod-ce"
      resource_group_name = "rg-openai-prod-alerts-canadaeast-001"
      scopes = [
        "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadaeast-001/providers/Microsoft.CognitiveServices/accounts/oai-openai-prod-ce-001"
      ]
      description              = "Fires when OpenAI response latency deviates from dynamic baseline"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT1H"
      severity                 = 2
      target_resource_type     = "Microsoft.CognitiveServices/accounts"
      target_resource_location = "canadaeast"
      dynamic_criteria = {
        metric_namespace         = "Microsoft.CognitiveServices/accounts"
        metric_name              = "AzureOpenAITimeToResponse"
        aggregation              = "Average"
        operator                 = "GreaterOrLessThan"
        alert_sensitivity        = "Medium"
        evaluation_total_count   = 4
        evaluation_failure_count = 4
        ignore_data_before       = null
        skip_metric_validation   = false
        dimensions               = []
      }
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/lga-servicenow-integration_group/providers/Microsoft.Insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        CostCenterId = "80045905"
        Environment  = "Prod"
      }
    }
    openai_blockedcalls_ce = {
      name                = "openai-blockedcalls-alert-openai-prod-ce"
      resource_group_name = "rg-openai-prod-alerts-canadaeast-001"
      scopes = [
        "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadaeast-001/providers/Microsoft.CognitiveServices/accounts/oai-openai-prod-ce-001"
      ]
      description              = "Fires when OpenAI calls are blocked due to rate or quota limits"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT15M"
      severity                 = 1
      target_resource_type     = "Microsoft.CognitiveServices/accounts"
      target_resource_location = "canadaeast"
      criteria = [
        {
          metric_namespace       = "Microsoft.CognitiveServices/accounts"
          metric_name            = "BlockedCalls"
          aggregation            = "Total"
          operator               = "GreaterThan"
          threshold              = 0
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/lga-servicenow-integration_group/providers/Microsoft.Insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        CostCenterId = "80045905"
        Environment  = "Prod"
      }
    }
    openai_servererror_ce = {
      name                = "openai-servererror-alert-openai-prod-ce"
      resource_group_name = "rg-openai-prod-alerts-canadaeast-001"
      scopes = [
        "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadaeast-001/providers/Microsoft.CognitiveServices/accounts/oai-openai-prod-ce-001"
      ]
      description              = "Fires when OpenAI returns server-side errors (5xx)"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT15M"
      severity                 = 1
      target_resource_type     = "Microsoft.CognitiveServices/accounts"
      target_resource_location = "canadaeast"
      criteria = [
        {
          metric_namespace       = "Microsoft.CognitiveServices/accounts"
          metric_name            = "ServerErrors"
          aggregation            = "Total"
          operator               = "GreaterThan"
          threshold              = 0
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/lga-servicenow-integration_group/providers/Microsoft.Insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        CostCenterId = "80045905"
        Environment  = "Prod"
      }
    }
    openai_tokenconsumption_ce = {
      name                = "openai-tokenconsumption-alert-openai-prod-ce"
      resource_group_name = "rg-openai-prod-alerts-canadaeast-001"
      scopes = [
        "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadaeast-001/providers/Microsoft.CognitiveServices/accounts/oai-openai-prod-ce-001"
      ]
      description              = "Fires when processed inference tokens deviate from dynamic baseline"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT1H"
      severity                 = 2
      target_resource_type     = "Microsoft.CognitiveServices/accounts"
      target_resource_location = "canadaeast"
      dynamic_criteria = {
        metric_namespace         = "Microsoft.CognitiveServices/accounts"
        metric_name              = "TokenTransaction"
        aggregation              = "Total"
        operator                 = "GreaterOrLessThan"
        alert_sensitivity        = "Medium"
        evaluation_total_count   = 4
        evaluation_failure_count = 4
        ignore_data_before       = null
        skip_metric_validation   = false
        dimensions               = []
      }
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/rg-alerts-management-canadacentral-001/providers/Microsoft.Insights/actionGroups/ag-monitor-mail-alerts-canadacentral-001"
      ]
      tags = {
        CostCenterId = "80045905"
        Environment  = "Prod"
      }
    }
    openai_availability_ce = {
      name                = "openai-availability-alert-openai-prod-ce"
      resource_group_name = "rg-openai-prod-alerts-canadaeast-001"
      scopes = [
        "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadaeast-001/providers/Microsoft.CognitiveServices/accounts/oai-openai-prod-ce-001"
      ]
      description              = "Fires when OpenAI availability drops below 99%"
      enabled                  = true
      auto_mitigate            = true
      frequency                = "PT5M"
      window_size              = "PT15M"
      severity                 = 0
      target_resource_type     = "Microsoft.CognitiveServices/accounts"
      target_resource_location = "canadaeast"
      criteria = [
        {
          metric_namespace       = "Microsoft.CognitiveServices/accounts"
          metric_name            = "AzureOpenAIAvailabilityRate"
          aggregation            = "Average"
          operator               = "LessThan"
          threshold              = 99
          skip_metric_validation = false
          dimensions             = []
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/lga-servicenow-integration_group/providers/Microsoft.Insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      tags = {
        CostCenterId = "80045905"
        Environment  = "Prod"
      }
    }
  }
  log_search_alerts = {
    kv_secret_expired = {
      name                = "kv-secret-expired-alert-openai-prod-cc"
      resource_group_name = "rg-openai-prod-siem-canadacentral-001"
      location            = "canadacentral"
      scopes = [
        "/subscriptions/7d54d6f7-83d9-48cf-ac35-1068bcfd0561/resourceGroups/rg-siem-security-canadacentral-001/providers/Microsoft.OperationalInsights/workspaces/la-siem-security-canadacentral-001"
      ]
      severity                          = 0
      evaluation_frequency              = "PT5M"
      window_duration                   = "PT30M"
      description                       = "Fires when one or more Key Vault secrets have already expired"
      display_name                      = null
      enabled                           = true
      auto_mitigation_enabled           = true
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = null
      target_resource_types             = null
      criteria = [
        {
          query                   = "AzureDiagnostics\n    | where ResourceProvider == \"MICROSOFT.KEYVAULT\"\n    | where OperationName contains \"SecretExpired\"\n"
          time_aggregation_method = "Count"
          threshold               = 1
          operator                = "GreaterThanOrEqual"
          resource_id_column      = null
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/lga-servicenow-integration_group/providers/Microsoft.Insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        CostCenterId = "80045905"
        Environment  = "Prod"
      }
    }
    kv_secret_near_expiry = {
      name                = "kv-secret-near-expiry-alert-openai-prod-cc"
      resource_group_name = "rg-openai-prod-siem-canadacentral-001"
      location            = "canadacentral"
      scopes = [
        "/subscriptions/7d54d6f7-83d9-48cf-ac35-1068bcfd0561/resourceGroups/rg-siem-security-canadacentral-001/providers/Microsoft.OperationalInsights/workspaces/la-siem-security-canadacentral-001"
      ]
      severity                          = 1
      evaluation_frequency              = "PT5M"
      window_duration                   = "PT30M"
      description                       = "Fires when one or more Key Vault secrets are expiring within 30 days"
      display_name                      = null
      enabled                           = true
      auto_mitigation_enabled           = true
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = null
      target_resource_types             = null
      criteria = [
        {
          query                   = "AzureDiagnostics\n| where ResourceProvider == \"MICROSOFT.KEYVAULT\"\n| where OperationName contains \"SecretNearExpiry\"\n"
          time_aggregation_method = "Count"
          threshold               = 1
          operator                = "GreaterThanOrEqual"
          resource_id_column      = null
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/lga-servicenow-integration_group/providers/Microsoft.Insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        CostCenterId = "80045905"
        Environment  = "Prod"
      }
    }
    storage_container_delete = {
      name                = "storage-container-delete-alert-openai-prod-cc"
      resource_group_name = "rg-openai-prod-alerts-canadacentral-001"
      location            = "canadacentral"
      scopes = [
        "/subscriptions/7d54d6f7-83d9-48cf-ac35-1068bcfd0561/resourceGroups/rg-siem-security-canadacentral-001/providers/Microsoft.OperationalInsights/workspaces/la-siem-security-canadacentral-001"
      ]
      severity                          = 0
      evaluation_frequency              = "PT5M"
      window_duration                   = "PT30M"
      description                       = "Fires when someone attempts to delete a storage container"
      display_name                      = null
      enabled                           = true
      auto_mitigation_enabled           = true
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = null
      target_resource_types             = null
      criteria = [
        {
          query                   = "AzureActivity\n| where ResourceProviderValue == \"MICROSOFT.STORAGE\"\n| where OperationNameValue == \"Microsoft.Storage/storageAccounts/blobServices/containers/delete\"\n| where SubscriptionId == \"ab6893cb-e4ea-447e-a514-0ae1b4929416\"\n"
          time_aggregation_method = "Count"
          threshold               = 1
          operator                = "GreaterThanOrEqual"
          resource_id_column      = null
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/lga-servicenow-integration_group/providers/Microsoft.Insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        CostCenterId = "80045905"
        Environment  = "Prod"
      }
    }
    storage_delete = {
      name                = "storage-delete-alert-openai-prod-cc"
      resource_group_name = "rg-openai-prod-alerts-canadacentral-001"
      location            = "canadacentral"
      scopes = [
        "/subscriptions/7d54d6f7-83d9-48cf-ac35-1068bcfd0561/resourceGroups/rg-siem-security-canadacentral-001/providers/Microsoft.OperationalInsights/workspaces/la-siem-security-canadacentral-001"
      ]
      severity                          = 0
      evaluation_frequency              = "PT5M"
      window_duration                   = "PT30M"
      description                       = "Fires when someone attempts to delete a storage account"
      display_name                      = null
      enabled                           = true
      auto_mitigation_enabled           = true
      skip_query_validation             = false
      mute_actions_after_alert_duration = null
      query_time_range_override         = null
      target_resource_types             = null
      criteria = [
        {
          query                   = "AzureActivity\n| where ResourceProviderValue == \"MICROSOFT.STORAGE\"\n| where OperationNameValue == \"Microsoft.Storage/storageAccounts/delete\"\n| where SubscriptionId == \"ab6893cb-e4ea-447e-a514-0ae1b4929416\"\n"
          time_aggregation_method = "Count"
          threshold               = 1
          operator                = "GreaterThanOrEqual"
          resource_id_column      = null
          metric_measure_column   = null
          dimensions              = []
          failing_periods = {
            minimum_failing_periods_to_trigger_alert = 1
            number_of_evaluation_periods             = 1
          }
        }
      ]
      action_group_ids = [
        "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/lga-servicenow-integration_group/providers/Microsoft.Insights/actionGroups/ ag-servicenow-alerts-canadacentral-001"
      ]
      custom_properties = {}
      tags = {
        CostCenterId = "80045905"
        Environment  = "Prod"
      }
    }
  }
  alert_processing_rules = {}
}

activity_log_alert_imports = {
  kv_delete        = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-siem-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/kv-delete-alert-openai-prod-cc"
  app_delete       = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-alerts-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/app-delete-alert-openai-prod-cc"
  app_stop         = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-alerts-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/app-stop-alert-openai-prod-cc"
  cosmosdb_delete  = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-alerts-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/cosmosdb-delete-alert-openai-prod-cc"
  docintel_delete  = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-alerts-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/docintel-delete-alert-openai-prod-cc"
  psql_delete      = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-alerts-canadacentral-001/providers/Microsoft.Insights/activityLogAlerts/psql-delete-alert-openai-prod-cc"
  openai_delete_ce = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-alerts-canadaeast-001/providers/Microsoft.Insights/activityLogAlerts/openai-delete-alert-openai-prod-ce"
}

metric_alert_imports = {
  psql_storage                = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-alerts-canadacentral-001/providers/Microsoft.Insights/metricAlerts/psql-storage-alert-openai-prod-cc"
  cosmosdb_throttled_requests = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-alerts-canadacentral-001/providers/Microsoft.Insights/metricAlerts/cosmosdb-throttled-requests-alert-openai-prod-cc"
  docintel_latency            = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-alerts-canadacentral-001/providers/Microsoft.Insights/metricAlerts/docintel-latency-alert-openai-prod-cc"
  psql_connection             = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-alerts-canadacentral-001/providers/Microsoft.Insights/metricAlerts/psql-connection-alert-openai-prod-cc"
  docintel_blockedcalls       = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-alerts-canadacentral-001/providers/Microsoft.Insights/metricAlerts/docintel-blockedcalls-alert-openai-prod-cc"
  docintel_servererror        = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-alerts-canadacentral-001/providers/Microsoft.Insights/metricAlerts/docintel-servererror-alert-openai-prod-cc"
  cosmosdb_availability       = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-alerts-canadacentral-001/providers/Microsoft.Insights/metricAlerts/cosmosdb-availability-alert-openai-prod-cc"
  psql_cpu                    = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-alerts-canadacentral-001/providers/Microsoft.Insights/metricAlerts/psql-cpu-alert-openai-prod-cc"
  docintel_clienterror        = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-alerts-canadacentral-001/providers/Microsoft.Insights/metricAlerts/docintel-clienterror-alert-openai-prod-cc"
  cosmosdb_ruconsumption      = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-alerts-canadacentral-001/providers/Microsoft.Insights/metricAlerts/cosmosdb-ruconsumption-alert-openai-prod-cc"
  app_httpresponsetime        = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-alerts-canadacentral-001/providers/Microsoft.Insights/metricAlerts/app-httpresponsetime-alert-openai-prod-cc"
  app_http4xx                 = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-alerts-canadacentral-001/providers/Microsoft.Insights/metricAlerts/app-http4xx-alert-openai-prod-cc"
  app_cputime                 = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-alerts-canadacentral-001/providers/Microsoft.Insights/metricAlerts/app-cputime-alert-openai-prod-cc"
  app_http5xx                 = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-alerts-canadacentral-001/providers/Microsoft.Insights/metricAlerts/app-http5xx-alert-openai-prod-cc"
  app_healthcheck             = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-alerts-canadacentral-001/providers/Microsoft.Insights/metricAlerts/app-healthcheck-alert-openai-prod-cc"
  openai_responsetime_ce      = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-alerts-canadaeast-001/providers/Microsoft.Insights/metricAlerts/openai-responsetime-alert-openai-prod-ce"
  openai_blockedcalls_ce      = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-alerts-canadaeast-001/providers/Microsoft.Insights/metricAlerts/openai-blockedcalls-alert-openai-prod-ce"
  openai_servererror_ce       = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-alerts-canadaeast-001/providers/Microsoft.Insights/metricAlerts/openai-servererror-alert-openai-prod-ce"
  openai_tokenconsumption_ce  = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-alerts-canadaeast-001/providers/Microsoft.Insights/metricAlerts/openai-tokenconsumption-alert-openai-prod-ce"
  openai_availability_ce      = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-alerts-canadaeast-001/providers/Microsoft.Insights/metricAlerts/openai-availability-alert-openai-prod-ce"
}

log_search_alert_imports = {
  kv_secret_expired        = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-siem-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/kv-secret-expired-alert-openai-prod-cc"
  kv_secret_near_expiry    = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-siem-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/kv-secret-near-expiry-alert-openai-prod-cc"
  storage_container_delete = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-alerts-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/storage-container-delete-alert-openai-prod-cc"
  storage_delete           = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-alerts-canadacentral-001/providers/Microsoft.Insights/scheduledQueryRules/storage-delete-alert-openai-prod-cc"
}

# Not managed here:
#   activitylogalerts 'app-start-alert-openai-prod-cc' (rg-openai-prod-alerts-canadacentral-001): `status` uses containsAny ['started']; the wrapper's single `status` writes `equals`, so adoption would rewrite the condition
#   activitylogalerts 'app-plan-write-alert-openai-prod-cc' (rg-openai-prod-alerts-canadacentral-001): `status` uses containsAny ['started']; the wrapper's single `status` writes `equals`, so adoption would rewrite the condition
#   actionrules 'Alert suppression for OpenAI Canadacentral' (rg-openai-prod-app-canadacentral-001): azurerm rejects processing rule names with spaces; rename it in Azure to manage it
#   actionrules 'Alert suppression for OpenAI Network' (rg-openai-prod-network-canadacentral-001): azurerm rejects processing rule names with spaces; rename it in Azure to manage it
#   actionrules 'Alert suppression for OpenAI East' (rg-openai-prod-app-canadaeast-001): azurerm rejects processing rule names with spaces; rename it in Azure to manage it
alert_processing_rule_imports = {}

app_service_plan = {
  app = {
    name                            = "asp-openai-prod-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    os_type                         = "Linux"
    sku_name                        = "P1v3"
    worker_count                    = 1
    maximum_elastic_worker_count    = 1
    per_site_scaling_enabled        = false
    premium_plan_auto_scale_enabled = false
    zone_balancing_enabled          = false
    app_service_environment_id      = null
    tags = {
      CostCenterId = "80045905"
      Environment  = "Prod"
    }
  }
}

app_service_plan_imports = {
  app = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadacentral-001/providers/Microsoft.Web/serverFarms/asp-openai-prod-canadacentral-001"
}

# The daily cap is not in the export (100 is the provider default); confirm with
# az monitor app-insights component billing show.
application_insights = {
  app = {
    name                          = "ai-openai-prod-canadacentral-001"
    resource_group_key            = "app"
    location                      = "canadacentral"
    workspace_id                  = "/subscriptions/7d54d6f7-83d9-48cf-ac35-1068bcfd0561/resourceGroups/rg-siem-security-canadacentral-001/providers/Microsoft.OperationalInsights/workspaces/la-siem-security-canadacentral-001"
    application_type              = "web"
    retention_in_days             = 30
    daily_data_cap_in_gb          = 100
    sampling_percentage           = 100
    internet_ingestion_enabled    = false
    internet_query_enabled        = true
    local_authentication_disabled = false
    disable_ip_masking            = false
    tags = {
      CostCenterId = "80045905"
      Environment  = "Prod"
    }
  }
}

application_insights_imports = {
  app = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadacentral-001/providers/Microsoft.Insights/components/ai-openai-prod-canadacentral-001"
}

bastion_host = {
  app = {
    name               = "vnet-openai-prod-canadacentral-001-bastion"
    resource_group_key = "network"
    location           = "canadacentral"
    sku                = "Developer"
    scale_units        = 2
    virtual_network_id = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-prod-canadacentral-001"
    zones              = []
    copy_paste_enabled = true
    tags = {
      CostCenterId = "80045905"
      Environment  = "Prod"
    }
  }
}

bastion_host_imports = {
  app = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-network-canadacentral-001/providers/Microsoft.Network/bastionHosts/vnet-openai-prod-canadacentral-001-bastion"
}

# zone_redundancy_enabled forces replacement. Retention is disabled on the live
# registry, so retention_policy_in_days stays null; admin_enabled matches the export.
container_registry = {
  app = {
    name                          = "acropenaiprodcc001"
    resource_group_key            = "app"
    location                      = "canadacentral"
    sku                           = "Premium"
    admin_enabled                 = true
    anonymous_pull_enabled        = false
    data_endpoint_enabled         = false
    export_policy_enabled         = true
    quarantine_policy_enabled     = false
    retention_policy_in_days      = null
    trust_policy_enabled          = false
    public_network_access_enabled = false
    network_rule_bypass_option    = "None"
    network_rule_set              = null
    zone_redundancy_enabled       = false
    tags = {
      CostCenterId = "80045905"
      Environment  = "Prod"
    }
  }
}

container_registry_existing = {}

container_registry_imports = {
  app = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadacentral-001/providers/Microsoft.ContainerRegistry/registries/acropenaiprodcc001"
}

event_grid_system_topic = {
  app_storage = {
    name                        = "stopenaiprodcac001-44d2f147-0cc5-458e-9df3-8c8eec0cacd9"
    resource_group_key          = "app"
    location                    = "canadacentral"
    topic_type                  = "microsoft.storage.storageaccounts"
    source_resource_id          = null
    exported_source_resource_id = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadacentral-001/providers/microsoft.storage/storageaccounts/stopenaiprodcac001"
    tags = {
      CostCenterId = "80045905"
      Environment  = "Prod"
    }
  }
}

event_grid_system_topic_imports = {
  app_storage = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadacentral-001/providers/Microsoft.EventGrid/systemTopics/stopenaiprodcac001-44d2f147-0cc5-458e-9df3-8c8eec0cacd9"
}

# softDeleteRetentionInDays is not reported, which means Azure's default of 90.
key_vault = {
  app = {
    name                            = "kvopenaiprodcc001"
    resource_group_key              = "siem"
    location                        = "canadacentral"
    tenant_id                       = "8fbb85e8-0cbc-48c3-a2e9-528cef30ec27"
    sku_name                        = "premium"
    enabled_for_deployment          = false
    enabled_for_disk_encryption     = true
    enabled_for_template_deployment = true
    legacy_access_policies_enabled  = false
    public_network_access_enabled   = false
    purge_protection_enabled        = true
    soft_delete_retention_days      = 90
    network_acls = {
      bypass                     = "AzureServices"
      default_action             = "Deny"
      ip_rules                   = []
      virtual_network_subnet_ids = []
    }
    tags = {
      CostCenterId = "80045905"
      Environment  = "Prod"
    }
  }
}

key_vault_imports = {
  app = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-siem-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvopenaiprodcc001"
}

# Switched off for the first apply; adopt in its own run. SSH keys only, so no
# password is needed. The OS disk is owned inline; extensions and run commands stay unmanaged.
linux_virtual_machine = {
  app = {
    name               = "vm-openai-prod-canadacentral-001"
    resource_group_key = "app"
    location           = "canadacentral"
    size               = "Standard_D4s_v4"
    zone               = null
    admin_username     = "azure_admin"
    admin_ssh_public_keys = [
      "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAACAQCXWopMO3dkiUqMWfczr58AKN6RkoIbx6imrTpoo4d7zAr7c8wp87RgzrzALz9R3UycPztMRMiLMGxvJ/UkdEGqxvlo/av68n0bac9E6M7ezHSx2amHxjR4rorzylQFzyaPKUvVl8WUp6GWAOxCukYBQ/eGB+2dNqK5pSndOAAtPwcpKNzDtmo1O9PNZBZQdGm/D5RkGWpd1siKTpAeYwUip9T0WJooidrMNusbeH9igSz1seSl4CeJRY7N/Adymys7ghbyJ47qMMH5ggGbey82NUTyQffPF6PxKMa12sKoXyQ63l0UzEsYlDJd9nAsBSpyZ7uIrQQW9tRk1PL1b2TvCE8Q2YdMN2Tt66TMNBW8arkpvK+/x/plP6JskkgUXMMFZjQlp7tX8614vVzooUgLr5VOeurz95c0ReVjeQIwKuVe5o+B/q2VK5wpMMHKD/I+2xLZC31if0IeByB6mLV0qV9XdA/Aoo8999qnNs0dCs19r6QKxGdYfZCQZmCII2d0tVAZN0CK8coJEfxuomK+2sNLIEXVLN0gloO+AmZK/3I3rBePVSIVSlVrlDKkNoVDiTcA5nvzJRZ+92i3Qx0YBQakqqxaK02vRLN+rUzlzx6XRnzKBuHkR3YsOZN+BhnLQPBqbCq0EfBKGL6bse99B+u5Srzfcho/3IzlSuCf9w==\n"
    ]
    computer_name = "vm-openai-prod-canadacentral-001"
    network_interface_ids = [
      "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadacentral-001/providers/Microsoft.Network/networkInterfaces/vm-openai-prod-canadacentral-001-nic"
    ]
    os_managed_disk_id                                     = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadacentral-001/providers/Microsoft.Compute/disks/vm-openai-prod-canadacentral-001_OsDisk_1_675276b1cc7e4c7a8b6e3c486c65a4e6"
    allow_extension_operations                             = true
    bypass_platform_safety_checks_on_user_schedule_enabled = false
    disk_controller_type                                   = "SCSI"
    encryption_at_host_enabled                             = false
    license_type                                           = "RHEL_BYOS"
    patch_assessment_mode                                  = "AutomaticByPlatform"
    patch_mode                                             = "ImageDefault"
    provision_vm_agent                                     = true
    secure_boot_enabled                                    = false
    vtpm_enabled                                           = false
    additional_capabilities = {
      hibernation_enabled = false
    }
    boot_diagnostics = null
    identity = {
      type                       = "SystemAssigned"
      user_assigned_identity_ids = []
    }
    os_disk = {
      name                 = "vm-openai-prod-canadacentral-001_OsDisk_1_675276b1cc7e4c7a8b6e3c486c65a4e6"
      caching              = "ReadWrite"
      disk_size_gb         = 64
      storage_account_type = "StandardSSD_LRS"
    }
    source_image_reference = {
      publisher = "RedHat"
      offer     = "RHEL"
      sku       = "9_6"
      version   = "Latest"
    }
    tags = {
      CostCenterId = "80045905"
      Environment  = "Prod"
    }
  }
}

linux_virtual_machine_imports = {
  app = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-openai-prod-canadacentral-001"
}

# Created by the platform (Defender/AMA default workspace).
log_analytics_workspace = {
  default_ccan = {
    name                            = "defaultworkspace-ab6893cb-e4ea-447e-a514-0ae1b4929416-cca"
    resource_group_key              = "defaultresourcegroup_cca"
    location                        = "canadacentral"
    sku                             = "PerGB2018"
    retention_in_days               = 30
    daily_quota_gb                  = -1
    internet_ingestion_enabled      = "true"
    internet_query_enabled          = "true"
    local_authentication_enabled    = true
    allow_resource_only_permissions = true
    tags = {
      CostCenterId = "80045905"
      Environment  = "Prod"
    }
  }
}

log_analytics_workspace_imports = {
  default_ccan = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/defaultresourcegroup-cca/providers/Microsoft.OperationalInsights/workspaces/defaultworkspace-ab6893cb-e4ea-447e-a514-0ae1b4929416-cca"
}

network_interface = {
  app_primary = {
    name                           = "vm-openai-prod-canadacentral-001-nic"
    resource_group_key             = "app"
    location                       = "canadacentral"
    enabled                        = true
    accelerated_networking_enabled = false
    ip_forwarding_enabled          = false
    ip_configurations = {
      primary = {
        name                          = "internal"
        primary                       = true
        private_ip_address            = "10.195.14.4"
        private_ip_address_allocation = "Dynamic"
        subnet_id                     = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-prod-canadacentral-001/subnets/snet-openai-prod-mgmt-canadacentral-001"
      }
    }
    tags = {
      CostCenterId = "80045905"
      Environment  = "Prod"
    }
  }
}

# No NIC-level NSGs.
network_interface_nsg_associations = {}

network_watcher = {
  canadacentral = {
    name               = "NetworkWatcher_canadacentral"
    resource_group_key = "networkwatcherrg"
    location           = "canadacentral"
    tags = {
      CostCenterId = "80045905"
      Environment  = "Prod"
    }
  }
}

network_watcher_imports = {
  canadacentral = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/NetworkWatcherRG/providers/Microsoft.Network/networkWatchers/NetworkWatcher_canadacentral"
}

private_endpoint = {
  container_registry = {
    enabled                         = true
    name                            = "pep-acropenaiprodcc001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-prod-canadacentral-001/subnets/snet-openai-prod-pep-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadacentral-001/providers/Microsoft.ContainerRegistry/registries/acropenaiprodcc001"
    private_service_connection_name = "acropenaiprodcc001-psc"
    subresource_names               = ["registry"]
    network_interface_name          = null
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.azurecr.io"
    ]
    ip_configurations = {}
    tags = {
      CostCenterId = "80045905"
      Environment  = "Prod"
    }
  }
  key_vault = {
    enabled                         = true
    name                            = "pep-kvopenaiprodcc001"
    resource_group_key              = "siem"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-prod-canadacentral-001/subnets/snet-openai-prod-pep-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-siem-canadacentral-001/providers/Microsoft.KeyVault/vaults/kvopenaiprodcc001"
    private_service_connection_name = "kvopenaiprodcc001-psc"
    subresource_names               = ["vault"]
    network_interface_name          = null
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.vaultcore.azure.net"
    ]
    ip_configurations = {}
    tags = {
      CostCenterId = "80045905"
      Environment  = "Prod"
    }
  }
  storage_blob = {
    enabled                         = true
    name                            = "pep-blob-stopenaiprodcac001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-prod-canadacentral-001/subnets/snet-openai-prod-pep-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadacentral-001/providers/Microsoft.Storage/storageAccounts/stopenaiprodcac001"
    private_service_connection_name = "stopenaiprodcac001-blob-psc"
    subresource_names               = ["blob"]
    network_interface_name          = null
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net"
    ]
    ip_configurations = {}
    tags = {
      CostCenterId = "80045905"
      Environment  = "Prod"
    }
  }
  storage_queue = {
    enabled                         = true
    name                            = "pep-queue-stopenaiprodcac001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-prod-canadacentral-001/subnets/snet-openai-prod-pep-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadacentral-001/providers/Microsoft.Storage/storageAccounts/stopenaiprodcac001"
    private_service_connection_name = "stopenaiprodcac001-queue-psc"
    subresource_names               = ["queue"]
    network_interface_name          = null
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.queue.core.windows.net"
    ]
    ip_configurations = {}
    tags = {
      CostCenterId = "80045905"
      Environment  = "Prod"
    }
  }
  web_app = {
    enabled                         = true
    name                            = "pep-app-openai-prod-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-prod-canadacentral-001/subnets/snet-openai-prod-pep-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadacentral-001/providers/Microsoft.Web/sites/app-openai-prod-canadacentral-001"
    private_service_connection_name = "app-openai-prod-canadacentral-001-psc"
    subresource_names               = ["sites"]
    network_interface_name          = null
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.azurewebsites.net"
    ]
    ip_configurations = {}
    tags = {
      CostCenterId = "80045905"
      Environment  = "Prod"
    }
  }
  function_app = {
    enabled                         = true
    name                            = "pep-func-openai-prod-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-prod-canadacentral-001/subnets/snet-openai-prod-pep-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadacentral-001/providers/Microsoft.Web/sites/func-openai-prod-canadacentral-001"
    private_service_connection_name = "func-openai-prod-canadacentral-001-psc"
    subresource_names               = ["sites"]
    network_interface_name          = null
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.azurewebsites.net"
    ]
    ip_configurations = {}
    tags = {
      CostCenterId = "80045905"
      Environment  = "Prod"
    }
  }
  postgresql = {
    enabled                         = true
    name                            = "pep-psql-openai-prod-cc-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-prod-canadacentral-001/subnets/snet-openai-prod-pep-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadacentral-001/providers/Microsoft.DBforPostgreSQL/flexibleServers/psql-openai-prod-cc-001"
    private_service_connection_name = "psql-openai-prod-cc-001-psc"
    subresource_names               = ["postgresqlServer"]
    network_interface_name          = null
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.postgres.database.azure.com"
    ]
    ip_configurations = {}
    tags = {
      CostCenterId = "80045905"
      Environment  = "Prod"
    }
  }
  cosmos_db = {
    enabled                         = true
    name                            = "pep-cdb-openai-prod-canadacentral-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-prod-canadacentral-001/subnets/snet-openai-prod-pep-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadacentral-001/providers/Microsoft.DocumentDB/databaseAccounts/cdb-openai-prod-canadacentral-001"
    private_service_connection_name = "cdb-openai-prod-canadacentral-001-psc"
    subresource_names               = ["Sql"]
    network_interface_name          = null
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.documents.azure.com"
    ]
    ip_configurations = {}
    tags = {
      CostCenterId = "80045905"
      Environment  = "Prod"
    }
  }
  document_intelligence = {
    enabled                         = true
    name                            = "pep-doc-openai-prod-cc-001"
    resource_group_key              = "app"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-prod-canadacentral-001/subnets/snet-openai-prod-pep-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadacentral-001/providers/Microsoft.CognitiveServices/accounts/doc-openai-prod-cc-001"
    private_service_connection_name = "doc-openai-prod-cc-001-psc"
    subresource_names               = ["account"]
    network_interface_name          = null
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.cognitiveservices.azure.com"
    ]
    ip_configurations = {}
    tags = {
      CostCenterId = "80045905"
      Environment  = "Prod"
    }
  }
  backup = {
    enabled                         = true
    name                            = "pep-rsv-openai-prod-backup-canadacentral-001"
    resource_group_key              = "network"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-prod-canadacentral-001/subnets/snet-openai-prod-pep-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourcegroups/rg-openai-prod-app-canadacentral-001/providers/Microsoft.RecoveryServices/vaults/rsv-openai-prod-canadacentral-001"
    private_service_connection_name = "pep-rsv-openai-prod-backup-canadacentral-001_54c6523f-50bf-48a9-8d63-39b37f70c09b"
    subresource_names               = ["AzureBackup"]
    network_interface_name          = null
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net",
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.queue.core.windows.net",
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.cnc.backup.windowsazure.com"
    ]
    ip_configurations = {}
    tags = {
      CostCenterId = "80045905"
      Environment  = "Prod"
    }
  }
  openai = {
    enabled                         = true
    name                            = "pep-oai-openai-prod-ce-001"
    resource_group_key              = "app_canadaeast"
    location                        = "canadacentral"
    subnet_resource_id              = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-prod-canadacentral-001/subnets/snet-openai-prod-pep-canadacentral-001"
    private_connection_resource_id  = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadaeast-001/providers/Microsoft.CognitiveServices/accounts/oai-openai-prod-ce-001"
    private_service_connection_name = "oai-openai-prod-ce-001-psc"
    subresource_names               = ["account"]
    network_interface_name          = null
    private_dns_zone_group_name     = "default"
    private_dns_zone_resource_ids = [
      "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-dns-connectivity-canadacentral-001/providers/Microsoft.Network/privateDnsZones/privatelink.openai.azure.com"
    ]
    ip_configurations = {}
    tags = {
      CostCenterId = "80045905"
      Environment  = "Prod"
    }
  }
}

private_endpoint_imports = {
  container_registry    = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-acropenaiprodcc001"
  key_vault             = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-siem-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-kvopenaiprodcc001"
  storage_blob          = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-blob-stopenaiprodcac001"
  storage_queue         = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-queue-stopenaiprodcac001"
  web_app               = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-app-openai-prod-canadacentral-001"
  function_app          = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-func-openai-prod-canadacentral-001"
  postgresql            = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-psql-openai-prod-cc-001"
  cosmos_db             = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-cdb-openai-prod-canadacentral-001"
  document_intelligence = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-doc-openai-prod-cc-001"
  backup                = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-network-canadacentral-001/providers/Microsoft.Network/privateEndpoints/pep-rsv-openai-prod-backup-canadacentral-001"
  openai                = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadaeast-001/providers/Microsoft.Network/privateEndpoints/pep-oai-openai-prod-ce-001"
}

# Managed with azurerm_ssh_public_key directly; the AVM module rejects hyphens.
public_ssh_key = {
  openai_prod_key = {
    name               = "openai-prod-key"
    resource_group_key = "app"
    location           = "canadacentral"
    public_key         = "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQC5V8Ma4pdDCL2m3N4NU2+ScEQTvKc8o5/RV+P7XEpx9NJXkC2XdVhhWyeig5wEcPyOEAyADqtul/6tKV9FmPrgcsIzIzvFFCxR1obsl+kCDB7CnNqVFI/qBJeMlZJOIEsskiEz/uv5V9UGqmMzitQ4qHLkWP25rBiZKJZ6mExKhEIuoyBDMc54/SkeyMVQrGfoIfUCwZlT34V9hCFTqn1bcKkX2adALAz+SjPHKsdbpsU5bSgMpGxjrtNern6WVUsnFv5k6TWqZ92//JkT/m2k8uN5GADqKOYCCsZgm7YkIZOdHnb79NPExYQdogmOklBPf6VF5SectyJWtA07bSFbEOxYDm0i3iX5zq28V+ctMBv/F+n9iH4FyS/N6u+fYIgEeAqRHAmRDgNVQi7WtMdmQusmLzR9Bv+hPg0C7NYoLPDpi2GwYtVTo8KvQT5rka9cmto41Fft91sq8r9AWOe7m7KwMoZ5bFBefFvkZiUrCTyNzEqJGXPxPeWd0c1KpAU= generated-by-azure"
    tags = {
      CostCenterId = "80045905"
      Environment  = "Prod"
    }
  }
  sshkey_openai_prod = {
    name               = "sshkey-openai-prod"
    resource_group_key = "app"
    location           = "canadacentral"
    public_key         = "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQDOprGxfN3YXWlZA+C7r6M4s1ZVLSxdTMmJsN8Iiuxw4giutX5S7F4wseH8YwByX0sxVTlqzzup1GAiErOvYlHF0p6hjvwrNgcTmVA6ZCRZM/mDs24xCcOLOeAvaV/KXq0PTGi7mzwP7freoNII8uJo3JP96lXh27j5avKKcwakF3YxtD2/6GJVhnsDiqW7cioS4/fVjbNO3JeFV29PvS3jVRovMo5h3nocDIaPv6e7YcYz9yh42t5TxgGNCS7wpylYXTXcghdY1D/sD43+eCEKksA5a5RhdeUwoBeKGh+AmzqBcCF9M0piS8U4ck7oqCzc+ouvGaJHJwzMf6iOcIG6DWyJo9nzMvMkGgsuRwKGUMDSYSsjX57YakoIDlERrfe1FH5hFSv60NrX1m4/m2fU8BDddVma+S712M8ZtWY9Tk1v6115qdHJUtXYAgRibuksODTAzlxLYoPbguDlYR2HGdh480fq8F4SunImJzlkMEyO80H3JamihiTZq0x0EDk= generated-by-azure"
    tags = {
      CostCenterId = "80045905"
      Environment  = "Prod"
    }
  }
}

public_ssh_key_imports = {
  openai_prod_key    = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadacentral-001/providers/Microsoft.Compute/sshPublicKeys/openai-prod-key"
  sshkey_openai_prod = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadacentral-001/providers/Microsoft.Compute/sshPublicKeys/sshkey-openai-prod"
}

# monitoringSettings is null on the live vault; alert flags default to false
# so adoption does not switch alerting on.
recovery_services_vault = {
  app = {
    name                          = "rsv-openai-prod-canadacentral-001"
    resource_group_key            = "app"
    location                      = "canadacentral"
    sku                           = "RS0"
    storage_mode_type             = "GeoRedundant"
    cross_region_restore_enabled  = false
    soft_delete_enabled           = true
    immutability                  = "Disabled"
    public_network_access_enabled = false
    tags = {
      CostCenterId = "80045905"
      Environment  = "Prod"
    }
  }
}

recovery_services_vault_imports = {
  app = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadacentral-001/providers/Microsoft.RecoveryServices/vaults/rsv-openai-prod-canadacentral-001"
}

# Azure Backup owns these; only the containers are adopted.
restore_point_collection = {
  app = {
    name                      = "AzureBackup_vm-openai-prod-canadacentral-001_6310774531062826348"
    resource_group_name       = "AzureBackupRG_canadacentral_1"
    location                  = "canadacentral"
    source_virtual_machine_id = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadacentral-001/providers/Microsoft.Compute/virtualMachines/vm-openai-prod-canadacentral-001"
    tags = {
      CostCenterId = "80045905"
      Environment  = "Prod"
    }
  }
}

restore_point_collection_imports = {
  app = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/AzureBackupRG_canadacentral_1/providers/Microsoft.Compute/restorePointCollections/AzureBackup_vm-openai-prod-canadacentral-001_6310774531062826348"
}

# Blob service properties were not exported, so blob_properties stays null.
storage_account = {
  app = {
    name                              = "stopenaiprodcac001"
    resource_group_key                = "app"
    location                          = "canadacentral"
    account_kind                      = "StorageV2"
    account_tier                      = "Standard"
    account_replication_type          = "ZRS"
    access_tier                       = "Hot"
    allow_nested_items_to_be_public   = true
    cross_tenant_replication_enabled  = false
    default_to_oauth_authentication   = true
    https_traffic_only_enabled        = true
    infrastructure_encryption_enabled = false
    is_hns_enabled                    = false
    large_file_share_enabled          = null
    min_tls_version                   = "TLS1_2"
    public_network_access_enabled     = false
    sftp_enabled                      = false
    shared_access_key_enabled         = true
    blob_properties                   = null
    network_rules = {
      bypass                     = ["AzureServices"]
      default_action             = "Deny"
      ip_rules                   = []
      virtual_network_subnet_ids = []
      private_link_access = [
        {
          endpoint_resource_id = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/providers/Microsoft.Security/datascanners/storageDataScanner"
          endpoint_tenant_id   = "8fbb85e8-0cbc-48c3-a2e9-528cef30ec27"
        }
      ]
    }
    tags = {
      CostCenterId = "80045905"
      Environment  = "Prod"
    }
  }
}

storage_account_existing = {}

storage_account_imports = {
  app = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-app-canadacentral-001/providers/Microsoft.Storage/storageAccounts/stopenaiprodcac001"
}

# vnet-openai-prod-canadacentral-001 peerings (unmanaged): RemoteVnetToHubPeering_a8db0ae7-e4bd-4112-a74f-86be5b004e19
# Disabled for now, as in Fit and Fabric: the VNet module's body omits subnets and
# peerings, so the import plan removes them, and the only peering is the vWAN
# hub connection owned by tf-deploy-platform-connectivity. Adopt it with the
# connectivity team on hand to restore the hub connection.
# defaultOutboundAccess is taken from the export where reported, otherwise Azure's
# default (enabled). It is create-time only, so a replace in the plan means the
# value is wrong. The hub peering stays unmanaged.
virtual_network = {
  app = {
    name               = "vnet-openai-prod-canadacentral-001"
    resource_group_key = "network"
    location           = "canadacentral"
    address_space      = ["10.195.12.0/22"]
    ddos_protection_plan = {
      enable = true
      id     = "/subscriptions/f3835bc1-9829-4ac8-9d7a-0999e0b29b90/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/ddosProtectionPlans/ddos-protection-plan"
    }
    subnets = {
      mgmt = {
        name                                          = "snet-openai-prod-mgmt-canadacentral-001"
        address_prefixes                              = ["10.195.14.0/24"]
        default_outbound_access_enabled               = true
        private_endpoint_network_policies             = "Disabled"
        private_link_service_network_policies_enabled = true
        service_endpoint_policies                     = {}
        service_endpoints_with_location               = []
        delegations                                   = []
      }
      pep = {
        name                                          = "snet-openai-prod-pep-canadacentral-001"
        address_prefixes                              = ["10.195.12.0/24"]
        default_outbound_access_enabled               = true
        private_endpoint_network_policies             = "RouteTableEnabled"
        private_link_service_network_policies_enabled = true
        service_endpoint_policies                     = {}
        service_endpoints_with_location = [
          {
            service   = "Microsoft.AzureCosmosDB"
            locations = ["*"]
          }
        ]
        delegations = []
      }
      app = {
        name                                          = "snet-openai-prod-app-canadacentral-001"
        address_prefixes                              = ["10.195.13.0/24"]
        default_outbound_access_enabled               = true
        private_endpoint_network_policies             = "Disabled"
        private_link_service_network_policies_enabled = true
        service_endpoint_policies                     = {}
        service_endpoints_with_location               = []
        delegations = [
          {
            name = "Microsoft.Web/serverFarms"
            service_delegation = {
              name    = "Microsoft.Web/serverFarms"
              actions = ["Microsoft.Network/virtualNetworks/subnets/action"]
            }
          }
        ]
      }
    }
    tags = {
      CostCenterId = "80045905"
      Environment  = "Prod"
    }
  }
}

virtual_network_imports = {
  app = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-prod-canadacentral-001"
}

virtual_network_subnet_imports = {
  app_mgmt = {
    vnet_key   = "app"
    subnet_key = "mgmt"
    id         = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-prod-canadacentral-001/subnets/snet-openai-prod-mgmt-canadacentral-001"
  }
  app_pep = {
    vnet_key   = "app"
    subnet_key = "pep"
    id         = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-prod-canadacentral-001/subnets/snet-openai-prod-pep-canadacentral-001"
  }
  app_app = {
    vnet_key   = "app"
    subnet_key = "app"
    id         = "/subscriptions/ab6893cb-e4ea-447e-a514-0ae1b4929416/resourceGroups/rg-openai-prod-network-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-openai-prod-canadacentral-001/subnets/snet-openai-prod-app-canadacentral-001"
  }
}
