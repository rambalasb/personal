resource "azurerm_virtual_machine_restore_point_collection" "this" {
  for_each = var.enable_restore_point_collection ? var.restore_point_collection : {}

  name                      = each.value.name
  resource_group_name       = each.value.resource_group_name
  location                  = each.value.location
  source_virtual_machine_id = each.value.source_virtual_machine_id
  tags                      = each.value.tags

  lifecycle {
    prevent_destroy = true
  }
}

import {
  for_each = var.enable_restore_point_collection ? var.restore_point_collection_imports : {}

  to = azurerm_virtual_machine_restore_point_collection.this[each.key]
  id = each.value
}
