locals {
  linux_virtual_machine_network_interfaces = {
    for vm_key, vm in var.linux_virtual_machine : vm_key => {
      for nic_key, nic in var.network_interface : nic_key => {
        name                           = nic.name
        resource_group_name            = var.resource_group[nic.resource_group_key].name
        accelerated_networking_enabled = nic.accelerated_networking_enabled
        ip_forwarding_enabled          = nic.ip_forwarding_enabled
        is_primary                     = local.network_interface_resource_ids[nic_key] == vm.network_interface_ids[0]
        inherit_tags                   = false
        tags                           = nic.tags
        network_security_groups        = {}
        ip_configurations = {
          for configuration_key, configuration in nic.ip_configurations : configuration_key => {
            name                          = configuration.name
            is_primary_ipconfiguration    = configuration.primary
            private_ip_address            = configuration.private_ip_address_allocation == "Dynamic" ? null : configuration.private_ip_address
            private_ip_address_allocation = configuration.private_ip_address_allocation
            private_ip_subnet_resource_id = configuration.subnet_id
          }
        }
      } if contains(vm.network_interface_ids, local.network_interface_resource_ids[nic_key])
    }
  }

  linux_virtual_machine_nic_imports = merge({}, [
    for vm_key, vm in var.linux_virtual_machine : {
      for nic_key, nic in local.linux_virtual_machine_network_interfaces[vm_key] : "${vm_key}/${nic_key}" => {
        vm_key  = vm_key
        nic_key = nic_key
        id      = local.network_interface_resource_ids[nic_key]
      }
    }
  ]...)
}

module "linux_virtual_machine" {
  for_each = var.enable_linux_virtual_machine ? var.linux_virtual_machine : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-virtual-machine-linux/azurerm"
  version = "0.0.7"

  name                                                   = each.value.name
  resource_group_name                                    = module.resource_group[each.value.resource_group_key].name
  location                                               = coalesce(each.value.location, module.resource_group[each.value.resource_group_key].location)
  sku_size                                               = each.value.size
  zone                                                   = each.value.zone
  computer_name                                          = each.value.computer_name
  network_interfaces                                     = local.linux_virtual_machine_network_interfaces[each.key]
  allow_extension_operations                             = each.value.allow_extension_operations
  bypass_platform_safety_checks_on_user_schedule_enabled = each.value.bypass_platform_safety_checks_on_user_schedule_enabled
  disk_controller_type                                   = each.value.disk_controller_type
  encryption_at_host_enabled                             = each.value.encryption_at_host_enabled
  license_type                                           = each.value.license_type
  patch_assessment_mode                                  = each.value.patch_assessment_mode
  patch_mode                                             = each.value.patch_mode
  provision_vm_agent                                     = each.value.provision_vm_agent
  secure_boot_enabled                                    = each.value.secure_boot_enabled
  vtpm_enabled                                           = each.value.vtpm_enabled
  vm_additional_capabilities                             = each.value.additional_capabilities
  boot_diagnostics                                       = each.value.boot_diagnostics != null
  boot_diagnostics_storage_account_uri                   = try(each.value.boot_diagnostics.storage_account_uri, null)
  os_disk                                                = each.value.os_disk
  source_image_reference                                 = each.value.source_image_reference
  tags                                                   = each.value.tags

  account_credentials = {
    admin_credentials = {
      username                           = each.value.admin_username
      ssh_keys                           = each.value.admin_ssh_public_keys
      generate_admin_password_or_ssh_key = false
    }
    key_vault_configuration = null
  }

  managed_identities = {
    system_assigned            = contains(["SystemAssigned", "SystemAssigned, UserAssigned"], each.value.identity.type)
    user_assigned_resource_ids = each.value.identity.user_assigned_identity_ids
  }

  # Data disk attachments stay unmanaged; the VM resource does not detach them.
  azure_backup_configurations              = {}
  data_disk_existing_disks                 = {}
  data_disk_managed_disks                  = {}
  diagnostic_settings                      = {}
  extensions                               = {}
  gallery_applications                     = {}
  maintenance_configuration_resource_ids   = {}
  role_assignments                         = {}
  role_assignments_system_managed_identity = {}
  run_commands                             = {}
  run_commands_secrets                     = {}
  secrets                                  = []
  shutdown_schedules                       = {}
  lock                                     = null
  enable_telemetry                         = false
}

import {
  for_each = var.enable_linux_virtual_machine ? var.linux_virtual_machine_imports : {}

  to = module.linux_virtual_machine[each.key].module.linux_vm.azurerm_linux_virtual_machine.this[0]
  id = each.value
}

import {
  for_each = var.enable_linux_virtual_machine ? local.linux_virtual_machine_nic_imports : {}

  to = module.linux_virtual_machine[each.value.vm_key].module.linux_vm.azurerm_network_interface.virtualmachine_network_interfaces[each.value.nic_key]
  id = each.value.id
}
