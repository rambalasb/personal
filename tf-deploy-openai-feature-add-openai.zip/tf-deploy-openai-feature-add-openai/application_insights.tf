module "application_insights" {
  for_each = var.enable_application_insights ? var.application_insights : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-application-insights/azurerm"
  version = "0.1.0"

  name                          = each.value.name
  resource_group_name           = module.resource_group[each.value.resource_group_key].name
  location                      = coalesce(each.value.location, module.resource_group[each.value.resource_group_key].location)
  workspace_id                  = each.value.workspace_id
  application_type              = each.value.application_type
  retention_in_days             = each.value.retention_in_days
  daily_data_cap_in_gb          = each.value.daily_data_cap_in_gb
  sampling_percentage           = each.value.sampling_percentage
  internet_ingestion_enabled    = each.value.internet_ingestion_enabled
  internet_query_enabled        = each.value.internet_query_enabled
  local_authentication_disabled = each.value.local_authentication_disabled
  disable_ip_masking            = each.value.disable_ip_masking
  tags                          = each.value.tags

  role_assignments    = {}
  diagnostic_settings = {}
  lock                = null
  enable_telemetry    = false
}

import {
  for_each = var.enable_application_insights ? var.application_insights_imports : {}

  to = module.application_insights[each.key].module.application_insights.azurerm_application_insights.this
  id = each.value
}
