module "cosmos_db" {
  for_each = var.enable_cosmos_db ? var.cosmos_db : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-cosmos-db/azurerm"
  version = "0.1.0"

  name                                  = each.value.name
  resource_group_name                   = module.resource_group[each.value.resource_group_key].name
  location                              = each.value.location
  access_key_metadata_writes_enabled    = each.value.access_key_metadata_writes_enabled
  analytical_storage_enabled            = each.value.analytical_storage_enabled
  analytical_storage_config             = each.value.analytical_storage_config
  automatic_failover_enabled            = each.value.automatic_failover_enabled
  multiple_write_locations_enabled      = each.value.multiple_write_locations_enabled
  free_tier_enabled                     = each.value.free_tier_enabled
  partition_merge_enabled               = each.value.partition_merge_enabled
  backup                                = each.value.backup
  capabilities                          = each.value.capabilities
  capacity                              = each.value.capacity
  consistency_policy                    = each.value.consistency_policy
  geo_locations                         = each.value.geo_locations
  local_authentication_disabled         = each.value.local_authentication_disabled
  managed_identities                    = each.value.managed_identities
  minimal_tls_version                   = each.value.minimal_tls_version
  network_acl_bypass_for_azure_services = each.value.network_acl_bypass_for_azure_services
  network_acl_bypass_resource_ids       = each.value.network_acl_bypass_resource_ids
  public_network_access_enabled         = each.value.public_network_access_enabled
  virtual_network_rules                 = each.value.virtual_network_rules
  ip_range_filter                       = each.value.ip_range_filter
  tags                                  = each.value.tags

  sql_databases         = {}
  mongo_databases       = {}
  gremlin_databases     = {}
  sql_dedicated_gateway = null
  private_endpoints     = {}
  diagnostic_settings   = {}
  role_assignments      = {}
  customer_managed_key  = null
  cors_rule             = null
  lock                  = null
  enable_telemetry      = false
}

import {
  for_each = var.enable_cosmos_db ? var.cosmos_db : {}

  to = module.cosmos_db[each.key].module.cosmos_db.azurerm_cosmosdb_account.this
  id = "/subscriptions/${var.subscription_id}/resourceGroups/${var.resource_group[each.value.resource_group_key].name}/providers/Microsoft.DocumentDB/databaseAccounts/${each.value.name}"
}