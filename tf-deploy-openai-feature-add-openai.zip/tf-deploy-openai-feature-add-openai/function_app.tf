module "function_app" {
  for_each = var.enable_function_app ? var.function_app : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-function-app/azurerm"
  version = "0.1.2"

  name                                     = each.value.name
  resource_group_name                      = module.resource_group[each.value.resource_group_key].name
  subscription_id                          = var.subscription_id
  location                                 = each.value.location
  service_plan_resource_id                 = each.value.service_plan_resource_id
  os_type                                  = "Linux"
  function_app_uses_fc1                    = false
  builtin_logging_enabled                  = each.value.builtin_logging_enabled
  client_certificate_mode                  = each.value.client_certificate_mode
  ftp_publish_basic_authentication_enabled = each.value.ftp_publish_basic_authentication_enabled
  scm_publish_basic_authentication_enabled = each.value.scm_publish_basic_authentication_enabled
  functions_extension_version              = each.value.functions_extension_version
  https_only                               = each.value.https_only
  key_vault_reference_identity             = each.value.key_vault_reference_identity
  public_network_access_enabled            = each.value.public_network_access_enabled
  vnet_image_pull_enabled                  = each.value.vnet_image_pull_enabled
  hosting_environment_id                   = each.value.hosting_environment_id
  virtual_network_subnet_id                = each.value.virtual_network_subnet_id
  managed_identities                       = each.value.managed_identities
  site_config = merge(each.value.site_config, {
    application_stack = {}
  })
  tags = each.value.tags

  app_settings        = {}
  private_endpoints   = {}
  diagnostic_settings = {}
  deployment_slots    = {}
  backup              = {}
  certificates        = {}
  custom_domains      = {}
  connection_strings  = {}
  logs                = {}
  sticky_settings     = {}
  role_assignments    = {}
  lock                = null
  zip_deploy_file     = null
  enable_telemetry    = false
}

import {
  for_each = var.enable_function_app ? var.function_app : {}

  to = module.function_app[each.key].module.function_app.azapi_resource.this
  id = "/subscriptions/${var.subscription_id}/resourceGroups/${var.resource_group[each.value.resource_group_key].name}/providers/Microsoft.Web/sites/${each.value.name}?api-version=2025-03-01"
}