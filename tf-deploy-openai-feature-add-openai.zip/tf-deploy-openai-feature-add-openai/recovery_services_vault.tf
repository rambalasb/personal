module "recovery_services_vault" {
  for_each = var.enable_recovery_services_vault ? var.recovery_services_vault : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-recovery-services-vault/azurerm"
  version = "0.1.0"

  name                          = each.value.name
  resource_group_name           = module.resource_group[each.value.resource_group_key].name
  location                      = coalesce(each.value.location, module.resource_group[each.value.resource_group_key].location)
  sku                           = each.value.sku
  storage_mode_type             = each.value.storage_mode_type
  cross_region_restore_enabled  = each.value.cross_region_restore_enabled
  soft_delete_enabled           = each.value.soft_delete_enabled
  immutability                  = each.value.immutability
  public_network_access_enabled = each.value.public_network_access_enabled
  tags                          = each.value.tags

  # monitoringSettings is null on the live vaults and the upstream module
  # always writes it, so both default to false: adoption must not switch
  # alerting on. Set true per vault once the portal shows them enabled.
  alerts_for_all_job_failures_enabled            = each.value.alerts_for_all_job_failures_enabled
  alerts_for_critical_operation_failures_enabled = each.value.alerts_for_critical_operation_failures_enabled

  managed_identities  = {}
  private_endpoints   = {}
  role_assignments    = {}
  diagnostic_settings = {}
  lock                = null
  enable_telemetry    = false
}

import {
  for_each = var.enable_recovery_services_vault ? var.recovery_services_vault_imports : {}

  to = module.recovery_services_vault[each.key].module.recovery_services_vault.azapi_resource.this
  id = each.value
}
