module "bastion_host" {
  for_each = var.enable_bastion_host ? var.bastion_host : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-bastion-host/azurerm"
  version = "0.0.1"

  name        = each.value.name
  parent_id   = module.resource_group[each.value.resource_group_key].resource_id
  location    = coalesce(each.value.location, module.resource_group[each.value.resource_group_key].location)
  sku         = each.value.sku
  scale_units = each.value.scale_units
  zones       = each.value.zones
  tags        = each.value.tags

  # Developer attaches to the VNet; other SKUs use a subnet and an existing public IP.
  virtual_network_id = each.value.sku == "Developer" ? each.value.virtual_network_id : null
  ip_configuration = each.value.sku == "Developer" ? null : {
    name                 = each.value.ip_configuration.name
    subnet_id            = each.value.ip_configuration.subnet_id
    create_public_ip     = false
    public_ip_address_id = each.value.ip_configuration.public_ip_address_id
  }

  copy_paste_enabled        = each.value.copy_paste_enabled
  file_copy_enabled         = each.value.file_copy_enabled
  ip_connect_enabled        = each.value.ip_connect_enabled
  kerberos_enabled          = each.value.kerberos_enabled
  shareable_link_enabled    = each.value.shareable_link_enabled
  tunneling_enabled         = each.value.tunneling_enabled
  session_recording_enabled = each.value.session_recording_enabled
  private_only_enabled      = each.value.private_only_enabled

  enable_telemetry = false
}

import {
  for_each = var.enable_bastion_host ? { for k, id in var.bastion_host_imports : k => id if try(var.bastion_host[k].sku, "") == "Developer" } : {}

  to = module.bastion_host[each.key].module.bastion_host.azapi_resource.bastion_developer[0]
  id = "${each.value}?api-version=2024-05-01"
}

import {
  for_each = var.enable_bastion_host ? { for k, id in var.bastion_host_imports : k => id if try(var.bastion_host[k].sku, "Developer") != "Developer" } : {}

  to = module.bastion_host[each.key].module.bastion_host.azapi_resource.bastion[0]
  id = "${each.value}?api-version=2024-05-01"
}
