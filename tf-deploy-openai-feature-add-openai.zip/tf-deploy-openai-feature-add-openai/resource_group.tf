module "resource_group" {
  for_each = var.enable_resource_group ? var.resource_group : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-resource-group/azurerm"
  version = "2.0.0"

  name             = each.value.name
  location         = each.value.location
  lock             = each.value.lock
  managed_by       = each.value.managed_by
  tags             = each.value.tags
  enable_telemetry = false
}

import {
  for_each = var.enable_resource_group ? var.import_resource_group : {}

  to = module.resource_group[each.key].module.resource_group.azapi_resource.this
  id = each.value
}