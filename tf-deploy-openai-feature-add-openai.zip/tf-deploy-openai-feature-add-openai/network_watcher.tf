resource "azurerm_network_watcher" "this" {
  for_each = var.enable_network_watcher ? var.network_watcher : {}

  name                = each.value.name
  resource_group_name = module.resource_group[each.value.resource_group_key].name
  location            = coalesce(each.value.location, module.resource_group[each.value.resource_group_key].location)
  tags                = each.value.tags
}

import {
  for_each = var.enable_network_watcher ? var.network_watcher_imports : {}

  to = azurerm_network_watcher.this[each.key]
  id = each.value
}