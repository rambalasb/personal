module "log_analytics_workspace" {
  for_each = var.enable_log_analytics_workspace ? var.log_analytics_workspace : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-log-analytics-workspace/azurerm"
  version = "0.1.2"

  name                = each.value.name
  resource_group_name = module.resource_group[each.value.resource_group_key].name
  location            = coalesce(each.value.location, module.resource_group[each.value.resource_group_key].location)
  tags                = each.value.tags

  log_analytics_workspace_sku                             = each.value.sku
  log_analytics_workspace_retention_in_days               = each.value.retention_in_days
  log_analytics_workspace_daily_quota_gb                  = each.value.daily_quota_gb
  log_analytics_workspace_internet_ingestion_enabled      = each.value.internet_ingestion_enabled
  log_analytics_workspace_internet_query_enabled          = each.value.internet_query_enabled
  log_analytics_workspace_local_authentication_enabled    = each.value.local_authentication_enabled
  log_analytics_workspace_allow_resource_only_permissions = each.value.allow_resource_only_permissions

  diagnostic_settings = {}
  private_endpoints   = {}
  role_assignments    = {}
  lock                = null
  enable_telemetry    = false
}

import {
  for_each = var.enable_log_analytics_workspace ? var.log_analytics_workspace_imports : {}

  to = module.log_analytics_workspace[each.key].module.log_analytics_workspace.azurerm_log_analytics_workspace.this
  id = each.value
}
