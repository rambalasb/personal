locals {
  network_interface_resource_ids = {
    for nic_key, nic in var.network_interface : nic_key =>
    "/subscriptions/${var.subscription_id}/resourceGroups/${var.resource_group[nic.resource_group_key].name}/providers/Microsoft.Network/networkInterfaces/${nic.name}"
  }
}

# VM NICs are owned by the VM wrapper; private endpoint NICs by their
# endpoint. Only the NSG association is managed here.
resource "azurerm_network_interface_security_group_association" "this" {
  for_each = var.enable_network_interface ? { for nic_key, nsg_id in var.network_interface_nsg_associations : nic_key => nsg_id if try(var.network_interface[nic_key].enabled, false) } : {}

  network_interface_id      = local.network_interface_resource_ids[each.key]
  network_security_group_id = each.value

  depends_on = [module.linux_virtual_machine]
}

import {
  for_each = var.enable_network_interface ? { for nic_key, nsg_id in var.network_interface_nsg_associations : nic_key => nsg_id if try(var.network_interface[nic_key].enabled, false) } : {}

  to = azurerm_network_interface_security_group_association.this[each.key]
  id = "${local.network_interface_resource_ids[each.key]}|${each.value}"
}
