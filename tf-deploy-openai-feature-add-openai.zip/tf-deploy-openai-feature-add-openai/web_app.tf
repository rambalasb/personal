module "web_app" {
  for_each = var.enable_web_app ? var.web_app : {}
  source   = "app.terraform.io/BC_Hydro/tf-wrapper-avm-web-app/azurerm"
  version  = "0.0.5"

  name                                     = each.value.name
  resource_group_name                      = module.resource_group[each.value.resource_group_key].name
  subscription_id                          = var.subscription_id
  location                                 = each.value.location
  service_plan_resource_id                 = each.value.service_plan_resource_id
  os_type                                  = "Linux"
  client_affinity_enabled                  = each.value.client_affinity_enabled
  ftp_publish_basic_authentication_enabled = each.value.ftp_publish_basic_authentication_enabled
  https_only                               = each.value.https_only
  key_vault_reference_identity             = each.value.key_vault_reference_identity
  public_network_access_enabled            = each.value.public_network_access_enabled
  virtual_network_subnet_id                = each.value.virtual_network_subnet_id
  vnet_image_pull_enabled                  = each.value.vnet_image_pull_enabled
  scm_publish_basic_authentication_enabled = each.value.scm_publish_basic_authentication_enabled
  managed_identities                       = each.value.managed_identities
  site_config = {
    container_registry_use_managed_identity = each.value.site_config.container_registry_use_managed_identity
    default_documents                       = each.value.site_config.default_documents
    remote_debugging_version                = each.value.site_config.remote_debugging_version
    use_32_bit_worker                       = each.value.site_config.use_32_bit_worker
    vnet_route_all_enabled                  = each.value.site_config.vnet_route_all_enabled
    worker_count                            = each.value.site_config.worker_count
    linux_fx_version                        = "DOCKER|${each.value.site_config.application_stack.docker_image_name}"
    application_stack                       = {}
  }
  tags = each.value.tags

  app_settings        = {}
  private_endpoints   = {}
  diagnostic_settings = {}
  deployment_slots    = {}
  backup              = {}
  certificates        = {}
  custom_domains      = {}
  connection_strings  = {}
  sticky_settings     = {}
  logs                = {}
  role_assignments    = {}
  lock                = null
  zip_deploy_file     = null
  enable_telemetry    = false
}

import {
  for_each = var.enable_web_app ? var.web_app : {}

  to = module.web_app[each.key].module.web_app.azapi_resource.this
  id = "/subscriptions/${var.subscription_id}/resourceGroups/${var.resource_group[each.value.resource_group_key].name}/providers/Microsoft.Web/sites/${each.value.name}?api-version=2025-03-01"
}