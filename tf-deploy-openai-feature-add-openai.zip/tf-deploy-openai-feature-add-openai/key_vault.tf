module "key_vault" {
  for_each = var.enable_key_vault ? var.key_vault : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-key-vault/azurerm"
  version = "0.4.0"

  name                = each.value.name
  resource_group_name = module.resource_group[each.value.resource_group_key].name
  location            = coalesce(each.value.location, module.resource_group[each.value.resource_group_key].location)
  tenant_id           = each.value.tenant_id

  sku_name                        = each.value.sku_name
  enabled_for_deployment          = each.value.enabled_for_deployment
  enabled_for_disk_encryption     = each.value.enabled_for_disk_encryption
  enabled_for_template_deployment = each.value.enabled_for_template_deployment
  legacy_access_policies_enabled  = each.value.legacy_access_policies_enabled
  public_network_access_enabled   = each.value.public_network_access_enabled
  purge_protection_enabled        = each.value.purge_protection_enabled
  soft_delete_retention_days      = each.value.soft_delete_retention_days
  network_acls                    = each.value.network_acls
  tags                            = each.value.tags

  contacts               = {}
  diagnostic_settings    = {}
  keys                   = {}
  secrets                = {}
  secrets_value          = null
  legacy_access_policies = {}
  private_endpoints      = {}
  role_assignments       = {}
  lock                   = null
  enable_telemetry       = false
  wrapper_tags_enabled   = false
}

import {
  for_each = var.enable_key_vault ? var.key_vault_imports : {}

  to = module.key_vault[each.key].module.key_vault.azurerm_key_vault.this
  id = each.value
}