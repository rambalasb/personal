module "postgresql_flexible_server" {
  for_each = var.enable_postgresql_flexible_server ? var.postgresql_flexible_server : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-postgresql-flexible-server/azurerm"
  version = "0.0.1"

  name                          = each.value.name
  resource_group_name           = module.resource_group[each.value.resource_group_key].name
  location                      = each.value.location
  administrator_login           = each.value.administrator_login
  auto_grow_enabled             = each.value.auto_grow_enabled
  backup_retention_days         = each.value.backup_retention_days
  public_network_access_enabled = each.value.public_network_access_enabled
  sku_name                      = each.value.sku_name
  storage_mb                    = each.value.storage_mb
  storage_tier                  = each.value.storage_tier
  server_version                = each.value.server_version
  zone                          = each.value.zone
  authentication                = each.value.authentication
  high_availability             = each.value.high_availability
  maintenance_window            = each.value.maintenance_window
  geo_redundant_backup_enabled  = each.value.geo_redundant_backup_enabled
  delegated_subnet_id           = each.value.delegated_subnet_id
  private_dns_zone_id           = each.value.private_dns_zone_id
  tags                          = each.value.tags

  administrator_password            = null
  administrator_password_wo         = null
  administrator_password_wo_version = null
  create_mode                       = null
  source_server_id                  = null
  point_in_time_restore_time_in_utc = null
  replication_role                  = null
  customer_managed_key              = null
  managed_identities                = {}
  ad_administrator                  = {}
  databases                         = {}
  firewall_rules                    = {}
  server_configuration              = {}
  virtual_endpoint                  = {}
  private_endpoints                 = {}
  diagnostic_settings               = {}
  role_assignments                  = {}
  lock                              = null
  enable_telemetry                  = false
}

import {
  for_each = var.enable_postgresql_flexible_server ? var.postgresql_flexible_server : {}

  to = module.postgresql_flexible_server[each.key].module.postgresql_flexible_server.azurerm_postgresql_flexible_server.this
  id = "/subscriptions/${var.subscription_id}/resourceGroups/${var.resource_group[each.value.resource_group_key].name}/providers/Microsoft.DBforPostgreSQL/flexibleServers/${each.value.name}"
}