module "app_service_plan" {
  for_each = var.enable_app_service_plan ? var.app_service_plan : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-app-service-plan/azurerm"
  version = "0.1.0"

  name                            = each.value.name
  subscription_id                 = var.subscription_id
  resource_group_name             = module.resource_group[each.value.resource_group_key].name
  location                        = coalesce(each.value.location, module.resource_group[each.value.resource_group_key].location)
  os_type                         = each.value.os_type
  sku_name                        = each.value.sku_name
  worker_count                    = each.value.worker_count
  maximum_elastic_worker_count    = each.value.maximum_elastic_worker_count
  per_site_scaling_enabled        = each.value.per_site_scaling_enabled
  premium_plan_auto_scale_enabled = each.value.premium_plan_auto_scale_enabled
  zone_balancing_enabled          = each.value.zone_balancing_enabled
  app_service_environment_id      = each.value.app_service_environment_id
  tags                            = each.value.tags

  role_assignments    = {}
  diagnostic_settings = {}
  lock                = null
  enable_telemetry    = false
}

import {
  for_each = var.enable_app_service_plan ? var.app_service_plan_imports : {}

  to = module.app_service_plan[each.key].module.app_service_plan.azapi_resource.this
  id = replace(each.value, "providers/Microsoft.Web/serverFarms/", "providers/Microsoft.Web/serverfarms/")
}
