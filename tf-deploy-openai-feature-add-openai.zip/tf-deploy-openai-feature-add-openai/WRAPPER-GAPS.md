# Wrapper gaps: `tf-deploy-app-openai`

Resources in the OpenAI subscriptions that this repo does not manage. Counts
are from the Azure resource export of 2026-11-03.

## Staged

Code and tfvars are complete; each is switched off and adopted in its own
run. See "Staged adoption" in the README.

| Resource | Environment | Reason |
|---|---|---|
| `vm-openai-<env>-canadacentral-001` (+ NIC) | both | Image `RedHat/RHEL/9_6` is not on the Linux wrapper's grandfathered list |
| `vnet-openai-<env>-canadacentral-001` (+ 3 subnets) | both | vWAN hub connection owned by the connectivity repo |
| `app-openai-nonprod-canadacentral-001` | nonprod | Every apply rewrites the full app settings; settings and Linux container `site_config` not verified |
| `psql-`, `cdb-`, `app-`, `func-openai-prod-*` | prod | Code is in place; prod tfvars not filled in yet |

## Needs a tier

| Resource | Reason |
|---|---|
| `oai-openai-<env>-ce-001` (Azure OpenAI, Canada East), `doc-openai-<env>-cc-001` (Document Intelligence) | `tf-wrapper-avm-cognitive-services-account` is built but not yet used by any deploy repo. Pin it once published; import target `.module.cognitive_services_account.azapi_resource.this`. Model deployments must be modelled too, or adoption removes them |

## Not managed

| Type | Nonprod | Prod | Reason |
|---|---:|---:|---|
| `microsoft.insights/activitylogalerts` | 4 | 2 | `status` uses `containsAny`; the wrapper's single `status` writes `equals`, so adoption would rewrite the condition |
| `microsoft.alertsmanagement/actionrules` | 0 | 3 | Spaces in their names, which AzureRM rejects; rename them in Azure to manage them |
| `microsoft.alertsmanagement/smartdetectoralertrules` | 1 | 1 | App Insights failure anomalies; created by Azure |
| `microsoft.insights/actiongroups` | 1 | 1 | App Insights smart detection group; created by Azure |
| `microsoft.network/networkinterfaces` | 12 | 12 | PE NICs belong to their endpoint; the VM NIC goes with the VM (staged) |
| `microsoft.compute/virtualmachines/extensions` | 5 | 5 | VM wrapper is called with `extensions = {}` |
| `microsoft.compute/virtualmachines/runcommands` | 0 | 3 | Ad hoc run commands |
| `microsoft.compute/disks` | 1 | 1 | OS disk is owned inline by its VM |
| `microsoft.insights/datacollectionrules` | 0 | 3 | `tf-wrapper-avm-data-collection-stack` needs stream/destination modelling |
| `microsoft.insights/datacollectionendpoints` | 0 | 1 | Belongs to the default Azure Monitor workspace |
| `microsoft.monitor/accounts` | 0 | 1 | Platform default Azure Monitor workspace |
| `microsoft.network/virtualnetworks` peerings | 1 | 1 | Hub peering is owned by the connectivity repo |
| `AzureBackupRG_canadacentral_1` | 1 | 1 | `managedBy` Azure Backup; ARM rejects a PUT that drops it |
| `MA_defaultazuremonitorworkspace-cca_canadacentral_managed` | 0 | 1 | `managedBy` the Azure Monitor workspace |
