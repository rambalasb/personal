module "private_endpoint" {
  for_each = var.enable_private_endpoint ? { for endpoint_key, endpoint in var.private_endpoint : endpoint_key => endpoint if endpoint.enabled } : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-private-endpoint/azurerm"
  version = "0.1.2"

  name                            = each.value.name
  resource_group_name             = module.resource_group[each.value.resource_group_key].name
  location                        = coalesce(each.value.location, module.resource_group[each.value.resource_group_key].location)
  subnet_resource_id              = each.value.subnet_resource_id
  private_connection_resource_id  = each.value.private_connection_resource_id
  private_service_connection_name = each.value.private_service_connection_name
  subresource_names               = each.value.subresource_names
  network_interface_name          = each.value.network_interface_name
  private_dns_zone_group_name     = each.value.private_dns_zone_group_name
  private_dns_zone_resource_ids   = each.value.private_dns_zone_resource_ids
  ip_configurations               = each.value.ip_configurations
  tags                            = each.value.tags

  enable_telemetry = false
}

import {
  for_each = var.enable_private_endpoint ? { for endpoint_key, resource_id in var.private_endpoint_imports : endpoint_key => resource_id if try(var.private_endpoint[endpoint_key].enabled, false) } : {}

  to = module.private_endpoint[each.key].module.private_endpoint.azurerm_private_endpoint.this
  id = each.value
}