# Direct AzureRM: the upstream AVM module only accepts lowercase alphanumeric
# names, which rejects the existing key.
resource "azurerm_ssh_public_key" "this" {
  for_each = var.enable_public_ssh_key ? var.public_ssh_key : {}

  name                = each.value.name
  resource_group_name = module.resource_group[each.value.resource_group_key].name
  location            = coalesce(each.value.location, module.resource_group[each.value.resource_group_key].location)
  public_key          = each.value.public_key
  tags                = each.value.tags

  lifecycle {
    prevent_destroy = true
  }
}

import {
  for_each = var.enable_public_ssh_key ? var.public_ssh_key_imports : {}

  to = azurerm_ssh_public_key.this[each.key]
  id = each.value
}
