resource "azurerm_storage_account" "this" {
  for_each = var.enable_storage_account ? var.storage_account : {}

  name                              = each.value.name
  resource_group_name               = module.resource_group[each.value.resource_group_key].name
  location                          = coalesce(each.value.location, module.resource_group[each.value.resource_group_key].location)
  account_kind                      = each.value.account_kind
  account_tier                      = each.value.account_tier
  account_replication_type          = each.value.account_replication_type
  access_tier                       = each.value.access_tier
  allow_nested_items_to_be_public   = each.value.allow_nested_items_to_be_public
  cross_tenant_replication_enabled  = each.value.cross_tenant_replication_enabled
  default_to_oauth_authentication   = each.value.default_to_oauth_authentication
  https_traffic_only_enabled        = each.value.https_traffic_only_enabled
  infrastructure_encryption_enabled = each.value.infrastructure_encryption_enabled
  is_hns_enabled                    = each.value.is_hns_enabled
  large_file_share_enabled          = each.value.large_file_share_enabled
  min_tls_version                   = each.value.min_tls_version
  public_network_access_enabled     = each.value.public_network_access_enabled
  sftp_enabled                      = each.value.sftp_enabled
  shared_access_key_enabled         = each.value.shared_access_key_enabled
  tags                              = each.value.tags

  # Blob service properties were not exported; the block stays out until they are.
  dynamic "blob_properties" {
    for_each = each.value.blob_properties == null ? [] : [each.value.blob_properties]
    content {
      container_delete_retention_policy {
        days = blob_properties.value.container_delete_retention_policy.days
      }
      delete_retention_policy {
        days = blob_properties.value.delete_retention_policy.days
      }
    }
  }

  network_rules {
    bypass                     = each.value.network_rules.bypass
    default_action             = each.value.network_rules.default_action
    ip_rules                   = each.value.network_rules.ip_rules
    virtual_network_subnet_ids = each.value.network_rules.virtual_network_subnet_ids

    dynamic "private_link_access" {
      for_each = each.value.network_rules.private_link_access
      content {
        endpoint_resource_id = private_link_access.value.endpoint_resource_id
        endpoint_tenant_id   = private_link_access.value.endpoint_tenant_id
      }
    }
  }

  lifecycle {
    prevent_destroy = true
  }
}

import {
  for_each = var.enable_storage_account ? var.storage_account_imports : {}

  to = azurerm_storage_account.this[each.key]
  id = each.value
}

# Read-only: Deny_Public_Access_On_PaaS_Services_v0 denies any write to an
# account with public network access enabled. Move to storage_account once
# the account is exempted. AzAPI rather than azurerm so the access keys stay
# out of state.
data "azapi_resource" "storage_account_existing" {
  for_each = var.storage_account_existing

  type      = "Microsoft.Storage/storageAccounts@2025-08-01"
  name      = each.value.name
  parent_id = "/subscriptions/${var.subscription_id}/resourceGroups/${var.resource_group[each.value.resource_group_key].name}"
}
