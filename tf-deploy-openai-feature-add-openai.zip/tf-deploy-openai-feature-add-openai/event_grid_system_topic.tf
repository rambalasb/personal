resource "azurerm_eventgrid_system_topic" "this" {
  for_each = var.enable_event_grid_system_topic ? var.event_grid_system_topic : {}

  name                = each.value.name
  resource_group_name = module.resource_group[each.value.resource_group_key].name
  location            = coalesce(each.value.location, module.resource_group[each.value.resource_group_key].location)
  source_resource_id  = each.value.source_resource_id
  topic_type          = each.value.topic_type
  tags                = each.value.tags

  lifecycle {
    prevent_destroy = true

    postcondition {
      condition     = lower(self.source_resource_id) == lower(each.value.exported_source_resource_id)
      error_message = "The imported system topic must retain its exported source resource ID."
    }
  }
}

import {
  for_each = var.enable_event_grid_system_topic ? var.event_grid_system_topic_imports : {}

  to = azurerm_eventgrid_system_topic.this[each.key]
  id = each.value
}