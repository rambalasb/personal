# Module gaps: `tf-deploy-platform-firewall-management`

Unresolved AVM and provider limitations affecting resources this deployment
manages. Versions in brackets are what the configuration pins.

**No gap here is currently waived.** A waiver is an `--allow-resource` flag
passed to `scripts/verify_zero_diff.sh` from the pipelines, and the bar for
taking one is that nothing can remove the diff: no tfvars value and no
published module version. Nothing in this repo has been applied yet, so no
gap has had the chance to earn one.

Distinct from `HANDOVER.md`, which lists what Terraform does not own at all:
everything here **is** managed, except where a row says the module cannot
express it — those rows say so explicitly and appear in `HANDOVER.md` too.

All three module versions were confirmed against the private registry listing
on 2026-09-09 and are the latest published: `tf-wrapper-avm-azure-firewall`
0.1.0, `tf-wrapper-avm-azure-firewall-policy` 0.1.0, `tf-wrapper-avm-ip-group`
0.1.0.

| Module / provider | Version | Issue | Why it is unresolved | How it is handled |
|---|---|---|---|---|
| tf-wrapper-avm-azure-firewall-policy | 0.1.0 | **Resolved in 0.1.1.** The wrapper did not expose rule collection groups, so the tier could not be built from it. The upstream AVM module does ship them, as the `rule_collection_groups` submodule — the gap was the wrapper's, not AVM's. | — | The wrapper now instantiates that submodule per group as `module.rule_collection_group`, wiring `firewall_policy_id` from the policy it owns. `firewall.tf` passes each policy its own groups, filtered from the flat `local.firewall_rule_collection_groups` map so the `"<policy>/<group>"` keys are unchanged. No native resource remains in this tier. |
| hashicorp/azurerm | >= 4.37 | A rule collection with zero rules cannot be represented. `network_rule_collection` and `application_rule_collection` both require at least one `rule` block, and the API accepts a collection with none. | Provider schema. No configuration expresses it, and the wrapper is not involved. | Five live collections are omitted rather than misrepresented; `HANDOVER.md` lists them with group, priority and action. **Four are Allow collections with no rules, so omitting them changes no traffic decision** — an empty Allow permits nothing — and the fifth is a Deny that denies nothing. Deleting them in Azure would make the configuration exact. The wrapper carries a `rule_collections_not_empty` check, which explains the cause as a warning; the run still fails on the provider's own error, because `check` blocks are advisory and never block a plan. Making it block would mean a variable `validation` instead. |
| tf-wrapper-avm-azure-firewall | 0.1.0 | The module has no input for classic inline `networkRuleCollections` — the pre-policy rule model, set directly on the firewall resource. | Deliberate upstream omission: AVM models rules through a policy. The classic form is legacy and not exposed. | `azfw-transit-connectivity-canadacentral-001` carries one such collection live (`rc-allow-ns2-to-bch`). It is declared natively as `azurerm_firewall_network_rule_collection` in `classic_rules.tf`, outside the wrapper. Migrating the transit firewall onto a policy would retire that file. |
| tf-wrapper-avm-azure-firewall / -policy / tf-wrapper-avm-ip-group | 0.1.0 | **Resolved.** The internal addresses the `import{}` blocks target are now read from source, not inferred. `terraform init` names the inner modules (`firewall.azure_firewall`, `firewall_policy.firewall_policy`, `ip_group.ip_group`) and the AVM modules declare the leaves: `azurerm_firewall.this` (avm-res-network-azurefirewall 0.4.0), `azurerm_firewall_policy.this` (avm-res-network-firewallpolicy 0.3.4), and `azapi_resource.this` (avm-res-network-ipgroup 0.2.0 — azapi, not `azurerm_ip_group`). | The firewall and policy addresses were already correct; all 89 IP-group blocks were wrong and are fixed. | A wrong address fails `terraform validate` with "Resource <address> not found" and **does not name the right one**, so guessing costs a round trip per attempt. Re-read the leaves from `.terraform/modules` if a wrapper bumps its AVM version. Confirmed by the 2026-09-28 plan, which resolved all 198. The 8 diagnostic settings target `azurerm_monitor_diagnostic_setting.this[<key>]` in the same firewall module. |
| tf-wrapper-avm-ip-group | 0.1.0 | `ip_addresses` is typed `set(string)`, so Terraform sorts and deduplicates it. Azure keeps the order it was given, duplicates included, so 21 groups plan a rewrite with unchanged membership. | A wrapper type choice; making it a `list` would move the ordering burden onto every tfvars entry. | One apply converges it; listed in `HANDOVER.md` under known plan diffs. Separately, azapi records the latest API version on import; the import IDs pin `?api-version=2024-05-01` so `type` does not diff. Re-pin both if the wrapper's AVM version changes its API version. |
