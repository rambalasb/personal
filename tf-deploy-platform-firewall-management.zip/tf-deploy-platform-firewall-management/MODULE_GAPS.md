# Module gaps: `tf-deploy-platform-firewall-management`

Unresolved AVM and provider limitations affecting resources this deployment
manages. Versions in brackets are what the configuration pins.

**No gap here is currently waived.** A waiver is an `--allow-resource` flag
passed to `scripts/verify_zero_diff.sh` from the pipelines, and the bar for
taking one is that nothing can remove the diff: no tfvars value and no
published module version. Nothing in this repo has been applied yet, so no
gap has had the chance to earn one.

Distinct from `HANDOVER.md`, which lists what Terraform does not own at all:
everything here **is** managed, except where a row says the module cannot
express it — those rows say so explicitly and appear in `HANDOVER.md` too.

All three module versions were confirmed against the private registry listing
on 2026-09-09 and are the latest published: `tf-wrapper-avm-azure-firewall`
0.1.0, `tf-wrapper-avm-azure-firewall-policy` 0.1.0, `tf-wrapper-avm-ip-group`
0.1.0.

| Module / provider | Version | Issue | Why it is unresolved | How it is handled |
|---|---|---|---|---|
| tf-wrapper-avm-azure-firewall-policy | 0.1.0 | The wrapper does not expose rule collection groups. A policy's rules are the reviewable unit in this repo, so the tier cannot be built from the wrapper alone. | Wrapper scope. The upstream AVM policy module has the same shape: policy attributes only. | All 17 groups are declared natively as `azurerm_firewall_policy_rule_collection_group` in `firewall.tf`, keyed `"<policy>/<group>"`. The policies themselves still go through the wrapper, so only the rules bypass it. |
| hashicorp/azurerm | >= 4.37 | A rule collection with zero rules cannot be represented. `network_rule_collection` and `application_rule_collection` both require at least one `rule` block, and the API accepts a collection with none. | Provider schema. No configuration expresses it, and the wrapper is not involved. | Two live collections are omitted rather than misrepresented: `rc-allow-sap-aem-inbound` (Allow, priority 2520) on `azfwpol-connectivity-001/rcg-1000-spoke-specific-canada-central`, and `rc-allow-net-fit-to-esb-nonprod` (Allow, priority 41100) on the backup policy's `rcg-41000-spokes-to-onprem`. **Both are Allow collections with no rules, so omitting them changes no traffic decision** — an empty Allow permits nothing. They are listed in `HANDOVER.md` §3 as unmanaged, and deleting either in Azure would make the configuration exact. |
| tf-wrapper-avm-azure-firewall | 0.1.0 | The module has no input for classic inline `networkRuleCollections` — the pre-policy rule model, set directly on the firewall resource. | Deliberate upstream omission: AVM models rules through a policy. The classic form is legacy and not exposed. | `azfw-transit-connectivity-canadacentral-001` carries one such collection live (`rc-allow-ns2-to-bch`). Its firewall resource is managed; that collection is not, and is recorded in `HANDOVER.md` §3. The resolution is to migrate the transit firewall onto a policy, which is a change to the estate and not something this adoption should make on its way in. |
| tf-wrapper-avm-azure-firewall / -policy / tf-wrapper-avm-ip-group | 0.1.0 | The internal resource addresses the `import{}` blocks target (`module.firewall["x"].module.azure_firewall.azurerm_firewall.this`) are best-guess, inferred from the wrapper naming convention rather than read from the module source. | The registry listing confirms the version but not the module's internal structure, which needs the source. | `imports_firewall.tf` says so in its header. A wrong address is a hard plan error that prints the correct one, so the first speculative plan resolves all 22 in one pass — it is a build-time correction, not a live risk. The 89 IP-group imports carry the same caveat. |
