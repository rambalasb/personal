output "firewall_ids" {
  description = "Resource IDs of the Azure Firewalls, by name."
  value       = { for k, m in module.firewall : k => m.resource_id }
}

output "firewall_policy_ids" {
  description = "Resource IDs of the firewall policies, by name."
  value       = { for k, m in module.firewall_policy : k => m.resource_id }
}

output "ip_group_ids" {
  description = "Resource IDs of the IP groups, by name. Consumed by the policy rule collections in this repo."
  value       = { for k, m in module.ip_group : k => m.resource_id }
}
