# =====================================================================
# Firewall management for the connectivity subscription
# (f3835bc1-9829-4ac8-9d7a-0999e0b29b90).
#
# Resource groups are NOT managed here. az-sub-connectivity-lz owns all 12;
# this repo reads the four it needs through data sources in data.tf, so the
# two workspaces can never both plan a change to the same resource group.
# =====================================================================

variable "subscription_id" {
  type        = string
  description = "Connectivity subscription the firewall estate lives in."
}

variable "environment" {
  type    = string
  default = "prod"
}

variable "tags" {
  type    = map(string)
  default = {}
}

# --- Resource groups read from the connectivity workspace ---------------
# Names, not IDs: the data sources resolve them against var.subscription_id.

variable "hub_cc_resource_group_name" {
  type        = string
  description = "Hub RG, canadacentral. Holds azfw-connectivity-canadacentral-001 and both firewall policies."
  default     = "rg-hub-connectivity-canadacentral-001"
}

variable "hub_ce_resource_group_name" {
  type        = string
  description = "Hub RG, canadaeast. Holds azfw-connectivity-canadaeast-001."
  default     = "rg-hub-connectivity-canadaeast-001"
}

variable "shared_cc_resource_group_name" {
  type        = string
  description = "Shared RG, canadacentral. Holds the VNet-based transit firewall."
  default     = "rg-shared-connectivity-canadacentral-001"
}

variable "ip_groups_resource_group_name" {
  type        = string
  description = "Global RG holding the 89 IP groups the policy rules resolve against."
  default     = "rg-ip-groups-connectivity-global"
}

# --- Cross-subscription references --------------------------------------

variable "firewall_insights_workspace_id" {
  type        = string
  description = "Log Analytics workspace the policy writes insights to. Lives in the security subscription."
}

variable "firewall_uami_id" {
  type        = string
  description = "UserAssigned identity the connectivity policy uses to read the TLS certificate. Lives in the identity subscription."
}

variable "firewall_tls_certificate" {
  type = object({
    name                = string
    key_vault_secret_id = string
  })
  description = "TLS inspection certificate for azfwpol-connectivity-001. The key vault is managed by identity-lz."
  default     = null
}
