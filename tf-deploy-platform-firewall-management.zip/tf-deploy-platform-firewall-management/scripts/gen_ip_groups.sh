#!/usr/bin/env bash
# Regenerate the ip_groups tfvars block and its import blocks from Azure.
#
# firewall.tfvars declares every IP group in the resource group. Every
# group that is not declared is invisible to a plan -- `for_each` skips it, so
# an apply neither reports it nor touches it. This reads the live groups and
# emits the two files needed to bring them under management.
#
# `az resource list` is not enough input here: it returns properties as null,
# so it carries the names but not the members, and an ip_group without
# ip_addresses cannot be described.
#
# Usage:
#   az network ip-group list -g rg-ip-groups-connectivity-global -o json > ipg.json
#   gen_ip_groups.sh ipg.json [--tfvars FILE] [--out DIR]
#
# --tfvars  the tfvars to read currently-declared names from.
#           Default ./firewall.tfvars
# --out     directory for the generated files. Default ./generated
# --inner   the address of the resource inside the wrapper, relative to
#           module.ip_group["<name>"]. Defaults to the verified address for
#           Azure/avm-res-network-ipgroup 0.2.0, which uses azapi rather than
#           azurerm_ip_group. Re-read it if the wrapper bumps that version:
#             find .terraform/modules -path '*ipgroup*' -name '*.tf' \
#               | xargs grep -n '^resource "'
#           A wrong address fails `terraform validate` without naming the right
#           one, so it costs a round trip each time.
#
# Writes three files:
#   ip_groups.tfvars.txt   the complete ip_groups block, all groups, sorted.
#                          Replaces the existing block; it is not a fragment to
#                          append, because a duplicate key is a hard error.
#   ip_groups.imports.txt  import blocks for the undeclared groups only.
#                          Append to pending_imports_ip_groups.tf; do not overwrite it,
#                          which would drop the blocks already there.
#   drift.txt              declared groups whose members no longer match Azure.
#
# Nothing is edited in place. Review, then move the files into position.

set -euo pipefail

die() { echo "error: $*" >&2; exit 2; }

[ $# -ge 1 ] || die "usage: gen_ip_groups.sh ipg.json [--tfvars FILE] [--out DIR]"

src="$1"; shift
tfvars="./firewall.tfvars"
out="./generated"
inner="module.ip_group.azapi_resource.this"

while [ $# -gt 0 ]; do
  case "$1" in
    --tfvars) tfvars="${2:-}"; [ -n "$tfvars" ] || die "--tfvars needs a value"; shift 2 ;;
    --out)    out="${2:-}";    [ -n "$out" ]    || die "--out needs a value";    shift 2 ;;
    --inner)  inner="${2:-}";  [ -n "$inner" ]  || die "--inner needs a value";  shift 2 ;;
    *) die "unknown argument: $1" ;;
  esac
done

[ -f "$src" ]    || die "no such file: $src"
[ -f "$tfvars" ] || die "no such file: $tfvars"
command -v jq >/dev/null || die "jq not found"

mkdir -p "$out"

# Names the tfvars already declares. The block is one entry per line, so a line
# parse is enough -- a general HCL parse would need a real parser for no gain.
sed -n '/^ip_groups = {/,/^}/p' "$tfvars" \
  | grep -oE '^[[:space:]]+"[^"]+"' \
  | tr -d ' "' \
  | sort > "$out/.declared"

jq -r '.[].name' "$src" | sort > "$out/.live"

declared=$(grep -c . "$out/.declared" || true)
live=$(grep -c . "$out/.live" || true)

# The full block. Emitted whole rather than as a delta: the generated file is
# the one that gets committed, so it has to stand on its own.
{
  echo "ip_groups = {"
  # az network flattens properties onto the object; a raw ARM response does
  # not. Accept both shapes.
  jq -r '
    sort_by(.name)[]
    | "  \"\(.name)\" = { location = \"\(.location)\", ip_addresses = ["
      + ((.ipAddresses // .properties.ipAddresses // []) | map("\"" + . + "\"") | join(", "))
      + "] }"
  ' "$src"
  echo "}"
} > "$out/ip_groups.tfvars.txt"

# Import blocks for the undeclared groups. The inner address is not verifiable
# from this repo -- the AVM module it points into is fetched at init.
{
  echo "# Generated fragment -- import blocks for groups not previously declared."
  echo "# Append to pending_imports_ip_groups.tf. Inner address: $inner"
  echo
  comm -13 "$out/.declared" "$out/.live" | while IFS= read -r name; do
    [ -n "$name" ] || continue
    printf 'import {\n'
    printf '  to = module.ip_group["%s"].%s\n' "$name" "$inner"
    printf '  id = "${local.sub}/resourceGroups/rg-ip-groups-connectivity-global/providers/Microsoft.Network/ipGroups/%s?api-version=2024-05-01"\n' "$name"
    printf '}\n'
  done
} > "$out/ip_groups.imports.txt"

new=$(comm -13 "$out/.declared" "$out/.live" | grep -c . || true)
gone=$(comm -23 "$out/.declared" "$out/.live" | grep -c . || true)

# Members that changed on a group already in state. HCP drift detection reports
# these too, but only once the workspace is running clean.
{
  comm -12 "$out/.declared" "$out/.live" | while IFS= read -r name; do
    [ -n "$name" ] || continue
    want=$(sed -n "/^ip_groups = {/,/^}/p" "$tfvars" \
      | awk -v k="\"$name\"" '$1 == k' \
      | grep -oE 'ip_addresses = \[[^]]*\]' \
      | { grep -oE '"[^"]+"' || true; } | tr -d '"' | sort | tr '\n' ' ')
    # An empty group has no quoted members; under pipefail the bare grep's exit 1 killed the script.
    have=$(jq -r --arg n "$name" '.[] | select(.name == $n)
      | (.ipAddresses // .properties.ipAddresses // [])[]' "$src" | sort | tr '\n' ' ')
    [ "$want" = "$have" ] || echo "$name"
  done
} > "$out/drift.txt"

drift=$(grep -c . "$out/drift.txt" || true)

rm -f "$out/.declared" "$out/.live"

cat <<EOF
declared in $tfvars : $declared
live in Azure       : $live
to be added         : $new
declared but absent : $gone
member drift        : $drift

wrote $out/ip_groups.tfvars.txt
      $out/ip_groups.imports.txt
      $out/drift.txt
EOF

[ "$gone" -eq 0 ] || echo "warning: $gone declared groups do not exist in Azure; check before applying" >&2
