#!/usr/bin/env bash
# Diff what exists in Azure against what Terraform state manages.
#
# The half of drift HCP Terraform cannot see. Its drift detection runs a
# refresh-only plan, comparing each resource *already in state* to its real
# counterpart. A resource created by hand has no state entry, so there is
# nothing to compare it against and HCP never reports it. This script reads
# Azure's inventory instead and diffs both ways. Driven by
# .github/workflows/unmanaged-detect.yml.
#
# Usage:
#   az resource list --subscription "$SUB" -o json > azure.json
#   terraform show -json > state.json
#   detect_unmanaged.sh azure.json state.json [--scope-rg NAME]... \
#                          [--scope-type TYPE]... [--exclude-type TYPE]... \
#                          [--waivers FILE] [--out DIR]
#
# --scope-rg   restrict the comparison to this resource group, repeatable. When
#              omitted, scope is the set of resource groups that appear in
#              state -- so the report covers what this workspace is responsible
#              for and stays quiet about resources another workspace owns.
# --scope-type restrict the comparison to this ARM type, repeatable
#              (e.g. Microsoft.Network/azureFirewalls). Case-insensitive.
# --exclude-type
#              the inverse, repeatable: a type another workspace owns.
#
# The two type flags exist because a resource group is no longer a reliable
# ownership boundary once one subscription is split across workspaces by
# resource type -- rg-hub-connectivity-canadacentral-001 holds firewalls owned
# by one repo and hubs and gateways owned by another. Without a type filter each
# workspace reports the other's resources as unmanaged on every run, which is
# how a report like this gets ignored. Scope is the intersection: a resource
# must be in an in-scope resource group AND pass the type filter.
# --waivers    file of resource IDs or glob patterns that are expected to be
#              unmanaged, one per line, # comments ignored. Case-insensitive.
# --out        directory for the report files. Default ./reconcile
#
# Reports two directions, which mean different things:
#   unmanaged  in Azure, inside scope, with no state entry -- created outside
#              Terraform, or never adopted
#   ghosts     in state but absent from Azure -- deleted out of band, leaving
#              state claiming something that is gone
#
# Only top-level ARM resources are compared. Azure's inventory APIs do not
# enumerate child resources (a blob container, a backup policy, a subnet), so
# treating a child resource in state as missing from Azure would be a false
# positive on every run. Child resources in state are counted and listed
# separately rather than silently dropped.
#
# ARM IDs are compared case-insensitively: the casing Azure returns for a
# resource group segment does not always match what a template export recorded.
#
# Exits 0 when scope is clean, 1 when anything is unmanaged or a ghost,
# 2 on usage error.

set -euo pipefail

if [ $# -lt 2 ]; then
  echo "usage: $(basename "$0") <azure.json> <state.json> [--scope-rg NAME]... [--scope-type TYPE]... [--exclude-type TYPE]... [--waivers FILE] [--out DIR]" >&2
  exit 2
fi

if ! command -v python3 >/dev/null 2>&1; then
  echo "error: python3 is required" >&2
  exit 2
fi

exec python3 - "$@" <<'PYTHON'
import fnmatch
import json
import sys
from pathlib import Path

argv = sys.argv[1:]
azure_path, state_path = argv[0], argv[1]
scope_rgs = set()
scope_types = set()
exclude_types = set()
waivers_path = None
out_dir = Path("reconcile")

i = 2
while i < len(argv):
    if argv[i] == "--scope-rg" and i + 1 < len(argv):
        scope_rgs.add(argv[i + 1].lower())
        i += 2
        continue
    if argv[i] == "--scope-type" and i + 1 < len(argv):
        scope_types.add(argv[i + 1].lower())
        i += 2
        continue
    if argv[i] == "--exclude-type" and i + 1 < len(argv):
        exclude_types.add(argv[i + 1].lower())
        i += 2
        continue
    if argv[i] == "--waivers" and i + 1 < len(argv):
        waivers_path = argv[i + 1]
        i += 2
        continue
    if argv[i] == "--out" and i + 1 < len(argv):
        out_dir = Path(argv[i + 1])
        i += 2
        continue
    print(f"error: unrecognised argument {argv[i]!r}", file=sys.stderr)
    sys.exit(2)


def load(path, label):
    try:
        return json.loads(Path(path).read_text())
    except (OSError, json.JSONDecodeError) as exc:
        print(f"error: could not read {label} {path}: {exc}", file=sys.stderr)
        sys.exit(2)


def classify(rid):
    """Depth of an ARM ID. Only 'resource' is safe to compare against Azure's
    inventory; 'child' is invisible to it."""
    parts = [p for p in rid.split("/") if p]
    if len(parts) == 4 and parts[2].lower() == "resourcegroups":
        return "resource_group"
    if len(parts) == 8 and parts[4].lower() == "providers":
        return "resource"
    if len(parts) > 8 and parts[4].lower() == "providers":
        return "child"
    return "other"


def type_of(rid):
    """ARM type from an ID's provider segments. Top-level resources only, which
    is all the diff compares."""
    parts = [p for p in rid.split("/") if p]
    if len(parts) == 8 and parts[4].lower() == "providers":
        return f"{parts[5]}/{parts[6]}".lower()
    return ""


def in_type_scope(rid, declared=""):
    t = (declared or type_of(rid)).lower()
    if scope_types and t not in scope_types:
        return False
    return t not in exclude_types


def rg_of(rid):
    parts = [p for p in rid.split("/") if p]
    if len(parts) >= 4 and parts[2].lower() == "resourcegroups":
        return parts[3].lower()
    return ""


# ---- Azure inventory ----------------------------------------------------
azure = load(azure_path, "Azure inventory")
if not isinstance(azure, list):
    print("error: Azure inventory must be a JSON array (az resource list -o json)", file=sys.stderr)
    sys.exit(2)
azure_ids = {}
for r in azure:
    rid = (r or {}).get("id")
    if rid:
        azure_ids[rid.lower()] = {"id": rid, "type": r.get("type", "")}

# ---- Terraform state ---------------------------------------------------
# terraform show -json nests modules arbitrarily deep, so walk rather than
# assume a shape.
state = load(state_path, "Terraform state")
managed = {}


def walk(node):
    if isinstance(node, dict):
        for res in node.get("resources", []) or []:
            vals = res.get("values") or {}
            rid = vals.get("id") or vals.get("resource_id")
            if isinstance(rid, str) and rid.startswith("/subscriptions/"):
                # azapi IDs can carry ?api-version=; strip it before comparing.
                clean = rid.split("?", 1)[0]
                managed[clean.lower()] = {"id": clean, "address": res.get("address", "?")}
        for child in node.get("child_modules", []) or []:
            walk(child)
        for key in ("values", "root_module"):
            if key in node:
                walk(node[key])
    elif isinstance(node, list):
        for item in node:
            walk(item)


walk(state)

managed_res = {k: v for k, v in managed.items() if classify(k) == "resource"}
managed_child = {k: v for k, v in managed.items() if classify(k) == "child"}
managed_rg = {k: v for k, v in managed.items() if classify(k) == "resource_group"}

# ---- scope -------------------------------------------------------------
derived = not scope_rgs
if derived:
    scope_rgs = {rg_of(k) for k in managed if rg_of(k)}

# ---- waivers -----------------------------------------------------------
patterns = []
if waivers_path:
    try:
        for line in Path(waivers_path).read_text().splitlines():
            line = line.strip()
            if line and not line.startswith("#"):
                patterns.append(line.lower())
    except OSError as exc:
        print(f"error: could not read waivers {waivers_path}: {exc}", file=sys.stderr)
        sys.exit(2)


def waived(rid_lower):
    return any(fnmatch.fnmatch(rid_lower, p) for p in patterns)


# ---- diff --------------------------------------------------------------
in_scope_azure = {
    k: v for k, v in azure_ids.items()
    if classify(k) == "resource" and rg_of(k) in scope_rgs
    and in_type_scope(k, v["type"])
}

unmanaged, waived_hits = {}, {}
for k, v in in_scope_azure.items():
    if k in managed_res:
        continue
    (waived_hits if waived(k) else unmanaged)[k] = v

ghosts = {
    k: v for k, v in managed_res.items()
    if rg_of(k) in scope_rgs and k not in azure_ids and in_type_scope(k)
}

out_dir.mkdir(parents=True, exist_ok=True)


def write(name, lines):
    (out_dir / name).write_text("".join(f"{l}\n" for l in lines))


write("unmanaged.txt", sorted(f"{v['type']}\t{v['id']}" for v in unmanaged.values()))
write("ghosts.txt", sorted(f"{v['address']}\t{v['id']}" for v in ghosts.values()))
write("waived.txt", sorted(f"{v['type']}\t{v['id']}" for v in waived_hits.values()))
write("child-in-state.txt", sorted(f"{v['address']}\t{v['id']}" for v in managed_child.values()))
write("scope.txt", sorted(scope_rgs))
write("scope-types.txt", sorted(
    [f"only  {t}" for t in scope_types] + [f"minus {t}" for t in exclude_types]
) or ["(all types)"])

print(f"scope: {len(scope_rgs)} resource group(s)"
      + (" (derived from state)" if derived else " (given)"))
for rg in sorted(scope_rgs):
    print(f"  - {rg}")
if scope_types:
    print(f"types: only {len(scope_types)}")
    for t in sorted(scope_types):
        print(f"  - {t}")
if exclude_types:
    print(f"types excluded: {len(exclude_types)}")
    for t in sorted(exclude_types):
        print(f"  - {t}")
print()
print(f"azure, in scope, top-level : {len(in_scope_azure)}")
print(f"state, top-level           : {len(managed_res)}")
print(f"state, child (not compared): {len(managed_child)}")
print(f"state, resource groups     : {len(managed_rg)}")
print(f"waived                     : {len(waived_hits)}")
print(f"UNMANAGED                  : {len(unmanaged)}")
print(f"GHOSTS                     : {len(ghosts)}")

if not scope_rgs:
    # Deliberately not "PASS": an empty scope has proved nothing, and a clean
    # verdict here would read as a clean bill of health for the subscription.
    print("\nINCONCLUSIVE: scope is empty -- state manages nothing, so there is")
    print("nothing to compare against. Pass --scope-rg to inventory a resource")
    print("group anyway; everything in it will read as unmanaged, which is true.")
    sys.exit(0)

if unmanaged:
    print("\nUNMANAGED -- in Azure, inside scope, not in state:")
    for v in sorted(unmanaged.values(), key=lambda x: x["id"]):
        print(f"  [{v['type']}] {v['id']}")

if ghosts:
    print("\nGHOSTS -- in state, absent from Azure:")
    for v in sorted(ghosts.values(), key=lambda x: x["id"]):
        print(f"  {v['address']}")
        print(f"    {v['id']}")

if waived_hits:
    print(f"\nwaived ({len(waived_hits)}), expected to be unmanaged:")
    for v in sorted(waived_hits.values(), key=lambda x: x["id"]):
        print(f"  [{v['type']}] {v['id']}")

if unmanaged or ghosts:
    print("\nFAIL: Azure and state disagree about what exists.")
    sys.exit(1)

print("\nPASS: every top-level resource in scope is accounted for.")
sys.exit(0)
PYTHON
