# firewall.tf
# 3 Azure Firewalls (2 secured-hub in the hub RGs, 1 VNet-based transit in shared_cc),
# 2 firewall policies + 17 rule collection groups (all in the canadacentral hub RG).
# Firewalls, policies and rule collection groups all go through tf-wrapper-avm-*;
# the policy wrapper instantiates the AVM rule_collection_groups submodule, so no
# native resource remains in this tier.
# Rule ipGroups references resolve to module.ip_group[...].resource_id in ip_groups.tf.
#
# Rule bodies are generated from the live policies (rule-collection-groups.json,
# exported 2026-10-05): 518 rules across 137 rule collections, in Azure's own
# collection order. Terraform compares these blocks
# positionally, so sorting them by priority produces a large and meaningless diff.
#
# Five rule collections in Azure hold no rules and are deliberately omitted: the
# provider cannot represent an empty collection, and an Allow collection with no
# rules permits nothing. HANDOVER.md lists them.
#
# Resource groups come from local.rg_names, which reads the data sources in data.tf.

variable "enable_firewall" {
  type    = bool
  default = false
}

locals {
  firewalls = {
    "azfw-connectivity-canadacentral-001" = {
      rg_key                      = "hub_cc"
      location                    = "canadacentral"
      sku_name                    = "AZFW_Hub"
      sku_tier                    = "Premium"
      firewall_policy_id          = module.firewall_policy["azfwpol-connectivity-001"].resource_id
      zones                       = []
      virtual_hub                 = { public_ip_count = 1, virtual_hub_id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001" }
      ip_configurations           = {}
      management_ip_configuration = null
    }
    "azfw-connectivity-canadaeast-001" = {
      rg_key                      = "hub_ce"
      location                    = "canadaeast"
      sku_name                    = "AZFW_Hub"
      sku_tier                    = "Premium"
      firewall_policy_id          = module.firewall_policy["azfwpol-connectivity-001"].resource_id
      zones                       = []
      virtual_hub                 = { public_ip_count = 1, virtual_hub_id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadaeast-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadaeast-001" }
      ip_configurations           = {}
      management_ip_configuration = null
    }
    "azfw-transit-connectivity-canadacentral-001" = {
      rg_key             = "shared_cc"
      location           = "canadacentral"
      sku_name           = "AZFW_VNet"
      sku_tier           = "Standard"
      firewall_policy_id = null
      zones              = []
      virtual_hub        = null
      ip_configurations = {
        primary = {
          name                 = "azfw-transit-connectivity-canadacentral-001_IPConf"
          subnet_id            = "${local.sub}/resourceGroups/rg-shared-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-transit-connectivity-canadacentral-001/subnets/AzureFirewallSubnet"
          public_ip_address_id = null
        }
      }
      management_ip_configuration = {
        name                 = "pip-azfw-transit-connectivity-canadacentral-001"
        public_ip_address_id = "${local.sub}/resourceGroups/rg-shared-connectivity-canadacentral-001/providers/Microsoft.Network/publicIPAddresses/pip-azfw-transit-connectivity-canadacentral-001"
        subnet_id            = "${local.sub}/resourceGroups/rg-shared-connectivity-canadacentral-001/providers/Microsoft.Network/virtualNetworks/vnet-transit-connectivity-canadacentral-001/subnets/AzureFirewallManagementSubnet"
      }
    }
  }

  firewall_policies = {
    "azfwpol-connectivity-001" = {
      location                 = "canadacentral"
      sku                      = "Premium"
      threat_intelligence_mode = "Deny"
      dns                      = { proxy_enabled = true, servers = ["10.195.4.7"] }
      intrusion_detection      = { mode = "Deny" }
      identity                 = { type = "UserAssigned", identity_ids = [var.firewall_uami_id] }
      insights = {
        enabled                            = true
        default_log_analytics_workspace_id = var.firewall_insights_workspace_id
        retention_in_days                  = 30
        log_analytics_workspace = [
          { firewall_location = "canadacentral", id = var.firewall_insights_workspace_id },
          { firewall_location = "canadaeast", id = var.firewall_insights_workspace_id },
        ]
      }
      tls_certificate = var.firewall_tls_certificate
    }
    "azfwpol-connectivity-001-BACKUP-20260320-233016-UTC" = {
      location                 = "canadacentral"
      sku                      = "Premium"
      threat_intelligence_mode = "Deny"
      dns                      = { proxy_enabled = true, servers = ["10.195.4.7"] }
      intrusion_detection      = { mode = "Deny" }
      identity                 = null
      insights                 = null
      tls_certificate          = null
    }
  }

  firewall_rule_collection_groups = {
    "azfwpol-connectivity-001/rcg-1000-spoke-specific-canada-central" = {
      name       = "rcg-1000-spoke-specific-canada-central"
      policy_key = "azfwpol-connectivity-001"
      priority   = 1000
      network_rule_collection = [
        {
          name     = "rc-allow-vnet-cops-nonprod-canadacentral-001-inbound"
          priority = 1610
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-hosted-runners-to-cops-nonprod-dbs-tmp"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-nonprod-cops-db"].resource_id]
              destination_ports     = ["443", "1433", "11000-11999"]
            },
            {
              name                  = "r-allow-hosted-runners-to-cops-nonprod-apps-tmp"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-nonprod-cops-apps"].resource_id]
              destination_ports     = ["80", "443", "8172"]
            },
            {
              name                  = "r-allow-cops-nonprod-to-apple-push"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-nonprod-cops-apps"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["api.push.apple.com", "api.sandbox.push.apple.com"]
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-fit-nonprod-canadacentral-001-inbound"
          priority = 1810
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-hosted-runners-to-fit-nonprod-apps-tmp"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-nonprod-fit-apps"].resource_id]
              destination_ports     = ["80", "443", "8172"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-pta-nonprod-canadacentral-001-inbound"
          priority = 2010
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-hosted-runners-to-pta-nonprod-dbs-tmp"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-nonprod-pta-db"].resource_id]
              destination_ports     = ["443", "1433", "11000-11999"]
            },
            {
              name                  = "r-allow-hosted-runners-to-pta-nonprod-apps-tmp"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-nonprod-pta-apps"].resource_id]
              destination_ports     = ["80", "443", "8172"]
            },
            {
              name                  = "r-allow-hosted-runners-to-pta-nonprod-storage-tmp"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = ["10.195.66.9"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-pta-prod-canadacentral-inbound"
          priority = 2210
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-hosted-runners-to-pta-prod-storage-tmp"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-prod-pta-db"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-hosted-runners-to-pta-prod-dbs-tmp"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-prod-pta-db"].resource_id]
              destination_ports     = ["443", "1433", "11000-11999"]
            },
            {
              name                  = "r-allow-hosted-runners-to-pta-prod-apps-tmp"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-prod-pta-apps"].resource_id]
              destination_ports     = ["80", "443", "8172"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-fit-nonprod-canadacentral-001-outbound"
          priority = 1910
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-fit-nonprod-to-esb-1"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.80.0-10.195.83.254"]
              source_ip_groups      = []
              destination_addresses = ["10.242.47.1"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["22734", "22738", "443"]
            },
            {
              name                  = "r-allow-fit-nonprod-to-esb-2"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.80.0-10.195.83.254"]
              source_ip_groups      = []
              destination_addresses = ["10.242.47.2"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["23734", "23738", "443"]
            },
            {
              name                  = "r-allow-fit-nonprod-db-to-tkdcdbmontr"
              protocols             = ["TCP", "UDP"]
              source_addresses      = ["10.195.81.4"]
              source_ip_groups      = []
              destination_addresses = ["10.242.83.125"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["4903", "22", "3872"]
            },
            {
              name                  = "r-allow-fit-nonprod-db-to-bch-smtp"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.81.4"]
              source_ip_groups      = []
              destination_addresses = ["10.242.35.1"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["25"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-ertest-canadacentral-001-inbound"
          priority = 1390
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-ertest-canadacentral-001-inbound"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-ertest-vnet"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-cyberark-canadacentral-001-inbound"
          priority = 2690
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-vnet-cyberark-canadacentral-001-inbound"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cyberark-vnet"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-dns-connectivity-canadacentral-001-inbound"
          priority = 2890
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-dns-connectivity-canadacentral-001-inbound"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-dns-connectivity-vnet"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-shared-connectivity-canadacentral-001-inbound"
          priority = 1590
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-vnet-shared-connectivity-canadacentral-001-inbound"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-shared-connectivity-vnet"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-cops-nonprod-canadacentral-inbound"
          priority = 1790
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-vnet-cops-nonprod-canadacentral-inbound"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cops-nonprod-vnet"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-fit-nonprod-canadacentral-001-inbound"
          priority = 1990
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-vnet-fit-nonprod-canadacentral-001-inbound"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-fit-nonprod-vnet"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-runners-connectivity-canadacentral-001-inbound"
          priority = 3090
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-vnet-runners-connectivity-canadacentral-001-inbound"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners-vnet"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-cops-prod-canadacentral-inbound"
          priority = 3290
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-vnet-cops-prod-canadacentral-inbound"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cops-prod-vnet"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-fit-prod-canadacentral-001-inbound"
          priority = 3490
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-vnet-fit-prod-canadacentral-001-inbound"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-fit-prod-vnet"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-pta-prod-canadacentral-001-inbound"
          priority = 2390
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-vnet-pta-prod-canadacentral-001-inbound"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-pta-prod-vnet"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-pta-nonprod-canadacentral-001-inbound"
          priority = 2190
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-vnet-pta-nonprod-canadacentral-001-inbound"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-pta-nonprod-vnet"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-fit-prod-canadacentral-001-outbound"
          priority = 3310
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-fit-prod-db-to-kdcdbmontr"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.33.4"]
              source_ip_groups      = []
              destination_addresses = ["10.242.83.115"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["4903"]
            },
            {
              name                  = "r-allow-fit-prod-db-to-bch-smtp"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.33.4"]
              source_ip_groups      = []
              destination_addresses = ["10.242.35.1"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["25"]
            },
            {
              name                  = "r-allow-fit-prod-to-prod-esb"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-prod-fit-apps"].resource_id]
              destination_addresses = ["10.242.12.161"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["21734", "21738", "443"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-cops-prod-canadacentral-001-outbound"
          priority = 3110
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-cops-prod-to-apple-push"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-prod-cops-apps"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["api.push.apple.com", "api.sandbox.push.apple.com"]
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-fit-prod-canadacentral-001-inbound"
          priority = 1710
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-hosted-runners-to-fit-prod-apps"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-prod-fit-apps"].resource_id]
              destination_ports     = ["80", "443", "8172"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-cops-prod-canadacentral-inbound"
          priority = 3120
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-hosted-runners-to-cops-prod-dbs"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-prod-cops-db"].resource_id]
              destination_ports     = ["443", "1433", "11000-11999"]
            },
            {
              name                  = "r-allow-hosted-runners-to-cops-prod-apps"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-prod-cops-apps"].resource_id]
              destination_ports     = ["80", "443", "8172"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-mds-prod-canadacentral-in"
          priority = 3690
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-vnet-mds-prod-canadacentral-in"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-mds-prod-canadacentral"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-solace-nonprod-canadacentral-in"
          priority = 3890
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-vnet-solace-nonprod-canadacentral-in"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-solace-nonprod-canadacentral"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-openai-nonprod-canadacentral-001-in"
          priority = 4290
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-vnet-openai-nonprod-canadacentral-001-in"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-openai-nonprod-canadacentral-001"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-auritas-nonprod-canadacentral-in"
          priority = 4490
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-vnet-auritas-nonprod-canadacentral-in"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-auritas-nonprod-canadacentral"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-mds-canadacentral-outbound"
          priority = 3610
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-mds-https"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-mds-ips"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-allow-runners-cacentral"
          priority = 2912
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-prod-runners-to-prod-vnets"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-prod-runner-ips"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-clz-prod-subnets"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-dev-runners-to-dev-vnets"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-dev-runner-ips"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-clz-dev-subnets"].resource_id]
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-allow-sap-aem-outbound"
          priority = 3810
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-dev-30500"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.112.0/24"]
              source_ip_groups      = []
              destination_addresses = ["10.242.74.123", "10.242.83.70"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["30500"]
            },
            {
              name                  = "r-allow-qa-30500"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.112.0/24"]
              source_ip_groups      = []
              destination_addresses = ["10.242.83.220", "10.242.83.138"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["30500"]
            },
            {
              name                  = "r-allow-dev-8443"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.112.0/24"]
              source_ip_groups      = []
              destination_addresses = ["10.242.83.52", "10.242.83.10"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["8443"]
            },
            {
              name                  = "r-allow-qa-8443"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.112.0/24"]
              source_ip_groups      = []
              destination_addresses = ["10.242.83.97", "10.242.83.11"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["8443"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-cyberark-canadacentral-001-in"
          priority = 2531
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-runners-to-openai-nonprod"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cyberark-vnet"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-vnet-openai-nonprod-canadacentral-001"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-oracle-cyberark"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cyberark-vm-ips"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["dogwood.oracle.cyberark.cloud"]
              destination_ip_groups = []
              destination_ports     = ["1521"]
            },
            {
              name                  = "r-allow-sql-cyberark"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cyberark-vm-ips"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["dogwood.mssql.cyberark.cloud"]
              destination_ip_groups = []
              destination_ports     = ["1433"]
            },
            {
              name                  = "r-allow-cyberark-to-windows-vms"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cyberark-vm-ips"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_ports     = ["445", "3389"]
            },
            {
              name                  = "r-allow-cyberark-to-linux-vms"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cyberark-vm-ips"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_ports     = ["22"]
            },
            {
              name                  = "r-allow-cyberark-1858-ip"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cyberark-vm-ips"].resource_id]
              destination_addresses = ["15.223.165.102"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["1858"]
            },
            {
              name                  = " r-allow-cyberark-1858 "
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cyberark-vm-ips"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["vault-dogwood.privilegecloud.cyberark.cloud"]
              destination_ip_groups = []
              destination_ports     = ["1858"]
            },
            {
              name                  = "r-allow-cyberark-to-cyberarksite"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cyberark-vm-ips"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["www.cyberark.cloud", "abp4127.id.cyberark.cloud", "cyberark.cloud", "cyberark.com", "www.cyberark.com", "community.cyberark.com", "s3.amazonaws.com", "amazonaws.com", "component-registry-store-490081306957.s3.amazonaws.com", "caintegrations.s3.amazonaws.com", "dogwood.cyberark.cloud", "connector-dogwood.privilegecloud.cyberark.cloud", "console.privilegecloud.cyberark.cloud", "dogwood.dpa.cyberark.cloud", "ca-central-1.bc.be-privilege-access.cyberark.cloud", "a3vvqcp8z371p3-ats.iot.ca-central-1.amazonaws.com", "a2m4b3cupk8nzj-ats.iot.ca-central-1.amazonaws.com", "casoftware.s3.amazonaws.com", "dogwood.privilegecloud.cyberark.cloud", "webaccess-dogwood.privilegecloud.cyberark.cloud", "dogwood.webaccess.cyberark.cloud", "dogwood.connectormanagement.cyberark.cloud", "connector-management-scripts-490081306957-ca-central-1.s3.amazonaws.com", "connector-management-assets-490081306957-ca-central-1.s3.amazonaws.com", "pod1402-b1.relay.idaptive.app", "pod1402-b2.relay.idaptive.app", "pod1402-a1.relay.idaptive.app", "pod1402-a2.relay.idaptive.app", "pod0.idaptive.app", "edge.idaptive.app", "cms-assets-bucket-445444212982.s3.amazonaws.com", "cms-assets-bucket-445444212982-ca-central-1.s3.ca-central-1.amazonaws.com", "dogwood.rdp.cyberark.cloud", "dogwood.k8s.cyberark.cloud", "crt.r2m02.amazontrust.com", "ocsp.r2m02.amazontrust.com", "privacy-policy.truste.com", "ocsp.verisign.com", "ocsp.globalsign.com", "crl.globalsign.com", "secure.globalsign.com", "dogwood.ssh.cyberark.cloud", "dogwood.rdp.cyberark.cloud", "dogwood.mariadb.cyberark.cloud", "dogwood.mysql.cyberark.cloud", "dogwood.oracle.cyberark.cloud", "dogwood.postgres.cyberark.cloud", "dogwood.mssql.cyberark.cloud", "dogwood.db2.cyberark.cloud", "dogwood.mongodb.cyberark.cloud", "vault-dogwood.privilegecloud.cyberark.cloud", "ipinfo.io"]
              destination_ip_groups = []
              destination_ports     = ["443", "80", "22", "8443", "3306", "2484", "5432", "1433", "50002", "27017", "1858"]
            },
            {
              name                  = "r-allow-cyberark-to-openai-prod"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cyberark-vm-ips"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-vm-openai-prod-canadacentral-001"].resource_id]
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-auritas-nonprod-canadacentral-in"
          priority = 4310
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-snet-auritas-nonprod-app-cc-in"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-snet-auritas-nonprod-app-canadacentral-001"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["hub.docker.com", "registry-1.docker.io", "production.cloudflare.docker.com", "docker.io", "index.docker.io"]
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-snet-auritas-nonprod-pep-cc-in"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-snet-auritas-nonprod-pep-canadacentral-001"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["hub.docker.com", "registry-1.docker.io", "production.cloudflare.docker.com", "docker.io", "index.docker.io"]
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-auritas-prod-canadacentral-in"
          priority = 4690
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-vnet-auritas-prod-canadacentral-in"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-auritas-prod-canadacentral"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-auritas-prod-canadacentral-in"
          priority = 4510
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-snet-auritas-prod-app-cc-in"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-snet-auritas-prod-app-canadacentral-001"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["hub.docker.com", "registry-1.docker.io", "production.cloudflare.docker.com", "docker.io", "index.docker.io"]
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-snet-auritas-prod-pep-cc-in"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-snet-auritas-prod-pep-canadacentral-001"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["hub.docker.com", "registry-1.docker.io", "production.cloudflare.docker.com", "docker.io", "index.docker.io"]
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-fabric-prod-canadacentral-in"
          priority = 4890
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-vnet-fabric-prod-canadacentral-in"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-fabric-prod-canadacentral"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-spo-nonprod-canadacentral-in"
          priority = 5090
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-vnet-spo-nonprod-canadacentral-in"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-spo-nonprod-canadacentral"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-spo-prod-canadacentral-in"
          priority = 5290
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-vnet-spo-prod-canadacentral-in"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-spo-prod-canadacentral-001"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-fabric-nonprod-canadacentral-in"
          priority = 5490
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-vnet-fabric-nonprod-canadacentral-in"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-fabric-nonprod-canadacentral"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-fabric-prod-canadacentral-in"
          priority = 4710
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-fabric-prod-to-sap-dataphere"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.123.4", "10.195.123.5", "10.195.123.136"]
              source_ip_groups      = []
              destination_addresses = ["15.156.54.127", "16.52.121.191", "16.52.13.141", "3.98.251.234"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-fabric-prod-to-sap-dataphere-fqdn"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.123.4", "10.195.123.5", "10.195.123.136"]
              source_ip_groups      = []
              destination_addresses = []
              destination_fqdns     = ["2edc5e24-4425-4dab-849e-84cf13483b26.hana.prod-ca10.hanacloud.ondemand.com"]
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-fabric-prod-to-esb-dropbox-sftp"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.123.4", "10.195.123.5", "10.195.123.136"]
              source_ip_groups      = []
              destination_addresses = ["10.242.124.15"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["22"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-pei-prod-canadacentral-001-outbnd"
          priority = 5890
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-vnet-pei-prod-canadacentral-in"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-pei-appservice-prod-canadacentral"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-dthree-prod-canadacentral-001-outbound"
          priority = 6090
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-vnet-dthree-prod-canadacentral-in"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-dthree-appservice-prod-canadacentral"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "r-deny-vnet-cae-cep-dev-canadacentral-in"
          priority = 6290
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-cae-cep-dev-canadacentral-001-inbound"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgroup-vnet-cae-cep-dev-canadacentral-in"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-shared-connectivity-canadacentral-001-inbound"
          priority = 1410
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-sentinel-to-logic-app"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-monitor"].resource_id]
              destination_addresses = ["10.195.6.16"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-hosted-runners-to-loganalytics"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = ["10.195.6.8"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-hosted-runners-to-keyvault-tmp"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = ["10.195.66.4"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-hosted-runners-to-logic-app-tmp"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = ["10.195.6.16"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-hosted-runners-to-container-registry"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = ["10.195.128.4", "10.195.128.5"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-dthree-dev-canadacentral-in"
          priority = 6320
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-vnet-dthree-dev-canadacentral-in"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-dthree-dev-canadacentral"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-allow-pei-appservice-canadacentral-in"
          priority = 5710
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-pei-appservicesubnet-to-azuresql-prod-sql"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-pei-appservice-prod-canadacentral"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-pei-sql-private-endpoint-ip"].resource_id]
              destination_ports     = ["1433"]
            },
            {
              name                  = "r-allow-pei-appservicesubnet-to-keyvault-https"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-pei-appservice-prod-canadacentral"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-pei-key-vault-private-endpoint-ip"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-pei-appservicesubnet-to-azuresql-mi-db"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-pei-appservice-prod-canadacentral"].resource_id]
              destination_addresses = ["10.195.69.41"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["1433"]
            },
            {
              name                  = "r-allow-pei-appservicesubnet-to-pei-sql-1433-11000-11999"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-pei-appservice-prod-canadacentral"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-pei-sql-endpoint"].resource_id]
              destination_ports     = ["1433", "11000-11999"]
            },
            {
              name                  = "r-allow-pei-sql-kdcsql-1443"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-pep-pei-sql-endpoint"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-kdcbchsqld01"].resource_id, module.ip_group["ipgrp-pep-kdcbchsqlt01"].resource_id, module.ip_group["ipgrp-pep-kdcbchsqlp01"].resource_id, module.ip_group["ipgrp-pep-kdcbchpsdbd02"].resource_id]
              destination_ports     = ["1433"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-gom-test-canadacentral-in"
          priority = 6410
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-ipgrp-Azure-GOM-VM-DB-to-tkdcdbmontr-ssh-4903"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-Azure-GOM-VM-DB"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-tkdcdbmontr"].resource_id]
              destination_ports     = ["4903", "22"]
            },
            {
              name                  = "r-allow-githubrunner-to-ipgrp-Azure-GOM-VM-DB-https"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-githubrunner-nonprod-canadacentral"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-Azure-GOM-VM-DB"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-githubrunner-to-ipgrp-bchgatev-SMTP"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-Azure-GOM-VM-DB"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-bchgatev"].resource_id]
              destination_ports     = ["25"]
            },
            {
              name                  = "r-allow-vnet-githubrunner-nonprod-gom-storageblob-https"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-githubrunner-nonprod-canadacentral"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-gom-storageblob"].resource_id]
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-gom-test-canadacentral-canadacentral-in"
          priority = 6590
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-vnet-gom-test-canadacentral-in"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-gom-test-canadacentral"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-dthree-dev-canadacentral-in"
          priority = 6310
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-scm-graph-api"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-dethree-SCM-endpoint-ip"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["graph.microsoft.com"]
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-app-dthree-dev-graph-api"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-dthree-appservice-prod-canadacentral"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["graph.microsoft.com", "login.microsoftonline.com"]
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-cns-nonprod-canadacentral-in"
          priority = 6790
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-vnet-cns-nonprod-canadacentral-in"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgroup-vnet-cns-nonprod-canadacentral-001"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-cns-nonprod-canadacentral-in"
          priority = 6610
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-snet-app-cns-nonprod-cc"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgroup-snet-app-cns-nonprod-canadacentral-001"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["graph.microsoft.com", "login.microsoftonline.com"]
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-cswt-test-canadacentral-in"
          priority = 6810
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-vnet-cswt-test-to-app-service-endpts"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-cswt-test-canadacentral-001"].resource_id]
              destination_addresses = ["10.195.73.104", "10.195.73.105"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-cswt-test-canadacentral-in"
          priority = 6990
          action   = "Allow"
          rule = [
            {
              name                  = "r-deny-vnet-cswt-test-canadacentral-001-inbound"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-cswt-test-canadacentral-001"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-snet-app-lims-dev-canadacentral-in"
          priority = 7190
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-snet-app-lims-canadacentral-in"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-snet-app-lims-dev-canadacentral-001"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-cae-cep-dev-canadacentral-in"
          priority = 6110
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-cae-cep-dev-canadacentral-001-to-aem-dev"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.128.229", "10.195.128.6"]
              source_ip_groups      = []
              destination_addresses = ["10.195.112.8"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["55443", "9443", "8883", "5671", "443"]
            },
            {
              name                  = "r-allow-cae-cep-dev-canadacentral-001-to-file-storage"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.128.229", "10.195.128.6"]
              source_ip_groups      = []
              destination_addresses = ["10.195.126.37"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["445"]
            },
            {
              name                  = "r-allow-cae-cep-dev-canadacentral-001-to-archive-blob"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.128.229", "10.195.128.6"]
              source_ip_groups      = []
              destination_addresses = ["10.195.126.38"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-cae-cep-dev-canadacentral-001-to-sql-db"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.128.229", "10.195.128.6"]
              source_ip_groups      = []
              destination_addresses = ["10.195.126.39"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["1433"]
            },
            {
              name                  = "r-allow-cae-cep-dev-canadacentral-001-to-key-vaults"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.128.229", "10.195.128.6"]
              source_ip_groups      = []
              destination_addresses = ["10.195.126.36"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-cae-cep-dev-canadacentral-001-to-mdms"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.128.229", "10.195.128.6"]
              source_ip_groups      = []
              destination_addresses = ["10.242.12.153"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["8001"]
            },
            {
              name                  = "r-allow-cae-cep-dev-canadacentral-001-to-bch-mail-srv"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.128.229", "10.195.128.6"]
              source_ip_groups      = []
              destination_addresses = ["10.242.35.1"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["25"]
            },
            {
              name                  = "r-allow-cae-cep-dev-canadacentral-001-to-bch-splunk-cloud"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.128.229", "10.195.128.6"]
              source_ip_groups      = []
              destination_addresses = []
              destination_fqdns     = ["http-inputs-bchpa.splunkcloud.com"]
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-allow-snet-app-pea-qa-canadacentral-in"
          priority = 7200
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-snet-app-pea-qa-db-1433"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-snet-app-pea-qa"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-db-pea-qa"].resource_id]
              destination_ports     = ["1433"]
            },
            {
              name                  = "r-allow-pea-db-qa-kdc-kdcbchpsdbq02-kdcbchsqlt01-1433"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-db-pea-qa"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-kdcbchpsdbq02"].resource_id, module.ip_group["ipgrp-pep-kdcbchsqlt01"].resource_id]
              destination_ports     = ["1433"]
            },
            {
              name                  = "r-allow-snet-app-pea-qa-pea-keyvault-appconfig-443"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-snet-app-pea-qa"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pea-keyvault-qa"].resource_id, module.ip_group["ipgrp-pea-appconfig-qa"].resource_id]
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-deny-snet-app-pea-qa-canadacentral-in"
          priority = 7220
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-snet-app-pea-qa-canadacentral-in"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-snet-app-pea-qa"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-pea-dev-canadacentral-in"
          priority = 7410
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-pea-dev-to-pea-app-to-pea-dev-traffic"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-pea-dev-canadacentral-001"].resource_id]
              destination_addresses = ["10.195.69.6"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-pea-dev-canadacentral-in"
          priority = 7590
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-vnet-pea-dev-canadacentral-001-inbound"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-pea-dev-canadacentral-001"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-allow-dthree-appservice-canadacentral-in"
          priority = 5910
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-dthree-appservicesubnet-to-azuresql-prod-sql "
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-dthree-appservice-prod-canadacentral"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-dethree-sql-endpoint-ip"].resource_id]
              destination_ports     = ["1433"]
            },
            {
              name                  = "r-allow-dthree-appservicesubnet-to-keyvault-https"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-dthree-appservice-prod-canadacentral"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-dethree-key-vault-endpoint-ip"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-dthree-appservicesubnet-to-storage-smb"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-dthree-appservice-prod-canadacentral"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-dethree-Storage-endpoint-ip"].resource_id]
              destination_ports     = ["445"]
            },
            {
              name                  = "r-allow-dthree-appservicesubnet-to-dthree-app-to-dthree-dev-traffic"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-dthree-appservice-prod-canadacentral"].resource_id]
              destination_addresses = ["10.195.68.139"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-boundary-test-canadacentral-001"
          priority = 7240
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-boundary-encroachment-ad-to-on-prem-icmp"
              protocols             = ["ICMP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-snet-pep-boundary-test-canadacentral-001"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-bchydro-adroot-ad-servers"].resource_id, module.ip_group["ipgrp-bchydro-adroot-ad-servers-azure"].resource_id]
              destination_ports     = ["*"]
            },
            {
              name                  = "r-allow-boundary-encroachment-ad-to-on-prem-tcp"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-snet-pep-boundary-test-canadacentral-001"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-bchydro-adroot-ad-servers-azure"].resource_id, module.ip_group["ipgrp-bchydro-adroot-ad-servers"].resource_id]
              destination_ports     = ["135", "3268", "3269", "389", "445", "464", "49152-65535", "53", "636", "88"]
            },
            {
              name                  = "r-allow-boundary-encroachment-ad-to-on-prem-udp"
              protocols             = ["UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-snet-pep-boundary-test-canadacentral-001"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-bchydro-adroot-ad-servers"].resource_id, module.ip_group["ipgrp-bchydro-adroot-ad-servers-azure"].resource_id]
              destination_ports     = ["389", "464", "88", "53", "123"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-boundary-test-canadacentral-001"
          priority = 7260
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-vnet-boundary-test-canadacentral-001"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-boundary-test-canadacentral-001"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-allow-snet-sql-pea-dev-canadacentral-001"
          priority = 7280
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-snet-sql-pea-dev-bch-db-1433"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-snet-sql-pea-dev-canadacentral-001"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-kdcbchsqld01"].resource_id, module.ip_group["ipgrp-pep-kdcbchsqlt01"].resource_id, module.ip_group["ipgrp-pep-kdcbchpsdbd02"].resource_id, module.ip_group["ipgrp-pep-kdcbchsqlp01"].resource_id, module.ip_group["ipgrp-kdcbchpsdbq02"].resource_id]
              destination_ports     = ["1433"]
            },
          ]
        },
        {
          name     = "rc-deny-snet-sql-pea-dev-canadacentral-001"
          priority = 7300
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-snet-sql-pea-dev-canadacentral-001"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-snet-sql-pea-dev-canadacentral-001"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-sharedsvc-nonprod-gw-canadacentral-001"
          priority = 7340
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-vnet-sharedsvc-nonprod-gw-canadacentral-001"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-sharedsvc-nonprod-gw-canadacentral-001"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-sharedsvc-nonprod-gw-canadacentral-001"
          priority = 7320
          action   = "Allow"
          rule = [
            {
              name                  = "r-vnet-sharedsvc-nonprod-gw-keyvault-https"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-sharedsvc-nonprod-gw-canadacentral-001"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-keyvault-endpoint"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-vnet-sharedsvc-nonprod-subnet-to-azure-multiple-private-endpts"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-sharedsvc-nonprod-gw-canadacentral-001"].resource_id]
              destination_addresses = ["10.195.68.135", "10.195.70.69", "10.195.69.198", "10.195.132.102", "10.195.122.198", "10.195.69.5", "10.195.73.103"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-vnet-sharedsvc-nonprod-subnet-to-lims-staging-vm-https"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-sharedsvc-nonprod-gw-canadacentral-001"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-azure-staging-vm"].resource_id]
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-runners-connectivity-canadacentral-001-in"
          priority = 2911
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-runners-to-openai-nonprod"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners-vnet"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-vnet-openai-nonprod-canadacentral-001"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-runners-to-openai-prod"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-openai-prod-acropenaiprodcc001"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-runners-to-pep-psql-openai-prod"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-psql-openai-prod-cc-001"].resource_id]
              destination_ports     = ["5432"]
            },
            {
              name                  = "r-allow-runners-to-pep-psql-openai-nonprod"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-psql-openai-nonprod-cc-001"].resource_id]
              destination_ports     = ["5432"]
            },
            {
              name                  = "r-allow-runners-nonprod-to-Application-deployment-https"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-githubrunner-nonprod-canadacentral"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-func-boundary-test-canadacentral-001"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-hosted-runners-to-wrap-test-https"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-githubrunner-nonprod-canadacentral"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-func-wrap-test-canadacentral-001"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-runners-nonprod-to-dethree-scm-https-test"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-githubrunner-nonprod-canadacentral"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-dethree-SCM-endpoint-ip"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-runners-nonprod-to-github-app-https"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-githubrunner-nonprod-canadacentral"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-pei-appservice-private-endpoint-ip"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-runners-nonprod-to-ecsi-app-smb-test"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-githubrunner-nonprod-canadacentral"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-ecsi-app-service-endpoint-test"].resource_id]
              destination_ports     = ["445"]
            },
            {
              name                  = "r-allow-runners-nonprod-to-ecsi-db-sql-test"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-githubrunner-nonprod-canadacentral"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-ecsi-endpoint-test"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-runners-nonprod-to-cns-nonprod-endpts"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-githubrunner-nonprod-canadacentral"].resource_id]
              destination_addresses = ["10.195.70.69", "10.195.70.73"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443", "1433"]
            },
            {
              name                  = "r-allow-runners-nonprod-to-app-blob-storage-endpt"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-githubrunner-nonprod-canadacentral"].resource_id]
              destination_addresses = ["10.195.70.72"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-runners-nonprod-to-app-deployment-endpt"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-githubrunner-nonprod-canadacentral"].resource_id]
              destination_addresses = ["10.195.73.103"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-pe-app-citt-dev-cc "
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-githubrunner-nonprod-canadacentral"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-app-citt-dev-canadacentral001-pe"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-vnet-githubrunner-nonprod-pea-endpoints-https"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-githubrunner-nonprod-canadacentral"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pea-keyvault-qa"].resource_id, module.ip_group["ipgrp-pea-appconfig-qa"].resource_id, module.ip_group["ipgrp-pea-app-qa"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-vnet-runners-dev-blobstorage-https"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-githubrunner-nonprod-canadacentral"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-gom-storageblob"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-githubrunner-to-dthree-pea-ecsi-and-cns-app-endpts"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-githubrunner-nonprod-canadacentral"].resource_id]
              destination_addresses = ["10.195.68.139", "10.195.69.6", "10.195.70.75", "10.195.69.205"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-githubrunner-to-stdthreedevcc001"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-githubrunner-nonprod-canadacentral"].resource_id]
              destination_addresses = ["10.195.68.138"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443", "445", "2049"]
            },
            {
              name                  = "r-allow-githubrunner-to-azure-key-vault-private-endpts"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-githubrunner-nonprod-canadacentral"].resource_id]
              destination_addresses = ["10.195.132.70"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-githubrunner-to-shipd-nonprod-pvt-ip"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-githubrunner-nonprod-canadacentral"].resource_id]
              destination_addresses = ["10.195.122.198"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["445"]
            },
            {
              name                  = "r-allow-githubrunner-to-shipd-all-non-prod-endpts"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-githubrunner-nonprod-canadacentral"].resource_id]
              destination_addresses = ["10.195.122.230", "10.195.122.231", "10.195.122.232"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-vnet-githubrunner-nonprod-to-bch-onprem-jumphost01"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.114.0/27"]
              source_ip_groups      = []
              destination_addresses = ["10.242.112.4"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["22", "443", "445", "2049", "8000"]
            },
            {
              name                  = "r-allow-runners-nonprd-stdthreedevcc01-https"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-githubrunner-nonprod-canadacentral"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-dethree-Storage-endpoint-ip"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-runners-nonprd-lims-staging-vm-https"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-githubrunner-nonprod-canadacentral"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-azure-staging-vm"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-runners-nonprd-key-vault-endpoint-443"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-githubrunner-nonprod-canadacentral"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-key-vault-endpoint"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-runners-nonprd-shipping-docs-vm-8172"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-githubrunner-nonprod-canadacentral"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-shipping-doc-vm"].resource_id]
              destination_ports     = ["8172"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-mft-dev-canadacentral-in"
          priority = 5530
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-vnet-mft-dev-canadacentral-in"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-mft-dev-canadacentral"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-mft-dev-canadacentral-in"
          priority = 5509
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-mft-dev-gateway-to-sftp-01"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.126.4"]
              source_ip_groups      = []
              destination_addresses = ["204.90.130.72", "207.134.108.253", "184.71.123.38", "15.156.124.131", "69.60.255.221", "10.242.46.32", "142.52.192.220", "35.182.172.137", "35.182.82.195", "206.191.68.109", "70.42.29.42", "20.175.151.177", "158.106.224.104", "199.185.7.108", "142.34.128.106", "10.242.83.3", "34.206.25.254", "156.11.17.10"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["22"]
            },
            {
              name                  = "r-allow-mft-dev-gateway-to-sftp-02"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.126.4"]
              source_ip_groups      = []
              destination_addresses = ["142.179.106.119"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["2222"]
            },
            {
              name                  = "r-allow-mft-dev-gateway-to-sftp-03"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.126.4"]
              source_ip_groups      = []
              destination_addresses = ["192.26.212.108", "40.177.26.229", "40.177.71.12", "40.177.156.89", "99.79.158.168", "3.98.44.143", "15.156.185.237"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["10022"]
            },
            {
              name                  = "r-allow-mft-dev-gateway-to-sftp-04"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.126.4"]
              source_ip_groups      = []
              destination_addresses = ["204.104.133.4"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["21021"]
            },
            {
              name                  = "r-allow-vnet-mft-dev-mft-node-to-sftp-01"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.126.20"]
              source_ip_groups      = []
              destination_addresses = ["10.242.124.9", "10.242.74.17", "10.242.74.43"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["22"]
            },
            {
              name                  = "r-allow-vnet-mft-dev-mft-node-to-sftp-02"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.126.20"]
              source_ip_groups      = []
              destination_addresses = ["54.91.141.3"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["10022"]
            },
          ]
        },
        {
          name     = "rc-allow-snet-app-lims-dev-canadacentral-in"
          priority = 7010
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-snet-app-lims-dev-kdcejasut1-15110"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-snet-app-lims-dev-canadacentral-001"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-kdcejasut1"].resource_id]
              destination_ports     = ["15110"]
            },
            {
              name                  = "r-allow-snet-app-lims-dev-kdcendbt1-1521"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-snet-app-lims-dev-canadacentral-001"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-kdcendbt1"].resource_id]
              destination_ports     = ["1521"]
            },
            {
              name                  = "r-allow-snet-app-lims-dev-kdcbchlimsdcc1-11080"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-snet-app-lims-dev-canadacentral-001"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-kdcbchlimsdcc1"].resource_id]
              destination_ports     = ["11080"]
            },
            {
              name                  = "r-allow-snet-app-lims-dev-kdcbchepo1-443"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-snet-app-lims-dev-canadacentral-001"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-kdcbchepo1"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-snet-app-lims-dev-kdcbchepotie1-8883"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-snet-app-lims-dev-canadacentral-001"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-kdcbchepotie1"].resource_id]
              destination_ports     = ["8883"]
            },
            {
              name                  = "r-allow-snet-app-lims-dev-bchgatev-25"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-snet-app-lims-dev-canadacentral-001"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-bchgatev"].resource_id]
              destination_ports     = ["25"]
            },
            {
              name                  = "r-allow-snet-app-lims-dev-fqdn-outlook-443"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-snet-app-lims-dev-canadacentral-001"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["outlook.office365.com"]
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-snet-app-lims-sql-1433"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-snet-app-lims-dev-canadacentral-001"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-lims-sql-endpoint"].resource_id]
              destination_ports     = ["1433"]
            },
            {
              name                  = "r-allow-snet-app-lims-key-vault-443"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-snet-app-lims-dev-canadacentral-001"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-lims-key-vault"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-githubrunner-to-lmsdev-https"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-githubrunner-nonprod-canadacentral"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-snet-app-lims-dev-canadacentral-001"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-snet-app-lims-dev-fqdn-login.microsoft-443"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-snet-app-lims-dev-canadacentral-001"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["login.microsoftonline.com"]
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-snet-app-lims-dev-to-azure-key-vault-private-endpts"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-snet-app-lims-dev-canadacentral-001"].resource_id]
              destination_addresses = ["10.195.132.70"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-snet-app-lims-dev-kdcfnapd2-https"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-snet-app-lims-dev-canadacentral-001"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-kdcfnapd2"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-snet-app-lims-dev-ad-to-on-prem-icmp"
              protocols             = ["ICMP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-snet-app-lims-dev-canadacentral-001"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-bchydro-adroot-ad-servers"].resource_id, module.ip_group["ipgrp-bchydro-adroot-ad-servers-azure"].resource_id]
              destination_ports     = ["*"]
            },
            {
              name                  = "r-allow-snet-app-lims-dev-ad-to-on-prem-tcp"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-snet-app-lims-dev-canadacentral-001"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-bchydro-adroot-ad-servers"].resource_id, module.ip_group["ipgrp-bchydro-adroot-ad-servers-azure"].resource_id]
              destination_ports     = ["135", "3268", "3269", "389", "445", "464", "49152-65535", "53", "636", "88"]
            },
            {
              name                  = "r-allow-snet-app-lims-dev-ad-to-on-prem-udp"
              protocols             = ["UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-snet-app-lims-dev-canadacentral-001"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-bchydro-adroot-ad-servers"].resource_id, module.ip_group["ipgrp-bchydro-adroot-ad-servers-azure"].resource_id]
              destination_ports     = ["389", "464", "88", "53", "123"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-tibco-nonprod-canadacentral-in"
          priority = 5510
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-tibco-mft-node-cluster-to-onprem-metermgr"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.126.20"]
              source_ip_groups      = []
              destination_addresses = ["10.242.83.186"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["22"]
            },
            {
              name                  = "r-allow-mft-dev-to-dropbox"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.126.20"]
              source_ip_groups      = []
              destination_addresses = ["10.242.94.7"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["22"]
            },
            {
              name                  = "r-allow-mft-dev-to-goanywhere-com"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.126.20", "10.195.126.4"]
              source_ip_groups      = []
              destination_addresses = []
              destination_fqdns     = ["my.goanywhere.com", "goanywhere.com"]
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-mft-dev-to-stwraptestcac001"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.126.20", "10.195.126.4"]
              source_ip_groups      = []
              destination_addresses = ["10.195.68.41"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443", "445"]
            },
            {
              name                  = "r-allow-tibco-mft-node-cluster-to-on-prem-meter-mgr"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.126.20"]
              source_ip_groups      = []
              destination_addresses = ["10.242.83.3"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["22"]
            },
            {
              name                  = "r-allow-tibco-mft-node-cluster-to-on-prem-sftp-srvr"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.126.20"]
              source_ip_groups      = []
              destination_addresses = ["10.242.124.9"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["22"]
            },
            {
              name                  = "r-allow-tibco-mft-node-cluster-to-on-prem-smtp-srvr"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.126.20"]
              source_ip_groups      = []
              destination_addresses = ["10.242.35.1"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["25"]
            },
            {
              name                  = "r-allow-tibco-mft-node-cluster-to-on-prem-dropbox-srvr"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.126.20"]
              source_ip_groups      = []
              destination_addresses = ["10.242.141.238"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["635", "445"]
            },
            {
              name                  = "r-allow-tibco-mft-node-cluster-to-onprem-ad-auth"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.126.20"]
              source_ip_groups      = []
              destination_addresses = ["10.242.12.4"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["636", "389", "88"]
            },
            {
              name                  = "r-allow-tibco-mft-node-cluster-to-on-prem-oms-db"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.126.20"]
              source_ip_groups      = []
              destination_addresses = ["10.242.239.7"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["1521"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-solace-nonprod-canadacentral-in"
          priority = 3809
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-solace-eam-to-esb-dev"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.112.8"]
              source_ip_groups      = []
              destination_addresses = ["10.242.94.44"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-solace-aem-datalake"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-solace-nonprod-canadacentral"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-stfabricnonprodcac001"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-solace-eam-to-internet"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-solace-nonprod-canadacentral"].resource_id]
              destination_addresses = ["35.183.74.34", "35.182.75.101", "3.98.102.153", "15.157.88.166", "3.98.202.222", "52.60.210.33"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-solace-aem-dev-to-msg-brk-443"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.112.15"]
              source_ip_groups      = []
              destination_addresses = ["10.242.94.44"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-solace-aem-dev-to-msg-brk-24777"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.112.15", "10.195.112.8"]
              source_ip_groups      = []
              destination_addresses = ["10.242.94.13", "10.242.94.14", "10.242.94.17", "10.242.94.18"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["24777"]
            },
            {
              name                  = "r-allow-solace-aem-qas-to-msg-broker"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.112.12"]
              source_ip_groups      = []
              destination_addresses = ["10.242.94.44"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-solace-dev-endpts-to-bchpa-splunk-cloud"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.112.8", "10.195.112.12"]
              source_ip_groups      = []
              destination_addresses = []
              destination_fqdns     = ["http-inputs-bchpa.splunkcloud.com"]
              destination_ip_groups = []
              destination_ports     = ["443", "8088", "8089", "9997"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-fabric-nonprod-canadacentral-in"
          priority = 5310
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-fabric-nonprod-to-sap-dataphere"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-pep-df-fabric-nonprod-canadacentral-001"].resource_id, module.ip_group["ipgrp-pep-vm-fabric-nonprod-canadacentral-001"].resource_id]
              destination_addresses = ["15.156.54.127", "16.52.121.191", "16.52.13.141", "3.98.251.234"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-fabric-nonprod-to-sap-dataphere-fqdn"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-pep-df-fabric-nonprod-canadacentral-001"].resource_id, module.ip_group["ipgrp-pep-vm-fabric-nonprod-canadacentral-001"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["dcaa148a-35ec-449b-9faa-496ecda12902.hana.prod-ca10.hanacloud.ondemand.com", "e70c6873-472e-48ed-9476-05b63d89ec98.hana.prod-ca10.hanacloud.ondemand.com"]
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-fabric-non-prod-to-esb-dropbox"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-pep-vm-fabric-nonprod-canadacentral-001"].resource_id, module.ip_group["ipgrp-pep-df-fabric-nonprod-canadacentral-001"].resource_id]
              destination_addresses = ["10.242.124.9"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["22"]
            },
            {
              name                  = "r-allow-snet-fabric-nonprod-vdg-to-on-prem-emetering-nprod-sql-servers"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["snet-fabric-nonprod-vdg-canadacentral-001"].resource_id]
              destination_addresses = ["10.242.69.42", "10.242.69.30", "10.242.91.143"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["1433"]
            },
            {
              name                  = "r-allow-snet-fabric-nonprod-vdg-to-on-prem-oracle-servers"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["snet-fabric-nonprod-vdg-canadacentral-001"].resource_id]
              destination_addresses = ["10.242.90.27", "10.242.90.42", "10.242.90.36", "10.242.82.12", "10.242.239.228"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["1521"]
            },
            {
              name                  = "r-allow-snet-fabric-nonprod-vdg-to-on-prem-pi-prod-servers"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["snet-fabric-nonprod-vdg-canadacentral-001"].resource_id]
              destination_addresses = ["172.26.102.17", "10.242.34.165"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["5450"]
            },
            {
              name                  = "r-allow-snet-fabric-nonprod-vdg-to-on-prem-eas-nprod-server"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["snet-fabric-nonprod-vdg-canadacentral-001"].resource_id]
              destination_addresses = ["10.242.97.200"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["5432"]
            },
            {
              name                  = "r-allow-snet-fabric-nonprod-vdg-to-on-prem-pi-nprod-server"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["snet-fabric-nonprod-vdg-canadacentral-001"].resource_id]
              destination_addresses = ["10.242.33.110"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-snet-fabric-nonprod-vdg-to-on-prem-nprod-dropbox"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["snet-fabric-nonprod-vdg-canadacentral-001"].resource_id]
              destination_addresses = ["10.242.141.238"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["445"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-lims-stg-canadacentral-in"
          priority = 7620
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-vnet-pea-dev-canadacentral-001-inbound"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-lims-stg-canadacentral-001"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-lims-stg-canadacentral-in"
          priority = 7600
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-lims-staging-kdc-filenetstaging-15110-15101"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-azure-staging-vm"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-w3tecm"].resource_id]
              destination_ports     = ["15110", "15101"]
            },
            {
              name                  = "r-allow-lims-staging-kdcfndbs1-1521"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-azure-staging-vm"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-kdcfndbs1"].resource_id]
              destination_ports     = ["1521"]
            },
            {
              name                  = "r-allow-lims-staging-kdcbchlimsscc1-11080"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-azure-staging-vm"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-kdcbchlimsscc1"].resource_id]
              destination_ports     = ["11080"]
            },
            {
              name                  = "r-allow-lims-staging-kdcbchepo1-https"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-azure-staging-vm"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-kdcbchepo1"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-lims-staging-kdcbchepotie2-8883"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-azure-staging-vm"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-kdcbchepotie2"].resource_id]
              destination_ports     = ["8883"]
            },
            {
              name                  = "r-allow-lims-staging-bchgatev-smtp"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-azure-staging-vm"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-bchgatev"].resource_id]
              destination_ports     = ["25"]
            },
            {
              name                  = "r-allow-lims-staging-key-vault-endpoint-https"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-azure-staging-vm"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-key-vault-endpoint"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-lims-staging-kdcfnaps3-https"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-azure-staging-vm"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-kdcfnaps3"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-lims-staging-bch-activedirectory-tcp"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-snet-app-lims-stg-canadacentral-001"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-bchydro-adroot-ad-servers"].resource_id]
              destination_ports     = ["135", "3268", "3269", "445", "464", "49152-65535", "88", "53", "389", "636"]
            },
            {
              name                  = "r-allow-lims-staging-bch-activedirectory-udp"
              protocols             = ["UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-snet-app-lims-stg-canadacentral-001"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-bchydro-adroot-ad-servers"].resource_id]
              destination_ports     = ["389", "53", "88", "123", "464"]
            },
            {
              name                  = "r-allow-lims-staging-lims-sql-endpoint-1433"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-azure-staging-vm"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-lims-sql-endpoint"].resource_id]
              destination_ports     = ["1433"]
            },
            {
              name                  = "r-allow-kdcbchclzjmp01-lims-staging-lims-key-vault-https"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-azure-staging-vm"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-key-vault-endpoint"].resource_id]
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-runners-connectivity-canadacentral-001-outbound"
          priority = 2910
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-runners-to-ms-build"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["akamaized.net", "akamaitechnologies.com", "aka.ms", "download.visualstudio.microsoft.com", "download.microsoft.com", "download.visualstudio.com", "marketplace.visualstudio.com", "gallerycdn.vsassets.io", "visualstudio.microsoft.com", "learn.microsoft.com", "msdn.microsoft.com", "www.microsoft.com", "windows.net", "microsoftonline.com", "live.com", "github-releases.githubusercontent.com", "objects.githubusercontent.com", "github.com", "az837173.vo.msecnd.net"]
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-runners-dev-to-app-pep"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.115.0/27"]
              source_ip_groups      = []
              destination_addresses = ["10.195.68.39"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["445"]
            },
            {
              name                  = "r-allow-runners-to-fa-test"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.115.0/27"]
              source_ip_groups      = []
              destination_addresses = ["10.195.69.198"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["445"]
            },
            {
              name                  = "r-allow-runners-to-all-endpoints-test"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.115.0/27"]
              source_ip_groups      = []
              destination_addresses = ["10.195.69.198", "10.195.69.199", "10.195.69.200"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-githubrunner-to-pei-appservice-private-https"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-githubrunner-prod-canadacentral"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-pei-appservice-private-endpoint-ip"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-githubrunner-to-dethree-appservice-private-https"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-githubrunner-prod-canadacentral"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-dethree-SCM-endpoint-ip"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-githubrunner-to-BEP-function-app-https"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-githubrunner-prod-canadacentral"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-bep-function-app"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-snet-runners-prod-canadacentral-to-azure-app-service"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-githubrunner-prod-canadacentral"].resource_id]
              destination_addresses = ["10.195.20.229"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-snet-runners-prod-canadacentral-to-azure-function-app-service"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-githubrunner-prod-canadacentral"].resource_id]
              destination_addresses = ["10.195.21.166"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-mft-prod-canadacentral-001"
          priority = 4910
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-vnet-mft-prod-canadacentral-to-azure-blob-endpoint"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.73.37", "10.195.73.38", "10.195.73.21", "10.195.73.22"]
              source_ip_groups      = []
              destination_addresses = ["10.195.21.167"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-mft-prod-canadacentral-001"
          priority = 5080
          action   = "Allow"
          rule = [
            {
              name                  = "r-deny-vnet-mft-prod-canadacentral-001"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-mft-prod-canadacentral-001"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
      ]
      application_rule_collection = [

      ]
    }
    "azfwpol-connectivity-001/rcg-20000-spoke-specific-canada-east" = {
      name       = "rcg-20000-spoke-specific-canada-east"
      policy_key = "azfwpol-connectivity-001"
      priority   = 20000
      network_rule_collection = [
        {
          name     = "rc-deny-vnet-ertest-canadaeast-001-inbound"
          priority = 20390
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-ertest-canadaeast-001-inbound"
              protocols             = ["Any"]
              source_addresses      = ["10.196.114.0/23"]
              source_ip_groups      = []
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-spo-nonprod-canadaeast-in"
          priority = 20590
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-vnet-spo-nonprod-canadaeast-in"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-spo-nonprod-canadaeast"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-spo-nonprod-canadaeast-in"
          priority = 20490
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-vnet-spo-nonprod-ce-to-kv-cc"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-spo-nonprod-canadaeast"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-kv-spo-nonprod-cc"].resource_id]
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-spo-prod-canadaeast-001-in"
          priority = 20790
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-vnet-spo-prod-canadaeast-001-in"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-spo-prod-canadaeast-001"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-spo-prod-canadaeast-001-in"
          priority = 20610
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-spo-prod-canadaeast-to-keyvault"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-spo-prod-canadaeast-001"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-kvspoprod-canadacentral-001"].resource_id]
              destination_ports     = ["443"]
            },
          ]
        },
      ]
      application_rule_collection = [

      ]
    }
    "azfwpol-connectivity-001/rcg-39800-transit-to-spoke" = {
      name       = "rcg-39800-transit-to-spoke"
      policy_key = "azfwpol-connectivity-001"
      priority   = 39800
      network_rule_collection = [
        {
          name     = "rc-deny-vnet-transit-connectivity-canadacentral-inbound"
          priority = 39880
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-vnet-transit-connectivity-canadacentral-inbound"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-transit-connectivity-canadacentral"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-transit-connectivity-canadacentral-in"
          priority = 39810
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-snet-auritas-nonprod-canadacentral"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-transit-connectivity-canadacentral"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-auritas-nonprod-canadacentral"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-ns2-to-auritas-nonprod"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cc-ns2-subnet"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-auritas-nonprod-canadacentral"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-snet-auritas-prod-canadacentral"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-transit-connectivity-canadacentral"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-auritas-prod-canadacentral"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-ns2-to-auritas-prod"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cc-ns2-subnet"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-auritas-prod-canadacentral"].resource_id]
              destination_ports     = ["443"]
            },
          ]
        },
      ]
      application_rule_collection = [

      ]
    }
    "azfwpol-connectivity-001/rcg-40000-onprem-to-spokes" = {
      name       = "rcg-40000-onprem-to-spokes"
      policy_key = "azfwpol-connectivity-001"
      priority   = 40000
      network_rule_collection = [
        {
          name     = "rc-allow-net-onprem-to-east"
          priority = 40200
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-icmp"
              protocols             = ["ICMP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-allow-net-onprem-to-central"
          priority = 40100
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-icmp"
              protocols             = ["ICMP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id]
              destination_ports     = ["*"]
            },
            {
              name                  = "r-allow-pta-nonprod-apps"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-nonprod-pta-apps"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-pta-nonprod-db"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-to-clzdb-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-nonprod-pta-db"].resource_id]
              destination_ports     = ["1433", "11000-11999"]
            },
            {
              name                  = "r-allow-cops-nonprod-db"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-to-clzdb-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-nonprod-cops-db"].resource_id]
              destination_ports     = ["1433", "11000-11999"]
            },
            {
              name                  = "r-allow-cops-nonprod-apps"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-nonprod-cops-apps"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-fit-apps"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-nonprod-fit-apps"].resource_id, module.ip_group["ipgrp-cacentral-prod-fit-apps"].resource_id]
              destination_ports     = ["443", "1521"]
            },
            {
              name                  = "r-allow-esb-fit-nonprod-1"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.47.1"]
              source_ip_groups      = []
              destination_addresses = ["10.195.80.4"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["22734", "23738", "443"]
            },
            {
              name                  = "r-allow-esb-to-fit-nonprod-2"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.47.2", "10.242.94.14"]
              source_ip_groups      = []
              destination_addresses = ["10.195.80.4"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["23734", "23738", "443"]
            },
            {
              name                  = "r-allow-pta-prod-apps"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-prod-pta-apps"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-pta-prod-db"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-to-clzdb-subnets"].resource_id, module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-prod-pta-db"].resource_id]
              destination_ports     = ["443", "1433", "11000-11999"]
            },
            {
              name                  = "r-allow-esb-to-fit-nonprod-3"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.94.14"]
              source_ip_groups      = []
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-nonprod-fit-apps"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-UAG-to-fit-nonprod"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.234.34", "10.242.234.33"]
              source_ip_groups      = []
              destination_addresses = ["10.195.80.4"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-UAG-to-fit-prod"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.234.34", "10.242.234.33"]
              source_ip_groups      = []
              destination_addresses = ["10.195.32.4"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-kdcdbmontr-to-fit-prod-db"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.83.115"]
              source_ip_groups      = []
              destination_addresses = ["10.195.33.4"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["1521", "22", "3872"]
            },
            {
              name                  = "r-allow-tkdcdbmontr-to-fit-nonprod-db"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.83.125"]
              source_ip_groups      = []
              destination_addresses = ["10.195.81.4"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["1521", "22", "3872"]
            },
            {
              name                  = "r-allow-esb-to-fit-prod"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.94.14"]
              source_ip_groups      = []
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-prod-fit-apps"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-mds-https"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-mds-ips"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-bch-onprem-subnets-to-cyberark"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-cyberark-vnet"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-bch-to-openai-nonprod"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-app-openai-nonprod-canadacentral-001"].resource_id, module.ip_group["ipgrp-func-openai-nonprod-canadacentral-001"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-bch-to-auritas-nonprod-web-fun"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-auritas-nonprod-canadacentral"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-mds-logging-https"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-clz-monitor-ips"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-bch-to-openai-prod"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-app-openai-prod-canadacentral-001"].resource_id, module.ip_group["ipgrp-func-openai-prod-canadacentral-001"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-onprem-sap-aem-9443"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.33.41", "10.242.33.42", "10.242.33.40", "10.242.33.44", "10.242.33.45", "10.242.33.46", "10.242.33.43", "10.242.33.47", "10.242.33.50"]
              source_ip_groups      = []
              destination_addresses = ["10.195.112.0/24"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["9443"]
            },
            {
              name                  = "r-allow-bch-to-auritas-prod-web-fun"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-auritas-prod-canadacentral"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-esb-dev-to-solace-eam"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.94.44"]
              source_ip_groups      = []
              destination_addresses = ["10.195.112.8"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["55443", "443", "5671", "8883", "8443", "9443", "943"]
            },
            {
              name                  = "r-allow-bch-to-pep-stfabricprodcac001"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-stfabricprodcac001"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-bch-to-pep-kvfabricprodcac001"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-kvfabricprodcac001"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-siops-to-stazfwpkcapture"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-bchsiops-jumphost"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-stazpkcapture-prod-canadacentral-001"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-bch-to-spo-nonprod-https"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-kv-spo-nonprod-cc"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-bch-to-keyvault"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-kvspoprod-canadacentral-001"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-bch-to-stfabricnonprodca-nonprod-https"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-stfabricnonprodcac001"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-bch-to-kvfabricnonprodcc001-nonprod-https"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-kvfabricnonprodcc001"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-bch-to-vm-fabric-nonprod-canadacentral-001-rdp"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-pep-kdcazdevjumpp1"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-vm-fabric-nonprod-canadacentral-001"].resource_id]
              destination_ports     = ["3389"]
            },
            {
              name                  = "r-allow-bch-vpn-to-mi-sql-pta-nonprod-cc"
              protocols             = ["TCP"]
              source_addresses      = ["10.244.128.0/18", "10.242.0.0/17", "10.244.0.0/19"]
              source_ip_groups      = []
              destination_addresses = ["10.195.66.10"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["1433"]
            },
            {
              name                  = "r-allow-bch-to-vm-fabric-prod-canadacentral-001-rdp"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-pep-kdcazdevjumpp1"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-vm-fabric-prod-canadacentral"].resource_id]
              destination_ports     = ["3389"]
            },
            {
              name                  = "r-allow-esb-nprd-ora-to-tibco-mft"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.94.121", "10.242.94.92"]
              source_ip_groups      = []
              destination_addresses = ["10.195.126.20"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["8443"]
            },
            {
              name                  = "r-allow-esb-dropbox-to-tibco-mft"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.94.7"]
              source_ip_groups      = []
              destination_addresses = ["10.195.126.20"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-net-onprem-to-tibco-mft"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = ["10.195.126.20"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["8001"]
            },
            {
              name                  = "r-allow-onprem-oms-to-tibco-aem"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.239.41", "10.242.74.88", "10.242.74.89"]
              source_ip_groups      = []
              destination_addresses = ["10.195.112.8"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["55443", "9443", "8883", "5671", "443"]
            },
            {
              name                  = "r-allow-onprem-eas-to-tibco-aem"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.82.164", "10.242.82.160"]
              source_ip_groups      = []
              destination_addresses = ["10.195.112.8"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["55443", "9443", "8883", "5671"]
            },
            {
              name                  = "r-allow-esb-dropbox-to-aem-dev"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.94.44"]
              source_ip_groups      = []
              destination_addresses = ["10.195.112.15"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443", "55443", "5671", "8883", "8443", "9443", "943"]
            },
            {
              name                  = "r-allow-esb-dropbox-to-aem-dev-2"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.94.13", "10.242.94.14", "10.242.94.17", "10.242.94.18"]
              source_ip_groups      = []
              destination_addresses = ["10.195.112.8", "10.195.112.15"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443", "55443"]
            },
            {
              name                  = "r-allow-bch-clzjmp-to-web-scraping-servers"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.112.11", "10.242.112.1", "10.242.112.4"]
              source_ip_groups      = []
              destination_addresses = ["10.195.68.39", "10.195.68.40", "10.195.68.41"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-onprem-informatica-to-fileshare-pep"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.95.60", "10.242.82.160", "10.242.82.164"]
              source_ip_groups      = []
              destination_addresses = ["10.195.68.101"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["445"]
            },
            {
              name                  = "r-allow-clzdevjmp-to-boundary-servers"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.112.11", "10.242.112.1"]
              source_ip_groups      = []
              destination_addresses = ["10.195.68.71", "10.195.68.101", "10.195.68.102"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443", "445"]
            },
            {
              name                  = "r-allow-clzjmp-to-ecsi-pep"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.112.7", "10.242.112.9"]
              source_ip_groups      = []
              destination_addresses = ["10.195.69.198", "10.195.69.199", "10.195.69.200", "10.195.69.201"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-bch-to-ecsi-app-sep"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = ["10.195.69.198"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-appservicesubnet-to-keyvault-https"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-pep-kdcbchpsdbp02"].resource_id, module.ip_group["ipgrp-pep-kdcbchsqlp01"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-pei-key-vault-private-endpoint-ip"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-bch-to-pea-private-endpoints"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-pei-appservice-private-endpoint-ip"].resource_id, module.ip_group["ipgrp-cacentral-pei-sql-private-endpoint-ip"].resource_id, module.ip_group["ipgrp-cacentral-pei-key-vault-private-endpoint-ip"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-kdcsqldb-to-keyvault-https "
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-pep-kdcbchpsdbp02"].resource_id, module.ip_group["ipgrp-pep-kdcbchsqlp01"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-pei-key-vault-private-endpoint-ip"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-bch-to-dthree-private-endpoints"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-dethree-sql-endpoint-ip"].resource_id, module.ip_group["ipgrp-cacentral-dethree-key-vault-endpoint-ip"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-kdcsqldb-to-dthree-keyvault-https"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-dethree-SCM-endpoint-ip"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-onprem-subnets-to-cae-cep-dev-canadacentral"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = ["10.195.128.229", "10.195.128.6"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["25725", "25724", "443"]
            },
            {
              name                  = "r-allow-onprem-subnets-to-acr-cep-nprod"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = ["10.195.128.4", "10.195.128.5"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-onprem-subnets-to-azure-fs-smb"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = ["10.195.126.37"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["445"]
            },
            {
              name                  = "r-allow-onprem-subnets-to-azure-archive-blob"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = ["10.195.126.38"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-onprem-subnets-to-azure-sql-db"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = ["10.195.126.39"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["1433"]
            },
            {
              name                  = "r-allow-onprem-subnets-to-azure-key-vault"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = ["10.195.126.36"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-onprem-subnets-to-aem-dev"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = ["10.195.112.8"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["22"]
            },
            {
              name                  = "r-allow-on-prem-msg-broker-to-aem-qas"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.94.44"]
              source_ip_groups      = []
              destination_addresses = ["10.195.112.12"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443", "943", "5671", "8443", "8883", "9443", "55443"]
            },
            {
              name                  = "r-allow-runners-nonprod-to-Boundary-File-Share"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-pep-kdcazdevjumpp1"].resource_id, module.ip_group["ipgrp-pep-kdcazdevjumpp2"].resource_id, module.ip_group["ipgrp-pep-kdcbchclzjmp07"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-func-boundary-test-canadacentral-001"].resource_id, module.ip_group["ipgrp-pep-stboundaryenc001"].resource_id, module.ip_group["ipgrp-pep-kvboundarytestcac001"].resource_id, module.ip_group["ipgrp-pep-appcs-boundary-test-canadacentral-001"].resource_id]
              destination_ports     = ["443", "445"]
            },
            {
              name                  = "r-allow-Web-Scraping-Storage-Private-Endpoint-https"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-pep-kdcazdevjumpp1"].resource_id, module.ip_group["ipgrp-pep-kdcazdevjumpp2"].resource_id, module.ip_group["ipgrp-pep-kdcbchclzjmp07"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-stwraptestcc001"].resource_id, module.ip_group["ipgrp-pep-kvwraptestcc001"].resource_id, module.ip_group["ipgrp-pep-func-wrap-test-canadacentral-001"].resource_id, module.ip_group["appcs-wrap-test-canadacentral-001"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-kdcbchclzjmp09-to-ecsi2-endpoint-test"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-pep-kdcbchclzjmp09"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-dethree-endpoints"].resource_id, module.ip_group["ipgrp-pep-ecsi2-endpoint-test"].resource_id]
              destination_ports     = ["443", "1433"]
            },
            {
              name                  = "r-allow-dts-psl-to-pea-azure-sql"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-pep-kdcbchsqld01"].resource_id, module.ip_group["ipgrp-pep-kdcbchsqlt01"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-pei-sql-private-endpoint-ip"].resource_id]
              destination_ports     = ["1433"]
            },
            {
              name                  = "r-allow-KDCBCHCLZJMP10-to-PEA-endpoints"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-pep-kdcbchclzjmp09"].resource_id, module.ip_group["ipgrp-pep-kdcbchclzjmp02"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-pea-private-endpoint"].resource_id]
              destination_ports     = ["443", "1433"]
            },
            {
              name                  = "r-allow-jumpserver-to-dthree-peps"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-pep-kdcbchclzjmp07"].resource_id, module.ip_group["backup_cc/ipgrp-pep-kdcspesewec1"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-dethree-endpoints"].resource_id]
              destination_ports     = ["443", "1433"]
            },
            {
              name                  = "r-allow-on-premdb-to-azuresql-mi-db"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.69.86", "10.242.82.32", "10.242.82.31", "10.242.82.33"]
              source_ip_groups      = []
              destination_addresses = ["10.195.69.41"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["1433"]
            },
            {
              name                  = "r-allow-jumpservers-to-azuresql-mi-db"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.112.6", "10.242.112.13"]
              source_ip_groups      = []
              destination_addresses = ["10.195.69.41"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443", "1433"]
            },
            {
              name                  = "r-allow-onprem-kidc-jmp-srv-to-ecsi-pvt-endpts"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.112.7", "10.242.112.9"]
              source_ip_groups      = []
              destination_addresses = ["10.195.69.198", "10.195.69.199", "10.195.69.200", "10.195.69.201"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443", "1433"]
            },
            {
              name                  = "r-allow-onprem-subnets-to-cns-pvt-endpts"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.112.7", "10.242.112.9", "10.242.112.13"]
              source_ip_groups      = []
              destination_addresses = ["10.195.70.69", "10.195.70.71", "10.195.70.72", "10.195.70.73"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["1433", "443"]
            },
            {
              name                  = "r-allow-onprem-subnets-to-azure-app-service-endpt"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = ["10.195.70.69"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["1433", "443"]
            },
            {
              name                  = "r-allow-tkdcdbmontr-to-vnet-gom-test-1521-22-3872"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-tkdcdbmontr"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-vnet-gom-test-canadacentral"].resource_id]
              destination_ports     = ["1521", "22", "3872"]
            },
            {
              name                  = "r-allow-kdcjumphost-to-ipgrp-Azure-GOM-VM-DB-338-1521-2485"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-pep-kdcbchclzjmp08"].resource_id, module.ip_group["ipgrp-pep-kdcazdevjumpp1"].resource_id, module.ip_group["ipgrp-pep-kdcazdevjumpp2"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-vnet-gom-test-canadacentral"].resource_id, module.ip_group["ipgrp-Azure-GOM-VM-DB"].resource_id]
              destination_ports     = ["3389", "1521", "2485"]
            },
            {
              name                  = "r-allow-bch-network-to-ipgrp-Azure-GOM-VM-DB-2484 "
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-Azure-GOM-VM-DB"].resource_id]
              destination_ports     = ["2484"]
            },
            {
              name                  = "r-allow-onprem-subnets-to-pei-sql-1433-11000-11999"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-pep-kdcbchpsdbp02"].resource_id, module.ip_group["ipgrp-pep-kdcbchsqlp01"].resource_id, module.ip_group["ipgrp-pep-kdcbchsqld01"].resource_id, module.ip_group["ipgrp-pep-kdcbchsqlt01"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-pei-sql-endpoint"].resource_id]
              destination_ports     = ["1433", "11000-11999"]
            },
            {
              name                  = "r-allow-jumphost-to-pei-sql-1433-11000-11999"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-pep-kdcbchclzjmp02"].resource_id, module.ip_group["ipgrp-pep-kdcbchclzjmp09"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-pei-sql-endpoint"].resource_id]
              destination_ports     = ["443", "1433", "11000-11999"]
            },
            {
              name                  = "r-allow-onprem-jmphosts-to-app-srvcs-pvt-endpts"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.112.1", "10.242.112.2", "10.242.112.10"]
              source_ip_groups      = []
              destination_addresses = ["10.195.73.103", "10.195.73.104", "10.195.73.105"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-onprem-wrkstns-to-azure-app-service-endpt"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = ["10.195.73.103"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-bch-jumphost-lims-sql-1433"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-pep-kdcbchclzjmp09"].resource_id, module.ip_group["ipgrp-pep-kdcbchclzjmp01"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-lims-sql-endpoint"].resource_id, module.ip_group["ipgrp-lims-sql-endpoint"].resource_id]
              destination_ports     = ["1433"]
            },
            {
              name                  = "r-allow-bch-jumphost-lims-dev-win-3389 "
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-pep-kdcbchclzjmp01"].resource_id, module.ip_group["ipgrp-pep-kdcbchclzjmp06"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-lims-dev-win-vm"].resource_id, module.ip_group["ipgrp-azure-staging-vm"].resource_id]
              destination_ports     = ["3389"]
            },
            {
              name                  = "r-allow-bch-network-lims-dev-win-443"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-lims-dev-win-vm"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-kdcejasut1-lims-dev-win-151110"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-pep-kdcejasut1"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-lims-dev-win-vm"].resource_id]
              destination_ports     = ["15110"]
            },
            {
              name                  = "r-allow-kdcendbt1-lims-dev-win-1521"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-pep-kdcendbt1"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-lims-dev-win-vm"].resource_id]
              destination_ports     = ["1521"]
            },
            {
              name                  = "r-allow-kdcbchlimsdcc1-lims-dev-win-11080"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-pep-kdcbchlimsdcc1"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-lims-dev-win-vm"].resource_id]
              destination_ports     = ["11080"]
            },
            {
              name                  = "r-allow-kdcbchepo1-lims-dev-win-smtp-8883 "
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-pep-kdcbchepo1"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-lims-dev-win-vm"].resource_id]
              destination_ports     = ["25", "8883"]
            },
            {
              name                  = "r-allow-kdcjumphost-webscrapping-resources-443"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-pep-kdcbchclzjmp07"].resource_id, module.ip_group["ipgrp-pep-kdcazdevjumpp1"].resource_id, module.ip_group["ipgrp-pep-kdcazdevjumpp2"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-stwraptestcc001"].resource_id, module.ip_group["ipgrp-pep-kvwraptestcc001"].resource_id, module.ip_group["ipgrp-pep-func-wrap-test-canadacentral-001"].resource_id, module.ip_group["appcs-wrap-test-canadacentral-001"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-bch-onprem-subnet-gom-storageblob-https "
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-gom-storageblob"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-onprem-subnets-to-aem-dev-qa-servers"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = ["10.195.112.8", "10.195.112.12"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["55443", "9443", "8443", "8883", "5671", "943", "443"]
            },
            {
              name                  = "r-allow-onprem-subnets-to-mft-dev-server"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = ["10.195.126.20"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-bch-to-finops-https"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-bchydrofinops-vnet-canadacentral"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-bch-to-app-citt-dev-https"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-app-citt-dev-canadacentral001-pe"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-bch-jump-to-app-citt-dev"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-pep-kdcbchclzjmp02"].resource_id, module.ip_group["ipgrp-pep-kdcbchclzjmp09"].resource_id]
              destination_addresses = ["10.195.129.182", "10.195.129.183", "10.195.129.184", "10.195.129.185"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443", "1433"]
            },
            {
              name                  = "r-allow-kdcbchpsdbd02-sql-pei-1433"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-pep-kdcbchpsdbd02"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-pei-sql-endpoint"].resource_id]
              destination_ports     = ["1433"]
            },
            {
              name                  = "r-allow-kdcbchbidgt-azure-kvfabric-nonprodcc01-https"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-pep-kdcbchbidgt1"].resource_id, module.ip_group["ipgrp-pep-kdcbchbidgt2"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-kvfabricnonprodcc001"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-kdcbchbidgt-azure-kvfabric-prodcac01-https"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-pep-kdcbchbidgp1"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-kvfabricprodcac001"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-kdcbchclzjmp02-09-pea-endpoints-https-1433"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-pep-kdcbchclzjmp02"].resource_id, module.ip_group["ipgrp-pep-kdcbchclzjmp09"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pea-keyvault-qa"].resource_id, module.ip_group["ipgrp-pea-appconfig-qa"].resource_id, module.ip_group["ipgrp-pea-app-qa"].resource_id, module.ip_group["ipgrp-db-pea-qa"].resource_id]
              destination_ports     = ["443", "1433"]
            },
            {
              name                  = "r-allow-kdcdbq02-sqlt01-pea-mi-qa-https-1433"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-kdcbchpsdbq02"].resource_id, module.ip_group["ipgrp-pep-kdcbchsqlt01"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-db-pea-qa"].resource_id]
              destination_ports     = ["443", "1433"]
            },
            {
              name                  = "r-allow-bch-onprem-jumphost01-to-dthree-app-endpoint"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.112.4"]
              source_ip_groups      = []
              destination_addresses = ["10.195.68.139", "10.195.68.138"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443", "2049", "445"]
            },
            {
              name                  = "r-allow-bch-onprem-jumphost03-to-pea-app-endpoint"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.112.6"]
              source_ip_groups      = []
              destination_addresses = ["10.195.69.6"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-bch-onprem-jumphost04-and-06-to-cns-ecsi-app-endpoints"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.112.7", "10.242.112.9"]
              source_ip_groups      = []
              destination_addresses = ["10.195.70.75", "10.195.69.205"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-bch-jumphost-GOM-Keyvault-https"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-pep-kdcazdevjumpp2"].resource_id, module.ip_group["ipgrp-pep-kdcazdevjumpp1"].resource_id, module.ip_group["ipgrp-pep-kdcbchclzjmp08"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-gom-keyvault"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-bch-jumphost-GOM-Storageblob-ssh"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-pep-kdcazdevjumpp1"].resource_id, module.ip_group["ipgrp-pep-kdcazdevjumpp2"].resource_id, module.ip_group["ipgrp-pep-kdcbchclzjmp08"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-pep-gom-storageblob"].resource_id]
              destination_ports     = ["22"]
            },
            {
              name                  = "r-allow-bch-jumphost-GOM-oracle-vm-ssh"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-pep-kdcazdevjumpp2"].resource_id, module.ip_group["ipgrp-pep-kdcazdevjumpp1"].resource_id, module.ip_group["ipgrp-pep-kdcbchclzjmp08"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-Azure-GOM-VM-DB"].resource_id]
              destination_ports     = ["22"]
            },
            {
              name                  = "r-allow-kdcspesewec1-dethree-Storage-endpoint-ip-https-smb"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["backup_cc/ipgrp-pep-kdcspesewec1"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-dethree-Storage-endpoint-ip"].resource_id]
              destination_ports     = ["443", "445"]
            },
            {
              name                  = "r-allow-bch-onprem-jumphost02-to-azure-key-vault-endpoint"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.112.5"]
              source_ip_groups      = []
              destination_addresses = ["10.195.132.70"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-bch-onprem-jumphost03&10-to-all-shipd-nonprod-endpoints"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.112.6", "10.242.112.13"]
              source_ip_groups      = []
              destination_addresses = ["10.195.122.198", "10.195.122.230", "10.195.122.231", "10.195.122.232"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443", "1433"]
            },
            {
              name                  = "r-allow-bch-onprem-all-subnets-to-shipd-nonprod-endpoint"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = ["10.195.122.198"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443", "1433"]
            },
            {
              name                  = "r-allow-bch-onprem-all-subnets-to-pep-stweb-gom-test-canadacentral"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = ["10.195.70.168"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-bch-onprem-jumphost01-02-09-to-pep-stweb-gom-test-canadacentral"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.112.1", "10.242.112.2", "10.242.112.12"]
              source_ip_groups      = []
              destination_addresses = ["10.195.70.168"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-KDCFNAPD2-ipgrp-snet-app-lims-dev-https"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-kdcfnapd2"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-snet-app-lims-dev-canadacentral-001"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-bch-onprem-jumphost03-to-vm-runners-dev-canadacentral-001"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.112.4"]
              source_ip_groups      = []
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-vnet-githubrunner-nonprod-canadacentral"].resource_id]
              destination_ports     = ["22", "443", "445", "2049", "8000"]
            },
            {
              name                  = "r-allow-bch-onprem-jumphost10-to-vm-oracledb-gom-test-canadacentral"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.112.13"]
              source_ip_groups      = []
              destination_addresses = ["10.195.70.135"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["22", "1521", "2484", "2485"]
            },
            {
              name                  = "r-allow-bch-onprem-jumphost10-to-pep-kv-gom-test-canadacentral"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.112.13"]
              source_ip_groups      = []
              destination_addresses = ["10.195.70.166"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-bch-onprem-jumphost10-to-pep-st-gom-test-canadacentral"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.112.13"]
              source_ip_groups      = []
              destination_addresses = ["10.195.70.167"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["22", "443"]
            },
            {
              name                  = "r-allow-bch-onprem-jumphost10-to-pep-stweb-gom-test-canadacentral"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.112.13"]
              source_ip_groups      = []
              destination_addresses = ["10.195.70.168"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-bch-onprem-all-subnets-to-snet-sharedsvc-nonprod"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-vnet-sharedsvc-nonprod-gw-canadacentral-001"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-on-prem-to-clz-ad-rep-tcp"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-bchydro-adroot-ad-servers"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-bchydro-adroot-ad-servers-azure"].resource_id]
              destination_ports     = ["135", "3268", "3269", "389", "445", "464", "49152-65535", "53", "53", "5722", "636", "88", "9389"]
            },
            {
              name                  = "r-allow-on-prem-to-clz-ad-rep-udp"
              protocols             = ["UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-bchydro-adroot-ad-servers"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-bchydro-adroot-ad-servers-azure"].resource_id]
              destination_ports     = ["123", "389", "445", "464", "88"]
            },
            {
              name                  = "r-allow-bch-onprem-jumphost0-02-11-to-azure-blob-storage"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.112.1", "10.242.112.2", "10.242.112.11"]
              source_ip_groups      = []
              destination_addresses = ["10.195.68.105"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-bch-onprem-subnet-lims-staging-vm"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-azure-staging-vm"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-bch-ibm-filenet-staging-lims-staging-vm-15110-15101"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-w3tecm"].resource_id, module.ip_group["ipgrp-kdcejasus1"].resource_id, module.ip_group["ipgrp-kdcejasus2"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-azure-staging-vm"].resource_id]
              destination_ports     = ["15110", "15101"]
            },
            {
              name                  = "r-allow-bchkdcfndbs1-lims-staging-vm-1521"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-kdcfndbs1"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-azure-staging-vm"].resource_id]
              destination_ports     = ["1521"]
            },
            {
              name                  = "r-allow-kdcbchlimsscc1-lims-staging-vm-11080"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-kdcbchlimsscc1"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-azure-staging-vm"].resource_id]
              destination_ports     = ["11080"]
            },
            {
              name                  = "r-allow-kdcbchepo1-lims-staging-vm-smtp"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-pep-kdcbchepo1"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-azure-staging-vm"].resource_id]
              destination_ports     = ["25"]
            },
            {
              name                  = "r-allow-kdcbchepotie2-lims-staging-vm-8883"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-kdcbchepotie2"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-azure-staging-vm"].resource_id]
              destination_ports     = ["8883"]
            },
            {
              name                  = "r-allow-"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-pep-kdcbchclzjmp01"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-key-vault-endpoint"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-kdcjumphost-dev-BEP-function-app"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-pep-kdcbchclzjmp07"].resource_id, module.ip_group["ipgrp-pep-kdcazdevjumpp1"].resource_id, module.ip_group["ipgrp-pep-kdcazdevjumpp2"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-bep-function-app"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-kdcjumphost-dev-BEP-file-share-smb"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-pep-kdcbchclzjmp07"].resource_id, module.ip_group["ipgrp-pep-kdcazdevjumpp1"].resource_id, module.ip_group["ipgrp-pep-kdcazdevjumpp2"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-BEP-fileshare-vm"].resource_id]
              destination_ports     = ["445"]
            },
            {
              name                  = "r-allow-kdcjumphost-dev-BEP-APP-Configuration"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-pep-kdcbchclzjmp07"].resource_id, module.ip_group["ipgrp-pep-kdcazdevjumpp1"].resource_id, module.ip_group["ipgrp-pep-kdcazdevjumpp2"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-BEP-app-config"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-kdcjumphost-dev-BEP-key-vault"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-pep-kdcbchclzjmp07"].resource_id, module.ip_group["ipgrp-pep-kdcazdevjumpp1"].resource_id, module.ip_group["ipgrp-pep-kdcazdevjumpp2"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-bep-keyvault"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-kdcjumphost-dev-BEP-blob-storage"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-pep-kdcbchclzjmp07"].resource_id, module.ip_group["ipgrp-pep-kdcazdevjumpp1"].resource_id, module.ip_group["ipgrp-pep-kdcazdevjumpp2"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-bep-blob-storage"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-EDMBCHINF1-BEP-fileshare-smb"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-edmbchinf1"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-BEP-fileshare-vm"].resource_id]
              destination_ports     = ["445"]
            },
            {
              name                  = "r-allow-bch-onprem-jumphost1-02-08-to-azure-app-and-keyvault"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.112.1", "10.242.112.2", "10.242.112.11"]
              source_ip_groups      = []
              destination_addresses = ["10.195.21.166", "10.195.21.167", "10.195.21.168", "10.195.21.169"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-bch-onprem-jumphost1-02-07-to-azure-app-cswt-prod-app-and-keyvault"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.112.1", "10.242.112.2", "10.242.112.10"]
              source_ip_groups      = []
              destination_addresses = ["10.195.20.229", "10.195.20.230"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-bch-onprem--to-azure-app-cswt-prod-app"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = ["10.195.20.229"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
          ]
        },
      ]
      application_rule_collection = [

      ]
    }
    "azfwpol-connectivity-001/rcg-490-global-security-rexception" = {
      name       = "rcg-490-global-security-rexception"
      policy_key = "azfwpol-connectivity-001"
      priority   = 490
      network_rule_collection = [
        {
          name     = "rc-allow-rexception-services"
          priority = 495
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-cyberark-to-windows-vms-tcp135"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cyberark-vm-ips"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_ports     = ["135"]
            },
          ]
        },
      ]
      application_rule_collection = [

      ]
    }
    "azfwpol-connectivity-001/rcg-500-global-security-baseline" = {
      name       = "rcg-500-global-security-baseline"
      policy_key = "azfwpol-connectivity-001"
      priority   = 500
      network_rule_collection = [
        {
          name     = "rc-deny-risky-protocols"
          priority = 600
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-telnet"
              protocols             = ["TCP"]
              source_addresses      = ["*"]
              source_ip_groups      = []
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["23"]
            },
            {
              name                  = "r-deny-ftp"
              protocols             = ["TCP"]
              source_addresses      = ["*"]
              source_ip_groups      = []
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["20", "21"]
            },
            {
              name                  = "r-deny-tftp"
              protocols             = ["UDP"]
              source_addresses      = ["*"]
              source_ip_groups      = []
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["69"]
            },
            {
              name                  = "r-deny-netbios"
              protocols             = ["TCP"]
              source_addresses      = ["*"]
              source_ip_groups      = []
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["137", "138"]
            },
            {
              name                  = "r-deny-rpc"
              protocols             = ["TCP"]
              source_addresses      = ["*"]
              source_ip_groups      = []
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["135"]
            },
          ]
        },
      ]
      application_rule_collection = [

      ]
    }
    "azfwpol-connectivity-001/rcg-64900-deny-all" = {
      name       = "rcg-64900-deny-all"
      policy_key = "azfwpol-connectivity-001"
      priority   = 64900
      network_rule_collection = [
        {
          name     = "rc-deny-network"
          priority = 64910
          action   = "Deny"
          rule = [
            {
              name                  = "rc-deny-network"
              protocols             = ["Any"]
              source_addresses      = ["*"]
              source_ip_groups      = []
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
      ]
      application_rule_collection = [
        {
          name     = "rc-deny-applications"
          priority = 64920
          action   = "Deny"
          rule = [
            {
              name                  = "rc-deny-applications"
              source_addresses      = ["*"]
              source_ip_groups      = []
              destination_fqdns     = ["*"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = true
              protocols             = [{ type = "Https", port = 443 }, { type = "Mssql", port = 1433 }]
            },
          ]
        },
      ]
    }
    "azfwpol-connectivity-001/rcg-800-global-internet-baseline" = {
      name       = "rcg-800-global-internet-baseline"
      policy_key = "azfwpol-connectivity-001"
      priority   = 800
      network_rule_collection = [
        {
          name     = "rc-allow-tagbased-services"
          priority = 820
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-azure-services"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = ["AzurePortal", "AzureCloud", "LogicApps", "AzureFrontDoor.Frontend", "AzureFrontDoor.FirstParty", "AzureFrontDoor.Backend", "AzureFrontDoor.Infra", "AzureFrontDoor.MicrosoftSecurity", "AzureActiveDirectory", "AzureResourceManager", "AppService", "Storage", "AzureKeyVault", "AppConfiguration"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443", "445"]
            },
            {
              name                  = "r-allow-azure-monitor"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = ["AzureMonitor", "AzureSentinel", "KustoAnalytics", "ActionGroup", "LogicAppsManagement", "AppServiceManagement"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-sql-services"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = ["Sql", "SqlManagement"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-allow-fqdnbased-services"
          priority = 830
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-microsoft-nuget"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["dotnet.microsoft.com", "download.microsoft.com", "api.nuget.org", "www.nuget.org", "nuget.org", "azuresearch-usnc.nuget.org", "azuresearch-ussc.nuget.org", "licenses.nuget.org", "nuget.cdn.azure.cn", "azuresearch-ea.nuget.org", "azuresearch-sea.nuget.org", "crl3.digicert.com", "crl4.digicert.com", "ocsp.digicert.com", "cacerts.digicert.com", "registry.npmjs.org", "nodejs.org", "dist.nuget.org", "skimdb.npmjs.com", "api.npms.io", "eslint.org", "gradle.org"]
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-smsgateway"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["secure.smsgateway.ca"]
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-servicenow"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["bchydrodev.service-now.com", "bchydroqa.service-now.com", "bchydrouat.service-now.com", "bchydro.service-now.com"]
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-windows-update"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["windowsupdate.microsoft.com", "windowsupdate.microsoft.com", "update.microsoft.com", "windowsupdate.com", "download.windowsupdate.com", "download.microsoft.com", "wustat.windows.com", "ntservicepack.microsoft.com"]
              destination_ip_groups = []
              destination_ports     = ["80", "443"]
            },
            {
              name                  = "r-allow-ntp"
              protocols             = ["UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["time.windows.com"]
              destination_ip_groups = []
              destination_ports     = ["123"]
            },
            {
              name                  = "r-allow-windows-kms"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["kms.core.windows.net"]
              destination_ip_groups = []
              destination_ports     = ["1688"]
            },
            {
              name                  = "r-allow-cyberark-certs"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-caeast-clz-subnets"].resource_id, module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["support.sectigo.com"]
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-cyberark-ssh-to-dogwood"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-caeast-clz-subnets"].resource_id, module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["dogwood.ssh.cyberark.cloud"]
              destination_ip_groups = []
              destination_ports     = ["22"]
            },
          ]
        },
        {
          name     = "rc-allow-ipbased-services"
          priority = 810
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-ntp"
              protocols             = ["UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = ["168.61.215.74"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["123"]
            },
            {
              name                  = "r-allow-dns-inbound"
              protocols             = ["UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-infoblox"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-clz-dns-resolvers"].resource_id]
              destination_ports     = ["53"]
            },
            {
              name                  = "r-allow-dns-outbound"
              protocols             = ["UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-onprem-controllers"].resource_id]
              destination_ports     = ["53"]
            },
            {
              name                  = "r-allow-dns-azure"
              protocols             = ["UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-clz-dns-resolvers"].resource_id]
              destination_ports     = ["53"]
            },
            {
              name                  = "r-allow-github-actions"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = ["4.175.114.51/32", "20.102.35.120/32", "4.175.114.43/32", "20.72.125.48/32", "20.19.5.100/32", "20.7.92.46/32", "20.232.252.48/32", "52.186.44.51/32", "20.22.98.201/32", "20.246.184.240/32", "20.96.133.71/32", "20.253.2.203/32", "20.102.39.220/32", "20.81.127.181/32", "52.148.30.208/32", "20.14.42.190/32", "20.85.159.192/32", "52.224.205.173/32", "20.118.176.156/32", "20.236.207.188/32", "20.242.161.191/32", "20.166.216.139/32", "20.253.126.26/32", "52.152.245.137/32", "40.118.236.116/32", "20.185.75.138/32", "20.96.226.211/32", "52.167.78.33/32", "20.105.13.142/32", "20.253.95.3/32", "20.221.96.90/32", "51.138.235.85/32", "52.186.47.208/32", "20.7.220.66/32", "20.75.4.210/32", "20.120.75.171/32", "20.98.183.48/32", "20.84.200.15/32", "20.14.235.135/32", "20.10.226.54/32", "20.22.166.15/32", "20.65.21.88/32", "20.102.36.236/32", "20.124.56.57/32", "20.94.100.174/32", "20.102.166.33/32", "20.31.193.160/32", "20.232.77.7/32", "20.102.38.122/32", "20.102.39.57/32", "20.85.108.33/32", "40.88.240.168/32", "20.69.187.19/32", "20.246.192.124/32", "20.4.161.108/32", "20.22.22.84/32", "20.1.250.47/32", "20.237.33.78/32", "20.242.179.206/32", "40.88.239.133/32", "20.121.247.125/32", "20.106.107.180/32", "20.22.118.40/32", "20.15.240.48/32", "20.84.218.150/32"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-github"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = ["140.82.112.0/20", "143.55.64.0/20", "185.199.108.0/22", "192.30.252.0/22", "20.175.192.146/32", "20.175.192.147/32", "20.175.192.149/32", "20.175.192.150/32", "20.199.39.227/32", "20.199.39.228/32", "20.199.39.231/32", "20.199.39.232/32", "20.200.245.241/32", "20.200.245.245/32", "20.200.245.246/32", "20.200.245.247/32", "20.200.245.248/32", "20.201.28.144/32", "20.201.28.148/32", "20.201.28.149/32", "20.201.28.151/32", "20.201.28.152/32", "20.205.243.160/32", "20.205.243.164/32", "20.205.243.165/32", "20.205.243.166/32", "20.205.243.168/32", "20.207.73.82/32", "20.207.73.83/32", "20.207.73.85/32", "20.207.73.86/32", "20.207.73.88/32", "20.217.135.1/32", "20.233.83.145/32", "20.233.83.146/32", "20.233.83.147/32", "20.233.83.149/32", "20.233.83.150/32", "20.248.137.48/32", "20.248.137.49/32", "20.248.137.50/32", "20.248.137.52/32", "20.248.137.55/32", "20.26.156.215/32", "20.26.156.216/32", "20.26.156.211/32", "20.27.177.113/32", "20.27.177.114/32", "20.27.177.116/32", "20.27.177.117/32", "20.27.177.118/32", "20.29.134.17/32", "20.29.134.18/32", "20.29.134.19/32", "20.29.134.23/32", "20.29.134.24/32", "20.87.245.0/32", "20.87.245.1/32", "20.87.245.4/32", "20.87.245.6/32", "20.87.245.7/32", "4.208.26.196/32", "4.208.26.197/32", "4.208.26.198/32", "4.208.26.199/32", "4.208.26.200/32", "4.225.11.196/32", "4.237.22.32/32"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-logging"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-clz-monitor-ips"].resource_id]
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-allow-ipbased-azbchclz-to-onprem"
          priority = 835
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-azbchclz-to-unix-satellite"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-onprem-unix-satellite-servers"].resource_id]
              destination_ports     = ["443"]
            },
          ]
        },
      ]
      application_rule_collection = [
        {
          name     = "rc-allow-fqdnbased-app-services"
          priority = 850
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-cyberark-https"
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cyberark-vm-ips"].resource_id]
              destination_fqdns     = ["*.cyberark.cloud", "*.cyberark.com", "*.privilegecloud.cyberark.cloud", "*.dpa.cyberark.cloud", "*.bc.be-privilege-access.cyberark.cloud", "*.s3.amazonaws.com", "*.s3.ca-central-1.amazonaws.com", "*.ca-central-1.amazonaws.com", "*.iot.ca-central-1.amazonaws.com", "component-registry-store-490081306957.s3.amazonaws.com", "caintegrations.s3.amazonaws.com", "connector-management-scripts-490081306957-ca-central-1.s3.amazonaws.com", "connector-management-assets-490081306957-ca-central-1.s3.amazonaws.com", "cms-assets-bucket-445444212982.s3.amazonaws.com", "cms-assets-bucket-445444212982-ca-central-1.s3.ca-central-1.amazonaws.com", "casoftware.s3.amazonaws.com", "community.cyberark.com", "ca-central-1.bc.be-privilege-access.cyberark.cloud", "dogwood.cyberark.cloud", "dogwood.privilegecloud.cyberark.cloud", "webaccess-dogwood.privilegecloud.cyberark.cloud", "dogwood.webaccess.cyberark.cloud", "dogwood.connectormanagement.cyberark.cloud", "connector-dogwood.privilegecloud.cyberark.cloud", "console.privilegecloud.cyberark.cloud", "dogwood.dpa.cyberark.cloud", "a3vvqcp8z371p3-ats.iot.ca-central-1.amazonaws.com", "a2m4b3cupk8nzj-ats.iot.ca-central-1.amazonaws.com", "pod1402-b1.relay.idaptive.app", "pod1402-b2.relay.idaptive.app", "pod1402-a1.relay.idaptive.app", "pod1402-a2.relay.idaptive.app", "pod0.idaptive.app", "edge.idaptive.app", "ip-ranges.amazonaws.com", "*.relay.idaptive.app", "*.idaptive.app", "*.webaccess.cyberark.cloud", "*.connectormanagement.cyberark.cloud"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = false
              protocols             = [{ type = "Https", port = 443 }]
            },
            {
              name                  = "r-allpw-hosted-runners-to-fit-apps"
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_fqdns     = ["*.appserviceenvironment.net"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = true
              protocols             = [{ type = "Http", port = 80 }, { type = "Https", port = 443 }]
            },
            {
              name                  = "r-allow-cyberark-http"
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cyberark-vm-ips"].resource_id]
              destination_fqdns     = ["crt.r2m02.amazontrust.com", "ocsp.r2m02.amazontrust.com", "privacy-policy.truste.com", "ocsp.verisign.com", "ocsp.globalsign.com", "crl.globalsign.com", "secure.globalsign.com", "ipinfo.io"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = false
              protocols             = [{ type = "Http", port = 80 }]
            },
          ]
        },
        {
          name     = "rc-allow-microsoft-services"
          priority = 840
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-windows-update"
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_fqdns     = ["windowsupdate.microsoft.com", "*.windowsupdate.microsoft.com", "update.microsoft.com", "*.update.microsoft.com", "windowsupdate.com", "*.windowsupdate.com", "download.windowsupdate.com", "*.download.windowsupdate.com", "download.microsoft.com", "wustat.windows.com", "*.wustat.windows.com", "ntservicepack.microsoft.com", "*.delivery.mp.microsoft.com", "*.microsoft.com", "*.windows.com"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = false
              protocols             = [{ type = "Https", port = 443 }, { type = "Http", port = 80 }]
            },
            {
              name                  = "r-allow-azure-services"
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_fqdns     = ["*.azure.com", "*.microsoft.com", "*.azure.net", "*.azurewebsites.net", "*.blob.core.windows.net", "*.queue.core.windows.net", "*.table.core.windows.net"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = true
              protocols             = [{ type = "Https", port = 443 }]
            },
            {
              name                  = "r-allow-azure-monitor"
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_fqdns     = ["*.ods.opinsights.azure.com", "*.oms.opinsights.azure.com", "*.monitoring.azure.com", "api.loganalytics.io", "*.loganalytics.io", "js.monitor.azure.com", "*.monitor.azure.com"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = true
              protocols             = [{ type = "Https", port = 443 }]
            },
            {
              name                  = "r-allow-office365"
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_fqdns     = ["*.office.com", "*.office365.com", "*.outlook.com", "*.sharepoint.com", "*.onedrive.com", "*.teams.microsoft.com"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = true
              protocols             = [{ type = "Https", port = 443 }]
            },
            {
              name                  = "r-allow-app-insights"
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_fqdns     = ["*.applicationinsights.azure.com"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = true
              protocols             = [{ type = "Https", port = 443 }]
            },
            {
              name                  = "r-allow-cops-nonprod-apple-api"
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-nonprod-cops-apps"].resource_id]
              destination_fqdns     = ["api.push.apple.com", "api.sandbox.push.apple.com"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = false
              protocols             = [{ type = "Https", port = 443 }]
            },
            {
              name                  = "r-allow-ms-build-tools"
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_fqdns     = ["*akamaitechnologies.com", "akamaized.net", "go.microsoft.com", "aka.ms", "download.visualstudio.microsoft.com", "download.microsoft.com", "download.visualstudio.com", "marketplace.visualstudio.com", "*.gallerycdn.vsassets.io", "visualstudio.microsoft.com", "learn.microsoft.com", "msdn.microsoft.com", "www.microsoft.com", "*.windows.net", "*.microsoftonline.com", "*.live.com", "github-releases.githubusercontent.com", "objects.githubusercontent.com", "github.com", "az837173.vo.msecnd.net"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = false
              protocols             = [{ type = "Https", port = 443 }]
            },
            {
              name                  = "r-allow-vnet-solace-to-oath2-token-endpt"
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-solace-nonprod-canadacentral"].resource_id, module.ip_group["ipgrp-vnet-solace-prod-canadacentral"].resource_id]
              destination_fqdns     = ["*.microsoftonline.com"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = false
              protocols             = [{ type = "Https", port = 443 }]
            },
            {
              name                  = "r-allow-vnet-cns-nonprod-to-graph.microsoft.com"
              source_addresses      = ["10.195.70.69"]
              source_ip_groups      = []
              destination_fqdns     = ["graph.microsoft.com"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = false
              protocols             = [{ type = "Https", port = 443 }]
            },
            {
              name                  = "r-allow-vnet-app-service-to-microsoftonline"
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-vnet-cswt-test-canadacentral-001"].resource_id]
              destination_fqdns     = ["login.microsoftonline.com", "*.sharepoint.com"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = false
              protocols             = [{ type = "Https", port = 443 }]
            },
            {
              name                  = "r-allow-app-cswt-prod-canadacentral-to-microsoft-services"
              source_addresses      = ["10.195.20.229"]
              source_ip_groups      = []
              destination_fqdns     = ["login.microsoftonline.com", "*.sharepoint.com"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = false
              protocols             = [{ type = "Https", port = 443 }]
            },
          ]
        },
      ]
    }
    "azfwpol-connectivity-001-BACKUP-20260320-233016-UTC/rcg-1000-spoke-specific-canada-central" = {
      name       = "rcg-1000-spoke-specific-canada-central"
      policy_key = "azfwpol-connectivity-001-BACKUP-20260320-233016-UTC"
      priority   = 1000
      network_rule_collection = [
        {
          name     = "rc-allow-vnet-ertest-canadacentral-001-inbound"
          priority = 1210
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-iperf01"
              protocols             = ["TCP", "UDP"]
              source_addresses      = ["10.195.118.7", "10.195.118.8"]
              source_ip_groups      = []
              destination_addresses = ["10.196.114.7", "10.242.69.32", "10.242.69.100", "10.242.69.101", "10.242.69.194", "10.242.69.195", "172.25.6.58"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["5201"]
            },
            {
              name                  = "r-allow-iperf02"
              protocols             = ["ICMP"]
              source_addresses      = ["10.195.118.7", "10.195.118.8"]
              source_ip_groups      = []
              destination_addresses = ["10.196.114.7", "10.242.69.32", "10.242.69.100", "10.242.69.101", "10.242.69.194", "10.242.69.195", "172.25.6.58"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
            {
              name                  = "r-allow-cyberark-to-ertest"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cyberark-vm-ips"].resource_id]
              destination_addresses = ["10.195.118.7", "10.195.118.8", "10.196.114.7"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["135", "445", "3389"]
            },
            {
              name                  = "r-allow-cyberark-to-ertest-linux-vms"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cyberark-vm-ips"].resource_id]
              destination_addresses = ["10.195.116.6", "10.195.116.8"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["22"]
            },
          ]
        },
        {
          name     = "rc-allow-monitoring"
          priority = 1010
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-logging"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-clz-monitor-ips"].resource_id]
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-shared-connectivity-canadacentral-001-inbound"
          priority = 1410
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-sentinel-to-logic-app"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-monitor"].resource_id]
              destination_addresses = ["10.195.6.16"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-hosted-runners-to-loganalytics"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = ["10.195.6.8"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-hosted-runners-to-keyvault-tmp"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = ["10.195.66.4"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-hosted-runners-to-logic-app-tmp"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = ["10.195.6.16"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-cops-nonprod-canadacentral-001-inbound"
          priority = 1610
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-hosted-runners-to-cops-nonprod-dbs-tmp"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-nonprod-cops-db"].resource_id]
              destination_ports     = ["443", "1433", "11000-11999"]
            },
            {
              name                  = "r-allow-hosted-runners-to-cops-nonprod-apps-tmp"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-nonprod-cops-apps"].resource_id]
              destination_ports     = ["80", "443", "8172"]
            },
            {
              name                  = "r-allow-cops-nonprod-to-apple-push"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-nonprod-cops-apps"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["api.push.apple.com", "api.sandbox.push.apple.com"]
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-fit-nonprod-canadacentral-001-inbound"
          priority = 1810
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-hosted-runners-to-fit-nonprod-apps-tmp"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-nonprod-fit-apps"].resource_id]
              destination_ports     = ["80", "443", "8172"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-pta-nonprod-canadacentral-001-inbound"
          priority = 2010
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-hosted-runners-to-pta-nonprod-dbs-tmp"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-nonprod-pta-db"].resource_id]
              destination_ports     = ["443", "1433", "11000-11999"]
            },
            {
              name                  = "r-allow-hosted-runners-to-pta-nonprod-apps-tmp"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-nonprod-pta-apps"].resource_id]
              destination_ports     = ["80", "443", "8172"]
            },
            {
              name                  = "r-allow-hosted-runners-to-pta-nonprod-storage-tmp"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = ["10.195.66.9"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-pta-prod-canadacentral-inbound"
          priority = 2210
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-hosted-runners-to-pta-prod-storage-tmp"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-prod-pta-db"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-hosted-runners-to-pta-prod-dbs-tmp"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-prod-pta-db"].resource_id]
              destination_ports     = ["443", "1433", "11000-11999"]
            },
            {
              name                  = "r-allow-hosted-runners-to-pta-prod-apps-tmp"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-prod-pta-apps"].resource_id]
              destination_ports     = ["80", "443", "8172"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-fit-nonprod-canadacentral-001-outbound"
          priority = 1910
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-fit-nonprod-to-esb-1"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.80.0-10.195.83.254"]
              source_ip_groups      = []
              destination_addresses = ["10.242.47.1"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["22734", "22738", "443"]
            },
            {
              name                  = "r-allow-fit-nonprod-to-esb-2"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.80.0-10.195.83.254"]
              source_ip_groups      = []
              destination_addresses = ["10.242.47.2"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["23734", "23738", "443"]
            },
            {
              name                  = "r-allow-fit-nonprod-db-to-tkdcdbmontr"
              protocols             = ["TCP", "UDP"]
              source_addresses      = ["10.195.81.4"]
              source_ip_groups      = []
              destination_addresses = ["10.242.83.125"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["4903", "22", "3872"]
            },
            {
              name                  = "r-allow-fit-nonprod-db-to-bch-smtp"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.81.4"]
              source_ip_groups      = []
              destination_addresses = ["10.242.35.1"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["25"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-cyberark-canadacentral-001-outbound"
          priority = 2510
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-cyberark-to-cyberarksite"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cyberark-vm-ips"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["www.cyberark.cloud", "abp4127.id.cyberark.cloud", "cyberark.cloud", "cyberark.com", "www.cyberark.com", "community.cyberark.com", "s3.amazonaws.com", "amazonaws.com", "component-registry-store-490081306957.s3.amazonaws.com", "caintegrations.s3.amazonaws.com", "dogwood.cyberark.cloud", "connector-dogwood.privilegecloud.cyberark.cloud", "console.privilegecloud.cyberark.cloud", "dogwood.dpa.cyberark.cloud", "ca-central-1.bc.be-privilege-access.cyberark.cloud", "a3vvqcp8z371p3-ats.iot.ca-central-1.amazonaws.com", "a2m4b3cupk8nzj-ats.iot.ca-central-1.amazonaws.com", "casoftware.s3.amazonaws.com", "dogwood.privilegecloud.cyberark.cloud", "webaccess-dogwood.privilegecloud.cyberark.cloud", "dogwood.webaccess.cyberark.cloud", "dogwood.connectormanagement.cyberark.cloud", "connector-management-scripts-490081306957-ca-central-1.s3.amazonaws.com", "connector-management-assets-490081306957-ca-central-1.s3.amazonaws.com", "pod1402-b1.relay.idaptive.app", "pod1402-b2.relay.idaptive.app", "pod1402-a1.relay.idaptive.app", "pod1402-a2.relay.idaptive.app", "pod0.idaptive.app", "edge.idaptive.app", "cms-assets-bucket-445444212982.s3.amazonaws.com", "cms-assets-bucket-445444212982-ca-central-1.s3.ca-central-1.amazonaws.com", "dogwood.rdp.cyberark.cloud", "dogwood.k8s.cyberark.cloud", "crt.r2m02.amazontrust.com", "ocsp.r2m02.amazontrust.com", "privacy-policy.truste.com", "ocsp.verisign.com", "ocsp.globalsign.com", "crl.globalsign.com", "secure.globalsign.com", "dogwood.ssh.cyberark.cloud", "dogwood.rdp.cyberark.cloud", "dogwood.mariadb.cyberark.cloud", "dogwood.mysql.cyberark.cloud", "dogwood.oracle.cyberark.cloud", "dogwood.postgres.cyberark.cloud", "dogwood.mssql.cyberark.cloud", "dogwood.db2.cyberark.cloud", "dogwood.mongodb.cyberark.cloud", "vault-dogwood.privilegecloud.cyberark.cloud", "ipinfo.io"]
              destination_ip_groups = []
              destination_ports     = ["443", "80", "22", "8443", "3306", "2484", "5432", "1433", "50002", "27017", "1858"]
            },
            {
              name                  = "r-allow-cyberark-1858"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cyberark-vm-ips"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["vault-dogwood.privilegecloud.cyberark.cloud"]
              destination_ip_groups = []
              destination_ports     = ["1858"]
            },
            {
              name                  = "r-allow-cyberark-1858-ip"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cyberark-vm-ips"].resource_id]
              destination_addresses = ["15.223.165.102"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["1858"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-ertest-canadacentral-001-inbound"
          priority = 1390
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-ertest-canadacentral-001-inbound"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-ertest-vnet"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-cyberark-canadacentral-001-inbound"
          priority = 2690
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-vnet-cyberark-canadacentral-001-inbound"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cyberark-vnet"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-dns-connectivity-canadacentral-001-inbound"
          priority = 2890
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-dns-connectivity-canadacentral-001-inbound"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-dns-connectivity-vnet"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-shared-connectivity-canadacentral-001-inbound"
          priority = 1590
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-vnet-shared-connectivity-canadacentral-001-inbound"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-shared-connectivity-vnet"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-cops-nonprod-canadacentral-inbound"
          priority = 1790
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-vnet-cops-nonprod-canadacentral-inbound"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cops-nonprod-vnet"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-fit-nonprod-canadacentral-001-inbound"
          priority = 1990
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-vnet-fit-nonprod-canadacentral-001-inbound"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-fit-nonprod-vnet"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-runners-connectivity-canadacentral-001-inbound"
          priority = 3090
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-vnet-runners-connectivity-canadacentral-001-inbound"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners-vnet"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-cops-prod-canadacentral-inbound"
          priority = 3290
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-vnet-cops-prod-canadacentral-inbound"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cops-prod-vnet"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-fit-prod-canadacentral-001-inbound"
          priority = 3490
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-vnet-fit-prod-canadacentral-001-inbound"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-fit-prod-vnet"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-pta-prod-canadacentral-001-inbound"
          priority = 2390
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-vnet-pta-prod-canadacentral-001-inbound"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-pta-prod-vnet"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-pta-nonprod-canadacentral-001-inbound"
          priority = 2190
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-vnet-pta-nonprod-canadacentral-001-inbound"
              protocols             = ["Any"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-pta-nonprod-vnet"].resource_id]
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-fit-prod-canadacentral-001-outbound"
          priority = 3310
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-fit-prod-db-to-kdcdbmontr"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.33.4"]
              source_ip_groups      = []
              destination_addresses = ["10.242.83.115"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["4903"]
            },
            {
              name                  = "r-allow-fit-prod-db-to-bch-smtp"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.33.4"]
              source_ip_groups      = []
              destination_addresses = ["10.242.35.1"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["25"]
            },
            {
              name                  = "r-allow-fit-prod-to-prod-esb"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-prod-fit-apps"].resource_id]
              destination_addresses = ["10.242.12.161"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["21734", "21738", "443"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-cops-prod-canadacentral-001-outbound"
          priority = 3110
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-cops-prod-to-apple-push"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-prod-cops-apps"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["api.push.apple.com", "api.sandbox.push.apple.com"]
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-fit-prod-canadacentral-001-inbound"
          priority = 1710
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-hosted-runners-to-fit-prod-apps"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-prod-fit-apps"].resource_id]
              destination_ports     = ["80", "443", "8172"]
            },
          ]
        },
        {
          name     = "rc-allow-runners-cacentral"
          priority = 1020
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-prod-runners-to-prod-vnets"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-prod-runner-ips"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-clz-prod-subnets"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-dev-runners-to-dev-vnets"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-dev-runner-ips"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-clz-dev-subnets"].resource_id]
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-runners-connectivity-canadacentral-001-outbound"
          priority = 2910
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-runners-to-ms-build"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["akamaized.net", "akamaitechnologies.com", "aka.ms", "download.visualstudio.microsoft.com", "download.microsoft.com", "download.visualstudio.com", "marketplace.visualstudio.com", "gallerycdn.vsassets.io", "visualstudio.microsoft.com", "learn.microsoft.com", "msdn.microsoft.com", "www.microsoft.com", "windows.net", "microsoftonline.com", "live.com", "github-releases.githubusercontent.com", "objects.githubusercontent.com", "github.com", "az837173.vo.msecnd.net"]
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-cops-prod-canadacentral-inbound"
          priority = 3120
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-hosted-runners-to-cops-prod-dbs"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-prod-cops-db"].resource_id]
              destination_ports     = ["443", "1433", "11000-11999"]
            },
            {
              name                  = "r-allow-hosted-runners-to-cops-prod-apps"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-prod-cops-apps"].resource_id]
              destination_ports     = ["80", "443", "8172"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-mds-canadacentral-outbound"
          priority = 1110
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-mds-https"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-mds-ips"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-allow-sap-aem-outbound"
          priority = 2530
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-dev-30500"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.112.0/24"]
              source_ip_groups      = []
              destination_addresses = ["10.242.74.123", "10.242.83.70"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["30500"]
            },
            {
              name                  = "r-allow-qa-30500"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.112.0/24"]
              source_ip_groups      = []
              destination_addresses = ["10.242.83.220", "10.242.83.138"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["30500"]
            },
            {
              name                  = "r-allow-dev-8443"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.112.0/24"]
              source_ip_groups      = []
              destination_addresses = ["10.242.83.52", "10.242.83.10"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["8443"]
            },
            {
              name                  = "r-allow-qa-8443"
              protocols             = ["TCP"]
              source_addresses      = ["10.195.112.0/24"]
              source_ip_groups      = []
              destination_addresses = ["10.242.83.97", "10.242.83.11"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["8443"]
            },
          ]
        },
        {
          name     = "rc-allow-sap-aem-inbound"
          priority = 2520
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-onprem-9443"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.33.41", "10.242.33.42", "10.242.33.40", "10.242.33.44", "10.242.33.45", "10.242.33.46", "10.242.33.43", "10.242.33.47"]
              source_ip_groups      = []
              destination_addresses = ["10.195.112.0/24"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["9443"]
            },
          ]
        },
      ]
      application_rule_collection = [

      ]
    }
    "azfwpol-connectivity-001-BACKUP-20260320-233016-UTC/rcg-20000-spoke-specific-canada-east" = {
      name       = "rcg-20000-spoke-specific-canada-east"
      policy_key = "azfwpol-connectivity-001-BACKUP-20260320-233016-UTC"
      priority   = 20000
      network_rule_collection = [
        {
          name     = "rc-allow-vnet-ertest-canadaeast-001-inbound"
          priority = 20000
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-iperf01"
              protocols             = ["TCP", "UDP"]
              source_addresses      = ["10.196.114.7"]
              source_ip_groups      = []
              destination_addresses = ["10.195.118.7", "10.195.118.8", "10.242.69.32", "10.242.69.100", "10.242.69.101", "10.242.69.194", "10.242.69.195", "172.25.6.58"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["5201"]
            },
            {
              name                  = "r-allow-iperf02"
              protocols             = ["ICMP"]
              source_addresses      = ["10.196.114.7"]
              source_ip_groups      = []
              destination_addresses = ["10.195.118.7", "10.195.118.8", "10.242.69.32", "10.242.69.100", "10.242.69.101", "10.242.69.194", "10.242.69.195", "172.25.6.58"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-deny-vnet-ertest-canadaeast-001-inbound"
          priority = 20500
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-ertest-canadaeast-001-inbound"
              protocols             = ["Any"]
              source_addresses      = ["10.196.114.0/23"]
              source_ip_groups      = []
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
        {
          name     = "rc-allow-vnet-ertest-canadaeast-001-outbound"
          priority = 20200
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-ertest-caeast-to-certificates"
              protocols             = ["TCP"]
              source_addresses      = ["10.196.114.7"]
              source_ip_groups      = []
              destination_addresses = []
              destination_fqdns     = ["support.sectigo.com"]
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
          ]
        },
      ]
      application_rule_collection = [

      ]
    }
    "azfwpol-connectivity-001-BACKUP-20260320-233016-UTC/rcg-300-cyberark-SIA-baseline" = {
      name       = "rcg-300-cyberark-SIA-baseline"
      policy_key = "azfwpol-connectivity-001-BACKUP-20260320-233016-UTC"
      priority   = 300
      network_rule_collection = [
        {
          name     = "rc-allow-cyberark-SIA"
          priority = 320
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-cyberark-to-windows-vms"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cyberark-vm-ips"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_ports     = ["135", "445", "3389"]
            },
            {
              name                  = "r-allow-cyberark-to-linux-vms"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cyberark-vm-ips"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_ports     = ["22"]
            },
            {
              name                  = "r-allow-cyberark-certs"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-caeast-clz-subnets"].resource_id, module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["support.sectigo.com"]
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-cyberark-ssh-to-dogwood"
              protocols             = ["TCP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-caeast-clz-subnets"].resource_id, module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["dogwood.ssh.cyberark.cloud"]
              destination_ip_groups = []
              destination_ports     = ["22"]
            },
          ]
        },
      ]
      application_rule_collection = [

      ]
    }
    "azfwpol-connectivity-001-BACKUP-20260320-233016-UTC/rcg-40000-onprem-to-spokes" = {
      name       = "rcg-40000-onprem-to-spokes"
      policy_key = "azfwpol-connectivity-001-BACKUP-20260320-233016-UTC"
      priority   = 40000
      network_rule_collection = [
        {
          name     = "rc-allow-net-onprem-to-central"
          priority = 40100
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-icmp"
              protocols             = ["ICMP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id]
              destination_ports     = ["*"]
            },
            {
              name                  = "r-allow-pta-nonprod-apps"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-nonprod-pta-apps"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-pta-nonprod-db"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-to-clzdb-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-nonprod-pta-db"].resource_id]
              destination_ports     = ["1433", "11000-11999"]
            },
            {
              name                  = "r-allow-cops-nonprod-db"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-to-clzdb-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-nonprod-cops-db"].resource_id]
              destination_ports     = ["1433", "11000-11999"]
            },
            {
              name                  = "r-allow-cops-nonprod-apps"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-nonprod-cops-apps"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-fit-apps"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-nonprod-fit-apps"].resource_id, module.ip_group["ipgrp-cacentral-prod-fit-apps"].resource_id]
              destination_ports     = ["443", "1521"]
            },
            {
              name                  = "r-allow-esb-fit-nonprod-1"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.47.1"]
              source_ip_groups      = []
              destination_addresses = ["10.195.80.4"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["22734", "23738", "443"]
            },
            {
              name                  = "r-allow-esb-to-fit-nonprod-2"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.47.2", "10.242.94.14"]
              source_ip_groups      = []
              destination_addresses = ["10.195.80.4"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["23734", "23738", "443"]
            },
            {
              name                  = "r-allow-pta-prod-apps"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-prod-pta-apps"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-pta-prod-db"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-to-clzdb-subnets"].resource_id, module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-prod-pta-db"].resource_id]
              destination_ports     = ["443", "1433", "11000-11999"]
            },
            {
              name                  = "r-allow-iperf01"
              protocols             = ["TCP", "UDP"]
              source_addresses      = ["10.242.69.32", "10.242.69.100", "10.242.69.101", "10.242.69.194", "10.242.69.195", "172.25.6.58"]
              source_ip_groups      = []
              destination_addresses = ["10.195.118.7", "10.195.118.8"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["5201"]
            },
            {
              name                  = "r-allow-esb-to-fit-nonprod-3"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.94.14"]
              source_ip_groups      = []
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-nonprod-fit-apps"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-UAG-to-fit-nonprod"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.234.34", "10.242.234.33"]
              source_ip_groups      = []
              destination_addresses = ["10.195.80.4"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-UAG-to-fit-prod"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.234.34", "10.242.234.33"]
              source_ip_groups      = []
              destination_addresses = ["10.195.32.4"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-kdcdbmontr-to-fit-prod-db"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.83.115"]
              source_ip_groups      = []
              destination_addresses = ["10.195.33.4"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["1521", "22", "3872"]
            },
            {
              name                  = "r-allow-tkdcdbmontr-to-fit-nonprod-db"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.83.125"]
              source_ip_groups      = []
              destination_addresses = ["10.195.81.4"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["1521", "22", "3872"]
            },
            {
              name                  = "r-allow-esb-to-fit-prod"
              protocols             = ["TCP"]
              source_addresses      = ["10.242.94.14"]
              source_ip_groups      = []
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-prod-fit-apps"].resource_id]
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-mds-https"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-mds-ips"].resource_id]
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-allow-net-onprem-to-east"
          priority = 40200
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-icmp"
              protocols             = ["ICMP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_ports     = ["*"]
            },
            {
              name                  = "r-allow-iperf01"
              protocols             = ["TCP", "UDP"]
              source_addresses      = ["10.242.69.32", "10.242.69.100", "10.242.69.101", "10.242.69.194", "10.242.69.195", "172.25.6.58"]
              source_ip_groups      = []
              destination_addresses = ["10.196.114.7"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["5201"]
            },
          ]
        },
      ]
      application_rule_collection = [
        {
          name     = "rc-allow-app-onprem"
          priority = 40300
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-database"
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id, module.ip_group["ipgrp-onprem-to-clzdb-subnets"].resource_id]
              destination_fqdns     = ["*.database.windows.net"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = false
              protocols             = [{ type = "Mssql", port = 1433 }]
            },
            {
              name                  = "r-allow-apps"
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-subnets"].resource_id]
              destination_fqdns     = ["*core.windows.net", "*.azurewebsites.net"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = false
              protocols             = [{ type = "Https", port = 443 }]
            },
          ]
        },
      ]
    }
    "azfwpol-connectivity-001-BACKUP-20260320-233016-UTC/rcg-41000-spokes-to-onprem" = {
      name       = "rcg-41000-spokes-to-onprem"
      policy_key = "azfwpol-connectivity-001-BACKUP-20260320-233016-UTC"
      priority   = 41000
      network_rule_collection = [

      ]
      application_rule_collection = [

      ]
    }
    "azfwpol-connectivity-001-BACKUP-20260320-233016-UTC/rcg-490-global-security-rexception" = {
      name       = "rcg-490-global-security-rexception"
      policy_key = "azfwpol-connectivity-001-BACKUP-20260320-233016-UTC"
      priority   = 490
      network_rule_collection = [

      ]
      application_rule_collection = [

      ]
    }
    "azfwpol-connectivity-001-BACKUP-20260320-233016-UTC/rcg-500-global-security-baseline" = {
      name       = "rcg-500-global-security-baseline"
      policy_key = "azfwpol-connectivity-001-BACKUP-20260320-233016-UTC"
      priority   = 500
      network_rule_collection = [
        {
          name     = "rc-deny-risky-protocols"
          priority = 600
          action   = "Deny"
          rule = [
            {
              name                  = "r-deny-telnet"
              protocols             = ["TCP"]
              source_addresses      = ["*"]
              source_ip_groups      = []
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["23"]
            },
            {
              name                  = "r-deny-ftp"
              protocols             = ["TCP"]
              source_addresses      = ["*"]
              source_ip_groups      = []
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["20", "21"]
            },
            {
              name                  = "r-deny-tftp"
              protocols             = ["UDP"]
              source_addresses      = ["*"]
              source_ip_groups      = []
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["69"]
            },
            {
              name                  = "r-deny-netbios"
              protocols             = ["TCP"]
              source_addresses      = ["*"]
              source_ip_groups      = []
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["137", "138"]
            },
            {
              name                  = "r-deny-rpc"
              protocols             = ["TCP"]
              source_addresses      = ["*"]
              source_ip_groups      = []
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["135"]
            },
          ]
        },
      ]
      application_rule_collection = [

      ]
    }
    "azfwpol-connectivity-001-BACKUP-20260320-233016-UTC/rcg-64900-deny-all" = {
      name       = "rcg-64900-deny-all"
      policy_key = "azfwpol-connectivity-001-BACKUP-20260320-233016-UTC"
      priority   = 64900
      network_rule_collection = [
        {
          name     = "rc-deny-network"
          priority = 64910
          action   = "Deny"
          rule = [
            {
              name                  = "rc-deny-network"
              protocols             = ["Any"]
              source_addresses      = ["*"]
              source_ip_groups      = []
              destination_addresses = ["*"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["*"]
            },
          ]
        },
      ]
      application_rule_collection = [
        {
          name     = "rc-deny-applications"
          priority = 64920
          action   = "Deny"
          rule = [
            {
              name                  = "rc-deny-applications"
              source_addresses      = ["*"]
              source_ip_groups      = []
              destination_fqdns     = ["*"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = true
              protocols             = [{ type = "Https", port = 443 }, { type = "Mssql", port = 1433 }]
            },
          ]
        },
      ]
    }
    "azfwpol-connectivity-001-BACKUP-20260320-233016-UTC/rcg-800-global-internet-baseline" = {
      name       = "rcg-800-global-internet-baseline"
      policy_key = "azfwpol-connectivity-001-BACKUP-20260320-233016-UTC"
      priority   = 800
      network_rule_collection = [
        {
          name     = "rc-allow-tagbased-services"
          priority = 820
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-azure-services"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = ["AzurePortal", "AzureCloud", "LogicApps", "AzureFrontDoor.Frontend", "AzureFrontDoor.FirstParty", "AzureFrontDoor.Backend", "AzureFrontDoor.Infra", "AzureFrontDoor.MicrosoftSecurity", "AzureActiveDirectory", "AzureResourceManager", "AppService", "Storage", "AzureKeyVault", "AppConfiguration"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443", "445"]
            },
            {
              name                  = "r-allow-azure-monitor"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = ["AzureMonitor", "AzureSentinel", "KustoAnalytics", "ActionGroup", "LogicAppsManagement", "AppServiceManagement"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-sql-services"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = ["Sql", "SqlManagement"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-allow-ipbased-services"
          priority = 810
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-ntp"
              protocols             = ["UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = ["168.61.215.74"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["123"]
            },
            {
              name                  = "r-allow-dns-inbound"
              protocols             = ["UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-onprem-infoblox"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-clz-dns-resolvers"].resource_id]
              destination_ports     = ["53"]
            },
            {
              name                  = "r-allow-dns-outbound"
              protocols             = ["UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-onprem-controllers"].resource_id]
              destination_ports     = ["53"]
            },
            {
              name                  = "r-allow-dns-azure"
              protocols             = ["UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = []
              destination_ip_groups = [module.ip_group["ipgrp-cacentral-clz-dns-resolvers"].resource_id]
              destination_ports     = ["53"]
            },
            {
              name                  = "r-allow-github-actions"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = ["4.175.114.51/32", "20.102.35.120/32", "4.175.114.43/32", "20.72.125.48/32", "20.19.5.100/32", "20.7.92.46/32", "20.232.252.48/32", "52.186.44.51/32", "20.22.98.201/32", "20.246.184.240/32", "20.96.133.71/32", "20.253.2.203/32", "20.102.39.220/32", "20.81.127.181/32", "52.148.30.208/32", "20.14.42.190/32", "20.85.159.192/32", "52.224.205.173/32", "20.118.176.156/32", "20.236.207.188/32", "20.242.161.191/32", "20.166.216.139/32", "20.253.126.26/32", "52.152.245.137/32", "40.118.236.116/32", "20.185.75.138/32", "20.96.226.211/32", "52.167.78.33/32", "20.105.13.142/32", "20.253.95.3/32", "20.221.96.90/32", "51.138.235.85/32", "52.186.47.208/32", "20.7.220.66/32", "20.75.4.210/32", "20.120.75.171/32", "20.98.183.48/32", "20.84.200.15/32", "20.14.235.135/32", "20.10.226.54/32", "20.22.166.15/32", "20.65.21.88/32", "20.102.36.236/32", "20.124.56.57/32", "20.94.100.174/32", "20.102.166.33/32", "20.31.193.160/32", "20.232.77.7/32", "20.102.38.122/32", "20.102.39.57/32", "20.85.108.33/32", "40.88.240.168/32", "20.69.187.19/32", "20.246.192.124/32", "20.4.161.108/32", "20.22.22.84/32", "20.1.250.47/32", "20.237.33.78/32", "20.242.179.206/32", "40.88.239.133/32", "20.121.247.125/32", "20.106.107.180/32", "20.22.118.40/32", "20.15.240.48/32", "20.84.218.150/32"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-github"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_addresses = ["140.82.112.0/20", "143.55.64.0/20", "185.199.108.0/22", "192.30.252.0/22", "20.175.192.146/32", "20.175.192.147/32", "20.175.192.149/32", "20.175.192.150/32", "20.199.39.227/32", "20.199.39.228/32", "20.199.39.231/32", "20.199.39.232/32", "20.200.245.241/32", "20.200.245.245/32", "20.200.245.246/32", "20.200.245.247/32", "20.200.245.248/32", "20.201.28.144/32", "20.201.28.148/32", "20.201.28.149/32", "20.201.28.151/32", "20.201.28.152/32", "20.205.243.160/32", "20.205.243.164/32", "20.205.243.165/32", "20.205.243.166/32", "20.205.243.168/32", "20.207.73.82/32", "20.207.73.83/32", "20.207.73.85/32", "20.207.73.86/32", "20.207.73.88/32", "20.217.135.1/32", "20.233.83.145/32", "20.233.83.146/32", "20.233.83.147/32", "20.233.83.149/32", "20.233.83.150/32", "20.248.137.48/32", "20.248.137.49/32", "20.248.137.50/32", "20.248.137.52/32", "20.248.137.55/32", "20.26.156.215/32", "20.26.156.216/32", "20.26.156.211/32", "20.27.177.113/32", "20.27.177.114/32", "20.27.177.116/32", "20.27.177.117/32", "20.27.177.118/32", "20.29.134.17/32", "20.29.134.18/32", "20.29.134.19/32", "20.29.134.23/32", "20.29.134.24/32", "20.87.245.0/32", "20.87.245.1/32", "20.87.245.4/32", "20.87.245.6/32", "20.87.245.7/32", "4.208.26.196/32", "4.208.26.197/32", "4.208.26.198/32", "4.208.26.199/32", "4.208.26.200/32", "4.225.11.196/32", "4.237.22.32/32"]
              destination_fqdns     = []
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
          ]
        },
        {
          name     = "rc-allow-fqdnbased-services"
          priority = 830
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-microsoft-nuget"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["dotnet.microsoft.com", "download.microsoft.com", "api.nuget.org", "www.nuget.org", "nuget.org", "azuresearch-usnc.nuget.org", "azuresearch-ussc.nuget.org", "licenses.nuget.org", "nuget.cdn.azure.cn", "azuresearch-ea.nuget.org", "azuresearch-sea.nuget.org", "crl3.digicert.com", "crl4.digicert.com", "ocsp.digicert.com", "cacerts.digicert.com", "registry.npmjs.org", "nodejs.org", "dist.nuget.org", "skimdb.npmjs.com", "api.npms.io", "eslint.org", "gradle.org"]
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-smsgateway"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["secure.smsgateway.ca"]
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-servicenow"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["bchydrodev.service-now.com", "bchydroqa.service-now.com", "bchydrouat.service-now.com", "bchydro.service-now.com"]
              destination_ip_groups = []
              destination_ports     = ["443"]
            },
            {
              name                  = "r-allow-windows-update"
              protocols             = ["TCP", "UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["windowsupdate.microsoft.com", "windowsupdate.microsoft.com", "update.microsoft.com", "windowsupdate.com", "download.windowsupdate.com", "download.microsoft.com", "wustat.windows.com", "ntservicepack.microsoft.com"]
              destination_ip_groups = []
              destination_ports     = ["80", "443"]
            },
            {
              name                  = "r-allow-ntp"
              protocols             = ["UDP"]
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_addresses = []
              destination_fqdns     = ["time.windows.com"]
              destination_ip_groups = []
              destination_ports     = ["123"]
            },
          ]
        },
      ]
      application_rule_collection = [
        {
          name     = "rc-allow-microsoft-services"
          priority = 840
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-windows-update"
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_fqdns     = ["windowsupdate.microsoft.com", "*.windowsupdate.microsoft.com", "update.microsoft.com", "*.update.microsoft.com", "windowsupdate.com", "*.windowsupdate.com", "download.windowsupdate.com", "*.download.windowsupdate.com", "download.microsoft.com", "wustat.windows.com", "*.wustat.windows.com", "ntservicepack.microsoft.com", "*.delivery.mp.microsoft.com", "*.microsoft.com", "*.windows.com"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = false
              protocols             = [{ type = "Https", port = 443 }, { type = "Http", port = 80 }]
            },
            {
              name                  = "r-allow-azure-services"
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_fqdns     = ["*.azure.com", "*.microsoft.com", "*.azure.net", "*.azurewebsites.net", "*.blob.core.windows.net", "*.queue.core.windows.net", "*.table.core.windows.net"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = true
              protocols             = [{ type = "Https", port = 443 }]
            },
            {
              name                  = "r-allow-azure-monitor"
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_fqdns     = ["*.ods.opinsights.azure.com", "*.oms.opinsights.azure.com", "*.monitoring.azure.com", "api.loganalytics.io", "*.loganalytics.io", "js.monitor.azure.com", "*.monitor.azure.com"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = true
              protocols             = [{ type = "Https", port = 443 }]
            },
            {
              name                  = "r-allow-office365"
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_fqdns     = ["*.office.com", "*.office365.com", "*.outlook.com", "*.sharepoint.com", "*.onedrive.com", "*.teams.microsoft.com"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = true
              protocols             = [{ type = "Https", port = 443 }]
            },
            {
              name                  = "r-allow-app-insights"
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id, module.ip_group["ipgrp-caeast-clz-subnets"].resource_id]
              destination_fqdns     = ["*.applicationinsights.azure.com"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = true
              protocols             = [{ type = "Https", port = 443 }]
            },
            {
              name                  = "r-allow-cops-nonprod-apple-api"
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-nonprod-cops-apps"].resource_id]
              destination_fqdns     = ["api.push.apple.com", "api.sandbox.push.apple.com"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = false
              protocols             = [{ type = "Https", port = 443 }]
            },
            {
              name                  = "r-allow-ms-build-tools"
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_fqdns     = ["*akamaitechnologies.com", "akamaized.net", "go.microsoft.com", "aka.ms", "download.visualstudio.microsoft.com", "download.microsoft.com", "download.visualstudio.com", "marketplace.visualstudio.com", "*.gallerycdn.vsassets.io", "visualstudio.microsoft.com", "learn.microsoft.com", "msdn.microsoft.com", "www.microsoft.com", "*.windows.net", "*.microsoftonline.com", "*.live.com", "github-releases.githubusercontent.com", "objects.githubusercontent.com", "github.com", "az837173.vo.msecnd.net"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = false
              protocols             = [{ type = "Https", port = 443 }]
            },
          ]
        },
        {
          name     = "rc-allow-fqdnbased-app-services"
          priority = 850
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-cyberark-https"
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cyberark-vm-ips"].resource_id]
              destination_fqdns     = ["*.cyberark.cloud", "*.cyberark.com", "*.privilegecloud.cyberark.cloud", "*.dpa.cyberark.cloud", "*.bc.be-privilege-access.cyberark.cloud", "*.s3.amazonaws.com", "*.s3.ca-central-1.amazonaws.com", "*.ca-central-1.amazonaws.com", "*.iot.ca-central-1.amazonaws.com", "component-registry-store-490081306957.s3.amazonaws.com", "caintegrations.s3.amazonaws.com", "connector-management-scripts-490081306957-ca-central-1.s3.amazonaws.com", "connector-management-assets-490081306957-ca-central-1.s3.amazonaws.com", "cms-assets-bucket-445444212982.s3.amazonaws.com", "cms-assets-bucket-445444212982-ca-central-1.s3.ca-central-1.amazonaws.com", "casoftware.s3.amazonaws.com", "community.cyberark.com", "ca-central-1.bc.be-privilege-access.cyberark.cloud", "dogwood.cyberark.cloud", "dogwood.privilegecloud.cyberark.cloud", "webaccess-dogwood.privilegecloud.cyberark.cloud", "dogwood.webaccess.cyberark.cloud", "dogwood.connectormanagement.cyberark.cloud", "connector-dogwood.privilegecloud.cyberark.cloud", "console.privilegecloud.cyberark.cloud", "dogwood.dpa.cyberark.cloud", "a3vvqcp8z371p3-ats.iot.ca-central-1.amazonaws.com", "a2m4b3cupk8nzj-ats.iot.ca-central-1.amazonaws.com", "pod1402-b1.relay.idaptive.app", "pod1402-b2.relay.idaptive.app", "pod1402-a1.relay.idaptive.app", "pod1402-a2.relay.idaptive.app", "pod0.idaptive.app", "edge.idaptive.app", "ip-ranges.amazonaws.com", "*.relay.idaptive.app", "*.idaptive.app", "*.webaccess.cyberark.cloud", "*.connectormanagement.cyberark.cloud"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = false
              protocols             = [{ type = "Https", port = 443 }]
            },
            {
              name                  = "r-allpw-hosted-runners-to-fit-apps"
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
              destination_fqdns     = ["*.appserviceenvironment.net"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = true
              protocols             = [{ type = "Http", port = 80 }, { type = "Https", port = 443 }]
            },
            {
              name                  = "r-allow-cyberark-http"
              source_addresses      = []
              source_ip_groups      = [module.ip_group["ipgrp-cacentral-cyberark-vm-ips"].resource_id]
              destination_fqdns     = ["crt.r2m02.amazontrust.com", "ocsp.r2m02.amazontrust.com", "privacy-policy.truste.com", "ocsp.verisign.com", "ocsp.globalsign.com", "crl.globalsign.com", "secure.globalsign.com", "ipinfo.io"]
              destination_urls      = []
              destination_fqdn_tags = []
              web_categories        = []
              terminate_tls         = false
              protocols             = [{ type = "Http", port = 80 }]
            },
          ]
        },
      ]
    }
  }
}

module "firewall" {
  # `var.enable_firewall ? local.firewalls : {}` fails: the conditional forces
  # conversion to map, which requires every entry's attribute types to unify,
  # and entries that leave an attribute null alongside ones that set an object
  # do not. The for expression gates without converting. Same below.
  for_each = { for k, v in local.firewalls : k => v if var.enable_firewall }

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-azure-firewall/azurerm"
  version = "0.1.0"

  name                = each.key
  resource_group_name = local.rg_names[each.value.rg_key]
  location            = each.value.location
  firewall_sku_name   = each.value.sku_name
  firewall_sku_tier   = each.value.sku_tier

  firewall_policy_id                   = each.value.firewall_policy_id
  firewall_zones                       = each.value.zones
  firewall_virtual_hub                 = each.value.virtual_hub
  ip_configurations                    = each.value.ip_configurations
  firewall_management_ip_configuration = each.value.management_ip_configuration

  diagnostic_settings = lookup(local.firewall_diagnostic_settings, each.key, {})

  enable_telemetry = false
  tags             = local.common_tags
}

# Adopted as exported on 2026-09-28. The hub firewalls send every log twice:
# allLogs to la-siem-management (FirewallPolicySettings) and 16 categories to
# la-siem-security (sendLogsToLA). Kept as-is; see the handover before changing.
locals {
  la_siem_management_id = "/subscriptions/ccac6a90-8b47-44a9-88b2-520506c45219/resourceGroups/rg-siem-management-canadacentral-001/providers/Microsoft.OperationalInsights/workspaces/la-siem-management-canadacentral-001"

  firewall_log_categories = [
    "AzureFirewallApplicationRule", "AzureFirewallNetworkRule", "AzureFirewallDnsProxy",
    "AZFWNetworkRule", "AZFWApplicationRule", "AZFWNatRule", "AZFWThreatIntel", "AZFWIdpsSignature",
    "AZFWDnsQuery", "AZFWFqdnResolveFailure", "AZFWFatFlow", "AZFWFlowTrace", "AZFWDnsAdditional",
    "AZFWApplicationRuleAggregation", "AZFWNetworkRuleAggregation", "AZFWNatRuleAggregation",
  ]

  hub_firewall_diagnostic_settings = {
    metrics = {
      name                           = "sendMetricsToLA"
      workspace_resource_id          = local.la_siem_management_id
      log_analytics_destination_type = "AzureDiagnostics"
      log_groups                     = []
      metric_categories              = ["AllMetrics"]
    }
    policy_settings = {
      name                  = "FirewallPolicySettings"
      workspace_resource_id = local.la_siem_management_id
      log_groups            = ["allLogs"]
      metric_categories     = []
    }
    logs = {
      name                  = "sendLogsToLA"
      workspace_resource_id = var.firewall_insights_workspace_id
      log_categories        = local.firewall_log_categories
      log_groups            = []
      metric_categories     = []
    }
  }

  firewall_diagnostic_settings = {
    "azfw-connectivity-canadacentral-001" = local.hub_firewall_diagnostic_settings
    "azfw-connectivity-canadaeast-001"    = local.hub_firewall_diagnostic_settings
    "azfw-transit-connectivity-canadacentral-001" = {
      metrics = {
        name                  = "sendMetricsToLA"
        workspace_resource_id = local.la_siem_management_id
        log_groups            = []
        metric_categories     = ["AllMetrics"]
      }
      logs = {
        name                  = "sendLogsToLA"
        workspace_resource_id = var.firewall_insights_workspace_id
        log_groups            = ["allLogs"]
        metric_categories     = []
      }
    }
  }
}

module "firewall_policy" {
  # Gated as module.firewall above. Here it is identity, insights and
  # tls_certificate: objects on azfwpol-connectivity-001, null on the BACKUP.
  for_each = { for k, v in local.firewall_policies : k => v if var.enable_firewall }

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-azure-firewall-policy/azurerm"
  version = "0.1.1"

  name                = each.key
  resource_group_name = local.rg_names["hub_cc"]
  location            = each.value.location

  firewall_policy_sku                      = each.value.sku
  firewall_policy_threat_intelligence_mode = each.value.threat_intelligence_mode
  firewall_policy_dns                      = each.value.dns
  firewall_policy_intrusion_detection      = each.value.intrusion_detection
  firewall_policy_identity                 = each.value.identity
  firewall_policy_insights                 = each.value.insights
  firewall_policy_tls_certificate          = each.value.tls_certificate

  # Rule collection groups, filtered to this policy. The flat local map keeps its
  # "<policy>/<group>" keys; the wrapper is per-policy, so it receives only its own
  # groups, keyed by group name. The wrapper wires firewall_policy_id internally.
  firewall_policy_rule_collection_groups = {
    for k, v in local.firewall_rule_collection_groups : v.name => {
      name                        = v.name
      priority                    = v.priority
      network_rule_collection     = v.network_rule_collection
      application_rule_collection = v.application_rule_collection
    } if v.policy_key == each.key && var.enable_firewall
  }

  enable_telemetry = false
  tags             = local.common_tags
}
