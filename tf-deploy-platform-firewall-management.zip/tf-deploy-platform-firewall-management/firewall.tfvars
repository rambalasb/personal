# ── Shared ─────────────────────────────────────────────────────────────
# The connectivity subscription. Firewall and IP groups only; every resource
# group here is read through data.tf and owned by tf-deploy-platform-connectivity.
subscription_id = "f3835bc1-9829-4ac8-9d7a-0999e0b29b90"
environment     = "Prod"

# CostCenterId is live on all 181 resources and feeds cost allocation, so it is
# declared here rather than left to be dropped. Environment is deliberately not
# set here: local.common_tags emits `environment`, and Azure tag names are
# case-insensitive, so declaring both would collide. See locals.tf.
tags = {
  owner        = "connectivity-platform"
  CostCenterId = "80025906"
}

# ── Resource groups read from the connectivity workspace ───────────────
hub_cc_resource_group_name    = "rg-hub-connectivity-canadacentral-001"
hub_ce_resource_group_name    = "rg-hub-connectivity-canadaeast-001"
shared_cc_resource_group_name = "rg-shared-connectivity-canadacentral-001"
ip_groups_resource_group_name = "rg-ip-groups-connectivity-global"

# ── Cross-subscription references ──────────────────────────────────────
# SIEM workspace, security subscription.
firewall_insights_workspace_id = "/subscriptions/7d54d6f7-83d9-48cf-ac35-1068bcfd0561/resourceGroups/rg-siem-security-canadacentral-001/providers/Microsoft.OperationalInsights/workspaces/la-siem-security-canadacentral-001"

# mid-azfirewall, identity subscription. Managed by sub-identity-lz.
firewall_uami_id = "/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0/resourceGroups/rg-mid-identity-canadacentral-001/providers/Microsoft.ManagedIdentity/userAssignedIdentities/mid-azfirewall-canadacentral-001"

# TLS inspection certificate. The key vault (kvfwtlscanadacentral) is managed by
# sub-identity-lz; the versioned secret id is what the policy pins, so it has to
# be updated here on certificate rotation.
firewall_tls_certificate = {
  name                = "azkv-fw-tls-cert"
  key_vault_secret_id = "https://kvfwtlscanadacentral.vault.azure.net/secrets/azkv-fw-tls-cert/0393397970c443b4be90c8928137ef62"
}

# ── Feature flags ──────────────────────────────────────────────────────
enable_firewall  = true
enable_ip_groups = true

# ── IP groups (177) ─────────────────────────────────────────────────────
# Referenced only by the policy rule collections in firewall.tf.
ip_groups = {
  "backup_cc/ipgrp-pep-kdcspesewec1"                                   = { name = "ipgrp-pep-kdcspesewec1", rg_key = "backup_cc", location = "canadacentral", ip_addresses = ["10.242.112.4"] }
  "backup_cc/ipgrp-tkdcgomora"                                         = { name = "ipgrp-tkdcgomora", rg_key = "backup_cc", location = "canadacentral", ip_addresses = ["10.242.95.184"] }
  "hub_cc/ipgrp-kvspoprod-canadacentral001"                            = { name = "ipgrp-kvspoprod-canadacentral001", rg_key = "hub_cc", location = "canadacentral", ip_addresses = ["10.195.124.4"] }
  "hub_cc/ipgrp-vnet-spo-prod-canadacentral-001"                       = { name = "ipgrp-vnet-spo-prod-canadacentral-001", rg_key = "hub_cc", location = "canadacentral", ip_addresses = ["10.195.124.0/24"] }
  "appcs-wrap-test-canadacentral-001"                                  = { location = "canadacentral", ip_addresses = ["10.195.68.39"] }
  "ipgroup-snet-app-cns-nonprod-canadacentral-001"                     = { location = "canadacentral", ip_addresses = ["10.195.70.0/27"] }
  "ipgroup-vnet-cae-cep-dev-canadacentral-in"                          = { location = "canadacentral", ip_addresses = ["10.195.128.0/24"] }
  "ipgroup-vnet-cns-nonprod-canadacentral-001"                         = { location = "canadacentral", ip_addresses = ["10.195.70.0/25"] }
  "ipgrp-Azure-GOM-VM-DB"                                              = { location = "canadacentral", ip_addresses = ["10.195.70.135"] }
  "ipgrp-app-citt-dev-canadacentral001-pe"                             = { location = "canadacentral", ip_addresses = ["10.195.129.183"] }
  "ipgrp-app-openai-nonprod-canadacentral-001"                         = { location = "canadacentral", ip_addresses = ["10.195.28.9"] }
  "ipgrp-app-openai-prod-canadacentral-001"                            = { location = "canadacentral", ip_addresses = ["10.195.12.9"] }
  "ipgrp-azure-staging-vm"                                             = { location = "canadacentral", ip_addresses = ["10.195.73.134"] }
  "ipgrp-bchgatev"                                                     = { location = "canadacentral", ip_addresses = ["10.242.35.1"] }
  "ipgrp-bchsiops-jumphost"                                            = { location = "canadacentral", ip_addresses = ["10.242.30.30", "172.25.81.3"] }
  "ipgrp-bchydro-adroot-ad-servers"                                    = { location = "canadacentral", ip_addresses = ["10.242.74.145", "10.242.74.146", "10.242.74.147", "10.242.74.148", "10.242.74.149", "10.5.22.7", "10.5.24.7", "10.65.64.1", "10.65.64.2", "10.71.196.12", "10.71.196.13", "172.18.253.226", "172.25.6.100", "172.25.6.101", "172.25.6.16", "172.25.6.17", "172.26.101.48", "172.26.111.1", "172.30.111.1"] }
  "ipgrp-bchydro-adroot-ad-servers-azure"                              = { location = "canadacentral", ip_addresses = ["10.195.100.5", "10.195.100.6", "10.195.100.7"] }
  "ipgrp-bchydrofinops-vnet-canadacentral"                             = { location = "canadacentral", ip_addresses = ["10.195.129.0/26"] }
  "ipgrp-BEP-app-config"                                               = { location = "canadacentral", ip_addresses = ["10.195.21.234"] }
  "ipgrp-bep-blob-storage"                                             = { location = "canadacentral", ip_addresses = ["10.195.21.235"] }
  "ipgrp-BEP-fileshare-vm"                                             = { location = "canadacentral", ip_addresses = ["10.195.21.232"] }
  "ipgrp-bep-function-app"                                             = { location = "canadacentral", ip_addresses = ["10.195.21.231"] }
  "ipgrp-bep-keyvault"                                                 = { location = "canadacentral", ip_addresses = ["10.195.21.233"] }
  "ipgrp-cacentral-caeast-ertest-vm"                                   = { location = "canadacentral", ip_addresses = ["10.195.118.7", "10.195.118.8", "10.196.114.7"] }
  "ipgrp-cacentral-clz-dev-subnets"                                    = { location = "canadacentral", ip_addresses = ["10.195.96.0/22", "10.195.80.0/22", "10.195.64.0/22", "172.17.0.0/22", "172.18.0.0/16", "172.16.0.0/16", "172.19.0.0/16", "172.20.0.0/16", "10.0.0.0/16"] }
  "ipgrp-cacentral-clz-dns-resolvers"                                  = { location = "canadacentral", ip_addresses = ["10.195.1.4/32", "10.196.1.4/32", "10.195.4.7/32"] }
  "ipgrp-cacentral-clz-monitor"                                        = { location = "canadacentral", ip_addresses = ["10.195.6.7/32", "10.195.6.14/32", "10.195.6.17/32", "10.195.6.18/32", "10.195.6.8/32", "10.195.6.12/32", "10.195.6.15/32", "10.195.6.9/32", "10.195.6.11/32", "10.195.6.10/32"] }
  "ipgrp-cacentral-clz-prod-subnets"                                   = { location = "canadacentral", ip_addresses = ["10.195.48.0/22", "10.195.116.0/26", "10.195.4.0/22", "10.195.118.0/23", "10.196.114.0/23", "10.195.32.0/22", "10.195.16.0/22", "10.195.114.0/23", "10.195.117.0/24"] }
  "ipgrp-cacentral-clz-subnets"                                        = { location = "canadacentral", ip_addresses = ["10.195.0.0/16"] }
  "ipgrp-cacentral-cops-nonprod-vnet"                                  = { location = "canadacentral", ip_addresses = ["10.195.96.0/22"] }
  "ipgrp-cacentral-cops-prod-vnet"                                     = { location = "canadacentral", ip_addresses = ["10.195.48.0/22"] }
  "ipgrp-cacentral-cyberark-vm-ips"                                    = { location = "canadacentral", ip_addresses = ["10.195.116.4", "10.195.116.5"] }
  "ipgrp-cacentral-cyberark-vnet"                                      = { location = "canadacentral", ip_addresses = ["10.195.116.0/26"] }
  "ipgrp-cacentral-dethree-SCM-endpoint-ip"                            = { location = "canadacentral", ip_addresses = ["10.195.68.135"] }
  "ipgrp-cacentral-dethree-Storage-endpoint-ip"                        = { location = "canadacentral", ip_addresses = ["10.195.68.138"] }
  "ipgrp-cacentral-dethree-endpoints"                                  = { location = "canadacentral", ip_addresses = ["10.195.68.136", "10.195.68.135", "10.195.68.137"] }
  "ipgrp-cacentral-dethree-key-vault-endpoint-ip"                      = { location = "canadacentral", ip_addresses = ["10.195.68.137"] }
  "ipgrp-cacentral-dethree-sql-endpoint-ip"                            = { location = "canadacentral", ip_addresses = ["10.195.68.136"] }
  "ipgrp-cacentral-dev-runner-ips"                                     = { location = "canadacentral", ip_addresses = ["10.195.114.7"] }
  "ipgrp-cacentral-dns-connectivity-vnet"                              = { location = "canadacentral", ip_addresses = ["10.195.4.0/22"] }
  "ipgrp-cacentral-ertest-vnet"                                        = { location = "canadacentral", ip_addresses = ["10.195.118.0/23"] }
  "ipgrp-cacentral-fit-nonprod-vnet"                                   = { location = "canadacentral", ip_addresses = ["10.195.80.0/22"] }
  "ipgrp-cacentral-fit-prod-vnet"                                      = { location = "canadacentral", ip_addresses = ["10.195.32.0/22"] }
  "ipgrp-cacentral-hosted-runners"                                     = { location = "canadacentral", ip_addresses = ["10.195.114.7/32", "10.195.115.7/32", "10.195.114.9/32", "10.195.115.9/32"] }
  "ipgrp-cacentral-hosted-runners-vnet"                                = { location = "canadacentral", ip_addresses = ["10.195.114.0/23"] }
  "ipgrp-cacentral-mds-ips"                                            = { location = "canadacentral", ip_addresses = ["10.195.120.4/32", "10.195.120.5/32", "10.195.120.6/32", "10.195.120.7/32", "10.195.120.8/32", "10.195.120.9/32"] }
  "ipgrp-cacentral-nonprod-cops-apps"                                  = { location = "canadacentral", ip_addresses = ["10.195.98.8/32", "10.195.98.7/32", "10.195.96.0/24", "10.195.50.8/32", "10.195.50.6/32", "10.195.48.0/26"] }
  "ipgrp-cacentral-nonprod-cops-db"                                    = { location = "canadacentral", ip_addresses = ["10.195.98.6/32", "10.195.50.7/32"] }
  "ipgrp-cacentral-nonprod-fit-apps"                                   = { location = "canadacentral", ip_addresses = ["10.195.82.6/32", "10.195.82.7/32", "10.195.80.4/32", "10.195.80.0/24", "10.195.81.4/32", "10.195.33.4", "10.195.32.4", "10.195.34.8"] }
  "ipgrp-cacentral-nonprod-pta-apps"                                   = { location = "canadacentral", ip_addresses = ["10.195.64.132/32", "10.195.64.4/32"] }
  "ipgrp-cacentral-nonprod-pta-db"                                     = { location = "canadacentral", ip_addresses = ["10.195.66.6/32"] }
  "ipgrp-cacentral-pei-appservice-private-endpoint-ip"                 = { location = "canadacentral", ip_addresses = ["10.195.69.5"] }
  "ipgrp-cacentral-pei-key-vault-private-endpoint-ip"                  = { location = "canadacentral", ip_addresses = ["10.195.69.7"] }
  "ipgrp-cacentral-pei-sql-private-endpoint-ip"                        = { location = "canadacentral", ip_addresses = ["10.195.69.6"] }
  "ipgrp-cacentral-prod-cops-apps"                                     = { location = "canadacentral", ip_addresses = ["10.195.48.0/26"] }
  "ipgrp-cacentral-prod-cops-db"                                       = { location = "canadacentral", ip_addresses = ["10.195.49.0/26"] }
  "ipgrp-cacentral-prod-fit-apps"                                      = { location = "canadacentral", ip_addresses = ["10.195.32.4/32", "10.195.34.8", "10.195.34.0/24", "10.195.32.0/24"] }
  "ipgrp-cacentral-prod-pta-apps"                                      = { location = "canadacentral", ip_addresses = ["10.195.16.4/32"] }
  "ipgrp-cacentral-prod-pta-db"                                        = { location = "canadacentral", ip_addresses = ["10.195.18.6/32"] }
  "ipgrp-cacentral-prod-runner-ips"                                    = { location = "canadacentral", ip_addresses = ["10.195.115.7"] }
  "ipgrp-cacentral-pta-nonprod-vnet"                                   = { location = "canadacentral", ip_addresses = ["10.195.64.0/22"] }
  "ipgrp-cacentral-pta-prod-vnet"                                      = { location = "canadacentral", ip_addresses = ["10.195.16.0/22"] }
  "ipgrp-cacentral-sandbox-cacentral-1-vnet"                           = { location = "canadacentral", ip_addresses = ["172.17.0.0/16"] }
  "ipgrp-cacentral-sandbox-cacentral-2-vnet"                           = { location = "canadacentral", ip_addresses = ["172.18.0.0/16"] }
  "ipgrp-cacentral-sandbox-cacentral-vnet"                             = { location = "canadacentral", ip_addresses = ["172.16.0.0/16"] }
  "ipgrp-cacentral-shared-connectivity-vnet"                           = { location = "canadacentral", ip_addresses = ["10.195.117.0/24"] }
  "ipgrp-caeast-clz-dns-resolvers"                                     = { location = "canadacentral", ip_addresses = ["10.196.1.4"] }
  "ipgrp-caeast-clz-subnets"                                           = { location = "canadacentral", ip_addresses = ["10.196.0.0/16"] }
  "ipgrp-caeast-ertest-vnet"                                           = { location = "canadacentral", ip_addresses = ["10.196.114.0/23"] }
  "ipgrp-cc-ns2-subnet"                                                = { location = "canadacentral", ip_addresses = ["10.237.0.0/21"] }
  "ipgrp-clz-monitor-ips"                                              = { location = "canadacentral", ip_addresses = ["10.195.6.7/32", "10.195.6.14/32", "10.195.6.17/32", "10.195.6.18/32", "10.195.6.8/32", "10.195.6.12/32", "10.195.6.15/32", "10.195.6.9/32", "10.195.6.11/32", "10.195.6.10/32", "10.195.6.13/32", "10.195.6.6/32", "10.195.6.5/32", "10.195.82.8/32", "10.195.82.9/32", "10.195.66.7/32", "10.195.66.8/32", "10.195.6.20/32", "10.195.6.21/32", "10.195.6.22/32"] }
  "ipgrp-db-pea-qa"                                                    = { location = "canadacentral", ip_addresses = ["10.195.132.137"] }
  "ipgrp-edmbchinf1"                                                   = { location = "canadacentral", ip_addresses = ["10.242.95.60"] }
  "ipgrp-ertest-vm-ips"                                                = { location = "canadacentral", ip_addresses = ["10.195.118.7", "10.195.118.8", "10.196.114.7"] }
  "ipgrp-func-openai-nonprod-canadacentral-001"                        = { location = "canadacentral", ip_addresses = ["10.195.28.10"] }
  "ipgrp-func-openai-prod-canadacentral-001"                           = { location = "canadacentral", ip_addresses = ["10.195.12.10"] }
  "ipgrp-ipgrp-pep-auritas-prod-canadacentral"                         = { location = "canadacentral", ip_addresses = ["10.195.121.10", "10.195.121.12"] }
  "ipgrp-kdcbchepotie2"                                                = { location = "canadacentral", ip_addresses = ["10.242.238.5"] }
  "ipgrp-kdcbch-ips"                                                   = { location = "canadacentral", ip_addresses = ["10.242.69.32", "10.242.69.100", "10.242.69.101", "10.242.69.194", "10.242.69.195", "172.25.6.58"] }
  "ipgrp-kdcbchlimsscc1"                                               = { location = "canadacentral", ip_addresses = ["10.242.237.37"] }
  "ipgrp-kdcbchpsdbq02"                                                = { location = "canadacentral", ip_addresses = ["10.242.69.87"] }
  "ipgrp-kdcejasus1"                                                   = { location = "canadacentral", ip_addresses = ["10.242.74.104"] }
  "ipgrp-kdcejasus2"                                                   = { location = "canadacentral", ip_addresses = ["10.242.74.105"] }
  "ipgrp-kdcfnapd2"                                                    = { location = "canadacentral", ip_addresses = ["10.242.149.147"] }
  "ipgrp-kdcfnaps3"                                                    = { location = "canadacentral", ip_addresses = ["10.242.149.145"] }
  "ipgrp-kdcfndbs1"                                                    = { location = "canadacentral", ip_addresses = ["10.242.74.81"] }
  "ipgrp-keyvault-endpoint"                                            = { location = "canadacentral", ip_addresses = ["10.195.6.4"] }
  "ipgrp-key-vault-endpoint"                                           = { location = "canadacentral", ip_addresses = ["10.195.73.182"] }
  "ipgrp-kvspoprod-canadacentral-001"                                  = { location = "canadacentral", ip_addresses = ["10.195.124.4"] }
  "ipgrp-lims-sql-endpoint"                                            = { location = "canadacentral", ip_addresses = ["10.195.73.181"] }
  "ipgrp-onprem-controllers"                                           = { location = "canadacentral", ip_addresses = ["10.242.74.147/32", "10.242.74.148/32", "10.242.74.149/32", "172.25.6.17/32", "172.25.6.101/32"] }
  "ipgrp-onprem-infoblox"                                              = { location = "canadacentral", ip_addresses = ["10.242.82.58/32", "10.242.82.56/32", "172.25.4.15/32", "10.242.82.60/32", "142.52.239.60/32"] }
  "ipgrp-onprem-kdcbch"                                                = { location = "canadacentral", ip_addresses = ["10.242.69.32", "10.242.69.100", "10.242.69.101", "10.242.69.194", "10.242.69.195", "172.25.6.58"] }
  "ipgrp-onprem-kdcbch-ips"                                            = { location = "canadacentral", ip_addresses = [] }
  "ipgrp-onprem-subnets"                                               = { location = "canadacentral", ip_addresses = ["10.0.0.0-10.192.255.255", "10.197.0.0-10.255.255.255", "172.16.0.0/12", "192.168.0.0/16", "142.52.0.0/16", "155.190.0.0/16"] }
  "ipgrp-onprem-to-clzdb-subnets"                                      = { location = "canadacentral", ip_addresses = ["142.52.206.1-142.52.237.255", "142.52.198.1-142.52.202.255", "142.52.194.1-142.52.196.255", "142.52.150.1-142.52.191.255", "142.52.0.1-142.52.133.255", "10.171.0.0/19", "10.171.32.0/19", "10.171.48.0/20", "10.172.120.0/21", "10.172.128.0/21", "10.172.160.0/21", "10.172.200.0/21", "10.173.0.0/17", "10.181.10.0/24", "10.49.0.0/16", "10.60.0.0/16", "10.60.0.0/16", "10.74.0.0/16", "10.75.0.0/16", "10.76.0.0/16", "142.52.252.0/24", "172.16.0.0/16", "172.20.0.0/16", "172.21.0.0/21", "172.22.0.0/16", "172.23.0.0/16", "172.24.0.0/16", "172.28.0.0/16", "172.29.0.0/16", "10.244.23.226", "10.244.21.54", "10.244.21.54", "10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "142.52.0.0/16"] }
  "ipgrp-onprem-unix-satellite-servers"                                = { location = "canadacentral", ip_addresses = ["10.242.82.212", "172.25.5.84"] }
  "ipgrp-openai-prod-acropenaiprodcc001"                               = { location = "canadacentral", ip_addresses = ["10.195.12.4", "10.195.12.5"] }
  "ipgrp-pea-app-qa"                                                   = { location = "canadacentral", ip_addresses = ["10.195.132.230"] }
  "ipgrp-pea-appconfig-qa"                                             = { location = "canadacentral", ip_addresses = ["10.195.132.232"] }
  "ipgrp-pea-keyvault-qa"                                              = { location = "canadacentral", ip_addresses = ["10.195.132.231"] }
  "ipgrp-pep-appcs-boundary-test-canadacentral-001"                    = { location = "canadacentral", ip_addresses = ["10.195.68.104"] }
  "ipgrp-pep-auritas-nonprod-canadacentral"                            = { location = "canadacentral", ip_addresses = ["10.195.121.200/32", "10.195.121.199/32"] }
  "ipgrp-pep-auritas-prod-canadacentral"                               = { location = "canadacentral", ip_addresses = ["10.195.121.10", "10.195.121.12"] }
  "ipgrp-pep-df-fabric-nonprod-canadacentral-001"                      = { location = "canadacentral", ip_addresses = ["10.195.127.134"] }
  "ipgrp-pep-ecsi-app-service-endpoint-test"                           = { location = "canadacentral", ip_addresses = ["10.195.69.198"] }
  "ipgrp-pep-ecsi-endpoint-test"                                       = { location = "canadacentral", ip_addresses = ["10.195.69.198", "10.195.69.199", "10.195.69.200"] }
  "ipgrp-pep-ecsi-sql-service-endpoint-test"                           = { location = "canadacentral", ip_addresses = ["10.195.69.200"] }
  "ipgrp-pep-ecsi2-endpoint-test"                                      = { location = "canadacentral", ip_addresses = ["10.195.69.198", "10.195.69.199", "10.195.69.200", "10.195.69.201"] }
  "ipgrp-pep-func-boundary-test-canadacentral-001"                     = { location = "canadacentral", ip_addresses = ["10.195.68.103"] }
  "ipgrp-pep-func-wrap-test-canadacentral-001"                         = { location = "canadacentral", ip_addresses = ["10.195.68.42"] }
  "ipgrp-pep-gom-keyvault"                                             = { location = "canadacentral", ip_addresses = ["10.195.70.166"] }
  "ipgrp-pep-gom-storageblob"                                          = { location = "canadacentral", ip_addresses = ["10.195.70.167"] }
  "ipgrp-pep-kdcazdevjumpp1"                                           = { location = "canadacentral", ip_addresses = ["10.242.112.1"] }
  "ipgrp-pep-kdcazdevjumpp2"                                           = { location = "canadacentral", ip_addresses = ["10.242.112.2"] }
  "ipgrp-pep-kdcbchbidgp1"                                             = { location = "canadacentral", ip_addresses = ["10.242.33.24"] }
  "ipgrp-pep-kdcbchbidgt1"                                             = { location = "canadacentral", ip_addresses = ["10.242.33.1"] }
  "ipgrp-pep-kdcbchbidgt2"                                             = { location = "canadacentral", ip_addresses = ["10.242.33.32"] }
  "ipgrp-pep-kdcbchclzjmp01"                                           = { location = "canadacentral", ip_addresses = ["10.242.112.5"] }
  "ipgrp-pep-kdcbchclzjmp02"                                           = { location = "canadacentral", ip_addresses = ["10.242.112.6"] }
  "ipgrp-pep-kdcbchclzjmp06"                                           = { location = "canadacentral", ip_addresses = ["10.242.112.10"] }
  "ipgrp-pep-kdcbchclzjmp07"                                           = { location = "canadacentral", ip_addresses = ["10.242.112.11"] }
  "ipgrp-pep-kdcbchclzjmp08"                                           = { location = "canadacentral", ip_addresses = ["10.242.112.12"] }
  "ipgrp-pep-kdcbchclzjmp09"                                           = { location = "canadacentral", ip_addresses = ["10.242.112.13"] }
  "ipgrp-pep-kdcbchepo1"                                               = { location = "canadacentral", ip_addresses = ["10.242.238.1"] }
  "ipgrp-pep-kdcbchepotie1"                                            = { location = "canadacentral", ip_addresses = ["10.242.238.4"] }
  "ipgrp-pep-kdcbchlimsdcc1"                                           = { location = "canadacentral", ip_addresses = ["10.242.237.34"] }
  "ipgrp-pep-kdcbchpsdbd02"                                            = { location = "canadacentral", ip_addresses = ["10.242.139.42"] }
  "ipgrp-pep-kdcbchpsdbp02"                                            = { location = "canadacentral", ip_addresses = ["10.242.69.86"] }
  "ipgrp-pep-kdcbchsqld01"                                             = { location = "canadacentral", ip_addresses = ["10.242.82.31"] }
  "ipgrp-pep-kdcbchsqlp01"                                             = { location = "canadacentral", ip_addresses = ["10.242.82.32"] }
  "ipgrp-pep-kdcbchsqlt01"                                             = { location = "canadacentral", ip_addresses = ["10.242.82.33"] }
  "ipgrp-pep-kdcejasut1"                                               = { location = "canadacentral", ip_addresses = ["10.242.74.83"] }
  "ipgrp-pep-kdcendbt1"                                                = { location = "canadacentral", ip_addresses = ["10.242.74.84"] }
  "ipgrp-pep-kv-spo-nonprod-cc"                                        = { location = "canadacentral", ip_addresses = ["10.195.125.4"] }
  "ipgrp-pep-kvboundarytestcac001"                                     = { location = "canadacentral", ip_addresses = ["10.195.68.102"] }
  "ipgrp-pep-kvfabricnonprodcc001"                                     = { location = "canadacentral", ip_addresses = ["10.195.127.132"] }
  "ipgrp-pep-kvfabricnonprodcc001-vm-fabric-nonprod-canadacentral-001" = { location = "canadacentral", ip_addresses = [] }
  "ipgrp-pep-kvfabricprodcac001"                                       = { location = "canadacentral", ip_addresses = ["10.195.123.132"] }
  "ipgrp-pep-kvwraptestcc001"                                          = { location = "canadacentral", ip_addresses = ["10.195.68.40"] }
  "ipgrp-pep-lims-dev-win-vm"                                          = { location = "canadacentral", ip_addresses = ["10.195.132.102"] }
  "ipgrp-pep-lims-key-vault"                                           = { location = "canadacentral", ip_addresses = ["10.195.132.70"] }
  "ipgrp-pep-lims-sql-endpoint"                                        = { location = "canadacentral", ip_addresses = ["10.195.132.69"] }
  "ipgrp-pep-pea-private-endpoint"                                     = { location = "canadacentral", ip_addresses = ["10.195.69.5", "10.195.69.6", "10.195.69.7", "10.195.69.8", "10.195.69.41"] }
  "ipgrp-pep-pei-sql-endpoint"                                         = { location = "canadacentral", ip_addresses = ["10.195.69.41"] }
  "ipgrp-pep-psql-openai-nonprod-cc-001"                               = { location = "canadacentral", ip_addresses = ["10.195.28.13"] }
  "ipgrp-pep-psql-openai-prod-cc-001"                                  = { location = "canadacentral", ip_addresses = ["10.195.12.11"] }
  "ipgrp-pep-stazpkcapture-prod-canadacentral-001"                     = { location = "canadacentral", ip_addresses = ["10.195.6.24"] }
  "ipgrp-pep-stboundaryenc001"                                         = { location = "canadacentral", ip_addresses = ["10.195.68.101"] }
  "ipgrp-pep-stfabricnonprodcac001"                                    = { location = "canadacentral", ip_addresses = ["10.195.127.135", "10.195.127.133"] }
  "ipgrp-pep-stfabricprodcac001"                                       = { location = "canadacentral", ip_addresses = ["10.195.123.135", "10.195.123.134"] }
  "ipgrp-pep-stprodcloudassetcc001"                                    = { location = "canadacentral", ip_addresses = ["10.195.100.132"] }
  "ipgrp-pep-stwraptestcc001"                                          = { location = "canadacentral", ip_addresses = ["10.195.68.41"] }
  "ipgrp-pep-vm-fabric-nonprod-canadacentral-001"                      = { location = "canadacentral", ip_addresses = ["10.195.127.4"] }
  "ipgrp-shipping-doc-vm"                                              = { location = "canadacentral", ip_addresses = ["10.195.122.198"] }
  "ipgrp-snet-app-lims-dev-canadacentral-001"                          = { location = "canadacentral", ip_addresses = ["10.195.132.96/27"] }
  "ipgrp-snet-app-lims-stg-canadacentral-001"                          = { location = "canadacentral", ip_addresses = ["10.195.73.128/27"] }
  "ipgrp-snet-app-pea-qa"                                              = { location = "canadacentral", ip_addresses = ["10.195.132.192/27"] }
  "ipgrp-snet-auritas-nonprod-app-canadacentral-001"                   = { location = "canadacentral", ip_addresses = ["10.195.121.128/26"] }
  "ipgrp-snet-auritas-nonprod-pep-canadacentral-001"                   = { location = "canadacentral", ip_addresses = ["10.195.121.192/26"] }
  "ipgrp-snet-auritas-prod-app-canadacentral-001"                      = { location = "canadacentral", ip_addresses = ["10.195.121.64/26"] }
  "ipgrp-snet-auritas-prod-pep-canadacentral-001"                      = { location = "canadacentral", ip_addresses = ["10.195.121.0/26"] }
  "ipgrp-snet-pep-boundary-test-canadacentral-001"                     = { location = "canadacentral", ip_addresses = ["10.195.68.96/27"] }
  "ipgrp-snet-sql-pea-dev-canadacentral-001"                           = { location = "canadacentral", ip_addresses = ["10.195.69.32/27"] }
  "ipgrp-tkdcdbmontr"                                                  = { location = "canadacentral", ip_addresses = ["10.242.83.125"] }
  "ipgrp-tkdcgomapp1"                                                  = { location = "canadacentral", ip_addresses = ["10.242.82.140"] }
  "ipgrp-vm-fabric-prod-canadacentral"                                 = { location = "canadacentral", ip_addresses = ["10.195.123.4", "10.195.123.5"] }
  "ipgrp-vm-openai-prod-canadacentral-001"                             = { location = "canadacentral", ip_addresses = ["10.195.14.4"] }
  "ipgrp-vnet-auritas-nonprod-canadacentral"                           = { location = "canadacentral", ip_addresses = ["10.195.121.128/25"] }
  "ipgrp-vnet-auritas-prod-canadacentral"                              = { location = "canadacentral", ip_addresses = ["10.195.121.0/25"] }
  "ipgrp-vnet-boundary-test-canadacentral-001"                         = { location = "canadacentral", ip_addresses = ["10.195.68.64/26"] }
  "ipgrp-vnet-cswt-test-canadacentral-001"                             = { location = "canadacentral", ip_addresses = ["10.195.73.64/27"] }
  "ipgrp-vnet-dthree-appservice-prod-canadacentral"                    = { location = "canadacentral", ip_addresses = ["10.195.68.160/27"] }
  "ipgrp-vnet-dthree-dev-canadacentral"                                = { location = "canadacentral", ip_addresses = ["10.195.68.128/25"] }
  "ipgrp-vnet-fabric-nonprod-canadacentral"                            = { location = "canadacentral", ip_addresses = ["10.195.127.0/24"] }
  "ipgrp-vnet-fabric-prod-canadacentral"                               = { location = "canadacentral", ip_addresses = ["10.195.123.0/24"] }
  "ipgrp-vnet-githubrunner-nonprod-canadacentral"                      = { location = "canadacentral", ip_addresses = ["10.195.114.0/27"] }
  "ipgrp-vnet-githubrunner-prod-canadacentral"                         = { location = "canadacentral", ip_addresses = ["10.195.115.0/27"] }
  "ipgrp-vnet-gom-prod-canadacentral-001"                              = { location = "canadacentral", ip_addresses = ["10.195.20.128/26"] }
  "ipgrp-vnet-gom-test-canadacentral"                                  = { location = "canadacentral", ip_addresses = ["10.195.70.128/27"] }
  "ipgrp-vnet-lims-stg-canadacentral-001"                              = { location = "canadacentral", ip_addresses = ["10.195.73.128/26"] }
  "ipgrp-vnet-mds-prod-canadacentral"                                  = { location = "canadacentral", ip_addresses = ["10.195.120.0/24"] }
  "ipgrp-vnet-mft-dev-canadacentral"                                   = { location = "canadacentral", ip_addresses = ["10.195.126.0/26"] }
  "ipgrp-vnet-mft-nonprod-canadacentral"                               = { location = "canadacentral", ip_addresses = ["10.195.126.0/26"] }
  "ipgrp-vnet-mft-prod-canadacentral-001"                              = { location = "canadacentral", ip_addresses = ["10.195.73.0/26"] }
  "ipgrp-vnet-openai-nonprod-canadacentral-001"                        = { location = "canadacentral", ip_addresses = ["10.195.28.0/22"] }
  "ipgrp-vnet-pea-dev-canadacentral-001"                               = { location = "canadacentral", ip_addresses = ["10.195.69.64/27"] }
  "ipgrp-vnet-pei-appservice-prod-canadacentral"                       = { location = "canadacentral", ip_addresses = ["10.195.69.64/27"] }
  "ipgrp-vnet-sharedsvc-nonprod-gw-canadacentral-001"                  = { location = "canadacentral", ip_addresses = ["10.195.134.0/24"] }
  "ipgrp-vnet-solace-nonprod-canadacentral"                            = { location = "canadacentral", ip_addresses = ["10.195.112.0/24"] }
  "ipgrp-vnet-solace-prod-canadacentral"                               = { location = "canadacentral", ip_addresses = ["10.195.113.0/24"] }
  "ipgrp-vnet-spo-nonprod-canadacentral"                               = { location = "canadacentral", ip_addresses = ["10.195.125.0/24"] }
  "ipgrp-vnet-spo-nonprod-canadaeast"                                  = { location = "canadacentral", ip_addresses = ["10.196.125.0/24"] }
  "ipgrp-vnet-spo-prod-canadacentral-001"                              = { location = "canadacentral", ip_addresses = ["10.195.124.0/24"] }
  "ipgrp-vnet-spo-prod-canadaeast-001"                                 = { location = "canadacentral", ip_addresses = ["10.196.124.0/24"] }
  "ipgrp-vnet-transit-connectivity-canadacentral"                      = { location = "canadacentral", ip_addresses = ["10.195.122.0/26"] }
  "ipgrp-w3tecm"                                                       = { location = "canadacentral", ip_addresses = ["10.242.83.151"] }
  "psql-openai-nonprod-cc-001"                                         = { location = "canadacentral", ip_addresses = ["10.195.28.13"] }
  "snet-fabric-nonprod-vdg-canadacentral-001"                          = { location = "canadacentral", ip_addresses = ["10.195.127.64/26"] }
}
