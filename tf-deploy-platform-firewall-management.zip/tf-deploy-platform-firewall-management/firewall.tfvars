# ── Shared ─────────────────────────────────────────────────────────────
# The connectivity subscription. Firewall and IP groups only; every resource
# group here is read through data.tf and owned by az-sub-connectivity-lz.
subscription_id = "f3835bc1-9829-4ac8-9d7a-0999e0b29b90"
environment     = "prod"

tags = {
  owner = "connectivity-platform"
}

# ── Resource groups read from the connectivity workspace ───────────────
hub_cc_resource_group_name    = "rg-hub-connectivity-canadacentral-001"
hub_ce_resource_group_name    = "rg-hub-connectivity-canadaeast-001"
shared_cc_resource_group_name = "rg-shared-connectivity-canadacentral-001"
ip_groups_resource_group_name = "rg-ip-groups-connectivity-global"

# ── Cross-subscription references ──────────────────────────────────────
# SIEM workspace, security subscription. TODO confirm the subscription id
# before the first plan: the value below is the resource path only and the
# placeholder subscription will not resolve.
firewall_insights_workspace_id = "/subscriptions/REPLACE_SECURITY_SUBSCRIPTION_ID/resourceGroups/rg-siem-security-canadacentral-001/providers/Microsoft.OperationalInsights/workspaces/la-siem-security-canadacentral-001"

# mid-azfirewall, identity subscription. Managed by sub-identity-lz.
firewall_uami_id = "/subscriptions/b6dc12b1-645d-4a43-b08f-50c862f793d0/resourceGroups/rg-mid-identity-canadacentral-001/providers/Microsoft.ManagedIdentity/userAssignedIdentities/mid-azfirewall-canadacentral-001"

# TLS inspection certificate. The key vault (kvfwtlscanadacentral) is managed by
# sub-identity-lz; the versioned secret id is what the policy pins, so it has to
# be updated here on certificate rotation.
firewall_tls_certificate = {
  name                = "azkv-fw-tls-cert"
  key_vault_secret_id = "https://kvfwtlscanadacentral.vault.azure.net/secrets/azkv-fw-tls-cert/0393397970c443b4be90c8928137ef62"
}

# ── Feature flags ──────────────────────────────────────────────────────
enable_firewall  = true
enable_ip_groups = true

# ── IP groups (89) ─────────────────────────────────────────────────────
# Moved from az-sub-connectivity-lz with the firewall tier. Referenced only by
# the policy rule collections in firewall.tf.
ip_groups = {
  "ipgrp-app-openai-nonprod-canadacentral-001"                         = { location = "canadacentral", ip_addresses = ["10.195.28.9"] }
  "ipgrp-app-openai-prod-canadacentral-001"                            = { location = "canadacentral", ip_addresses = ["10.195.12.9"] }
  "ipgrp-bchsiops-jumphost"                                            = { location = "canadacentral", ip_addresses = ["10.242.30.30", "172.25.81.3"] }
  "ipgrp-cacentral-caeast-ertest-vm"                                   = { location = "canadacentral", ip_addresses = ["10.195.118.7", "10.195.118.8", "10.196.114.7"] }
  "ipgrp-cacentral-clz-dev-subnets"                                    = { location = "canadacentral", ip_addresses = ["10.195.96.0/22", "10.195.80.0/22", "10.195.64.0/22", "172.17.0.0/22", "172.18.0.0/16", "172.16.0.0/16", "172.19.0.0/16", "172.20.0.0/16", "10.0.0.0/16"] }
  "ipgrp-cacentral-clz-dns-resolvers"                                  = { location = "canadacentral", ip_addresses = ["10.195.1.4/32", "10.196.1.4/32", "10.195.4.7/32"] }
  "ipgrp-cacentral-clz-monitor"                                        = { location = "canadacentral", ip_addresses = ["10.195.6.7/32", "10.195.6.14/32", "10.195.6.17/32", "10.195.6.18/32", "10.195.6.8/32", "10.195.6.12/32", "10.195.6.15/32", "10.195.6.9/32", "10.195.6.11/32", "10.195.6.10/32"] }
  "ipgrp-cacentral-clz-prod-subnets"                                   = { location = "canadacentral", ip_addresses = ["10.195.48.0/22", "10.195.116.0/26", "10.195.4.0/22", "10.195.118.0/23", "10.196.114.0/23", "10.195.32.0/22", "10.195.16.0/22", "10.195.114.0/23", "10.195.117.0/24"] }
  "ipgrp-cacentral-clz-subnets"                                        = { location = "canadacentral", ip_addresses = ["10.195.0.0/16"] }
  "ipgrp-cacentral-cops-nonprod-vnet"                                  = { location = "canadacentral", ip_addresses = ["10.195.96.0/22"] }
  "ipgrp-cacentral-cops-prod-vnet"                                     = { location = "canadacentral", ip_addresses = ["10.195.48.0/22"] }
  "ipgrp-cacentral-cyberark-vm-ips"                                    = { location = "canadacentral", ip_addresses = ["10.195.116.4", "10.195.116.5"] }
  "ipgrp-cacentral-cyberark-vnet"                                      = { location = "canadacentral", ip_addresses = ["10.195.116.0/26"] }
  "ipgrp-cacentral-dev-runner-ips"                                     = { location = "canadacentral", ip_addresses = ["10.195.114.7"] }
  "ipgrp-cacentral-dns-connectivity-vnet"                              = { location = "canadacentral", ip_addresses = ["10.195.4.0/22"] }
  "ipgrp-cacentral-ertest-vnet"                                        = { location = "canadacentral", ip_addresses = ["10.195.118.0/23"] }
  "ipgrp-cacentral-fit-nonprod-vnet"                                   = { location = "canadacentral", ip_addresses = ["10.195.80.0/22"] }
  "ipgrp-cacentral-fit-prod-vnet"                                      = { location = "canadacentral", ip_addresses = ["10.195.32.0/22"] }
  "ipgrp-cacentral-hosted-runners"                                     = { location = "canadacentral", ip_addresses = ["10.195.114.7/32", "10.195.115.7/32", "10.195.114.9/32", "10.195.115.9/32"] }
  "ipgrp-cacentral-hosted-runners-vnet"                                = { location = "canadacentral", ip_addresses = ["10.195.114.0/23"] }
  "ipgrp-cacentral-mds-ips"                                            = { location = "canadacentral", ip_addresses = ["10.195.120.4/32", "10.195.120.5/32", "10.195.120.6/32", "10.195.120.7/32", "10.195.120.8/32", "10.195.120.9/32"] }
  "ipgrp-cacentral-nonprod-cops-apps"                                  = { location = "canadacentral", ip_addresses = ["10.195.98.8/32", "10.195.98.7/32", "10.195.96.0/24", "10.195.50.8/32", "10.195.50.6/32", "10.195.48.0/26"] }
  "ipgrp-cacentral-nonprod-cops-db"                                    = { location = "canadacentral", ip_addresses = ["10.195.98.6/32", "10.195.50.7/32"] }
  "ipgrp-cacentral-nonprod-fit-apps"                                   = { location = "canadacentral", ip_addresses = ["10.195.82.6/32", "10.195.82.7/32", "10.195.80.4/32", "10.195.80.0/24", "10.195.81.4/32", "10.195.33.4", "10.195.32.4", "10.195.34.8"] }
  "ipgrp-cacentral-nonprod-pta-apps"                                   = { location = "canadacentral", ip_addresses = ["10.195.64.132/32", "10.195.64.4/32"] }
  "ipgrp-cacentral-nonprod-pta-db"                                     = { location = "canadacentral", ip_addresses = ["10.195.66.6/32"] }
  "ipgrp-cacentral-prod-cops-apps"                                     = { location = "canadacentral", ip_addresses = ["10.195.48.0/26"] }
  "ipgrp-cacentral-prod-cops-db"                                       = { location = "canadacentral", ip_addresses = ["10.195.49.0/26"] }
  "ipgrp-cacentral-prod-fit-apps"                                      = { location = "canadacentral", ip_addresses = ["10.195.32.4/32", "10.195.34.8", "10.195.34.0/24", "10.195.32.0/24"] }
  "ipgrp-cacentral-prod-pta-apps"                                      = { location = "canadacentral", ip_addresses = ["10.195.16.4/32"] }
  "ipgrp-cacentral-prod-pta-db"                                        = { location = "canadacentral", ip_addresses = ["10.195.18.6/32"] }
  "ipgrp-cacentral-prod-runner-ips"                                    = { location = "canadacentral", ip_addresses = ["10.195.115.7"] }
  "ipgrp-cacentral-pta-nonprod-vnet"                                   = { location = "canadacentral", ip_addresses = ["10.195.64.0/22"] }
  "ipgrp-cacentral-pta-prod-vnet"                                      = { location = "canadacentral", ip_addresses = ["10.195.16.0/22"] }
  "ipgrp-cacentral-sandbox-cacentral-1-vnet"                           = { location = "canadacentral", ip_addresses = ["172.17.0.0/16"] }
  "ipgrp-cacentral-sandbox-cacentral-2-vnet"                           = { location = "canadacentral", ip_addresses = ["172.18.0.0/16"] }
  "ipgrp-cacentral-sandbox-cacentral-vnet"                             = { location = "canadacentral", ip_addresses = ["172.16.0.0/16"] }
  "ipgrp-cacentral-shared-connectivity-vnet"                           = { location = "canadacentral", ip_addresses = ["10.195.117.0/24"] }
  "ipgrp-caeast-clz-dns-resolvers"                                     = { location = "canadacentral", ip_addresses = ["10.196.1.4"] }
  "ipgrp-caeast-clz-subnets"                                           = { location = "canadacentral", ip_addresses = ["10.196.0.0/16"] }
  "ipgrp-caeast-ertest-vnet"                                           = { location = "canadacentral", ip_addresses = ["10.196.114.0/23"] }
  "ipgrp-cc-ns2-subnet"                                                = { location = "canadacentral", ip_addresses = ["10.237.0.0/21"] }
  "ipgrp-clz-monitor-ips"                                              = { location = "canadacentral", ip_addresses = ["10.195.6.7/32", "10.195.6.14/32", "10.195.6.17/32", "10.195.6.18/32", "10.195.6.8/32", "10.195.6.12/32", "10.195.6.15/32", "10.195.6.9/32", "10.195.6.11/32", "10.195.6.10/32", "10.195.6.13/32", "10.195.6.6/32", "10.195.6.5/32", "10.195.82.8/32", "10.195.82.9/32", "10.195.66.7/32", "10.195.66.8/32", "10.195.6.20/32", "10.195.6.21/32", "10.195.6.22/32"] }
  "ipgrp-ertest-vm-ips"                                                = { location = "canadacentral", ip_addresses = ["10.195.118.7", "10.195.118.8", "10.196.114.7"] }
  "ipgrp-func-openai-nonprod-canadacentral-001"                        = { location = "canadacentral", ip_addresses = ["10.195.28.10"] }
  "ipgrp-func-openai-prod-canadacentral-001"                           = { location = "canadacentral", ip_addresses = ["10.195.12.10"] }
  "ipgrp-ipgrp-pep-auritas-prod-canadacentral"                         = { location = "canadacentral", ip_addresses = ["10.195.121.10", "10.195.121.12"] }
  "ipgrp-kdcbch-ips"                                                   = { location = "canadacentral", ip_addresses = ["10.242.69.32", "10.242.69.100", "10.242.69.101", "10.242.69.194", "10.242.69.195", "172.25.6.58"] }
  "ipgrp-kvspoprod-canadacentral-001"                                  = { location = "canadacentral", ip_addresses = ["10.195.124.4"] }
  "ipgrp-onprem-controllers"                                           = { location = "canadacentral", ip_addresses = ["10.242.74.147/32", "10.242.74.148/32", "10.242.74.149/32", "172.25.6.17/32", "172.25.6.101/32"] }
  "ipgrp-onprem-infoblox"                                              = { location = "canadacentral", ip_addresses = ["10.242.82.58/32", "10.242.82.56/32", "172.25.4.15/32", "10.242.82.60/32", "142.52.239.60/32"] }
  "ipgrp-onprem-kdcbch-ips"                                            = { location = "canadacentral", ip_addresses = [] }
  "ipgrp-onprem-kdcbch"                                                = { location = "canadacentral", ip_addresses = ["10.242.69.32", "10.242.69.100", "10.242.69.101", "10.242.69.194", "10.242.69.195", "172.25.6.58"] }
  "ipgrp-onprem-subnets"                                               = { location = "canadacentral", ip_addresses = ["10.0.0.0-10.192.255.255", "10.197.0.0-10.255.255.255", "172.16.0.0/12", "192.168.0.0/16", "142.52.0.0/16", "155.190.0.0/16"] }
  "ipgrp-onprem-to-clzdb-subnets"                                      = { location = "canadacentral", ip_addresses = ["142.52.206.1-142.52.237.255", "142.52.198.1-142.52.202.255", "142.52.194.1-142.52.196.255", "142.52.150.1-142.52.191.255", "142.52.0.1-142.52.133.255", "10.171.0.0/19", "10.171.32.0/19", "10.171.48.0/20", "10.172.120.0/21", "10.172.128.0/21", "10.172.160.0/21", "10.172.200.0/21", "10.173.0.0/17", "10.181.10.0/24", "10.49.0.0/16", "10.60.0.0/16", "10.60.0.0/16", "10.74.0.0/16", "10.75.0.0/16", "10.76.0.0/16", "142.52.252.0/24", "172.16.0.0/16", "172.20.0.0/16", "172.21.0.0/21", "172.22.0.0/16", "172.23.0.0/16", "172.24.0.0/16", "172.28.0.0/16", "172.29.0.0/16", "10.244.23.226", "10.244.21.54", "10.244.21.54", "10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "142.52.0.0/16"] }
  "ipgrp-onprem-unix-satellite-servers"                                = { location = "canadacentral", ip_addresses = ["10.242.82.212", "172.25.5.84"] }
  "ipgrp-openai-prod-acropenaiprodcc001"                               = { location = "canadacentral", ip_addresses = ["10.195.12.4", "10.195.12.5"] }
  "ipgrp-pep-auritas-nonprod-canadacentral"                            = { location = "canadacentral", ip_addresses = ["10.195.121.200/32", "10.195.121.199/32"] }
  "ipgrp-pep-auritas-prod-canadacentral"                               = { location = "canadacentral", ip_addresses = ["10.195.121.10", "10.195.121.12"] }
  "ipgrp-pep-df-fabric-nonprod-canadacentral-001"                      = { location = "canadacentral", ip_addresses = ["10.195.127.134"] }
  "ipgrp-pep-kdcazdevjumpp1"                                           = { location = "canadacentral", ip_addresses = ["10.242.112.1"] }
  "ipgrp-pep-kv-spo-nonprod-cc"                                        = { location = "canadacentral", ip_addresses = ["10.195.125.4"] }
  "ipgrp-pep-kvfabricnonprodcc001"                                     = { location = "canadacentral", ip_addresses = ["10.195.127.132"] }
  "ipgrp-pep-kvfabricnonprodcc001-vm-fabric-nonprod-canadacentral-001" = { location = "canadacentral", ip_addresses = [] }
  "ipgrp-pep-kvfabricprodcac001"                                       = { location = "canadacentral", ip_addresses = ["10.195.123.132"] }
  "ipgrp-pep-psql-openai-nonprod-cc-001"                               = { location = "canadacentral", ip_addresses = ["10.195.28.13"] }
  "ipgrp-pep-psql-openai-prod-cc-001"                                  = { location = "canadacentral", ip_addresses = ["10.195.12.11"] }
  "ipgrp-pep-stazpkcapture-prod-canadacentral-001"                     = { location = "canadacentral", ip_addresses = ["10.195.6.24"] }
  "ipgrp-pep-stfabricnonprodcac001"                                    = { location = "canadacentral", ip_addresses = ["10.195.127.135", "10.195.127.133"] }
  "ipgrp-pep-stfabricprodcac001"                                       = { location = "canadacentral", ip_addresses = ["10.195.123.135", "10.195.123.134"] }
  "ipgrp-pep-vm-fabric-nonprod-canadacentral-001"                      = { location = "canadacentral", ip_addresses = ["10.195.127.4"] }
  "ipgrp-snet-auritas-nonprod-app-canadacentral-001"                   = { location = "canadacentral", ip_addresses = ["10.195.121.128/26"] }
  "ipgrp-snet-auritas-nonprod-pep-canadacentral-001"                   = { location = "canadacentral", ip_addresses = ["10.195.121.192/26"] }
  "ipgrp-snet-auritas-prod-app-canadacentral-001"                      = { location = "canadacentral", ip_addresses = ["10.195.121.64/26"] }
  "ipgrp-snet-auritas-prod-pep-canadacentral-001"                      = { location = "canadacentral", ip_addresses = ["10.195.121.0/26"] }
  "ipgrp-vm-openai-prod-canadacentral-001"                             = { location = "canadacentral", ip_addresses = ["10.195.14.4"] }
  "ipgrp-vnet-auritas-nonprod-canadacentral"                           = { location = "canadacentral", ip_addresses = ["10.195.121.128/25"] }
  "ipgrp-vnet-auritas-prod-canadacentral"                              = { location = "canadacentral", ip_addresses = ["10.195.121.0/25"] }
  "ipgrp-vnet-fabric-nonprod-canadacentral"                            = { location = "canadacentral", ip_addresses = ["10.195.127.0/24"] }
  "ipgrp-vnet-fabric-prod-canadacentral"                               = { location = "canadacentral", ip_addresses = ["10.195.123.0/24"] }
  "ipgrp-vnet-mds-prod-canadacentral"                                  = { location = "canadacentral", ip_addresses = ["10.195.120.0/24"] }
  "ipgrp-vnet-openai-nonprod-canadacentral-001"                        = { location = "canadacentral", ip_addresses = ["10.195.28.0/22"] }
  "ipgrp-vnet-solace-nonprod-canadacentral"                            = { location = "canadacentral", ip_addresses = ["10.195.112.0/24"] }
  "ipgrp-vnet-spo-nonprod-canadacentral"                               = { location = "canadacentral", ip_addresses = ["10.195.125.0/24"] }
  "ipgrp-vnet-spo-nonprod-canadaeast"                                  = { location = "canadacentral", ip_addresses = ["10.196.125.0/24"] }
  "ipgrp-vnet-spo-prod-canadacentral-001"                              = { location = "canadacentral", ip_addresses = ["10.195.124.0/24"] }
  "ipgrp-vnet-spo-prod-canadaeast-001"                                 = { location = "canadacentral", ip_addresses = ["10.196.124.0/24"] }
  "ipgrp-vnet-transit-connectivity-canadacentral"                      = { location = "canadacentral", ip_addresses = ["10.195.122.0/26"] }
  "psql-openai-nonprod-cc-001"                                         = { location = "canadacentral", ip_addresses = ["10.195.28.13"] }
}
