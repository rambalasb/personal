data "azurerm_subscription" "current" {}

# Read-only. az-sub-connectivity-lz is the sole owner of these resource groups;
# reading them here means a firewall apply cannot retag or delete one, and the
# plan fails early with a clear error if a group is missing rather than
# producing a firewall create against a resource group that does not exist.

data "azurerm_resource_group" "hub_cc" {
  name = var.hub_cc_resource_group_name
}

data "azurerm_resource_group" "hub_ce" {
  name = var.hub_ce_resource_group_name
}

data "azurerm_resource_group" "shared_cc" {
  name = var.shared_cc_resource_group_name
}

data "azurerm_resource_group" "ip_groups" {
  name = var.ip_groups_resource_group_name
}
