terraform {
  required_version = ">= 1.10, < 2.0"

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 4.37.0, < 5.0.0"
    }
    # The firewall and firewall-policy wrappers pull the AVM telemetry provider.
    modtm = {
      source  = "Azure/modtm"
      version = "~> 0.3"
    }
    random = {
      source  = "hashicorp/random"
      version = "~> 3.6"
    }
  }

  cloud {
    organization = "BC_Hydro"

    # Separate workspace from az-platform-connectivity: same subscription, but
    # firewall rules change on a different cadence than the network estate and
    # a rule apply must not be able to touch VNets, hubs or gateways.
    workspaces {
      name = "az-platform-firewall"
    }
  }
}

provider "azurerm" {
  subscription_id     = var.subscription_id
  storage_use_azuread = true
  features {}
}
