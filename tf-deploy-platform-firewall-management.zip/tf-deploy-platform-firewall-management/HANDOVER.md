# Terraform scope and handover: platform firewall management

The management boundary for the Azure Firewall estate in the connectivity
subscription: what Terraform owns, what it deliberately does not, and what remains before the first apply.

## Contents

1. [Summary of the boundary](#1-summary-of-the-boundary)
2. [What Terraform owns](#2-what-terraform-owns)
3. [What Terraform does not own](#3-what-terraform-does-not-own)
4. [Open items before the first apply](#4-open-items-before-the-first-apply)
5. [Why this repo is separate](#5-why-this-repo-is-separate)
6. [Repository and state locations](#6-repository-and-state-locations)
7. [Drift detection and monitoring](#7-drift-detection-and-monitoring)
8. [Reproducing the inventory](#8-reproducing-the-inventory)

## 1. Summary of the boundary

The split from `tf-deploy-platform-connectivity` is by **resource type**, not by resource
group. Three types belong to this repo wherever they sit in the subscription:

- `Microsoft.Network/azureFirewalls`
- `Microsoft.Network/firewallPolicies`
- `Microsoft.Network/ipGroups`

Everything else in the subscription — including all 12 resource groups, and
including the monitor alerts that watch the firewalls — belongs to
`tf-deploy-platform-connectivity`.

Two of the four resource groups this repo reads also hold connectivity-owned
resources, so **a resource group name does not tell you who owns what is inside
it**:

| Resource group | This repo's resources | Also holds (connectivity-owned) |
|---|---|---|
| `rg-hub-connectivity-canadacentral-001` | 1 firewall, 2 policies, 17 rule collection groups | vWAN hub, route tables, route maps, gateways, storage |
| `rg-hub-connectivity-canadaeast-001` | 1 firewall | vWAN hub, gateways |
| `rg-shared-connectivity-canadacentral-001` | 1 firewall (transit) | VNet, public IP, subnets |
| `rg-ip-groups-connectivity-global` | 193 IP groups | nothing else |
| `AzureBackupRG_canadacentral_1` | 2 IP groups | everything else |

## 2. What Terraform owns

**230 import blocks**: 31 in `pending_imports_firewall.tf` (23 resources, 8
diagnostic settings), 199 in `pending_imports_ip_groups.tf`. Rules and IP groups
reflect the 2026-10-05 export (`rule-collection-groups.json`, `ip-groups.json`).

| Object | Count | Where |
|---|---|---|
| Azure Firewall, secured vWAN hub (`AZFW_Hub`/Premium) | 2 | `rg-hub-connectivity-canadacentral-001`, `rg-hub-connectivity-canadaeast-001` |
| Azure Firewall, VNet-based (`AZFW_VNet`/Standard) | 1 | `rg-shared-connectivity-canadacentral-001` |
| Firewall policy | 2 | `rg-hub-connectivity-canadacentral-001` |
| Rule collection group | 17 | children of the two policies (8 live, 9 backup) |
| Rule collection | 137 | inside those groups (93 live, 44 backup); five empty ones are omitted (§3) |
| Network rule | 490 | inside those collections |
| Application rule | 28 | inside those collections |
| Classic network rule collection | 1 | `rc-allow-ns2-to-bch` on the transit firewall, native in `classic_rules.tf` |
| IP group | 199 | `rg-ip-groups-connectivity-global` (195), `rg-hub-connectivity-canadacentral-001` (2), `AzureBackupRG_canadacentral_1` (2) |
| Diagnostic setting | 8 | on the three firewalls, through the firewall wrapper's `diagnostic_settings` input. Firewall policies do not support diagnostic settings (`ResourceTypeNotSupported`). |

The rule collection groups go through the policy wrapper's
`rule_collection_group` submodule (`MODULE_GAPS.md`). 178 of the 199 IP groups
are referenced by the rules, which is why they sit with the firewall — a rule
change and the IP group it references change together.

### Diagnostic settings

Adopted as exported on 2026-09-28, in
`local.firewall_diagnostic_settings` in `firewall.tf`:

| Setting | Hub firewalls (cc, ce) | Transit firewall | Workspace |
|---|---|---|---|
| `sendMetricsToLA` | AllMetrics, destination `AzureDiagnostics` | AllMetrics, destination `Dedicated` | la-siem-management |
| `FirewallPolicySettings` | allLogs | — | la-siem-management |
| `sendLogsToLA` | 16 named categories | allLogs | la-siem-security |

**The hub firewalls ingest every log twice** — allLogs into la-siem-management
and the 16 categories into la-siem-security — and the 16 include both the legacy
`AzureFirewall*` categories and the resource-specific `AZFW*` ones, which
overlap. Adopted as-is. Trimming it is a cost decision for the owners of the two
workspaces; change `firewall.tf`, not the portal.

## 3. What Terraform does not own

### Owned by another repo, by design

| Object | Owner | Note |
|---|---|---|
| All 12 resource groups | `tf-deploy-platform-connectivity` | Read here through `data.tf`. A firewall apply cannot retag or delete one. |
| `firewall-connectivity-health` (metric alert), `firewall-connectivity-update` (activity log alert) | `tf-deploy-platform-connectivity`, `conn_alerts.tf` | Scoped to `azfw-connectivity-canadacentral-001` by constructed resource ID. They watch the firewall; they do not configure it, and they live with the rest of the alerts tier in `rg-alerts-connectivity-canadacentral-001`. |
| vWAN route next-hops pointing at the two hub firewalls | `tf-deploy-platform-connectivity`, `hub_vwan.tf` | Constructed IDs, not state references. No output crosses between the two workspaces in either direction. |
| `mid-azfirewall-canadacentral-001` (the policy's UAMI) | `sub-identity-lz` | Identity subscription. |
| `kvfwtlscanadacentral` (the TLS certificate's key vault) | `sub-identity-lz` | Identity subscription. The certificate secret itself is not managed by any repo; see that repo's handover. |
| `la-siem-security-canadacentral-001` (insights workspace, `sendLogsToLA`) | security LZ | Security subscription. |
| `la-siem-management-canadacentral-001` (`sendMetricsToLA`, `FirewallPolicySettings`) | management LZ | Management subscription. |
| `CanNotDelete` locks on the resource groups, including `rg-ip-groups-connectivity-global` | `tf-deploy-platform-connectivity` | Locks follow the resource they sit on, and the resource groups are connectivity's. None of the firewalls, policies or IP groups carries a lock of its own (`locks.json`, 2026-09-28). |

### Not owned by anything, and why

| Object | Why | What would change it |
|---|---|---|
| Five empty rule collections (see below) | The provider cannot represent a rule collection with zero rules. | Delete them in Azure — four are Allow collections with no rules, so they permit nothing; the Deny one denies nothing. Removing them changes no traffic decision. |
| `rc-allow-net-fit-to-esb-nonprod` (Allow, priority 41100) on the backup policy's `rcg-41000-spokes-to-onprem` | Same. | Same. |
| Policy assignments and exemptions affecting these resources | Inherited from management groups; outside this repo either way. | — |

The five, all omitted from `firewall.tf`:

| Rule collection group | Collection | Priority | Action |
| --- | --- | --- | --- |
| `rcg-1000-spoke-specific-canada-central` | `rc-allow-vnet-ertest-canadacentral-001-in` | 1211 | Allow |
| `rcg-1000-spoke-specific-canada-central` | `rc-allow-sap-aem-inbound` | 2520 | Allow |
| `rcg-1000-spoke-specific-canada-central` | `rc-deny-vnet-tibco-nonprod-canadacentral-in` | 5690 | Deny |
| `rcg-20000-spoke-specific-canada-east` | `rc-allow-vnet-ertest-canadaeast-001-in` | 20210 | Allow |
| `rcg-41000-spokes-to-onprem` | `rc-allow-net-fit-to-esb-nonprod` | 41100 | Allow |

## 4. Open items before the first apply

In the order they block progress.

1. **Re-run the speculative plan.** The 2026-09-28 plan resolved all its
   import addresses, but predates the classic collection (`classic_rules.tf`),
   the 2026-10-05 refresh (45 new rules, 4 new collections, 3 changed rules,
   20 new IP groups) and the tag and `api-version` fixes. Expect 230 imports;
   the changes it should show are under
   [Known plan diffs](#known-plan-diffs-on-first-import).
2. **Review three rules created in the portal after 2026-10-01.** Adopted as
   they are live, because an import must match Azure; correcting them is a
   reviewed change after the first apply.
   - **`rc-deny-vnet-mft-prod-canadacentral-001` (priority 5080) has action
     `Allow`.** Its one rule matches `ipgrp-vnet-mft-prod-canadacentral-001` to
     `*` on all ports, so the mft-prod VNet can currently reach anything. The
     name says deny; this is almost certainly meant to be `Deny`.
   - `rc-deny-vnet-lims-stg-canadacentral-in` holds a rule named
     `r-deny-vnet-pea-dev-canadacentral-001-inbound`. It matches lims-stg
     correctly; only the name was copied.
   - A rule in `rc-allow-net-onprem-to-central` is named `r-allow-`.
3. **Configure required reviewers on the `firewall` GitHub environment.**
   Without them `import-apply.yml` runs straight through with no approval stop.
4. **Decide the state position for the omitted rule collections.** All are
   empty and change no traffic decision (§3). Deleting them in Azure makes the
   configuration exact; leaving them means the repo is knowingly inexact in
   those places, which is fine as long as §3 says so.

Settled, and recorded here so they are not reopened:

- **`firewall_insights_workspace_id`** carries the security subscription's real
  ID (`7d54d6f7-…`), confirmed by the connectivity flow-log export pointing at
  the same workspace.
- **Import addresses** — the plan above resolved every one.
- **Diagnostic settings** — adopted (§2). **Resource locks** — none on this
  repo's resources (§3).
- **`rcg-300-cyberark-SIA-baseline`** (backup policy only) is the pre-March
  layout, not a lost group. Its four rules are on the live policy: the certs and
  dogwood rules unchanged in `rcg-800`, the Windows and Linux rules in
  `rcg-1000` with port 135 moved to its own exception rule in `rcg-490` and UDP
  dropped from the Linux rule. The backup policy is attached to no firewall.
- **The classic collection** `rc-allow-ns2-to-bch` is managed in
  `classic_rules.tf` and matches the 2026-10-05 export rule for rule.

## 5. Why this repo is separate

`tf-deploy-platform-connectivity` covers 564 import blocks across eleven tiers — VNets,
vWAN, gateways, private DNS, DNS resolver, network primitives, spoke VMs,
alerts. The firewall was one of those tiers.

Splitting it out buys three things:

1. **A rule change plans only the rules.** A firewall rule change is the most
   frequent change in this subscription and the least tolerant of a slow
   review. It no longer requires a plan that refreshes the spoke VMs, 4 bastion
   hosts, 43 private DNS zones and 50 hub connections.
2. **A rule apply cannot touch the network.** The firewall workspace's state
   contains no VNet, hub or gateway, so no apply from this repo can modify or
   destroy one — whatever the plan says and whoever approves it. That is a
   stronger guarantee than a review process.
3. **Separate approvers.** The `firewall` environment can require a network
   security reviewer; the connectivity environment can require a network
   platform reviewer. One repo could not distinguish them.

The cost is the boundary itself: it is by type, it is enforced in two places
(`data.tf` here, and the complementary `--scope-type`/`--exclude-type` filters
in the two `unmanaged-detect.yml` workflows), and **if it moves, both sides have
to move together**. A type dropped from one filter and not added to the other
stops being checked by either, and nothing fails to tell you.

## 6. Repository and state locations

| | |
|---|---|
| Repository | `tf-deploy-platform-firewall-management` |
| HCP organisation | `BC_Hydro` |
| HCP workspace | `az-platform-firewall` |
| Subscription | `f3835bc1-9829-4ac8-9d7a-0999e0b29b90` (connectivity) |
| tfvars | `firewall.tfvars` |
| Concurrency group | `platform-firewall-management` |
| Sibling workspace | `az-platform-connectivity` (repo `tf-deploy-platform-connectivity`) |

The concurrency group is deliberately not shared with the connectivity
pipelines. The two workspaces own disjoint resources, so a concurrent plan is
safe; serialising them would only mean a rule change waits behind a spoke VM
refresh.

## 7. Drift detection and monitoring

Three questions, three different answers:

| Question | Answered by | Status |
|---|---|---|
| A firewall, policy or IP group **in state** changed in Azure | HCP Terraform drift detection on `az-platform-firewall` | **Enable it.** This is the control that covers a rule added through the portal to a managed rule collection group. |
| A firewall, policy or IP group exists in Azure with **no state entry** | `unmanaged-detect.yml` | **Written, scheduled, not running.** No federated credential for the platform SPN, so it skips on `vars.AZURE_CLIENT_ID`. It skips rather than fails — read the job summary, not the green tick. |
| The committed configuration still agrees with state (a tfvars change merged without an apply) | nothing | A `terraform plan -detailed-exitcode` answers it if it becomes worth watching. |

`unmanaged-detect.yml` filters by type as well as resource group
(`--scope-type` × 3). Without that filter it would report every
connectivity-owned VNet, hub and gateway in the shared resource groups as
unmanaged on every run, which is how a report like this gets muted.
`tf-deploy-platform-connectivity` passes `--exclude-type` for the same three types. The
two filters are complements; between them every top-level resource in the shared
groups is covered exactly once.

Rule collection groups are **child** resources. Azure's inventory API does not
enumerate them, so the job lists them under "child resources in state, not
compared" rather than diffing them. HCP's refresh-only drift detection is the
only control that sees a change to one — which is the main reason to turn it on.

An unmanaged **firewall policy** is the most serious finding the job can report.
It can carry rules nobody reviewed, and attaching it to a firewall later puts
those rules into effect without passing the approval gate.

## 8. Reproducing the inventory

```bash
SUB=f3835bc1-9829-4ac8-9d7a-0999e0b29b90
az account set --subscription "$SUB"

# 1. the three owned types -> compare against `terraform state list`
az resource list --subscription "$SUB" \
  --query "[?type=='Microsoft.Network/azureFirewalls' || type=='Microsoft.Network/firewallPolicies' || type=='Microsoft.Network/ipGroups'].{name:name,type:type,rg:resourceGroup}" \
  -o table

# 2. rule collection groups, per policy -- children, so absent from the listing above
for p in azfwpol-connectivity-001 azfwpol-connectivity-001-BACKUP-20260320-233016-UTC; do
  echo "== $p"
  az network firewall policy rule-collection-group list \
    --policy-name "$p" -g rg-hub-connectivity-canadacentral-001 \
    --query "[].{name:name,priority:priority}" -o table
done

# 3. the transit firewall's classic inline rules -- classic_rules.tf, not the AVM wrapper
az network firewall show -n azfw-transit-connectivity-canadacentral-001 \
  -g rg-shared-connectivity-canadacentral-001 \
  --query "networkRuleCollections[].{name:name,priority:priority,action:action.type}" -o table

# 4. diagnostic settings, per firewall -- never in a resource listing
for f in azfw-connectivity-canadacentral-001:rg-hub-connectivity-canadacentral-001 \
         azfw-connectivity-canadaeast-001:rg-hub-connectivity-canadaeast-001 \
         azfw-transit-connectivity-canadacentral-001:rg-shared-connectivity-canadacentral-001; do
  n=${f%%:*}; g=${f##*:}
  echo "== $n"
  az monitor diagnostic-settings list \
    --resource "/subscriptions/$SUB/resourceGroups/$g/providers/Microsoft.Network/azureFirewalls/$n" \
    -o json
done

# 5. locks -- the resource-group locks here belong to connectivity
az lock list --subscription "$SUB" -o table

# 6. empty rule collections -- the two the provider cannot represent
az network firewall policy rule-collection-group show \
  --policy-name azfwpol-connectivity-001 \
  -g rg-hub-connectivity-canadacentral-001 \
  -n rcg-1000-spoke-specific-canada-central \
  --query "ruleCollections[?length(rules)==\`0\`].{name:name,priority:priority}" -o table
```

## Known plan diffs on first import

**Tags.** `local.common_tags` writes `Environment = "Prod"` — capitalised to
match the tag already on every resource, because Azure tag keys are
case-insensitive and a lowercase `environment` would rewrite the live key and
its value (`Prod` → `prod`). What remains is additive: `managed-by`, `module`,
`solution` and `owner` on the 202 tagged resources (3 firewalls, 2 policies,
199 IP groups; rule collection groups, the classic collection and diagnostic
settings carry no tags).

**Not expected any more.** The IP-group import IDs carry
`?api-version=2024-05-01`, the version the module declares. Without it azapi
imports at the latest version and every group plans an update to `type`.
If the IP-group wrapper moves to a newer API version, update the suffix in
`pending_imports_ip_groups.tf` and `scripts/gen_ip_groups.sh` with it.

Two classes of in-place change are expected and are not drift. Both come from
`ip_addresses` being typed as a set in the IP group wrapper: Terraform sorts
string sets on conversion and deduplicates them, so the provider receives a
different list from the one Azure returns.

- **20 IP groups reorder.** Identical membership, different order. Confirmed by
  every removed value reappearing as an added one.
- **`ipgrp-onprem-to-clzdb-subnets` deduplicates.** Azure holds 36 entries of
  which 34 are unique: `10.60.0.0/16` and `10.244.21.54` are each listed twice.
  The set drops the duplicates, so the first apply writes 34 entries.

Neither can be fixed in tfvars, because the sort and the dedupe happen inside
the module. `tf-deploy-platform-identity` hit the same defect on key vault
access-policy permissions and it converged after one apply, with the waivers
removed afterwards. Expect the same here, or waive the 21 with
`--allow-resource` on the `verify_zero_diff.sh` call.

The dedupe is a real, if small, write to Azure. It is a cleanup rather than a
behaviour change -- a duplicated CIDR in an IP group matches exactly as often as
a single one -- but it should be an explicit decision, not a surprise.
