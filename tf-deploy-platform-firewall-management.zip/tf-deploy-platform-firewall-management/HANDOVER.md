# Terraform scope and handover: platform firewall management

The management boundary for the Azure Firewall estate in the connectivity
subscription `f3835bc1-9829-4ac8-9d7a-0999e0b29b90`: what Terraform owns, what
it deliberately does not, and what remains before the first apply.

**Status: pre-apply.** The tiers in this repo were built from an offline
ARM/JSON export of the live estate and moved here out of `az-sub-connectivity-lz`.
Nothing has been applied and nothing is in state. Sections 1–3 describe the
intended boundary; §4 is the list of things that must be settled first. Unlike
the identity landing zone's handover, **no section here claims confirmation
against live** — the export is the only evidence, and where the export cannot
answer a question the section says so.

## Contents

1. [Summary of the boundary](#1-summary-of-the-boundary)
2. [What Terraform owns](#2-what-terraform-owns)
3. [What Terraform does not own](#3-what-terraform-does-not-own)
4. [Open items before the first apply](#4-open-items-before-the-first-apply)
5. [Why this repo is separate](#5-why-this-repo-is-separate)
6. [Repository and state locations](#6-repository-and-state-locations)
7. [Drift detection and monitoring](#7-drift-detection-and-monitoring)
8. [Reproducing the inventory](#8-reproducing-the-inventory)

## 1. Summary of the boundary

The split from `az-sub-connectivity-lz` is by **resource type**, not by resource
group. Three types belong to this repo wherever they sit in the subscription:

- `Microsoft.Network/azureFirewalls`
- `Microsoft.Network/firewallPolicies`
- `Microsoft.Network/ipGroups`

Everything else in the subscription — including all 12 resource groups, and
including the monitor alerts that watch the firewalls — belongs to
`az-sub-connectivity-lz`.

Two of the four resource groups this repo reads also hold connectivity-owned
resources, so **a resource group name does not tell you who owns what is inside
it**:

| Resource group | This repo's resources | Also holds (connectivity-owned) |
|---|---|---|
| `rg-hub-connectivity-canadacentral-001` | 1 firewall, 2 policies, 17 rule collection groups | vWAN hub, route tables, route maps, gateways, storage |
| `rg-hub-connectivity-canadaeast-001` | 1 firewall | vWAN hub, gateways |
| `rg-shared-connectivity-canadacentral-001` | 1 firewall (transit) | VNet, public IP, subnets |
| `rg-ip-groups-connectivity-global` | 89 IP groups | nothing else |

## 2. What Terraform owns

**111 import blocks**: 22 in `imports_firewall.tf`, 89 in `imports_ip_groups.tf`.

| Object | Count | Where |
|---|---|---|
| Azure Firewall, secured vWAN hub (`AZFW_Hub`/Premium) | 2 | `rg-hub-connectivity-canadacentral-001`, `rg-hub-connectivity-canadaeast-001` |
| Azure Firewall, VNet-based (`AZFW_VNet`/Standard) | 1 | `rg-shared-connectivity-canadacentral-001` |
| Firewall policy | 2 | `rg-hub-connectivity-canadacentral-001` |
| Rule collection group | 17 | children of the two policies (8 live, 9 backup) |
| Rule collection | 105 | inside those groups |
| Network rule | 272 | inside those collections |
| Application rule | 24 | inside those collections |
| IP group | 89 | `rg-ip-groups-connectivity-global` |

The rule collection groups are declared natively rather than through the
wrapper, which does not expose them; see `MODULE_GAPS.md`. The 89 IP groups are
resolved by 301 references from the rules, which is why they moved here with the
firewall rather than staying in `az-sub-connectivity-lz` — a rule change and the
IP group it references change together.

## 3. What Terraform does not own

### Owned by another repo, by design

| Object | Owner | Note |
|---|---|---|
| All 12 resource groups | `az-sub-connectivity-lz` | Read here through `data.tf`. A firewall apply cannot retag or delete one. |
| `firewall-connectivity-health` (metric alert), `firewall-connectivity-update` (activity log alert) | `az-sub-connectivity-lz`, `conn_alerts.tf` | Scoped to `azfw-connectivity-canadacentral-001` by constructed resource ID. They watch the firewall; they do not configure it, and they live with the rest of the alerts tier in `rg-alerts-connectivity-canadacentral-001`. |
| vWAN route next-hops pointing at the two hub firewalls | `az-sub-connectivity-lz`, `hub_vwan.tf` | Constructed IDs, not state references. No output crosses between the two workspaces in either direction. |
| `mid-azfirewall-canadacentral-001` (the policy's UAMI) | `sub-identity-lz` | Identity subscription. |
| `kvfwtlscanadacentral` (the TLS certificate's key vault) | `sub-identity-lz` | Identity subscription. The certificate secret itself is not managed by any repo; see that repo's handover. |
| `la-siem-security-canadacentral-001` (insights workspace) | security LZ | Security subscription. |

### Not owned by anything, and why

| Object | Why | What would change it |
|---|---|---|
| `rc-allow-ns2-to-bch` — classic inline `networkRuleCollection` on `azfw-transit-connectivity-canadacentral-001` | The AVM firewall module has no input for the pre-policy inline rule model. The firewall resource is managed; this collection is not. | Migrate the transit firewall onto a firewall policy. That is a change to the estate, not something an adoption should do on its way in. |
| `rc-allow-sap-aem-inbound` (Allow, priority 2520) on `azfwpol-connectivity-001/rcg-1000-spoke-specific-canada-central` | The provider cannot represent a rule collection with zero rules. | Delete it in Azure — it is an Allow collection with no rules, so it permits nothing and removing it changes no traffic decision. |
| `rc-allow-net-fit-to-esb-nonprod` (Allow, priority 41100) on the backup policy's `rcg-41000-spokes-to-onprem` | Same. | Same. |
| Firewall diagnostic settings | Not exported, so not built. Whether the two hub firewalls have diagnostic settings beyond what the policy's `insights` block configures is **not answerable from the export**. | Read them with `az monitor diagnostic-settings list` against each firewall; adopt or record them. Item 4 in §4. |
| Resource locks on the firewalls or policies | Not in the export. Not confirmed present or absent. | `az lock list`. Item 4 in §4. |
| Policy assignments and exemptions affecting these resources | Inherited from management groups; outside this repo either way. | — |

## 4. Open items before the first apply

In the order they block progress.

1. **`firewall_insights_workspace_id` is a placeholder.** `firewall.tfvars`
   carries `REPLACE_SECURITY_SUBSCRIPTION_ID`. The first plan fails until the
   security subscription's ID is filled in. This is a **fix**, not a
   regression: the value inherited from `az-sub-connectivity-lz` built the
   security workspace's path under the connectivity subscription's ID, which
   resolves to nothing. See `REMEDIATION.md`.
2. **Confirm the 111 import addresses on a speculative plan.** Every
   `module.<x>[k].module.<inner>.<resource>` target is inferred from the wrapper
   naming convention. A wrong address is a hard plan error that prints the
   correct one, so one plan resolves them all; `sed` the corrections in en
   masse. The three module **versions** are confirmed (see `MODULE_GAPS.md`);
   it is the wrappers' internal structure that still needs a plan.
3. **Read the objects the export does not cover** and either adopt them or
   record them in §3: firewall diagnostic settings, resource locks. The
   commands are in §8.
4. **Settle `rcg-300-cyberark-SIA-baseline`.** It exists on the backup policy
   and has no counterpart on the live policy. Whether it was deleted from live
   since 20 March 2026 or never promoted is **not answerable from the export**.
   Ask whoever owns the CyberArk SIA integration before the first apply — if it
   should be live, adopting the backup policy as-is records the wrong intent.
5. **Configure required reviewers on the `firewall` GitHub environment.**
   Without them `import-apply.yml` runs straight through with no approval stop.
6. **Decide the state position for the two omitted rule collections.** Both are
   empty Allow collections that permit nothing (§3). Deleting them in Azure
   makes the configuration exact; leaving them means the repo is knowingly
   inexact in two places, which is fine as long as §3 says so.

## 5. Why this repo is separate

`az-sub-connectivity-lz` covers 564 import blocks across eleven tiers — VNets,
vWAN, gateways, private DNS, DNS resolver, network primitives, spoke VMs,
alerts. The firewall was one of those tiers.

Splitting it out buys three things:

1. **A rule change plans only the rules.** A firewall rule change is the most
   frequent change in this subscription and the least tolerant of a slow
   review. It no longer requires a plan that refreshes 17 VMs, 4 bastion hosts,
   39 private DNS zones and 26 hub connections.
2. **A rule apply cannot touch the network.** The firewall workspace's state
   contains no VNet, hub or gateway, so no apply from this repo can modify or
   destroy one — whatever the plan says and whoever approves it. That is a
   stronger guarantee than a review process.
3. **Separate approvers.** The `firewall` environment can require a network
   security reviewer; the connectivity environment can require a network
   platform reviewer. One repo could not distinguish them.

The cost is the boundary itself: it is by type, it is enforced in two places
(`data.tf` here, and the complementary `--scope-type`/`--exclude-type` filters
in the two `unmanaged-detect.yml` workflows), and **if it moves, both sides have
to move together**. A type dropped from one filter and not added to the other
stops being checked by either, and nothing fails to tell you.

## 6. Repository and state locations

| | |
|---|---|
| Repository | `tf-deploy-platform-firewall-management` |
| HCP organisation | `BC_Hydro` |
| HCP workspace | `az-platform-firewall` |
| Subscription | `f3835bc1-9829-4ac8-9d7a-0999e0b29b90` (connectivity) |
| tfvars | `firewall.tfvars` |
| Concurrency group | `platform-firewall-management` |
| Sibling workspace | `az-platform-connectivity` (repo `az-sub-connectivity-lz`) |

The concurrency group is deliberately not shared with the connectivity
pipelines. The two workspaces own disjoint resources, so a concurrent plan is
safe; serialising them would only mean a rule change waits behind a spoke VM
refresh.

## 7. Drift detection and monitoring

Three questions, three different answers:

| Question | Answered by | Status |
|---|---|---|
| A firewall, policy or IP group **in state** changed in Azure | HCP Terraform drift detection on `az-platform-firewall` | **Enable it.** This is the control that covers a rule added through the portal to a managed rule collection group. |
| A firewall, policy or IP group exists in Azure with **no state entry** | `unmanaged-detect.yml` | **Written, scheduled, not running.** No federated credential for the platform SPN, so it skips on `vars.AZURE_CLIENT_ID`. It skips rather than fails — read the job summary, not the green tick. |
| The committed configuration still agrees with state (a tfvars change merged without an apply) | nothing | A `terraform plan -detailed-exitcode` answers it if it becomes worth watching. |

`unmanaged-detect.yml` filters by type as well as resource group
(`--scope-type` × 3). Without that filter it would report every
connectivity-owned VNet, hub and gateway in the shared resource groups as
unmanaged on every run, which is how a report like this gets muted.
`az-sub-connectivity-lz` passes `--exclude-type` for the same three types. The
two filters are complements; between them every top-level resource in the shared
groups is covered exactly once.

Rule collection groups are **child** resources. Azure's inventory API does not
enumerate them, so the job lists them under "child resources in state, not
compared" rather than diffing them. HCP's refresh-only drift detection is the
only control that sees a change to one — which is the main reason to turn it on.

An unmanaged **firewall policy** is the most serious finding the job can report.
It can carry rules nobody reviewed, and attaching it to a firewall later puts
those rules into effect without passing the approval gate.

## 8. Reproducing the inventory

```bash
SUB=f3835bc1-9829-4ac8-9d7a-0999e0b29b90
az account set --subscription "$SUB"

# 1. the three owned types -> compare against `terraform state list`
az resource list --subscription "$SUB" \
  --query "[?type=='Microsoft.Network/azureFirewalls' || type=='Microsoft.Network/firewallPolicies' || type=='Microsoft.Network/ipGroups'].{name:name,type:type,rg:resourceGroup}" \
  -o table

# 2. rule collection groups, per policy -- children, so absent from the listing above
for p in azfwpol-connectivity-001 azfwpol-connectivity-001-BACKUP-20260320-233016-UTC; do
  echo "== $p"
  az network firewall policy rule-collection-group list \
    --policy-name "$p" -g rg-hub-connectivity-canadacentral-001 \
    --query "[].{name:name,priority:priority}" -o table
done

# 3. the transit firewall's classic inline rules -- not expressible via AVM
az network firewall show -n azfw-transit-connectivity-canadacentral-001 \
  -g rg-shared-connectivity-canadacentral-001 \
  --query "networkRuleCollections[].{name:name,priority:priority,action:action.type}" -o table

# 4. diagnostic settings, per firewall -- never in a resource listing
for f in azfw-connectivity-canadacentral-001:rg-hub-connectivity-canadacentral-001 \
         azfw-connectivity-canadaeast-001:rg-hub-connectivity-canadaeast-001 \
         azfw-transit-connectivity-canadacentral-001:rg-shared-connectivity-canadacentral-001; do
  n=${f%%:*}; g=${f##*:}
  echo "== $n"
  az monitor diagnostic-settings list \
    --resource "/subscriptions/$SUB/resourceGroups/$g/providers/Microsoft.Network/azureFirewalls/$n" \
    --query "value[].name" -o tsv
done

# 5. locks on the owned resources
az lock list --subscription "$SUB" -o table

# 6. empty rule collections -- the two the provider cannot represent
az network firewall policy rule-collection-group show \
  --policy-name azfwpol-connectivity-001 \
  -g rg-hub-connectivity-canadacentral-001 \
  -n rcg-1000-spoke-specific-canada-central \
  --query "ruleCollections[?length(rules)==\`0\`].{name:name,priority:priority}" -o table
```
