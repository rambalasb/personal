# classic_rules.tf
# Classic inline network rule collections on azfw-transit-connectivity-canadacentral-001,
# the one firewall without a policy. The firewall wrapper (AVM) has no input for
# these, so they are declared natively against the wrapper's firewall.
# Remove this file when the transit firewall moves onto a firewall policy.

locals {
  classic_network_rule_collections = {
    "azfw-transit-connectivity-canadacentral-001/rc-allow-ns2-to-bch" = {
      firewall_key = "azfw-transit-connectivity-canadacentral-001"
      name         = "rc-allow-ns2-to-bch"
      priority     = 100
      action       = "Allow"
      rule = [
        {
          name                  = "r-allow-ns2"
          protocols             = ["TCP", "UDP"]
          source_addresses      = []
          source_ip_groups      = [module.ip_group["ipgrp-cc-ns2-subnet"].resource_id, module.ip_group["ipgrp-vnet-transit-connectivity-canadacentral"].resource_id]
          destination_addresses = []
          destination_fqdns     = []
          destination_ip_groups = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id]
          destination_ports     = ["*"]
        },
        {
          name                  = "r-allow-bch"
          protocols             = ["TCP", "UDP"]
          source_addresses      = []
          source_ip_groups      = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id]
          destination_addresses = []
          destination_fqdns     = []
          destination_ip_groups = [module.ip_group["ipgrp-cc-ns2-subnet"].resource_id, module.ip_group["ipgrp-vnet-transit-connectivity-canadacentral"].resource_id]
          destination_ports     = ["*"]
        },
      ]
    }
  }
}

resource "azurerm_firewall_network_rule_collection" "classic" {
  for_each = { for k, v in local.classic_network_rule_collections : k => v if var.enable_firewall }

  name                = each.value.name
  azure_firewall_name = module.firewall[each.value.firewall_key].resource.name
  resource_group_name = local.rg_names[local.firewalls[each.value.firewall_key].rg_key]
  priority            = each.value.priority
  action              = each.value.action

  dynamic "rule" {
    for_each = each.value.rule
    content {
      name                  = rule.value.name
      protocols             = rule.value.protocols
      source_addresses      = rule.value.source_addresses
      source_ip_groups      = rule.value.source_ip_groups
      destination_addresses = rule.value.destination_addresses
      destination_fqdns     = rule.value.destination_fqdns
      destination_ip_groups = rule.value.destination_ip_groups
      destination_ports     = rule.value.destination_ports
    }
  }
}
