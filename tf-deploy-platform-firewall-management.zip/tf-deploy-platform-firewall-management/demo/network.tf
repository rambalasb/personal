# Owned here so the demo needs nothing from the connectivity repo. In
# tf-deploy-platform-firewall-management these are read, not created.

module "resource_group" {
  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-resource-group/azurerm"
  version = "2.0.0"

  name             = var.resource_group_name
  location         = var.location
  enable_telemetry = false
  tags             = local.common_tags
}

module "virtual_network" {
  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-virtual-network/azurerm"
  version = "0.1.0"

  name          = var.virtual_network_name
  parent_id     = module.resource_group.resource_id
  location      = var.location
  address_space = var.virtual_network_address_space

  subnets = {
    firewall = {
      name           = "AzureFirewallSubnet"
      address_prefix = var.firewall_subnet_prefix
    }
    firewall_management = {
      name           = "AzureFirewallManagementSubnet"
      address_prefix = var.firewall_management_subnet_prefix
    }
  }

  peerings         = {}
  enable_telemetry = false
  tags             = local.common_tags
}
