output "firewall_ids" {
  value = { for k, m in module.firewall : k => m.resource_id }
}

output "firewall_policy_ids" {
  value = { for k, m in module.firewall_policy : k => m.resource_id }
}

output "ip_group_ids" {
  value = { for k, m in module.ip_group : k => m.resource_id }
}
