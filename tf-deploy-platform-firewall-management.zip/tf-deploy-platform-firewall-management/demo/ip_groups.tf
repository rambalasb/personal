# Keyed by name. Referenced by the rule collections in firewall.tf.

variable "ip_groups" {
  type = map(object({
    location     = optional(string, null)
    ip_addresses = list(string)
  }))
  default = {}
}

module "ip_group" {
  for_each = var.ip_groups

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-ip-group/azurerm"
  version = "0.1.0"

  name                = each.key
  resource_group_name = module.resource_group.name
  location            = coalesce(each.value.location, var.location)
  ip_addresses        = each.value.ip_addresses

  enable_telemetry = false
  tags             = local.common_tags
}
