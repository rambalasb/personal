locals {
  common_tags = merge(var.tags, {
    Environment = var.environment
    managed-by  = "terraform"
    solution    = "tf-deploy-platform-firewall-demo"
  })
}
