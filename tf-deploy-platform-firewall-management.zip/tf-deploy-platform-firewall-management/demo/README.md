# demo

Plan-only demo of adding IP groups, a rule collection group and a firewall
through the deploy pipeline. A separate root module from the repo root, with
its own workspace, so it never reads or plans against `az-platform-firewall`.

| | |
| --- | --- |
| Workflow | `.github/workflows/deploy-demo.yml` (plan only, no apply path) |
| HCP workspace | `az-platform-firewall-demo` |
| Var file | `demo/firewall-demo.tfvars` |

## Setup

1. Set `subscription_id` in `firewall-demo.tfvars`.
2. Create the `az-platform-firewall-demo` workspace in HCP Terraform with Azure
   dynamic credentials for that subscription.
3. `TF_API_TOKEN` available to the repo.

## Run

1. Branch from `main`, add `demo/` and `.github/workflows/deploy-demo.yml`.
2. Open a PR to `main`. lint, security and plan run automatically.
3. Close the PR without merging.

## What gets added

| File | Map | Entry |
| --- | --- | --- |
| `firewall-demo.tfvars` | `ip_groups` | `ipgrp-demo-app-canadacentral-001`, `ipgrp-demo-db-canadacentral-001` |
| `firewall.tf` | `local.firewall_rule_collection_groups` | `rcg-1000-demo`: one network and one application collection |
| `firewall.tf` | `local.firewalls` | `azfw-demo-canadacentral-001`, Basic tier, plus its public IPs |

The workspace starts empty, so the plan also creates what the firewall sits
on: resource group, VNet with `AzureFirewallSubnet` and
`AzureFirewallManagementSubnet`, and the policy `afwp-firewall-demo-001`.
Expect creates only.
