locals {
  # Basic: cheapest tier, Alert is the only threat intel mode it supports.
  firewall_policies = {
    "afwp-firewall-demo-001" = {
      sku                      = "Basic"
      threat_intelligence_mode = "Alert"
    }
  }

  # Keyed "<policy>/<group>", as in tf-deploy-platform-firewall-management.
  firewall_rule_collection_groups = {
    "afwp-firewall-demo-001/rcg-1000-demo" = {
      name       = "rcg-1000-demo"
      policy_key = "afwp-firewall-demo-001"
      priority   = 1000
      network_rule_collection = [
        {
          name     = "rc-allow-demo-app-to-db"
          priority = 1100
          action   = "Allow"
          rule = [
            {
              name                  = "r-allow-demo-app-to-db-sql"
              protocols             = ["TCP"]
              source_ip_groups      = [module.ip_group["ipgrp-demo-app-canadacentral-001"].resource_id]
              destination_ip_groups = [module.ip_group["ipgrp-demo-db-canadacentral-001"].resource_id]
              destination_ports     = ["1433"]
            },
          ]
        },
      ]
      application_rule_collection = [
        {
          name     = "rc-allow-demo-app-outbound-web"
          priority = 1200
          action   = "Allow"
          rule = [
            {
              name              = "r-allow-demo-app-to-microsoft"
              source_ip_groups  = [module.ip_group["ipgrp-demo-app-canadacentral-001"].resource_id]
              destination_fqdns = ["*.microsoft.com"]
              protocols         = [{ type = "Https", port = 443 }]
            },
          ]
        },
      ]
    }
  }

  # AZFW_VNet in the demo VNet. One AzureFirewallSubnet holds one firewall.
  firewalls = {
    "azfw-demo-canadacentral-001" = {
      sku_tier   = "Basic"
      policy_key = "afwp-firewall-demo-001"
      zones      = []
    }
  }
}

module "firewall_policy" {
  for_each = local.firewall_policies

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-azure-firewall-policy/azurerm"
  version = "0.1.1"

  name                = each.key
  resource_group_name = module.resource_group.name
  location            = var.location

  firewall_policy_sku                      = each.value.sku
  firewall_policy_threat_intelligence_mode = each.value.threat_intelligence_mode

  firewall_policy_rule_collection_groups = {
    for k, v in local.firewall_rule_collection_groups : v.name => {
      name                        = v.name
      priority                    = v.priority
      network_rule_collection     = v.network_rule_collection
      application_rule_collection = v.application_rule_collection
    } if v.policy_key == each.key
  }

  enable_telemetry = false
  tags             = local.common_tags
}

module "firewall_public_ip" {
  for_each = local.firewalls

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-public-ip-address/azurerm"
  version = "0.0.1"

  name                = "pip-${each.key}"
  resource_group_name = module.resource_group.name
  location            = var.location
  zones               = each.value.zones

  enable_telemetry = false
  tags             = local.common_tags
}

module "firewall_management_public_ip" {
  for_each = { for k, v in local.firewalls : k => v if v.sku_tier == "Basic" }

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-public-ip-address/azurerm"
  version = "0.0.1"

  name                = "pip-${each.key}-mgmt"
  resource_group_name = module.resource_group.name
  location            = var.location
  zones               = each.value.zones

  enable_telemetry = false
  tags             = local.common_tags
}

module "firewall" {
  for_each = local.firewalls

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-azure-firewall/azurerm"
  version = "0.1.0"

  name                = each.key
  resource_group_name = module.resource_group.name
  location            = var.location
  firewall_sku_name   = "AZFW_VNet"
  firewall_sku_tier   = each.value.sku_tier
  firewall_policy_id  = module.firewall_policy[each.value.policy_key].resource_id
  firewall_zones      = each.value.zones

  ip_configurations = {
    primary = {
      name                 = "${each.key}-ipconfig"
      subnet_id            = module.virtual_network.subnets["firewall"].resource_id
      public_ip_address_id = module.firewall_public_ip[each.key].resource_id
    }
  }

  firewall_management_ip_configuration = each.value.sku_tier == "Basic" ? {
    name                 = "${each.key}-mgmt-ipconfig"
    subnet_id            = module.virtual_network.subnets["firewall_management"].resource_id
    public_ip_address_id = module.firewall_management_public_ip[each.key].resource_id
  } : null

  enable_telemetry = false
  tags             = local.common_tags
}
