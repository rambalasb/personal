variable "subscription_id" {
  type        = string
  description = "Sandbox subscription the demo deploys into. Not the connectivity subscription."
}

variable "location" {
  type    = string
  default = "canadacentral"
}

variable "environment" {
  type    = string
  default = "Demo"
}

variable "tags" {
  type    = map(string)
  default = {}
}

variable "resource_group_name" {
  type = string
}

variable "virtual_network_name" {
  type = string
}

variable "virtual_network_address_space" {
  type = set(string)
}

# Both /26 minimum. Names are fixed by Azure.
variable "firewall_subnet_prefix" {
  type        = string
  description = "AzureFirewallSubnet."
}

variable "firewall_management_subnet_prefix" {
  type        = string
  description = "AzureFirewallManagementSubnet. Required by the Basic tier."
}
