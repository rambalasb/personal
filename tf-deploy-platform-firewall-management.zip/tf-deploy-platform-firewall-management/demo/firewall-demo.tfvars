subscription_id = "CHANGE-ME"

tags = {
  owner   = "connectivity-platform"
  purpose = "demo"
}

resource_group_name = "rg-firewall-demo-canadacentral-001"

# Not peered to anything, so the range only has to be valid.
virtual_network_name              = "vnet-firewall-demo-canadacentral-001"
virtual_network_address_space     = ["10.250.0.0/24"]
firewall_subnet_prefix            = "10.250.0.0/26"
firewall_management_subnet_prefix = "10.250.0.64/26"

ip_groups = {
  "ipgrp-demo-app-canadacentral-001" = { ip_addresses = ["10.20.1.0/24"] }
  "ipgrp-demo-db-canadacentral-001"  = { ip_addresses = ["10.20.2.0/27"] }
}
