# ip_groups.tf
# 89 IP groups in rg-ip-groups-connectivity-global (all canadacentral).
# Referenced by the hub firewall policy rule collections in firewall.tf, and by
# nothing else - they moved out of az-sub-connectivity-lz with the firewall tier.

variable "enable_ip_groups" {
  type    = bool
  default = false
}

variable "ip_groups" {
  type = map(object({
    location     = optional(string, "canadacentral")
    ip_addresses = list(string)
  }))
  default = {}
}

module "ip_group" {
  for_each = var.enable_ip_groups ? var.ip_groups : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-ip-group/azurerm"
  version = "0.1.0"

  name                = each.key
  resource_group_name = local.rg_names["ip_groups"]
  location            = each.value.location
  ip_addresses        = each.value.ip_addresses
  tags                = local.common_tags
}
