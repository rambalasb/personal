# ip_groups.tf
# IP groups, almost all in rg-ip-groups-connectivity-global. The set is generated from Azure
# by scripts/gen_ip_groups.sh -- do not hand-edit the tfvars block.
# Referenced by the hub firewall policy rule collections in firewall.tf, and by
# nothing else.

variable "enable_ip_groups" {
  type    = bool
  default = false
}

variable "ip_groups" {
  # Keyed by name for the groups in the global RG. The four that live elsewhere
  # are keyed "<rg_key>/<name>": two names collide across resource groups, so the
  # key cannot double as the Azure name for them.
  type = map(object({
    name         = optional(string, null)
    rg_key       = optional(string, "ip_groups")
    location     = optional(string, "canadacentral")
    ip_addresses = list(string)
  }))
  default = {}
}

module "ip_group" {
  for_each = var.enable_ip_groups ? var.ip_groups : {}

  source  = "app.terraform.io/BC_Hydro/tf-wrapper-avm-ip-group/azurerm"
  version = "0.1.0"

  name                = coalesce(each.value.name, each.key)
  resource_group_name = local.rg_names[each.value.rg_key]
  location            = each.value.location
  ip_addresses        = each.value.ip_addresses

  enable_telemetry = false
  tags             = local.common_tags
}
