# tf-deploy-platform-firewall-management

Manages the Azure Firewall estate in the connectivity subscription
(`f3835bc1-9829-4ac8-9d7a-0999e0b29b90`, `canadacentral` + `canadaeast`)
through the `tf-wrapper-avm-*` modules.

Split out of `az-sub-connectivity-lz` so firewall rules can be changed without
a plan that also reads the VNets, vWAN hubs, gateways, DNS zones and spoke VMs.
Same subscription, separate HCP workspace (`az-platform-firewall`), separate
approval gate. Nothing here can modify a resource group, a VNet or a hub.

## What is managed

- **3 Azure Firewalls**: `azfw-connectivity-canadacentral-001` and
  `azfw-connectivity-canadaeast-001` (both `AZFW_Hub`/Premium, secured vWAN
  hubs), and `azfw-transit-connectivity-canadacentral-001` (`AZFW_VNet`/Standard,
  in `rg-shared-connectivity-canadacentral-001`)
- **2 firewall policies**: `azfwpol-connectivity-001` (Premium, TLS inspection,
  IDPS in Deny, DNS proxy) and `azfwpol-connectivity-001-BACKUP-20260320-233016-UTC`
- **17 rule collection groups**: 8 on the live policy, 9 on the backup —
  105 rule collections, 272 network rules and 24 application rules
- **89 IP groups** in `rg-ip-groups-connectivity-global`, resolved by 301
  references from the policy rules

`az-sub-connectivity-lz` remains the owner of everything else in the
subscription, including all 12 resource groups. See
[the boundary](#the-boundary-with-az-sub-connectivity-lz).

**111 import blocks total** (22 firewall + 89 IP group). Nothing has been
applied yet; see `HANDOVER.md` §4 for what must be filled in first.

## The boundary with az-sub-connectivity-lz

Three resource types, wherever they are in the subscription:

| | This repo | az-sub-connectivity-lz |
|---|---|---|
| `Microsoft.Network/azureFirewalls` | owns | — |
| `Microsoft.Network/firewallPolicies` | owns | — |
| `Microsoft.Network/ipGroups` | owns | — |
| resource groups | reads (4, via `data.tf`) | owns (12) |
| VNets, subnets, peerings | — | owns |
| vWAN, hubs, route tables, gateways | — | owns |
| private DNS, DNS resolver, NSGs, PIPs | — | owns |
| spoke VMs, bastion, load balancer | — | owns |
| alerts (including the firewall health/write alerts) | — | owns |

The split is by **resource type, not by resource group**. Two of the four
groups this repo reads also hold connectivity-owned resources, so ownership
cannot be read off a resource group name. Two consequences worth knowing:

1. **The resource groups are read, never managed.** `data.tf` declares four
   `data "azurerm_resource_group"` blocks. A firewall apply cannot retag or
   delete a group, and a plan fails with a clear error if one is missing
   rather than proposing a firewall in a group that does not exist.
2. **The inventory check filters by type.** `unmanaged-detect.yml` passes
   `--scope-type` for the three types above; connectivity passes
   `--exclude-type` for the same three. The two filters are complements, so
   every top-level resource in the shared groups is still covered exactly
   once. **If the boundary moves, both lists have to move together** — a type
   dropped from one and not added to the other stops being checked by either.

The firewall's own monitor alerts stay in `az-sub-connectivity-lz`
(`conn_alerts.tf`), scoped to the firewall by constructed resource ID. They
watch the firewall rather than configure it, and they sit in
`rg-alerts-connectivity-canadacentral-001` with the rest of that tier.
`hub_vwan.tf` there likewise points its route next-hops at the two hub
firewalls by constructed ID, so no state reference crosses between the
workspaces in either direction.

## Running a change

```bash
terraform init
terraform plan -var-file=firewall.tfvars -out=tfplan.binary
terraform apply tfplan.binary
```

## Pipelines

The three below share the `platform-firewall-management` concurrency group, so
one run touches the firewall estate at a time. The group is deliberately *not*
shared with `az-sub-connectivity-lz`: the two workspaces own disjoint
resources, so they can plan concurrently.

- `import-verify.yml`: plan and gate, never applies. `workflow_dispatch` only.
  Safe to run any time.
- `import-apply.yml`: two jobs in one run. `check` plans, gates, and publishes
  a digest of the change set; `apply` sits behind the `firewall` GitHub
  environment and needs an approver. `workflow_dispatch` only.
- `unmanaged-detect.yml`: diffs Azure's inventory against state, filtered to
  the three owned types. Daily at 14:30 UTC, plus `workflow_dispatch`. Skips
  unless `vars.AZURE_CLIENT_ID` is set. See [Drift](#drift).

The two scanning workflows are separate: `tflint.yml` runs on push to `main`
and on pull request, `trivy.yml` on pull request and weekly. Neither takes the
concurrency group; they never read state.

**The `firewall` environment must have required reviewers configured.** Without
them the job runs straight through and there is no approval stop. This matters
more here than in the other landing zones: the reviewable unit is a firewall
rule, and an unreviewed apply can open or close network paths across every
spoke.

Two controls sit between approval and apply, covering different failures:

1. The apply job re-plans and re-runs `verify_zero_diff.sh`, so attribute-level
   drift that appeared during the approval wait fails the run. It does not
   consume the check job's plan: applying a saved plan would replay a recorded
   diff without re-reading Azure.
2. It then compares its own change set against the digest the check job
   published, so a resource entering or leaving the plan between review and
   approval blocks the apply. The approver's summary shows the digest that has
   to match.

Neither `plan.json` nor `tfplan.binary` is uploaded. In this repo that is not
only about resolved attribute values in general — a firewall plan's JSON is a
complete listing of every source, destination, port and FQDN in the estate. The
artifacts hold the gate output and an address-level change list only.

## Drift

**HCP Terraform's drift detection** should be enabled on the
`az-platform-firewall` workspace. It runs a refresh-only comparison and reports
when a resource *already in state* has changed in Azure — a rule added through
the portal to a managed rule collection group shows up here.

**One question is not covered by it.** A firewall policy or rule collection
group created by hand has no state entry, so a refresh-only plan has nothing to
compare it against. `unmanaged-detect.yml` is written and scheduled for exactly
this, but **it is not running**: the platform SPN has no GitHub federated
credential and no client secret, so the job has no way to authenticate. It is
gated on `vars.AZURE_CLIENT_ID` and **skips rather than fails**, so an
unconfigured run looks identical to a clean one in the Actions list. **Read the
job summary, not the green tick.**

Turning it on needs no code change: set `vars.AZURE_CLIENT_ID` to a Reader
identity holding a federated credential for this repository, with
`AZURE_TENANT_ID` and `AZURE_SUBSCRIPTION_ID` alongside it.

An unmanaged **firewall policy** is the more serious of the two findings the job
reports. It can carry rules nobody reviewed, and if it is later attached to a
firewall those rules take effect without ever passing the approval gate.

Rule collection groups are child resources, so Azure's inventory API does not
enumerate them and the job lists them under "child resources in state, not
compared" rather than diffing them. HCP's refresh-only drift detection is the
control that covers those — which is why it should be on.

**Prevention is the stronger control for the unmanaged-resource gap.** Azure
Policy denying `Microsoft.Network/firewallPolicies` and
`Microsoft.Network/azureFirewalls` writes outside the pipeline's identity stops
the gap forming rather than reporting it a day later.

## Reports

- `REMEDIATION.md`: every divergence from wrapper defaults, why it matters, and what breaks if it's ever "corrected" carelessly
- `HANDOVER.md`: the management boundary (what Terraform owns and what it does not, with reasons and owners) plus what remains before the first apply
- `MODULE_GAPS.md`: wrapper and AVM defects this configuration works around
