# Remediation report: `tf-deploy-platform-firewall-management`

Every place the live configuration differs from a wrapper's hardened default,
or from what a reader would assume, is written explicitly into `firewall.tfvars`
or `firewall.tf`. That is what keeps a plan from silently hardening a live
system — and in a firewall repo, "silently hardening" means closing a network
path that something depends on.

**Nothing here has been applied.** The divergences below were read off the
offline ARM export the tier was built from, not confirmed against live. Each
row says which. Confirming them is item 1 in `HANDOVER.md` §4.

## `azfwpol-connectivity-001`

The live policy, attached to both secured-hub firewalls.

| Attribute | Value | Why it is explicit |
|---|---|---|
| `threat_intelligence_mode` | `Deny` | Stricter than the module default (`Alert`). Written explicitly so a module change cannot relax it. |
| `intrusion_detection.mode` | `Deny` | Same reasoning. IDPS in Deny drops matched traffic; a silent move to `Alert` would keep the estate looking healthy while passing what it used to block. |
| `dns.proxy_enabled` | `true`, servers `["10.195.4.7"]` | The DNS proxy is load-bearing: FQDN-based application rules resolve through it. Turning it off breaks every rule that matches on `destination_fqdns` rather than an address. The server is the DNS resolver inbound endpoint managed by `az-sub-connectivity-lz`. |
| `sku` | `Premium` | Required by TLS inspection and IDPS. Not a default. |
| `identity` | UserAssigned, `mid-azfirewall-canadacentral-001` | The identity the policy uses to read the TLS certificate out of the key vault. Lives in the **identity** subscription and is managed by `sub-identity-lz`; passed in as `var.firewall_uami_id`. |

## `azfwpol-connectivity-001-BACKUP-20260320-233016-UTC`

A point-in-time copy of the live policy taken on 20 March 2026, carrying 9 rule
collection groups against the live policy's 8. It is attached to no firewall.

It is **managed deliberately**, not by accident. Two reasons: it exists, so
leaving it out would leave an unmanaged policy in a resource group this repo
owns the policy type in — exactly what `unmanaged-detect.yml` exists to flag.
And its rules are a record of what the estate allowed in March, which is worth
keeping under review rather than editable in the portal without a trace.

Its `identity`, `insights` and `tls_certificate` are all `null`, matching live —
a detached policy needs none of them. **Do not "fix" that by copying the live
policy's values across.** Setting `insights` on it would start it writing to the
SIEM workspace for no reason, and giving it the UAMI would grant a policy
nothing uses a read on the TLS certificate.

Its extra group, `rcg-300-cyberark-SIA-baseline`, has no counterpart on the live
policy. Whether that is a group deleted from live since March or one that was
never promoted is not answerable from the export; it is an open item in
`HANDOVER.md` §4.

## `azfw-transit-connectivity-canadacentral-001`

The odd firewall of the three: `AZFW_VNet`/Standard, not a secured hub, and
`firewall_policy_id = null`. Its rules are classic inline
`networkRuleCollections` on the firewall resource itself.

Standard rather than Premium is what live carries. Leave it — moving to Premium
is a cost and a behaviour change, not a correction. Its rules being inline is
the reason one collection is unmanaged; see `MODULE_GAPS.md` and
`HANDOVER.md` §3.

## Cross-subscription references

Three values point outside this subscription. Each is a variable rather than a
constructed string, so a plan fails on a missing input instead of quietly
building an ID that resolves to nothing.

| Input | Points at | Owner |
|---|---|---|
| `firewall_insights_workspace_id` | `la-siem-security-canadacentral-001`, security subscription | security LZ |
| `firewall_uami_id` | `mid-azfirewall-canadacentral-001`, identity subscription | `sub-identity-lz` |
| `firewall_tls_certificate.key_vault_secret_id` | `kvfwtlscanadacentral`, identity subscription | `sub-identity-lz` |

**`firewall_insights_workspace_id` was wrong in `az-sub-connectivity-lz` and is
fixed here.** It was built as `"${local.sub}/resourceGroups/rg-siem-security-…"`,
which puts the security subscription's workspace path under the *connectivity*
subscription's ID. That resource does not exist, and the policy's insights
block would have failed to apply. The old value carried a `# TODO confirm`
comment; making it an input is the confirmation. **`firewall.tfvars` still holds
`REPLACE_SECURITY_SUBSCRIPTION_ID` — the first plan fails until that is set**,
which is the intended behaviour rather than an oversight.

**The TLS certificate secret ID is version-pinned**
(`…/secrets/azkv-fw-tls-cert/0393397970c443b4be90c8928137ef62`). That is what
live carries, and it is the safer form: an unversioned ID would let a
certificate rotation change what the firewall presents with no commit and no
approval. The cost is that **rotation requires a change here** — update
`firewall_tls_certificate.key_vault_secret_id` in `firewall.tfvars` and apply.
Rotating the certificate in the key vault alone will not move the firewall onto
it.

## Zero-diff verification: what is suppressed, and what is not

The gate arguments in `import-verify.yml` and `import-apply.yml` are short by
comparison with the other landing zones, and deliberately so.

### Suppressed

- `timeouts` — a configuration-only block. Never sent to Azure, and `terraform import` leaves it null, so it reads as a diff on every import.
- `modtm_telemetry`, `random_uuid`, `time_sleep` — resource types the AVM wrappers instantiate for telemetry and sequencing. Not Azure resources.

That is the whole list. **No azapi arguments appear here.** The other landing
zones ignore a long list of `azapi_resource` config-only knobs; the firewall,
policy and IP-group wrappers are all `azurerm`, so those knobs do not exist in
this plan and adding them would only make the gate look more permissive than it
is.

### Not suppressed, on purpose

**No rule attribute is waived, and `azurerm_firewall_policy_rule_collection_group`
has no `--subset-attr`.** A rule collection whose rule list Terraform would
rewrite is precisely what the gate exists to catch. If a rule ordering or
membership diff shows up, it is a real difference between the export and live
and it needs reading, not suppressing.

The IP groups are the same. `ip_addresses` is a `list(string)` on both sides, so
no set-ordering artefact like the one the identity repo hit on key vault access
policies applies — an `ip_addresses` diff means the CIDR set actually differs
from the export.

## Expected on the first plan

Two kinds of diff are expected and are **not** grounds for suppression:

1. **Tag additions.** `local.common_tags` adds `environment`, `managed-by` and `solution` to every managed resource. The `solution` value is `tf-deploy-platform-firewall-management`, so resources that were tagged by `az-sub-connectivity-lz` before the split will show a tag update. In-place, additive, and the point of the tag.
2. **Import addresses that do not exist.** The 111 `import{}` blocks target best-guess wrapper internals. A wrong address is a hard error that prints the right one; see `MODULE_GAPS.md`.
