# Adding resources to the firewall estate

How to add an IP group, a firewall rule, a rule collection group, a policy or a
firewall to this workspace. Read `README.md` first for what the workspace owns
and why the boundary sits where it does.

[Order of operations](#order-of-operations) first if you are adding more than
one thing, or anything that depends on the connectivity repo. Sections A to G
are each a complete numbered sequence, and every one ends at
[Shipping the change](#shipping-the-change) — the same four steps whatever you
added.

Three things hold for every change here:

- **Everything is map-driven.** Adding a resource means adding a key to a map.
  There is no new `resource` or `module` block to write.
- **The map key is the resource identity.** Change a key and Terraform renames
  the Azure resource. On a firewall, a policy or a VM-backed resource, `name`
  is ForceNew — the rename is a destroy and recreate, not an update. Rename via
  a `moved` block or not at all.
- **Import blocks are for adoption only.** A resource you are creating does not
  get one. Import blocks exist to bring an *existing* Azure resource under
  management; pointing one at a resource that does not exist fails the plan.

---

## Order of operations

Terraform resolves dependencies inside a single plan, so within this workspace
you can add everything in one PR and it will order itself. What it cannot order
is anything that lives outside this workspace, and what it cannot warn you
about is a reference to a key you have not written yet.

Work outside-in. Each layer must exist before the one below it references it.

| # | Layer | Owned by | Must exist before |
| --- | --- | --- | --- |
| 1 | Resource group | `tf-deploy-platform-connectivity` | anything in it |
| 2 | vWAN hub, VNet, subnets, public IPs | `tf-deploy-platform-connectivity` | a firewall attaching to them |
| 3 | RG wiring (variable, data source, `rg_names`) | here — [section G](#g-add-a-resource-group-to-the-workspaces-reach) | any resource keyed to that `rg_key` |
| 4 | Firewall policy — [section E](#e-add-a-firewall-policy) | here | a firewall or rule collection group referencing it |
| 5 | IP groups — [section A](#a-add-an-ip-group) | here | any rule referencing them |
| 6 | Firewall — [section F](#f-add-a-firewall) | here | — |
| 7 | Rule collection group — [section D](#d-add-a-rule-collection-group) | here | its collections |
| 8 | Rule collection — [section C](#c-add-a-rule-collection) | here | its rules |
| 9 | Rules — [section B](#b-add-a-rule-to-an-existing-rule-collection) | here | — |

Layers 1 and 2 are the hard boundary. They are a separate repo, a separate
workspace and a separate approval gate, so they are a separate PR that has to
be **merged and applied** before this one plans. A firewall referencing a hub
that does not exist yet fails the plan; it does not wait.

Layers 3 to 9 can all go in one PR here.

### Adding a whole new stream

Say a new application spoke needs its own firewall rules. In order:

1. **Connectivity repo** — VNet, subnets, any peering or hub connection.
   Merged and applied first.
2. **Here, one PR:** the IP groups for the new subnets (section A), then a rule
   collection group if the rules need their own priority band (section D),
   then the collections (section C), then the rules referencing those IP
   groups (section B).
3. One `import-verify.yml` run covers the lot. Read the plan as a whole.

If the stream also needs a new firewall or policy, those go in the same PR at
layers 4 and 6 — before the rules that reference them.

### Adding the same stream to both regions

Canada Central and Canada East are separate rule collection groups
(`rcg-1000-spoke-specific-canada-central` and
`rcg-20000-spoke-specific-canada-east`) on the same policy. IP groups are
shared and single-region (`canadacentral`), so add them once and reference them
from both groups. Do both regions in one PR — a rule set that is live in one
region and not the other is harder to reason about than either state.

### What not to split across PRs

Do not merge a rule that references an IP group added in a different, unmerged
PR. The plan fails on an unresolved `module.ip_group["..."]` key, and the
failure names the reference rather than the missing declaration. Same for a
rule collection group referencing a `policy_key` that does not exist yet.

If two people are adding to the same rule collection group at once, expect a
merge conflict in `firewall.tf` rather than a plan failure — the file is one
large map and both edits land in the same region of it.

---

## A. Add an IP group

### Step 1 — decide whether you are creating or adopting

Creating a new group: continue to step 2.

Adopting a group that already exists in Azure: skip to step 5. Do not hand-edit
the block for an adoption.

### Step 2 — add the entry

One line in the `ip_groups` map in `firewall.tfvars`:

```hcl
"ipgrp-vnet-newapp-prod-canadacentral-001" = { location = "canadacentral", ip_addresses = ["10.195.44.0/22"] }
```

The key is the Azure resource name. `location` defaults to `canadacentral`.
`ip_addresses` takes single addresses or CIDR ranges.

### Step 3 — if it is not in rg-ip-groups-connectivity-global

Key it `"<rg_key>/<name>"` and set `name` and `rg_key` explicitly:

```hcl
"hub_cc/ipgrp-example-canadacentral-001" = {
  name         = "ipgrp-example-canadacentral-001"
  rg_key       = "hub_cc"
  location     = "canadacentral"
  ip_addresses = ["10.195.124.4"]
}
```

`rg_key` is one of `ip_groups` (the default), `hub_cc`, `hub_ce`, `shared_cc`,
`backup_cc`. Anything else needs [section G](#g-add-a-resource-group-to-the-workspaces-reach) first.

The compound key exists because two groups in Azure share the name
`ipgrp-vnet-spo-prod-canadacentral-001` across two resource groups, so the key
cannot double as the name for them.

### Step 4 — ship the IP group

Nothing else is needed; `module.ip_group` picks the entry up through `for_each`.
Go to [Shipping the change](#shipping-the-change).

### Step 5 — adopting instead: regenerate the block

```sh
az network ip-group list -g rg-ip-groups-connectivity-global -o json > ipg.json
./scripts/gen_ip_groups.sh ipg.json --tfvars firewall.tfvars --out ./generated
```

It writes three files and edits nothing in place:

- `ip_groups.tfvars.txt` — the complete block for the global resource group's
  groups. **Do not paste it over the existing block as-is:** it omits the four
  groups keyed `hub_cc/…` and `backup_cc/…`, which live in other resource
  groups and are not in `ipg.json`. Either add those four back, or insert only
  the new entries into the existing block (what the 2026-10-05 refresh did, so
  the diff shows only the additions).
- `ip_groups.imports.txt` — import blocks for undeclared groups only. Append to
  `pending_imports_ip_groups.tf`; do not overwrite it. Each ID ends in
  `?api-version=2024-05-01`; keep it, or the group plans a `type` update on
  import.
- `drift.txt` — declared groups whose members no longer match Azure.

The summary always reports **4 declared but absent** for the same reason: those
four are not in the global resource group. Any number above 4 is real.

The script stopped silently, before its summary, on an empty IP group until
2026-10-05, leaving a truncated `drift.txt` that read as "no drift". If the
summary lines are missing, the run failed; do not trust its files.

### Step 6 — review, move the files into position, then ship

---

## B. Add a rule to an existing rule collection

### Step 1 — find the collection

In `local.firewall_rule_collection_groups` in `firewall.tf`, locate the rule
collection group, then the collection inside it.

### Step 2 — add the rule object

Network rule:

```hcl
{
  name                  = "r-allow-newapp-to-clz"
  protocols             = ["TCP"]
  source_addresses      = []
  source_ip_groups      = [module.ip_group["ipgrp-vnet-newapp-prod-canadacentral-001"].resource_id]
  destination_addresses = []
  destination_fqdns     = []
  destination_ip_groups = [module.ip_group["ipgrp-cacentral-clz-subnets"].resource_id]
  destination_ports     = ["443"]
}
```

Application rule:

```hcl
{
  name                  = "r-allow-database"
  source_addresses      = []
  source_ip_groups      = [module.ip_group["ipgrp-cacentral-hosted-runners"].resource_id]
  destination_fqdns     = ["*.database.windows.net"]
  destination_urls      = []
  destination_fqdn_tags = []
  web_categories        = []
  terminate_tls         = false
  protocols             = [{ type = "Mssql", port = 1433 }]
}
```

### Step 3 — check every key is present

**All eight network keys, or all nine application keys, are required even when
empty.** The `dynamic "rule"` block reads each one unconditionally, so omitting
a key you do not need is an error rather than a default. Use `[]`, not omission.

### Step 4 — if the IP group is new, add it first

Any `module.ip_group["..."]` you reference must exist in the `ip_groups` map.
See [section A](#a-add-an-ip-group).

### Step 5 — ship the rule

Go to [Shipping the change](#shipping-the-change).

---

## C. Add a rule collection

### Step 1 — append to the group's collection list

Into `network_rule_collection` or `application_rule_collection` on an existing
rule collection group:

```hcl
{
  name     = "rc-allow-newapp-outbound"
  priority = 1450
  action   = "Allow"
  rule     = [ /* see section B */ ]
}
```

### Step 2 — pick a priority unique within the rule collection group

### Step 3 — put at least one rule in it

A collection with an empty `rule` list will not work: the provider requires at
least one `rule` block. The wrapper's `rule_collections_not_empty` check explains
the cause as a warning — `check` blocks are advisory and never block a plan — and
the run then fails on the provider's own error. Azure holds five such collections
today, all omitted from this config and listed in `HANDOVER.md`.

### Step 4 — ship the collection

Go to [Shipping the change](#shipping-the-change).

---

## D. Add a rule collection group

### Step 1 — add the key

In `local.firewall_rule_collection_groups`, shaped `"<policy-name>/<rcg-name>"`:

```hcl
"azfwpol-connectivity-001/rcg-45000-newapp" = {
  name       = "rcg-45000-newapp"
  policy_key = "azfwpol-connectivity-001"
  priority   = 45000
  network_rule_collection = [
  ]
  application_rule_collection = [
  ]
}
```

### Step 2 — include both collection lists

Both keys must be present. Empty lists are fine; omitting either is not. The
names are singular, matching the AVM submodule the wrapper instantiates.

### Step 3 — choose the priority

Unique per policy, and it sets evaluation order. Existing groups run 300, 490,
500, 800, 1000, 20000, 39800, 40000, 41000, 64900. `rcg-64900-deny-all` is last
on purpose, so anything added above it is evaluated first.

### Step 4 — confirm `policy_key` matches a key in `local.firewall_policies`

### Step 5 — ship the rule collection group

Go to [Shipping the change](#shipping-the-change).

---

## E. Add a firewall policy

### Step 1 — add the key to `local.firewall_policies`

```hcl
"azfwpol-example-001" = {
  location                 = "canadacentral"
  sku                      = "Premium"
  threat_intelligence_mode = "Deny"
  dns                      = { proxy_enabled = true, servers = ["10.195.4.7"] }
  intrusion_detection      = { mode = "Deny" }
  identity                 = null
  insights                 = null
  tls_certificate          = null
}
```

### Step 2 — set every attribute, `null` where it does not apply

`for_each` requires the attribute types across map entries to unify. Omit one
and the plan fails with a type error that does not point at your addition. This
is why the BACKUP policy carries three explicit `null`s.

### Step 3 — know where it lands

Policies always go to `rg-hub-connectivity-canadacentral-001`; the module
hardcodes `local.rg_names["hub_cc"]`.

### Step 4 — ship the policy

Go to [Shipping the change](#shipping-the-change).

---

## F. Add a firewall

### Step 1 — confirm the network resources exist

The vWAN hub, VNet, subnets and public IPs a firewall attaches to are owned by
`tf-deploy-platform-connectivity` and must exist before this plan runs. This
workspace references them by constructed ID and cannot create them.

### Step 2 — add the key to `local.firewalls`

Secured hub:

```hcl
"azfw-example-canadacentral-001" = {
  rg_key                      = "hub_cc"
  location                    = "canadacentral"
  sku_name                    = "AZFW_Hub"
  sku_tier                    = "Premium"
  firewall_policy_id          = module.firewall_policy["azfwpol-connectivity-001"].resource_id
  zones                       = []
  virtual_hub                 = { public_ip_count = 1, virtual_hub_id = "${local.sub}/resourceGroups/rg-hub-connectivity-canadacentral-001/providers/Microsoft.Network/virtualHubs/vhub-connectivity-canadacentral-001" }
  ip_configurations           = {}
  management_ip_configuration = null
}
```

VNet-based takes the other half — `virtual_hub = null`, with `ip_configurations`
and usually `management_ip_configuration` set. See
`azfw-transit-connectivity-canadacentral-001` for the worked example.

### Step 3 — set every attribute, `null` where unused

Same type-unification constraint as step 2 of section E.

### Step 4 — decide how its rules will be managed

A firewall without a policy cannot have its rules managed through the wrapper — the AVM module
has no input for classic inline `networkRuleCollections`. Attach a policy, or
declare the collections natively in `classic_rules.tf`. See `MODULE_GAPS.md`.

### Step 5 — ship the firewall

Go to [Shipping the change](#shipping-the-change).

---

## G. Add a resource group to the workspace's reach

Only needed when a resource lands in a group this workspace does not already
read. The group must already exist — `tf-deploy-platform-connectivity` owns all
of them, and this workspace only reads.

### Step 1 — add the variable, in `variables.tf`

```hcl
variable "example_resource_group_name" {
  type    = string
  default = "rg-example-canadacentral-001"
}
```

### Step 2 — add the data source, in `data.tf`

```hcl
data "azurerm_resource_group" "example" {
  name = var.example_resource_group_name
}
```

### Step 3 — add the `rg_names` entry, in `locals.tf`

```hcl
example = data.azurerm_resource_group.example.name
```

### Step 4 — extend drift detection

If the new group holds resources of a type this workspace owns, add it to the
`--scope-rg` handling in `.github/workflows/unmanaged-detect.yml`, or drift
detection will not see it.

### Step 5 — ship the wiring

Go to [Shipping the change](#shipping-the-change).

---

## Shipping the change

The same four steps whatever you added.

### Step 1 — branch, change, open a PR

`tflint.yml` and `trivy.yml` run on the PR. Neither reads state.

### Step 2 — run `import-verify.yml`

`workflow_dispatch` only. It plans and gates, never applies. Safe at any time.

### Step 3 — read the plan

For a new resource, expect creates and nothing else. Any **replace** or
**destroy** on something you did not intend to change means a key or a name is
wrong. Stop and fix it rather than approving.

### Step 4 — run `import-apply.yml`

The `check` job plans and publishes a digest of the change set. The `apply` job
sits behind the `firewall` GitHub environment and needs an approver. It blocks
the apply if the change set moved after approval, so a merge landing mid-run
cannot slip through.

All three workflows share the `platform-firewall-management` concurrency group,
so one run touches the estate at a time. Changes from different people land one
after another, each with its own approval.

---

## Things that have gone wrong before

**Resource names that are not what you think.** The generic
`Microsoft.Resources` API lowercases `microsoft.insights` resource IDs and
derives `name` from them, so `az resource show` reports the wrong case. Two VMs
in the sibling repo came back lowercased the same way, one of which would have
destroyed a production server on first apply. When adopting, confirm the name
against the portal or a typed `az` command, never a generic
`az resource show --ids`.

**Names with whitespace or the wrong prefix.** Azure holds a rule literally
named `" r-allow-cyberark-1858 "`, with a leading and trailing space; two rules
named `rc-...`; one collection named `r-...`. They are reproduced verbatim on
purpose. Tidying one is a rename.

**Carriage returns in strings.** KQL queries and similar multi-line values can
carry `\r\n`. A raw CR terminates an HCL string. Escape it or use a heredoc.

**Feature flags.** `enable_firewall` and `enable_ip_groups` both default to
`false` and are set `true` in `firewall.tfvars`. A change that appears to do
nothing usually means the flag is off for the tfvars set being planned.
