locals {
  sub = data.azurerm_subscription.current.id

  common_tags = merge(var.tags, {
    environment = var.environment
    managed-by  = "terraform"
    solution    = "tf-deploy-platform-firewall-management"
  })

  # Keyed the same way az-sub-connectivity-lz keys module.resource_group, so
  # the firewall/IP-group definitions carried over from that repo read
  # unchanged.
  rg_names = {
    hub_cc    = data.azurerm_resource_group.hub_cc.name
    hub_ce    = data.azurerm_resource_group.hub_ce.name
    shared_cc = data.azurerm_resource_group.shared_cc.name
    ip_groups = data.azurerm_resource_group.ip_groups.name
  }
}
